#!/bin/sh
# 豆包信创 V4.31.0 —— Linux（麒麟 / 统信 UOS / 欧拉 / Ubuntu）安装为系统服务
#
# 用法（需要 root）：
#   sudo sh 安装.sh
#
# 做完之后：
#   启动   systemctl start doubao-xinchuang
#   状态   systemctl status doubao-xinchuang
#   停止   systemctl stop doubao-xinchuang
#   开机自启 已自动设置（systemctl is-enabled 可查）
#
# 说明：
#   1) 本脚本按当前目录当作程序目录，请先把整个「豆包信创 V4.31.0」解压到 /opt 下再运行；
#   2) 数据库、附件、备份都放在程序目录的 data/ 里，升级时只替换程序、保留 data 即可；
#   3) Node 版本要求 ≥ 22.5（内置 node:sqlite）。国产系统若自带 node 太旧，请另装 node 22 并改下面的 NODE_BIN。
set -e

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE=doubao-xinchuang
UNIT=/etc/systemd/system/$SERVICE.service
PORT=${PORT:-8787}
RUN_USER=${RUN_USER:-}

# 找 node：优先程序目录自带，其次系统
if [ -x "$APP_DIR/runtime/node" ]; then
  NODE_BIN="$APP_DIR/runtime/node"
elif command -v node >/dev/null 2>&1; then
  NODE_BIN="$(command -v node)"
else
  echo "没找到 node。请先安装 Node.js 22 以上（内置 node:sqlite 模块），例如："
  echo "  麒麟/UOS：sudo apt install nodejs   （或从 nodejs.org 下载 22 LTS 版 tar.gz 解压到 /opt/nodejs）"
  exit 1
fi

echo "程序目录：$APP_DIR"
echo "Node     ：$NODE_BIN（$("$NODE_BIN" -v 2>/dev/null || echo 版本未知)）"

# 没有指定运行用户就用当前 sudo 调用者，避免以 root 跑业务
if [ -z "$RUN_USER" ]; then
  RUN_USER=${SUDO_USER:-$(id -un)}
fi
echo "运行用户：$RUN_USER"

mkdir -p "$APP_DIR/data"
chown -R "$RUN_USER" "$APP_DIR/data" 2>/dev/null || true

cat > "$UNIT" <<EOF
[Unit]
Description=豆包信创档案管理系统
After=network.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$APP_DIR
ExecStart=$NODE_BIN $APP_DIR/server/server.js --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5
# 服务日志走 journald：journalctl -u $SERVICE -f
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE"
systemctl restart "$SERVICE"
sleep 2

echo
echo "已安装并启动。检查状态："
systemctl --no-pager status "$SERVICE" | head -n 12
echo
echo "浏览器打开： http://<本机IP>:$PORT/"
echo "手机端两屏： http://<本机IP>:$PORT/m.html"
echo "日志：       journalctl -u $SERVICE -f"
