@echo off
rem ============================================================
rem  Archive Management System - portable launcher (any location)
rem
rem  Starts the copy of the program that sits in the SAME folder
rem  as this file. Keep this .bat next to the "server" and
rem  "runtime" folders; it works from the Desktop, from D:\, or
rem  straight from a USB stick.
rem
rem  ASCII-only on purpose: cmd.exe parses .bat with the console
rem  codepage, so non-ASCII here breaks on some setups.
rem ============================================================
title Archive Management System
setlocal

set "APPDIR=%~dp0"

if not exist "%APPDIR%server\server.js" goto NOTFOUND
if not exist "%APPDIR%runtime\node.exe" goto NOTFOUND

cd /d "%APPDIR%"

echo.
echo   ============================================================
echo    Archive Management System
echo   ============================================================
echo    Program folder : %APPDIR%
echo.
echo    KEEP THIS BLACK WINDOW OPEN while you use the system.
echo    Closing this window STOPS the service.
echo.
echo    On THIS computer open :  http://127.0.0.1:8787
echo    For phones / other PCs:  use the address printed below
echo   ============================================================
echo.

"%APPDIR%runtime\node.exe" --no-warnings "%APPDIR%server\server.js" --host 0.0.0.0 --open
goto END

:NOTFOUND
echo.
echo   [ERROR] Could not find "server\server.js" and "runtime\node.exe"
echo   next to this file.
echo.
echo   This .bat must stay in the SAME folder as the "server" and
echo   "runtime" folders. Do not move it out, and do not rename
echo   those two folders. Then run it again.
echo.
pause
exit /b 1

:END
echo.
echo   Service stopped. You may close this window.
pause
