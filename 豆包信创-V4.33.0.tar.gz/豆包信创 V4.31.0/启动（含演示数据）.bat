@echo off
rem ============================================================
rem  Archive Management System - Launcher (DEMO data)
rem  NOTE: ASCII-only here too (see main launcher remarks).
rem  Creates 32 sample archives when the database is empty.
rem ============================================================
title Archive Management System - DEMO mode
cd /d "%~dp0"

echo.
echo   Starting in DEMO mode.
echo   If the database is empty, 32 sample archives will be created.
echo.

set "NODEEXE="
if exist "runtime\node.exe" set "NODEEXE=%CD%\runtime\node.exe"

if not defined NODEEXE (
  where node >nul 2>&1
  if not errorlevel 1 (
    for /f "tokens=*" %%v in ('where node') do (
      if not defined NODEEXE set "NODEEXE=%%v"
    )
  )
)

if not defined NODEEXE goto NONODE

echo   Demo login - the banner below prints the real accounts. It is verified against
echo   the database, so it is never stale (a hardcoded password in this file would be).
echo       Step 1  identity : "archive manager" or "other staff"  - there is no username box
echo       Step 2  password : demo reader accounts all use 123456
echo   The banner prints the manager password only while it is still the factory default.
echo.

"%NODEEXE%" --no-warnings "server\server.js" --demo --open
goto END

:NONODE
echo   [ERROR] Node runtime not found (expected runtime\node.exe).
echo.
pause
exit /b 1

:END
echo.
echo   Service stopped.
pause