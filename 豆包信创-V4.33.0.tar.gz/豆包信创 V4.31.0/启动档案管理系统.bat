@echo off
rem ============================================================
rem  Archive Management System - Launcher
rem  NOTE: This file is intentionally ASCII-only.
rem  cmd.exe parses .bat files using the console codepage, so
rem  non-ASCII text here would break on some Windows setups.
rem  All Chinese messages are printed by the server itself below.
rem  Do NOT add "chcp 65001" here: switching the codepage mid-file
rem  makes cmd re-parse the remaining lines as UTF-8 and corrupt them.
rem ============================================================
title Archive Management System - running (close window to stop)
cd /d "%~dp0"

echo.
echo   Starting Archive Management System ...
echo.

if not exist "runtime\node.exe" goto NONODE

echo   Runtime : bundled runtime\node.exe  (nothing to install)
echo.
echo   Browser will open automatically. If not, visit:
echo       http://127.0.0.1:8787
echo.
echo   Account         : see the login line printed by the server below
echo   To stop         : close this window or press Ctrl+C
echo.
echo   Note: the service banner below is printed in Chinese by the server.
echo.

"%CD%\runtime\node.exe" --no-warnings "server\server.js" --open
goto END

:NONODE
echo   [ERROR] runtime\node.exe is missing.
echo.
echo   This package carries its own runtime in the "runtime" folder.
echo   Fix: copy the WHOLE folder again, "runtime" included, then retry.
echo   The folder names "server" and "runtime" must stay unchanged.
echo.
pause
exit /b 1

:END
echo.
echo   Service stopped.
pause
