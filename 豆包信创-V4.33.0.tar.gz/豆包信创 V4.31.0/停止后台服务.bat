@echo off
chcp 65001 >nul
title 停止豆包信创后台服务
setlocal
set "PIDFILE=%~dp0data\server.pid"
if not exist "%PIDFILE%" (
  echo 没有找到进程记录（可能从未用后台方式启动过，或已经停过了）。
  echo 如果你是用「双击启动」黑窗口方式跑的，直接把那个黑窗口关掉即可。
  pause
  exit /b 0
)
for /f "usebackq delims=" %%p in ("%PIDFILE%") do set "PID=%%p"
echo 正在停止进程 %PID% …
taskkill /F /PID %PID% >nul 2>&1
if errorlevel 1 (
  echo 该进程已经不在了（可能你手动关过）。
) else (
  echo 已停止。
)
del "%PIDFILE%" >nul 2>&1
echo.
echo 只停这一套服务，不会误杀本机其它程序。
pause
