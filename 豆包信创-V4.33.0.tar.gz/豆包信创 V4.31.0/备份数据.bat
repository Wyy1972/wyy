@echo off
rem ============================================================
rem  Archive Management System - Data backup
rem  Copies data\ (database + all attachments) into backup\.
rem  NOTE: ASCII-only on purpose (see main launcher remarks).
rem  Do NOT add "chcp 65001" here (see main launcher remarks).
rem ============================================================
title Archive Management System - backup
cd /d "%~dp0"

rem Timestamp is produced by PowerShell, NOT by slicing %date% / %time%.
rem Those two depend on the machine's regional short date/time format
rem (yyyy/MM/dd vs MM/dd/yyyy, and a LEADING SPACE when the hour is a single
rem digit), so the old "set STAMP=%date:~0,4%%date:~5,2%..." slicing produced
rem malformed folder names on other regional settings.
rem PowerShell is present on every supported Windows, so this needs no extra install.
set "STAMP="
for /f "usebackq tokens=*" %%i in (`powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"`) do set "STAMP=%%i"
if not defined STAMP set "STAMP=backup"
set DEST=%~dp0backup\backup_%STAMP%

echo.
echo   Backing up archive data ...
echo.

if not exist "data" goto NODATA
if not exist "backup" mkdir "backup"
mkdir "%DEST%" 2>nul

echo   Copying database ...
copy /y "data\archive.db" "%DEST%\" >nul
if exist "data\archive.db-wal" copy /y "data\archive.db-wal" "%DEST%\" >nul
if exist "data\archive.db-shm" copy /y "data\archive.db-shm" "%DEST%\" >nul

echo   Copying attachments (may take a while for large archives) ...
xcopy "data\files" "%DEST%\files\" /e /i /q /y >nul

echo.
echo   Backup finished:
echo       %DEST%
echo.
echo   To restore: stop the system, copy archive.db back into data\,
echo               and copy the files folder back into data\files\.
echo.
pause
exit /b 0

:NODATA
echo   [ERROR] No "data" folder found. The system has probably never been started.
echo.
pause
exit /b 1
