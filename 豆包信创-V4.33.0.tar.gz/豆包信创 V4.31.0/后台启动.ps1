# 豆包信创 V4.31.0 —— 后台启动（由「后台启动-豆包信创.vbs」隐藏调用，也可直接右键“使用 PowerShell 运行”）
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $base 'data'
if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Path $dataDir | Out-Null }

$node = if (Test-Path (Join-Path $base 'runtime\node.exe')) { Join-Path $base 'runtime\node.exe' } else { 'node' }
$serverJs = Join-Path $base 'server\server.js'
$outLog = Join-Path $dataDir '后台运行日志.txt'
$errLog = Join-Path $dataDir '后台运行错误.txt'
$pidFile = Join-Path $dataDir 'server.pid'

# 已经有服务在跑就不再起第二份（两份同时跑会抢同一个数据库文件）
if (Test-Path $pidFile) {
  $old = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
  if ($old -and (Get-Process -Id ([int]$old) -ErrorAction SilentlyContinue)) {
    Write-Host "服务已经在运行（进程 $old），直接打开页面。"
    Start-Process 'http://127.0.0.1:8787/'
    exit 0
  }
}

$p = Start-Process -FilePath $node -ArgumentList @($serverJs, '--host', '0.0.0.0', '--port', '8787') `
  -WorkingDirectory $base -WindowStyle Hidden -PassThru `
  -RedirectStandardOutput $outLog -RedirectStandardError $errLog
$p.Id | Set-Content -Path $pidFile -Encoding UTF8
Start-Sleep -Seconds 3
Start-Process 'http://127.0.0.1:8787/'
Write-Host "已在后台启动（进程 $($p.Id)）。日志：$outLog"
