#!/bin/sh
# ============================================================
#  档案管理系统 —— 局域网启动脚本（Linux / 麒麟 / 统信 UOS / macOS）
#
#  与「start.sh」的区别：本脚本把服务绑定到 0.0.0.0，
#  同一局域网内的同事和手机才能访问 —— 手机扫二维码必须用这个。
#
#  用法：sh start-lan.sh
# ============================================================

cd "$(dirname "$0")" || exit 1

NODE_BIN=""
if [ -x "runtime/node" ]; then
  NODE_BIN="$PWD/runtime/node"
elif command -v node >/dev/null 2>&1; then
  NODE_BIN="node"
fi

if [ -z "$NODE_BIN" ]; then
  echo ""
  echo "  [错误] 没有找到 Node.js，请先安装 Node.js 22.13 或更高版本。"
  echo "  详细步骤见 start.sh 里的提示。"
  echo ""
  exit 1
fi

echo ""
echo "  Node.js : $("$NODE_BIN" -v)   （$NODE_BIN）"
echo ""
echo "  局域网模式：同一网络内的其他设备可以访问本系统。"
echo "  安全提示：知道地址且拥有账号的人都能登录，用完请关闭本窗口。"
echo ""
echo "  本机可用地址（把其中一个发给同事，或用手机直接打开）："
# 尽量列出真实网卡地址；命令不存在时静默跳过
if command -v hostname >/dev/null 2>&1; then
  hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.' | while read -r ip; do
    echo "      http://$ip:8787/"
  done
fi
if command -v ip >/dev/null 2>&1; then
  ip -4 addr show 2>/dev/null | grep -oE 'inet [0-9.]+' | awk '{print $2}' \
    | grep -v '^127\.' | while read -r ip; do
    echo "      http://$ip:8787/     （网卡地址 $ip）"
  done
fi
echo ""
echo "  手机扫码前请注意："
echo "      ① 手机要和这台电脑连同一个局域网（同一 WiFi / 同一网段）"
echo "      ② 防火墙要放行 8787 端口（firewalld / ufw 都要放行）"
echo "  登录方式 : 选身份（档案管理员 / 其他人员）+ 口令，没有用户名框"
echo "             初始口令见下面的启动横幅（口令若已改过就不会印出来）"
echo "  停止服务 : 在本窗口按 Ctrl+C"
echo ""

exec "$NODE_BIN" --no-warnings "server/server.js" --host 0.0.0.0 --open
