#!/bin/sh
# ============================================================
#  档案管理系统 —— 启动脚本（Linux / 麒麟 / 统信 UOS / macOS）
#
#  用法：
#      sh start.sh          本机使用（只有这台电脑能打开）
#      sh start-lan.sh      局域网使用（同事、手机可以访问，需手机扫码就用这个）
#
#  说明：
#      · 与 Windows 版「启动档案管理系统.bat」功能相同
#      · Windows 分发包里带的 runtime/node.exe 是 Windows 程序，本脚本不使用它，
#        所以 Linux 上必须先自行安装 Node.js（见下面版本要求）
#      · 首次使用如果提示权限不足，可以执行：chmod +x start.sh start-lan.sh backup.sh
# ============================================================

cd "$(dirname "$0")" || exit 1

# ---- 找 Node.js：优先用随包附带的 runtime/node（如果存在），否则用系统的 ----
NODE_BIN=""
if [ -x "runtime/node" ]; then
  NODE_BIN="$PWD/runtime/node"
elif command -v node >/dev/null 2>&1; then
  NODE_BIN="node"
fi

if [ -z "$NODE_BIN" ]; then
  echo ""
  echo "  [错误] 没有找到 Node.js。"
  echo ""
  echo "  本系统需要 Node.js 22.13 或更高版本（推荐 24 LTS），"
  echo "  因为它使用 Node 内置的 SQLite 模块保存档案数据。"
  echo ""
  echo "  安装方法（任选其一）："
  echo "    1) 麒麟 / 统信 UOS 等基于 apt 的系统："
  echo "         sudo apt install nodejs"
  echo "       若源里的版本低于 22.13，请用下面的办法装官方包。"
  echo "    2) 官方预编译包（x86_64 兆芯/海光 机器）："
  echo "         wget https://nodejs.org/dist/v24.20.0/node-v24.20.0-linux-x64.tar.xz"
  echo "         tar -xf node-v24.20.0-linux-x64.tar.xz"
  echo "         sudo mv node-v24.20.0-linux-x64 /opt/node"
  echo "         export PATH=/opt/node/bin:\$PATH      # 可写进 ~/.bashrc"
  echo "    3) ARM64（飞腾、鲲鹏）机器：把上面的 x64 换成 arm64"
  echo "    4) 龙芯（LoongArch）：用龙芯社区的适配版 V22.16.0 loongarch64"
  echo "         https://www.loongnix.cn/zh/api/nodejs/"
  echo ""
  exit 1
fi

echo ""
echo "  Node.js : $("$NODE_BIN" -v)   （$NODE_BIN）"
echo "  启动中，浏览器会自动打开；若没有自动打开，请手动访问窗口里显示的地址。"
echo "  登录方式 : 选身份（档案管理员 / 其他人员）+ 口令，没有用户名框"
echo "             初始口令见下面的启动横幅（口令若已改过就不会印出来）"
echo "  停止服务 : 在本窗口按 Ctrl+C，或直接关闭窗口"
echo ""

exec "$NODE_BIN" --no-warnings "server/server.js" --open
