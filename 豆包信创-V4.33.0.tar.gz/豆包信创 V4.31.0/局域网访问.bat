@echo off
rem ============================================================
rem  Archive Management System - LAN mode launcher
rem
rem  Binds the service to 0.0.0.0 so phones and other PCs on the
rem  same LAN can open it. This is REQUIRED for scanning the QR
rem  codes with a phone: with the default 127.0.0.1 binding the
rem  phone can never reach the page, and users report it as
rem  "the QR code cannot be scanned".
rem
rem  ASCII-only on purpose: cmd.exe parses .bat using the console
rem  codepage, so non-ASCII text here breaks on some Windows setups.
rem  Do NOT add "chcp 65001" here (see the main launcher remarks).
rem ============================================================
title Archive Management System - LAN mode
cd /d "%~dp0"

echo.
echo   Starting in LAN mode.
echo   Other devices on the same network (phones, other PCs) can
echo   open this system. Keep this window open while in use.
echo.
echo   Security note: anyone on the same LAN who knows the address
echo   and has a valid account can log in.
echo.

rem Prefer the BUNDLED runtime: this package is portable and must start on a
rem machine with no system Node.js at all. Only fall back to a system node.
set "NODEEXE="
if exist "runtime\node.exe" set "NODEEXE=%CD%\runtime\node.exe"
if not defined NODEEXE (
  where node >nul 2>&1
  if not errorlevel 1 for /f "tokens=*" %%v in ('where node') do if not defined NODEEXE set "NODEEXE=%%v"
)
if not defined NODEEXE goto NONODE
echo   Node.js runtime : %NODEEXE%
echo.
echo   The server banner below prints the real LAN addresses.
echo   Type one of them into the phone browser, or scan the QR code
echo   shown in the system (Barcode / Scan self-check).
echo.
echo   Account : see the login line printed by the server below
echo   Stop            : close this window or press Ctrl+C
echo.
echo   If the phone still cannot open the page, allow the port
echo   through Windows Firewall on this machine.
echo.

"%CD%\runtime\node.exe" --no-warnings "server\server.js" --host 0.0.0.0 --open
goto END

:NONODE
echo   [ERROR] No Node runtime found.
echo.
echo   This package should carry its own runtime in the "runtime" folder
echo   (runtime\node.exe). If that folder is missing, copy the WHOLE folder
echo   again, "runtime" included.
echo   A system-wide Node.js 18 or newer ^(22 / 24 recommended^) also works:
echo   https://nodejs.org/en/download
echo.
pause
exit /b 1

:END
echo.
echo   Service stopped.
pause
