' 豆包信创 V4.31.0 —— 后台启动（无黑窗口常驻）
' 双击本文件：服务在后台运行，浏览器关掉也不会停；重启电脑后需要再双击一次。
' 要停止：双击「停止后台服务.bat」。
Option Explicit
Dim fso, sh, base, q, runLine
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
q = Chr(34)
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
runLine = "powershell -NoProfile -ExecutionPolicy Bypass -File " & q & base & "\后台启动.ps1" & q
' 0 = 隐藏窗口；False = 不等待，脚本立即结束
sh.Run runLine, 0, False
