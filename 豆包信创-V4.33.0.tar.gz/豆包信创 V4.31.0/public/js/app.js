/* ============================================================
 * 档案管理系统 前端应用（原生 JS，无依赖）
 * ============================================================ */
(() => {
  'use strict';

  // ---------------- 全局状态 ----------------
  const state = {
    user: null,
    // 角色名兜底表（真实值由登录/me 接口下发，见 api.js 的 policy.ROLE_NAMES）。
    // 六个角色一个都不能少：少了三员，用户在"服务端还没回话"的那一瞬间
    // 会在顶栏看到 secadmin 这种英文代号（v4.16.3 修正）。
    roleNames: {
      admin: '管理员', sysadmin: '系统管理员', secadmin: '系统安全保密员',
      auditor: '系统安全审计员', clerk: '档案员', reader: '普通用户',
    },
    // 我的权限（服务端下发，见 api.js 的 myAccess）。界面**只依据它**决定显示什么，
    // 这样界面与实际权限不可能对不上：显示得出来就点得动，点不动就不会显示（v4.17.0）。
    actions: {},
    views: [],
    // 对外暴露的两种身份（档案管理员 / 其他人员），由服务端下发（v4.18.0）
    identities: [],
    // 口令策略（服务端下发）：对话框里的"至少 N 位 / 不能含用户名…"必须来自这里，
    // 不许在前端写死 —— 写死就会跟真实规则错开（v4.20.3 修的就是这个）。
    passwordPolicy: null,
    types: [],
    categories: [],
    catFlat: [],
    meta: { retentions: [], secretLevels: [], carriers: [], statuses: [] },
    view: 'workbench',
    archiveQuery: {},
    archivePage: 1,
    version: '4.6.0',
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  /**
   * 连续著录的会话状态（v4.13.0）。
   *
   * carryOver 只在**点过「保存并录下一条」之后**才有值 —— 所以直接进著录页时
   * 什么都不会被沿用，"东一条西一条"的录法天然不会带错值。
   * 这是页面级会话状态，不进库：换台机器接着录就该是干净的，带着上次的值反而不安全。
   */
  let carryOver = null;
  let batchCount = 0;

  /**
   * 按「含静区的总格数」算出二维码的显示像素尺寸。
   *
   * 为什么要算而不是写死：
   *   二维码的模块数随内容长度变化（版本 1~10 → 21~57 模块，含静区 33~69 格）。
   *   写死一个像素尺寸（比如 190px）时，长档号的码每个模块只剩 3 像素，屏幕根本扫不出。
   *   这里让显示尺寸 = 格数 × 整数倍率，并且：
   *     · 倍率尽量大（越大越好扫），上限 maxPx
   *     · 但每个模块不小于 MIN_MODULE_PX 像素
   *   因为倍率是整数、且显示尺寸就等于图片原生尺寸，浏览器不会做任何缩放，模块边缘是硬的。
   */
  const MIN_MODULE_PX = 6;
  function qrNaturalPx(info, maxPx) {
    const cells = info.cells || (info.modules + (info.margin || 0) * 2);
    let scale = Math.floor(maxPx / cells);
    if (scale < MIN_MODULE_PX) scale = MIN_MODULE_PX;
    return cells * scale;
  }

  function el(tag, attrs, html) {
    const n = document.createElement(tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v);
    }
    if (html !== undefined) n.innerHTML = html;
    return n;
  }

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fmtSize(b) {
    const n = Number(b) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  }

  function fmtTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return String(iso);
    const p = (x) => String(x).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  function fmtDay(iso) { return iso ? String(iso).slice(0, 10) : ''; }

  function toast(msg, kind, ms) {
    const wrap = $('#toast-wrap');
    const t = el('div', { class: 'toast ' + (kind || '') }, esc(msg));
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, (ms || 2600) - 300);
    setTimeout(() => t.remove(), ms || 2600);
  }

  /**
   * 右键菜单（v4.30.1 起）。
   * items: [{ label, onClick, danger?, disabled? } | { sep: true }]
   * 同屏只允许存在一个；点击别处 / Esc / 窗口失焦都会关掉。
   */
  function showContextMenu(x, y, items) {
    $$('.ctx-menu').forEach((n) => n.remove());
    if (!items || !items.length) return null;
    const menu = el('div', { class: 'ctx-menu', role: 'menu' });
    items.forEach((it) => {
      if (it.sep) { menu.appendChild(el('div', { class: 'ctx-sep' })); return; }
      const b = el('button', {
        class: 'ctx-item' + (it.danger ? ' danger' : '') + (it.disabled ? ' disabled' : ''),
        type: 'button', role: 'menuitem',
      }, esc(it.label));
      if (it.disabled) b.disabled = true;
      else b.onclick = (e) => { e.stopPropagation(); close(); it.onClick(); };
      menu.appendChild(b);
    });
    function close() {
      document.removeEventListener('mousedown', onDown, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('blur', close);
      window.removeEventListener('resize', close);
      menu.remove();
    }
    function onDown(e) { if (!menu.contains(e.target)) close(); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.body.appendChild(menu);
    const r = menu.getBoundingClientRect();
    menu.style.left = Math.max(8, Math.min(x, window.innerWidth - r.width - 8)) + 'px';
    menu.style.top = Math.max(8, Math.min(y, window.innerHeight - r.height - 8)) + 'px';
    setTimeout(() => {
      document.addEventListener('mousedown', onDown, true);
      document.addEventListener('keydown', onKey, true);
      window.addEventListener('blur', close);
      window.addEventListener('resize', close);
    }, 0);
    return menu;
  }

  // ---------------- API ----------------
  async function api(pathname, { method = 'GET', body, raw = false } = {}) {
    const opts = { method, headers: {}, credentials: 'same-origin' };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(pathname, opts);
    if (raw) return res;
    let json = null;
    try { json = await res.json(); } catch (_) { json = null; }
    if (!res.ok || !json || json.ok === false) {
      const err = new Error((json && json.error) || `请求失败（HTTP ${res.status}）`);
      err.status = res.status;
      err.code = json && json.code;
      // 高级检索表达式出错时后端会带上出错字符下标，前端据此把位置标出来
      err.position = json && json.position;
      throw err;
    }
    return json.data;
  }

  /** 带进度条的上传 */
  function uploadWithProgress(url, formData, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.withCredentials = true;
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        let json = null;
        try { json = JSON.parse(xhr.responseText); } catch (_) { json = null; }
        if (xhr.status >= 200 && xhr.status < 300 && json && json.ok) resolve(json.data);
        else reject(new Error((json && json.error) || `上传失败（HTTP ${xhr.status}）`));
      };
      xhr.onerror = () => reject(new Error('网络错误，上传失败'));
      xhr.send(formData);
    });
  }

  // ---------------- 弹窗 ----------------
  const modal = {
    open(title, bodyHtml, footNodes, opts = {}) {
      const dlg = $('#modal');
      dlg.className = 'modal' + (opts.wide ? ' wide' : '') + (opts.narrow ? ' narrow' : '');
      $('#modal-title').textContent = title;
      const body = $('#modal-body');
      // 用鸭子类型判断是否为 DOM 节点，避免依赖可能不存在的全局 Node 构造器
      const isNode = bodyHtml && typeof bodyHtml === 'object' && typeof bodyHtml.nodeType === 'number';
      if (isNode) { body.innerHTML = ''; body.appendChild(bodyHtml); }
      else body.innerHTML = bodyHtml === undefined || bodyHtml === null ? '' : String(bodyHtml);
      const foot = $('#modal-foot');
      foot.innerHTML = '';
      (footNodes || []).forEach((n) => foot.appendChild(n));
      foot.classList.toggle('hidden', !(footNodes && footNodes.length));
      if (!dlg.open) dlg.showModal();
      return body;
    },
    close() { const d = $('#modal'); if (d.open) d.close(); },
  };

  function btn(text, cls, onClick) {
    const b = el('button', { class: 'btn ' + (cls || ''), type: 'button' }, esc(text));
    if (onClick) b.addEventListener('click', onClick);
    return b;
  }

  /**
   * 是不是在"应用内置浏览器"里打开的（微信 / QQ / 钉钉 / 支付宝 …）。
   *
   * 为什么要专门认这件事（v4.20.10）：这些 WebView **从设计上就不支持下载文件**。
   * 使用者一点下载，它只弹自己的一句提示（实测微信里是
   * 「可在浏览器打开此网页来下载文件」），**请求根本不会发到服务端**。
   * 这一点在服务端审计日志里看得很清楚：手机那几次"下载"一条记录都没有。
   * 我们先后换过三种下载实现（整页直链 / fetch+Blob / 短时票据直链）全都无效 ——
   * 因为问题不在实现，而在这个容器没有下载能力。
   * 正确的做法不是继续换写法，而是**把使用者引导到真正的浏览器**。
   */
  function inAppBrowser() {
    // ⚠ 必须防御式读取：回归里的「前端冒烟测试」用 DOM 仿真跑这个文件，
    // 那个环境**没有 navigator** —— 直接写 `navigator.userAgent` 会抛
    // ReferenceError，把整个详情弹窗的渲染打断（v4.24.0 实测撞到）。
    // 一个"读全局拿环境信息"的函数，不该假设宿主一定有那个全局。
    const nav = (typeof navigator !== 'undefined' && navigator) ? navigator : null;
    const ua = (nav && nav.userAgent) || '';
    const list = [
      ['MicroMessenger', '微信'], ['QQ/', 'QQ'], ['DingTalk', '钉钉'],
      ['AliApp', '支付宝'], ['Weibo', '微博'], ['baiduboxapp', '百度'],
      ['Quark', '夸克'], ['SogouMobileBrowser', '搜狗'],
    ];
    for (const [key, name] of list) if (ua.indexOf(key) >= 0) return name;
    return '';
  }

  /** 复制文本。内置浏览器多半没有 clipboard API，所以必须带 execCommand 兜底。 */
  async function copyText(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) { /* 落到下面的老办法 */ }
    try {
      const ta = el('textarea', {});
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      ta.style.top = '0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, ta.value.length);
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (_) { return false; }
  }

  /**
   * 顶部提示条：在应用内置浏览器里打开时，明确告诉使用者"这里下不了，
   * 请到真正的浏览器里打开"，并给出可复制的网址。
   * 与其让他反复点下载、反复失败，不如一次把原因和出路讲清楚。
   */
  function webViewNotice() {
    const host = $('#app-view');
    if (!host) return;
    const old = $('#webview-notice');
    if (old) old.remove();
    const name = inAppBrowser();
    if (!name) return;
    const url = location.origin + '/';
    const box = el('div', { class: 'webview-notice', id: 'webview-notice' });
    box.innerHTML = '<b>当前是在「' + esc(name) + '」内置浏览器里打开的，它不支持下载文件。</b>'
      + '点「下载」只会看到它自己的一句提示（例如「可在浏览器打开此网页来下载文件」），'
      + '文件其实没有开始下载 —— 这不是系统的问题，是这类内置浏览器的限制。<br>'
      + '请点右上角 <b>⋯</b> → <b>在浏览器打开</b>，或在手机浏览器里手动输入：';
    box.appendChild(el('div', { class: 'mono', style: 'margin:6px 0', text: url }));
    const row = el('div', { class: 'flex', style: 'gap:6px;flex-wrap:wrap' });
    const cp = el('button', { class: 'btn btn-sm btn-primary', text: '复制网址' });
    cp.onclick = async () => {
      const ok = await copyText(url);
      toast(ok ? '网址已复制 —— 粘贴到手机浏览器打开即可' : '复制没成功，请照着上面手动输入', ok ? 'ok' : 'err', 7000);
    };
    const dismiss = el('button', { class: 'btn btn-sm', text: '知道了' });
    dismiss.onclick = () => box.remove();
    row.appendChild(cp);
    row.appendChild(dismiss);
    box.appendChild(row);
    host.insertBefore(box, host.firstChild);
  }

  function confirmDialog(title, message, onOk, okText) {
    const body = el('div', {}, `<p style="margin:0 0 6px;line-height:1.7">${esc(message)}</p>`);
    modal.open(title, body, [
      btn('取消', '', () => modal.close()),
      btn(okText || '确定', 'btn-primary', async () => {
        modal.close();
        await onOk();
      }),
    ], { narrow: true });
  }

  function promptDialog(title, fields, onSubmit, opts = {}) {
    const wrap = el('div', { class: 'form-grid' });
    // 报错不只在右下角弹一条一闪而过的红条，还要**留在对话框里**（v4.20.3）。
    // 起因：使用者重置密码失败时只看到"没反应"——红条出现过但没被注意到，
    // 于是结论变成"重置密码不成功"。错误留在原地，人才知道该改什么。
    const errBox = el('div', { class: 'hint-box warn span-2 hidden', id: 'dlg-err' });
    fields.forEach((f) => {
      const span = el('label', { class: 'field' + (f.span2 ? ' span-2' : '') });
      span.appendChild(el('span', {}, esc(f.label) + (f.required ? '<b class="req">*</b>' : '')));
      let input;
      if (f.type === 'textarea') input = el('textarea', { name: f.name, rows: f.rows || 3 });
      else if (f.type === 'select') {
        input = el('select', { name: f.name });
        (f.options || []).forEach((o) => {
          const val = typeof o === 'string' ? o : o.value;
          const lb = typeof o === 'string' ? o : o.label;
          input.appendChild(el('option', { value: val, text: lb }));
        });
      } else input = el('input', { type: f.type || 'text', name: f.name, value: f.value === undefined ? '' : f.value });
      // 浏览器会把「门类名称」这类输入框当成个人信息，弹出"保存的个人信息 / 电子钱包"下拉，
      // 挡住表单又点不掉。关掉自动填充与拼写检查（v4.30.4）。
      if (input.tagName !== 'SELECT') {
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('autocorrect', 'off');
        input.setAttribute('autocapitalize', 'off');
        input.setAttribute('spellcheck', 'false');
      }
      if (f.placeholder) input.setAttribute('placeholder', f.placeholder);
      if (f.required) input.required = true;
      span.appendChild(input);
      if (f.help) span.appendChild(el('div', { class: 'help' }, esc(f.help)));
      wrap.appendChild(span);
    });
    wrap.appendChild(errBox);
    modal.open(title, wrap, [
      btn('取消', '', () => modal.close()),
      btn(opts.okText || '保存', 'btn-primary', async () => {
        const data = {};
        let bad = null;
        fields.forEach((f) => {
          const node = wrap.querySelector(`[name="${f.name}"]`);
          data[f.name] = node ? node.value : '';
          if (f.required && !String(data[f.name]).trim()) bad = bad || f.label;
        });
        if (bad) return toast('请填写：' + bad, 'warn');
        errBox.classList.add('hidden');
        const okBtn = $('#modal-foot button:last-child');
        okBtn.disabled = true;
        try {
          await onSubmit(data);
          modal.close();
        } catch (e) {
          errBox.textContent = e.message || String(e);
          errBox.classList.remove('hidden');
          toast(e.message, 'err');
          okBtn.disabled = false;
        }
      }),
    ], { narrow: opts.wide ? false : true, wide: !!opts.wide });
    const first = wrap.querySelector('input,select,textarea');
    if (first) setTimeout(() => first.focus(), 60);
  }

  // ---------------- 视图框架 ----------------
  const VIEW_TITLES = {
    workbench: '工作台', dashboard: '看板', archives: '档案检索', textsearch: '正文检索', create: '档案著录',
    retention: '鉴定工作台', storage: '实体管理', transfer: '档案移交', quality: '数据体检',
    todos: '待办与提醒',
    scan: '扫码工作台',
    downloads: '下载审批',
    detection: '四性检测', compliance: '合规体检', backup: '备份与存储',
    import: '导入导出', loans: '借阅管理', logs: '操作日志', manage: '系统管理', report: '统计报表',
  };

  function setView(view, params) {
    state.view = view;
    $$('#nav .nav-item').forEach((n) => n.classList.toggle('active', n.dataset.view === view));
    $('#crumb').textContent = VIEW_TITLES[view] || view;
    const content = $('#content');
    // 越权直达的兜底（v4.17.0）：菜单里已经藏了，但地址栏的 #/... 或历史记录仍可能带过来。
    // 与其渲染出一个请求全 403 的破页面，不如当场说清楚"这个功能你的角色没有权限"，
    // 并告知该找谁 —— 权限只由服务端下发，这里只是把它说出来。
    const noNavCheck = ['workbench', 'dashboard', 'report'];
    if (!noNavCheck.includes(view) && Array.isArray(state.views) && state.views.length && !state.views.includes(view)) {
      content.innerHTML = `<div class="empty"><b>当前角色没有这个功能的权限</b>`
        + `你的角色是「${esc((state.roleNames || {})[state.user && state.user.role] || (state.user && state.user.role) || '')}」，`
        + `可使用：${state.views.map((v) => esc(VIEW_TITLES[v] || v)).join('、')}<br>`
        + '如需该权限，请联系档案管理员调整。</div>';
      return;
    }
    content.innerHTML = '<div class="empty">加载中…</div>';
    const render = {
      workbench: renderWorkbench,
      dashboard: renderDashboard,
      todos: () => renderTodos(params),
      scan: () => renderScan(params),
      downloads: () => renderDownloads(params),
      archives: renderArchives,
      textsearch: () => renderTextSearch(params),
      create: renderCreate,
      retention: () => renderRetention(params),
      storage: () => renderStorage(params),
      transfer: () => renderTransfer(params),
      quality: () => renderQuality(params),
      detection: () => renderDetection(params),
      compliance: () => renderCompliance(params),
      backup: () => renderBackup(params),
      import: () => renderImport(params),
      loans: () => renderLoans(params),
      logs: renderLogs,
      report: () => renderReport(params),
      manage: () => renderManage(params),
    }[view] || renderWorkbench;
    Promise.resolve(render(params)).catch((e) => {
      content.innerHTML = `<div class="empty"><b>加载失败</b>${esc(e.message)}</div>`;
      if (e.status === 401) return logoutLocal();
    });
  }

  // ---------------- 工作台（v4.30.2）----------------
  // 使用者的分法：工作台是"每天开工的地方"，把 著录 / 档案检索 / 正文检索 / 扫码 收成四块入口；
  // 原来那张统计图表页改名「看板」（renderDashboard），它只负责看数据，不冒充开工入口。
  // 权限仍然只认服务端下发的 state.views —— 看不到的入口就不画出来。
  function renderWorkbench() {
    const views = Array.isArray(state.views) ? state.views : [];
    const has = (v) => !views.length || views.includes(v);
    const tiles = [
      { go: 'create', icon: '＋', name: '档案著录', desc: '按门类逐条登记，档号自动生成', main: true },
      { go: 'archives', icon: '▦', name: '档案检索', desc: '按档号、题名、年度、门类查找' },
      { go: 'textsearch', icon: '⌕', name: '正文检索', desc: '在附件正文里找关键词' },
      { go: 'scan', icon: '▮', name: '扫码工作台', desc: '扫码定位盒与件，快速上架下架' },
    ].filter((t) => has(t.go));
    const quick = [
      { go: 'todos', name: '待办与提醒' },
      { go: 'loans', name: '借阅管理' },
      { go: 'transfer', name: '档案移交' },
      { go: 'retention', name: '到期与鉴定' },
      { go: 'storage', name: '实体管理' },
      { go: 'dashboard', name: '看板' },
    ].filter((q) => q.go === 'dashboard' || has(q.go));
    const u = state.user || {};
    const hour = new Date().getHours();
    const hello = hour < 6 ? '夜深了' : hour < 12 ? '上午好' : hour < 18 ? '下午好' : '晚上好';
    $('#content').innerHTML = `
      <div class="wb-head">
        <h2 class="wb-title">${hello}，${esc(u.display_name || u.username || '')}</h2>
        <p class="wb-sub">日常四件事：登记、查档、找正文、扫码。<a href="/m.html" target="_blank" style="color:var(--c-primary,#1d4ed8)">手机端（扫码 / 拍照传件）</a></p>
      </div>
      <div class="wb-grid">
        ${tiles.map((t) => `
          <button class="wb-tile${t.main ? ' wb-tile-main' : ''}" data-go="${t.go}">
            <span class="wb-ico">${t.icon}</span>
            <span class="wb-name">${t.name}</span>
            <span class="wb-desc">${t.desc}</span>
            <span class="wb-arrow">→</span>
          </button>`).join('')}
      </div>
      <div class="grid grid-4 mb16" id="wb-stats" hidden></div>
      <div class="card" id="wb-cockpit-card">
        <div class="card-head"><h3>管理驾驶舱</h3>
          <button class="btn btn-sm" id="wb-cockpit-refresh">刷新</button></div>
        <div id="wb-cockpit"><div class="help">正在汇总…</div></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>常用</h3></div>
        <div class="wb-quick">
          ${quick.map((q) => `<button class="btn btn-sm" data-go="${q.go}">${q.name}</button>`).join('')}
        </div>
      </div>
      <div class="grid grid-2 mb16">
        <div class="card" style="margin:0">
          <div class="card-head"><h3>数据与备份</h3></div>
          <div class="help" id="wb-backup">正在读取备份状态…</div>
          <div class="flex mt8" style="gap:8px;flex-wrap:wrap">
            <button class="btn btn-sm btn-primary" id="wb-backup-run">立即备份</button>
            <button class="btn btn-sm" data-go="backup">备份与存储</button>
          </div>
        </div>
        <div class="card" style="margin:0">
          <div class="card-head"><h3>一键出表</h3></div>
          <div class="help">不用一件件凑，直接从全库出表；按盒的卷内目录/盒脊在“实体管理”。</div>
          <div class="flex mt8" style="gap:8px;flex-wrap:wrap">
            <button class="btn btn-sm" data-print="/api/print/catalog">案卷目录（全部）</button>
            <button class="btn btn-sm" data-print="/api/print/catalog?year=${new Date().getFullYear()}">案卷目录（${new Date().getFullYear()} 年）</button>
            <button class="btn btn-sm" data-print="/api/print/stamps">归档章套打（全部）</button>
            <button class="btn btn-sm" data-go="storage">盒内目录 / 盒脊</button>
          </div>
        </div>
      </div>`;
    $$('#content [data-go]').forEach((b) => { b.onclick = () => setView(b.dataset.go); });
    // 一键出表：直接按现有打印接口打开新窗口（参数即筛选条件）
    $$('#content [data-print]').forEach((b) => { b.onclick = () => window.open(b.dataset.print, '_blank'); });

    // 今日要看：只放四张能点的数字卡 —— 待办、待批、逾期、馆藏。
    // 两个接口任一失败就整块不显示（工作台不能因为统计挂了变白页）。
    (async () => {
      try {
        const [s, t] = await Promise.all([
          api('/api/stats/overview').catch(() => null),
          api('/api/todos?status=open&limit=1').catch(() => null),
        ]);
        const box = $('#wb-stats');
        if (!box) return;
        const todoN = (t && t.counts && t.counts.open) || 0;
        const critN = (t && t.counts && t.counts.critical) || 0;
        const cards = [
          { label: '待办与提醒', value: todoN, foot: critN ? `紧急 ${critN} 条` : (todoN ? '按期限处理' : '没有待办'), go: 'todos' },
          { label: '借阅待审批', value: s ? s.loanStats.pending : '—', foot: '去借阅管理处理', go: 'loans' },
          { label: '逾期未还', value: s ? s.loanStats.overdue : '—', foot: s && s.loanStats.overdue ? '需要催还' : '没有逾期', go: 'loans' },
          { label: '馆藏档案总量', value: s ? s.total : '—', foot: s ? `${s.typeCount} 个门类 · ${s.fileCount} 个附件` : '', go: 'archives' },
        ];
        box.innerHTML = cards.map((k) => `
          <div class="stat" data-go="${k.go}" style="cursor:pointer">
            <div class="stat-accent"></div>
            <div class="stat-label">${k.label}</div>
            <div class="stat-value">${k.value}</div>
            <div class="stat-foot">${k.foot}</div>
          </div>`).join('');
        box.hidden = false;
        $$('#wb-stats [data-go]').forEach((b) => { b.onclick = () => setView(b.dataset.go); });
      } catch (_) { /* 概览取不到就不显示 */ }
    })();

    // 备份状态：数据放在哪、多大、上次什么时候备的、还差几套。
    // 没有备份权限的账号（普通读者）看到的是"联系管理员"，不是一堆报错。
    (async () => {
      const box = $('#wb-backup');
      if (!box) return;
      try {
        const s = await api('/api/backup/status');
        const mb = (n) => (Number(n || 0) / 1048576).toFixed(1) + ' MB';
        const d = s.data || {};
        const latest = (s.usableBackups && s.usableBackups[0]) || null;
        const okN = (s.counts && s.counts.usable) || 0;
        const need = (s.requirement && s.requirement.requiredCopies) || 3;
        box.innerHTML = `
          <div>数据目录：<span class="mono">${esc(String(d.dir || '—'))}</span></div>
          <div>数据体量：库 <b>${mb(d.db_bytes)}</b>　附件 <b>${mb(d.files_bytes)}</b></div>
          <div>上次备份：<b>${latest ? esc(String(latest.created_at || '').replace('T', ' ').slice(0, 16)) : '<span style="color:#c2410c">还没备份过</span>'}</b></div>
          <div>备份套数：${okN} / ${need}${okN >= need ? ' <span style="color:#15803d">已达标</span>' : ' <span style="color:#c2410c">还不够</span>'}</div>`;
        const runBtn = $('#wb-backup-run');
        if (runBtn) {
          runBtn.onclick = async () => {
            runBtn.disabled = true;
            runBtn.textContent = '正在备份…';
            try {
              await api('/api/backup/run', { method: 'POST', body: {} });
              toast('备份完成', 'ok');
              renderWorkbench();
            } catch (e) {
              toast(e.message || '备份失败', 'err');
              runBtn.disabled = false;
              runBtn.textContent = '立即备份';
            }
          };
        }
      } catch (e) {
        box.innerHTML = '<div class="help">当前账号没有查看备份状态的权限，需要时请联系档案管理员。</div>';
        const runBtn = $('#wb-backup-run');
        if (runBtn) runBtn.hidden = true;
      }
    })();

    // 管理驾驶舱（v4.32.0）：给管理者看"整库现在什么状态、哪里有风险"，而不是让他在五个页面间来回翻。
    const cockpit = async () => {
      const box = $('#wb-cockpit');
      if (!box) return;
      try {
        const c = await api('/api/cockpit');
        const bar = (label, arr, total) => {
          if (!arr || !arr.length) return '';
          const top = arr.slice(0, 6);
          return `<div style="margin-bottom:8px">
            <div class="muted" style="font-weight:600;margin-bottom:4px">${esc(label)}</div>
            ${top.map((x) => {
    const n = Number(x.count) || 0;
    const pct = total ? Math.round((n / total) * 100) : 0;
    return `<div style="display:flex;align-items:center;gap:8px;font-size:12.5px;margin-bottom:3px">
                <span style="width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(String(x.name || '未填'))}</span>
                <span style="flex:1;height:7px;background:var(--c-line,#e5e7eb);border-radius:4px;overflow:hidden">
                  <span style="display:block;width:${pct}%;height:100%;background:var(--c-primary,#1d4ed8)"></span></span>
                <span class="muted" style="width:52px;text-align:right">${n}</span></div>`;
  }).join('')}</div>`;
        };
        const riskTag = { error: 'tag-red', warn: 'tag-amber', info: 'tag-blue' };
        const risks = (c.risks || []).map((r) => `<div style="display:flex;gap:8px;align-items:baseline;margin-bottom:5px">
            <span class="tag ${riskTag[r.level] || 'tag'}">${esc(r.kind)}</span>
            <b>${Number(r.count) || 0}</b>
            ${(r.items || []).length ? `<span class="muted" style="font-size:11.5px">如 ${esc((r.items[0] || {}).title || (r.items[0] || {}).archive_code || '')}…</span>` : ''}
          </div>`).join('') || '<div class="help" style="color:#15803d">没有发现明显风险。</div>';
        const prog = (c.progress || []).map((p) => `<div style="display:flex;gap:8px;align-items:center;font-size:12.5px;margin-bottom:3px">
            <span style="width:66px">${esc(p.label)}</span>
            <span style="flex:1;height:7px;background:var(--c-line,#e5e7eb);border-radius:4px;overflow:hidden">
              <span style="display:block;width:${p.ratio}%;height:100%;background:${p.ratio >= 95 ? '#15803d' : p.ratio >= 70 ? '#c2410c' : '#b91c1c'}"></span></span>
            <span class="muted" style="width:74px;text-align:right">${p.ratio}%${p.missing ? `（缺${p.missing}）` : ''}</span>
          </div>`).join('');
        const noEv = (c.risks || []).filter((r) => r.kind === '未做四性取证').reduce((n, r) => n + Number(r.count || 0), 0);
        const evPct = c.total ? Math.round(((c.total - noEv) / c.total) * 100) : 0;
        box.innerHTML = `
          <div class="grid grid-4 mb16">
            <div class="stat"><div class="stat-accent"></div><div class="stat-label">馆藏总量</div>
              <div class="stat-value">${c.total}</div><div class="stat-foot">有附件 ${c.withFiles} 件 · 含电子 ${c.electronic} 件</div></div>
            <div class="stat"><div class="stat-accent"></div><div class="stat-label">四性取证覆盖</div>
              <div class="stat-value">${evPct}%</div><div class="stat-foot">缺证据的件会列在风险里</div></div>
            <div class="stat"><div class="stat-accent"></div><div class="stat-label">著录完成度</div>
              <div class="stat-value">${c.progress && c.progress.length ? Math.round(c.progress.reduce((n, p) => n + p.ratio, 0) / c.progress.length) : 0}%</div>
              <div class="stat-foot">七项关键字段平均填写率</div></div>
            <div class="stat"><div class="stat-accent"></div><div class="stat-label">风险项</div>
              <div class="stat-value">${(c.risks || []).length}</div><div class="stat-foot">${(c.risks || []).length ? '见下方清单' : '暂无'}</div></div>
          </div>
          <div class="grid grid-2" style="gap:16px">
            <div>${bar('按门类', c.byType, c.total)}${bar('按年度', c.byYear, c.total)}</div>
            <div>${bar('按保管期限', c.byRetention, c.total)}${bar('按办理进度', c.byLifecycle, c.total)}</div>
          </div>
          <div class="grid grid-2" style="gap:16px;margin-top:8px">
            <div><div class="section-title" style="margin-top:0">著录质量</div>${prog || '<div class="muted">还没有档案</div>'}</div>
            <div><div class="section-title" style="margin-top:0">风险清单</div>${risks}</div>
          </div>
          <div class="help mt8">最后汇总：${esc(String(c.generated_at || '').replace('T', ' ').slice(0, 16))}</div>`;
      } catch (e) {
        box.innerHTML = `<div class="help">驾驶舱数据读取失败：${esc(e.message || '')}（其它功能不受影响）</div>`;
      }
    };
    cockpit();
    const ckBtn = $('#wb-cockpit-refresh');
    if (ckBtn) ckBtn.onclick = () => {
      const b = $('#wb-cockpit');
      if (b) b.innerHTML = '<div class="help">正在汇总…</div>';
      cockpit();
    };

    refreshTodoBadge();
  }

  // ---------------- 看板 ----------------
  async function renderDashboard() {
    const s = await api('/api/stats/overview');
    // 工作台的主角是「接收作业区」（v4.30.0）：只有能读档案的人才需要它。
    // 它取不到时只少这一块，统计与提醒照常显示 —— 工作台不能因为一个接口挂掉就整页失败。
    let intake = { projects: [], batches: [] };
    if (can('archive:read')) {
      try { intake = await loadIntakeData(); } catch (_) { /* 忽略，保底是空 */ }
    }
    const c = $('#content');
    const loanBadge = $('#nav-loan-badge');
    if (s.loanStats.pending > 0 && state.user.role !== 'reader') {
      loanBadge.textContent = s.loanStats.pending;
      loanBadge.classList.remove('hidden');
    } else loanBadge.classList.add('hidden');
    if (s.loanStats.overdue > 0) {
      const p = $('#pill-overdue');
      p.textContent = `逾期未还 ${s.loanStats.overdue} 件`;
      p.hidden = false;
      p.style.cursor = 'pointer';
      p.onclick = () => setView('loans', { status: '逾期' });
    } else $('#pill-overdue').hidden = true;

    // 到期鉴定提醒
    try {
      const dueInfo = await api('/api/retention/due?exact=1&to=' + new Date().getFullYear());
      const cnt = (dueInfo.counts && dueInfo.counts.overdue) || 0;
      const badge = $('#nav-due-badge');
      if (badge) {
        if (cnt > 0) { badge.textContent = cnt; badge.classList.remove('hidden'); }
        else badge.classList.add('hidden');
      }
    } catch (_) { /* 普通用户无权限，忽略 */ }

    // 待办红点（v13）：回到工作台时刷新一次
    refreshTodoBadge();

    // 全宗信息提醒（v4.20.0）。
    //
    // 原来的"首次使用向导"已经删掉（使用者明确说它没用了：登录页已经定死两种身份，
    // 向导那套建号/定角色的事都成了废动作）。但**有一条不能跟着一起消失** ——
    // 全宗号如果还是出厂占位值 Z001，那么之后每一件档案的档号都会带着 Z001，
    // 而档号印在归档章、盒脊、报表上，改起来要一件一件来。
    //
    // 呈现形式刻意做成**一行细条**而不是卡片（v4.20.2）：卡片带标题栏和按钮，
    // 使用者一眼看过去会以为"向导又回来了"。细条只占用一行，点的是既有设置页。
    if (can('system:manage')) {
      api('/api/stats/overview').then((o) => {
        if (!o.unitIsFactory) return;
        const box = $('#content');
        if (!box) return;
        const div = document.createElement('div');
        div.className = 'hint-box warn';
        div.style.cssText = 'display:flex;align-items:center;gap:10px;flex-wrap:wrap';
        div.innerHTML = `<span>全宗号仍是出厂占位值 <b>${esc(o.unitCode || 'Z001')} / ${esc(o.unitName || '本单位')}</b>`
          + ' —— 它会印在归档章、盒脊和档号里（DA/T 22—2015 §5.4.4、§6.4），现在改是改两个字段。</span>'
          + '<button class="btn btn-sm" id="unit-go">去改成贵单位的</button>';
        box.insertBefore(div, box.firstChild);
        const btn = $('#unit-go');
        if (btn) btn.onclick = () => setView('manage', { tab: 'numbering' });
      }).catch(() => { /* 接口异常不影响工作台 */ });
    }

    const typeRows = s.byType.map((r) => {
      const max = Math.max(1, ...s.byType.map((x) => x.count));
      return `<div class="chart-row"><span class="lb" title="${esc(r.name)}">${esc(r.name)}</span>
        <span class="bar"><i style="width:${(r.count / max) * 100}%"></i></span>
        <span class="vl">${r.count}</span></div>`;
    }).join('') || '<div class="muted">暂无数据</div>';

    const yearRows = s.byYear.map((r) => {
      const max = Math.max(1, ...s.byYear.map((x) => x.count));
      return `<div class="chart-row"><span class="lb">${esc(r.name || '未填')}</span>
        <span class="bar"><i style="width:${(r.count / max) * 100}%"></i></span>
        <span class="vl">${r.count}</span></div>`;
    }).join('') || '<div class="muted">暂无数据</div>';

    const statusTags = s.byStatus.map((r) => {
      const cls = { '在库': 'tag-green', '借出': 'tag-amber', '待整理': 'tag-blue', '待销毁': 'tag-gray', '已销毁': 'tag-gray' }[r.name] || 'tag';
      return `<span class="tag ${cls}" style="margin:0 6px 6px 0">${esc(r.name)} ${r.count}</span>`;
    }).join('');

    const recentRows = s.recent.map((r) => `
      <tr data-open="${r.id}" style="cursor:pointer">
        <td class="code">${esc(r.archive_code)}</td>
        <td>${esc(r.title)}</td>
        <td class="nowrap"><span class="tag tag-blue">${esc(r.type_code)}</span></td>
        <td class="nowrap">${esc(r.status)}</td>
        <td class="nowrap muted">${esc(r.creator || '')}</td>
        <td class="nowrap muted">${fmtTime(r.created_at)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty">还没有档案，先去「档案著录」登记第一份档案</td></tr>';

    const overdueRows = s.overdueLoans.map((r) => `
      <tr><td class="code">${esc(r.loan_no)}</td><td>${esc(r.archive_code)} ${esc(r.title)}</td>
      <td>${esc(r.user_name || '')}</td><td class="nowrap" style="color:var(--c-danger)">${esc(r.due_date)}</td></tr>
    `).join('');

    c.innerHTML = `
      <div class="grid grid-4 mb16">
        <div class="stat"><div class="stat-accent"></div>
          <div class="stat-label">馆藏档案总量</div><div class="stat-value">${s.total}</div>
          <div class="stat-foot">共 ${s.categoryCount} 个分类 · ${s.typeCount} 个门类</div></div>
        <div class="stat"><div class="stat-accent"></div>
          <div class="stat-label">电子附件</div><div class="stat-value">${s.fileCount}</div>
          <div class="stat-foot">占用 ${fmtSize(s.storageBytes)}${s.noFile ? ` · <span style="color:var(--c-warn)">${s.noFile} 条无附件</span>` : ''}</div></div>
        <div class="stat"><div class="stat-accent"></div>
          <div class="stat-label">在借 / 待审批</div><div class="stat-value">${s.loanStats.active} <span style="font-size:14px;color:var(--c-text-3)">/ ${s.loanStats.pending}</span></div>
          <div class="stat-foot">${s.loanStats.overdue ? `<span style="color:var(--c-danger)">逾期 ${s.loanStats.overdue} 件</span>` : '暂无逾期'}</div></div>
        <div class="stat"><div class="stat-accent"></div>
          <div class="stat-label">在用账号</div><div class="stat-value">${s.userCount}</div>
          <div class="stat-foot">累计归还 ${s.loanStats.returned} 次</div></div>
      </div>

      ${can('archive:read')
    ? intakeWorkbenchHtml({ projects: intake.projects, batches: intake.batches, canWrite: can('archive:create') })
    : ''}

      ${s.overdueLoans.length ? `<div class="card" style="border-color:#f0c9c9">
        <div class="card-head"><h3 style="color:var(--c-danger)">逾期未还提醒</h3>
        <button class="btn btn-sm" id="go-loans">去处理</button></div>
        <div class="table-wrap"><table><thead><tr><th>借阅单号</th><th>档案</th><th>借阅人</th><th>应还日期</th></tr></thead>
        <tbody>${overdueRows}</tbody></table></div></div>` : ''}

      <div class="grid grid-2">
        <div class="card">
          <div class="card-head"><h3>各门类馆藏分布</h3></div>
          ${typeRows}
        </div>
        <div class="card">
          <div class="card-head"><h3>年度归档量</h3></div>
          ${yearRows}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>档案状态</h3><span class="sub">共 ${s.total} 条</span></div>
        <div>${statusTags || '<span class="muted">暂无数据</span>'}</div>
      </div>

      <div class="card">
        <div class="card-head"><h3>最近入库</h3>
          <button class="btn btn-sm" id="go-archives">查看全部</button></div>
        <div class="table-wrap"><table>
          <thead><tr><th>档案号</th><th>题名</th><th>门类</th><th>状态</th><th>登记人</th><th>登记时间</th></tr></thead>
          <tbody>${recentRows}</tbody></table></div>
      </div>
    `;

    const gl = $('#go-loans'); if (gl) gl.onclick = () => setView('loans');
    const ga = $('#go-archives'); if (ga) ga.onclick = () => setView('archives');
    // 作业区里的按钮/行：登记完、建完项目后就地重画工作台
    if (can('archive:read')) bindIntakeWorkbench(c, () => renderDashboard());
    $$('#content tr[data-open]').forEach((tr) => {
      tr.onclick = () => openArchiveDetail(Number(tr.dataset.open));
    });
  }

  // ---------------- 档案检索 ----------------
  function categoryOptions(selected, includeAll) {
    const tops = state.categories;
    let html = includeAll ? '<option value="">全部分类</option>' : '<option value="">请选择分类</option>';
    for (const t of tops) {
      html += `<option value="${t.id}"${String(selected) === String(t.id) ? ' selected' : ''}>${esc(t.name)}</option>`;
      for (const c of (t.children || [])) {
        html += `<option value="${c.id}"${String(selected) === String(c.id) ? ' selected' : ''}>　└ ${esc(c.name)}</option>`;
      }
    }
    return html;
  }

  /**
   * 某个门类下的「分类」选项（v4.30.6，A 方案：去重复显示）
   *
   * 标准结构是「门类 → 属类」两层，门类（文书档案 WS）与分类树的根是同一个东西。
   * 以前分类下拉把根和属类一起列出来，于是著录时要选两次「文书档案」——
   * 现在门类已经在上一栏选过，这里**只列它下面的属类**，根自动带出。
   *
   * 三种情况：
   *   1) 有属类      → 只列属类（多层用缩进）
   *   2) 没有属类    → 给一个「（不细分，直接归入本门类）」兜底项，保证还能保存
   *   3) 连根都没有  → 提示去「分类与门类」里补一个，避免用户对着空下拉发呆
   */
  function categoryOptionsForType(typeCode, selected) {
    const tops = state.categories || [];
    const root = tops.find((t) => String(t.code) === String(typeCode));
    let html = '<option value="">请选择分类</option>';
    if (!root) {
      return html + '<option value="__mkroot__">＋ 立即为「' + esc(typeCode) + '」门类建立分类</option>';
    }
    const walk = (node, depth) => {
      for (const c of (node.children || [])) {
        const prefix = depth > 1 ? '　'.repeat(depth - 1) + '└ ' : '';
        html += `<option value="${c.id}"${String(selected) === String(c.id) ? ' selected' : ''}>${prefix}${esc(c.name)}</option>`;
        walk(c, depth + 1);
      }
    };
    walk(root, 1);
    if (!(root.children || []).length) {
      html += `<option value="${root.id}"${String(selected) === String(root.id) ? ' selected' : ''}>（不细分，直接归入「${esc(root.name)}」）</option>`;
    }
    return html;
  }

  /**
   * 门类还没有分类根时，按门类名建一个（v4.30.6）
   * 只在用户真的在分类下拉里点了那一行时调用 —— 不主动改数据。
   */
  async function ensureCategoryRoot(typeCode) {
    const t = (state.types || []).find((x) => String(x.code) === String(typeCode));
    if (!t) return null;
    try {
      await api('/api/categories', { method: 'POST', body: { code: t.code, name: t.name, sort_no: 99 } });
    } catch (_) { /* 已经有了就忽略 */ }
    const cats = await api('/api/categories');
    state.categories = cats.list; state.catFlat = cats.flat;
    const root = (state.categories || []).find((c) => String(c.code) === String(typeCode));
    return root ? root.id : null;
  }

  /**
   * 「所属项目 / 接收批次」两栏的显隐（v4.30.8）
   *
   * 这两栏是 v4.29 之后随「过程接收」进来的，对文书、人事、财务这类按年度
   * 整理的门类毫无用处，却摆在著录页正中间，看着像必填。现在：
   *   · 门类按「项目」整理 → 显示（且项目必选）；
   *   · 记录本来就挂了项目或批次 → 显示（改档时不能把已有的关联藏掉）；
   *   · 其余情况 → 收起，需要时改门类整理方式或在该档的编辑弹窗里挂。
   */
  function syncProcFields(form) {
    if (!form) return;
    const p = form.querySelector('#f-project');
    const b = form.querySelector('#f-batch');
    const t = form.querySelector('#f-type');
    const trow = t ? (state.types || []).find((x) => String(x.code) === String(t.value)) : null;
    const need = Boolean(trow && String(trow.filing_mode) === 'project');
    const show = need || Boolean((p && p.value) || (b && b.value));
    // 用 display 而不是 hidden 属性：.field 自带 display:flex，hidden 会被它压掉
    form.querySelectorAll('[data-proc]').forEach((el) => { el.style.display = show ? '' : 'none'; });
  }

  function typeOptions(selected, includeAll) {
    let html = includeAll ? '<option value="">全部门类</option>' : '';
    for (const t of state.types) {
      html += `<option value="${esc(t.code)}"${selected === t.code ? ' selected' : ''}>${esc(t.name)}</option>`;
    }
    return html;
  }

  function optionList(list, selected, allLabel) {
    let html = allLabel === undefined ? '' : `<option value="">${esc(allLabel)}</option>`;
    for (const v of list) html += `<option value="${esc(v)}"${selected === v ? ' selected' : ''}>${esc(v)}</option>`;
    return html;
  }

  /** 检索字段表只从服务端注册表取（前端不另抄一份，避免规则漂移）；取一次缓存住 */
  async function queryFields() {
    if (state.queryFields) return state.queryFields;
    try { state.queryFields = await api('/api/archives/query-fields'); }
    catch (_) { state.queryFields = { fields: [], limits: { MAX_LEN: 500 } }; }
    return state.queryFields;
  }

  /**
   * 把表达式出错位置画出来。
   * 只给一句「表达式有错」是不够的 —— 长表达式里人根本找不到是哪一处。
   */
  function exprErrorHtml(expr, err) {
    const s = String(expr || '');
    const i = Math.min(Math.max(0, Number(err.position) || 0), Math.max(0, s.length - 1));
    const mark = (t) => esc(String(t));
    const painted = s
      ? mark(s.slice(0, i))
        + `<span style="background:#ffe0e0;color:#b03030;font-weight:700;border-radius:2px">${mark(s[i] || '') || '␠'}</span>`
        + mark(s.slice(i + 1))
      : '';
    return `<div style="margin-top:8px;padding:8px 10px;background:#fff5f5;border:1px solid #f3c2c2;border-radius:6px;font-size:13px">
      <div style="color:#b03030;font-weight:600">${esc(err.message)}</div>
      ${painted ? `<div style="margin-top:6px;font-family:Consolas,monospace;font-size:12px;word-break:break-all">${painted}</div>` : ''}
      <div class="muted" style="margin-top:4px;font-size:12px">第 ${i + 1} 个字符处。</div>
    </div>`;
  }

  /** 语法提示：字段名从服务端注册表来，不写死在前端 */
  function exprHintHtml(qf) {
    const names = (qf.fields || []).map((f) => `<code>${esc(f.label)}</code>`).join(' ');
    const max = (qf.limits && qf.limits.MAX_LEN) || 500;
    return `<div class="muted" style="font-size:12px;margin-top:8px;line-height:1.9">
      <b>表达式写法</b>：<code>字段:值</code> 用 <code>AND</code> / <code>OR</code> / <code>NOT</code> 与括号组合；
      <code>:</code> 是<b>包含</b>，<code>=</code> 是<b>精确</b>，<code>!=</code> 是不等；
      数字与日期字段可用 <code>&gt;</code> <code>&gt;=</code> <code>&lt;</code> <code>&lt;=</code>；
      一组值写 <code>保管期限:[永久,30年]</code>；带空格的词加双引号 <code>题名:"年度 检查"</code>；
      直接打一个词就是关键词检索。上限 ${max} 字。<br>
      <b>可用字段</b>：${names || '<span class="muted">（未能取得字段表）</span>'}
    </div>`;
  }

  async function renderArchives(preset) {
    if (preset && preset.query) { state.archiveQuery = preset.query; state.archivePage = 1; }
    const q = state.archiveQuery || {};
    const params = new URLSearchParams();
    Object.entries(q).forEach(([k, v]) => { if (v !== '' && v !== undefined && v !== null) params.set(k, v); });
    params.set('page', String(state.archivePage));
    params.set('size', '20');
    const qf = await queryFields();
    // 所属项目 / 接收批次（v4.30.8）：以前这两样只能在档案详情里看到，想在检索页按项目
    // 拉出一整套档案做不到。取不到（无权限/接口异常）就不显示这两个条件，不影响检索。
    let projList = [];
    let batchList = [];
    try {
      const [pd, bd] = await Promise.all([
        api('/api/projects').catch(() => ({ list: [] })),
        api('/api/batches?limit=200').catch(() => ({ list: [] })),
      ]);
      projList = (pd && pd.list) || [];
      batchList = (bd && bd.list) || [];
    } catch (_) { /* 忽略，保底是空 */ }
    // 表达式写错时后端回 400 并带出错位置，这里**必须接住**：
    // 否则整个检索页会白屏，用户连改回正常条件的地方都没有。
    let data = null;
    let exprErr = null;
    try {
      data = await api('/api/archives?' + params.toString());
    } catch (e) {
      if (e.status === 400 && q.expr) {
        exprErr = { message: e.message, position: Number(e.position) || 0 };
        data = { list: [], total: 0, page: 1, size: 20, pages: 1 };
      } else { throw e; }
    }

    const rows = data.list.map((r) => `
      <tr data-id="${r.id}" style="cursor:pointer">
        <td class="code">${esc(r.archive_code)}</td>
        <td><div style="font-weight:500">${esc(r.title)}</div>
            <div class="muted" style="font-size:12px">${esc(r.category_name || '')}${r.keywords ? ' · ' + esc(r.keywords) : ''}${r.project_no ? ' · 项目 ' + esc(r.project_no) : ''}${r.batch_no ? ' · 批次 ' + esc(r.batch_no) : ''}</div>
            ${r.text_hit ? `<div class="text-hit">
              <span class="tag tag-green" title="这条不是靠题名命中的，是附件里的内容命中">命中附件正文</span>
              <span class="muted" style="font-size:12px">${esc(r.text_hit.original_name)}</span>
              ${r.text_hit.via === 'ocr' ? '<span class="tag tag-amber" title="这段正文是 OCR 识别的，可能有错字">OCR</span>' : ''}
              <div class="snippet">${highlight(r.text_hit.snippet, (state.archiveQuery || {}).kw || '')}</div>
            </div>` : ''}</td>
        <td class="nowrap"><span class="tag tag-blue">${esc(r.type_code)}</span></td>
        <td class="nowrap">${esc(r.year || '')}</td>
        <td class="nowrap">${esc(r.retention)}</td>
        <td class="nowrap">${r.secret_level === '公开' ? '<span class="tag tag-gray">公开</span>' : `<span class="tag tag-amber">${esc(r.secret_level)}</span>`}</td>
        <td class="nowrap">${statusTag(r.status)}</td>
        <td class="nowrap muted">${r.file_count ? `📎 ${r.file_count}` : '<span class="muted">—</span>'}${r.loan_count ? ' <span class="tag tag-amber">借出</span>' : ''}</td>
        <td class="nowrap">
          <button class="btn btn-sm" data-act="view">查看</button>
        </td>
      </tr>`).join('') || `<tr><td colspan="9" class="empty"><b>没有查到符合条件的档案</b>可以调整检索条件，或先去「档案著录」新增档案</td></tr>`;

    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>检索条件</h3>
          <div class="flex">
            <button class="btn btn-sm" id="btn-reset">重置</button>
            <button class="btn btn-sm btn-primary" id="btn-search">检 索</button>
          </div>
        </div>
        <form class="filters" id="filter-form" onsubmit="return false">
          <label class="field grow"><span>关键词（题名/档案号/关键词/摘要/责任者）</span>
            <input type="search" name="kw" value="${esc(q.kw || '')}" placeholder="中文、拼音或首字母都可以：档案管理 / wenshuguanli / wsgl"></label>
          <label class="field grow"><span>高级检索表达式（可选）</span>
            <input type="text" name="expr" value="${esc(q.expr || '')}" spellcheck="false"
                   placeholder="如：门类:WS AND 年度&gt;=2020 AND NOT 状态:已销毁"></label>
          <label class="field"><span>门类</span><select name="type">${typeOptions(q.type, true)}</select></label>
          <label class="field"><span>分类</span><select name="category">${categoryOptions(q.category, true)}</select></label>
          ${projList.length ? `<label class="field"><span>所属项目</span>
            <select name="project" id="flt-project"><option value="">全部项目</option>
              ${projList.map((p) => `<option value="${p.id}"${String(q.project) === String(p.id) ? ' selected' : ''}>${esc(p.project_no || '')} ${esc(p.name || '')}${p.status ? '（' + esc(p.status) + '）' : ''}</option>`).join('')}
            </select></label>` : ''}
          ${batchList.length ? `<label class="field"><span>接收批次</span>
            <select name="batch" id="flt-batch"><option value="">全部批次</option>
              ${batchList.map((b) => `<option value="${b.id}" data-pid="${b.project_id || ''}"${String(q.batch) === String(b.id) ? ' selected' : ''}>${esc(b.received_at || '')} ${esc(b.batch_no || '')}${b.project_name ? ' · ' + esc(b.project_name) : ''}</option>`).join('')}
            </select></label>` : ''}
          <label class="field"><span>年度</span><input type="text" name="year" value="${esc(q.year || '')}" placeholder="2025"></label>
          <label class="field"><span>保管期限</span><select name="retention">${optionList(state.meta.retentions, q.retention, '全部')}</select></label>
          <label class="field"><span>密级</span><select name="secret">${optionList(state.meta.secretLevels, q.secret, '全部')}</select></label>
          <label class="field"><span>状态</span><select name="status">${optionList(state.meta.statuses, q.status, '全部')}</select></label>
          <label class="field"><span>归档日期起</span><input type="date" name="dateFrom" value="${esc(q.dateFrom || '')}"></label>
          <label class="field"><span>归档日期止</span><input type="date" name="dateTo" value="${esc(q.dateTo || '')}"></label>
          <label class="field"><span>附件</span>
            <select name="hasFile"><option value="">不限</option>
              <option value="1"${q.hasFile === '1' ? ' selected' : ''}>仅有附件</option>
              <option value="0"${q.hasFile === '0' ? ' selected' : ''}>仅无附件</option></select></label>
        </form>
        ${exprHintHtml(qf)}
        ${exprErr ? exprErrorHtml(q.expr, exprErr) : ''}
        <div class="help">关键词支持三种输入：<b>汉字</b>（档案管理）、<b>全拼</b>（wenshuguanli）、<b>首字母</b>（wsgl）。
          拼音索引在著录时自动生成，多音字按常用读音（如「重庆」记作 zhongqing）。</div>
      </div>

      <div class="card" id="facet-card" style="display:none">
        <div class="card-head"><h3>检索分面 <span class="sub" id="facet-total"></span></h3>
          <button class="btn btn-sm" id="facet-clear">清除全部筛选</button></div>
        <div id="facet-panel"><div class="muted">正在统计…</div></div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3>检索结果 <span class="sub">共 ${data.total} 条</span></h3>
          <div class="flex">
            <select class="btn btn-sm" id="search-pick" style="max-width:190px"><option value="">常用检索…</option></select>
            <button class="btn btn-sm" id="btn-save-search">保存当前条件</button>
            <button class="btn btn-sm" id="btn-export">导出目录 CSV</button>
            <button class="btn btn-sm" id="btn-stamps">打印归档章</button>
            <button class="btn btn-sm btn-primary" id="btn-new">＋ 新增档案</button>
          </div>
        </div>
        <div class="table-wrap">
          <table><thead><tr>
            <th>档案号</th><th>题名 / 分类</th><th>门类</th><th>年度</th><th>保管期限</th><th>密级</th><th>状态</th><th>附件</th><th>操作</th>
          </tr></thead><tbody>${rows}</tbody></table>
        </div>
        ${pagerHtml(data, 'archive')}
      </div>
    `;

    const form = $('#filter-form');
    const collect = () => {
      const o = {};
      new FormData(form).forEach((v, k) => { const s = String(v).trim(); if (s) o[k] = s; });
      return o;
    };
    $('#btn-search').onclick = () => { state.archiveQuery = collect(); state.archivePage = 1; setView('archives'); };
    // 选了项目就把批次下拉收窄到这个项目（批次都挂在项目上，跨项目选批次没意义）
    const projFlt = $('#flt-project');
    const batchFlt = $('#flt-batch');
    if (projFlt && batchFlt) {
      const narrow = () => {
        const pid = projFlt.value;
        Array.from(batchFlt.options).forEach((o) => {
          if (!o.value) return;
          const keep = !pid || String(o.dataset.pid || '') === String(pid);
          o.hidden = !keep;
          if (!keep && o.selected) batchFlt.value = '';
        });
      };
      projFlt.addEventListener('change', narrow);
      narrow();
    }
    form.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#btn-search').click(); } });
    $('#btn-reset').onclick = () => { state.archiveQuery = {}; state.archivePage = 1; setView('archives'); };
    $('#btn-new').onclick = () => setView('create');
    $('#btn-export').onclick = () => {
      const p = new URLSearchParams();
      Object.entries(state.archiveQuery || {}).forEach(([k, v]) => { if (v) p.set(k, v); });
      window.location.href = '/api/export/archives.csv?' + p.toString();
    };
    // 常用检索：把反复用的那套条件存下来，下次一键调出。
    // 存的就是**检索表单的原始条件对象**（state.archiveQuery），服务端不解释它 ——
    // 解释权只有列表接口一处，避免"存的时候能查到、调出来查不到"。
    const pick = $('#search-pick');
    if (pick) {
      api('/api/searches').then((r) => {
        const opts = (r.list || []).map((s) => {
          const bits = Object.entries(s.query || {}).filter(([, v]) => v).slice(0, 3)
            .map(([k, v]) => `${k}=${v}`).join(' ');
          return `<option value="${s.id}">${esc(s.name)}${s.mine ? '' : '（共享）'}${bits ? ' · ' + esc(bits) : ''}</option>`;
        }).join('');
        pick.innerHTML = '<option value="">常用检索…</option>' + opts;
      }).catch(() => { /* 无权限或接口异常都不影响检索本身 */ });
      pick.onchange = async () => {
        const id = Number(pick.value);
        if (!id) return;
        try {
          const r = await api('/api/searches/' + id + '/use', { method: 'POST', body: {} });
          state.archiveQuery = r.query || {};
          state.archivePage = 1;
          setView('archives');
        } catch (e) { toast(e.message, 'err'); }
      };
    }
    /**
     * 检索分面（v4.11.0）：把"这批结果由什么构成"摊开给人看，点一下就能收窄。
     *
     * 为什么要单独发一个请求、还做成"不阻塞"：分面要跑 8 条 GROUP BY，
     * 而列表本身已经出来了。让分面晚半秒出现，比让整个检索页多等半秒好得多。
     * 分面失败也**绝不能影响检索本身**（它只是辅助），所以整个函数包在 try 里。
     */
    const FACET_LABELS = {
      type: '门类', year: '年度', retention: '保管期限', secret: '密级',
      status: '状态', category: '分类', department: '部门', hasFile: '附件', textIndex: '正文可检索性',
    };
    async function loadFacets() {
      const panel = $('#facet-panel');
      const card = $('#facet-card');
      if (!panel || !card) return;
      const p = new URLSearchParams();
      Object.entries(state.archiveQuery || {}).forEach(([k, v]) => { if (v) p.set(k, v); });
      try {
        const f = await api('/api/archives/facets?' + p.toString());
        $('#facet-total').textContent = `共 ${f.total} 条`;
        const blocks = (f.facets || []).map((fd) => {
          const active = (f.active || {})[fd.key];
          const chips = fd.values.filter((v) => v.count > 0).map((v) => {
            const on = active !== undefined && String(active) === String(v.value);
            return `<button class="facet-chip${on ? ' on' : ''}" data-fkey="${fd.key}" data-fval="${esc(v.value)}">
              ${esc(v.label)}<span class="facet-n">${v.count}</span></button>`;
          }).join('');
          return `<div class="facet-row">
            <span class="facet-label">${esc(FACET_LABELS[fd.key] || fd.key)}</span>
            <span class="facet-values">${chips || '<span class="muted" style="font-size:12px">（无）</span>'}
              ${fd.blank ? `<span class="muted" style="font-size:12px">未填写 ${fd.blank}</span>` : ''}
              ${fd.more ? `<span class="muted" style="font-size:12px">另有 ${fd.more} 项未列出</span>` : ''}</span>
            ${fd.note ? `<span class="help" style="margin:0 0 0 8px">${esc(fd.note)}</span>` : ''}
          </div>`;
        }).join('');
        panel.innerHTML = blocks || '<div class="muted">没有可统计的维度</div>';
        card.style.display = '';
        panel.querySelectorAll('.facet-chip').forEach((b) => {
          b.onclick = () => {
            const key = b.dataset.fkey;
            const val = b.dataset.fval;
            const cur = Object.assign({}, state.archiveQuery || {});
            if (String(cur[key]) === String(val)) delete cur[key];   // 再点一次＝取消这个筛选
            else cur[key] = val;
            state.archiveQuery = cur;
            state.archivePage = 1;
            setView('archives');
          };
        });
      } catch (e) {
        // 分面是辅助功能：出错就把卡片收起来，不打扰使用者
        card.style.display = 'none';
      }
    }
    const facetClear = $('#facet-clear');
    if (facetClear) {
      facetClear.onclick = () => {
        // 只清分面对应的维度，保留关键词与表达式 —— 否则"清除筛选"会把用户刚打的检索词也清掉
        const keep = Object.assign({}, state.archiveQuery || {});
        for (const k of Object.keys(FACET_LABELS)) delete keep[k];
        state.archiveQuery = keep;
        state.archivePage = 1;
        setView('archives');
      };
    }
    loadFacets();

    const saveSearch = $('#btn-save-search');
    if (saveSearch) {      saveSearch.onclick = () => {
        const cur = state.archiveQuery || {};
        if (!Object.keys(cur).filter((k) => cur[k]).length) {
          toast('当前没有检索条件可保存 —— 先填上面的条件并检索一次', 'warn');
          return;
        }
        promptDialog('保存为常用检索', [
          { name: 'name', label: '名称', required: true, placeholder: '如：2026 年文书档案待鉴定' },
          { name: 'shared', label: '可见范围', type: 'select', value: '0',
            options: [{ value: '0', label: '仅自己可见' }, { value: '1', label: '共享给同系统其他人' }] },
          { name: 'note', label: '备注', span2: true },
        ], async (d) => {
          await api('/api/searches', { method: 'POST', body: { name: d.name, query: cur, shared: d.shared === '1', note: d.note || '' } });
          toast('已保存为常用检索', 'ok');
          setView('archives');
        });
      };
    }
    // 批量套打归档章：**按当前检索条件**打印（不传 ids 时后端就用同一套过滤条件，
    // 口径与列表完全一致，不需要在前端勾选一堆复选框）。密级过滤在服务端做。
    $('#btn-stamps').onclick = () => {
      const p = new URLSearchParams();
      Object.entries(state.archiveQuery || {}).forEach(([k, v]) => { if (v) p.set(k, v); });
      const url = '/api/print/stamps' + (p.toString() ? '?' + p.toString() : '');
      confirmDialog('打印归档章', '将按<b>当前检索条件</b>打印归档章（最多 200 枚，含六格必备项）。'
        + '如需只打某几件，先在上面检索出那几件再点这里。<br>现在打开打印页吗？',
      () => window.open(url, '_blank'), '打开打印页');
    };
    $$('#content tr[data-id]').forEach((tr) => {
      tr.onclick = (e) => {
        const id = Number(tr.dataset.id);
        if (e.target.closest('[data-act]')) return openArchiveDetail(id);
        openArchiveDetail(id);
      };
    });
    bindPager('archive', (page) => { state.archivePage = page; setView('archives'); });
  }

  function statusTag(s) {
    const cls = { '在库': 'tag-green', '借出': 'tag-amber', '待整理': 'tag-blue', '待销毁': 'tag-gray', '已销毁': 'tag-gray' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s)}</span>`;
  }

  /** 密级标签：越敏感越"重"，让涉密件在一屏清单里一眼跳出来 */
  function secretTag(s) {
    const cls = { '公开': 'tag-gray', '内部': 'tag', '秘密': 'tag-amber', '机密': 'tag-red' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s || '公开')}</span>`;
  }
  /** 开放状态标签（《档案法》第二十七、二十八条：开放 / 部分开放 / 控制使用） */
  function openTag(s) {
    const cls = { '开放': 'tag-green', '部分开放': 'tag-blue', '控制使用': 'tag-amber', '未鉴定': 'tag-gray' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s || '未鉴定')}</span>`;
  }

  function pagerHtml(data, key) {
    if (data.pages <= 1) return `<div class="pager"><span class="info">共 ${data.total} 条</span></div>`;
    return `<div class="pager" data-pager="${key}">
      <span class="info">共 ${data.total} 条 · 第 ${data.page}/${data.pages} 页</span>
      <button class="btn btn-sm" data-page="1" ${data.page === 1 ? 'disabled' : ''}>首页</button>
      <button class="btn btn-sm" data-page="${data.page - 1}" ${data.page === 1 ? 'disabled' : ''}>上一页</button>
      <button class="btn btn-sm" data-page="${data.page + 1}" ${data.page === data.pages ? 'disabled' : ''}>下一页</button>
      <button class="btn btn-sm" data-page="${data.pages}" ${data.page === data.pages ? 'disabled' : ''}>末页</button>
    </div>`;
  }

  function bindPager(key, cb) {
    $$(`[data-pager="${key}"] button[data-page]`).forEach((b) => {
      b.onclick = () => { const p = Number(b.dataset.page); if (p >= 1) cb(p); };
    });
  }

  // ---------------- 档案详情 ----------------
  /**
   * 历史版本（v4.32.0 豆包信创）：列出这件档案的每一次改动，"改之前"的完整样子都在，
   * 改错了点"还原到此版"就退回去。还原前也会自动再存一版，所以还原本身也能反悔。
   */
  async function openVersionList(a) {
    let data;
    try {
      data = await api(`/api/archives/${a.id}/versions`);
    } catch (e) {
      toast(e.message || '历史版本读取失败', 'err');
      return;
    }
    const list = (data && data.list) || [];
    const body = el('div', {}, list.length
      ? `<div class="help mb16">共 ${list.length} 个历史版本。每一次修改保存前都会自动留底，还原错了还能再退回来。</div>
         <div class="table-wrap"><table><thead><tr>
           <th style="width:150px">时间</th><th style="width:110px">操作人</th>
           <th style="width:110px">动作</th><th>说明</th><th style="width:120px">操作</th>
         </tr></thead><tbody>${list.map((v) => `<tr>
           <td class="mono">${esc(String(v.changed_at || '').replace('T', ' ').slice(0, 19))}</td>
           <td>${esc(v.changed_by || '')}</td>
           <td>${esc(v.action || '')}</td>
           <td>${esc(v.note || '')}</td>
           <td><button class="btn btn-sm" data-restore="${v.id}">还原到此版</button></td>
         </tr>`).join('')}</tbody></table></div>`
      : '<div class="help">这件档案还没有改动记录（第一次修改之后就会自动出现在这里）。</div>');

    const foot = [btn('关闭', '', () => modal.close())];
    modal.open(`历史版本 · ${a.archive_code || a.title}`, body, foot, { wide: true });

    $$('#modal-body [data-restore]').forEach((b) => {
      b.onclick = async () => {
        if (!data.can_restore) { toast('你没有修改这件档案的权限，不能还原', 'err'); return; }
        const v = list.find((x) => String(x.id) === String(b.dataset.restore));
        const when = String((v && v.changed_at) || '').replace('T', ' ').slice(0, 19);
        if (!window.confirm(`确定把这件档案还原到「${when} ${(v && v.changed_by) || ''}」修改之前的样子？\n\n还原前会先把当前内容再存一版，选错了还能退回来。`)) return;
        b.disabled = true;
        try {
          const r = await api(`/api/archives/${a.id}/versions/${b.dataset.restore}/restore`, { method: 'POST', body: {} });
          toast(`已还原${r && r.archive_code ? `（档号 ${r.archive_code}）` : ''}`, 'ok');
          modal.close();
          setTimeout(() => openArchiveDetail(a.id), 120);
        } catch (e) {
          toast(e.message || '还原失败', 'err');
          b.disabled = false;
        }
      };
    });
  }

  /**
   * 件级授权（v4.32.0）：把「这一件」单独开给某个账号。
   *
   * 为什么要有它：密级和部门两道门槛是"一刀切"的 —— 一件标了「机密」的档案，
   * 整个科室谁都看不到；但真实场景里常常是"这份要给某位领导看一次"。
   * 为了这一次去改密级，比不改更危险。所以给一条只对这一件生效的授权通道。
   */
  async function grantDialog(a) {
    let targets = [];
    try {
      const d = await api('/api/grant-targets');
      targets = d.list || [];
    } catch (e) {
      return toast('读取账号列表失败：' + e.message, 'err');
    }
    promptDialog(`授权查阅：${a.title.slice(0, 18)}`, [
      { name: 'user_id', label: '授权给', type: 'select', required: true,
        options: targets.map((t) => ({ value: String(t.id), label: `${t.display_name}（${t.department || '未填部门'}）` })) },
      { name: 'expires_at', label: '到期日期（可空）', type: 'text', placeholder: 'YYYY-MM-DD，留空表示长期有效' },
      { name: 'reason', label: '授权理由', span2: true, required: true,
        placeholder: '如：局长批示需查阅本件合同原件' },
    ], async (data) => {
      await api(`/api/archives/${a.id}/grants`, { method: 'POST', body: data });
      toast('已授权，该账号可查阅这一件（授权与放行都会留审计）', 'ok', 7000);
    }, { wide: true });
  }

  async function openArchiveDetail(id) {
    const a = await api('/api/archives/' + id);
    // 归档章与元数据并行取：不让弹窗变慢；任一段取不到就少显示一段，不影响其它功能
    const [stamp, meta, lc, ev] = await Promise.all([
      api('/api/archives/' + id + '/stamp').catch(() => null),
      api('/api/archives/' + id + '/metadata').catch(() => null),
      api('/api/archives/' + id + '/transitions').catch(() => null),   // v4.32.0 件级状态机
      api('/api/archives/' + id + '/evidence').catch(() => null),      // v4.32.0 四性证据链
    ]);
    const t = state.types.find((x) => x.code === a.type_code);
    const fields = (t && t.fields) || [];
    const extra = a.extra || {};

    const dlBase = [
      ['档案号', `<span class="code">${esc(a.archive_code)}</span>`],
      ['门类', esc(t ? t.name : a.type_code)],
      ['分类', esc(a.category_name || '')],
      ['年度', esc(a.year)],
      ['归档日期', esc(a.archive_date)],
      ['保管期限', esc(a.retention)],
      ['密级', esc(a.secret_level)],
      ['载体', esc(a.carrier)],
      ['案卷号', esc(a.volume_no || '')],
      ['件号', esc(a.item_no || '')],
      ['页数', esc(a.pages || '')],
      ['份数', String(a.copies)],
      ['责任者', esc(a.responsible || '')],
      ['部门', esc(a.department || '')],
      ['存放位置', esc(a.location || '')],
      ['登记人', esc(a.creator_name || '')],
      ['登记时间', fmtTime(a.created_at)],
      ['最近修改', fmtTime(a.updated_at)],
    ];
    // 过程接收归属（v4.29.0）：打开一件档案最想知道"它是哪个项目、哪一批、什么时候交的"
    if (a.batch) {
      dlBase.unshift(['接收批次', `${esc(a.batch.title || a.batch.batch_no)}${a.batch.received_at ? '（' + esc(a.batch.received_at) + ' 接收）' : ''}`]);
    }
    if (a.project) dlBase.unshift(['所属项目', `${esc(a.project.project_no)} ${esc(a.project.name)}`]);
    const dlExtra = fields.map((f) => [f.label, esc(extra[f.key] || '')]);
    const dl = dlBase.concat(dlExtra).map(([k, v]) =>
      `<div><span class="k">${esc(k)}</span><span class="v">${v || '<span class="muted">—</span>'}</span></div>`).join('');

    // 附件顺序可调 + 正文可替换（v4.9.0）。
    // 为什么要能调顺序：后补到的材料在顺序上常常属于中间（原件第 3 页的扫描件后来才找到），
    // 只追加会让附件顺序与实体件顺序对不上 —— 打印卷内目录时最明显。
    // 附件行按钮顺序（v4.24.0）：**先放最常用的「预览」，再放「打开/下载」，
    // 编辑类动作（上移/下移/替换/识别/删除）排到最后**。
    // 原来预览夹在一堆按钮中间，手机上要在一个换行的按钮堆里找它 ——
    // 而实际上"看一眼原文"是这一行最高频的动作。
    // 在微信等内置浏览器里，「下载」根本下不来，所以**直接把按钮改成「复制链接」**，
    // 点了就复制，而不是等点了才弹一句说明。
    const wvNow = inAppBrowser();
    const files = a.files.map((f, i) => `
      <div class="file-item" data-file="${f.id}">
        <span class="file-icon">${esc(fileIcon(f.original_name))}</span>
        <span class="file-name"><b>${esc(f.original_name)}</b>
          <span>${fmtSize(f.size)} · ${esc(f.kind)}${Number(f.pages) > 0 ? ` · <b>${Number(f.pages)} 页</b>` : ''}${Number(f.dpi) > 0 ? ` · ${Number(f.dpi)}dpi` : ''}${f.color_mode ? ` · ${esc(f.color_mode)}` : ''} · ${fmtTime(f.created_at)}</span></span>
        <button class="btn btn-sm btn-primary" data-fact="preview" title="在当前页面里看正文，不离开系统（图片、PDF、Office 正文都能看；扫描件还能就地 OCR 并复制文字）">预览</button>
        <a class="btn btn-sm" data-fact="download" data-ticket=""
           title="${wvNow ? '当前是' + esc(wvNow) + '内置浏览器，不能下载 —— 点了会复制下载链接，粘到手机浏览器即可' : '下载附件'}">${wvNow ? '复制链接' : '下载'}</a>
        <a class="btn btn-sm" data-fact="open" data-ticket="" target="_blank" rel="noopener"
           title="在独立查看页里打开（页内有可选中复制的文字，适合用浏览器看、右键复制、另存；会离开当前界面，右上角有 ✕ 可关）">打开</a>
        ${/* 三者各司其职（v4.26.2，使用者要求"和打开的效果区别开"）：
             悬停文件名 = 小浮层快速瞄一眼（不离开、不挡界面）
             预览       = 应用内完整弹窗（图/PDF + 文字面板 + 复制全文 + 就地 OCR）
             打开       = 独立查看页（带可选中文字，方便浏览器里右键复制、另存） */ ''}
        ${canEditFile() ? `<button class="btn btn-sm" data-fact="up" title="上移"${i === 0 ? ' disabled' : ''}>↑</button>
        <button class="btn btn-sm" data-fact="down" title="下移"${i === a.files.length - 1 ? ' disabled' : ''}>↓</button>
        <button class="btn btn-sm" data-fact="replace" title="重新扫描/补页后替换正文（旧版留痕）">替换</button>
        <button class="btn btn-sm" data-fact="ocr" title="对扫描件做 OCR，让正文可以被检索（需本机装有 OCR 引擎）">识别</button>
        <button class="btn btn-sm btn-danger" data-fact="del">删除</button>` : ''}
      </div>`).join('') || '<div class="muted">暂无电子附件</div>';

    // 扫描件页数核对（v4.28.0）：实体页数 vs PDF 实际页数。
    // 漏扫是数字化最常见的质量问题，必须在打开这件档案时**当场看见**差了几页，
    // 而不是等上级检查时才发现。这里只提示，不阻断任何操作。
    const scanFiles = (a.files || []).filter((f) => f.kind === '扫描件');
    const declaredPages = Number(String(a.pages || '').replace(/[^0-9]/g, '')) || 0;
    const scannedPages = scanFiles.reduce((n, f) => n + (Number(f.pages) || 0), 0);
    const scanCheckHtml = (() => {
      if (!scanFiles.length) {
        return '<div class="hint-box" style="margin-bottom:8px">还没有扫描件。扫描仪出 PDF 后点「导入扫描件」，'
          + '文件会按档号命名、存到该档号对应的目录里。</div>';
      }
      const head = `已导入 ${scanFiles.length} 个扫描件，共 ${scannedPages} 页`;
      if (!declaredPages) {
        return `<div class="hint-box warn" style="margin-bottom:8px">${head}；但著录里还没填<b>实体页数</b>，无法核对是否漏扫。</div>`;
      }
      if (scannedPages === declaredPages) {
        return `<div class="hint-box" style="margin-bottom:8px;border-left:3px solid var(--c-ok)">页数核对：实体 ${declaredPages} 页，扫描件 ${scannedPages} 页，一致。</div>`;
      }
      return `<div class="hint-box warn" style="margin-bottom:8px">页数核对：实体 ${declaredPages} 页，扫描件 ${scannedPages} 页，`
        + `相差 <b>${Math.abs(declaredPages - scannedPages)} 页</b>`
        + `${scannedPages < declaredPages ? '（可能漏扫）' : '（可能重扫或双面扫）'}。</div>`;
    })();

    // ---- 正文替换留痕（v4.9.0）----
    // 替换不是"偷偷改文件"：旧版文件名/哈希/大小/原因/经办人全部留在这里，
    // 配合四性检测才能证明"这份电子原文被换过、原来的长什么样"。
    const repls = a.replacements || [];
    const replBlock = repls.length ? `
      <div class="section-title">正文替换留痕（${repls.length}）</div>
      <div class="table-wrap"><table><thead><tr><th class="nowrap">时间</th><th>被替换掉的旧版</th><th class="nowrap">大小</th><th>原因</th><th class="nowrap">经办人</th></tr></thead><tbody>
        ${repls.map((r) => `<tr>
          <td class="nowrap muted">${fmtTime(r.replaced_at)}</td>
          <td>${esc(r.old_name || '')}
            <div class="mono muted" style="font-size:11px">SHA-256 ${esc(String(r.old_sha256 || '').slice(0, 16))}…</div></td>
          <td class="nowrap">${fmtSize(r.old_size)}</td>
          <td>${esc(r.reason || '')}</td>
          <td class="nowrap">${esc(r.by_name || '')}</td></tr>`).join('')}
      </tbody></table></div>
      <div class="help">旧版实体文件在替换成功后即从磁盘移除（同一份文件若还被其它档案引用则保留），
        这里留下的旧版 SHA-256 用来证明"当时那一版是什么"，也是四性检测里完整性核对的依据。</div>` : '';

    // ---- 定密与开放状态 + 鉴定历史（v4.10.0）----
    // 三种鉴定（价值 / 密级 / 开放）在这件档案上的当前状态与来龙去脉。
    // 为什么要放在详情页而不是只放在工作台：打开一件档案时最想知道的是
    // "它为什么是这个保管期限、这个密级、这个开放状态"——答案就在鉴定历史里。
    const AP_KIND_TAG = { 价值鉴定: 'tag-blue', 密级鉴定: 'tag-amber', 开放鉴定: 'tag-green' };
    const apList = a.appraisals || [];
    const aprHistory = apList.length ? `
      <div class="table-wrap mt8"><table><thead><tr>
        <th class="nowrap">鉴定日期</th><th>类别</th><th>结论</th><th>依据</th>
        <th class="nowrap">鉴定人</th><th class="nowrap">批次</th>
      </tr></thead><tbody>
        ${apList.map((p) => {
    let after = p.decision;
    if (p.kind === '价值鉴定' && p.decision === '延长保管期限') after = `延长为 ${p.new_retention || ''}`;
    if (p.kind === '密级鉴定') {
      if (p.decision === '解密') after = '解密（公开）';
      else if (p.decision === '降低密级') after = `降为 ${p.new_secret_level || ''}`;
      else if (p.decision === '延长保密期限') after = `延长至 ${p.new_secret_to || ''}`;
    }
    if (p.kind === '开放鉴定') after = `${p.new_open_state || p.decision}${p.open_delay_to ? `（延期至 ${p.open_delay_to}）` : ''}`;
    return `<tr>
          <td class="nowrap muted">${esc(p.appraised_at || '')}</td>
          <td class="nowrap"><span class="tag ${AP_KIND_TAG[p.kind] || 'tag'}">${esc(p.kind || '价值鉴定')}</span></td>
          <td>${esc(after)}</td>
          <td class="muted">${esc(p.basis_ref || '')}${p.basis_ref && p.basis ? '　' : ''}${esc(p.basis || '')}
            ${p.control_reason ? `<div style="font-size:11.5px">${esc(p.control_reason)}</div>` : ''}</td>
          <td class="nowrap muted">${esc(p.appraiser_name || '')}</td>
          <td class="nowrap">${p.batch_no ? `<a href="/api/appraisal/batches/${p.batch_id}/print" target="_blank" class="mono">${esc(p.batch_no)}</a>` : '<span class="muted">单件</span>'}</td>
        </tr>`;
  }).join('')}
      </tbody></table></div>` : '<div class="muted mt8">尚无鉴定记录。三种鉴定分别处理：<b>价值鉴定</b>（保管期限届满）、<b>密级鉴定</b>（保密期限届满）、<b>开放鉴定</b>（形成满 25 年）。</div>';

    const termTxt = a.secret_level === '公开'
      ? '<span class="muted">公开事项，无需保密期限</span>'
      : `${esc(a.secret_term || '—')}${a.secret_to
        ? `（至 ${esc(a.secret_to)}）`
        : '<span class="tag tag-amber" style="margin-left:6px">未登记届满日期</span>'}`;
    const apprBlock = `
      <div class="section-title">定密与开放状态</div>
      <div class="dl">
        <div><span>密级</span><b>${secretTag(a.secret_level)}</b></div>
        <div><span>保密期限</span><b>${termTxt}</b></div>
        <div><span>定密依据</span><b>${esc(a.secret_basis || '—')}</b></div>
        <div><span>解密条件</span><b>${esc(a.declassify_condition || '—')}</b></div>
        <div><span>开放状态</span><b>${openTag(a.open_state)}</b></div>
        <div><span>开放鉴定日期</span><b>${esc(a.open_review_at || '—')}</b></div>
        ${a.open_control_reason ? `<div><span>控制使用理由</span><b>${esc(a.open_control_reason)}</b></div>` : ''}
        ${a.open_delay_to ? `<div><span>延期开放至</span><b>${esc(a.open_delay_to)}</b></div>` : ''}
        ${a.open_scope_note ? `<div><span>部分开放范围</span><b>${esc(a.open_scope_note)}</b></div>` : ''}
      </div>
      <div class="flex mt8" style="gap:6px;flex-wrap:wrap">
        ${canSecretClassify() ? '<button class="btn btn-sm" id="detail-secret">登记 / 变更定密信息</button>' : ''}
        ${can('appraisal:run') ? '<button class="btn btn-sm" id="detail-apr-value">价值鉴定</button>' : ''}
        ${canSecretClassify() ? '<button class="btn btn-sm" id="detail-apr-secret">密级鉴定</button>' : ''}
        ${canApproveAppraisal() ? '<button class="btn btn-sm" id="detail-apr-open">开放鉴定</button>' : ''}
      </div>
      <div class="help mt8">密级鉴定须由定密责任人（系统安全保密员）作出，开放与否由馆领导批准 ——
        系统不会替你决定解密与开放。尚未解密的档案不能作出「开放」结论。</div>
      <div class="section-title">鉴定历史</div>
      ${aprHistory}`;

    const loans = a.loans.map((l) => `
      <tr><td class="code">${esc(l.loan_no)}</td><td>${esc(l.user_name || '')}</td>
      <td class="nowrap">${esc(l.mode)}</td><td class="nowrap">${loanStatusTag(l.status)}</td>
      <td class="nowrap">${esc(l.due_date || '')}</td>
      <td class="nowrap muted">${fmtTime(l.return_at || l.apply_at)}</td></tr>
    `).join('') || '<tr><td colspan="6" class="muted">暂无借阅记录</td></tr>';

    // ---- 归档章（DA/T 22—2015 §5.4.4）：六格必备项 + 单件打印 ----
    const STAMP_CELLS = [
      ['unit_code', '全宗号', true], ['year', '年度', true], ['retention', '保管期限', true],
      ['item_no', '件号', true], ['pages', '页数', true], ['org_code', '机构(问题)', false],
    ];
    const sf = (stamp && stamp.fields && !Array.isArray(stamp.fields)) ? stamp.fields : {};
    const missSet = new Set(((stamp && stamp.missing) || []).map((m) => (typeof m === 'string' ? m : (m && (m.key || m.label)) || '')));
    const stampHtml = stamp ? `
      <div class="table-wrap"><table><thead><tr><th>必备项</th><th>值</th><th>状态</th></tr></thead><tbody>
        ${STAMP_CELLS.map(([k, label, required]) => {
    const v = sf[k];
    const empty = v === undefined || v === null || v === '';
    const bad = empty || missSet.has(k) || missSet.has(label);
    return `<tr><td>${esc(label)}${required ? '' : '（选择项）'}</td>
          <td>${empty ? '<span class="muted">—</span>' : esc(String(v))}</td>
          <td>${required ? (bad ? '<span class="tag tag-red">缺</span>' : '<span class="tag tag-green">齐</span>')
    : (empty ? '<span class="muted">可空</span>' : '<span class="tag tag-green">已填</span>')}</td></tr>`;
  }).join('')}
      </tbody></table></div>
      <div class="flex mt8" style="gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-primary" id="detail-stamp-print">打印归档章</button>
        <span class="help" style="align-self:center">必备项：全宗号、年度、保管期限、件号、页数（机构(问题)为选择项）</span>
      </div>` : '<div class="muted">归档章数据读取失败（不影响其它操作）</div>';

    // ---- 元数据（DA/T 46）：按 背景/结构/管理过程/描述 分组 ----
    const metaEls = (meta && meta.elements) || [];
    const metaVals = (meta && meta.values) || {};
    const metaGroups = [];
    for (const e of metaEls) {
      let g = metaGroups.find((x) => x.kind === e.kind);
      if (!g) { g = { kind: e.kind, label: e.kindLabel || e.kind, items: [] }; metaGroups.push(g); }
      g.items.push(e);
    }
    const metaFilled = metaEls.filter((e) => String(metaVals[e.code] === undefined || metaVals[e.code] === null ? '' : metaVals[e.code]) !== '').length;
    const metaReqMissing = metaEls.filter((e) => e.required && String(metaVals[e.code] === undefined ? '' : metaVals[e.code]) === '').length;
    const metaHtml = meta ? `
      <div class="muted" style="margin-bottom:8px">共 ${metaEls.length} 项，已填 <b>${metaFilled}</b> 项${metaReqMissing
    ? `，<span class="tag tag-red">必填缺 ${metaReqMissing} 项</span>` : '，必填项齐全'}${meta.captured ? '' : '（尚未自动捕获，以下按现有档案信息实时推算）'}</div>
      ${metaGroups.map((g) => `
        <div style="margin-bottom:10px">
          <div class="muted" style="font-weight:600;margin-bottom:4px">${esc(g.label)}（${g.items.length} 项）</div>
          <div class="table-wrap"><table><thead><tr><th>元数据项</th><th>值</th><th>属性</th></tr></thead><tbody>
            ${g.items.map((e) => {
    const v = metaVals[e.code];
    const canEdit = e.editable && e.writeThrough;
    const show = v === undefined || v === null ? '' : String(v);
    return `<tr>
              <td>${esc(e.name)} <span class="muted">${esc(e.code)}</span></td>
              <td>${canEdit
    ? `<input data-meta-input="${esc(e.code)}" value="${esc(show)}" style="width:100%;padding:4px 6px;border:1px solid var(--c-line);border-radius:4px">`
    : (show === '' ? '<span class="muted">—</span>' : esc(show))}</td>
              <td>${e.required ? '<span class="tag tag-amber">必填</span> ' : ''}${canEdit
    ? '<span class="tag tag-green">可编辑</span>' : '<span class="tag tag-gray">禁止修改</span>'}${e.autoCaptured ? ' <span class="tag tag-blue">自动捕获</span>' : ''}</td>
            </tr>`;
  }).join('')}
          </tbody></table></div>
        </div>`).join('')}
      <div class="flex mt8" style="gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-primary" id="detail-meta-save">保存可编辑项</button>
        <a class="btn btn-sm" href="/api/archives/${a.id}/metadata/export.xml" target="_blank">导出元数据 XML</a>
        <span class="help" style="align-self:center">背景/结构/管理过程元数据按标准禁止修改，只能由系统捕获；试图修改会被拦截并留痕。</span>
      </div>
      ${(meta.changes || []).length ? `<div class="muted mt8">变更留痕 ${(meta.changes || []).length} 条：${esc((meta.changes || []).slice(0, 3).map((c) => `${c.element_code}·${c.action}`).join('、'))}…</div>` : ''}`
      : '<div class="muted">元数据读取失败（不影响其它操作）</div>';

    // ---- 件级状态机（v4.32.0）----
    // 「实体在哪」（status）与「办到哪一步」（lifecycle）是两件事：
    // 一件档案可能已经上架（status=在库），但著录还没做完（lifecycle=著录）。
    // 两者分开看，才不会出现"改流程就把借阅状态改乱"的情况。
    const LC_TAG = {
      接收: 'tag-gray', 整理: 'tag-gray', 著录: 'tag-blue', 归档: 'tag-blue',
      上架: 'tag-green', 借阅: 'tag-amber', 鉴定: 'tag-amber', 销毁: 'tag-red', 移交: 'tag-blue',
    };
    const lcCur = (lc && lc.current) || a.lifecycle || '';
    const lcNext = (lc && lc.next) || [];
    const lcHist = (lc && lc.list) || [];
    const lcBlock = `
      <div class="section-title">办理进度（件级状态机）</div>
      <div class="dl">
        <div><span>当前节点</span><b>${lcCur ? `<span class="tag ${LC_TAG[lcCur] || 'tag'}">${esc(lcCur)}</span>` : '<span class="muted">未设置</span>'}</b></div>
        <div><span>实体状态</span><b>${statusTag(a.status)}</b></div>
        <div><span>最近流转</span><b>${a.lifecycle_at ? fmtTime(a.lifecycle_at) : '<span class="muted">—</span>'}</b></div>
      </div>
      <div class="flex mt8" style="gap:6px;flex-wrap:wrap">
        ${lcNext.length ? lcNext.map((s) => `<button class="btn btn-sm" data-lc-to="${esc(s)}">转为「${esc(s)}」</button>`).join('')
    : '<span class="muted">已是终态（销毁 / 移交），不能再流转</span>'}
      </div>
      ${lcHist.length ? `<div class="table-wrap mt8"><table><thead><tr><th class="nowrap">#</th><th class="nowrap">流转</th><th>原因</th><th class="nowrap">经办人</th><th class="nowrap">时间</th></tr></thead><tbody>
        ${lcHist.slice(0, 8).map((h) => `<tr><td class="nowrap muted">${h.seq}</td>
          <td class="nowrap">${esc(h.from_state || '—')} → <b>${esc(h.to_state)}</b></td>
          <td>${esc(h.reason || '')}</td><td class="nowrap">${esc(h.by_name || '')}</td>
          <td class="nowrap muted">${fmtTime(h.at)}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="help mt8">还没有流转记录。新接收的件从「接收」开始，按 接收→整理→著录→归档→上架 逐段推进。</div>'}`;

    // ---- 四性证据链（v4.32.0）----
    // 真实性/完整性/可用性/安全性：不是"检测过一次就算"，而是**每类各留一条证据**，
    // 谁、用什么方法、测出什么值、结论如何，全都能翻出来查。缺哪一类就直接标出来。
    const EV_LIST = (ev && ev.list) || [];
    const EV_MISSING = (ev && ev.missing) || [];
    const EV_TAG = { 通过: 'tag-green', 存疑: 'tag-amber', 不通过: 'tag-red' };
    const evBlock = `
      <div class="section-title">四性证据链</div>
      <div class="flex" style="gap:6px;flex-wrap:wrap;margin-bottom:8px">
        ${((ev && ev.aspects) || ['真实性', '完整性', '可用性', '安全性']).map((s) => {
    const hit = EV_LIST.filter((x) => x.aspect === s).pop();
    return `<span class="tag ${hit ? EV_TAG[hit.result] || 'tag' : 'tag-gray'}"
      title="${hit ? esc(hit.method + '｜' + (hit.value || '') + '｜' + (hit.by_name || '')) : '尚未取证'}">${esc(s)}${hit ? '·' + esc(hit.result) : '·未取证'}</span>`;
  }).join('')}
        <button class="btn btn-sm btn-primary" id="detail-ev-fixity" title="重算附件 SHA-256 与库内登记值比对，结论自动写入">完整性实测</button>
        <button class="btn btn-sm" id="detail-ev-add">补录证据</button>
      </div>
      ${EV_LIST.length ? `<div class="table-wrap"><table><thead><tr>
          <th class="nowrap">类别</th><th>方法</th><th>结果值</th><th class="nowrap">结论</th>
          <th class="nowrap">经办人</th><th class="nowrap">时间</th></tr></thead><tbody>
        ${EV_LIST.slice(0, 10).map((x) => `<tr>
          <td class="nowrap">${esc(x.aspect)}</td>
          <td>${esc(x.method || '')}${x.file_name ? `<div class="muted" style="font-size:11px">${esc(x.file_name)}</div>` : ''}</td>
          <td class="mono" style="font-size:11px;word-break:break-all">${esc(String(x.value || '').slice(0, 80))}${String(x.value || '').length > 80 ? '…' : ''}
            ${x.note ? `<div class="muted" style="font-size:11px">${esc(x.note)}</div>` : ''}</td>
          <td class="nowrap"><span class="tag ${EV_TAG[x.result] || 'tag'}">${esc(x.result)}</span></td>
          <td class="nowrap muted">${esc(x.by_name || '')}</td>
          <td class="nowrap muted">${fmtTime(x.at)}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="muted">还没有任何证据记录。</div>'}
      <div class="help mt8">完整性由系统实测 SHA-256；真实性、可用性、安全性本机无 CA/时间戳服务，
        按<b>方法学留痕</b>记录（人工核验、格式可解析、权限校验），不冒充第三方权威证明。
        ${EV_MISSING.length ? `当前缺：<b>${EV_MISSING.join('、')}</b>` : '四类证据齐全。'}</div>`;

    const body = el('div', {}, `
      <div class="detail-head">
        <div>
          <div class="detail-title">${esc(a.title)}</div>
          <div class="detail-tags">
            <span class="tag tag-blue">${esc(a.archive_code)}</span>
            ${statusTag(a.status)}
            ${lcCur ? `<span class="tag ${LC_TAG[lcCur] || 'tag'}">${esc(lcCur)}</span>` : ''}
            <span class="tag">${esc(a.retention)}</span>
            ${a.secret_level !== '公开' ? `<span class="tag tag-amber">${esc(a.secret_level)}</span>` : ''}
            ${a.files.length ? `<span class="tag tag-green">附件 ${a.files.length}</span>` : '<span class="tag tag-gray">无附件</span>'}
          </div>
        </div>
      </div>
      <div class="section-title">著录信息</div>
      <div class="dl">${dl}</div>
      <div class="section-title">摘要</div>
      <div style="line-height:1.8;color:var(--c-text-2)">${a.abstract ? esc(a.abstract) : '<span class="muted">未填写</span>'}</div>
      ${apprBlock}
      <div class="section-title">电子附件</div>
      ${scanCheckHtml}
      <div class="file-list" id="file-list">${files}</div>
      ${canUploadTo(a)
    ? `<div class="flex mt8" style="gap:8px;flex-wrap:wrap">
         <button class="btn btn-sm btn-primary" id="detail-scan-import"
           title="扫描仪输出 PDF 后从这导入：按档号命名、按档号建目录、自动记录页数与扫描参数">＋ 导入扫描件（PDF）</button>
         <span class="muted" style="align-self:center">扫描仪出 PDF 走左边；其它文件用下面的拖放区</span>
       </div>
       <div class="dropzone mt8" id="detail-drop">点击选择文件上传，或把文件拖到这里 <b>（支持批量）</b></div>`
    : '<div class="help mt8">你没有向本件上传附件的权限（需要档案员及以上，或本人著录的件）。</div>'}
      <input type="file" id="detail-file-input" multiple class="hidden">
      <input type="file" id="detail-scan-input" accept=".pdf,application/pdf" multiple class="hidden">
      ${replBlock}
      <div class="section-title">关联件 / 补充归档</div>
      <div id="detail-links"><div class="muted">正在读取关联件…</div></div>
      <div class="section-title">档案二维码</div>
      <div class="qr-box">
        <div class="qr-holder" id="detail-qr-wrap">
          <div class="help" style="padding:20px 0">正在按档案号长度计算合适的二维码尺寸…</div>
        </div>
        <div class="qr-side">
          <div class="mono" style="font-size:13px">${esc(a.archive_code || a.archive_number || '')}</div>
          <div class="help">二维码内容就是上面的档案号，扫码枪扫出来可直接在盘点/检索里匹配到这份档案。</div>
          <div class="help" id="detail-qr-meta"></div>
          <div class="flex mt8" style="flex-wrap:wrap;gap:6px">
            <a class="btn btn-sm" href="/api/archives/${a.id}/qrcode.png?download=1">下载 PNG</a>
            <button class="btn btn-sm" id="detail-qr-big">放大显示</button>
            <button class="btn btn-sm" id="detail-qr-debug">二维码调试</button>
            <button class="btn btn-sm" id="detail-qr-print">打印二维码标签</button>
            <button class="btn btn-sm" id="detail-qr-rebuild">重新生成</button>
          </div>
        </div>
      </div>
      <div class="section-title">归档章（DA/T 22—2015 §5.4.4）</div>
      ${stampHtml}
      <div class="section-title">元数据（DA/T 46）</div>
      ${metaHtml}
      ${lcBlock}
      ${evBlock}
      <div class="section-title">借阅记录</div>
      <div class="table-wrap"><table><thead><tr><th>单号</th><th>借阅人</th><th>方式</th><th>状态</th><th>应还日期</th><th>时间</th></tr></thead>
        <tbody>${loans}</tbody></table></div>
      ${a.status_note ? `<div class="hint-box mt16">状态备注：${esc(a.status_note)}</div>` : ''}
    `);

    const canEdit = canEditArchive(a);
    const foot = [];
    foot.push(btn('关闭', '', () => modal.close()));
    foot.push(btn('打印案卷目录', '', () => window.open('/api/print/catalog?type=' + encodeURIComponent(a.type_code), '_blank')));
    if (a.box_id) foot.push(btn('打印盒脊/卷内目录', '', () => window.open('/api/print/box/' + a.box_id, '_blank')));
    foot.push(btn('借阅申请', '', () => loanDialog(a)));
    if (state.user.role !== 'reader') {
      foot.push(btn('鉴定', '', () => promptDialog(`鉴定：${a.title.slice(0, 20)}`, [
        { name: 'decision', label: '鉴定结论', type: 'select', required: true, value: '继续保管',
          options: [
            { value: '延长保管期限', label: '延长保管期限（继续保存）' },
            { value: '继续保管', label: '继续保管（维持原期限）' },
            { value: '建议销毁', label: '建议销毁（提交销毁清册）' },
          ] },
        { name: 'new_retention', label: '新的保管期限（选“延长”时必填）', type: 'select', value: a.retention, options: state.meta.retentions },
        { name: 'basis', label: '鉴定依据 / 理由', span2: true },
        { name: 'group_opinion', label: '鉴定小组意见', type: 'textarea', span2: true },
        { name: 'member_count', label: '参加鉴定人数', value: '3' },
      ], async (data) => {
        await api(`/api/archives/${a.id}/appraise`, { method: 'POST', body: data });
        toast('鉴定结论已记录', 'ok');
        modal.close();
        setView(a.status === '待销毁' ? 'retention' : 'archives');
      }, { wide: true })));
    }
    if (canEdit) foot.push(btn('编辑', '', () => { modal.close(); setTimeout(() => openArchiveForm(a), 80); }));
    // 件级授权（v4.32.0）：密级或部门把某个同事挡在外面时，不必为了这一件去改密级，
    // 单独给他这一件的阅读权即可 —— 授权只放宽这一件，不外溢到同类档案。
    if (canSecretClassify() && a.secret_level !== '公开') foot.push(btn('授权查阅', '', () => grantDialog(a)));
    // 改错了怎么办：每一版修改前的样子都存着，可以一键退回去（v4.32.0 豆包信创）
    foot.push(btn('历史版本', '', () => openVersionList(a)));
    // 删除 = 移入回收站（v4.22.0）。
    // **原因必填**：删除留痕的核心就是"谁、什么时候、为什么"，
    // 少了原因，回收站就只剩一个不知道来路的名单。
    if (canDeleteArchive()) foot.push(btn('删除', 'btn-danger', () => promptDialog(
      '删除档案（移入回收站）',
      [{
        name: 'reason', label: '删除原因', required: true, span2: true,
        placeholder: '如：重复收录、分类录错、测试件',
        help: '原因会一并记入回收站与审计日志，事后可查。不填不能删除。',
      }],
      async (data) => {
        const r = await api('/api/archives/' + a.id, { method: 'DELETE', body: { reason: data.reason } });
        toast(`《${a.title}》已移入回收站，${(r && r.keepDays) || 30} 天内可恢复`, 'ok', 7000);
        setView('archives');
      },
      { okText: '移入回收站', wide: true })));

    modal.open('档案详情', body, foot, { wide: true });

    // 件级状态机：点节点→填理由→流转（理由非必填，写了才有解释力）
    body.querySelectorAll('[data-lc-to]').forEach((b) => {
      b.onclick = () => {
        const to = b.dataset.lcTo;
        promptDialog(`流转到「${to}」`,
          [{ name: 'reason', label: '流转原因 / 说明', span2: true, type: 'textarea', rows: 2,
            placeholder: '如：已按 8 号令完成著录，转入归档' }],
          async (data) => {
            await api(`/api/archives/${a.id}/transition`, { method: 'POST', body: { to, reason: data.reason } });
            toast(`已流转到「${to}」`, 'ok');
            setTimeout(() => openArchiveDetail(a.id), 120);
          }, { okText: '确认流转' });
      };
    });
    // 四性：完整性一键实测（真实算哈希，不是打个勾）
    const evFix = body.querySelector('#detail-ev-fixity');
    if (evFix) {
      evFix.onclick = async () => {
        try {
          const r = await api(`/api/archives/${a.id}/evidence`, { method: 'POST', body: { aspect: '完整性' } });
          toast(`完整性实测：${r.result}${r.value ? '（SHA-256 ' + String(r.value).slice(0, 12) + '…）' : ''}`,
            r.result === '通过' ? 'ok' : 'warn', 7000);
          setTimeout(() => openArchiveDetail(a.id), 150);
        } catch (e) { toast(e.message, 'err'); }
      };
    }
    const evAdd = body.querySelector('#detail-ev-add');
    if (evAdd) {
      evAdd.onclick = () => promptDialog('补录四性证据', [
        { name: 'aspect', label: '证据类别', type: 'select', required: true, value: '真实性',
          options: ['真实性', '完整性', '可用性', '安全性'] },
        { name: 'method', label: '取证方法', value: '人工核验',
          help: '如：人工核验原件、格式可解析（打开无损）、权限校验（越权访问被拒）' },
        { name: 'result', label: '结论', type: 'select', value: '通过', options: ['通过', '存疑', '不通过'] },
        { name: 'value', label: '结果值', span2: true, help: '如核验人/依据条款/校验码，可空' },
        { name: 'note', label: '备注说明', type: 'textarea', span2: true },
      ], async (data) => {
        await api(`/api/archives/${a.id}/evidence`, { method: 'POST', body: data });
        toast('证据已记录', 'ok');
        setTimeout(() => openArchiveDetail(a.id), 120);
      }, { wide: true });
    }

    // 归档章：单件打印（批量入口在档案检索页的批量操作里）
    const stampBtn = $('#detail-stamp-print');
    if (stampBtn) {
      stampBtn.onclick = () => window.open('/api/print/stamps?ids=' + a.id, '_blank');
    }
    // 元数据：只提交"可编辑且能写回"的那几项；被拒的项原样把标准依据显示出来
    const metaSaveBtn = $('#detail-meta-save');
    if (metaSaveBtn) {
      metaSaveBtn.onclick = async () => {
        const values = {};
        $$('#modal-body [data-meta-input]').forEach((inp) => { values[inp.dataset.metaInput] = inp.value; });
        try {
          const r = await api('/api/archives/' + a.id + '/metadata', { method: 'PUT', body: { values } });
          const applied = (r && r.applied) || [];
          const rejected = (r && r.rejected) || [];
          toast(`已保存 ${applied.length} 项${rejected.length ? `，${rejected.length} 项被拒` : ''}`, rejected.length ? 'warn' : 'ok');
          if (rejected.length) {
            toast(rejected.map((x) => `${x.name || x.code}：${x.reason || '被拒绝'}`).join('；'), 'err', 8000);
          }
          modal.close();
          setTimeout(() => openArchiveDetail(a.id), 120);
        } catch (e) { toast(e.message, 'err'); }
      };
    }

    // 二维码：先问后端「这段内容会生成多少个模块」，再按模块数算显示尺寸，
    // 保证「显示尺寸 = 图片原生尺寸」—— 浏览器一旦缩放就会把模块边缘插值糊掉，
    // 糊边的二维码手机经常认不出。之前这里写死 190px，长档号的码被压到 3px/模块，必然扫不出。
    const qrWrap = body.querySelector('#detail-qr-wrap');
    const qrMeta = body.querySelector('#detail-qr-meta');
    const renderQr = async (bust) => {
      if (!qrWrap) return;
      try {
        // 二维码里装的是**后端算出来的内容**（短落地页网址），不是档案号。
        // 曾经这里自己拿 a.archive_code 去问尺寸 —— 算出来是短内容的格数（37 格），
        // 但图片里其实是长内容（61 格），于是 <img width> 把图片拉伸，模块边缘被插值。
        const info0 = await api(`/api/archives/${a.id}/label`);
        const qrContent = info0.qr_text || a.archive_code || a.archive_number || '';
        const info = await api('/api/qrcode/info?text=' + encodeURIComponent(qrContent));
        const px = qrNaturalPx(info, 620);
        qrWrap.innerHTML = `<a href="/api/archives/${a.id}/qrcode.png?px=${px}&download=1" title="点击下载原图">`
          + `<img class="qr-img" src="/api/archives/${a.id}/qrcode.png?px=${px}${bust ? '&t=' + Date.now() : ''}"`
          + ` width="${px}" height="${px}" alt="档案二维码"></a>`;
        if (qrMeta) {
          qrMeta.innerHTML = `纠错等级 <b>${esc(info.ec_level)}</b>（约 30% 容错）· 静区 <b>${info.margin}</b> 个模块 · `
            + `版本 v${info.version}（${info.modules} 模块，含静区 ${info.cells} 格）<br>`
            + `显示尺寸 <b>${px}px</b>，与图片原生尺寸一致 · 每模块 <b>${px / info.cells}</b> 像素<br>`
            + `二维码内容：<span class="mono" style="word-break:break-all">${esc(qrContent)}</span>`;
        }
      } catch (e) {
        qrWrap.innerHTML = `<div class="hint-box warn">二维码加载失败：${esc(e.message)}</div>`;
      }
    };

    const rebuild = body.querySelector('#detail-qr-rebuild');
    if (rebuild) {
      rebuild.onclick = async () => {
        try {
          await fetch(`/api/archives/${a.id}/qrcode.png?rebuild=1`, { credentials: 'same-origin' });
          await renderQr(true);
          toast('二维码已重新生成', 'ok');
        } catch (e) { toast('重新生成失败：' + e.message, 'err'); }
      };
    }
    const qrBig = body.querySelector('#detail-qr-big');
    if (qrBig) qrBig.onclick = () => window.open(`/api/archives/${a.id}/qrcode.png?px=1400`, '_blank');
    const qrDbg = body.querySelector('#detail-qr-debug');
    if (qrDbg) qrDbg.onclick = () => window.open('/api/qrcode/debug?archive=' + a.id, '_blank');
    const qrPrint = body.querySelector('#detail-qr-print');
    if (qrPrint) qrPrint.onclick = () => window.open(`/api/print/archive/${a.id}?auto=1`, '_blank');

    // 附件操作
    const canUpload = canUploadTo(a);
    const drop = body.querySelector('#detail-drop');
    const input = body.querySelector('#detail-file-input');
    // 没有上传权限时，上传区在模板里就没有渲染出来（而不是渲染出来再隐藏），
    // 所以这里必须判空 —— 否则整页会在这一行抛 TypeError，附件区整个打不开。
    if (!canUpload) { if (drop) drop.classList.add('hidden'); }
    else if (drop && input) {
      drop.onclick = () => input.click();
      input.onchange = async () => { await doUpload(a.id, input.files); input.value = ''; modal.close(); openArchiveDetail(a.id); };
      ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
      ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
      drop.addEventListener('drop', async (e) => {
        if (e.dataTransfer && e.dataTransfer.files.length) {
          await doUpload(a.id, e.dataTransfer.files);
          modal.close(); openArchiveDetail(a.id);
        }
      });
    }

    // 导入扫描件（v4.28.0）：扫描仪出的是多页 PDF，一件通常一个 PDF。
    // 与普通上传的区别是 kind=扫描件、要报扫描参数、并按档号落盘（见 server/lib/storage.js）。
    const scanBtn = body.querySelector('#detail-scan-import');
    const scanInput = body.querySelector('#detail-scan-input');
    if (canUpload && scanBtn && scanInput) {
      scanBtn.onclick = () => scanInput.click();
      scanInput.onchange = () => {
        const list = Array.from(scanInput.files || []);
        scanInput.value = '';
        if (list.length) importScanDialog(a, list);
      };
    }

    body.querySelectorAll('[data-file]').forEach((row) => {
      const fid = Number(row.dataset.file);
      const fmeta = (a.files || []).find((x) => Number(x.id) === fid) || {};
      const fname = fmeta.original_name || '';
      // 悬停文件名 → **小浮层"瞄一眼"**（v4.26.2；桌面用，手机上本来没有 hover）。
      //
      // 使用者要求：「预览功能能否鼠标移动到文件名就自动打开画面？和打开的效果区别开」。
      // 所以这里刻意**不是**弹出完整预览 —— 那会挡住界面，鼠标划过一排附件就弹好几次。
      // 三种看法各司其职，一眼能分清：
      //   悬停 → 小浮层（缩略图 / 正文前几行，300×220，随鼠标位置出现，移开就消失）
      //   预览 → 应用内完整弹窗（图/PDF + 文字面板 + 复制全文 + 就地 OCR），不离开系统
      //   打开 → 独立查看页（带可选中文字，方便右键复制、另存）
      const nameEl = row.querySelector('.file-name');
      if (nameEl) {
        let hov = 0;
        nameEl.style.cursor = 'help';
        nameEl.title = '悬停快速看；点「预览」看完整内容';
        nameEl.onmouseenter = () => {
          clearTimeout(hov);
          // 350ms 延迟：鼠标只是路过时不该弹东西出来
          hov = setTimeout(async () => {
            let box = document.getElementById('hover-peek');
            if (!box) { box = el('div', { id: 'hover-peek' }); document.body.appendChild(box); }
            box.innerHTML = '';
            const W = 300, H = 220;
            box.style.cssText = 'position:fixed;z-index:9999;display:block;width:' + W + 'px;height:' + H + 'px;'
              + 'overflow:hidden;background:#fff;border:1px solid var(--c-line);border-radius:8px;'
              + 'box-shadow:0 8px 24px rgba(0,0,0,.18);padding:8px';
            if (/\.(png|jpe?g|gif|webp|bmp)$/i.test(fname)) {
              box.appendChild(el('img', { src: `/api/files/${fid}/preview`, style: 'max-width:100%;max-height:100%;display:block;margin:0 auto' }));
            } else {
              const pre = el('pre', { style: 'margin:0;font-size:11px;line-height:1.6;white-space:pre-wrap;word-break:break-all' });
              pre.textContent = '读取中…';
              box.appendChild(pre);
              const info = await api(`/api/files/${fid}/text`).catch(() => null);
              const tx = info && info.status === '成功' ? String(info.content || '') : '';
              pre.textContent = tx
                ? tx.slice(0, 380) + (tx.length > 380 ? '\n…（点「预览」看全文并复制）' : '')
                : '（这份文件没有可提取的正文）';
            }
            const r = nameEl.getBoundingClientRect();
            box.style.left = Math.max(8, Math.min(r.left, window.innerWidth - W - 12)) + 'px';
            box.style.top = Math.max(8, Math.min(r.bottom + 6, window.innerHeight - H - 12)) + 'px';
          }, 350);
        };
        nameEl.onmouseleave = () => {
          clearTimeout(hov);
          const b = document.getElementById('hover-peek');
          if (b) b.style.display = 'none';
        };
      }
      row.querySelectorAll('[data-fact]').forEach((b) => {
        b.onclick = async (ev) => {
          const act = b.dataset.fact;
          if (act === 'preview') return previewFile(fid, fname);
          if (act === 'open') {
            // 与「下载」同一套道理：href 里已经有票据就放行，让浏览器用真实手势新开标签。
            const href = b.getAttribute('href') || '';
            const exp = Number((/[?&]e=(\d+)/.exec(href) || [])[1] || 0);
            if (href && exp - Date.now() > 60000) return;
            if (ev && ev.preventDefault) ev.preventDefault();
            return void openInline(fid, fname);
          }
          if (act === 'download') {
            const wv = inAppBrowser();
            if (wv) {
              // 按钮上已经写着「复制链接」，所以**一点就复制**，不再多弹一层对话框
              // （v4.24.0）。原因说明放在提示里就够了：多一次点击就是多一次放弃的机会。
              if (ev && ev.preventDefault) ev.preventDefault();
              const link = b.getAttribute('href') || (location.origin + `/api/files/${fid}/download`);
              return void copyText(link).then((ok) => {
                toast(ok
                  ? `下载链接已复制 —— 粘贴到手机浏览器打开即可（「${wv}」不能下载文件）`
                  : `复制没成功：请点右上角「⋯」→「在浏览器打开」，再点下载`, ok ? 'ok' : 'err', 9000);
              });
            }
            // 「下载」现在是一个**真链接**，href 里在打开详情时就放好了票据。
            // 票据没过期就**绝不拦截**这次点击 —— 让浏览器按真实用户手势处理。
            //
            // 这是被实测逼出来的：手机上"先 await 取票据、再 location.href"会被
            // 当成"没有用户手势的下载"而**静默拦掉** —— 不发请求、不报错、
            // 提示自己消失。服务端审计日志里能看到证据：那几次手机下载
            // **一条 /download 记录都没有**，说明请求根本没发出去。
            const href = b.getAttribute('href') || '';
            const exp = Number((/[?&]e=(\d+)/.exec(href) || [])[1] || 0);
            if (href && exp - Date.now() > 60000) return;
            if (ev && ev.preventDefault) ev.preventDefault();
            return void downloadFile(fid, fname);
          }
          if (act === 'up' || act === 'down') {
            try {
              const r = await api(`/api/files/${fid}/move`, { method: 'POST', body: { dir: act } });
              if (r.moved) { modal.close(); openArchiveDetail(a.id); }
              else toast(act === 'up' ? '已经在最前面了' : '已经在最后面了', 'warn');
            } catch (e) { toast(e.message, 'err'); }
            return;
          }
          if (act === 'replace') {
            promptDialog('替换正文（补页 / 重扫）', [
              { name: 'file', label: '新的正文文件', type: 'file', required: true,
                help: '替换后旧版的文件名、SHA-256 与大小会留痕，事后可查 —— 不是"删掉重传"' },
              { name: 'reason', label: '替换原因', required: true, span2: true,
                placeholder: '如：原扫描缺页，重新扫描' },
              { name: 'keep_name', label: '保留原文件名', placeholder: '填 1 表示保留，留空则用新文件名' },
            ], async (data) => {
              const node = document.querySelector('#modal-body [name="file"]');
              const file = node && node.files && node.files[0];
              if (!file) throw new Error('请选择要替换的文件');
              const fd = new FormData();
              fd.append('files', file);
              fd.append('reason', data.reason);
              if (String(data.keep_name || '').trim() === '1') fd.append('keep_name', '1');
              await uploadWithProgress(`/api/files/${fid}/replace`, fd, () => {});
              toast('已替换正文，旧版已留痕', 'ok', 4000);
              setTimeout(() => openArchiveDetail(a.id), 150);
            }, { okText: '替换', wide: true });
            return;
          }
          if (act === 'ocr') {
            b.disabled = true;
            b.textContent = '识别中…';
            try {
              const r = await api(`/api/files/${fid}/ocr`, { method: 'POST', body: {} });
              toast(`OCR 完成：识别 ${r.chars} 字（${r.engine}${r.pages ? '，' + r.pages + ' 页' : ''}）`, 'ok', 6000);
              setTimeout(() => openArchiveDetail(a.id), 150);
            } catch (e) {
              toast(e.message, 'err', 9000);
              b.disabled = false;
              b.textContent = '识别';
            }
            return;
          }
          if (act === 'del') return confirmDialog('删除附件', '确定删除该附件吗？删除后不可恢复。', async () => {
            await api('/api/files/' + fid, { method: 'DELETE' });
            toast('已删除', 'ok');
            modal.close(); openArchiveDetail(a.id);
          }, '确认删除');
        };
      });
    });

    // 预取下载票据（v4.20.9）：打开详情时就把票据写进「下载」链接的 href，
    // 这样使用者点下去是**一次真实手势的真实链接**，浏览器必须下载。
    // 取不到也没关系 —— 点击时还有异步兜底那条路（会给出可点的链接）。
    (a.files || []).forEach(async (f) => {
      for (const [mode, fact] of [['download', 'download'], ['inline', 'open']]) {
        const node = body.querySelector(`[data-file="${f.id}"] [data-fact="${fact}"]`);
        if (!node) continue;
        try {
          const d = await fileTicket(f.id, mode);
          node.setAttribute('href', d.url);
          node.setAttribute('title', (mode === 'inline' ? '在新标签里打开：' : '点击下载：') + (d.name || ''));
        } catch (_) { /* 保持异步兜底路径 */ }
      }
    });
    // ---- 关联件 / 补充归档（v4.9.0）----
    // 依据 DA/T 22—2015：整理单位是「件」。后来才找到的材料应当**另立一件、编新件号**，
    // 再与原档案建立关联 —— 而不是把它插进那个已经编好、已盖归档章、已打印移交清册的件里。
    // 这个区块就是"建立关联 + 登记原因 + 出书面凭据"三件事的入口。
    const linksBox = body.querySelector('#detail-links');
    /** 一个档号（或二维码扫出的编号）→ 档案对象；解析不到返回 null */
    async function resolveOne(text) {
      const r = await api('/api/scan/resolve?text=' + encodeURIComponent(String(text).trim()));
      return (r && r.kind === 'archive' && r.archive) ? r.archive : null;
    }
    function renderLinks(list) {
      if (!linksBox) return;
      const rows = (list || []).map((l) => `
        <div class="file-item" data-link="${l.id}">
          <span class="file-icon">${l.kind === '补充归档' ? '补' : '关'}</span>
          <span class="file-name">
            <b>${esc(l.archive.archive_number || l.archive.archive_code || ('#' + l.archive.id))}</b>
            <span>${esc(l.archive.title || '')} · <b>${esc(l.kind)}</b>${l.direction === 'in' ? '（由对方建立）' : ''}${l.note ? ' · ' + esc(l.note) : ''}${l.by ? ' · ' + esc(l.by) : ''}</span>
          </span>
          <button class="btn btn-sm" data-lfact="open">查看</button>
          ${canEditFile() ? '<button class="btn btn-sm btn-danger" data-lfact="del">解除</button>' : ''}
        </div>`).join('') || '<div class="muted" style="padding:6px 0">暂无关联件。后来才找到的材料，建议在「档案著录」里另立一件拿到新档号，再回到这里与原件建立关联 —— 件级整理下不往已编好的件里插页。</div>';
      linksBox.innerHTML = `<div class="file-list">${rows}</div>`
        + (canEditFile() ? `<div class="flex mt8" style="gap:6px;flex-wrap:wrap">
            <button class="btn btn-sm" id="btn-link-add">建立关联（参见）</button>
            <button class="btn btn-sm btn-primary" id="btn-supplement">补充归档登记…</button>
            <a class="btn btn-sm" href="/api/archives/${a.id}/supplement/print" target="_blank">打印补充归档登记表</a>
          </div>` : '');
      linksBox.querySelectorAll('[data-link]').forEach((row) => {
        const lid = Number(row.dataset.link);
        const link = (list || []).find((x) => x.id === lid) || { archive: {} };
        row.querySelectorAll('[data-lfact]').forEach((b2) => {
          b2.onclick = async () => {
            if (b2.dataset.lfact === 'open') { modal.close(); return void openArchiveDetail(link.archive.id); }
            confirmDialog('解除关联',
              `确定解除与 ${link.archive.archive_number || link.archive.archive_code} 的关联吗？关联是双向的，解除后两个方向都会消失。`,
              async () => {
                try {
                  await api('/api/links/' + lid, { method: 'DELETE' });
                  toast('已解除关联', 'ok');
                  setTimeout(() => openArchiveDetail(a.id), 120);
                } catch (e) { toast(e.message, 'err'); }
              }, '确认解除');
          };
        });
      });
      const addBtn = linksBox.querySelector('#btn-link-add');
      if (addBtn) addBtn.onclick = () => linkDialog('参见');
      const supBtn = linksBox.querySelector('#btn-supplement');
      if (supBtn) supBtn.onclick = () => linkDialog('补充归档');
    }
    /**
     * 建立关联 / 补充归档登记的对话框。
     *
     * 这里用**填档号**而不是弹出档案选择器：这个场景发生在"新件刚著录完"，
     * 手上正好有它的档号或打印出来的二维码标签 —— 扫码枪扫一下比在几万条里翻找快得多。
     * 解析走 /api/scan/resolve，与扫码工作台同一套逻辑（含密级过滤：看不到的一律按"没找到"回）。
     */
    function linkDialog(kind) {
      const isSup = kind === '补充归档';
      promptDialog(isSup ? '补充归档登记' : '建立关联（参见）', [
        {
          name: 'codes', label: isSup ? '补入件的档号（可多件，每行一个）' : '要关联的档号（可多件，每行一个）',
          type: 'textarea', rows: 3, required: true, span2: true,
          placeholder: '可用扫码枪直接扫新件的二维码；多个档号换行、空格或逗号分隔',
          help: '新件要先去「档案著录」录好（它会拿到自己的件号/档号）—— 件级整理下新资料是独立一件，不并入原件。',
        },
        {
          name: 'reason', label: isSup ? '补充归档原因' : '关联说明', required: true, span2: true,
          placeholder: isSup ? '如：原件附件后补' : '如：同一事由',
          help: isSup ? '原因会写进补充归档登记表和操作日志，也是备考表说明里的内容。' : '',
        },
      ], async (data) => {
        const codes = String(data.codes || '').split(/[\s,，;；、]+/).map((s) => s.trim()).filter(Boolean);
        const found = [];
        const missed = [];
        for (const c of codes) {
          const hit = await resolveOne(c);
          if (hit) found.push(hit.id); else missed.push(c);
        }
        if (!found.length) throw new Error('这些档号都没找到（或超出你的密级范围）：' + missed.join('、'));
        const r = isSup
          ? await api(`/api/archives/${a.id}/supplement`, {
            method: 'POST',
            body: { new_ids: found, reason: data.reason, add_to_box_note: true },
          })
          : await api(`/api/archives/${a.id}/links`, {
            method: 'POST',
            body: { to_ids: found, kind: '参见', note: data.reason },
          });
        const n = (r.created || []).length;
        const skipped = (r.skipped || []).length;
        toast(`${isSup ? '已登记补充归档' : '已建立关联'} ${n} 件`
          + (skipped ? `，跳过 ${skipped} 件（重复或不可见）` : '')
          + (missed.length ? `，${missed.length} 个档号没找到` : '')
          + (isSup && r.box_note_updated ? `；已写入盒 ${r.box_code} 的备考表` : ''),
        'ok', 6000);
        // modal 只有一个实例，必须等它关掉再重开详情，否则新弹窗会被立刻覆盖
        setTimeout(() => openArchiveDetail(a.id), 150);
      }, { okText: isSup ? '登记' : '建立关联', wide: true });
    }
    renderLinks(a.links || []);
    // ---- 定密与三鉴的操作入口（v4.10.0）----
    const secBtn = body.querySelector('#detail-secret');
    if (secBtn) {
      secBtn.onclick = () => promptDialog('登记 / 变更定密信息', [
        { name: 'secret_level', label: '密级', type: 'select', required: true, value: a.secret_level, options: state.meta.secretLevels },
        { name: 'secret_term', label: '保密期限', placeholder: '如 10年 / 30年 / 长期 / 解密条件成就前',
          help: '填「N年」时系统会按定密日期自动算出届满日期；长期与条件解密则留空届满日期。' },
        { name: 'secret_from', label: '定密日期', value: a.secret_from || a.archive_date || '', placeholder: 'YYYY-MM-DD' },
        { name: 'secret_to', label: '届满日期', value: a.secret_to || '', placeholder: '可空，按保密期限自动换算' },
        { name: 'secret_basis', label: '定密依据', span2: true, value: a.secret_basis || '',
          placeholder: '如：本单位保密事项范围第 3 条', help: '涉密档案必填 —— 定密责任人的法定要求。' },
        { name: 'declassify_condition', label: '解密条件', span2: true, value: a.declassify_condition || '',
          placeholder: '如：公开后不会对国家安全和利益造成损害' },
      ], async (data) => {
        await api(`/api/archives/${a.id}/secret`, { method: 'POST', body: data });
        toast('定密信息已登记', 'ok');
        setTimeout(() => openArchiveDetail(a.id), 150);
      }, { okText: '保存', wide: true });
    }
    body.querySelectorAll('#detail-apr-value, #detail-apr-secret, #detail-apr-open').forEach((b2) => {
      b2.onclick = () => {
        const kind = b2.id === 'detail-apr-secret' ? '密级鉴定' : (b2.id === 'detail-apr-open' ? '开放鉴定' : '价值鉴定');
        modal.close();
        openAppraisalOneDialog(kind, {
          id: a.id, title: a.title, retention: a.retention, secret_level: a.secret_level,
          secret_term: a.secret_term, open_state: a.open_state,
        });
      };
    });
    // ★ 二维码渲染放到**所有按钮绑定完之后**再开始。
    //   踩过的坑：原来这里是 await renderQr(false)，而二维码要发一次（后来变成两次）
    //   网络请求 —— 在它返回之前，下面的附件「预览/下载/删除」按钮虽然已经画在页面上了，
    //   但 onclick 还没挂上，用户这时候点下去**没有任何反应**。
    //   请求越多，这个「点了没反应」的空窗期越长。所以：先绑事件，最后再渲染二维码。
    //   renderQr 内部自带 try/catch，不会把异常抛出来。
    renderQr(false).catch(() => {});
  }

  function fileIcon(name) {
    const ext = String(name).split('.').pop().toLowerCase();
    if (['pdf'].includes(ext)) return 'PDF';
    if (['doc', 'docx'].includes(ext)) return 'DOC';
    if (['xls', 'xlsx', 'csv'].includes(ext)) return 'XLS';
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)) return 'IMG';
    if (['zip', 'rar', '7z'].includes(ext)) return 'ZIP';
    if (['dwg', 'dxf'].includes(ext)) return 'DWG';
    return (ext || 'FILE').slice(0, 3).toUpperCase();
  }

  /**
   * 我的权限（v4.17.0）：**唯一**的前端判权入口。
   *
   * 规则来自服务端下发的 `state.actions`（由 lib/policy.js 的 can() 算出），
   * 所以这里不再自己写 `role === 'xxx'`。前端判权永远只用来**决定显不显示按钮**，
   * 真正的拦截永远在后端 —— 前端藏起来的东西，随手改个请求就绕过去了。
   */
  const can = (action) => !!(state.actions && state.actions[action]);

  /**
   * 角色下拉项（v4.18.0）：对外**只暴露两种身份** —— 档案管理员 / 其他人员。
   *
   * 三员（sysadmin/secadmin/auditor）与 clerk 在 policy 里、账号也还在库里，
   * 只是不出现在界面上；哪天要三员分立，把服务端的 LOGIN_IDENTITIES 加一行即可，
   * 前端不用改。
   *
   * ⚠ `current` 兜底很关键：编辑一个"保留角色"的账号（比如 auditor）时，
   * 若下拉里没有它，浏览器会把 select 落到第一个选项上 —— 保存下去就等于
   * **悄悄把这个账号提权成档案管理员**。所以当前角色必须原样出现在选项里。
   */
  function roleOptions(current) {
    const list = (state.identities && state.identities.length)
      ? state.identities.slice()
      : [{ key: 'manager', label: '档案管理员', role: 'admin' }, { key: 'staff', label: '其他人员', role: 'reader' }];
    const opts = list.map((x) => ({ value: x.role, label: x.label }));
    if (current && !opts.some((o) => o.value === current)) {
      opts.push({ value: current, label: `${(state.roleNames || {})[current] || current}（保留角色，不对外）` });
    }
    return opts;
  }

  function canEditArchive(a) {
    // 只依据服务端下发的 archive:update（v4.17.0）。
    // 原来还有一条 `a.created_by === u.id` 的兜底 —— 那是**假承诺**：
    // 后端按 policy 判定 `archive:update = lv>=2`，普通用户对自己建的件也是 403，
    // 而界面却给他显示"编辑/删除"，点了必然失败（v3.4.7 那个提权漏洞修掉后就是这样）。
    return !!a && can('archive:update');
  }
  function canDeleteArchive() { return can('archive:delete'); }
  /**
   * 附件操作（上移/下移/替换/删除）：与后端一致的判据是 `file:delete`（档案员及以上）。
   * 注意**不能**用 file:upload 来判断这些按钮 —— 后者的口径更宽
   * （普通用户对自己建的件可以上传），用它会让普通用户看到一排点了就 403 的按钮。
   */
  function canEditFile() { return can('file:delete'); }

  /**
   * 能不能往**这一件**上传附件。
   * v4.20.0 起口径就是服务端的 `file:upload`（档案员及以上）——
   * 之前这里还给普通用户补过"可传自己建的件"的例外，现在使用者把权限模型定成
   * "其他人员只能查阅"，那个例外已经取消，前端跟着简化，两边不会再分叉。
   */
  function canUploadTo() {
    return can('file:upload');
  }

  /** 定密与变更密级：与后端 `secret:classify` 同一口径（安全保密员 / 管理员） */
  function canSecretClassify() { return can('secret:classify'); }
  /** 开放鉴定：与后端 `appraisal:approve`（lv>=4）同一口径 —— 开放与否由馆领导批准 */
  function canApproveAppraisal() { return can('appraisal:approve'); }

  /**
   * 下载附件（v4.20.4 重做）。
   *
   * 原来这里是 `window.location.href = '/api/files/x/download'` —— **整页跳转**。
   * 在手机上这条跳转不一定带会话 cookie（浏览器下载器/外部浏览器另起请求），
   * 服务端就回 401，于是**整页变成一坨 JSON**（使用者截图里那句
   * `{"ok":false,"error":"未登录或登录已过期…"}`）。
   *
   * 现在改成：用带会话的 fetch 把字节取回来，再用 Blob 触发下载。
   * 好处有两个 —— ① 与页面同源同会话，手机上不会再"未登录"；
   * ② 出错时是一条正常提示（说明到底为什么），而不是把 JSON 甩在页面上。
   * 超过 100MB 的附件仍走直链：手机上把几百兆读进内存会直接把页面搞崩。
   */
  /**
   * 取一张附件**短时票据**（v4.20.7）。
   *
   * 为什么需要它：手机上"下载/打开附件"两条老路都断了 ——
   *   ① 整页直链：安卓把它交给**系统下载器**，那是另一个进程、不带会话 cookie，
   *      服务端回 401，整页变成一坨"未登录"的 JSON（v4.20.4 之前）；
   *   ② fetch + Blob：很多手机浏览器 / WebView 不支持 blob 下载，
   *      浏览器自己弹「暂无可用的打开方式」（v4.20.4 之后）。
   * 票据让直链**不依赖 cookie**；而服务端拿到票据后仍按票据里的用户重跑一遍
   * 权限、密级与利用控制，所以票据只解决"能不能认出你是谁"，不放松"你能不能拿"。
   */
  async function fileTicket(fid, mode) {
    // 必须带超时：手机网络"半死不活"时 fetch 会一直挂着，
    // 而提示语又不会自己消失 —— 使用者看到的就是"一直正在下载"。
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 8000);
    let r;
    try {
      r = await fetch(`/api/files/${fid}/download-ticket?mode=${mode}`,
        { credentials: 'same-origin', signal: ctl.signal });
    } catch (e) {
      throw new Error(e && e.name === 'AbortError' ? '服务器响应超时，请检查手机与本机是否在同一局域网' : '网络异常，无法获取下载凭据');
    } finally {
      clearTimeout(timer);
    }
    let j = null;
    try { j = await r.json(); } catch (_) { /* 非 JSON 时下面统一报错 */ }
    if (!r.ok || !j || !j.ok) throw new Error((j && j.error) || `无法获取下载凭据（HTTP ${r.status}）`);
    return j.data;
  }

  /**
   * 提示里带一个**可点的兜底下载链接**（v4.20.8）。
   *
   * 手机上程序化跳转有时会被浏览器静默拦掉（尤其是"下载"这种动作），
   * 页面看上去毫无反应。这时唯一可靠的办法是**让使用者自己点一下真实链接** ——
   * 所以兜底必须是个 <a>，不能只是一句话。
   * 提示语用 textContent、链接用真实元素构造，全程不拼 innerHTML。
   */
  function toastDownloadLink(msg, url) {
    const wrap = $('#toast-wrap');
    const t = el('div', { class: 'toast ok', text: msg });
    t.appendChild(el('div', { class: 'toast-sub', text: '没反应的话，点下面的链接下载：' }));
    t.appendChild(el('a', { href: url, class: 'toast-link', text: '点此下载附件' }));
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 27000);
    setTimeout(() => t.remove(), 30000);
  }

  /** 下载附件（v4.20.7 起：票据直链；v4.20.8：超时 + 可点兜底链接） */
  async function downloadFile(fid, fallbackName) {
    const t = toast('正在准备下载…', '', 12000);
    try {
      const d = await fileTicket(fid, 'download');
      t.remove();
      window.location.href = d.url;
      // 跳转是否真的触发了下载，前端**无法**可靠地知道（下载事件不回调、
      // 浏览器也可能静默拦掉），所以再给一条可点的链接兜底。
      toastDownloadLink('已发起下载：' + (d.name || fallbackName || ''), d.url);
    } catch (e) {
      t.remove();
      toast((e && e.message) || '下载失败', 'err', 9000);
    }
  }

  /**
   * 在新标签里打开附件原文（v4.20.7）。
   *
   * 先**同步**开一个空白标签页（这一步还在点击手势里，不会被弹窗拦截），
   * 拿到票据后再把地址填进去 —— 如果反过来"先 await 再 window.open"，
   * 手势已经过期，手机浏览器会直接拦掉这个新窗口。
   */
  /**
   * 生成"查看页"的 HTML（v4.25.1）。
   *
   * 为什么需要它：原来「打开」是把新标签**直接指向附件本身** ——
   * 那一页是浏览器渲染的裸文件，**没有任何我们自己的界面**，也就没有关闭按钮。
   * 手机上尤其难回去（微信内置浏览器连返回键都没有，右上角那个 ✕ 是关掉整页回聊天）。
   * 使用者原话：「点打开就不能设一个右上角 ✕ 关闭吗？」
   *
   * 现在改为：往新窗口写入**我们自己的查看页** —— 顶部一条栏 + 右上角 ✕。
   * ✕ 先试 `window.close()`（新开标签能关），关不掉就 `history.back()`（同标签能回），
   * 再不行回首页 —— 三条路总有一条走得通，不会出现"卡在文件页上出不去"。
   *
   * ⚠ 内层 `</script>` 必须写成 `<\/script>`：这段字符串本身就在 app.js 的脚本里，
   *   不转义会让浏览器**提前结束 app.js 的 script 标签**，整个前端直接崩掉。
   */
  function viewerHtml(d, name, text, via) {
    const label = name || '附件';
    const isImg = /\.(png|jpe?g|gif|webp|bmp)$/i.test(label);
    const body = isImg
      ? `<img src="${d.url}" alt="${esc(label)}">`
      : `<iframe src="${d.url}" title="${esc(label)}"></iframe>`;
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
      + '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
      + `<title>${esc(label)}</title><style>`
      + 'html,body{margin:0;height:100%;background:#111;color:#fff;'
      + 'font:14px/1.5 "Microsoft YaHei",system-ui,sans-serif}'
      + 'img{max-width:100%;max-height:100%;display:block;margin:0 auto}'
      + 'iframe{width:100%;height:100%;border:0;background:#fff}'
      + '</style></head><body>'
      // 这一页的样式全部用**行内写法**：它是一张独立生成的文档，
      // 类名既不在 app.css 里、也不该进 app.css —— 而前端静态守卫会检查
      // "app.js 里用到的类必须在 app.css 里有定义"，用类名反而会误报。
      + '<div style="position:fixed;top:0;left:0;right:0;display:flex;align-items:center;'
      + 'gap:10px;padding:10px 12px;background:rgba(17,17,17,.94);z-index:9">'
      + `<b style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500">${esc(label)}</b>`
      + '<button id="vx" title="关闭" style="flex:none;width:40px;height:40px;border-radius:50%;'
      + 'border:0;background:#fff;color:#111;font-size:20px;line-height:1;cursor:pointer">✕</button></div>'
      + `<div style="position:absolute;top:60px;left:0;right:0;bottom:0">${body}</div>`
      // 可选中复制的正文（v4.26.2）。使用者要求：「打开后用右键复制文字，包括 pdf、图片等都可以」——
      // 图片本身没有文字可选，PDF 在浏览器自带阅读器里也不一定能选，
      // 所以把系统提取/OCR 出来的正文一并放进来：**右键就能复制**。
      + (text
        ? '<details style="position:fixed;left:0;right:0;bottom:0;background:rgba(17,17,17,.96);'
          + 'border-top:1px solid #333;max-height:45%;overflow:auto;z-index:10">'
          + `<summary style="padding:8px 12px;cursor:pointer;font-size:13px">`
          + `文字（${text.length} 字 · ${via === 'ocr' ? '本机 OCR 识别，可能有错字' : '文档正文提取'}）—— 展开后可直接选中、右键复制</summary>`
          + '<pre style="white-space:pre-wrap;word-break:break-all;margin:0;padding:0 12px 12px;'
          + 'font-size:13px;line-height:1.7">' + esc(text) + '</pre></details>'
        : '<div style="position:fixed;left:0;right:0;bottom:0;padding:8px 12px;'
          + 'background:rgba(17,17,17,.96);border-top:1px solid #333;font-size:12px;color:#bbb">'
          + '这份文件里没有可提取的文字（扫描件请回到系统里点「预览」→「识别文字」做 OCR）</div>')
      + '<script>document.getElementById("vx").onclick=function(){'
      + 'try{window.close()}catch(e){}'
      + 'setTimeout(function(){if(!document.hidden){'
      + 'if(history.length>1)history.back();else location.href="/";}},180);};<\/script>'
      + '</body></html>';
  }

  async function openInline(fid, fallbackName) {
    const w = window.open('', '_blank');
    const t = toast('正在打开…', '', 15000);
    try {
      const d = await fileTicket(fid, 'inline');
      // 顺手把正文也取回来（v4.26.2）：查看页里要能"右键复制文字"，
      // 而图片/PDF 本身未必有可选文字 —— 只有把提取/OCR 的正文一并放进去才行。
      const info = await api(`/api/files/${fid}/text`).catch(() => null);
      const vText = info && info.status === '成功' ? String(info.content || '') : '';
      const vVia = (info && info.via) || 'native';
      t.remove();
      if (w && !w.closed) {
        // 写入我们自己的查看页（顶部栏 + 右上角 ✕ + 可选中文字），而不是把标签指向裸文件
        w.document.write(viewerHtml(d, fallbackName, vText, vVia));
        w.document.close();
      } else {
        // 新标签被拦（手机上极常见）——**绝不能退回"替换当前页"**（v4.25.1 修）：
        // 那样附件就把系统界面整个顶掉了，而微信内置浏览器**没有返回按钮**
        // （右上角那个 ✕ 是关掉整个页面、直接回聊天），使用者于是"回不去了"，
        // 只能重新打开系统。改成回退到**应用内预览弹窗** —— 它右上角有 ✕，
        // 随手就能关，界面不会被顶掉。
        toast('这个浏览器不允许开新窗口，已在当前页面预览', 'warn', 6000);
        previewFile(fid, fallbackName);
      }
    } catch (e) {
      t.remove();
      if (w && !w.closed) w.close();
      toast((e && e.message) || '打开失败', 'err', 9000);
    }
  }

  /**
   * 预览附件（v4.20.4 重做判断依据）。
   *
   * 原来只看 HTTP 的 `Content-Type`：凡是 `text/*` 就把字节当文本铺出来。
   * 于是**扩展名与实际内容不符的 Office 文档**（比如 .xlsx 被存成了 text/plain）
   * 会满屏 ZIP 二进制 —— 使用者截图里那些 `PK`、`worksheets/`、`xl/` 就是这个。
   *
   * 现在改为**先问系统自己的正文提取结果**（`/api/files/:id/text`）：
   * 它按字节嗅探真实格式（server/lib/office-sniff.js），认得出那是 Office 文档，
   * 而且正文早就提取好放进索引了。于是 Office 文档预览成**可读的正文**，
   * 而不是二进制；同时如实标明这段正文是"原生提取"还是"OCR 识别"。
   */
  async function previewFile(fid, nameOf) {
    const url = `/api/files/${fid}/preview`;
    const box = el('div', { class: 'preview-box' }, '<span class="muted">加载中…</span>');
    const foot = [
      btn('在浏览器新窗口打开', '', () => window.open(`/api/files/${fid}/download?inline=1`, '_blank')),
      btn('下载', '', () => downloadFile(fid, nameOf)),
    ];
    // 「用本机程序打开」（v4.26.5）—— 也就是"按照相应的格式打开"：
    // 让**服务端**用系统默认程序打开这份附件（Excel 开 .xlsx、Word 开 .docx、图片走看图程序）。
    // 网页自己做不到这件事（拿不到真实路径、也不许启动本机程序），但服务端就跑在这台电脑上。
    // **只对本机访问显示**：从手机或别的电脑点它，窗口只会弹在服务器那台机器上，毫无意义。
    // ⚠ 防御式读全局：回归的「前端冒烟测试」用 DOM 仿真跑这个文件，
    //   那个环境**没有 location** —— 直接读 `location.hostname` 会抛
    //   ReferenceError，把整个预览弹窗的渲染打断（v4.26.5 实测撞到，
    //   而 navigator 那次我刚犯过同样的错；读全局就必须假设宿主可能没有它）。
    const hostName = (typeof location !== 'undefined' && location && location.hostname)
      ? String(location.hostname) : '';
    if (/^(localhost|127\.0\.0\.1|\[::1\])$/.test(hostName)) {
      foot.push(btn('用本机程序打开', '', async () => {
        try {
          const r = await api(`/api/files/${fid}/open-local`, { method: 'POST', body: {} });
          toast((r && r.note) || '已交给本机默认程序打开', 'ok', 7000);
        } catch (e) {
          toast((e && e.message) || '打开失败', 'err', 9000);
        }
      }));
    }
    foot.push(btn('关闭', 'btn-primary', () => modal.close()));
    modal.open('附件预览', box, foot, { wide: true });
    try {
      const [head, info] = await Promise.all([
        fetch(url, { method: 'HEAD', credentials: 'same-origin' }),
        api(`/api/files/${fid}/text`).catch(() => null),
      ]);
      const mime = head.headers.get('content-type') || '';
      const text = info && info.status === '成功' ? String(info.content || '') : '';
      const via = (info && info.via) || 'native';
      const kind = (info && info.kind) || '';
      box.innerHTML = '';
      // 图片 / PDF：既给"看"（原样显示），也给"**复制文字**"（v4.26.1）。
      //
      // 这一段的正文其实早就取回来了（上面那句 `/api/files/:id/text`），
      // 只是原来在这两个分支里直接 return、把它丢掉了 ——
      // 使用者要的"虽然是图片或者 PDF 也能复制文字"，缺的就是这一步。
      // 没有文字的多半是扫描件：直接给一个「识别文字」按钮，走本机 OCR（Windows 自带，不用装东西）。
      const withTextPanel = (host) => {
        const bar = el('div', { class: 'help', style: 'padding:6px 2px;display:flex;gap:8px;align-items:center;flex-wrap:wrap' });
        const pre = el('pre', { style: 'display:none;white-space:pre-wrap;word-break:break-all;max-height:50vh;overflow:auto;margin:6px 0 0' });
        const showText = (t, note) => {
          pre.textContent = t;
          pre.style.display = t ? 'block' : 'none';
          if (t) pre.scrollIntoView({ block: 'nearest' });
          if (note) toast(note, 'ok', 6000);
        };
        if (text) {
          const src = via === 'ocr' ? '扫描件 OCR 识别' : '文档正文提取';
          bar.appendChild(el('span', {}, `可复制文字：已有${src}结果（${text.length} 字）`));
          const toggle = btn('看文字', '', () => {
            const hidden = pre.style.display === 'none';
            pre.style.display = hidden ? 'block' : 'none';
            toggle.textContent = hidden ? '收起文字' : '看文字';
            if (hidden) pre.scrollIntoView({ block: 'nearest' });
          });
          const copy = btn('复制全文', 'btn-primary', async () => {
            const ok = await copyText(text);
            toast(ok ? `已复制 ${text.length} 字` : '复制没成功：请点「看文字」后长按选中复制', ok ? 'ok' : 'err', 7000);
          });
          bar.appendChild(toggle);
          bar.appendChild(copy);
        } else {
          bar.appendChild(el('span', {}, '这份文件里没有可复制的文字（多半是扫描件）。'));
          const ocr = btn('识别文字（本机 OCR）', 'btn-primary', async () => {
            ocr.disabled = true;
            const old = ocr.textContent;
            ocr.textContent = '识别中…（一页约一秒）';
            try {
              await api(`/api/files/${fid}/ocr`, { method: 'POST', body: {} });
              const again = await api(`/api/files/${fid}/text`).catch(() => null);
              const t2 = again && again.status === '成功' ? String(again.content || '') : '';
              if (t2) {
                // 就地换成"可复制"那一套，不要求使用者关掉再点一次预览
                bar.innerHTML = '';
                bar.appendChild(el('span', {}, `识别完成：${t2.length} 字（OCR 结果可能有错字）`));
                pre.textContent = t2;
                pre.style.display = 'block';
                const copy2 = btn('复制全文', 'btn-primary', async () => {
                  const ok = await copyText(t2);
                  toast(ok ? `已复制 ${t2.length} 字` : '复制没成功，请长按选中复制', ok ? 'ok' : 'err', 7000);
                });
                bar.appendChild(copy2);
              } else {
                toast('识别跑完了，但没有提取到文字（可能是空白页或图片太模糊）', 'warn', 8000);
              }
            } catch (e) {
              toast((e && e.message) || '识别失败：本机可能没有可用的 OCR 引擎', 'err', 9000);
            } finally {
              ocr.disabled = false;
              ocr.textContent = old;
            }
          });
          bar.appendChild(ocr);
        }
        host.appendChild(bar);
        host.appendChild(pre);
      };
      if (mime.startsWith('image/')) {
        box.appendChild(el('img', { src: url, alt: '预览' }));
        withTextPanel(box);
        return;
      }
      if (mime.includes('pdf')) {
        box.appendChild(el('iframe', { src: url }));
        withTextPanel(box);
        return;
      }
      // 能提取出正文的（含 Office / 旧版 Office / RTF / 伪装扩展名）→ 显示正文
      if (text) {
        const src = via === 'ocr' ? '扫描件 OCR 识别' : '文档正文提取';
        const bar = el('div', { class: 'help', style: 'padding:6px 2px' },
          `${esc(kind || '文档')} · 已按${esc(src)}显示正文${via === 'ocr' ? '（识别结果可能有错字）' : ''}`
          + `　—　完整排版请点下方「下载」用 Office 打开`);
        box.appendChild(bar);
        box.appendChild(el('pre', {}, esc(text.slice(0, 200000))));
        return;
      }
      // 真正的纯文本（提取器没有专门处理，但确实是文本）→ 原样显示。
      // ⚠ 这里**不能**写 `mime.includes('json')`（v4.20.4 修）：接口出错时回的就是
      //   `application/json`，那会把"报错响应"当成"这是个 JSON 文件"，
      //   接着去拉原始字节铺出来 —— 效果就是满屏二进制。要判断"这是不是文本文件"，
      //   看的是类型前缀，不是里面有没有 json 这个词。
      if (/^text\//.test(mime) || /^application\/(xml|json)$/.test(mime)) {
        const r = await fetch(url, { credentials: 'same-origin' });
        if (r.ok) {
          const txt = await r.text();
          box.appendChild(el('pre', {}, esc(txt.slice(0, 200000))));
          return;
        }
      }
      box.innerHTML = `<div style="text-align:center;padding:40px">
        <div style="font-size:15px;margin-bottom:8px">该格式（${esc(mime || '未知')}）不支持在线预览</div>
        <div class="muted mb16">可下载后用本地软件打开</div>
        <button class="btn btn-primary" id="pv-dl">下载文件</button></div>`;
      const dl = box.querySelector('#pv-dl');
      if (dl) dl.onclick = () => downloadFile(fid, nameOf);
    } catch (e) {
      box.innerHTML = `<div class="muted">预览失败：${esc((e && e.message) || '')}</div>`;
    }
  }

  async function doUpload(archiveId, fileList) {
    if (!fileList || !fileList.length) return;
    const fd = new FormData();
    fd.append('kind', '正文');
    for (const f of fileList) fd.append('files', f, f.name);
    const t = toast('正在上传…', '', 60000);
    try {
      await uploadWithProgress(`/api/archives/${archiveId}/files`, fd, () => {});
      t.remove();
      toast(`已上传 ${fileList.length} 个文件`, 'ok');
    } catch (e) {
      t.remove();
      toast(e.message, 'err');
      throw e;
    }
  }

  /**
   * 导入扫描件（v4.28.0）。
   *
   * 扫描仪输出的是**多页 PDF**，一件档案通常就是一个 PDF。这里做三件事：
   *   ① 让操作者确认扫描参数（分辨率/色彩/设备）—— 这是《数字档案室建设指南》
   *      §5.6.2 要求捕获的数字化元数据，事后再问就没人说得清了；
   *   ② kind 固定为「扫描件」，文件由服务端按档号命名、按档号建目录；
   *   ③ 导入后回报"实体页数 vs PDF 页数"的核对结果 —— 差几页当场就能看见。
   *
   * 为什么不把 PDF 页数交给前端算：浏览器没有 PDF 解析能力（零依赖、不引 CDN），
   * 而服务端已经有 lib/pdf-info 了，同一份事实只留一个来源。
   */
  function importScanDialog(a, fileList) {
    const dftDpi = (state.settings && state.settings['scan.default_dpi']) || '300';
    const dftColor = (state.settings && state.settings['scan.default_color']) || '彩色';
    promptDialog(`导入扫描件：${a.archive_code || a.archive_number || ''}`, [
      { name: 'dpi', label: '扫描分辨率（dpi）', type: 'select', options: ['200', '300', '400', '600'], value: dftDpi },
      { name: 'color_mode', label: '色彩模式', type: 'select', options: ['彩色', '灰度', '黑白'], value: dftColor },
      { name: 'device', label: '扫描设备（可留空）', span2: true, placeholder: '如：佳能 iR-ADV C5535' },
    ], async (data) => {
      const fd = new FormData();
      fd.append('kind', '扫描件');
      fd.append('dpi', data.dpi || dftDpi);
      fd.append('color_mode', data.color_mode || dftColor);
      fd.append('device', data.device || '');
      for (const f of fileList) fd.append('files', f, f.name);
      const t = toast(`正在导入 ${fileList.length} 个扫描件…`, '', 180000);
      let r;
      try {
        r = await uploadWithProgress(`/api/archives/${a.id}/files`, fd, () => {});
      } finally { t.remove(); }
      const c = r && r.scanCheck;
      // promptDialog 成功后会自动关窗；这里延一帧再打开详情，避免两个弹窗互相踩
      setTimeout(() => {
        openArchiveDetail(a.id);
        if (c) toast(c.note, c.level === 'warn' ? 'warn' : 'ok');
        else toast(`已导入 ${fileList.length} 个扫描件`, 'ok');
      }, 80);
    }, { wide: true, okText: '导入' });
  }

  // ---------------- 著录 / 编辑 ----------------
  // 新增门类对话框（v4.30.3）：著录页与「系统管理 → 分类与门类」共用。
  // 门类下拉是原生 <select>，右键会被浏览器自己的菜单吃掉 —— 所以著录页改成
  // 下拉旁边直接给「＋ 新增门类」，右键菜单保留在分类与门类的门类表上（那里是我们的 DOM）。
  function typeAddDialog(onDone) {
    return promptDialog('新增门类', [
      { name: 'code', label: '门类代码（英文缩写）', placeholder: '如 KY，可留空',
        help: '只能用字母、数字或下划线，会拼进档号；中文全称填右侧「门类名称」。留空或填中文时自动分配代码。' },
      { name: 'name', label: '门类名称（中文全称）', required: true, placeholder: '如 科研档案' },
      { name: 'retention', label: '默认保管期限', type: 'select', value: '永久', options: state.meta.retentions },
      { name: 'filing_mode', label: '整理方式', type: 'select', value: 'year', options: [
        { value: 'year', label: '按年度整理（一年一组，跨年断开）' },
        { value: 'project', label: '按项目整理（长期项目跨年度连续编号）' },
      ], span2: true,
        help: '工程、养护这类动辄十几年的项目选「按项目」：档号里的目录号位换成项目号，件号在项目内连续，不因跨年重新从 0001 开始。' },
      { name: 'fields', label: '专用著录项（JSON，可留空）', type: 'textarea', value: '[]', span2: true,
        help: '格式示例：[{"key":"xm","label":"项目名称","type":"text"}]；type 可为 text/textarea/date/number/select' },
    ], async (d) => {
      let fields;
      try { fields = JSON.parse(d.fields || '[]'); } catch (_) { throw new Error('著录项 JSON 格式错误'); }
      // 门类代码必须是字母/数字/下划线（服务端同规则）。最常见的填错是把中文名称填进代码框，
      // 与其让人卡在"保存不了"，不如当场分配一个可用代码（v4.30.4）。
      let code = String(d.code || '').trim().toUpperCase();
      if (!/^[A-Z0-9_]{1,16}$/.test(code)) {
        const used = new Set(state.types.map((t) => String(t.code).toUpperCase()));
        let n = 1;
        do { code = 'T' + String(n).padStart(2, '0'); n += 1; } while (used.has(code) && n < 100);
        toast('门类代码只能用字母或数字，已自动分配「' + code + '」', 'warn');
      }
      await api('/api/types', { method: 'POST', body: { code, name: d.name, retention: d.retention, fields, filing_mode: d.filing_mode } });
      const t = await api('/api/types');
      state.types = t.list; state.meta = t;
      // 门类建好后顺手把它的分类根建出来（v4.30.6）：
      // 标准结构里「门类」与「分类树的根」是同一层级的两张表，只建门类会让分类下拉空着，
      // 用户会以为"分类没得选"。根建好后著录时就能直接落到该门类，需要细分再往里加属类。
      try {
        await api('/api/categories', { method: 'POST', body: { code, name: d.name, sort_no: 99 } });
      } catch (_) { /* 已有同名同码的分类根时忽略 */ }
      const cats = await api('/api/categories');
      state.categories = cats.list; state.catFlat = cats.flat;
      toast('已新增门类「' + d.name + '」', 'ok');
      if (onDone) onDone(code);
    }, { wide: true });
  }

  function archiveFormHtml(a) {
    const isEdit = !!a;
    const v = a || {};
    const extra = (a && a.extra) || {};
    return `
      <form class="form-grid" id="archive-form" onsubmit="return false" autocomplete="off">
        <label class="field"><span>档案门类<b class="req">*</b>${can('meta:manage')
          ? '<button type="button" id="btn-add-type" class="btn btn-sm" title="新增一个门类；也可以在「系统管理 → 分类与门类」里右键门类表新增" style="float:right;height:22px;padding:0 8px;font-size:11.5px;font-weight:400;line-height:20px">＋ 新增门类</button>'
          : ''}</span>
          <select name="type_code" id="f-type">${typeOptions(v.type_code || state.types[0] && state.types[0].code)}</select></label>
        <label class="field"><span>档案号<b class="req">*</b></span>
          <div class="flex" style="flex-wrap:nowrap">
            <input type="text" name="archive_code" id="f-code" value="${esc(v.archive_code || '')}" placeholder="留空自动生成">
            <button class="btn btn-sm" type="button" id="btn-gen-code">自动生成</button>
          </div></label>
        <label class="field"><span>规范档号（全宗-分类-目录-案卷-件）</span>
          <div class="flex" style="flex-wrap:nowrap">
            <input type="text" name="archive_number" id="f-number" value="${esc(v.archive_number || '')}" placeholder="留空按档号规则自动生成">
            <button class="btn btn-sm" type="button" id="btn-gen-number">按规则生成</button>
          </div>
          <div class="help">标准档号便于排架、移交与上级检查。可在「系统管理 → 档号规则」中调整生成规则。</div></label>
        <label class="field span-2"><span>题名（文件标题）<b class="req">*</b></span>
          <input type="text" name="title" value="${esc(v.title || '')}" placeholder="如：关于进一步加强档案管理工作的通知" required></label>
        <label class="field"><span>档案分类<b class="req">*</b></span>
          <select name="category_id" id="f-cat">${categoryOptionsForType(v.type_code || (state.types[0] && state.types[0].code), v.category_id)}</select></label>
        <label class="field" data-proc><span>所属项目（过程资料）</span>
          <select name="project_id" id="f-project"><option value="">（不挂项目）</option></select></label>
        <label class="field" data-proc><span>接收批次</span>
          <select name="batch_id" id="f-batch"><option value="">（不挂批次）</option></select>
          <div class="help">工程、养护资料按批交来：先选项目，再选这一批。留空也能著录（相当于不按批次管理）。</div></label>
        <label class="field"><span>年度</span>
          <input type="text" name="year" value="${esc(v.year || new Date().getFullYear())}" placeholder="2025"></label>
        <label class="field"><span>归档日期</span>
          <input type="date" name="archive_date" value="${esc(v.archive_date || new Date().toISOString().slice(0, 10))}"></label>
        <label class="field"><span>保管期限 <button type="button" class="btn btn-sm" id="f-ret-lookup"
            style="float:right;padding:1px 6px;font-size:11px" title="按门类和题名在保管期限表里查，自动带出期限与依据">查表</button></span>
          <select name="retention">${optionList(state.meta.retentions, v.retention || '永久')}</select>
          <div class="help" id="f-ret-basis"></div></label>
        <label class="field"><span>密级</span>
          <select name="secret_level">${optionList(state.meta.secretLevels, v.secret_level || '公开')}</select></label>
        <label class="field"><span>载体形式</span>
          <select name="carrier">${optionList(state.meta.carriers, v.carrier || '纸质')}</select></label>
        <label class="field"><span>案卷号</span><input type="text" name="volume_no" value="${esc(v.volume_no || '')}"></label>
        <label class="field"><span>件号</span><input type="text" name="item_no" value="${esc(v.item_no || '')}"></label>
        <label class="field"><span>页数</span><input type="text" name="pages" value="${esc(v.pages || '')}"></label>
        <label class="field"><span>份数</span><input type="number" name="copies" min="1" value="${esc(v.copies || 1)}"></label>
        <label class="field"><span>责任者</span><input type="text" name="responsible" value="${esc(v.responsible || '')}" placeholder="形成文件的单位或个人"></label>
        <label class="field"><span>所属部门</span><input type="text" name="department" value="${esc(v.department || '')}"></label>
        <label class="field"><span>存放位置</span><input type="text" name="location" value="${esc(v.location || '')}" placeholder="如：档案室 A 柜 3 层"></label>
        <label class="field"><span>全宗号</span><input type="text" name="unit_code" value="${esc(v.unit_code || (state.settings && state.settings['archive.unit_code']) || '')}" placeholder="如 Z001"></label>
        <label class="field"><span>分类号</span><input type="text" name="category_code" value="${esc(v.category_code || '')}" placeholder="选分类后自动带出"></label>
        <label class="field"><span>目录号</span><input type="text" name="catalog_no" value="${esc(v.catalog_no || (state.settings && state.settings['archive.catalog_no']) || '01')}"></label>
        <label class="field"><span>开放状态</span>
          <select name="open_state">${optionList(['未鉴定', '开放', '控制使用', '暂不开放'], v.open_state || '未鉴定')}</select></label>
        <label class="field"><span>状态</span>
          <select name="status">${optionList(state.meta.statuses, v.status || '在库')}</select></label>
        <label class="field span-2"><span>关键词（多个用空格或顿号分隔，便于检索）</span>
          <input type="text" name="keywords" value="${esc(v.keywords || '')}"></label>
        <label class="field span-2"><span>摘要 / 内容提要</span>
          <textarea name="abstract" rows="3">${esc(v.abstract || '')}</textarea></label>
        <label class="field span-2"><span>状态备注（如待整理原因、销毁审批情况）</span>
          <input type="text" name="status_note" value="${esc(v.status_note || '')}"></label>
        <div class="span-2" id="extra-fields"></div>
        ${isEdit ? '' : `<div class="span-2">
          <div class="section-title">电子附件（可稍后上传）</div>
          <div class="dropzone" id="create-drop">点击选择或拖拽文件到此处（可多选，单文件最大 512MB）</div>
          <input type="file" id="create-file-input" multiple class="hidden">
          <div class="upload-list" id="create-file-list"></div>
        </div>`}
      </form>
    `;
  }

  function renderExtraFields(container, typeCode, values) {
    const t = state.types.find((x) => x.code === typeCode);
    const fields = (t && t.fields) || [];
    const vals = values || {};
    if (!fields.length) { container.innerHTML = '<div class="muted" style="font-size:12.5px">该门类未定义扩展字段</div>'; return; }
    container.innerHTML = `<div class="section-title">${esc(t.name)} 专用著录项</div>
      <div class="form-grid" style="gap:12px 16px">` + fields.map((f) => {
      const val = esc(vals[f.key] || '');
      let input;
      if (f.type === 'textarea') input = `<textarea name="extra_${esc(f.key)}" rows="2">${val}</textarea>`;
      else if (f.type === 'select') input = `<select name="extra_${esc(f.key)}">${optionList(f.options || [], vals[f.key] || '', '（未选）')}</select>`;
      else input = `<input type="${f.type === 'date' ? 'date' : (f.type === 'number' ? 'number' : 'text')}" name="extra_${esc(f.key)}" value="${val}">`;
      return `<label class="field"><span>${esc(f.label)}</span>${input}</label>`;
    }).join('') + '</div>';
  }

  function collectArchiveForm(form) {
    const data = {};
    new FormData(form).forEach((v, k) => { data[k] = v; });
    const extra = {};
    state.types.forEach((t) => t.fields.forEach((f) => {
      if (data['extra_' + f.key] !== undefined) extra[f.key] = data['extra_' + f.key];
    }));
    data.extra = extra;
    return data;
  }

  async function openArchiveForm(existing) {
    if (!state.types.length) { state.types = (await api('/api/types')).list; state.meta = await api('/api/types'); }
    const body = el('div', {}, archiveFormHtml(existing));
    const foot = [btn('取消', '', () => modal.close())];
    const saveBtn = btn(existing ? '保存修改' : '保存并归档', 'btn-primary');
    foot.push(saveBtn);
    modal.open(existing ? '编辑档案' : '档案著录', body, foot, { wide: true });

    const typeSel = body.querySelector('#f-type');
    const extraBox = body.querySelector('#extra-fields');
    const form = body.querySelector('#archive-form');
    const catSel = form.querySelector('[name=category_id]');
    // 换门类时重建分类下拉：只列这个门类的属类（v4.30.6，A 方案）
    const syncCats = () => {
      const keep = catSel.value;
      catSel.innerHTML = categoryOptionsForType(typeSel.value, keep);
      const opts = Array.from(catSel.options).filter((o) => o.value);
      if (!catSel.value && opts.length === 1) catSel.value = opts[0].value;
    };
    const syncExtra = () => {
      renderExtraFields(extraBox, typeSel.value, existing && existing.type_code === typeSel.value ? (existing.extra || {}) : {});
      syncCats();
      syncProcFields(form);
    };
    typeSel.onchange = syncExtra;
    syncExtra();
    // 保管期限「查表」（v4.32.0）：按当前门类 + 题名去保管期限表里找，带出期限与依据。
    // 不自动改用户已选的期限，只做"建议 + 依据"，最后拍板仍是著录人。
    const retBtn = form.querySelector('#f-ret-lookup');
    if (retBtn) retBtn.onclick = async () => {
      const title = String((form.querySelector('[name=title]') || {}).value || '').trim();
      const sel = form.querySelector('[name=retention]');
      const basisBox = form.querySelector('#f-ret-basis');
      try {
        const d = await api('/api/retention/suggest?type_code=' + encodeURIComponent(typeSel.value)
          + '&kw=' + encodeURIComponent(title.slice(0, 30)));
        const s = d.suggested;
        if (!s) { if (basisBox) basisBox.textContent = '保管期限表里没有匹配的事项，按本单位归档范围自行判定。'; return; }
        if (Array.from(sel.options).some((o) => o.value === s.retention)) sel.value = s.retention;
        if (basisBox) basisBox.innerHTML = `查表：<b>${esc(s.item)}</b> → ${esc(s.retention)}${s.basis ? `（依据：${esc(s.basis)}）` : ''}`;
      } catch (e) { toast('查表失败：' + e.message, 'err'); }
    };
    // 编辑弹窗里同样可以直接新增门类（v4.30.3）
    const addTypeBtnModal = body.querySelector('#btn-add-type');
    if (addTypeBtnModal) addTypeBtnModal.onclick = () => typeAddDialog((code) => {
      const keep = code || typeSel.value;
      typeSel.innerHTML = typeOptions(keep);
      if (keep) typeSel.value = keep;
      syncExtra();
    });

    // 过程接收下拉（v4.29.0）：项目 → 批次联动。
    // 加载失败不影响著录（本来就可以不挂项目/批次），所以整段用 try 包住、静默退化。
    (async () => {
      const projSel = body.querySelector('#f-project');
      const batchSel = body.querySelector('#f-batch');
      if (!projSel || !batchSel) return;
      let projects = [];
      let batches = [];
      try {
        projects = ((await api('/api/projects')).list || []);
        batches = ((await api('/api/batches?limit=200')).list || []);
      } catch (_) { return; }
      const curP = existing && existing.project_id ? String(existing.project_id) : '';
      const curB = existing && existing.batch_id ? String(existing.batch_id) : '';
      projSel.innerHTML = '<option value="">（不挂项目）</option>' + projects.map((p) =>
        `<option value="${p.id}"${String(p.id) === curP ? ' selected' : ''}>${esc(p.project_no)} ${esc(p.name)}</option>`).join('');
      const fillBatches = () => {
        const pid = projSel.value;
        const list = pid ? batches.filter((b) => String(b.project_id) === String(pid)) : batches;
        const keep = batchSel.value;
        batchSel.innerHTML = '<option value="">（不挂批次）</option>' + list.map((b) =>
          `<option value="${b.id}">${esc(b.received_at)} ${esc(b.title || b.batch_no)}</option>`).join('');
        if (curB && list.some((b) => String(b.id) === curB)) batchSel.value = curB;
        else if (keep && list.some((b) => String(b.id) === keep)) batchSel.value = keep;
      };
      projSel.onchange = () => { fillBatches(); syncProcFields(form); };
      fillBatches();
      syncProcFields(form);
    })();

    body.querySelector('#btn-gen-code').onclick = async () => {
      const year = form.querySelector('[name=year]').value || new Date().getFullYear();
      const cat = form.querySelector('[name=category_id]').value;
      const proj = form.querySelector('[name=project_id]').value;
      const d = await api(`/api/archives/next-number?type=${encodeURIComponent(typeSel.value)}&year=${encodeURIComponent(year)}&category=${encodeURIComponent(cat)}&project_id=${encodeURIComponent(proj)}`);
      form.querySelector('#f-code').value = d.archive_code;
      const numEl = form.querySelector('#f-number');
      if (numEl && !numEl.value) numEl.value = d.archive_number;
      toast('已生成档案号 ' + d.archive_code, 'ok');
    };
    const genNumberBtn = body.querySelector('#btn-gen-number');
    if (genNumberBtn) genNumberBtn.onclick = async () => {
      const year = form.querySelector('[name=year]').value || new Date().getFullYear();
      const cat = form.querySelector('[name=category_id]').value;
      const proj = form.querySelector('[name=project_id]').value;
      const d = await api(`/api/archives/next-number?type=${encodeURIComponent(typeSel.value)}&year=${encodeURIComponent(year)}&category=${encodeURIComponent(cat)}&project_id=${encodeURIComponent(proj)}`);
      form.querySelector('#f-number').value = d.archive_number;
      const codeEl = form.querySelector('#f-code');
      if (codeEl && !codeEl.value) codeEl.value = d.archive_code;
      toast('已生成档号 ' + d.archive_number, 'ok');
    };
    // 切换分类时自动带出分类号
    const syncCategoryCode = () => {
      const opt = catSel.options[catSel.selectedIndex];
      const codeEl = form.querySelector('[name=category_code]');
      if (!codeEl || !opt) return;
      const code = state.catFlat.find((c) => String(c.id) === String(opt.value));
      if (code) codeEl.value = code.code;
    };
    catSel.addEventListener('change', async () => {
      // 门类还没有分类根时就地建根（v4.30.6）
      if (catSel.value === '__mkroot__') {
        const id = await ensureCategoryRoot(typeSel.value);
        catSel.innerHTML = categoryOptionsForType(typeSel.value, id);
        if (id) catSel.value = String(id);
        toast('已为该门类建立分类', 'ok');
      }
      syncCategoryCode();
    });

    let pickedFiles = [];
    const drop = body.querySelector('#create-drop');
    if (drop) {
      const input = body.querySelector('#create-file-input');
      const list = body.querySelector('#create-file-list');
      const renderList = () => {
        list.innerHTML = pickedFiles.map((f, i) =>
          `<div class="row"><span class="mono">${esc(f.name)}</span><span class="muted">${fmtSize(f.size)}</span>
           <button class="btn btn-sm" type="button" data-rm="${i}">移除</button></div>`).join('');
        list.querySelectorAll('[data-rm]').forEach((b) => {
          b.onclick = () => { pickedFiles.splice(Number(b.dataset.rm), 1); renderList(); };
        });
      };
      const add = (fl) => { for (const f of fl) pickedFiles.push(f); renderList(); };
      drop.onclick = () => input.click();
      input.onchange = () => { add(input.files); input.value = ''; };
      ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
      ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
      drop.addEventListener('drop', (e) => { if (e.dataTransfer && e.dataTransfer.files.length) add(e.dataTransfer.files); });
    }

    saveBtn.onclick = async () => {
      const data = collectArchiveForm(form);
      if (!data.title || !data.title.trim()) return toast('请填写题名', 'warn');
      if (!data.category_id) return toast('请选择档案分类', 'warn');
      saveBtn.disabled = true;
      try {
        let id;
        if (existing) {
          await api('/api/archives/' + existing.id, { method: 'PUT', body: data });
          id = existing.id;
          toast('已保存修改', 'ok');
        } else {
          const r = await api('/api/archives', { method: 'POST', body: data });
          id = r.id;
          toast('已归档：' + r.archive_code, 'ok');
        }
        if (pickedFiles.length) {
          const fd = new FormData();
          fd.append('kind', '正文');
          for (const f of pickedFiles) fd.append('files', f, f.name);
          await uploadWithProgress(`/api/archives/${id}/files`, fd);
        }
        modal.close();
        state.archiveQuery = {};
        setView('archives');
      } catch (e) {
        toast(e.message, 'err');
        saveBtn.disabled = false;
      }
    };
  }

  async function renderCreate(params) {
    // ------------------------------------------------------------------
    // 沿用只在**明确要求**时生效（v4.13.0）
    //
    // 只有点过「保存并录下一条」才会带着 `carry:1` 回到本页；从左侧菜单点
    // 「档案著录」、或从别的页面切回来，一律**干净开始**。
    //
    // 为什么这条保证必须严格：带着上一次的公共信息录新的一条，是"录错档案"
    // 最常见也最难发现的原因 —— 门类或保管期限录错，连档号都是错的，
    // 而且当时看不出来（界面上看着一切正常）。所以宁可让批量录的人多点一次
    // 「保存并录下一条」，也不让任何人"不知不觉"地继承上一次的值。
    // ------------------------------------------------------------------
    const wantCarry = !!(params && params.carry);
    if (!wantCarry) { carryOver = null; batchCount = 0; }

    if (!state.types.length) {
      const t = await api('/api/types');
      state.types = t.list;
      state.meta = t;
    }
    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>档案著录</h3>
          <span class="sub">按门类填写著录项，档案号可留空自动生成；保存后可直接上传电子附件</span></div>
        <div class="hint-box">提示：文书档案建议在「责任者」填写发文单位、在「专用著录项」填写发文字号与成文日期；合同档案填写合同双方与金额，便于日后按金额或对方名称检索。</div>
        <div id="carry-strip" style="display:none"></div>
        <div id="form-host"></div>
      </div>`;
    const host = $('#form-host');
    host.appendChild(el('div', {}, archiveFormHtml(null)));
    const form = host.querySelector('#archive-form');
    const typeSel = host.querySelector('#f-type');
    const extraBox = host.querySelector('#extra-fields');
    const catSel2 = form.querySelector('[name=category_id]');
    // 门类一换，分类下拉跟着只列这个门类的属类，并顺手带出分类号（v4.30.6）
    const syncCats = () => {
      const keep = catSel2.value;
      catSel2.innerHTML = categoryOptionsForType(typeSel.value, keep);
      const opts = Array.from(catSel2.options).filter((o) => o.value);
      if (!catSel2.value && opts.length === 1) catSel2.value = opts[0].value;
      const c = state.catFlat.find((x) => String(x.id) === String(catSel2.value));
      const codeEl = form.querySelector('[name=category_code]');
      if (codeEl) codeEl.value = c ? c.code : '';
    };
    // ------------------------------------------------------------------
    // 项目下拉（v4.30.7）
    //
    // 以前只有编辑弹窗里才填这个下拉，著录页里它永远只有「（不挂项目）」
    // —— 项目一多就根本挂不上。而「按项目整理」的门类（工程、养护）**必须**
    // 挂项目：项目号要写进档号，件号在项目内连续编号。
    // ------------------------------------------------------------------
    const projSel2 = form.querySelector('#f-project');
    let projList = [];
    const typeMode = () => {
      const t = state.types.find((x) => String(x.code) === String(typeSel.value));
      return t && String(t.filing_mode) === 'project' ? 'project' : 'year';
    };
    const syncProject = () => {
      const need = typeMode() === 'project';
      const labSpan = projSel2.parentNode ? projSel2.parentNode.querySelector('span') : null;
      if (labSpan) {
        labSpan.innerHTML = need
          ? '所属项目<b class="req">*</b><span class="help" style="display:block;font-weight:400">本门类按项目整理：档号里的目录号位换成项目号，件号在项目内连续，必须选项目</span>'
          : '所属项目（过程资料）';
      }
      projSel2.dataset.required = need ? '1' : '';
      const keep = projSel2.value;
      projSel2.innerHTML = (need ? '<option value="">请选择项目</option>' : '<option value="">（不挂项目）</option>')
        + projList.map((p) => `<option value="${p.id}">${esc(p.project_no)} ${esc(p.name)}</option>`).join('');
      if (keep && Array.from(projSel2.options).some((o) => o.value === keep)) projSel2.value = keep;
      syncProcFields(form);
    };
    (async () => {
      try { projList = ((await api('/api/projects')).list || []); } catch (_) { projList = []; }
      syncProject();
    })();
    const sync = () => { renderExtraFields(extraBox, typeSel.value, {}); syncCats(); syncProject(); };
    typeSel.onchange = sync; sync();
    // 著录页直接新增门类：加完把新门类选上，并重建专用著录项
    const addTypeBtn = host.querySelector('#btn-add-type');
    if (addTypeBtn) addTypeBtn.onclick = () => typeAddDialog((code) => {
      const keep = code || typeSel.value;
      typeSel.innerHTML = typeOptions(keep);
      if (keep) typeSel.value = keep;
      sync();
    });
    host.querySelector('#btn-gen-code').onclick = async () => {
      const year = form.querySelector('[name=year]').value || new Date().getFullYear();
      const cat = form.querySelector('[name=category_id]').value;
      const proj = form.querySelector('[name=project_id]').value;
      const d = await api(`/api/archives/next-number?type=${encodeURIComponent(typeSel.value)}&year=${encodeURIComponent(year)}&category=${encodeURIComponent(cat)}&project_id=${encodeURIComponent(proj)}`);
      form.querySelector('#f-code').value = d.archive_code;
      const numEl = form.querySelector('#f-number');
      if (numEl && !numEl.value) numEl.value = d.archive_number;
    };
    const genNumBtn = host.querySelector('#btn-gen-number');
    if (genNumBtn) genNumBtn.onclick = async () => {
      const year = form.querySelector('[name=year]').value || new Date().getFullYear();
      const cat = form.querySelector('[name=category_id]').value;
      const proj = form.querySelector('[name=project_id]').value;
      const d = await api(`/api/archives/next-number?type=${encodeURIComponent(typeSel.value)}&year=${encodeURIComponent(year)}&category=${encodeURIComponent(cat)}&project_id=${encodeURIComponent(proj)}`);
      form.querySelector('#f-number').value = d.archive_number;
      const codeEl = form.querySelector('#f-code');
      if (codeEl && !codeEl.value) codeEl.value = d.archive_code;
    };
    catSel2.addEventListener('change', async () => {
      // 门类还没有分类根时，这一项就地建根（v4.30.6），免得卡在空下拉
      if (catSel2.value === '__mkroot__') {
        const id = await ensureCategoryRoot(typeSel.value);
        catSel2.innerHTML = categoryOptionsForType(typeSel.value, id);
        if (id) catSel2.value = String(id);
        toast('已为该门类建立分类', 'ok');
      }
      const c = state.catFlat.find((x) => String(x.id) === String(catSel2.value));
      const el2 = form.querySelector('[name=category_code]');
      if (el2) el2.value = c ? c.code : '';
    });
    // ------------------------------------------------------------------
    // 连续著录（v4.13.0）
    //
    // 实际工作里"一批一批录"（30 份同年度文书档案）和"东一条西一条"都有，
    // 所以**不做模式开关**，改成两个保存按钮：
    //   保存并归档     → 存完打开详情（录完这条要看看结果）
    //   保存并录下一条 → 存完留在本页、带出公共信息、计数 +1（批量录）
    //
    // 关键：**没点过"下一条"就直接进本页时，一条都不会被带过来** ——
    // "东一条西一条"的场景天然不会带错值，不需要用户先选模式。
    // ------------------------------------------------------------------
    /** 会被沿用的字段：同批几乎不变的那些 */
    const CARRY_FIELDS = ['type_code', 'category_id', 'year', 'archive_date', 'retention',
      'secret_level', 'responsible', 'department', 'carrier'];
    /** 绝不沿用的字段：题名放第一位（带过来忘改就会录出两条同题名） */
    const NEVER_CARRY = ['title', 'abstract', 'keywords', 'volume_no', 'item_no', 'pages', 'copies', 'location'];

    const applyCarry = () => {
      const strip = host.querySelector('#carry-strip');
      if (!strip) return;
      if (!carryOver) { strip.innerHTML = ''; strip.style.display = 'none'; return; }
      strip.style.display = '';
      for (const f of CARRY_FIELDS) {
        const node = form.querySelector(`[name="${f}"]`);
        if (!node) continue;
        const v = carryOver.values[f];
        if (v === undefined || v === '') continue;
        node.value = v;
        node.classList.add('carried');          // 浅底 + 左侧竖条，和手填的值区分开
        if (f === 'secret_level') node.classList.add('carried-secret');  // 密级单独再醒目一点
      }
      // 门类的专用著录项要跟着门类重建（沿用门类时必须同步）
      sync();
      const bits = [
        carryOver.summary.type, carryOver.summary.year, carryOver.summary.retention,
        carryOver.summary.department,
      ].filter(Boolean);
      strip.innerHTML = `
        <div class="carry-strip">
          <span class="tag tag-blue">连续著录</span>
          <span>本批已录 <b>${batchCount}</b> 条</span>
          <span class="muted">沿用：${esc(bits.join(' · ') || '（无）')}</span>
          <span class="help" style="margin:0">浅底字段是沿用来的 —— <b>题名等每条不同的字段不会被沿用</b></span>
          <button class="btn btn-sm" id="btn-carry-clear">清空沿用</button>
          <button class="btn btn-sm" id="btn-batch-end">结束本批</button>
        </div>`;
      const clearBtn = strip.querySelector('#btn-carry-clear');
      if (clearBtn) clearBtn.onclick = () => { carryOver = null; setView('create'); };
      const endBtn = strip.querySelector('#btn-batch-end');
      if (endBtn) {
        endBtn.onclick = () => {
          const n = batchCount;
          carryOver = null; batchCount = 0;
          toast(n ? `本批共录 ${n} 条，已结束` : '已结束本批', 'ok');
          setView('create');
        };
      }
    };
    applyCarry();

    let picked = [];
    const drop = host.querySelector('#create-drop');
    const input = host.querySelector('#create-file-input');
    const list = host.querySelector('#create-file-list');
    /**
     * 待上传附件的**本地预览**（v4.26.0）。
     *
     * 诉求来自使用者的截图反馈：「希望这里可以加一个预览功能，或者点击能打开这个电子文档，
     * 可以复制上面的文字」—— 传之前先看一眼，能避免"传错文件"这种事后很难发现的问题。
     *
     * 做法上**不绕服务端**：直接 `URL.createObjectURL(file)` 看本地选中的那一份。
     * 它本来就只是"待上传列表"，还没提交；预览没有理由先把它传上去 ——
     * 既快，也不会在服务器上留下任何东西。看完记得 revoke，否则内存里的那份一直挂着。
     */
    const previewLocal = async (f) => {
      const url = URL.createObjectURL(f);
      const body = el('div', {}, '');
      if (/\.(png|jpe?g|gif|webp|bmp)$/i.test(f.name)) {
        body.appendChild(el('img', { src: url, style: 'max-width:100%;max-height:70vh;display:block;margin:0 auto' }));
      } else if (/\.pdf$/i.test(f.name)) {
        body.appendChild(el('iframe', { src: url, style: 'width:100%;height:70vh;border:0' }));
      } else if (/\.(txt|csv|md|log)$/i.test(f.name)) {
        const pre = el('pre', { style: 'white-space:pre-wrap;word-break:break-all;max-height:70vh;overflow:auto;margin:0;font-size:12px' });
        pre.textContent = '正在读取…';
        body.appendChild(pre);
        f.text().then((t) => { pre.textContent = t.slice(0, 20000); })
          .catch(() => { pre.textContent = '（这份文件读不出内容）'; });
      } else {
        // Office（xlsx / docx / 旧版 xls / doc）浏览器渲染不了，但**服务端的提取器能**（v4.26.4）。
        // 做法上只调一个"只提取、不落盘"的接口：不写 files、不写 file_text、不建任何记录。
        // 所以下面那句"预览不会在服务器上留下任何东西"**仍然成立** —— 这一点不能含糊。
        const tip = el('div', { class: 'help' },
          '正在提取正文…（Office 文档浏览器不能直接渲染，这里显示的是系统提取出来的文字）');
        const pre = el('pre', { style: 'display:none;white-space:pre-wrap;word-break:break-all;max-height:60vh;overflow:auto;margin:8px 0 0;font-size:13px' });
        body.appendChild(tip);
        body.appendChild(pre);
        try {
          const fd = new FormData();
          fd.append('file', f, f.name);
          const res = await fetch('/api/preview-extract', { method: 'POST', body: fd, credentials: 'same-origin' });
          const j = await res.json().catch(() => null);
          const d = j && j.data ? j.data : null;
          if (d && d.ok && d.text) {
            tip.textContent = `${d.kind || '文档'} · 已提取正文 ${d.chars} 字`
              + '（这里只有文字；完整排版、公式和图片请上传后下载用本地软件打开）';
            pre.textContent = d.text;
            pre.style.display = 'block';
          } else {
            tip.textContent = (d && d.note) || '这份文件的正文没能提取出来，可上传后用本地软件打开。';
          }
        } catch (e) {
          tip.textContent = '提取失败：' + ((e && e.message) || '网络异常');
        } finally {
          // 这条分支**从头到尾没用过**上面那个 objectURL（走的是服务端提取回来的文字），
          // 所以立刻释放：否则每预览一次就有一份文件内容挂在内存里，
          // 直到关掉弹窗才由 Close 里的 revoke 收掉 —— 反复预览几个 Excel 就一直涨。
          // 这里先释放、Close 里再释放一次都是安全的（重复 revoke 是无操作）。
          URL.revokeObjectURL(url);
        }
      }
      body.appendChild(el('div', { class: 'help', style: 'margin-top:8px' },
        '这是你本地选中的文件，还没有上传；预览不会在服务器上留下任何东西。'));
      modal.open('预览：' + f.name, body, [btn('关闭', '', () => {
        modal.close();
        URL.revokeObjectURL(url);
      })], { wide: true });
    };

    const renderList = () => {
      // 文件名单等宽 + 可选中（能选中就能复制）；点击名字或「预览」按钮都能预览，
      // 但**正在选文字准备复制时不要弹预览** —— 否则想复制名字的人每次都被弹窗打断。
      list.innerHTML = picked.map((f, i) => `<div class="row">
        <span class="mono" data-pv="${i}" title="点击预览这份文件（也可以选中文件名复制）"
              style="cursor:pointer;user-select:text;-webkit-user-select:text">${esc(f.name)}</span>
        <span class="muted">${fmtSize(f.size)}</span>
        <button class="btn btn-sm" type="button" data-pv="${i}">预览</button>
        <button class="btn btn-sm" type="button" data-rm="${i}">移除</button></div>`).join('');
      list.querySelectorAll('[data-rm]').forEach((b) => {
        b.onclick = () => { picked.splice(Number(b.dataset.rm), 1); renderList(); };
      });
      list.querySelectorAll('[data-pv]').forEach((b) => {
        b.onclick = () => {
          const sel = (window.getSelection && String(window.getSelection())) || '';
          if (sel) return;   // 正在选字复制，别打断
          previewLocal(picked[Number(b.dataset.pv)]);
        };
      });
    };
    const add = (fl) => { for (const f of fl) picked.push(f); renderList(); };
    drop.onclick = () => input.click();
    input.onchange = () => { add(input.files); input.value = ''; };
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => { if (e.dataTransfer && e.dataTransfer.files.length) add(e.dataTransfer.files); });

    const actions = el('div', { class: 'form-actions' }, '');

    /** 抽出保存逻辑，供「保存并归档」与「保存并录下一条」共用（口径只写一遍） */
    const doSave = async (next) => {
      const data = collectArchiveForm(form);
      if (!data.title || !data.title.trim()) return toast('请填写题名', 'warn');
      if (!data.category_id) return toast('请选择档案分类', 'warn');
      // 按项目整理的门类没选项目 → 当场拦住。否则档号里的项目号会是空的，
      // 等移交或上级检查才发现，那时已经编了一堆号（v4.30.7）。
      if (typeMode() === 'project' && !data.project_id) {
        return toast('该门类按「项目」整理，请先选择所属项目（项目号会写进档号）', 'warn');
      }
      // 兜底：题名与上一条一字不差 → 大概率是沿用公共信息时忘了改题名。
      // 这是"带错值/忘改"的最后一道网，成本很低但很有效。
      if (next && carryOver && carryOver.lastTitle && data.title.trim() === carryOver.lastTitle) {
        return confirmDialog('题名和上一条完全相同',
          `上一条的题名就是「${data.title.trim()}」。<br>连续著录时题名<b>不会</b>自动沿用，`
          + '所以这多半是忘了改。<br>确定这是两条不同的档案、确实同名吗？',
        async () => { await finishSave(data, next); }, '确认同名，继续保存');
      }
      return finishSave(data, next);
    };

    const finishSave = async (data, next) => {
      const b = actions.querySelector('#btn-save-next') || actions.querySelector('#btn-save-one');
      if (b) b.disabled = true;
      try {
        const r = await api('/api/archives', { method: 'POST', body: data });
        if (picked.length) {
          const fd = new FormData();
          fd.append('kind', '正文');
          for (const f of picked) fd.append('files', f, f.name);
          await uploadWithProgress(`/api/archives/${r.id}/files`, fd);
        }
        if (!next) {
          toast('已归档：' + r.archive_code, 'ok');
          openArchiveDetail(r.id);
          return;
        }
        batchCount++;
        // 记下这一条的公共信息，供下一条沿用。**题名只用来做重名校验，绝不回填。**
        const summary = {};
        const t = state.types.find((x) => x.code === data.type_code);
        summary.type = t ? t.name : (data.type_code || '');
        summary.year = data.year || '';
        summary.retention = data.retention || '';
        summary.department = data.department || '';
        const values = {};
        for (const f of CARRY_FIELDS) values[f] = data[f] === undefined ? '' : String(data[f]);
        carryOver = { values, summary, lastTitle: data.title.trim() };
        toast(`已归档 ${r.archive_code}　本批第 ${batchCount} 条`, 'ok', 4000);
        // 必须显式带 carry:1 —— 沿用只在这条路径上发生（见 renderCreate 顶部注释）
        setView('create', { carry: 1 });
      } catch (e) {
        toast(e.message, 'err');
        if (b) b.disabled = false;
      }
    };

    const saveOne = btn('保存并归档', 'btn-primary');
    saveOne.id = 'btn-save-one';
    saveOne.onclick = () => doSave(false);
    actions.appendChild(saveOne);
    const saveNext = btn('保存并录下一条', carryOver ? 'btn-primary' : '');
    saveNext.id = 'btn-save-next';
    saveNext.title = '存完留在本页，并把门类/年度/保管期限/责任者等公共信息带到下一条（题名不会带）';
    saveNext.onclick = () => doSave(true);
    actions.appendChild(saveNext);
    actions.appendChild(btn('清空重填', '', () => setView('create')));
    actions.appendChild(btn('查看档案列表', '', () => setView('archives')));
    host.appendChild(actions);
  }

  // ---------------- 借阅 ----------------
  function loanStatusTag(s) {
    const cls = { '待审批': 'tag-blue', '已批准': 'tag-amber', '已拒绝': 'tag-gray', '已归还': 'tag-green', '逾期': 'tag-red' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s)}</span>`;
  }

  async function renderLoans(params) {
    const status = (params && params.status) || '';
    const p = new URLSearchParams();
    if (status) p.set('status', status);
    if (params && params.mine) p.set('mine', '1');
    const data = await api('/api/loans?' + p.toString());
    const canApprove = state.user.role !== 'reader';

    const rows = data.list.map((l) => `
      <tr data-loan="${l.id}">
        <td class="code">${esc(l.loan_no)}</td>
        <td><div style="font-weight:500">${esc(l.archive_title || '')}</div>
            <div class="muted" style="font-size:12px">${esc(l.archive_code || '')}</div></td>
        <td class="nowrap">${esc(l.user_name || '')}<div class="muted" style="font-size:12px">${esc(l.user_department || '')}</div></td>
        <td class="nowrap">${esc(l.mode)}</td>
        <td>${esc(l.purpose || '')}</td>
        <td class="nowrap">${loanStatusTag(l.status)}</td>
        <td class="nowrap">${l.status === '已归还' ? esc(fmtDay(l.return_at)) : esc(l.due_date || '')}</td>
        <td class="nowrap">
          ${canApprove && l.status === '待审批' ? `<button class="btn btn-sm btn-primary" data-act="approve">批准</button>
            <button class="btn btn-sm" data-act="reject">拒绝</button>` : ''}
          ${canApprove && (l.status === '已批准' || l.status === '逾期') ? '<button class="btn btn-sm btn-primary" data-act="return">归还</button>' : ''}
          ${canApprove && (l.status === '待审批' || l.status === '已拒绝') ? '<button class="btn btn-sm btn-danger" data-act="del">删除</button>' : ''}
          ${state.user.role === 'reader' && l.user_id === state.user.id ? '<button class="btn btn-sm" data-act="view">查看档案</button>' : ''}
        </td>
      </tr>`).join('') || `<tr><td colspan="8" class="empty"><b>暂无借阅记录</b>在档案详情里点「借阅申请」即可发起</td></tr>`;

    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>借阅管理</h3>
          <div class="flex">
            <button class="btn btn-sm" data-tab="">全部</button>
            <button class="btn btn-sm${status === '待审批' ? ' btn-primary' : ''}" data-tab="待审批">待审批 ${data.counts.pending}</button>
            <button class="btn btn-sm${status === '已批准' ? ' btn-primary' : ''}" data-tab="已批准">在借 ${data.counts.active}</button>
            <button class="btn btn-sm${status === '逾期' ? ' btn-primary' : ''}" data-tab="逾期">逾期 ${data.counts.overdue}</button>
            <button class="btn btn-sm${status === '已归还' ? ' btn-primary' : ''}" data-tab="已归还">已归还</button>
            <button class="btn btn-sm${params && params.mine ? ' btn-primary' : ''}" data-mine="1">我的申请</button>
          </div>
        </div>
        <div class="table-wrap"><table>
          <thead><tr><th>借阅单号</th><th>档案</th><th>借阅人</th><th>方式</th><th>用途</th><th>状态</th><th>应还/归还</th><th>操作</th></tr></thead>
          <tbody>${rows}</tbody></table></div>
        ${pagerHtml(data, 'loan')}
      </div>`;

    $$('#content [data-tab]').forEach((b) => {
      b.onclick = () => setView('loans', b.dataset.tab ? { status: b.dataset.tab } : {});
    });
    const mine = $('#content [data-mine]');
    if (mine) mine.onclick = () => setView('loans', { mine: true });

    $$('#content tr[data-loan]').forEach((tr) => {
      const id = Number(tr.dataset.loan);
      const rec = data.list.find((x) => x.id === id);
      tr.querySelectorAll('[data-act]').forEach((b) => {
        b.onclick = async () => {
          const act = b.dataset.act;
          try {
            if (act === 'approve') {
              promptDialog('批准借阅', [
                { name: 'due_date', label: '应还日期', type: 'date', value: rec.due_date || '', required: true },
                { name: 'note', label: '审批意见', placeholder: '可选' },
              ], async (d) => {
                await api(`/api/loans/${id}/approve`, { method: 'POST', body: { approve: true, due_date: d.due_date, note: d.note } });
                toast('已批准', 'ok'); setView('loans', params || {});
              });
            } else if (act === 'reject') {
              promptDialog('拒绝借阅', [{ name: 'note', label: '拒绝理由', type: 'textarea', required: true }],
                async (d) => {
                  await api(`/api/loans/${id}/approve`, { method: 'POST', body: { approve: false, note: d.note } });
                  toast('已拒绝', 'ok'); setView('loans', params || {});
                });
            } else if (act === 'return') {
              promptDialog('办理归还', [{ name: 'note', label: '归还备注', placeholder: '如：完好无损' }],
                async (d) => {
                  await api(`/api/loans/${id}/return`, { method: 'POST', body: { note: d.note } });
                  toast('已办理归还', 'ok'); setView('loans', params || {});
                });
            } else if (act === 'del') {
              confirmDialog('删除借阅记录', '确定删除该借阅申请吗？', async () => {
                await api('/api/loans/' + id, { method: 'DELETE' });
                toast('已删除', 'ok'); setView('loans', params || {});
              }, '确认删除');
            } else if (act === 'view') {
              openArchiveDetail(rec.archive_id);
            }
          } catch (e) { toast(e.message, 'err'); }
        };
      });
    });
    bindPager('loan', () => setView('loans', params || {}));
  }

  function loanDialog(a) {
    const already = (a.loans || []).some((l) => l.user_id === state.user.id && ['待审批', '已批准', '逾期'].includes(l.status));
    const body = el('div', {}, `
      <div class="hint-box">档案：<b>${esc(a.archive_code)}</b> ${esc(a.title)}<br>
      当前状态：${a.status}${a.location ? '　存放位置：' + esc(a.location) : ''}</div>
      <label class="field"><span>借阅方式</span>
        <select name="mode">
          <option value="借出">借出原件（占用档案，需归还）</option>
          <option value="查阅">馆内查阅（不外借）</option>
          <option value="复制">复制/复印</option>
        </select></label>
      <label class="field"><span>用途说明<b class="req">*</b></span>
        <textarea name="purpose" rows="3" placeholder="如：办理年度审计需核对合同条款"></textarea></label>
      <label class="field"><span>期望归还日期</span><input type="date" name="due_date" value="${new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10)}"></label>
      ${already ? '<div class="hint-box warn">你已有该档案的未完成借阅申请，不能重复提交。</div>' : ''}
      ${state.user.role === 'reader' ? '<div class="help">你的申请需档案员审批后才能借出。</div>' : '<div class="help">档案员及以上角色登记后立即生效。</div>'}
    `);
    modal.open('借阅申请', body, [
      btn('取消', '', () => modal.close()),
      btn('提交申请', 'btn-primary', async () => {
        const mode = body.querySelector('[name=mode]').value;
        const purpose = body.querySelector('[name=purpose]').value.trim();
        const due = body.querySelector('[name=due_date]').value;
        if (!purpose) return toast('请填写用途说明', 'warn');
        try {
          const r = await api('/api/loans', { method: 'POST', body: { archive_id: a.id, mode, purpose, due_date: due } });
          toast(r.status === '已批准' ? '已登记，可到档案室领取' : '申请已提交，等待审批', 'ok');
          modal.close();
          setView('loans');
        } catch (e) { toast(e.message, 'err'); }
      }),
    ], { narrow: true });
  }

  // ---------------- 日志 ----------------
  async function renderLogs() {
    if (state.user.role === 'reader') {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>操作日志仅档案员及以上角色可查看</div></div>';
      return;
    }
    const q = state.logQuery || {};
    const p = new URLSearchParams(q);
    p.set('page', String(state.logPage || 1));
    p.set('size', '30');
    const data = await api('/api/logs?' + p.toString());
    const rows = data.list.map((l) => `
      <tr><td class="nowrap muted">${fmtTime(l.at)}</td>
      <td class="nowrap">${esc(l.username || '—')}</td>
      <td class="nowrap"><span class="tag tag-blue">${esc(l.action)}</span></td>
      <td class="mono">${esc(l.target || '')}</td>
      <td>${esc(l.detail || '')}</td>
      <td class="nowrap muted">${esc(l.ip || '')}</td></tr>`).join('')
      || '<tr><td colspan="6" class="empty">暂无日志</td></tr>';
    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>操作日志 <span class="sub">共 ${data.total} 条</span></h3></div>
        <form class="filters" id="log-form" onsubmit="return false">
          <label class="field grow"><span>关键词</span><input type="search" name="kw" value="${esc(q.kw || '')}" placeholder="档案号 / 用户名 / 内容"></label>
          <label class="field"><span>操作人</span><input type="text" name="user" value="${esc(q.user || '')}"></label>
          <label class="field"><span>起始日期</span><input type="date" name="from" value="${esc(q.from || '')}"></label>
          <label class="field"><span>截止日期</span><input type="date" name="to" value="${esc(q.to || '')}"></label>
          <button class="btn btn-primary" id="log-search" type="button">查询</button>
          <button class="btn" id="log-reset" type="button">重置</button>
        </form>
      </div>
      <div class="card"><div class="table-wrap"><table>
        <thead><tr><th>时间</th><th>操作人</th><th>操作</th><th>对象</th><th>详情</th><th>IP</th></tr></thead>
        <tbody>${rows}</tbody></table></div>
        ${pagerHtml(data, 'log')}
      </div>`;
    const form = $('#log-form');
    $('#log-search').onclick = () => {
      const o = {};
      new FormData(form).forEach((v, k) => { const s = String(v).trim(); if (s) o[k] = s; });
      state.logQuery = o; state.logPage = 1; setView('logs');
    };
    form.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#log-search').click(); } });
    $('#log-reset').onclick = () => { state.logQuery = {}; state.logPage = 1; setView('logs'); };
    bindPager('log', (p2) => { state.logPage = p2; setView('logs'); });
  }

  // ---------------- 四性检测 ----------------
  // 依据 DA/T 70—2018（三环境×四性）与 DA/T 92—2022 §9.4（归档后每年至少 1 次）
  async function renderDetection() {
    if (state.user.role === 'reader') {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>四性检测仅档案员及以上角色可使用</div></div>';
      return;
    }
    const [st, due, recent] = await Promise.all([
      api('/api/detections/stats'),
      api('/api/detections/due?limit=50'),
      api('/api/detections?size=10'),
    ]);
    const dimCards = (st.dimensions || []).map((d) => {
      const checks = (st.checks || []).filter((c) => c.dimension === d);
      return `<div class="card"><div class="card-head"><h3>${esc(d)} <span class="sub">${checks.length} 项</span></h3></div>
        <div class="muted" style="font-size:12px;line-height:1.9">
          ${checks.map((c) => `· ${esc(c.title)}${c.severity === 'warn' ? '（提示）' : ''}`).join('<br>') || '—'}
        </div></div>`;
    }).join('');
    const envCards = (st.environments || []).map((e) => {
      const n = (st.checks || []).filter((c) => (c.environments || []).includes(e.code)).length;
      return `<div class="stat"><div class="stat-num">${n}</div><div class="stat-label">${esc(e.label)}</div></div>`;
    }).join('');
    const dueRows = (due.list || []).map((x) => `
      <tr><td class="mono">${esc(x.archive_code || '')}</td><td>${esc(x.title || '')}</td>
      <td class="nowrap">${esc(x.year || '')}</td>
      <td class="muted">${esc(x.reason || '')}</td>
      <td class="nowrap"><button class="btn btn-sm" data-detect="${x.id}">执行检测</button></td></tr>`).join('')
      || '<tr><td colspan="5" class="empty">全部档案均在检测周期内 👍</td></tr>';
    const recentRows = (recent.list || []).map((d) => `
      <tr><td class="mono">${esc(d.detection_no)}</td>
      <td class="nowrap">${esc(envLabel(d.environment))}</td>
      <td class="mono">${esc(d.archive_code || '')}</td>
      <td>${d.qualified ? '<span class="tag tag-green">合格</span>' : '<span class="tag tag-red">不合格</span>'}</td>
      <td>${esc(d.conclusion || '')}</td>
      <td class="nowrap muted">${fmtTime(d.created_at)}</td>
      <td class="nowrap"><a class="btn btn-sm" target="_blank" href="/api/detections/${d.id}/print">报告</a></td></tr>`).join('')
      || '<tr><td colspan="7" class="empty">还没有检测记录</td></tr>';
    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>四性检测 <span class="sub">DA/T 70—2018 三环节 × 四性</span></h3></div>
        <div class="hint-box">检测覆盖 <b>归档 / 移交与接收 / 长期保存</b> 三个环节，每个环节查
          <b>真实性、完整性、可用性、安全性</b>。移交提交前要求每件档案都有合格的归档检测记录
          （《电子档案管理办法》第二十一条），上传附件时也会自动跑一次。</div>
        <div class="stat-row">${envCards}
          <div class="stat"><div class="stat-num">${st.detected}</div><div class="stat-label">已检测档案</div></div>
          <div class="stat"><div class="stat-num">${st.coverage}%</div><div class="stat-label">覆盖率</div></div>
          <div class="stat"><div class="stat-num">${st.overdue}</div><div class="stat-label">超期未检测</div></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>待检测清单 <span class="sub">${due.total} 件（${st.yearlyDays} 天周期）</span></h3></div>
        <div class="table-wrap"><table>
          <thead><tr><th>档案号</th><th>题名</th><th>年度</th><th>原因</th><th>操作</th></tr></thead>
          <tbody>${dueRows}</tbody></table></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>最近检测记录</h3></div>
        <div class="table-wrap"><table>
          <thead><tr><th>检测单号</th><th>环节</th><th>档号</th><th>结论</th><th>说明</th><th>时间</th><th></th></tr></thead>
          <tbody>${recentRows}</tbody></table></div>
      </div>
      <div class="grid grid-2">${dimCards}</div>`;
    $$('[data-detect]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true; b.textContent = '检测中…';
        try {
          const r = await api('/api/detections', { method: 'POST', body: { archive_id: Number(b.dataset.detect), environment: 'archive' } });
          const one = (r.results || [])[0] || {};
          toast(one.qualified ? `检测合格：${one.conclusion}` : `检测不合格：${one.conclusion}`);
          setView('detection');
        } catch (e) { b.disabled = false; b.textContent = '执行检测'; toast('检测失败：' + e.message); }
      };
    });
  }

  // ---------------- 合规体检 ----------------
  // 汇总安全（三员/密级/审计链/口令）、备份（三套两介质）、存储（空间/介质/检测周期）
  async function renderCompliance() {
    const safe = (p) => p.then((d) => ({ ok: true, data: d })).catch((e) => ({ ok: false, error: e.message, status: e.status }));
    const [sec, bak, sto] = await Promise.all([
      safe(api('/api/security/status')), safe(api('/api/backup/status')), safe(api('/api/storage/status')),
    ]);
    const block = (title, sub, body) => `<div class="card"><div class="card-head"><h3>${esc(title)} <span class="sub">${esc(sub)}</span></h3></div>${body}</div>`;
    const warnList = (ws) => (ws && ws.length)
      ? `<ul class="warn-list">${ws.map((w) => `<li>${esc(typeof w === 'string' ? w : (w.label + (w.detail ? '：' + w.detail : '')))}</li>`).join('')}</ul>`
      : '<div class="hint-box">未发现问题 👍</div>';

    let secBody;
    if (!sec.ok) {
      secBody = `<div class="empty">${sec.status === 403 ? '当前角色无权查看安全合规状态（需安全保密员/审计员/管理员）' : esc(sec.error)}</div>`;
    } else {
      const d = sec.data;
      const holders = Object.entries(d.holders || {}).map(([k, v]) =>
        `<tr><td>${esc((state.roleNames || {})[k] || k)}</td><td>${esc((v || []).join('、') || '—')}</td></tr>`).join('');
      secBody = `
        <div class="stat-row">
          <div class="stat"><div class="stat-num">${d.staffedCount}/3</div><div class="stat-label">三员配齐</div></div>
          <div class="stat"><div class="stat-num">${d.enforceSecret ? '开' : '关'}</div><div class="stat-label">密级管控</div></div>
          <div class="stat"><div class="stat-num">${d.audit && d.audit.chainIntact ? '完整' : '异常'}</div><div class="stat-label">审计链</div></div>
          <div class="stat"><div class="stat-num">${(d.audit && d.audit.total) || 0}</div><div class="stat-label">日志条数</div></div>
        </div>
        <div class="table-wrap"><table><thead><tr><th>三员角色</th><th>担任账号</th></tr></thead><tbody>${holders}</tbody></table></div>
        ${warnList(d.warnings)}`;
    }

    let bakBody = !bak.ok
      ? `<div class="empty">${bak.status === 403 ? '当前角色无权查看备份合规（需系统管理员/管理员）' : esc(bak.error)}</div>`
      : `<div class="stat-row">
          <div class="stat"><div class="stat-num">${bak.data.counts.usable}/${bak.data.requirement.requiredCopies}</div><div class="stat-label">可用备份套数</div></div>
          <div class="stat"><div class="stat-num">${bak.data.counts.online} / ${bak.data.counts.offline} / ${bak.data.counts.offsite}</div><div class="stat-label">在线 / 离线 / 异地</div></div>
          <div class="stat"><div class="stat-num">${bak.data.counts.mediaTypes.length}/${bak.data.requirement.requiredMediaTypes}</div><div class="stat-label">介质种类</div></div>
          <div class="stat"><div class="stat-num">${bak.data.compliant ? '合规' : '待改进'}</div><div class="stat-label">结论</div></div>
        </div>
        <div class="help">${esc(bak.data.requirement.basis)}</div>
        ${warnList(bak.data.warnings)}`;

    let stoBody = !sto.ok
      ? `<div class="empty">${sto.status === 403 ? '当前角色无权查看存储状况（需系统管理员/管理员）' : esc(sto.error)}</div>`
      : `<div class="stat-row">
          <div class="stat"><div class="stat-num">${sto.data.free_ratio}%</div><div class="stat-label">剩余空间占比</div></div>
          <div class="stat"><div class="stat-num">${(sto.data.free_bytes / 1073741824).toFixed(1)}G</div><div class="stat-label">剩余空间</div></div>
          <div class="stat"><div class="stat-num">${(sto.data.files_bytes / 1048576).toFixed(0)}M</div><div class="stat-label">附件占用</div></div>
          <div class="stat"><div class="stat-num">${sto.data.last_check_days === null ? '—' : sto.data.last_check_days + '天'}</div><div class="stat-label">距上次检测</div></div>
        </div>
        ${sto.data.last_check ? `<div class="hint-box">最近一次检测（${esc(sto.data.last_check.check_no)}）：${esc(sto.data.last_check.conclusion)}</div>` : ''}
        ${warnList(sto.data.alarms)}`;

    $('#content').innerHTML = `
      <div class="card"><div class="card-head"><h3>合规体检 <span class="sub">依据现行标准逐项自查</span></h3></div>
        <div class="hint-box">这一页把几项**必查项**直接算出来：三员是否配齐、密级管控是否开启、审计日志链是否完整、
          备份是否够三套两介质、存储是否充足、保管状况检测是否超期。点各项标题可进入对应页面处理。</div>
      </div>
      ${block('① 安全与三员分立', '档办发〔2017〕3号 第四十一条', secBody)}
      ${block('② 备份合规', '《电子档案管理办法》第二十六条', bakBody)}
      ${block('③ 存储状况监控', '档办发〔2017〕3号 第二十二/二十四条', stoBody)}`;
  }

  function envLabel(code) {
    return { archive: '归档环节', transfer: '移交与接收', preservation: '长期保存' }[code] || code || '';
  }

  // ---------------- 备份与存储 ----------------
  async function renderBackup() {
    if (state.user.role !== 'admin' && state.user.role !== 'sysadmin') {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>备份与存储管理仅系统管理员/管理员可用</div></div>';
      return;
    }
    const [st, bks, media, sst, dr] = await Promise.all([
      api('/api/backup/status'), api('/api/backups'), api('/api/backup/media'), api('/api/storage/status'),
      api('/api/backup/drills?limit=10').catch(() => ({ list: [], last_restore: null })),
    ]);
    const req = st.requirement;
    const bRows = (bks.list || []).map((b) => `
      <tr><td class="mono">${esc(b.backup_no)}</td>
      <td class="nowrap"><span class="tag ${b.target_type === '在线' ? 'tag-blue' : (b.target_type === '异地' ? 'tag-green' : '')}">${esc(b.target_type)}</span></td>
      <td class="mono">${esc(b.medium_no || '—')}</td>
      <td class="nowrap">${(b.size_bytes / 1048576).toFixed(1)} MB</td>
      <td class="nowrap">${b.chain_ok ? '完整' : '<b>异常</b>'}</td>
      <td class="muted nowrap">${esc((b.verify_result || '未校验').slice(0, 24))}</td>
      <td class="nowrap muted">${fmtTime(b.created_at)}</td>
      <td class="nowrap"><button class="btn btn-sm" data-verify="${b.id}">校验</button></td></tr>`).join('')
      || '<tr><td colspan="8" class="empty">还没有备份记录</td></tr>';
    const mRows = (media.list || []).map((m) => `
      <tr><td class="mono">${esc(m.medium_no)}</td><td>${esc(m.type)}</td><td>${esc(m.location)}</td>
      <td>${esc(m.condition)}</td><td>${m.backup_count}</td>
      <td class="nowrap muted">${m.latest_backup_at ? fmtTime(m.latest_backup_at) : '—'}</td></tr>`).join('')
      || '<tr><td colspan="6" class="empty">还没有登记备份介质</td></tr>';
    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>备份合规 <span class="sub">${st.compliant ? '已达标' : '待改进'}</span></h3></div>
        <div class="hint-box">标准要求：<b>至少 ${req.requiredCopies} 套完整数据</b>（一套在线应用、两套备份）、
          <b>至少 ${req.requiredMediaTypes} 种存储介质</b>${req.requireOffline ? '、<b>至少一套离线</b>' : ''}${req.requireOffsite ? '、<b>至少一套异地</b>' : ''}。
          保管状况检测周期 ${req.intervalDays} 天。</div>
        <div class="flex mt8">
          <button class="btn btn-primary" id="bk-run-online">制作在线备份</button>
          <button class="btn" id="bk-run-offline">制作离线备份</button>
          <button class="btn" id="bk-run-offsite">制作异地备份</button>
          <button class="btn" id="bk-check">执行保管状况检测</button>
        </div>
        <div id="bk-msg" class="mt8"></div>
        ${(st.warnings || []).length ? `<ul class="warn-list">${st.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>` : '<div class="hint-box mt8">备份合规要求已满足 👍</div>'}
      </div>
      <div class="card"><div class="card-head"><h3>备份登记 <span class="sub">共 ${bks.total} 份</span></h3></div>
        <div class="table-wrap"><table>
          <thead><tr><th>备份单号</th><th>类型</th><th>介质</th><th>大小</th><th>日志链</th><th>校验</th><th>时间</th><th></th></tr></thead>
          <tbody>${bRows}</tbody></table></div>
        <div class="help">提示：只有**登记在案且校验通过**的备份才计入套数 ——「备份做过」和「备份能用」是两件事。</div>
      </div>
      <div class="card"><div class="card-head"><h3>恢复演练 <span class="sub">台账 ${dr.total || 0} 条</span></h3></div>
        <div class="hint-box">备份"做过"不等于"能恢复"。演练会把备份包真正打开，数清里面的档案/附件/用户/日志，
          校验日志哈希链，并抽查附件是否都在包里 —— <b>全程不动生产库</b>。
          真要整库恢复属于维护动作：先停服务，再执行 <span class="mono">server\tools\restore-backup.js --backup &lt;备份包&gt; --yes</span>。</div>
        <div class="flex mt8">
          <button class="btn btn-primary" id="bk-drill">对最近一份备份做演练</button>
          <span class="help">${dr.last_drill ? '最近演练：' + esc(dr.last_drill.backup_no) + '（' + esc(dr.last_drill.result) + '，' + fmtTime(dr.last_drill.at) + '）' : '还没有演练记录'}</span>
        </div>
        <div id="bk-drill-msg" class="mt8"></div>
        <div class="table-wrap mt8"><table>
          <thead><tr><th>时间</th><th>备份单号</th><th>方式</th><th>结论</th><th>档案/附件/用户/日志</th><th>日志链</th><th>操作人</th></tr></thead>
          <tbody>${(dr.list || []).map((d) => `
            <tr><td class="nowrap muted">${fmtTime(d.at)}</td><td class="mono">${esc(d.backup_no)}</td>
            <td>${esc(d.mode)}</td>
            <td>${d.result === '合格' ? '<span class="tag tag-green">合格</span>' : `<span class="tag tag-red">${esc(d.result)}</span>`}</td>
            <td class="mono nowrap">${d.archives} / ${d.files} / ${d.users} / ${d.logs}</td>
            <td>${d.chain_ok ? '完整' : '异常'}</td>
            <td>${esc(d.by_name || '—')}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">还没有演练或恢复记录</td></tr>'}</tbody></table></div>
        ${dr.last_restore ? `<div class="help">最近一次整库恢复：${fmtTime(dr.last_restore.at)}，由 ${esc(dr.last_restore.by_name || '命令行')} 执行，结论 ${esc(dr.last_restore.result)}</div>` : ''}
      </div>
      <div class="card"><div class="card-head"><h3>备份介质台账 <span class="sub">共 ${media.list.length} 个</span></h3></div>
        <div class="flex mt8">
          <input type="text" id="m-no" placeholder="介质编号" class="grow">
          <select id="m-type">${(media.types || []).map((t) => `<option>${esc(t)}</option>`).join('')}</select>
          <select id="m-loc">${(media.locations || []).map((t) => `<option>${esc(t)}</option>`).join('')}</select>
          <button class="btn" id="m-add">登记介质</button>
        </div>
        <div class="table-wrap mt8"><table>
          <thead><tr><th>介质编号</th><th>类型</th><th>存放</th><th>状态</th><th>备份数</th><th>最近备份</th></tr></thead>
          <tbody>${mRows}</tbody></table></div>
      </div>
      <div class="card"><div class="card-head"><h3>存储状况 <span class="sub">剩余 ${sst.free_ratio}%</span></h3></div>
        ${(sst.alarms || []).length ? `<ul class="warn-list">${sst.alarms.map((a) => `<li>[${a.level === 'error' ? '严重' : '提示'}] ${esc(a.label)}${a.detail ? '：' + esc(a.detail) : ''}</li>`).join('')}</ul>` : '<div class="hint-box">存储状况正常 👍</div>'}
        ${sst.last_check ? `<div class="help">最近一次保管状况检测（${esc(sst.last_check.check_no)}，${fmtTime(sst.last_check.created_at)}）：${esc(sst.last_check.conclusion)}</div>` : ''}
      </div>`;
    const runBackup = async (type) => {
      const msg = $('#bk-msg');
      msg.innerHTML = '正在制作…';
      try {
        const r = await api('/api/backup/run', { method: 'POST', body: { target_type: type } });
        msg.innerHTML = `<div class="hint-box">已制作 ${esc(type)} 备份：<b class="mono">${esc(r.backup_no)}</b>　${(r.size_bytes / 1048576).toFixed(1)} MB　${esc(r.dest_path)}</div>`;
        setView('backup');
      } catch (e) { msg.innerHTML = `<div class="hint-box warn">制作失败：${esc(e.message)}</div>`; }
    };
    $('#bk-run-online').onclick = () => runBackup('在线');
    $('#bk-run-offline').onclick = () => runBackup('离线');
    $('#bk-run-offsite').onclick = () => runBackup('异地');
    $('#bk-check').onclick = async () => {
      const msg = $('#bk-msg');
      msg.innerHTML = '正在检测…';
      try {
        const r = await api('/api/storage/check', { method: 'POST', body: { sample: 20 } });
        msg.innerHTML = `<div class="hint-box">${esc(r.conclusion)}</div>`;
        setTimeout(() => setView('backup'), 900);
      } catch (e) { msg.innerHTML = `<div class="hint-box warn">检测失败：${esc(e.message)}</div>`; }
    };
    $('#bk-drill').onclick = async () => {
      const btn = $('#bk-drill');
      const msg = $('#bk-drill-msg');
      btn.disabled = true; btn.textContent = '演练中…';
      msg.innerHTML = '正在开包核对（大备份包可能要十几秒）…';
      try {
        const r = await api('/api/backup/drills', { method: 'POST', body: {} });
        msg.innerHTML = `<div class="hint-box ${r.ok ? '' : 'warn'}">${esc(r.detail || (r.ok ? '演练合格' : '演练不合格'))}</div>`;
        setTimeout(() => setView('backup'), r.ok ? 1200 : 2400);
      } catch (e) {
        btn.disabled = false; btn.textContent = '对最近一份备份做演练';
        msg.innerHTML = `<div class="hint-box warn">演练失败：${esc(e.message)}</div>`;
      }
    };
    $('#m-add').onclick = async () => {
      const no = ($('#m-no').value || '').trim();
      if (!no) { alert('请填写介质编号'); return; }
      try {
        await api('/api/backup/media', { method: 'POST', body: { medium_no: no, type: $('#m-type').value, location: $('#m-loc').value } });
        setView('backup');
      } catch (e) { alert('登记失败：' + e.message); }
    };
    $$('[data-verify]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true; b.textContent = '校验中…';
        try {
          const r = await api(`/api/backups/${b.dataset.verify}/verify`, { method: 'POST', body: {} });
          toast(r.result || (r.ok ? '校验合格' : '校验不合格'));
          setView('backup');
        } catch (e) { b.disabled = false; b.textContent = '校验'; toast('校验失败：' + e.message); }
      };
    });
  }

  // ---------------- 鉴定工作台（价值 / 密级 / 开放 三鉴 + 批次文据 + 销毁清册） ----------------
  // ---------------- 待办中心（v13） ----------------
  const TODO_LEVEL = {
    critical: { label: '紧急', cls: 'tag-red' },
    warn: { label: '注意', cls: 'tag-amber' },
    info: { label: '提示', cls: 'tag-blue' },
  };
  const TODO_KIND = {
    backup: '备份', detection: '四性检测', fixity: '完整性校验',
    retention: '到期与鉴定', loan: '借阅', security: '安全', system: '系统',
  };
  /** 待办"前往处理"跳到哪个页面（kind → data-view） */
  const TODO_VIEW = {
    backup: 'backup', detection: 'detection', fixity: 'backup',
    retention: 'retention', loan: 'loans', security: 'logs', system: 'manage',
  };
  const TODO_STATUS_LABEL = { open: '待处理', done: '已处理', dismissed: '已忽略' };

  /**
   * 刷新导航红点。单独抽出来是因为多处要用：登录后、进入工作台、处理完一条待办之后。
   * 有待办时数字为待处理条数；其中有紧急项（备份断链、附件损坏）时红点转红 ——
   * 这类问题拖着会变成不可挽回的损失，不能和"提示"混成同一个颜色。
   */
  async function refreshTodoBadge() {
    const badge = $('#nav-todo-badge');
    if (!badge) return;
    try {
      const r = await api('/api/todos?status=open&limit=1');
      const n = (r.counts && r.counts.open) || 0;
      const critical = (r.counts && r.counts.critical) || 0;
      if (n > 0) {
        badge.textContent = n > 99 ? '99+' : String(n);
        badge.classList.remove('hidden');
        if (critical > 0) badge.classList.add('tag-red');
        else badge.classList.remove('tag-red');
      } else {
        badge.classList.add('hidden');
      }
    } catch (_) {
      badge.classList.add('hidden');
    }
  }

  async function renderTodos(params) {
    const status = (params && params.status) || 'open';
    const r = await api('/api/todos?status=' + encodeURIComponent(status) + '&limit=300');
    const counts = r.counts || {};
    const c = $('#content');
    const canHandle = state.user.role !== 'reader' && state.user.role !== 'auditor';

    // 调度器面板只有系统管理员/管理员能看，其它角色 403 → 静默不显示
    let sched = null;
    try { sched = await api('/api/scheduler/status'); } catch (_) { sched = null; }

    const tab = (key, label, n) => `<button class="btn btn-sm${status === key ? ' btn-primary' : ''}" data-tab="${key}">${label}${n === undefined ? '' : ` ${n}`}</button>`;

    const items = (r.list || []).map((t) => {
      const lv = TODO_LEVEL[t.level] || TODO_LEVEL.info;
      const go = TODO_VIEW[t.kind];
      const handled = t.status !== 'open';
      const handledAt = t.handled_at ? String(t.handled_at).slice(0, 16).replace('T', ' ') : '';
      return `<div class="card" style="margin-bottom:10px">
        <div class="card-head">
          <h3><span class="tag ${lv.cls}">${lv.label}</span> ${esc(t.title)}</h3>
          <span class="sub">${esc(TODO_KIND[t.kind] || t.kind || '')}　${esc(String(t.created_at || '').slice(0, 16).replace('T', ' '))}</span>
        </div>
        <div style="padding:0 16px 14px">
          <div class="muted" style="line-height:1.7;margin-bottom:10px">${esc(t.detail || '')}</div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            ${go ? `<button class="btn btn-sm" data-go="${esc(go)}">前往处理</button>` : ''}
            ${canHandle && !handled ? `<button class="btn btn-sm btn-primary" data-done="${t.id}">标记已处理</button>
              <button class="btn btn-sm btn-danger" data-dismiss="${t.id}">忽略</button>` : ''}
            ${handled ? `<span class="muted">${esc(TODO_STATUS_LABEL[t.status] || t.status)}${handledAt ? '　' + esc(handledAt) : ''}${t.handled_note ? '　' + esc(t.handled_note) : ''}</span>` : ''}
          </div>
        </div>
      </div>`;
    }).join('') || `<div class="card"><div class="empty">${status === 'open' ? '当前没有待办事项' : '没有记录'}</div></div>`;

    const taskRows = ((sched && sched.attached) ? sched.tasks : []).map((t) => {
      const st = t.last_status === 'ok' ? '<span class="tag tag-green">成功</span>'
        : (t.last_status === 'fail' ? '<span class="tag tag-red">失败</span>'
          : (t.last_status === 'running' ? '<span class="tag tag-blue">执行中</span>' : '<span class="muted">尚未运行</span>'));
      const next = t.next_run_at ? String(t.next_run_at).slice(0, 16).replace('T', ' ') : '—';
      const last = t.last_run_at ? String(t.last_run_at).slice(0, 16).replace('T', ' ') : '—';
      return `<tr>
        <td>${esc(t.title)}</td>
        <td>${st}</td>
        <td class="muted">${esc(last)}</td>
        <td class="muted">${esc(next)}<br><span class="sub">${esc(t.reason || '')}</span></td>
        <td class="num">${t.runs}${t.fails ? ` <span class="tag tag-red">失败 ${t.fails}</span>` : ''}</td>
        <td><button class="btn btn-sm" data-run="${esc(t.key)}">立即运行</button></td>
      </tr>`;
    }).join('');

    const s = sched && sched.settings ? sched.settings : {};
    const schedPanel = (sched && sched.attached) ? `
      <div class="card" style="margin-top:18px">
        <div class="card-head"><h3>定时任务 <span class="sub">系统自己该做的事，共 ${sched.tasks.length} 个</span></h3></div>
        <div class="table-wrap"><table><thead><tr>
          <th>任务</th><th>上次结果</th><th>上次运行</th><th>下次运行</th><th class="num">累计</th><th></th>
        </tr></thead><tbody>${taskRows || '<tr><td colspan="6" class="muted">没有已注册的任务</td></tr>'}</tbody></table></div>
        <div class="hint-box">
          定时任务<b>只在服务运行期间执行</b>：本系统不注册系统级计划任务（那会破坏"拷贝即用"的便携性）。
          <br>每日自动备份 ${esc(String(s.backup_hour))} 点 · 在线备份保留 ${esc(String(s.keep_copies))} 份（只提醒、不自动删）
          · 四性检测巡检每 ${esc(String(s.sweep_days))} 天 · 保管状况与哈希校验每 ${esc(String(s.storage_days))} 天
        </div>
      </div>` : (sched ? `<div class="hint-box" style="margin-top:18px">定时任务未启用：${esc(sched.note || '')}</div>` : '');

    c.innerHTML = `
      <div class="card">
        <div class="card-head"><h3>待办与提醒 <span class="sub">该处理的事，系统替你盯着</span></h3></div>
        <div style="padding:0 16px 14px;display:flex;gap:8px;flex-wrap:wrap">
          ${tab('open', '待处理', counts.open || 0)}
          ${tab('done', '已处理', counts.done || 0)}
          ${tab('dismissed', '已忽略', counts.dismissed || 0)}
          ${tab('all', '全部')}
          ${counts.critical ? `<span class="tag tag-red" style="align-self:center">紧急 ${counts.critical}</span>` : ''}
        </div>
      </div>
      <div style="margin-top:14px">${items}</div>
      ${schedPanel}
    `;

    $$('#content [data-tab]').forEach((b) => {
      b.onclick = () => setView('todos', { status: b.dataset.tab });
    });
    $$('#content [data-go]').forEach((b) => {
      b.onclick = () => setView(b.dataset.go);
    });
    $$('#content [data-done]').forEach((b) => {
      b.onclick = async () => {
        try {
          await api('/api/todos/' + b.dataset.done + '/done', { method: 'POST', body: {} });
          toast('已标记为处理完成', 'ok');
        } catch (e) { toast(e.message, 'err'); }
        await refreshTodoBadge();
        setView('todos', { status });
      };
    });
    $$('#content [data-dismiss]').forEach((b) => {
      b.onclick = async () => {
        try {
          await api('/api/todos/' + b.dataset.dismiss + '/dismiss', { method: 'POST', body: {} });
          toast('已忽略该提醒', 'ok');
        } catch (e) { toast(e.message, 'err'); }
        await refreshTodoBadge();
        setView('todos', { status });
      };
    });
    $$('#content [data-run]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true;
        b.textContent = '执行中…';
        try {
          const res = await api('/api/scheduler/run/' + encodeURIComponent(b.dataset.run), { method: 'POST', body: {} });
          toast(res.ok ? '执行完成：' + (res.detail || '') : '执行失败：' + (res.detail || ''), res.ok ? 'ok' : 'err');
        } catch (e) {
          toast('执行失败：' + e.message, 'err');
        }
        setView('todos', { status });
      };
    });
    refreshTodoBadge();
  }

  // ---------------- 扫码枪（键盘模拟设备）全局捕获 ----------------
  /**
   * 扫码枪把二维码里的文字当按键"打"出来，末尾跟一个回车。
   * 判定"这是扫码枪还是人在打字"靠**击键速度**：真人打字通常 >40ms/字符，
   * 扫码枪几乎瞬间完成（常见 1–5ms/字符）。
   *
   * 命中后必须 preventDefault：否则这串字符会漏进当前聚焦的输入框 ——
   * 你正在检索框里打字，随手扫一下，检索框里就多了一整串网址。
   */
  const scanBuf = { text: '', startAt: 0, lastAt: 0, count: 0, committedAt: 0 };

  /**
   * 扫码诊断（v4.26.8）—— **只观察，不改变任何判定**。
   *
   * 起因：有一版我凭推断改了这里的判定（忽略 ev.repeat、提前 preventDefault），
   * 结果使用者反馈"扫不出信息了"；退回去之后**仍然扫不出来** ——
   * 说明原因未必在我改的那两行上，而我手上没有那支枪、没法复现。
   *
   * 所以这里只做一件事：把**实际到达的按键**记下来。下次扫描时，
   * 工作台里会显示"最近一次按键流"：有没有按键、多少个、平均多少毫秒一个、
   * 有没有自动重复标记、有没有跟回车。据此才能分清是**事件没到**、
   * 还是**到了但被判为"不像扫码枪"**、还是**解析没找到**。
   *
   * 这段代码不参与任何判断，删掉它也不影响扫码功能。
   */
  const scanDiag = { lastLen: 0, lastAvgMs: 0, lastAt: 0, sawRepeat: false, sawEnter: false, events: 0, bursts: 0, note: '还没有按键' };
  window.__dshScanDiag = scanDiag;
  const SCAN_MAX_AVG_MS = 35;   // 平均击键间隔阈值：快于此值才算扫码枪
  const SCAN_MIN_LEN = 4;       // 太短不当扫码，免得把人手快速敲的回车当扫码
  const SCAN_IDLE_MS = 400;     // 间隔超过它就认为换了一次输入
  const SCAN_COMMIT_MS = 160;   // 停手这么久就自动提交（见下）

  /**
   * 停手自动提交。
   *
   * 为什么需要：很多无线扫码枪（例如得力 14952W 这类）**出厂不带回车后缀**，
   * 扫完只把字符打出来、不跟回车 —— 而最初的实现只在收到回车时才提交，
   * 结果就是"枪明明扫了、界面毫无反应"。让它停手 160ms 就提交，两种枪都能用。
   *
   * 为什么不会误伤人工输入：只有当整串是**扫码枪速度**（平均 ≤35ms/字符，
   * 而人手最快也就 100ms/字符量级）且长度 ≥4 时才会提交。
   */
  let scanCommitTimer = null;
  function scheduleScanCommit() {
    if (scanCommitTimer) clearTimeout(scanCommitTimer);
    scanCommitTimer = setTimeout(() => {
      scanCommitTimer = null;
      const text = scanBuf.text;
      const count = scanBuf.count;
      const avg = count ? (Date.now() - scanBuf.startAt) / count : 9999;
      scanBuf.text = ''; scanBuf.count = 0; scanBuf.startAt = 0;
      if (text.length >= SCAN_MIN_LEN && count && avg <= SCAN_MAX_AVG_MS) {
        scanBuf.committedAt = Date.now();
        onScanText(text);
      }
    }, SCAN_COMMIT_MS);
  }

  function setupScanner() {
    document.addEventListener('keydown', (ev) => {
      // 只认真实硬件的按键：合成事件（自动化测试、脚本）不参与判定，
      // 否则"填表测试"会被误判成扫码枪。
      if (!ev.isTrusted) return;
      if (ev.ctrlKey || ev.altKey || ev.metaKey) { scanBuf.text = ''; scanBuf.count = 0; return; }
      const now = Date.now();
      if (ev.key === 'Enter') {
        scanDiag.sawEnter = true;   // 诊断：枪到底带不带回车后缀
        const text = scanBuf.text;
        const count = scanBuf.count;
        const avg = count ? (now - scanBuf.startAt) / count : 9999;
        scanBuf.text = ''; scanBuf.count = 0; scanBuf.startAt = 0;
        if (scanCommitTimer) { clearTimeout(scanCommitTimer); scanCommitTimer = null; }
        // 刚才若已被"停手自动提交"处理过，这里只清缓冲，不重复提交
        if (now - scanBuf.committedAt < 800) { scanBuf.committedAt = 0; return; }
        if (text.length >= SCAN_MIN_LEN && count && avg <= SCAN_MAX_AVG_MS) {
          ev.preventDefault();
          ev.stopPropagation();
          onScanText(text);
        }
        return;
      }
      if (ev.key.length !== 1) {
        scanBuf.text = ''; scanBuf.count = 0;
        if (scanCommitTimer) { clearTimeout(scanCommitTimer); scanCommitTimer = null; }
        return;
      }
      if (now - scanBuf.lastAt > SCAN_IDLE_MS) {
        // 一段输入结束：把这一段的实际统计记进诊断（只记录，不做判断）
        if (scanBuf.count >= 2) {
          scanDiag.lastLen = scanBuf.count;
          scanDiag.lastAvgMs = Math.round((scanBuf.lastAt - scanBuf.startAt) / scanBuf.count);
          scanDiag.bursts++;
        }
        scanBuf.text = ''; scanBuf.count = 0;
      }
      if (!scanBuf.count) scanBuf.startAt = now;
      scanBuf.text += ev.key;
      scanBuf.count++;
      scanBuf.lastAt = now;
      scanDiag.events++;
      scanDiag.lastAt = now;
      if (ev.repeat) scanDiag.sawRepeat = true;
      scanDiag.note = `已收到 ${scanDiag.events} 次按键；最近一段 ${scanDiag.lastLen} 个字符、平均 ${scanDiag.lastAvgMs} ms/字符`
        + `${scanDiag.sawRepeat ? '；见到"自动重复"标记' : ''}`;
      if (scanBuf.count > 800) { scanBuf.text = ''; scanBuf.count = 0; }   // 保险，避免无限增长
      scheduleScanCommit();
    }, true);
  }

  async function onScanText(text) {
    const t = String(text || '').trim();
    if (!t || !state.user) return;
    if (state.view !== 'scan') setView('scan');   // 扫到东西自动进工作台，操作者不用来回切页面
    await handleScan(t);
  }
  // 给自动化测试留的入口（键盘路径被 isTrusted 挡住了）
  window.__dshScan = { handle: (t) => onScanText(t) };

  // ---------------- 扫码工作台 ----------------
  const SCAN_MODES = [
    { key: 'query', label: '快速查询', tip: '扫档案码看详情与存放位置；扫盒码看盒内件数、库位' },
    { key: 'box', label: '装盒上架', tip: '先扫档案码，再扫盒码 —— 扫了即办，系统按「同年度/同机构/同期限/同门类」自动校验' },
    { key: 'loan', label: '借出 / 归还', tip: '扫档案码后**点一下**确认（涉及权属变更，值得一次确认）：在库→登记借出，已借出→办理归还' },
    { key: 'stock', label: '库房盘点', tip: '先选或新建盘点单，然后逐件扫 —— 扫一件记一件，现场就能看出多处/少处' },
    { key: 'stamp', label: '归档校验', tip: '扫档案码，核对归档章六项必备项是否齐备（DA/T 22—2015 §5.4.4），可直接打印' },
  ];
  const STAMP_LABELS = {
    unit_code: '全宗号', year: '年度', retention: '保管期限',
    item_no: '件号', pages: '页数', org_code: '机构(问题)',
  };
  const scanState = { mode: 'query', pendingArchive: null, stockId: 0, log: [], last: null, extra: null };

  function pushScanLog(raw, action, result, level) {
    scanState.log.unshift({
      at: new Date().toLocaleTimeString('zh-CN'), raw: String(raw || '').slice(0, 120), action, result: String(result || ''), level: level || 'ok',
    });
    if (scanState.log.length > 20) scanState.log.length = 20;
    renderScanLog();
  }

  function renderScanLog() {
    const box = $('#scan-log');
    if (!box) return;
    // 扫码诊断（v4.26.8）：只显示实际到达的按键统计，帮助判断问题出在哪一环。
    const dg = `<div class="hint-box" style="margin-bottom:8px">
      <b>扫码诊断</b>（只观察，不影响扫码）：${esc(scanDiag.note)}<br>
      收到回车：<b>${scanDiag.sawEnter ? '有' : '没有'}</b>　
      自动重复标记：<b>${scanDiag.sawRepeat ? '有' : '没有'}</b>　
      累计按键 <b>${scanDiag.events}</b> 次
      <div class="help" style="margin-top:4px">
        扫一次码后看这一行：<b>累计按键还是 0</b> → 按键根本没到系统（枪/焦点/电量问题）；
        <b>有按键但"最近一段"不刷新</b> → 事件到了却被别处截走；
        数字正常却仍"未识别" → 是解析没找到这个码。
      </div></div>`;
    if (!scanState.log.length) { box.innerHTML = dg + '<div class="empty">还没有扫码记录</div>'; return; }
    box.innerHTML = `<div class="table-wrap"><table><thead><tr>
        <th>时间</th><th>扫到的内容</th><th>识别/动作</th><th>结果</th></tr></thead><tbody>
      ${scanState.log.map((x) => `<tr>
        <td class="muted">${esc(x.at)}</td>
        <td><code style="font-size:12px">${esc(x.raw)}</code></td>
        <td>${esc(x.action)}</td>
        <td>${x.level === 'err' ? `<span class="tag tag-red">${esc(x.result)}</span>`
    : (x.level === 'warn' ? `<span class="tag tag-amber">${esc(x.result)}</span>` : esc(x.result))}</td>
      </tr>`).join('')}
    </tbody></table></div>`;
  }

  /** 解析结果卡片（按类型渲染） */
  function scanEntityHtml(r) {
    if (r.kind === 'archive') {
      const a = r.archive || {};
      return `<div class="hint-box" style="border-left:3px solid var(--c-ok)">
        <b>档案</b>　${esc(a.archive_code || r.code)}　${esc(a.title || '')}
        <br>年度 ${esc(String(a.year || '—'))}　门类 ${esc(a.type_code || '—')}　保管期限 ${esc(a.retention || '—')}　密级 ${esc(a.secret_level || '—')}　状态 ${esc(a.status || '—')}
        <br>存放：${esc(a.box_code || '未装盒')}${a.loc_code ? `　${esc(a.loc_code)}${a.loc_name ? ' ' + esc(a.loc_name) : ''}` : ''}</div>`;
    }
    if (r.kind === 'box') {
      const b = r.box || {};
      return `<div class="hint-box" style="border-left:3px solid var(--c-primary)">
        <b>档案盒</b>　${esc(b.box_code || r.code)}　${esc(b.title || '')}
        <br>年度 ${esc(String(b.year || '—'))}　门类 ${esc(b.type_code || '—')}　保管期限 ${esc(b.retention || '—')}　盒内 ${esc(String(b.archives_count === undefined ? '—' : b.archives_count))} 件
        <br>位置：${esc(b.loc_code || '未上架')}${b.loc_name ? ' ' + esc(b.loc_name) : ''}</div>`;
    }
    if (r.kind === 'location') {
      const l = r.location || {};
      return `<div class="hint-box"><b>库位</b>　${esc(l.code || r.code)}　${esc(l.name || '')}</div>`;
    }
    return `<div class="hint-box" style="border-left:3px solid var(--c-warn)">
      <b>未识别</b>：${esc(r.reason || '库中未找到该编号')}
      <br>扫到的原文：<code>${esc(r.raw || '')}</code>
      ${(r.candidates || []).length > 1 ? `<br>解析出的候选编号：${esc((r.candidates || []).slice(0, 6).join(' / '))}` : ''}</div>`;
  }

  function renderScanResult() {
    const box = $('#scan-result');
    if (!box) return;
    const r = scanState.last;
    if (!r) { box.innerHTML = '<div class="muted">还没有扫码。把光标放在上面的输入框里，直接扣扳机即可。</div>'; return; }
    const extra = scanState.extra || '';
    box.innerHTML = scanEntityHtml(r) + extra;
    $$('#scan-result [data-act]').forEach((b) => { b.onclick = () => scanAction(b.dataset.act, b.dataset.id ? Number(b.dataset.id) : 0); });
  }

  async function scanAction(act, id) {
    try {
      if (act === 'open') { location.hash = '#/archive/' + id; handleDeepLink(); return; }
      if (act === 'stamp-print') { window.open('/api/print/stamps?ids=' + id, '_blank'); return; }
      if (act === 'beikao') { window.open('/api/print/beikaobiao/' + id, '_blank'); return; }
      if (act === 'box-print') { window.open('/api/print/box/' + id, '_blank'); return; }
      if (act === 'loan-out') {
        const r = await api('/api/loans', { method: 'POST', body: { archive_id: id, mode: '借出' } });
        toast(r && r.status ? `已登记：${r.status}` : '已登记借出', 'ok');
        pushScanLog(scanState.last.raw, '登记借出', (r && r.status) || '已登记');
      } else if (act === 'loan-in') {
        await api('/api/loans/' + id + '/return', { method: 'POST', body: {} });
        toast('已办理归还', 'ok');
        pushScanLog(scanState.last.raw, '办理归还', '已完成');
      } else if (act === 'assign') {
        await api('/api/boxes/' + id + '/assign', { method: 'POST', body: { archive_ids: [scanState.pendingArchive.id] } });
        toast('已装入 ' + scanState.last.code, 'ok');
        pushScanLog(scanState.last.raw, '装盒', '已装入');
        scanState.pendingArchive = null;
      }
    } catch (e) {
      toast(e.message, 'err');
      pushScanLog((scanState.last || {}).raw || '', '动作失败', e.message, 'err');
    }
    scanState.last = null; scanState.extra = null;
    renderScanResult();
  }

  /** 借还：先查这份档案当前的借出记录，再决定给"借出"还是"归还"按钮 */
  async function prepareLoan(archive) {
    let open = null;
    for (const st of ['已批准', '逾期']) {
      const r = await api('/api/loans?status=' + encodeURIComponent(st) + '&limit=200');
      open = (r.list || []).find((x) => Number(x.archive_id) === Number(archive.id));
      if (open) break;
    }
    const canBorrow = archive.status === '在库' && !open;
    scanState.extra = `<div style="margin-top:10px">
      ${canBorrow
    ? `<button class="btn btn-primary" data-act="loan-out" data-id="${archive.id}">登记借出（${esc(archive.archive_code || '')}）</button>`
    : (open
      ? `<button class="btn btn-primary" data-act="loan-in" data-id="${open.id}">办理归还（借阅单 ${esc(open.loan_no || open.id)}）</button>`
      : `<span class="tag tag-amber">当前状态「${esc(archive.status || '')}」，无法借出</span>`)}
      </div>`;
    pushScanLog(scanState.last.raw, '档案', (archive.archive_code || '') + (canBorrow ? '（在库，可借出）' : (open ? '（借出中，可归还）' : '（不可借出）')));
    renderScanResult();
  }

  /** 归档校验：拉归档章字段，列出必备项齐备情况 */
  async function loadStamp(archive) {
    const r = await api('/api/archives/' + archive.id + '/stamp');
    const f = (r.fields && !Array.isArray(r.fields)) ? r.fields : {};
    const missing = new Set((r.missing || []).map((m) => (typeof m === 'string' ? m : (m && (m.key || m.label)) || '')));
    const rows = ['unit_code', 'year', 'retention', 'item_no', 'pages', 'org_code'].map((k) => {
      const label = STAMP_LABELS[k];
      const val = f[k] === undefined || f[k] === null || f[k] === '' ? '—' : String(f[k]);
      const bad = missing.has(k) || missing.has(label) || val === '—';
      return `<tr><td>${esc(label)}</td><td>${esc(val)}</td>
        <td>${bad ? '<span class="tag tag-red">缺</span>' : '<span class="tag tag-green">齐</span>'}</td></tr>`;
    }).join('');
    scanState.extra = `<div style="margin-top:10px">
      <div class="table-wrap"><table><thead><tr><th>归档章必备项（DA/T 22—2015 §5.4.4）</th><th>值</th><th>状态</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div style="margin-top:8px"><button class="btn btn-primary" data-act="stamp-print" data-id="${archive.id}">打印归档章</button></div></div>`;
    const badCount = ['unit_code', 'year', 'retention', 'item_no', 'pages'].filter((k) => f[k] === undefined || f[k] === '' || f[k] === null).length;
    pushScanLog(scanState.last.raw, '归档校验', badCount ? `必备项缺 ${badCount} 项` : '六项齐备', badCount ? 'warn' : 'ok');
    renderScanResult();
  }

  /** 盘点：把扫到的原文交给盘点接口（它自己会做兼容解析），并刷新进度 */
  async function scanIntoStock(raw, resolved) {
    if (!scanState.stockId) {
      scanState.extra = '<div class="hint-box" style="margin-top:10px">还没有选择盘点单：请在下面新建或选择一个「进行中」的盘点单。</div>';
      pushScanLog(raw, '盘点', '未选择盘点单', 'warn');
      renderScanResult();
      return;
    }
    try {
      const r = await api('/api/stock-checks/' + scanState.stockId + '/scan', { method: 'POST', body: { codes: [raw] } });
      const item = (r && r.item) || {};
      const label = item.archive_code || item.barcode || (resolved.code || raw);
      pushScanLog(raw, '盘点', (item.status ? item.status + '：' : '已核对：') + label);
      toast('已核对 ' + label, 'ok');
    } catch (e) {
      pushScanLog(raw, '盘点', e.message, 'err');
      toast(e.message, 'err');
    }
    scanState.extra = null;
    renderScanResult();
    await renderStockPanel();
  }

  async function renderStockPanel() {
    const box = $('#scan-extra');
    if (!box) return;
    if (scanState.mode !== 'stock') { box.innerHTML = ''; box.style.display = 'none'; return; }
    box.style.display = '';
    const listRes = await api('/api/stock-checks');
    const list = listRes.list || [];
    // 盘点进度的字段就在盘点单这一行上（checked/missing/mislocated），
    // 不是 counts 对象 —— 第一次写这块时想当然读了 counts，页面显示永远是 0。
    const cur = scanState.stockId ? await api('/api/stock-checks/' + scanState.stockId) : null;
    const total = cur && Array.isArray(cur.items) ? cur.items.length : 0;
    box.innerHTML = `<div class="card-head"><h3>盘点单 <span class="sub">${cur ? esc(cur.check_no || '') + ' · ' + esc(cur.status || '') : '未选择'}</span></h3></div>
      <div style="padding:0 16px 14px">
        ${cur ? `<div class="muted">应盘 ${total} 件　已核对 ${cur.checked || 0}　遗漏 ${cur.missing || 0}　位置不符 ${cur.mislocated || 0}</div>` : ''}
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
          <select id="stock-pick" class="btn btn-sm">
            <option value="">— 选择进行中的盘点单 —</option>
            ${list.filter((x) => x.status === '进行中').map((x) => `<option value="${x.id}"${Number(x.id) === Number(scanState.stockId) ? ' selected' : ''}>${esc(x.check_no)}　${esc(x.scope || '')}</option>`).join('')}
          </select>
          <button class="btn btn-sm" id="stock-new">新建全库盘点单</button>
          ${cur ? `<button class="btn btn-sm" id="stock-finish">完成盘点</button>
                   <button class="btn btn-sm" id="stock-print">打印清册</button>` : ''}
        </div>
      </div>`;
    const pick = $('#stock-pick');
    if (pick) pick.onchange = () => { scanState.stockId = Number(pick.value) || 0; renderStockPanel(); };
    const nb = $('#stock-new');
    if (nb) {
      nb.onclick = async () => {
        try {
          const r = await api('/api/stock-checks', { method: 'POST', body: { scope: '全库' } });
          scanState.stockId = Number(r.id) || 0;
          toast('已新建盘点单', 'ok');
        } catch (e) { toast(e.message, 'err'); }
        renderStockPanel();
      };
    }
    const fb = $('#stock-finish');
    if (fb) {
      fb.onclick = async () => {
        try {
          await api('/api/stock-checks/' + scanState.stockId + '/finish', { method: 'POST', body: {} });
          toast('盘点已完成', 'ok');
        } catch (e) { toast(e.message, 'err'); }
        renderStockPanel();
      };
    }
    const pb = $('#stock-print');
    if (pb) pb.onclick = () => window.open('/api/stock-checks/' + scanState.stockId + '/print', '_blank');
  }

  async function handleScan(text) {
    let r;
    try {
      r = await api('/api/scan/resolve?text=' + encodeURIComponent(text));
    } catch (e) {
      scanState.last = { kind: 'unknown', raw: text, reason: '解析请求失败：' + e.message };
      renderScanResult();
      pushScanLog(text, '解析失败', e.message, 'err');
      return;
    }
    scanState.last = r;
    scanState.extra = null;

    // 按模式决定"扫完立刻做什么"
    if (scanState.mode === 'box') {
      if (r.kind === 'archive') {
        scanState.pendingArchive = r.archive;
        scanState.extra = '<div class="muted" style="margin-top:8px">已选中这份档案，<b>请接着扫盒码</b>（扫了即装盒）。</div>';
        pushScanLog(text, '档案', (r.code || '') + ' → 待扫盒码');
      } else if (r.kind === 'box') {
        if (!scanState.pendingArchive) {
          scanState.extra = '<div class="muted" style="margin-top:8px">请**先扫档案码**，再扫盒码。</div>';
          pushScanLog(text, '档案盒', (r.code || '') + ' → 请先扫档案', 'warn');
        } else {
          const a = scanState.pendingArchive;
          try {
            await api('/api/boxes/' + r.box.id + '/assign', { method: 'POST', body: { archive_ids: [a.id] } });
            scanState.extra = `<div class="hint-box" style="margin-top:8px">已把 <b>${esc(a.archive_code || '')}</b> 装入 <b>${esc(r.code || '')}</b>。</div>`;
            pushScanLog(text, '装盒', `${a.archive_code || ''} → ${r.code || ''} 已装入`);
            scanState.pendingArchive = null;
          } catch (e) {
            // 同盒校验失败会把原因说清楚（不同年度/机构/期限/门类不得同盒），原样展示
            scanState.extra = `<div class="hint-box" style="margin-top:8px;border-left:3px solid var(--c-warn)"><b>不能同盒：</b>${esc(e.message)}</div>`;
            pushScanLog(text, '装盒', e.message, 'err');
          }
        }
      } else {
        pushScanLog(text, '未识别', r.reason || '库中未找到该编号', 'warn');
      }
      renderScanResult();
      return;
    }

    if (scanState.mode === 'loan' && r.kind === 'archive') { await prepareLoan(r.archive); return; }
    if (scanState.mode === 'stamp' && r.kind === 'archive') { await loadStamp(r.archive); return; }
    if (scanState.mode === 'stock') { await scanIntoStock(text, r); return; }

    // 查询模式（默认）：只展示
    pushScanLog(text, r.kind === 'archive' ? '档案' : (r.kind === 'box' ? '档案盒' : (r.kind === 'location' ? '库位' : '未识别')),
      r.kind === 'unknown' ? (r.reason || '库中未找到该编号') : (r.code || ''),
      r.kind === 'unknown' ? 'warn' : 'ok');
    renderScanResult();
  }

  async function renderScan(params) {
    if (params && params.mode) scanState.mode = params.mode;
    const c = $('#content');
    const tip = (SCAN_MODES.find((m) => m.key === scanState.mode) || {}).tip || '';
    c.innerHTML = `
      <div class="card" style="border-left:3px solid var(--c-primary)">
        <div class="card-head"><h3>扫码工作台 <span class="sub">扫码枪直接扫，不用点输入框</span></h3></div>
        <div style="padding:0 16px 14px">
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
            ${SCAN_MODES.map((m) => `<button class="btn btn-sm${scanState.mode === m.key ? ' btn-primary' : ''}" data-mode="${m.key}">${m.label}</button>`).join('')}
          </div>
          <div class="muted" style="margin-bottom:8px">${esc(tip)}</div>
          <div class="hint-box" style="margin-bottom:10px">
            <b>扫不出东西先查三样：</b>① 枪的键盘布局设成 <b>US（英文）</b>、输入法切到英文 ——
            中文/其它布局下 <code>/ : ? &amp;</code> 会打歪，而二维码里装的正是网址；
            ② 后缀设成<b>回车（CR）</b>最好，本系统对"不带后缀"的枪也兼容（停手即提交）；
            ③ 无线枪确认接收器插好、电量正常。自检办法：随便扫一张，下面「扫码流水」会原样显示枪打进来的字符。
          </div>
          <label class="field"><span>扫码 / 手动输入后回车</span>
            <input id="scan-input" placeholder="光标放这里，直接扣扳机；也可手输档号后回车" autocomplete="off"></label>
          <div id="scan-result"></div>
        </div>
      </div>
      <div class="card" id="scan-extra" style="display:none"></div>
      <div class="card">
        <div class="card-head"><h3>扫码流水 <span class="sub">最近 20 条</span></h3>
          <button class="btn btn-sm" id="scan-clear">清空</button></div>
        <div id="scan-log"></div>
      </div>`;

    $$('#content [data-mode]').forEach((b) => {
      b.onclick = () => { scanState.mode = b.dataset.mode; scanState.pendingArchive = null; scanState.extra = null; renderScan(); };
    });
    const clearBtn = $('#scan-clear');
    if (clearBtn) clearBtn.onclick = () => { scanState.log = []; renderScanLog(); };

    const inp = $('#scan-input');
    if (inp) {
      inp.focus();
      inp.onkeydown = (ev) => {
        if (ev.key === 'Enter') {
          const v = inp.value.trim();
          inp.value = '';
          if (v) onScanText(v);
        }
      };
      // 保持焦点：扫码枪是"扣扳机"操作，不该要求操作者每次先点一下输入框。
      // 但若焦点已经落在别的输入控件上（例如盘点面板的下拉框），就不要抢。
      inp.onblur = () => setTimeout(() => {
        if (state.view !== 'scan') return;
        // **用户已经切到别的窗口了，就绝不把焦点抢回来**。
        // 抢焦点不会移动光标，但会让人感觉"界面不受控"——只在窗口本来就是活动窗口时才自动归位。
        if (!document.hasFocus()) return;
        const ae = document.activeElement;
        if (ae && ['INPUT', 'TEXTAREA', 'SELECT'].includes(ae.tagName)) return;
        const again = $('#scan-input');
        if (again) again.focus();
      }, 60);
    }
    renderScanResult();
    renderScanLog();
    if (scanState.mode === 'stock') await renderStockPanel();
  }

  // ---------------- 接收台账（过程资料：项目 + 批次） ----------------
  //
  // 为什么单独一页：工程、养护的资料是"过程—结束"，一批一批交来，不是档案馆那种
  // 一次性成型的档案。这里按"项目"聚合、按"接收日期"倒序，打开就能回答三个问题：
  // 这个项目交了几批、最后一批是什么时候、这批里还有多少没扫。

  /** 作业区刷新：它现在挂在「工作台」上，只在工作台时就地重画 */
  function refreshIntakeHost() {
    if (state.view === 'dashboard') renderDashboard();
  }

  function intakeStages() {
    const s = state.settings || {};
    const pick = (k, dft) => String(s[k] || dft).split(',').map((x) => x.trim()).filter(Boolean);
    return Array.from(new Set([
      ...pick('intake.stage_engineering', '开工,主体施工,安装,竣工'),
      ...pick('intake.stage_maintenance', '月度,季度,年度'),
    ]));
  }

  /**
   * 新建项目。返回 Promise<新项目|null>。
   *
   * 为什么不再用 promptDialog：登记批次时下拉框最后一项是「＋ 新建项目…」，
   * 选它就要在这里建完、再回到批次表单并自动选中新项目 —— 需要一个"建完了告诉我"的回执。
   */
  function newProjectDialog() {
    return new Promise((resolve) => {
      const dlg = $('#modal');
      let done = false;
      const finish = (val) => { if (done) return; done = true; modal.close(); resolve(val); };
      dlg.addEventListener('close', () => finish(null), { once: true });
      const body = el('div', {}, `
        <div class="form-grid">
          <label class="field"><span>类型</span><select id="np-kind">
            <option>工程</option><option>养护</option><option>其他</option></select></label>
          <label class="field"><span>项目号（留空自动生成）</span><input id="np-no" placeholder="GC-2026-001"></label>
          <label class="field span-2"><span>项目名称<b class="req">*</b></span>
            <input id="np-name" placeholder="如：南沙区某泵站改造工程"></label>
          <label class="field"><span>开始日期</span><input type="date" id="np-start"></label>
          <label class="field"><span>备注</span><input id="np-note"></label>
        </div>`);
      modal.open('新建项目', body, [
        btn('取消', '', () => finish(null)),
        btn('创建', 'btn-primary', async () => {
          const name = body.querySelector('#np-name').value.trim();
          if (!name) return toast('请填写项目名称', 'warn');
          try {
            const r = await api('/api/projects', {
              method: 'POST',
              body: {
                kind: body.querySelector('#np-kind').value,
                name,
                project_no: body.querySelector('#np-no').value.trim(),
                start_date: body.querySelector('#np-start').value,
                note: body.querySelector('#np-note').value,
              },
            });
            toast('已建项目 ' + r.project_no, 'ok');
            finish({ id: r.id, project_no: r.project_no, name });
          } catch (e) { toast(e.message, 'err'); }
        }),
      ], { wide: true });
    });
  }

  async function newBatchDialog(projectId) {
    let projects = [];
    try { projects = ((await api('/api/projects')).list || []); } catch (_) { projects = []; }
    const stages = intakeStages();
    const today = new Date().toISOString().slice(0, 10);
    // 推荐 = 最近有接收记录的在建项目，按最近接收日期取前 3 个。
    // 它只影响排序和「（推荐）」标记 —— 选哪个还是操作者说了算，系统不替人决定。
    const recent = projects.filter((p) => p.status === '在建' && p.last_received)
      .sort((a, b) => String(b.last_received).localeCompare(String(a.last_received)));
    const recIds = recent.slice(0, 3).map((p) => String(p.id));
    const selectedId = projectId ? String(projectId) : (recIds[0] || '');
    const opts = projects.map((p) => `<option value="${p.id}"${String(p.id) === selectedId ? ' selected' : ''}>`
      + `${esc(p.project_no)} ${esc(p.name)}${recIds.includes(String(p.id)) ? '（推荐）' : ''}</option>`).join('');

    const body = el('div', {}, `
      <div class="form-grid">
        <label class="field span-2"><span>所属项目</span>
          <select id="nb-project">
            ${opts}
            <option value="">（不挂项目，只按时间记）</option>
            <option value="__new__">＋ 新建项目…</option>
          </select>
          <div class="help">标「（推荐）」的是最近有接收记录的在建项目，只是帮你少找一步；最终按实际选。</div></label>
        <label class="field"><span>录入日期</span><input type="date" id="nb-date" value="${today}"></label>
        <label class="field"><span>阶段</span><select id="nb-stage">${stages.map((s) => `<option>${esc(s)}</option>`).join('')}</select></label>
        <label class="field span-2"><span>批次名称<b class="req">*</b></span>
          <input id="nb-title" placeholder="如：第1批 开工资料"></label>
        <label class="field"><span>交件人<b class="req">*</b></span><input id="nb-by" placeholder="如：张工"></label>
        <label class="field"><span>联系电话</span><input id="nb-phone" inputmode="tel" placeholder="手机或座机"></label>
        <label class="field"><span>移交部门</span><input id="nb-dept"></label>
        <label class="field"><span>备注</span><input id="nb-note"></label>
      </div>`);

    const sel = body.querySelector('#nb-project');
    sel.onchange = async () => {
      if (sel.value !== '__new__') return;
      const p = await newProjectDialog();
      if (!p) { sel.value = selectedId || ''; return; }
      const opt = document.createElement('option');
      opt.value = String(p.id);
      opt.text = `${p.project_no} ${p.name}`;
      sel.insertBefore(opt, sel.lastElementChild);
      sel.value = String(p.id);
      toast('已选中新项目，继续填这一批', 'ok');
    };

    modal.open('登记一批资料', body, [
      btn('取消', '', () => modal.close()),
      btn('登记', 'btn-primary', async () => {
        const title = body.querySelector('#nb-title').value.trim();
        const by = body.querySelector('#nb-by').value.trim();
        const phone = body.querySelector('#nb-phone').value.trim();
        if (!title) return toast('请填写批次名称', 'warn');
        if (!by) return toast('请填写交件人', 'warn');
        if (phone && !/^[0-9+\-() ]{4,20}$/.test(phone)) {
          return toast('联系电话格式不对（只能填数字、空格、+、-、括号）', 'warn');
        }
        try {
          const r = await api('/api/batches', {
            method: 'POST',
            body: {
              project_id: sel.value === '__new__' ? '' : sel.value,
              received_at: body.querySelector('#nb-date').value,
              title,
              stage: body.querySelector('#nb-stage').value,
              handover_by: by,
              handover_phone: phone,
              source_unit: body.querySelector('#nb-dept').value,
              note: body.querySelector('#nb-note').value,
            },
          });
          toast('已登记 ' + r.batch_no + '（工作台两个版块都已更新）', 'ok');
          modal.close();
          refreshIntakeHost();
        } catch (e) { toast(e.message, 'err'); }
      }),
    ], { wide: true });
  }

  async function openBatchDialog(id) {
    const d = await api('/api/batches/' + id);
    const b = d.batch || {};
    const items = d.items || [];
    const rows = items.map((a) => `<tr>
        <td class="code">${esc(a.archive_number || a.archive_code)}</td>
        <td>${esc(a.title)}</td>
        <td class="num">${Number(a.file_count) || 0}</td>
        <td class="num">${Number(a.scanned_pages) || 0}</td>
        <td class="nowrap">${a.archive_state === '已归档' ? '<span class="tag tag-green">已归档</span>' : '<span class="tag tag-amber">过程</span>'}</td>
      </tr>`).join('') || '<tr><td colspan="5" class="empty">这一批还没有件。到「档案著录」新建时选上本批次即可。</td></tr>';
    const body = el('div', {}, `
      <div class="hint-box">${esc(b.batch_no)}　录入日期 <b>${esc(b.received_at)}</b>　${esc(b.stage || '未填阶段')}<br>
        交件：${esc(b.source_unit || '—')} / ${esc(b.handover_by || '—')}${b.handover_phone ? '　电话 ' + esc(b.handover_phone) : ''}
        　接收人：${esc(b.receive_by || '—')}
        ${b.note ? `<br>备注：${esc(b.note)}` : ''}</div>
      <div class="table-wrap"><table><thead><tr><th>档号</th><th>题名</th><th>文件</th><th>扫描页</th><th>状态</th></tr></thead>
        <tbody>${rows}</tbody></table></div>
      <div class="help">批次 ${esc(b.batch_no)} 共 ${items.length} 件。归档定稿会把本批文件从「过程区」移到「归档区」（按档号逐级目录）。</div>
    `);
    const foot = [btn('关闭', '', () => modal.close())];
    foot.push(btn('打印交接单', '', () => window.open(`/api/print/batch/${id}?auto=1`, '_blank')));
    if (b.status !== '已归档' && can('archive:update')) {
      foot.push(btn('归档定稿', 'btn-primary', () => {
        confirmDialog('归档定稿', `把本批 ${items.length} 件从过程区移入归档区（按档号目录）？归档后这批不再接受补件。`, async () => {
          const r = await api(`/api/batches/${id}/finalize`, { method: 'POST', body: {} });
          toast(`已归档：${r.archived} 件、${r.movedFiles} 个文件` + (r.failed ? `，失败 ${r.failed} 个` : ''),
            r.failed ? 'warn' : 'ok');
          modal.close();
          refreshIntakeHost();
        });
      }));
    }
    modal.open(`批次 ${b.batch_no}`, body, foot, { wide: true });
  }

  // ---------- 工作台里的「接收作业区」（v4.30.0：从独立页并入工作台） ----------
  // 为什么并到工作台：原来的工作台上全是统计数字，看得多、干得少 —— 档案员每天真正要做的是
  // "登记这一批、归到那个项目、看看哪批还没扫"。所以把作业区放在工作台最前面，
  // 左栏按录入时间（自动倒序），右栏按项目归组，两个方向录进去的是同一份数据。

  async function loadIntakeData() {
    const [pr, br] = await Promise.all([
      api('/api/projects').catch(() => ({ list: [] })),
      api('/api/batches?limit=200').catch(() => ({ list: [] })),
    ]);
    return { projects: pr.list || [], batches: br.list || [] };
  }

  function intakeWorkbenchHtml({ projects, batches, canWrite }) {
    const recent = batches.slice(0, 8);
    const last = batches.length ? batches[0].received_at : '—';
    const dateRows = recent.map((b) => `<tr data-batch="${b.id}" style="cursor:pointer">
        <td class="nowrap mono">${esc(b.received_at)}</td>
        <td class="nowrap">${esc(b.handover_by || '—')}${b.handover_phone
    ? `<div class="muted" style="font-size:11.5px">${esc(b.handover_phone)}</div>` : ''}</td>
        <td><b>${esc(b.title || b.batch_no)}</b><div class="muted" style="font-size:11.5px">${esc(b.project_name || '未挂项目')}</div></td>
        <td class="num">${Number(b.item_count) || 0}</td>
        <td class="nowrap">${b.status === '已归档'
    ? '<span class="tag tag-green">已归档</span>' : '<span class="tag tag-amber">接收中</span>'}</td>
      </tr>`).join('') || '<tr><td colspan="5" class="empty">还没有登记过。点右上角「＋ 登记一批」。</td></tr>';

    const projRows = projects.length ? projects.map((p) => `<div data-project="${p.id}"
        style="display:flex;align-items:center;flex-wrap:wrap;gap:8px;padding:8px 2px;cursor:pointer;border-bottom:1px dashed var(--c-line)">
        <span class="mono" style="min-width:96px">${esc(p.project_no)}</span>
        <span style="flex:1;min-width:130px">${esc(p.name)}</span>
        <span class="muted" style="font-size:11.5px">${p.last_received ? '最近 ' + esc(p.last_received) : '还没交过'} · ${Number(p.batch_count) || 0} 批 · ${Number(p.archive_count) || 0} 件</span>
        <span class="tag ${p.status === '在建' ? 'tag-blue' : (p.status === '已归档' ? 'tag-green' : 'tag-gray')}">${esc(p.status)}</span>
      </div>`).join('')
      : '<div class="empty">还没有项目。工程、养护资料建议先建项目，再按批登记。</div>';

    return `
      <div class="card" style="border-left:3px solid var(--c-primary)">
        <div class="card-head"><h3>接收作业区 <span class="sub">交的是哪批、哪天交的、谁交的、归到哪个项目</span></h3>
          <div class="flex" style="gap:6px;flex-wrap:wrap">
            ${canWrite ? '<button class="btn btn-sm btn-primary" id="wb-new-batch">＋ 登记一批</button>' : ''}
            ${canWrite ? '<button class="btn btn-sm" id="wb-new-project">＋ 新建项目</button>' : ''}
          </div></div>
        <div style="padding:0 16px 14px">
          <div class="hint-box" style="margin-bottom:10px">
            <b>①</b> 点「登记一批」：录入日期自动填今天（可改），填交件人、电话；
            <b>②</b> 在「所属项目」下拉里选（带「（推荐）」的是最近在用的，最后由你定；没有就选最后一项「＋ 新建项目…」）；
            <b>③</b> 保存后左右两栏同时出现——从哪个方向录都一样。
          </div>
          <div class="muted" style="margin-bottom:8px">共 <b>${batches.length}</b> 批 · 最近录入 <b>${esc(last)}</b></div>
          <div style="display:flex;flex-wrap:wrap;gap:18px;align-items:flex-start">
            <div id="wb-col-date" style="flex:1 1 460px;min-width:0">
              <div style="font-size:13px;font-weight:600;margin-bottom:6px;color:var(--c-text-2)">
                ① 按录入时间 <span class="muted" style="font-weight:400">日期倒序，最近的在最上面</span></div>
              <div class="table-wrap"><table>
                <thead><tr><th>录入日期</th><th>交件人</th><th>批次</th><th>件数</th><th>状态</th></tr></thead>
                <tbody>${dateRows}</tbody></table></div>
              <div class="help" style="margin-top:6px">点任一行：看件清单、打印交接单、归档定稿。</div>
            </div>
            <div id="wb-col-project" style="flex:1 1 340px;min-width:0">
              <div style="font-size:13px;font-weight:600;margin-bottom:6px;color:var(--c-text-2)">
                ② 按项目 <span class="muted" style="font-weight:400">一个工程 / 一个养护一行，点开看各批</span></div>
              ${projRows}
            </div>
          </div>
        </div>
      </div>`;
  }

  function bindIntakeWorkbench(root, refresh) {
    const scope = root || document;
    scope.querySelectorAll('[data-batch]').forEach((tr) => {
      tr.onclick = () => openBatchDialog(Number(tr.dataset.batch));
    });
    scope.querySelectorAll('[data-project]').forEach((row) => {
      row.onclick = () => openProjectDialog(Number(row.dataset.project));
    });
    const nb = scope.querySelector('#wb-new-batch');
    if (nb) nb.onclick = () => newBatchDialog(0);
    const np = scope.querySelector('#wb-new-project');
    if (np) np.onclick = () => newProjectDialog().then((p) => { if (p && refresh) refresh(); });
  }

  /** 把上一批的局部刷新交回去：登记完/建完项目后，调用方决定刷哪一页 */
  async function openProjectDialog(id) {
    const d = await api('/api/projects/' + id);
    const p = d.project || {};
    const list = d.batches || [];
    const rows = list.map((b) => `<tr data-batch="${b.id}" style="cursor:pointer">
        <td class="nowrap mono">${esc(b.received_at)}</td>
        <td><b>${esc(b.title || b.batch_no)}</b><div class="muted" style="font-size:11.5px">${esc(b.batch_no)}</div></td>
        <td class="nowrap">${b.stage ? `<span class="tag tag-blue">${esc(b.stage)}</span>` : '<span class="muted">—</span>'}</td>
        <td class="nowrap">${esc(b.handover_by || '—')}</td>
        <td class="num">${Number(b.item_count) || 0}</td>
        <td class="num">${Number(b.scanned_pages) || 0}</td>
        <td class="nowrap">${b.status === '已归档'
    ? '<span class="tag tag-green">已归档</span>' : '<span class="tag tag-amber">接收中</span>'}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="empty">这个项目还没交过资料</td></tr>';
    const body = el('div', {}, `
      <div class="hint-box">${esc(p.project_no)}　${esc(p.name)}　${esc(p.kind || '')}　${esc(p.status || '')}
        <br>共 ${list.length} 批。点某一行看件清单、打印交接单、归档定稿。</div>
      <div class="table-wrap"><table><thead><tr>
        <th>录入日期</th><th>批次</th><th>阶段</th><th>交件人</th><th>件数</th><th>扫描页</th><th>状态</th>
      </tr></thead><tbody>${rows}</tbody></table></div>`);
    const foot = [btn('关闭', '', () => modal.close())];
    if (can('archive:create')) {
      foot.push(btn('＋ 登记一批', 'btn-primary', () => { modal.close(); newBatchDialog(p.id); }));
    }
    modal.open(`项目 ${p.project_no}`, body, foot, { wide: true });
    body.querySelectorAll('[data-batch]').forEach((tr) => {
      tr.onclick = () => { modal.close(); openBatchDialog(Number(tr.dataset.batch)); };
    });
  }

  // ---------------- 下载审批 ----------------
  /**
   * 下载审批（v11 起就有的能力，但此前只有接口，界面上点不到）。
   * 申请是从「电子附件 → 下载」发起的：需要审批时，点下载会自动生成一张申请。
   * 这里负责**审批侧**：谁能批、批多久、能下几次。
   */
  const DL_STATUS = { 待审批: 'tag-blue', 已批准: 'tag-green', 已拒绝: 'tag-gray', 已过期: 'tag-red' };

  async function renderDownloads(params) {
    const status = (params && params.status) || '待审批';
    const r = await api('/api/download-grants?status=' + encodeURIComponent(status) + '&size=50');
    const pol = r.policy || {};
    const c = $('#content');
    const canApprove = ['admin', 'sysadmin', 'secadmin', 'clerk'].includes(state.user.role);

    const rows = (r.list || []).map((g) => `
      <tr>
        <td class="code">${esc(g.grant_no || '')}</td>
        <td>${esc(g.archive_code || '')}<br><span class="muted">${esc((g.title || '').slice(0, 24))}</span></td>
        <td>${esc(g.user_name || g.username || '')}</td>
        <td class="muted">${esc((g.purpose || '').slice(0, 20))}</td>
        <td><span class="tag ${DL_STATUS[g.status] || 'tag'}">${esc(g.status || '')}</span></td>
        <td class="nowrap muted">${g.read_to ? esc(String(g.read_to).slice(0, 16).replace('T', ' ')) : '—'}</td>
        <td class="num">${g.used_times === undefined ? '—' : esc(String(g.used_times))}${g.max_times ? ' / ' + esc(String(g.max_times)) : ''}</td>
        <td class="muted" style="font-size:12px">${esc(g.state_reason || '')}</td>
        <td class="nowrap">${canApprove && g.status === '待审批' ? `
          <button class="btn btn-sm btn-primary" data-dact="ok" data-did="${g.id}">批准</button>
          <button class="btn btn-sm btn-danger" data-dact="no" data-did="${g.id}">驳回</button>` : ''}</td>
      </tr>`).join('') || '<tr><td colspan="9" class="empty">没有记录</td></tr>';

    const tab = (k, label) => `<button class="btn btn-sm${status === k ? ' btn-primary' : ''}" data-dtab="${k}">${label}</button>`;

    c.innerHTML = `
      <div class="card">
        <div class="card-head"><h3>下载审批 <span class="sub">共 ${r.total} 条</span></h3>
          <div class="flex">${tab('待审批', '待审批')}${tab('已批准', '已批准')}${tab('已拒绝', '已拒绝')}${tab('', '全部')}</div></div>
        <div class="hint-box">
          ${pol.requireApproval
    ? '当前<b>已开启下载审批</b>：用户在「电子附件」里点下载会先生成一张申请，批准后才能取件。'
    : '当前<b>未开启下载审批</b>：下载直接放行（此页仍会记录凭据与次数，便于追溯）。'}
          <br>默认有效期 ${esc(String(pol.defaultValidHours))} 小时 · 默认次数 ${esc(String(pol.maxTimesDefault))} 次
          · 利用水印${pol.watermarkEnabled ? '已开启' : '未开启'}${pol.readWindowEnforced ? ' · 授权阅读时间窗已开启' : ''}
        </div>
        <div class="table-wrap"><table><thead><tr>
          <th>凭据编号</th><th>档案</th><th>申请人</th><th>用途</th><th>状态</th><th>有效期至</th><th class="num">已下/上限</th><th>说明</th><th></th>
        </tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;

    $$('#content [data-dtab]').forEach((b) => {
      b.onclick = () => setView('downloads', { status: b.dataset.dtab });
    });
    $$('#content [data-dact]').forEach((b) => {
      b.onclick = () => {
        const id = Number(b.dataset.did);
        if (b.dataset.dact === 'no') {
          promptDialog('驳回下载申请', [{ name: 'note', label: '驳回理由（会记入凭据与审计）', required: true, span2: true }],
            async (d) => {
              await api('/api/download-grants/' + id + '/approve', { method: 'POST', body: { approve: false, note: d.note } });
              toast('已驳回', 'ok');
              setView('downloads', { status });
            });
          return;
        }
        promptDialog('批准下载申请', [
          { name: 'valid_hours', label: '有效小时数', value: String(pol.defaultValidHours || 24) },
          { name: 'max_times', label: '允许下载次数', value: String(pol.maxTimesDefault || 1) },
          { name: 'note', label: '审批意见', span2: true },
        ], async (d) => {
          await api('/api/download-grants/' + id + '/approve', {
            method: 'POST',
            body: { approve: true, valid_hours: Number(d.valid_hours) || 24, max_times: Number(d.max_times) || 1, note: d.note || '' },
          });
          toast('已批准', 'ok');
          setView('downloads', { status });
        });
      };
    });
  }

  async function renderRetention(params) {
    const isClerk = state.user.role !== 'reader';
    if (!isClerk) {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>到期与鉴定需要档案员及以上权限</div></div>';
      return;
    }
    // 五个页签对应**三种法定不同的鉴定**（价值/密级/开放）＋批次文据＋销毁清册。
    // 为什么不合成一个"鉴定"按钮：三者的触发条件（期限届满 vs 满 25 年）、
    // 可选结论、以及"谁有权决定"都不一样（解密要定密责任人、开放要馆领导）。
    // 混在一起的结果就是"到期了顺手点一下"，而该不该解密、该不该开放都是要单独签字的事。
    const tab = (params && params.tab) === 'due' ? 'value' : ((params && params.tab) || 'value');
    const TAB_DEFS = [
      ['value', '价值鉴定'], ['secret', '密级鉴定'], ['open', '开放鉴定'],
      ['batch', '鉴定批次'], ['destroy', '销毁清册'],
    ];
    const head = `<div class="card"><div class="card-head"><h3>鉴定工作台</h3>
      <div class="flex">
        ${TAB_DEFS.map(([k, n]) => `<button class="btn btn-sm${tab === k ? ' btn-primary' : ''}" data-rtab="${k}">${n}</button>`).join('')}
      </div></div></div>`;

    if (tab === 'destroy') {
      const d = await api('/api/destructions');
      const rows = d.list.map((r) => `
        <tr><td class="code">${esc(r.batch_no)}</td><td>${esc(r.title)}</td>
        <td class="num">${r.archive_count}</td>
        <td>${destroyStatusTag(r.status)}</td>
        <td class="nowrap muted">${esc(r.applicant || '')}</td>
        <td class="nowrap muted">${fmtDay(r.applied_at)}</td>
        <td class="nowrap muted">${esc(r.supervisor || '')}</td>
        <td class="nowrap">
          <button class="btn btn-sm" data-dact="view" data-did="${r.id}">明细</button>
          ${r.status === '待审批' && state.user.role === 'admin' ? `<button class="btn btn-sm btn-primary" data-dact="approve" data-did="${r.id}">审批</button>` : ''}
          ${r.status === '已批准' ? `<button class="btn btn-sm btn-primary" data-dact="exec" data-did="${r.id}">执行销毁</button>` : ''}
          <button class="btn btn-sm" data-dact="print" data-did="${r.id}">打印清册</button>
        </td></tr>`).join('')
        || '<tr><td colspan="8" class="empty"><b>暂无销毁批次</b>在「到期提醒」里对到期档案作出“建议销毁”结论后，即可提交销毁清册</td></tr>';

      $('#content').innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>销毁清册 <span class="sub">待审批 ${d.counts.pending} · 已批准 ${d.counts.approved} · 已销毁 ${d.counts.done}</span></h3>
            <button class="btn btn-sm btn-primary" id="btn-new-batch">＋ 提交销毁清册（待销毁 ${d.counts.candidate} 件）</button></div>
          <div class="hint-box">销毁流程：鉴定作出“建议销毁”结论 → 提交销毁清册 → 管理员审批（须指定监销人）→ 执行销毁并留档。销毁后的档案从馆藏移除，但清册条目永久保留作为凭据。</div>
          <div class="table-wrap"><table><thead><tr>
            <th>批次号</th><th>批次名称</th><th class="num">件数</th><th>状态</th><th>申请人</th><th>申请日期</th><th>监销人</th><th>操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;

      $('#btn-new-batch').onclick = async () => {
        const cand = await api('/api/archives?status=' + encodeURIComponent('待销毁') + '&size=200');
        if (!cand.total) return toast('当前没有“待销毁”状态的档案，请先在到期清单中作出鉴定结论', 'warn');
        promptDialog('提交销毁清册', [
          { name: 'title', label: '批次名称', value: `销毁批次（${cand.total} 件）` },
          { name: 'reason', label: '销毁原因', type: 'textarea', value: '已超过保管期限，经鉴定无继续保存价值' },
          { name: 'basis', label: '销毁依据', value: '《档案法》及本单位档案保管期限表' },
        ], async (data) => {
          const r = await api('/api/destructions', { method: 'POST', body: data });
          toast(`已生成销毁清册 ${r.batch_no}（${r.count} 件），等待审批`, 'ok');
          setView('retention', { tab: 'destroy' });
        }, { wide: true });
      };

      $$('#content [data-dact]').forEach((b) => {
        const did = Number(b.dataset.did);
        b.onclick = async () => {
          const act = b.dataset.dact;
          if (act === 'print') return void window.open(`/api/destructions/${did}/print`, '_blank');
          if (act === 'view') {
            const d2 = await api('/api/destructions/' + did);
            const items = d2.items.map((it, i) => `<tr><td>${i + 1}</td><td class="code">${esc(it.archive_number || '')}</td>
              <td class="code">${esc(it.archive_code)}</td><td>${esc(it.title)}</td>
              <td>${esc(it.year)}</td><td>${esc(it.retention)}</td><td>${esc(it.action)}</td></tr>`).join('');
            modal.open(`销毁清册明细 ${d2.batch_no}`, el('div', {}, `
              <div class="dl" style="grid-template-columns:1fr">
                <div><span class="k">状态</span><span class="v">${esc(d2.status)}</span></div>
                <div><span class="k">申请人</span><span class="v">${esc(d2.applicant)} ${esc(fmtDay(d2.applied_at))}</span></div>
                <div><span class="k">审批人</span><span class="v">${esc(d2.approver || '')} ${d2.approved_at ? esc(fmtDay(d2.approved_at)) : ''}</span></div>
                <div><span class="k">监销人</span><span class="v">${esc(d2.supervisor || '')}${d2.witness ? '　见证人：' + esc(d2.witness) : ''}</span></div>
                ${d2.destroyed_at ? `<div><span class="k">销毁时间</span><span class="v">${fmtTime(d2.destroyed_at)}</span></div>` : ''}
              </div>
              <div class="section-title">销毁清单（${d2.items.length} 件）</div>
              <div class="table-wrap"><table><thead><tr><th>#</th><th>档号</th><th>档案号</th><th>题名</th><th>年度</th><th>保管期限</th><th>状态</th></tr></thead>
              <tbody>${items}</tbody></table></div>`), [
              btn('打印清册', '', () => window.open(`/api/destructions/${did}/print`, '_blank')),
              btn('关闭', 'btn-primary', () => modal.close()),
            ], { wide: true });
            return;
          }
          if (act === 'approve') {
            promptDialog('审批销毁清册', [
              { name: 'supervisor', label: '监销人（必须填写）', required: true, placeholder: '按档案管理规定须有监销人在场' },
              { name: 'witness', label: '见证人' },
              { name: 'note', label: '审批意见' },
            ], async (data) => {
              await api(`/api/destructions/${did}/approve`, { method: 'POST', body: { approve: true, ...data } });
              toast('已批准销毁', 'ok');
              setView('retention', { tab: 'destroy' });
            });
            return;
          }
          if (act === 'exec') {
            confirmDialog('执行销毁', '执行后所选档案将从馆藏中移除（清册条目保留作为凭据），该操作不可撤销。确定继续吗？', async () => {
              const r = await api(`/api/destructions/${did}/execute`, { method: 'POST', body: { note: '已按规程销毁' } });
              toast(`已销毁 ${r.destroyed} 件档案`, 'ok');
              setView('retention', { tab: 'destroy' });
            }, '确认销毁');
          }
        };
      });
      $$('#content [data-rtab]').forEach((b) => { b.onclick = () => setView('retention', { tab: b.dataset.rtab }); });
      return;
    }

    // ================= 鉴定批次：文据台账 =================
    if (tab === 'batch') {
      const d = await api('/api/appraisal/batches');
      const KIND_TAG = { 价值鉴定: 'tag-blue', 密级鉴定: 'tag-amber', 开放鉴定: 'tag-green' };
      const rows = d.list.map((b) => `
        <tr data-bid="${b.id}">
          <td class="code">${esc(b.batch_no)}</td>
          <td class="nowrap"><span class="tag ${KIND_TAG[b.kind] || 'tag'}">${esc(b.kind)}</span></td>
          <td>${esc(b.title)}</td>
          <td class="num">${b.item_count || b.archive_count}</td>
          <td>${esc(b.summary || b.conclusion || '')}</td>
          <td class="nowrap muted">${esc(b.meeting_date || '')}</td>
          <td class="nowrap muted">${esc(b.organizer || '')}</td>
          <td class="nowrap muted">${esc(b.approver || '')}</td>
          <td class="nowrap">
            <button class="btn btn-sm" data-bact="view">明细</button>
            <button class="btn btn-sm" data-bact="print">打印文据</button>
          </td>
        </tr>`).join('') || '<tr><td colspan="9" class="empty"><b>暂无鉴定批次</b>在「价值鉴定 / 密级鉴定 / 开放鉴定」页签里勾选档案后点「组织鉴定」，即生成一份带签字的《档案鉴定意见书》与清册</td></tr>';
      $('#content').innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>鉴定批次台账 <span class="sub">共 ${d.total} 个批次</span></h3></div>
          <div class="hint-box">一个批次 = 一次鉴定小组会议 ＋ 一份《档案鉴定意见书》。逐件散落的记录证明不了"这批档案是哪次会上定的、谁签的字"。<b>批次是不可修改的记录</b>：鉴定错了只能重新鉴定一次，两次记录都保留 —— 档案工作里没有"撤销鉴定"这回事。</div>
          <div class="table-wrap"><table><thead><tr>
            <th class="nowrap">批次号</th><th>类别</th><th>批次名称</th><th class="num">件数</th><th>结论分布</th>
            <th class="nowrap">鉴定日期</th><th class="nowrap">组织部门</th><th class="nowrap">审核人</th><th class="nowrap">操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;
      $$('#content [data-rtab]').forEach((b) => { b.onclick = () => setView('retention', { tab: b.dataset.rtab }); });
      $$('#content tr[data-bid]').forEach((tr) => {
        const bid = Number(tr.dataset.bid);
        tr.querySelectorAll('[data-bact]').forEach((btnEl) => {
          btnEl.onclick = async () => {
            if (btnEl.dataset.bact === 'print') return void window.open(`/api/appraisal/batches/${bid}/print`, '_blank');
            const d2 = await api('/api/appraisal/batches/' + bid);
            const items = d2.items.map((p, i) => `<tr><td>${i + 1}</td>
              <td class="code">${esc(p.archive_number || p.archive_code || '')}</td>
              <td>${esc(p.title || '')}</td><td>${esc(p.year || '')}</td>
              <td>${esc(p.decision)}</td>
              <td class="nowrap muted">${esc(p.appraiser_name || '')}</td></tr>`).join('')
              || '<tr><td colspan="6" class="muted">没有你可查看的条目</td></tr>';
            modal.open(`鉴定批次明细 ${d2.batch.batch_no}`, el('div', {}, `
              <div class="dl mb8">
                <div><span>类别</span><b>${esc(d2.batch.kind)}</b></div>
                <div><span>鉴定日期</span><b>${esc(d2.batch.meeting_date || '—')}</b></div>
                <div><span>鉴定小组</span><b>${esc(d2.batch.members || '—')}（${d2.batch.member_count || 0} 人）</b></div>
                <div><span>审核人</span><b>${esc(d2.batch.approver || '—')} ${esc(d2.batch.approved_at || '')}</b></div>
                <div><span>依据</span><b>${esc(d2.batch.basis || '—')} ${esc(d2.batch.basis_ref || '')}</b></div>
                <div><span>结论</span><b>${esc(d2.batch.summary || '—')}</b></div>
              </div>
              ${d2.hidden ? `<div class="hint-box warn">本批次另有 ${d2.hidden} 件超出你的密级权限，未列入明细（档号与题名本身就涉密）。</div>` : ''}
              <div class="table-wrap"><table><thead><tr><th>#</th><th>档号</th><th>题名</th><th>年度</th><th>结论</th><th>鉴定人</th></tr></thead>
              <tbody>${items}</tbody></table></div>`), [
              btn('关闭', '', () => modal.close()),
              btn('打印意见书与清册', 'btn-primary', () => window.open(`/api/appraisal/batches/${bid}/print`, '_blank')),
            ], { wide: true });
          };
        });
      });
      return;
    }

    // ================= 密级鉴定 / 开放鉴定 =================
    if (tab === 'secret' || tab === 'open') {
      const kind = tab === 'secret' ? '密级鉴定' : '开放鉴定';
      const wb = await api('/api/appraisals/workbench?kind=' + encodeURIComponent(kind));
      const c = wb.counts[kind];
      const canRun = kind === '密级鉴定' ? canSecretClassify() : canApproveAppraisal();
      const stats = tab === 'secret'
        ? [['已届满未鉴定', c.overdue, 'tag-red', '必须立即组织鉴定'], ['即将届满（90 天内）', c.soon, '', '需延长的应提前重定'],
          ['未登记保密期限', c.noreg, 'tag-amber', '无法判断何时解密'], ['涉密档案合计', c.total, '', '不含公开件']]
        : [['满 25 年未鉴定', c.pending, 'tag-amber', '《档案法》第二十七条'],
          ['已开放', c.open, 'tag-green', '可向社会提供利用'], ['部分开放', c.partial, 'tag-blue', '部分内容控制'],
          ['控制使用', c.controlled, 'tag-amber', '延期开放'], ['未满 25 年', c.notYet, '', `形成满 ${c.publicYears} 年后进入鉴定`]];
      const rows = wb.list.map((r) => {
        let extra;
        if (tab === 'secret') {
          const st = {
            overdue: ['<span class="tag tag-red">已届满</span>', r.secret_to],
            soon: ['<span class="tag tag-amber">即将届满</span>', r.secret_to],
            noreg: ['<span class="tag tag-gray">未登记期限</span>', '—'],
            ok: ['<span class="muted">期限内</span>', r.secret_to],
          }[r.due_state] || ['', ''];
          extra = `<td class="nowrap">${st[0]}</td>
            <td class="nowrap">${esc(r.secret_term || '—')}</td>
            <td class="nowrap">${esc(st[1] || '—')}</td>`;
        } else {
          extra = `<td class="nowrap">${openTag(r.open_state)}</td>
            <td class="nowrap">${r.open_due_year || '—'} 年</td>`;
        }
        return `<tr data-aid="${r.id}">
          <td>${canRun ? `<input type="checkbox" class="apr-pick" value="${r.id}">` : ''}</td>
          <td class="code">${esc(r.archive_number || r.archive_code)}</td>
          <td><div style="font-weight:500">${esc(r.title)}</div>
              <div class="muted" style="font-size:12px">${esc(r.category_name || '')} · ${esc(r.archive_code)}</div></td>
          <td class="nowrap">${secretTag(r.secret_level)}</td>
          <td class="nowrap">${esc(r.year)}</td>
          ${extra}
          <td class="nowrap">${r.last_decision ? `<span class="tag tag-blue">${esc(r.last_decision)}</span>` : '<span class="muted">未鉴定</span>'}</td>
          <td class="nowrap">${canRun ? '<button class="btn btn-sm btn-primary" data-apr="one">鉴定</button>' : ''}
            <button class="btn btn-sm" data-apr="view">查看</button></td>
        </tr>`;
      }).join('') || `<tr><td colspan="9" class="empty"><b>${kind}当前没有待办条目</b>${tab === 'secret'
        ? '所有涉密档案都登记了保密期限、且都未进入届满提醒窗口' : `还没有档案形成满 ${c.publicYears} 年`}</td></tr>`;

      const guide = tab === 'secret'
        ? `保密期限届满应当组织<b>密级鉴定</b>：<b>解密</b>、<b>降低密级</b>，或<b>延长保密期限</b>（延长必须在期限届满前重新确定）。
           依据《保守国家秘密法》第十九条（期限届满<b>自行解密</b>）、第二十条；《国家秘密定密管理暂行规定》。
           系统**不会替你决定**解密与否 —— 也没有替你预设保密期限：存量档案没登记期限就是没登记，靠这份清单催办补录。`
        : `馆藏档案一般自形成之日起满 <b>${c.publicYears} 年</b>向社会开放（《档案法》第二十七条）；涉及国家安全或重大利益等
           到期不宜开放的，可以<b>延期开放</b>（第二十八条）。控制使用与延期开放<b>必须写明理由和延期日期</b>。
           <b>尚未解密的档案不能作出"开放"结论</b> —— 请先完成密级鉴定（先解密、后开放）。`;

      $('#content').innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>${kind}待办清单 <span class="sub">共 ${wb.total} 条</span></h3>
            <div class="flex">
              ${canRun ? `<button class="btn btn-sm btn-primary" id="btn-apr-batch" disabled>组织鉴定（已选 0 件）</button>` : ''}
              <button class="btn btn-sm" id="btn-apr-refresh">刷新</button>
            </div></div>
          <div class="hint-box">${guide}</div>
          <div class="grid ${tab === 'secret' ? 'grid-4' : 'grid-4'} mb16">
            ${stats.map(([label, val, cls, foot]) => `<div class="stat">
              <div class="stat-label">${label}</div>
              <div class="stat-value" ${cls === 'tag-red' ? 'style="color:var(--c-danger)"' : ''}>${val}</div>
              <div class="stat-foot">${foot}</div></div>`).join('')}
          </div>
          <div class="table-wrap"><table><thead><tr>
            <th style="width:34px"><input type="checkbox" id="apr-all"></th>
            <th>档号</th><th>题名 / 分类</th><th>密级</th><th>年度</th>
            ${tab === 'secret' ? '<th>期限状态</th><th>保密期限</th><th>届满日期</th>' : '<th>开放状态</th><th>满 25 年</th>'}
            <th>最近鉴定</th><th>操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;

      $$('#content [data-rtab]').forEach((b) => { b.onclick = () => setView('retention', { tab: b.dataset.rtab }); });
      $('#btn-apr-refresh').onclick = () => setView('retention', { tab });
      const picks = $$('#content .apr-pick');
      const batchBtn = $('#btn-apr-batch');
      const syncBtn = () => {
        const n = picks.filter((x) => x.checked).length;
        if (batchBtn) { batchBtn.disabled = n === 0; batchBtn.textContent = `组织鉴定（已选 ${n} 件）`; }
      };
      picks.forEach((x) => { x.onchange = syncBtn; });
      const all = $('#apr-all');
      if (all) all.onchange = () => { picks.forEach((x) => { x.checked = all.checked; }); syncBtn(); };
      if (batchBtn) batchBtn.onclick = () => openAppraisalBatchDialog(kind, picks.filter((x) => x.checked).map((x) => Number(x.value)));

      $$('#content tr[data-aid]').forEach((tr) => {
        const aid = Number(tr.dataset.aid);
        const rec = wb.list.find((x) => x.id === aid) || {};
        tr.querySelectorAll('[data-apr]').forEach((btnEl) => {
          btnEl.onclick = () => {
            if (btnEl.dataset.apr === 'view') return openArchiveDetail(aid);
            openAppraisalOneDialog(kind, rec);
          };
        });
      });
      return;
    }

    // 到期提醒
    const q = state.dueQuery || {};
    const p = new URLSearchParams(q);
    const d = await api('/api/retention/due?' + p.toString());
    const canAppraise = state.user.role !== 'reader';
    const rows = d.list.map((r) => {
      const overdue = Number(r.retention_due_year) < d.thisYear;
      const soon = r.retention_due_year === d.thisYear || r.retention_due_year === d.thisYear + 1;
      return `<tr data-aid="${r.id}">
        <td>${canAppraise ? `<input type="checkbox" class="apr-pick" value="${r.id}">` : ''}</td>
        <td class="code">${esc(r.archive_number || r.archive_code)}</td>
        <td><div style="font-weight:500">${esc(r.title)}</div>
            <div class="muted" style="font-size:12px">${esc(r.category_name || '')} · ${esc(r.archive_code)}</div></td>
        <td class="nowrap">${esc(r.retention)} <span class="muted">(${esc(r.retention_code || '')})</span></td>
        <td class="nowrap ${overdue ? '' : 'muted'}" ${overdue ? 'style="color:var(--c-danger);font-weight:600"' : ''}>${r.retention_due_year || '—'}</td>
        <td class="nowrap">${esc(r.year)}</td>
        <td class="nowrap">${statusTag(r.status)}</td>
        <td class="nowrap">${r.last_decision ? `<span class="tag tag-blue">${esc(r.last_decision)}</span>` : '<span class="muted">未鉴定</span>'}</td>
        <td class="nowrap">${canAppraise ? `<button class="btn btn-sm btn-primary" data-act="appraise">鉴定</button>
          <button class="btn btn-sm" data-act="view">查看</button>` : ''}</td>
      </tr>`;
    }).join('') || `<tr><td colspan="9" class="empty"><b>该时间段内没有到期的档案</b>可调整查询范围，或确认档案是否已设置定期保管期限</td></tr>`;

    $('#content').innerHTML = head + `
      <div class="card">
        <div class="card-head"><h3>保管期限到期提醒</h3>
          <div class="flex">
            ${canAppraise ? '<button class="btn btn-sm btn-primary" id="btn-apr-batch" disabled>组织鉴定（已选 0 件）</button>' : ''}
            <button class="btn btn-sm" id="btn-due-overdue">已过期</button>
            <button class="btn btn-sm" id="btn-due-this">今年到期</button>
            <button class="btn btn-sm" id="btn-due-3">近三年</button>
          </div></div>
        <div class="hint-box">到期档案应组织鉴定：<b>延长保管期限</b>（如 10 年延为 30 年）、<b>继续保管</b>，或<b>建议销毁</b>。作出“建议销毁”结论后，可在「销毁清册」中提交审批；勾选多件再点「组织鉴定」会生成一份带签字的《档案鉴定意见书》与清册。</div>
        <div class="grid grid-4 mb16">
          <div class="stat"><div class="stat-label">已过期未鉴定</div><div class="stat-value" style="color:var(--c-danger)">${d.counts.overdue}</div><div class="stat-foot">应立即组织鉴定</div></div>
          <div class="stat"><div class="stat-label">今年到期</div><div class="stat-value">${d.counts.thisYear}</div><div class="stat-foot">建议列入年度计划</div></div>
          <div class="stat"><div class="stat-label">明年到期</div><div class="stat-value">${d.counts.nextYear}</div><div class="stat-foot">提前准备</div></div>
          <div class="stat"><div class="stat-label">永久/长期保管</div><div class="stat-value">${d.counts.permanent}</div><div class="stat-foot">不参与到期鉴定</div></div>
        </div>
        <div class="card-head"><h3>清单 <span class="sub">${d.range.from} ~ ${d.range.to} 年度到期，共 ${d.total} 条</span></h3></div>
        <div class="table-wrap"><table><thead><tr>
          <th style="width:34px"><input type="checkbox" id="apr-all"></th>
          <th>档号</th><th>题名 / 分类</th><th>保管期限</th><th>到期年度</th><th>归档年度</th><th>状态</th><th>最近鉴定</th><th>操作</th>
        </tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;

    $('#btn-due-overdue').onclick = () => { state.dueQuery = { from: 1900, to: new Date().getFullYear() - 1 }; setView('retention'); };
    $('#btn-due-this').onclick = () => { state.dueQuery = { exact: '1', to: String(new Date().getFullYear()) }; setView('retention'); };
    $('#btn-due-3').onclick = () => { state.dueQuery = {}; setView('retention'); };
    $$('#content [data-rtab]').forEach((b) => { b.onclick = () => setView('retention', { tab: b.dataset.rtab }); });

    // 勾选 → 批量组织鉴定（与密级/开放页签共用一个对话框）
    const vPicks = $$('#content .apr-pick');
    const vBatchBtn = $('#btn-apr-batch');
    const vSync = () => {
      const n = vPicks.filter((x) => x.checked).length;
      if (vBatchBtn) { vBatchBtn.disabled = n === 0; vBatchBtn.textContent = `组织鉴定（已选 ${n} 件）`; }
    };
    vPicks.forEach((x) => { x.onchange = vSync; });
    const vAll = $('#apr-all');
    if (vAll) vAll.onchange = () => { vPicks.forEach((x) => { x.checked = vAll.checked; }); vSync(); };
    if (vBatchBtn) vBatchBtn.onclick = () => openAppraisalBatchDialog('价值鉴定', vPicks.filter((x) => x.checked).map((x) => Number(x.value)));

    $$('#content tr[data-aid]').forEach((tr) => {
      const aid = Number(tr.dataset.aid);
      const rec = d.list.find((x) => x.id === aid);
      tr.querySelectorAll('[data-act]').forEach((b) => {
        b.onclick = async () => {
          if (b.dataset.act === 'view') return openArchiveDetail(aid);
          // 单件鉴定统一走三鉴共用的对话框（结论枚举来自后端，字段随类别变化），
          // 这里不再各写一份硬编码的结论列表 —— 两份列表迟早会不一致
          openAppraisalOneDialog('价值鉴定', rec);
        };
      });
    });
  }

  /**
   * 三鉴的结论与字段定义。
   *
   * 优先用后端 /api/types 下发的枚举（单一事实来源），但**留一份兜底**：
   * 页面上的枚举是会话早期一次性加载并缓存的，若后端加了新结论而用户没刷新页面，
   * 下拉框就会缺项 —— 宁可多一份兜底，也不要让"解密"这个选项凭空消失。
   */
  function appraisalSpec(kind) {
    const d = (state.meta && state.meta.appraisalDecisions) || {};
    const FALLBACK = {
      价值鉴定: ['延长保管期限', '继续保管', '建议销毁'],
      密级鉴定: ['解密', '降低密级', '延长保密期限', '维持原密级'],
      开放鉴定: ['开放', '部分开放', '控制使用'],
    };
    return { conclusions: (d[kind] && d[kind].length) ? d[kind] : FALLBACK[kind] };
  }

  /** 三鉴共用的表单字段（批次与单件同一套，避免"批量按规范、单件漏一项"） */
  function appraisalFields(kind) {
    const spec = appraisalSpec(kind);
    const f = [
      { name: 'conclusion', label: '鉴定结论', type: 'select', required: true, value: spec.conclusions[0], options: spec.conclusions },
    ];
    if (kind === '价值鉴定') {
      f.push({ name: 'new_retention', label: '新的保管期限（选「延长保管期限」时必填）', type: 'select', value: '定期30年', options: state.meta.retentions || [] });
    } else if (kind === '密级鉴定') {
      f.push({ name: 'new_secret_level', label: '降低到哪一级（选「降低密级」时必填）', type: 'select', value: '内部', options: (state.meta.secretLevels || []).filter((s) => s !== '公开') });
      f.push({ name: 'new_secret_term', label: '新的保密期限（选「延长保密期限」时必填）', placeholder: '如 10年 / 30年 / 长期；也可直接填下面的届满日期' });
      f.push({ name: 'new_secret_to', label: '新的届满日期（可空，填了以它为准）', placeholder: 'YYYY-MM-DD' });
      f.push({ name: 'declassify_condition', label: '解密条件（选「解密」时填，写入档案）', span2: true, placeholder: '如：公开后不会对国家安全和利益造成损害' });
    } else {
      f.push({ name: 'control_reason', label: '控制使用 / 部分开放的理由与依据（非「开放」时必填）', type: 'textarea', rows: 2, span2: true, placeholder: '如：涉及个人隐私，按《各级国家档案馆馆藏档案解密和划分控制使用范围的暂行规定》第七条控制使用' });
      f.push({ name: 'open_delay_to', label: '延期开放至（选「控制使用」时必填）', placeholder: 'YYYY-MM-DD' });
      f.push({ name: 'open_scope_note', label: '部分开放的范围说明（选「部分开放」时填）', placeholder: '如：正文开放，附表与人员名单控制使用' });
    }
    f.push(
      { name: 'basis', label: '鉴定依据 / 理由', span2: true, placeholder: kind === '价值鉴定' ? '如：仍有查考利用价值，参照本单位保管期限表第 X 条' : '如：经审核不再属于国家秘密事项' },
      { name: 'basis_ref', label: '依据条款', span2: true, placeholder: kind === '密级鉴定' ? '如：《保守国家秘密法》第十九条' : (kind === '开放鉴定' ? '如：《档案法》第二十七条' : '如：国家档案局令第 8 号附件') },
      { name: 'group_opinion', label: '鉴定小组意见 / 说明', type: 'textarea', rows: 2, span2: true },
      { name: 'members', label: '鉴定小组成员', placeholder: '姓名，顿号分隔' },
      { name: 'member_count', label: '参加鉴定人数', value: '3' },
      { name: 'meeting_date', label: '鉴定日期', value: new Date().toISOString().slice(0, 10) },
      { name: 'organizer', label: '组织鉴定部门', value: (state.user && state.user.department) || '档案室' },
      { name: 'approver', label: kind === '密级鉴定' ? '审核人（定密责任人）' : '审核人（馆领导）' },
      { name: 'approved_at', label: '审核同意日期', placeholder: 'YYYY-MM-DD' },
    );
    return f;
  }

  /**
   * 组织鉴定（批量）：一次鉴定小组会议 → 一个鉴定批次 → 一份可打印的意见书与清册。
   *
   * 批量只给**一个统一结论**：真实鉴定中同一批次结论通常一致；
   * 个别不同就单独做一次单件鉴定 —— 硬要在一个表单里逐件选结论，
   * 反而容易把"没细看的那几件"顺手归到同一类里。
   */
  function openAppraisalBatchDialog(kind, ids) {
    if (!ids.length) return toast('请先勾选要鉴定的档案', 'warn');
    promptDialog(`组织鉴定：${kind}（${ids.length} 件）`, [
      { name: 'title', label: '批次名称', value: `${kind}批次（${ids.length} 件）`, span2: true },
      { name: 'scope_note', label: '鉴定范围说明', span2: true, placeholder: '如：2026 年度到期的文书档案' },
    ].concat(appraisalFields(kind)), async (data) => {
      const r = await api('/api/appraisal/batches', {
        method: 'POST',
        body: Object.assign({ archive_ids: ids, kind }, data),
      });
      toast(`已生成鉴定批次 ${r.batch_no}：${r.summary}`
        + (r.skipped && r.skipped.length ? `；跳过 ${r.skipped.length} 件` : ''), 'ok', 7000);
      // modal 只有一个实例，必须等它关掉再切页签重绘
      setTimeout(() => setView('retention', { tab: 'batch' }), 150);
    }, { okText: '生成意见书', wide: true });
  }

  /** 单件鉴定：同上，只是批次里只有一件（不生成批次文据，记录进该件的鉴定历史） */
  function openAppraisalOneDialog(kind, rec) {
    const tip = rec && rec.title ? `：${String(rec.title).slice(0, 20)}` : '';
    promptDialog(`${kind}${tip}`, appraisalFields(kind), async (data) => {
      await api(`/api/archives/${rec.id}/appraise`, { method: 'POST', body: Object.assign({ kind }, data) });
      toast(`${kind}结论已记录`, 'ok');
      setTimeout(() => setView('retention', { tab: kind === '密级鉴定' ? 'secret' : (kind === '开放鉴定' ? 'open' : 'value') }), 150);
    }, { okText: '记录结论', wide: true });
  }

  function destroyStatusTag(s) {
    const cls = { '待审批': 'tag-blue', '已批准': 'tag-amber', '已拒绝': 'tag-gray', '已销毁': 'tag-red' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s)}</span>`;
  }

  // ---------------- 实体管理 ----------------
  /**
   * 扫码自检。
   * 二维码「扫不出来」有三种完全不同的原因，必须分开：
   *   ①二维码本身生成错（图案不规范，任何手机都扫不出）
   *   ②二维码里写的是手机打不开的地址（127.0.0.1）
   *   ③服务没开局域网 / 手机不在同一网段 / 防火墙拦截
   * 这个面板把当前可用地址全部列出来让用户现场试扫，一眼就能分清是哪一种。
   */
  async function openScanCheck() {
    const net = await api('/api/system/net');
    const urls = (net.candidates && net.candidates.length) ? net.candidates.map((c) => c.url) : [net.base_url];
    const uniq = [...new Set(urls)];
    const blocks = uniq.map((u) => `
      <div style="text-align:center;margin:0 0 18px">
        <img src="/api/qrcode.svg?text=${encodeURIComponent(u + '/api/s/TEST-001')}&px=320" alt="二维码"
             style="width:auto;height:auto;max-width:100%;image-rendering:pixelated">
        <div class="mono" style="font-size:12px;word-break:break-all">${esc(u)}</div>
      </div>`).join('');
    const warn = net.lan_open ? ''
      : `<div class="hint-box warn">当前服务只监听本机（${esc(net.bind_host)}），手机在局域网里连不上。
         请关闭本窗口后双击「局域网访问.bat」重新启动。</div>`;
    modal.open('扫码自检', el('div', {}, `
      ${warn}
      <div class="hint-box">用手机相机扫下面的二维码：<b>能扫出内容</b>说明二维码本身没问题，问题在网络；
      <b>完全扫不出</b>说明是相机对焦、打印尺寸或清晰度的问题。<br>
      系统探测到 ${uniq.length} 个可用地址，多网卡时请挑与手机同一网段的那个。</div>
      ${blocks}
      <div class="help">手机打不开时的排查顺序：①手机与电脑是否同一 WiFi／同一网段；
      ②Windows 防火墙是否放行 ${esc(String(net.port))} 端口；③是否用「局域网访问.bat」启动。<br>
      分不清是「码扫不出」还是「网址打不开」？<a href="/api/qrcode/selftest" target="_blank">打开二维码自检页</a>，用手机扫上面那两个码即可一步定位。<br>
      手机浏览器直接敲这个地址也能一步确认网络通不通：
      <span class="mono">${esc(net.base_url)}/api/ping</span>（看到 OK 就是通的）。</div>
      <div class="hint-box warn" style="margin-top:10px">
        <b>要在盒子/卷皮上印二维码，先解决「地址会不会变」。</b><br>
        二维码印出去就改不了了。如果这台机器的 IP 是自动获取的（DHCP），哪天变了，
        已经贴出去的二维码会<b>一起失效、需要重印</b>。<br>
        彻底的办法只有一个：让网络管理员做<b>内网 DNS 记录</b>（IP 变了只改 DNS，旧标签永久有效）
        或做 <b>DHCP 保留</b>（按网卡 MAC 固定 IP）。
        <a href="/api/system/address-request" target="_blank">点这里生成给 IT 的申请单</a>（自动填好计算机名/MAC/IP/端口，可打印可复制）。</div>`), [
      btn('固定地址申请单', 'btn-primary', () => window.open('/api/system/address-request', '_blank')),
      btn('扫码自检页', '', () => window.open('/api/qrcode/selftest', '_blank')),
      btn('关闭', '', () => modal.close()),
    ], { narrow: true });
  }

  async function renderStorage(params) {
    const isClerk = state.user.role !== 'reader';
    if (!isClerk) {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>实体管理需要档案员及以上权限</div></div>';
      return;
    }
    const tab = (params && params.tab) || 'boxes';
    const head = `<div class="card"><div class="card-head"><h3>实体管理</h3>
      <div class="flex">
        <button class="btn btn-sm${tab === 'boxes' ? ' btn-primary' : ''}" data-stab="boxes">档案盒</button>
        <button class="btn btn-sm${tab === 'locations' ? ' btn-primary' : ''}" data-stab="locations">库位</button>
        <button class="btn btn-sm${tab === 'checks' ? ' btn-primary' : ''}" data-stab="checks">盘点</button>
      </div></div></div>`;


    if (tab === 'locations') {
      const d = await api('/api/locations');
      const rows = d.list.map((l) => `
        <tr><td class="code">${esc(l.code)}</td><td>${esc(l.name)}</td>
        <td>${esc(l.library || '')}</td><td>${esc(l.shelf || '')}</td><td>${esc(l.layer || '')}</td>
        <td class="num">${l.capacity || '不限'}</td>
        <td class="num">${l.box_count}</td><td class="num">${l.archive_count}</td>
        <td class="muted">${esc(l.remark || '')}</td>
        <td class="nowrap">
          <button class="btn btn-sm" data-lact="print" data-lid="${l.id}">打印盒签</button>
          <button class="btn btn-sm btn-danger" data-lact="del" data-lid="${l.id}">删除</button>
        </td></tr>`).join('') || '<tr><td colspan="10" class="empty">还没有库位，先新增一个（如「A库-A1-3」）</td></tr>';
      $('#content').innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>库位管理 <span class="sub">共 ${d.list.length} 个</span></h3>
            <button class="btn btn-sm btn-primary" id="btn-add-loc">＋ 新增库位</button></div>
          <div class="hint-box">库位是档案的物理存放位置（如 A库-A1-3 表示 A库 A1 排第 3 层）。档案装盒后会自动继承盒所在库位，用于排架与盘点。</div>
          <div class="table-wrap"><table><thead><tr>
            <th>库位编号</th><th>名称</th><th>库房</th><th>排/架</th><th>层</th><th class="num">容量(盒)</th>
            <th class="num">盒数</th><th class="num">档案数</th><th>备注</th><th>操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;
      $('#btn-add-loc').onclick = () => promptDialog('新增库位', [
        { name: 'code', label: '库位编号', required: true, placeholder: '如 A库-A1-3' },
        { name: 'name', label: '库位名称', placeholder: '留空则与编号相同' },
        { name: 'library', label: '库房', placeholder: '如 A库' },
        { name: 'shelf', label: '排 / 架', placeholder: '如 A1' },
        { name: 'layer', label: '层', placeholder: '如 3' },
        { name: 'capacity', label: '可容纳盒数（0 表示不限）', value: '0' },
        { name: 'remark', label: '备注' },
      ], async (data) => {
        await api('/api/locations', { method: 'POST', body: data });
        toast('已新增库位', 'ok');
        setView('storage', { tab: 'locations' });
      }, { wide: true });
      $$('#content [data-lact]').forEach((b) => {
        const lid = Number(b.dataset.lid);
        b.onclick = async () => {
          if (b.dataset.lact === 'print') {
            const boxes = await api('/api/boxes?location=' + lid);
            if (!boxes.list.length) return toast('该库位下还没有档案盒', 'warn');
            boxes.list.slice(0, 8).forEach((bx) => window.open(`/api/print/box/${bx.id}`, '_blank'));
            return;
          }
          confirmDialog('删除库位', '确定删除该库位吗？', async () => {
            await api('/api/locations/' + lid, { method: 'DELETE' });
            toast('已删除', 'ok');
            setView('storage', { tab: 'locations' });
          }, '确认删除');
        };
      });
      $$('#content [data-stab]').forEach((b) => { b.onclick = () => setView('storage', { tab: b.dataset.stab }); });
      return;
    }

    if (tab === 'checks') {
      const d = await api('/api/stock-checks');
      const rows = d.list.map((c) => `
        <tr><td class="code">${esc(c.check_no)}</td><td>${esc(c.title)}</td><td>${esc(c.scope)}</td>
        <td>${c.status === '已完成' ? '<span class="tag tag-green">已完成</span>' : '<span class="tag tag-blue">进行中</span>'}</td>
        <td class="num">${c.checked}</td>
        <td class="num" ${c.missing ? 'style="color:var(--c-danger)"' : ''}>${c.missing}</td>
        <td class="num">${c.mislocated}</td>
        <td class="nowrap muted">${esc(c.operator || '')}</td>
        <td class="nowrap muted">${fmtDay(c.started_at)}</td>
        <td class="nowrap">
          <button class="btn btn-sm" data-cact="open" data-cid="${c.id}">${c.status === '进行中' ? '继续盘点' : '查看'}</button>
          <button class="btn btn-sm" data-cact="print" data-cid="${c.id}">打印结果</button>
        </td></tr>`).join('') || '<tr><td colspan="10" class="empty">还没有盘点任务，点右上角新建一个</td></tr>';
      $('#content').innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>盘点任务</h3>
            <button class="btn btn-sm btn-primary" id="btn-add-check">＋ 新建盘点</button></div>
          <div class="hint-box">盘点流程：新建盘点任务 → 用扫码枪或手工输入档案号/档号核对 → 完成后系统自动统计「在架 / 缺失 / 位置不符」，可打印结果表签字归档。</div>
          <div class="table-wrap"><table><thead><tr>
            <th>盘点单号</th><th>名称</th><th>范围</th><th>状态</th><th class="num">在架</th>
            <th class="num">缺失</th><th class="num">位置不符</th><th>盘点人</th><th>开始日期</th><th>操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;
      $('#btn-add-check').onclick = () => promptDialog('新建盘点任务', [
        { name: 'title', label: '任务名称', placeholder: '如 2026 年度库房盘点' },
        { name: 'scope', label: '盘点范围', value: '全部在库档案' },
        { name: 'type_code', label: '限定门类（可留空）', type: 'select', value: '', options: [{ value: '', label: '全部门类' }].concat(state.types.map((t) => ({ value: t.code, label: t.name }))) },
      ], async (data) => {
        const r = await api('/api/stock-checks', { method: 'POST', body: data });
        toast(`已创建盘点任务 ${r.check_no}（${r.total} 件）`, 'ok');
        setView('storage', { tab: 'checks' });
      }, { wide: true });
      $$('#content [data-cact]').forEach((b) => {
        const cid = Number(b.dataset.cid);
        b.onclick = () => {
          if (b.dataset.cact === 'print') return void window.open(`/api/stock-checks/${cid}/print`, '_blank');
          openStockCheck(cid);
        };
      });
      $$('#content [data-stab]').forEach((b) => { b.onclick = () => setView('storage', { tab: b.dataset.stab }); });
      return;
    }

    // 档案盒
    const d = await api('/api/boxes');
    const rows = d.list.map((b) => `
      <tr><td class="code">${esc(b.box_code)}</td><td>${esc(b.title || '')}</td>
      <td class="nowrap"><span class="tag tag-blue">${esc(b.type_code || '')}</span> ${esc(b.year || '')}</td>
      <td class="nowrap">${b.location_code ? esc(b.location_code) : '<span class="muted">未上架</span>'}</td>
      <td class="num">${b.archive_count} / ${b.capacity}</td>
      <td class="nowrap">
        <button class="btn btn-sm" data-bact="print" data-bid="${b.id}">打印盒脊/卷内目录</button>
        <button class="btn btn-sm" data-bact="beikao" data-bid="${b.id}">备考表</button>
        <button class="btn btn-sm" data-bact="qr" data-bid="${b.id}" data-code="${esc(b.box_code)}" data-qrtext="${esc(b.qr_text || b.box_code)}">二维码</button>
        <button class="btn btn-sm" data-bact="assign" data-bid="${b.id}">装盒</button>
        <button class="btn btn-sm btn-danger" data-bact="del" data-bid="${b.id}">删除</button>
      </td></tr>`).join('') || '<tr><td colspan="6" class="empty">还没有档案盒，点右上角新增</td></tr>';
    $('#content').innerHTML = head + `
      <div class="card">
        <div class="card-head"><h3>档案盒管理 <span class="sub">共 ${d.total} 个</span></h3>
          <button class="btn btn-sm btn-primary" id="btn-add-box">＋ 新增档案盒</button></div>
        <div class="hint-box">档案盒号与实体盒一一对应，<b>每个盒子一张不同的二维码</b>（内容由盒的内部编号决定，改盒号不会让已打印的标签失效）。
          打印盒脊标签时会带上二维码，手机扫码即可看到盒号与库位；装盒后盒内档案的存放位置会自动更新。</div>
        <div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <button class="btn btn-sm" id="btn-boxqr-all">生成全部盒二维码</button>
          <button class="btn btn-sm btn-primary" id="btn-boxqr-zip">打包下载全部盒二维码（ZIP）</button>
          <span class="muted" id="boxqr-stats" style="font-size:13px"></span>
        </div>
        <div class="table-wrap"><table><thead><tr>
          <th>盒号</th><th>盒标题</th><th>门类/年度</th><th>存放库位</th><th class="num">已装/容量</th><th>操作</th>
        </tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;

    // ---- 批量生成 / 打包下载全部盒二维码 ----
    const boxStats = async () => {
      const el2 = $('#boxqr-stats');
      if (!el2) return;
      try {
        const s = await api('/api/boxes/qrcodes/stats');
        el2.innerHTML = `已生成 <b>${s.images}</b> / ${s.boxes} 张`
          + `（每张按 <b>${s.ec_level}</b> 级纠错、静区 ${s.margin}、模块 ${s.scale}px）`
          + (s.missing ? ` · <b style="color:#b3261e">缺 ${s.missing} 张</b>` : ' · 无缺失');
      } catch (e) { el2.textContent = '统计失败：' + e.message; }
    };
    $('#btn-boxqr-all').onclick = async () => {
      const b = $('#btn-boxqr-all');
      b.disabled = true; b.textContent = '生成中…';
      try {
        const r = await api('/api/boxes/qrcodes/rebuild', { method: 'POST', body: {} });
        toast(`盒二维码：新生成 ${r.created}，已存在 ${r.skipped}`
          + (r.orphansRemoved ? `，清理孤儿 ${r.orphansRemoved}` : ''), 'ok', 5000);
        if (r.note) toast(r.note, 'warn', 9000);
        await boxStats();
      } catch (e) { toast('生成失败：' + e.message, 'err', 8000); }
      finally { b.disabled = false; b.textContent = '生成全部盒二维码'; }
    };
    $('#btn-boxqr-zip').onclick = () => {
      window.open('/api/boxes/qrcodes/download', '_blank');
      toast('正在打包下载（每盒一张 PNG + 清单.csv），文件较大时请稍等', 'ok', 5000);
    };
    boxStats();
    $('#btn-add-box').onclick = async () => {
      const locs = await api('/api/locations');
      const hasLoc = (locs.list || []).length > 0;
      promptDialog('新增档案盒', [
        { name: 'box_code', label: '档案盒号', required: true, placeholder: '如 2026-WS-001' },
        { name: 'title', label: '盒标题', placeholder: '如 2026 年文书档案（行政管理）' },
        { name: 'type_code', label: '门类', type: 'select', value: 'WS', options: state.types.map((t) => ({ value: t.code, label: t.name })) },
        { name: 'year', label: '年度', value: String(new Date().getFullYear()) },
        {
          name: 'location_id', label: '存放库位', type: 'select', value: '',
          options: [{ value: '', label: '（暂不上架）' }].concat((locs.list || []).map((l) => ({ value: l.id, label: `${l.code} ${l.name}` }))),
          // 一个只有一个选项的下拉框是个死胡同：用户不知道该去哪加库位。
          // 空的时候如实说明原因，并给出下一步。
          help: hasLoc ? '' : '还没有登记任何库位，所以这里只有「暂不上架」。'
            + '可以先这样保存这个盒，再到「实体管理 → 库位 → ＋新增库位」登记库位（如 A库-A1-3），'
            + '之后在盒上点「装盒」时系统会按库位归档。',
        },
        { name: 'capacity', label: '容量（件）', value: '60' },
      ], async (data) => {
        await api('/api/boxes', { method: 'POST', body: data });
        toast(hasLoc ? '已新增档案盒' : '已新增档案盒（暂不上架）——可在「库位」页登记库位后再上架', hasLoc ? 'ok' : 'warn', hasLoc ? undefined : 6000);
        setView('storage', { tab: 'boxes' });
      }, { wide: true });
    };
    $$('#content [data-bact]').forEach((b) => {
      const bid = Number(b.dataset.bid);
      b.onclick = async () => {
        const act = b.dataset.bact;
        if (act === 'print') return void window.open(`/api/print/box/${bid}`, '_blank');
        // 备考表（DA/T 22—2015 §6.5）：先填签署信息，保存后再问要不要打印。
        // 打印单独给一次点击，是因为「保存」后已不在用户手势调用栈里，直接 window.open 会被浏览器拦。
        if (act === 'beikao') {
          const bk = await api('/api/boxes/' + bid + '/beikaobiao');
          promptDialog(`备考表：${bk.box_code || ''}`, [
            { name: 'preparer', label: '整理人', value: bk.preparer || '' },
            { name: 'prepared_at', label: '整理日期（YYYY-MM-DD，可空）', value: String(bk.prepared_at || '').slice(0, 10) },
            { name: 'checker', label: '检查人', value: bk.checker || '' },
            { name: 'checked_at', label: '检查日期（YYYY-MM-DD，可空）', value: String(bk.checked_at || '').slice(0, 10) },
            { name: 'spine_mm', label: '盒脊厚度', type: 'select', value: String(bk.spine_mm || 30),
              options: [{ value: '20', label: '20 mm' }, { value: '30', label: '30 mm' },
                { value: '40', label: '40 mm' }, { value: '50', label: '50 mm' }] },
            { name: 'inventory_note', label: '情况说明（备考表正文）', type: 'textarea', span2: true, value: bk.inventory_note || '' },
          ], async (data) => {
            await api('/api/boxes/' + bid + '/beikaobiao', { method: 'PUT', body: data });
            toast('备考表已保存', 'ok');
            confirmDialog('打印备考表', '备考表通常需打印后签字。现在打开打印页吗？',
              () => window.open('/api/print/beikaobiao/' + bid, '_blank'), '打开打印页');
          }, { wide: true });
          return;
        }
        if (act === 'qr') {
          const code = b.dataset.code;
          const net = await api('/api/system/net');
          // 二维码内容**由后端给**（/api/boxes 每行带 qr_text），前端不再自己拼网址。
          // 自己拼的坑：内容格式一改（比如改成短网址 /b/<令牌>），前端还在拼老格式，
          // 屏幕上显示的码和系统实际用的码就不是一个东西了，而且很难查。
          const text = b.dataset.qrtext || code;
          const useUrl = /^https?:\/\//.test(text);
          // 按模块数算显示尺寸：显示尺寸 = 图片原生尺寸，浏览器不缩放，模块边缘是硬的。
          // 纠错等级必须与后端生成时一致（用 H），否则算出的格数偏少 → 图片被拉伸。
          const info = await api('/api/qrcode/info?text=' + encodeURIComponent(text) + '&ec=H');
          const px = qrNaturalPx(info, 620);
          modal.open('档案盒二维码：' + code, el('div', { style: 'text-align:center' }, `
            <a href="/api/qrcode.png?text=${encodeURIComponent(text)}&scale=${Math.floor(px / info.cells)}&border=${info.margin}&ec=H&x=1"
               title="点击可另存为图片" download="二维码-${esc(code)}.png">
              <img src="/api/qrcode.svg?text=${encodeURIComponent(text)}&px=${px}&border=${info.margin}&ec=H" alt="二维码"
                   width="${px}" height="${px}"
                   style="display:block;margin:0 auto;max-width:100%;height:auto;image-rendering:pixelated;background:#fff">
            </a>
            <div class="mono mt8" style="font-size:12px;word-break:break-all">${esc(text)}</div>
            <div class="help">版本 v${info.version}（${info.modules} 模块）· 静区 ${info.margin} 个模块 ·
              显示 ${px}px，每模块 ${px / info.cells} 像素</div>
            ${useUrl ? `<div class="help">手机扫码可直接打开该盒的盒内清单（手机需与本机在同一局域网）。<br>
              二维码内容 <b>${text.length}</b> 个字符 · 共 <b>${info.cells}</b> 格 ——
              内容越短、格数越少，印在盒脊上每个模块就越大、越好扫。</div>`
    : '<div class="help">当前二维码内容为纯盒号（设置里关闭了「二维码写网址」）。</div>'}
            <div class="help">${net.lan_open ? '局域网访问已开启。' : '<b>注意：当前未开启局域网访问，手机连不上，请在设置里或改用「局域网访问.bat」启动。</b>'}</div>`), [
            btn('打开调试页', '', () => window.open('/api/qrcode/debug?text=' + encodeURIComponent(text), '_blank')),
            btn('扫码自检', '', () => { modal.close(); openScanCheck(); }),
            btn('打印盒脊标签', 'btn-primary', () => { modal.close(); window.open(`/api/print/box/${bid}`, '_blank'); }),
            btn('关闭', '', () => modal.close()),
          ], {});
          return;
        }
        if (act === 'del') {
          return confirmDialog('删除档案盒', '确定删除该档案盒吗？（盒内有档案时无法删除）', async () => {
            await api('/api/boxes/' + bid, { method: 'DELETE' });
            toast('已删除', 'ok');
            setView('storage', { tab: 'boxes' });
          }, '确认删除');
        }
        if (act === 'assign') {
          const list = await api('/api/archives?hasFile=&size=100&sort=created_at&order=desc');
          modal.open('选择要装入该盒的档案', el('div', {}, `
            <div class="hint-box">勾选后点「确认装盒」。已装盒的档案会自动更新存放位置为该盒所在库位。</div>
            <div class="table-wrap" style="max-height:420px;overflow:auto"><table>
              <thead><tr><th style="width:40px"></th><th>档号</th><th>题名</th><th class="nowrap">年度</th></tr></thead>
              <tbody>${list.list.map((r) => `<tr><td><input type="checkbox" class="pick" value="${r.id}"></td>
                <td class="code">${esc(r.archive_code)}</td><td>${esc(r.title)}</td><td class="nowrap">${esc(r.year || '')}</td></tr>`).join('')}</tbody>
            </table></div>`), [
            btn('取消', '', () => modal.close()),
            btn('确认装盒', 'btn-primary', async () => {
              const ids = $$('#modal-body .pick').filter((c) => c.checked).map((c) => Number(c.value));
              if (!ids.length) return toast('请先勾选档案', 'warn');
              const r = await api(`/api/boxes/${bid}/assign`, { method: 'POST', body: { archive_ids: ids } });
              toast(`已装盒 ${r.assigned} 件`, 'ok');
              modal.close();
              setView('storage', { tab: 'boxes' });
            }),
          ], { wide: true });
        }
      };
    });
    $$('#content [data-stab]').forEach((b) => { b.onclick = () => setView('storage', { tab: b.dataset.stab }); });
  }

  /** 盘点作业界面：支持扫码枪连续录入 */
  async function openStockCheck(checkId) {
    const c = await api('/api/stock-checks/' + checkId);
    const done = c.status !== '进行中';
    const body = el('div', {}, `
      <div class="hint-box">
        盘点单号 <b>${esc(c.check_no)}</b>　范围：${esc(c.scope)}　共 ${c.items.length} 条明细<br>
        在架 <b>${c.checked}</b>　缺失 <b style="color:var(--c-danger)">${c.missing}</b>　位置不符 <b>${c.mislocated}</b>
      </div>
      ${done ? '' : `
      <label class="field"><span>扫描或输入档案号 / 档号（扫码枪扫一次会自动换行，可连续录入多行）</span>
        <textarea id="scan-input" rows="3" placeholder="Z001-WS-XZ-2026-0001&#10;WS-2026-0001"></textarea></label>
      <label class="field"><span>当前位置（可选，填写后会校验是否与应有位置一致）</span>
        <input type="text" id="scan-loc" placeholder="如 A库-A1-3"></label>
      <div class="flex mb8">
        <button class="btn btn-primary" id="btn-scan">提交核对</button>
        <span class="muted" id="scan-result"></span>
      </div>`}
      <div class="section-title">明细（最多显示前 300 条）</div>
      <div class="table-wrap" style="max-height:320px;overflow:auto"><table>
        <thead><tr><th>档案号</th><th>应有位置</th><th>实际位置</th><th>结果</th></tr></thead>
        <tbody>${c.items.slice(0, 300).map((i) => `<tr>
          <td class="code">${esc(i.archive_code)}</td><td>${esc(i.expect_location || '')}</td>
          <td>${esc(i.actual_location || '')}</td>
          <td>${i.result === '在架' ? '<span class="tag tag-green">在架</span>' : (i.result === '缺失' ? '<span class="tag tag-red">缺失</span>' : (i.result === '位置不符' ? '<span class="tag tag-amber">位置不符</span>' : '<span class="muted">待盘点</span>'))}</td>
        </tr>`).join('')}</tbody></table></div>
    `);
    const foot = [btn('关闭', '', () => modal.close())];
    if (!done) {
      foot.push(btn('完成盘点', 'btn-primary', async () => {
        confirmDialog('完成盘点', '完成后系统会把尚未扫描的明细标记为「缺失」。确定完成吗？', async () => {
          const r = await api(`/api/stock-checks/${checkId}/finish`, { method: 'POST', body: {} });
          toast(`盘点完成：在架 ${r.onShelf}，缺失 ${r.missing}，位置不符 ${r.mislocated}`, 'ok');
          setView('storage', { tab: 'checks' });
        }, '确认完成');
      }));
    }
    modal.open('盘点作业', body, foot, { wide: true });

    const scanBtn = body.querySelector('#btn-scan');
    if (scanBtn) {
      scanBtn.onclick = async () => {
        const raw = body.querySelector('#scan-input').value;
        const codes = raw.split(/[\r\n,;\s]+/).map((s) => s.trim()).filter(Boolean);
        if (!codes.length) return toast('请输入或扫描档案号', 'warn');
        try {
          const r = await api(`/api/stock-checks/${checkId}/scan`, {
            method: 'POST',
            body: { codes, location: body.querySelector('#scan-loc').value.trim() },
          });
          let msg = `本次核对：在架 ${r.hit}`;
          if (r.mislocated) msg += `，位置不符 ${r.mislocated}`;
          if (r.notFound) msg += `，库中无此号 ${r.notFound}`;
          if (r.already) msg += `，重复 ${r.already}`;
          body.querySelector('#scan-result').textContent = msg;
          body.querySelector('#scan-input').value = '';
          toast(msg, r.notFound ? 'warn' : 'ok');
          setTimeout(() => { modal.close(); openStockCheck(checkId); }, 600);
        } catch (e) { toast(e.message, 'err'); }
      };
      setTimeout(() => { const t = body.querySelector('#scan-input'); if (t) t.focus(); }, 100);
    }
  }

  // ---------------- 导入导出 ----------------
  async function renderImport() {
    const isClerk = state.user.role !== 'reader';
    const batches = isClerk ? await api('/api/import/batches') : { list: [] };
    const rows = batches.list.map((b) => `
      <tr><td class="nowrap muted">${fmtTime(b.created_at)}</td>
      <td class="mono">${esc(b.filename)}</td><td>${esc(b.mode)}</td>
      <td class="num">${b.total}</td>
      <td class="num" style="color:var(--c-ok)">${b.succeeded}</td>
      <td class="num" ${b.failed ? 'style="color:var(--c-danger)"' : ''}>${b.failed}</td>
      <td class="nowrap muted">${esc(b.operator || '')}</td>
      <td>${(b.errors || []).length ? `<button class="btn btn-sm" data-bact="err" data-bid="${b.id}">查看 ${b.errors.length} 条错误</button>` : '<span class="muted">—</span>'}</td>
      </tr>`).join('') || '<tr><td colspan="8" class="empty">还没有导入记录</td></tr>';

    $('#content').innerHTML = `
      <div class="grid grid-2">
        <div class="card">
          <div class="card-head"><h3>批量导入档案</h3></div>
          ${isClerk ? '' : '<div class="hint-box warn">批量导入需要档案员及以上权限。</div>'}
          <div class="hint-box">三步完成：<b>① 下载模板</b> → <b>② 用 Excel 填写</b>（另存为 CSV UTF-8）→ <b>③ 上传导入</b>。表头带 <b>*</b> 的列必须填，其余列留空即可，系统会按规则补默认值。</div>
          <div class="flex mb8" style="flex-wrap:wrap;gap:8px">
            <button class="btn btn-primary" id="btn-tpl">① 下载导入模板（9 列，够用）</button>
            <button class="btn" id="btn-tpl-full">下载全字段模板（33 列）</button>
          </div>
          <div class="help mb16">两张表只有列数不同：精简版 9 列，必填只有「门类代码、题名、分类」3 列；全字段版给「从别的系统整库迁移、对方字段本来就齐」时用。<b>多余的列可以整列删掉，列顺序也可以自己调</b> —— 系统按表头名字认列，不按位置。</div>
          <label class="field"><span>导入模式</span>
            <select id="imp-mode">
              <option value="新增">新增（档案号重复时报错跳过）</option>
              <option value="更新">更新（按档案号覆盖已有档案）</option>
            </select></label>
          <label class="field" style="flex-direction:row;align-items:center;gap:8px">
            <input type="checkbox" id="imp-dry" checked style="width:auto">
            <span style="flex:none">先试跑（只报告会发生什么，<b>不写入、不占用档号</b>）</span>
          </label>
          <div class="help">建议第一次导入新表时保持勾选：试跑会把文件完整跑一遍，告诉你「会新增/更新几条、
            哪些行有问题、会占哪些档号」，确认无误后再取消勾选正式导入。<br>
            之所以这么设计：<b>本系统的档号不复用</b> —— 导错一次就会永久烧掉一批正式档号，
            而删掉几条多余数据容易，把档号要回来是不可能的。</div>
          <div class="dropzone" id="imp-drop">③ 点击选择 CSV 文件，或把文件拖到这里</div>
          <input type="file" id="imp-file" accept=".csv" class="hidden">
          <div class="upload-list" id="imp-list"></div>
          <div class="mt16" id="imp-result"></div>
        </div>
        <div class="card">
          <div class="card-head"><h3>导出档案目录</h3></div>
          <div class="hint-box">导出当前全部档案的著录信息为 CSV，可用 Excel 打开（已处理中文编码）。</div>
          <div class="flex mb16">
            <button class="btn btn-primary" id="btn-export-all">导出全部档案目录</button>
          </div>
          <div class="section-title">模板字段说明</div>
          <div class="table-wrap"><table>
            <thead><tr><th>列名</th><th>是否必填</th><th>说明</th></tr></thead>
            <tbody>
              <tr><td>门类代码 <b>*</b></td><td><b>必填</b></td><td>WS／HT／RS／CW／GC，或直接写门类名称</td></tr>
              <tr><td>题名 <b>*</b></td><td><b>必填</b></td><td>文件标题</td></tr>
              <tr><td>分类 <b>*</b></td><td><b>必填</b></td><td>如「文书档案/行政管理」，或填分类号如 WS-XZ</td></tr>
              <tr><td>年度</td><td>可留空</td><td>4 位年份；留空按归档日期取，再留空按本年</td></tr>
              <tr><td>归档日期</td><td>可留空</td><td>YYYY-MM-DD；留空按「年度-12-31」</td></tr>
              <tr><td>保管期限</td><td>可留空</td><td>永久 / 定期30年 / 定期10年 / 定期5年 / 长期；留空取门类默认期限</td></tr>
              <tr><td>密级</td><td>可留空</td><td>公开 / 内部 / 秘密 / 机密；留空按公开</td></tr>
              <tr><td>责任者、所属部门</td><td>可留空</td><td>以上 9 列就是精简模板</td></tr>
              <tr><td>档案号 / 档号</td><td>可留空</td><td>留空由系统自动编号；填写则须不重复（在全字段模板里）</td></tr>
              <tr><td>其余列</td><td>可留空</td><td>密级、页数、关键词、摘要、存放位置、保密期限等，见全字段模板</td></tr>
            </tbody></table></div>
          <div class="help">电子附件（PDF/扫描件）无法通过表格导入，请在档案详情页单独上传。</div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>导入记录</h3></div>
        <div class="table-wrap"><table><thead><tr>
          <th>时间</th><th>文件名</th><th>模式</th><th class="num">总行数</th><th class="num">成功</th><th class="num">失败</th><th>操作人</th><th>错误</th>
        </tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;

    $('#btn-tpl').onclick = () => { window.location.href = '/api/import/template'; };
    $('#btn-tpl-full').onclick = () => { window.location.href = '/api/import/template?kind=full'; };
    $('#btn-export-all').onclick = () => { window.location.href = '/api/export/archives.csv'; };

    if (isClerk) {
      const drop = $('#imp-drop');
      const input = $('#imp-file');
      const listEl = $('#imp-list');
      let picked = null;
      const render = () => { listEl.innerHTML = picked ? `<div class="row"><span class="mono">${esc(picked.name)}</span><span class="muted">${fmtSize(picked.size)}</span></div>` : ''; };
      drop.onclick = () => input.click();
      input.onchange = () => { picked = input.files[0] || null; render(); };
      ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
      ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
      drop.addEventListener('drop', (e) => {
        if (e.dataTransfer && e.dataTransfer.files.length) { picked = e.dataTransfer.files[0]; render(); doImport(); }
      });
      input.onchange = () => { picked = input.files[0] || null; render(); if (picked) doImport(); };

      async function doImport() {
        if (!picked) return;
        // 「先试跑」（v4.21.0）：档号不复用，导错一次就永久烧掉一批正式号，
        // 所以默认鼓励先试跑 —— 试跑会把整批操作真跑一遍再整体回滚，
        // 数据、号段、批次记录一概不留，报告里能看到"会占哪些档号"。
        const dryEl = $('#imp-dry');
        const dry = !!(dryEl && dryEl.checked);
        const fd = new FormData();
        fd.append('mode', $('#imp-mode').value);
        if (dry) fd.append('dryRun', '1');
        fd.append('file', picked, picked.name);
        const t = toast(dry ? '正在试跑（不会写入）…' : '正在导入，请稍候…', '', 60000);
        try {
          const r = await uploadWithProgress('/api/import/archives', fd);
          t.remove();
          const errList = (r.errors || []).map((e) => `<li>第 ${e.line} 行：${esc(e.message)}</li>`).join('');
          const planRows = (r.planned || []).map((x) =>
            `<tr><td class="nowrap muted">第 ${x.line} 行</td><td class="nowrap">${esc(x.action)}</td>
             <td class="mono">${esc(x.archive_code || '')}</td><td>${esc(x.title || '')}</td></tr>`).join('');
          const planBlock = planRows ? `
            <div class="section-title">会写进去的内容（前 ${(r.planned || []).length} 条${r.plannedCount > (r.planned || []).length ? '，共 ' + r.plannedCount + ' 条' : ''}）</div>
            <div class="table-wrap"><table><thead><tr><th class="nowrap">行</th><th class="nowrap">动作</th><th class="nowrap">档号</th><th>题名</th></tr></thead><tbody>${planRows}</tbody></table></div>` : '';
          $('#imp-result').innerHTML = dry ? `
            <div class="hint-box ${r.failed ? 'warn' : ''}">
              <b>试跑完成 —— 没有写入任何数据，也没有占用任何档号。</b><br>
              这份文件共 ${r.total} 行：将新增/更新 <b style="color:var(--c-ok)">${r.succeeded}</b> 条，
              失败 <b style="color:var(--c-danger)">${r.failed}</b> 条。
              ${r.unknownColumns && r.unknownColumns.length ? '<br>未识别的列（会被忽略）：' + esc(r.unknownColumns.join('、')) : ''}
            </div>
            ${planBlock}
            ${errList ? `<div class="section-title">错误明细（这些行不会被导入）</div><ul style="line-height:1.9;color:var(--c-danger)">${errList}</ul>` : ''}
            <div class="hint-box">确认上面没问题后，把「先试跑」的勾去掉、再选一次这个文件，就会真正导入。</div>`
            : `
            <div class="hint-box ${r.failed ? 'warn' : ''}">
              导入完成：共 ${r.total} 行，成功 <b style="color:var(--c-ok)">${r.succeeded}</b> 条，
              失败 <b style="color:var(--c-danger)">${r.failed}</b> 条。
              ${r.unknownColumns && r.unknownColumns.length ? '<br>未识别的列（已忽略）：' + esc(r.unknownColumns.join('、')) : ''}
            </div>
            ${planBlock}
            ${errList ? `<div class="section-title">错误明细</div><ul style="line-height:1.9;color:var(--c-danger)">${errList}</ul>` : ''}`;
          toast(dry
            ? `试跑完成：将写入 ${r.succeeded} 条，失败 ${r.failed} 条（未写入）`
            : `导入完成：成功 ${r.succeeded}，失败 ${r.failed}`, r.failed ? 'warn' : 'ok');
          if (!dry) setView('import');
        } catch (e) {
          t.remove();
          toast(e.message, 'err');
          $('#imp-result').innerHTML = `<div class="hint-box warn">${dry ? '试跑' : '导入'}失败：${esc(e.message)}</div>`;
        }
      }
    }

    $$('#content [data-bact="err"]').forEach((b) => {
      const rec = batches.list.find((x) => x.id === Number(b.dataset.bid));
      b.onclick = () => modal.open('导入错误明细', el('div', {}, `
        <div class="hint-box">文件：${esc(rec.filename)}　共 ${rec.total} 行，失败 ${rec.failed} 条</div>
        <ul style="line-height:1.9;color:var(--c-danger)">${(rec.errors || []).map((e) => `<li>第 ${e.line} 行：${esc(e.message)}</li>`).join('')}</ul>`),
        [btn('关闭', 'btn-primary', () => modal.close())], { narrow: true });
    });
  }

  // ---------------- 正文检索 ----------------
  async function renderTextSearch(params) {
    const q = state.textQuery || {};
    const p = new URLSearchParams(q);
    p.set('page', String(state.textPage || 1));
    p.set('size', '20');

    let stats = null;
    try { stats = await api('/api/search/text/stats'); } catch (_) { stats = null; }
    const searched = !!(q.kw && q.kw.trim());
    const data = searched ? await api('/api/search/text?' + p.toString()) : { list: [], total: 0, pages: 1 };

    const rows = data.list.map((r) => `
      <tr data-aid="${r.archive_id}">
        <td class="code">${esc(r.archive_number || r.archive_code)}</td>
        <td><div style="font-weight:500">${esc(r.title)}</div>
            <div class="muted" style="font-size:12px">${esc(r.category_name || '')} · ${esc(r.archive_code)}</div></td>
        <td class="nowrap"><span class="tag tag-blue">${esc(r.type_code)}</span> ${esc(r.year || '')}</td>
        <td class="nowrap">${esc(r.original_name)}
          <div class="muted" style="font-size:12px">${fmtSize(r.size)} · 正文 ${r.char_count} 字
            ${r.via === 'ocr'
    ? `<span class="tag tag-amber" title="这段正文是 OCR 识别出来的，可能有错字">OCR${r.engine ? ' · ' + esc(r.engine) : ''}</span>`
    : '<span class="tag tag-gray" title="文档自带的文字层，准确">原生</span>'}</div></td>
        <td><div class="snippet">${highlight(r.snippet, q.kw)}</div></td>
        <td class="nowrap">
          <button class="btn btn-sm" data-fact="view">查看档案</button>
          <button class="btn btn-sm" data-fact="file">打开附件</button>
        </td>
      </tr>`).join('') || `<tr><td colspan="6" class="empty">
        ${searched ? '<b>没有找到包含该内容的附件</b>可换个关键词，或到「数据体检」查看哪些附件无法提取正文'
          : '<b>输入关键词检索附件正文</b>可以搜索 PDF、Word、Excel 等附件里的内容，而不只是题名和摘要'}
      </td></tr>`;

    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>附件正文检索</h3>
          ${stats ? `<span class="sub">已建索引 ${stats.indexed} 个附件${stats.skipped ? `，${stats.skipped} 个无法提取` : ''}${stats.notProcessed ? `，${stats.notProcessed} 个待处理` : ''}</span>` : ''}
        </div>
        <div class="hint-box">
          检索的是附件<b>内容</b>，不只是题名和摘要。支持 PDF（有文字层）、Word(.docx)、Excel(.xlsx)、文本文件；
          <b>扫描件 PDF</b> 没有文字层，需要 OCR 才能检索；<b>旧版 .doc/.xls</b> 请用 Office 另存为新格式后重新上传。
        </div>
        <form class="filters" id="ts-form" onsubmit="return false">
          <label class="field grow"><span>正文关键词</span>
            <input type="search" name="kw" value="${esc(q.kw || '')}" placeholder="如：内涝防治、值班制度、合同金额"></label>
          <label class="field"><span>门类</span><select name="type">${typeOptions(q.type, true)}</select></label>
          <label class="field"><span>年度</span><input type="text" name="year" value="${esc(q.year || '')}" placeholder="2032"></label>
          <label class="field"><span>正文来源</span>
            <select name="via"><option value="">不限</option>
              <option value="native"${q.via === 'native' ? ' selected' : ''}>仅原生文字层（准确）</option>
              <option value="ocr"${q.via === 'ocr' ? ' selected' : ''}>仅 OCR 识别（可能有错字）</option></select></label>
          <button class="btn btn-primary" id="ts-search">检 索</button>
          <button class="btn" id="ts-reset">重置</button>
        </form>
        ${stats && stats.notProcessed > 0 && state.user.role === 'admin' ? `
          <div class="hint-box warn mt16">
            还有 <b>${stats.notProcessed}</b> 个附件没有建立正文索引（多为此前上传的历史附件）。
            <div class="mt8"><button class="btn btn-sm btn-primary" id="ts-reindex">补建正文索引（每次处理 100 个）</button></div>
          </div>` : ''}
        <div class="hint-box mt16">
          扫描件搜不到是正常的 —— 它没有文字层。<b>本机装了 OCR 引擎的话</b>可以在
          「数据体检 → 扫描件 OCR」里批量识别，识别结果会标注为「OCR 来源」，与原文字层分得清清楚楚。
          <div class="mt8"><button class="btn btn-sm" id="ts-goto-ocr">去看 OCR 状态</button></div>
        </div>
      </div>
      ${searched ? `
      <div class="card">
        <div class="card-head"><h3>检索结果 <span class="sub">共 ${data.total} 个附件命中</span></h3></div>
        <div class="table-wrap"><table><thead><tr>
          <th>档号</th><th>题名 / 分类</th><th>门类年度</th><th>附件</th><th>命中片段</th><th>操作</th>
        </tr></thead><tbody>${rows}</tbody></table></div>
        ${pagerHtml(data, 'text')}
      </div>` : ''}`;

    const form = $('#ts-form');
    const collect = () => {
      const o = {};
      new FormData(form).forEach((v, k) => { const s = String(v).trim(); if (s) o[k] = s; });
      return o;
    };
    $('#ts-search').onclick = () => { state.textQuery = collect(); state.textPage = 1; setView('textsearch'); };
    form.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#ts-search').click(); } });
    $('#ts-reset').onclick = () => { state.textQuery = {}; state.textPage = 1; setView('textsearch'); };
    const goOcr = $('#ts-goto-ocr');
    if (goOcr) goOcr.onclick = () => setView('quality');
    const ri = $('#ts-reindex');
    if (ri) ri.onclick = async () => {
      ri.disabled = true;
      try {
        const r = await api('/api/search/text/reindex', { method: 'POST', body: { limit: 100 } });
        toast(`已处理 ${r.processed} 个附件：成功 ${r.ok}，跳过 ${r.skipped}，失败 ${r.failed}${r.remaining ? `；剩余 ${r.remaining} 个` : ''}`, 'ok', 5000);
        setView('textsearch');
      } catch (e) { toast(e.message, 'err'); ri.disabled = false; }
    };
    $$('#content tr[data-aid]').forEach((tr) => {
      const aid = Number(tr.dataset.aid);
      const rec = data.list.find((x) => x.archive_id === aid && true);
      tr.querySelectorAll('[data-fact]').forEach((b) => {
        b.onclick = () => {
          if (b.dataset.fact === 'view') return openArchiveDetail(aid);
          const row = data.list.find((x) => x.archive_id === aid);
          if (row) window.open(`/api/files/${row.file_id}/download?inline=1`, '_blank');
        };
      });
    });
    bindPager('text', (pg) => { state.textPage = pg; setView('textsearch'); });
  }

  /** 命中片段高亮 */
  function highlight(text, kw) {
    const s = esc(text || '');
    if (!kw) return s;
    const k = esc(kw);
    try {
      return s.replace(new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'),
        (m) => `<mark style="background:#fff3bf;padding:0 1px">${m}</mark>`);
    } catch (_) { return s; }
  }

  // ---------------- 档案移交 ----------------
  async function renderTransfer(params) {
    const isClerk = state.user.role !== 'reader';
    if (!isClerk) {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>档案移交需要档案员及以上权限</div></div>';
      return;
    }
    const status = (params && params.status) || '';
    const p = new URLSearchParams();
    if (status) p.set('status', status);
    const d = await api('/api/transfers?' + p.toString());

    const rows = d.list.map((t) => `
      <tr data-tid="${t.id}">
        <td class="code">${esc(t.transfer_no)}</td>
        <td><div style="font-weight:500">${esc(t.title)}</div>
            <div class="muted" style="font-size:12px">${esc(t.direction)} · ${esc(t.source_unit)} → ${esc(t.target_unit || '未填接收单位')}</div></td>
        <td class="num">${t.item_count}</td>
        <td class="num">${t.total_pages}</td>
        <td class="nowrap">${transferStatusTag(t.status)}</td>
        <td class="nowrap muted">${esc(t.applicant || '')}<div style="font-size:12px">${fmtDay(t.applied_at)}</div></td>
        <td class="nowrap muted">${esc(t.acceptor || '—')}</td>
        <td class="nowrap">
          <button class="btn btn-sm" data-tact="view">明细</button>
          ${t.status === '待提交' || t.status === '已退回' ? '<button class="btn btn-sm btn-primary" data-tact="submit">提交移交</button>' : ''}
          ${t.status === '已提交' ? '<button class="btn btn-sm btn-primary" data-tact="accept">办理接收</button>' : ''}
          <button class="btn btn-sm" data-tact="print">打印清册</button>
          ${t.status !== '待提交' ? `<button class="btn btn-sm btn-primary" data-tact="package" data-tid="${t.id}">导出移交数据包</button>` : ''}
          ${t.status !== '已接收' ? '<button class="btn btn-sm btn-danger" data-tact="del">删除</button>' : ''}
        </td>
      </tr>`).join('') || `<tr><td colspan="8" class="empty"><b>还没有移交批次</b>点右上角「新建移交批次」，按门类/年度挑选档案生成移交清册</td></tr>`;

    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>档案移交</h3>
          <div class="flex">
            <button class="btn btn-sm${status === '' ? ' btn-primary' : ''}" data-tstatus="">全部</button>
            <button class="btn btn-sm${status === '待提交' ? ' btn-primary' : ''}" data-tstatus="待提交">待提交 ${d.counts.draft}</button>
            <button class="btn btn-sm${status === '已提交' ? ' btn-primary' : ''}" data-tstatus="已提交">已提交 ${d.counts.submitted}</button>
            <button class="btn btn-sm${status === '已接收' ? ' btn-primary' : ''}" data-tstatus="已接收">已接收 ${d.counts.accepted}</button>
            <button class="btn btn-sm${status === '已退回' ? ' btn-primary' : ''}" data-tstatus="已退回">已退回 ${d.counts.rejected}</button>
            <button class="btn btn-sm btn-primary" id="btn-new-transfer">＋ 新建移交批次</button>
          </div></div>
        <div class="hint-box">
          移交流程：<b>新建批次</b>（按门类/年度挑选档案）→ <b>提交移交</b> → <b>办理接收或退回</b>。
          清册可打印（含移交单位、接收单位签章栏与经办人、接收人签字栏）。同一档案不会同时出现在两个未完成的批次里。
        </div>
        <div class="table-wrap"><table><thead><tr>
          <th>移交单号</th><th>批次 / 去向</th><th class="num">件数</th><th class="num">页数</th>
          <th>状态</th><th>申请人</th><th>接收人</th><th>操作</th>
        </tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;

    $$('#content [data-tstatus]').forEach((b) => {
      b.onclick = () => setView('transfer', b.dataset.tstatus ? { status: b.dataset.tstatus } : {});
    });

    $('#btn-new-transfer').onclick = () => {
      promptDialog('新建移交批次', [
        { name: 'title', label: '批次名称', placeholder: '如 2026 年度文书档案移交' },
        { name: 'direction', label: '移交方向', type: 'select', value: '移交进馆',
          options: [{ value: '移交进馆', label: '移交进馆（本单位移交给档案馆）' }, { value: '接收进馆', label: '接收进馆（接收下属单位档案）' }] },
        { name: 'target_unit', label: '接收单位', placeholder: '如 广州市南沙区档案馆' },
        { name: 'contact', label: '联系人' },
        { name: 'phone', label: '联系电话' },
        { name: 'basis', label: '移交依据', span2: true, placeholder: '如《档案法》关于定期向档案馆移交档案的规定' },
        { name: 'type_code', label: '按门类挑选（可留空）', type: 'select', value: '',
          options: [{ value: '', label: '全部门类' }].concat(state.types.map((x) => ({ value: x.code, label: x.name }))) },
        { name: 'year', label: '按年度挑选（可留空）', placeholder: '如 2026' },
      ], async (data) => {
        const r = await api('/api/transfers', { method: 'POST', body: data });
        toast(`已生成移交批次 ${r.transfer_no}（${r.count} 件）`, 'ok');
        setView('transfer');
      }, { wide: true });
    };

    $$('#content tr[data-tid]').forEach((tr) => {
      const tid = Number(tr.dataset.tid);
      const rec = d.list.find((x) => x.id === tid);
      tr.querySelectorAll('[data-tact]').forEach((b) => {
        b.onclick = async () => {
          const act = b.dataset.tact;
          if (act === 'print') return void window.open(`/api/transfers/${tid}/print`, '_blank');
          // 数据包是移交给档案馆的最终交付物；未提交的批次内容还会变，后端也会拒绝
          if (act === 'package') {
            window.open(`/api/transfers/${tid}/package`, '_blank');
            return;
          }
          if (act === 'view') return openTransferDetail(tid);
          if (act === 'submit') {
            confirmDialog('提交移交', `确定提交批次「${rec.transfer_no}」吗？提交后清单不能再修改。`, async () => {
              await api(`/api/transfers/${tid}/submit`, { method: 'POST', body: {} });
              toast('已提交移交', 'ok');
              setView('transfer', params || {});
            }, '确认提交');
            return;
          }
          if (act === 'accept') {
            promptDialog('办理接收', [
              { name: 'acceptor', label: '接收人', required: true, placeholder: '档案馆接收经办人姓名' },
              { name: 'note', label: '接收说明', type: 'textarea', placeholder: '如：数量相符、载体完好，予以接收' },
            ], async (data) => {
              await api(`/api/transfers/${tid}/accept`, { method: 'POST', body: { accept: true, ...data } });
              toast('已办理接收', 'ok');
              setView('transfer', params || {});
            });
            return;
          }
          if (act === 'del') {
            confirmDialog('删除移交批次', `确定删除批次「${rec.transfer_no}」吗？`, async () => {
              await api('/api/transfers/' + tid, { method: 'DELETE' });
              toast('已删除', 'ok');
              setView('transfer', params || {});
            }, '确认删除');
          }
        };
      });
    });
  }

  function transferStatusTag(s) {
    const cls = { '待提交': 'tag-gray', '已提交': 'tag-blue', '已接收': 'tag-green', '已退回': 'tag-red' }[s] || 'tag';
    return `<span class="tag ${cls}">${esc(s)}</span>`;
  }

  async function openTransferDetail(tid) {
    const t = await api('/api/transfers/' + tid);
    const items = t.items.map((it, i) => `<tr>
      <td>${i + 1}</td><td class="code">${esc(it.archive_number || it.archive_code)}</td>
      <td>${esc(it.title)}</td><td class="nowrap">${esc(it.type_code)}</td>
      <td class="nowrap">${esc(it.year)}</td><td class="nowrap">${esc(it.retention)}</td>
      <td class="nowrap">${esc(it.pages || '')}</td></tr>`).join('');
    const canEdit = ['待提交', '已退回'].includes(t.status);
    modal.open(`移交明细 ${t.transfer_no}`, el('div', {}, `
      <div class="dl" style="grid-template-columns:1fr">
        <div><span class="k">状态</span><span class="v">${transferStatusTag(t.status)}</span></div>
        <div><span class="k">去向</span><span class="v">${esc(t.source_unit)} → ${esc(t.target_unit || '未填')}</span></div>
        <div><span class="k">申请人</span><span class="v">${esc(t.applicant)} ${esc(fmtDay(t.applied_at))}</span></div>
        ${t.submitted_at ? `<div><span class="k">提交时间</span><span class="v">${fmtTime(t.submitted_at)}</span></div>` : ''}
        ${t.accepted_at ? `<div><span class="k">接收</span><span class="v">${esc(t.acceptor)} ${esc(fmtDay(t.accepted_at))} ${esc(t.accept_note || '')}</span></div>` : ''}
        ${t.reject_reason ? `<div><span class="k">退回原因</span><span class="v" style="color:var(--c-danger)">${esc(t.reject_reason)}</span></div>` : ''}
        <div><span class="k">合计</span><span class="v">${t.items.length} 件 / ${t.total_pages} 页</span></div>
      </div>
      <div class="section-title">移交清单</div>
      <div class="table-wrap" style="max-height:340px;overflow:auto"><table>
        <thead><tr><th style="width:42px">#</th><th>档号</th><th>题名</th><th>门类</th><th>年度</th><th>保管期限</th><th>页数</th></tr></thead>
        <tbody>${items || '<tr><td colspan="7" class="muted">清单为空</td></tr>'}</tbody></table></div>`), [
      btn('打印清册', '', () => window.open(`/api/transfers/${tid}/print`, '_blank')),
      canEdit ? btn('移除所选', '', async () => {
        const checked = $$('#modal-body input.pick').filter((c) => c.checked);
        if (!checked.length) return toast('请先勾选要移除的档案', 'warn');
        const r = await api(`/api/transfers/${tid}/remove`, { method: 'POST', body: { item_ids: checked.map((c) => Number(c.value)) } });
        toast(`已移除 ${r.removed} 件`, 'ok');
        modal.close();
        openTransferDetail(tid);
      }) : null,
      btn('关闭', 'btn-primary', () => modal.close()),
    ].filter(Boolean), { wide: true });
    if (canEdit) {
      // 允许勾选移除
      const table = $('#modal-body tbody');
      if (table) {
        $$('#modal-body tbody tr').forEach((tr, i) => {
          const it = t.items[i];
          if (!it) return;
          const cell = document.createElement('td');
          cell.innerHTML = `<input type="checkbox" class="pick" value="${it.id}">`;
          tr.insertBefore(cell, tr.firstChild);
        });
      }
    }
  }

  // ---------------- 数据体检 ----------------
  async function renderQuality(params) {
    const isClerk = state.user.role !== 'reader';
    if (!isClerk) {
      $('#content').innerHTML = '<div class="card"><div class="empty"><b>权限不足</b>数据体检需要档案员及以上权限</div></div>';
      return;
    }
    const d = await api('/api/quality/scan?limit=20');
    // OCR 卡片**异步加载**：取一次状态要跑本机引擎探测（Windows OCR 要起一次 PowerShell），
    // 慢起来能把整个体检页拖在"加载中…"。体检本身不该等它 —— 先出页面，卡片后填。
    const ocrCard = '<div class="card"><div class="muted">正在探测本机 OCR 引擎…</div></div>';

    // 严重度样式（v4.23.0）：必须处理=红、建议处理=琥珀、提示=灰。
    // 服务端已按严重度排好序，所以界面按顺序渲染就是"先干哪个"的顺序。
    const SEV_STYLE = {
      must: { color: 'var(--c-danger)', tag: 'tag-red', label: '必须处理' },
      should: { color: 'var(--c-warn)', tag: 'tag-amber', label: '建议处理' },
      info: { color: 'var(--c-text-3)', tag: 'tag-gray', label: '提示' },
    };
    const cards = d.problems.map((p) => {
      const sv = SEV_STYLE[p.severity] || SEV_STYLE.should;
      return `
      <div class="card" style="border-left:3px solid ${p.count ? sv.color : 'var(--c-ok)'}">
        <div class="card-head" style="margin-bottom:6px">
          <h3 style="font-size:14px">${p.count ? `<span class="tag ${sv.tag}">${sv.label}</span> ` : ''}${esc(p.label)}</h3>
          <span class="tag ${p.count ? sv.tag : 'tag-green'}">${p.count} 条</span>
        </div>
        <div class="help">${esc(p.hint)}</div>
        ${p.samples && p.samples.length ? `
          <div class="table-wrap mt8" style="max-height:180px;overflow:auto"><table>
            <tbody>${p.samples.slice(0, 10).map((s) => `<tr data-aid="${s.id}" style="cursor:pointer">
              <td class="code" style="width:130px">${esc(s.code || '')}</td>
              <td>${esc(s.title || '')}</td></tr>`).join('')}</tbody></table></div>
          <div class="help">点任意一行查看档案详情</div>` : '<div class="help">没有发现此类问题 ✓</div>'}
      </div>`;
    }).join('');

    const ss = d.severitySummary || { must: 0, should: 0, info: 0 };
    const st = d.severityTypes || { must: 0, should: 0, info: 0 };
    const summary = `
      <div class="hint-box ${ss.must ? 'warn' : ''}">
        <b>先看这一行：按紧迫程度分三级</b>（不是按发现顺序）<br>
        <span class="tag tag-red">必须处理 ${ss.must} 条</span>（${st.must} 类）
        <span class="tag tag-amber">建议处理 ${ss.should} 条</span>（${st.should} 类）
        <span class="tag tag-gray">提示 ${ss.info} 条</span>（${st.info} 类）
        <div class="help" style="margin-top:6px">「必须处理」不解决就是错档或违规 ——
          例如两件档案占用同一个规范档号、涉密档案未登记保密期限；
          「建议处理」影响利用与统计，或有法定时限压力；
          「提示」只是规范性建议（例如档号断号，按规范本来就不得回填），可以最后再说。</div>
      </div>`;

    $('#content').innerHTML = `
      ${summary}
      <div class="card">
        <div class="card-head"><h3>数据体检</h3>
          <div class="flex">
            <span class="sub">共 ${d.archives} 条档案，扫描时间 ${fmtTime(d.scannedAt)}</span>
            <button class="btn btn-sm btn-primary" id="btn-scan">重新扫描</button>
            <button class="btn btn-sm" id="btn-report">统计报表</button>
            <button class="btn btn-sm" id="btn-stat-print">打印统计年报</button>
            <button class="btn btn-sm" id="btn-stat-csv">导出统计表</button>
          </div></div>
        <div class="hint-box">
          体检会找出影响检索与合规的常见问题：疑似重复、著录缺项、无附件、已到期未鉴定、缺存放位置、附件正文无法提取等。
          点击问题条目可直接打开档案修正。
        </div>
      </div>
      <div class="grid grid-2"><div id="ocr-card-host">${ocrCard}</div>${cards}</div>`;

    $('#btn-scan').onclick = () => setView('quality');
    $('#btn-report').onclick = () => setView('report');
    $('#btn-stat-print').onclick = () => window.open('/api/stats/report/print', '_blank');
    $('#btn-stat-csv').onclick = () => { window.location.href = '/api/stats/report.csv'; };

    /**
     * 异步补上 OCR 卡片。**失败/超时都不影响体检页其余内容** ——
     * 体检本身是有用的，不该因为一个外部探测慢就被拖住。
     */
    (async () => {
      const host = $('#ocr-card-host');
      if (!host) return;
      let ocr = null;
      try { ocr = await api('/api/ocr/status'); } catch (_) { ocr = null; }
      if (!$('#ocr-card-host')) return;      // 期间用户已经切走了
      if (!ocr) {
        host.innerHTML = '<div class="card"><div class="muted">OCR 状态读取失败（不影响体检）</div></div>';
        return;
      }
      const det = ocr.detect || {};
      const pdfNote = det.canPdf
        ? `扫描版 PDF 也能识别（走 ${esc(det.pdfVia || '内置渲染')}）`
        : '扫描版 PDF 暂不能识别（本机缺 PDF 渲染能力）';
      host.innerHTML = `
      <div class="card" style="border-left:3px solid ${det.available ? 'var(--c-ok)' : 'var(--c-line)'}">
        <div class="card-head" style="margin-bottom:6px">
          <h3 style="font-size:14px">扫描件 OCR（把"搜不到"变成"搜得到"）</h3>
          <span class="tag ${det.available ? 'tag-green' : 'tag-gray'}">${det.available ? esc(det.engine) : '引擎不可用'}</span>
        </div>
        <div class="help" style="line-height:1.9">
          待识别 <b>${ocr.counts.candidates}</b> 个附件　·　已识别 <b>${ocr.counts.ocrDone}</b> 个（${ocr.counts.ocrChars} 字）　·　识别失败 ${ocr.counts.ocrFailed} 个
          ${det.windows ? `<br>Windows 自带识别：${esc((det.windows.langs || []).join(' / ') || '（无语言包）')}（无需安装任何软件）` : ''}
          ${det.tesseract ? `<br>tesseract ${esc(det.tesseract.version || '')}　语言包：${esc((det.tesseract.langs || []).slice(0, 8).join(' / ') || '（无）')}` : ''}
          <br>${pdfNote}
          ${(det.notes || []).map((n) => `<br><span style="color:var(--c-warn)">${esc(n)}</span>`).join('')}
          ${!det.available && det.reason ? `<br><span style="color:var(--c-warn)">${esc(det.reason)}</span>` : ''}
        </div>
        <div class="help" style="margin-top:6px">
          <b>本系统不捆绑也不下载 OCR 引擎</b>：装在本机就用、没装就如实说明。识别结果会标注为「OCR 来源」（可能有错字），
          且<b>不会覆盖</b>文档自带的文字层。
        </div>
        <div class="flex mt8">
          <button class="btn btn-sm" id="btn-ocr-detect">重新探测引擎</button>
          <button class="btn btn-sm btn-primary" id="btn-ocr-batch" ${det.available && ocr.counts.candidates ? '' : 'disabled'}>
            识别一批（最多 10 个）</button>
        </div>
        <div id="ocr-result" class="mt8"></div>
      </div>`;
      // 两个按钮都在卡片生成之后才存在，所以在这里绑（外面那层绑不到）
      const btnDetect = $('#btn-ocr-detect');
      if (btnDetect) {
        btnDetect.onclick = async () => {
          btnDetect.disabled = true;
          try {
            const r = await api('/api/ocr/detect', { method: 'POST', body: {} });
            const ver = (r.windows && r.windows.profileLang) || (r.tesseract && r.tesseract.version) || '';
            toast(r.available ? `已就绪：${r.engine}${ver ? ' ' + ver : ''}` : (r.reason || '仍未探测到 OCR 引擎'),
              r.available ? 'ok' : 'warn', 6000);
            setView('quality');
          } catch (e) { toast(e.message, 'err'); btnDetect.disabled = false; }
        };
      }
      const btnBatch = $('#btn-ocr-batch');
      if (btnBatch) {
        btnBatch.onclick = async () => {
          btnBatch.disabled = true;
          const box = $('#ocr-result');
          box.innerHTML = '<div class="help">正在识别…OCR 比较慢（一页约一秒），请勿关闭页面</div>';
          try {
            const r = await api('/api/ocr/batch', { method: 'POST', body: { limit: 10 } });
            const rows = (r.results || []).map((x) => `<tr>
              <td class="code" style="width:120px">${esc(x.archive_code || '')}</td>
              <td>${esc(x.original_name || '')}</td>
              <td class="nowrap">${x.ok ? `<span class="tag tag-green">识别 ${x.chars} 字</span>` : (x.skipped ? '<span class="tag tag-gray">跳过</span>' : '<span class="tag tag-red">失败</span>')}</td>
              <td class="muted" style="font-size:12px">${esc(x.reason || (x.engine || ''))}</td></tr>`).join('');
            box.innerHTML = `<div class="hint-box">成功 ${r.ok} · 失败 ${r.failed} · 跳过 ${r.skipped}，共识别 ${r.chars} 字，
              还剩 ${r.remaining} 个待识别${r.note ? '　' + esc(r.note) : ''}</div>
              ${rows ? `<div class="table-wrap" style="max-height:220px;overflow:auto"><table><tbody>${rows}</tbody></table></div>` : ''}`;
            toast(`OCR 完成：成功 ${r.ok} 个${r.failed ? `，失败 ${r.failed} 个` : ''}`, r.failed ? 'warn' : 'ok', 6000);
          } catch (e) {
            box.innerHTML = `<div class="hint-box warn">${esc(e.message)}</div>`;
          }
          btnBatch.disabled = false;
        };
      }
    })();

    $$('#content tr[data-aid]').forEach((tr) => {
      tr.onclick = () => openArchiveDetail(Number(tr.dataset.aid));
    });
  }

  // ---------------- 统计报表 ----------------
  async function renderReport(params) {
    const year = (params && params.year) || '';
    const d = await api('/api/stats/report' + (year ? '?year=' + encodeURIComponent(year) : ''));
    const bar = (rows, key) => {
      const max = Math.max(1, ...rows.map((r) => Number(r[key]) || 0));
      return rows.filter((r) => Number(r[key]) > 0).map((r) => `
        <div class="chart-row"><span class="lb" title="${esc(r.name)}">${esc(r.name)}</span>
          <span class="bar"><i style="width:${(Number(r[key]) / max * 100).toFixed(1)}%"></i></span>
          <span class="vl">${r[key]}</span></div>`).join('') || '<div class="muted">暂无数据</div>';
    };
    const tbl = (rows, name) => `<div class="table-wrap"><table><tbody>
      ${rows.map((r) => `<tr><td>${esc(name(r))}</td><td class="num">${r.count}</td></tr>`).join('')}
      </tbody></table></div>`;

    $('#content').innerHTML = `
      <div class="card">
        <div class="card-head"><h3>统计报表</h3>
          <div class="flex">
            <select id="rep-year" style="min-width:120px">
              <option value="">全部年度</option>
              ${d.years.map((y) => `<option value="${esc(y)}"${y === year ? ' selected' : ''}>${esc(y)} 年</option>`).join('')}
            </select>
            <button class="btn btn-sm btn-primary" id="rep-print">打印年报</button>
            <button class="btn btn-sm" id="rep-csv">导出 CSV</button>
          </div></div>
        <div class="grid grid-4">
          <div class="stat"><div class="stat-label">档案总数</div><div class="stat-value">${d.totals.total}</div><div class="stat-foot">${esc(d.year)}</div></div>
          <div class="stat"><div class="stat-label">总页数</div><div class="stat-value">${d.totals.pages}</div><div class="stat-foot">含电子与纸质登记</div></div>
          <div class="stat"><div class="stat-label">电子附件</div><div class="stat-value">${d.fileStats.total}</div><div class="stat-foot">占用 ${fmtSize(d.fileStats.bytes)}</div></div>
          <div class="stat"><div class="stat-label">可检索正文</div><div class="stat-value">${d.fileStats.indexed}</div><div class="stat-foot">${d.fileStats.textChars.toLocaleString()} 字</div></div>
        </div>
      </div>
      <div class="grid grid-2">
        <div class="card"><div class="card-head"><h3>按门类</h3></div>${bar(d.byType, 'count')}</div>
        <div class="card"><div class="card-head"><h3>按保管期限</h3></div>${bar(d.byRetention, 'count')}</div>
        <div class="card"><div class="card-head"><h3>按密级</h3></div>${bar(d.bySecret, 'count')}</div>
        <div class="card"><div class="card-head"><h3>按档案状态</h3></div>${bar(d.byStatus, 'count')}</div>
        <div class="card"><div class="card-head"><h3>按年度归档量</h3></div>${bar(d.byYear, 'count')}</div>
        <div class="card"><div class="card-head"><h3>按部门（前 10）</h3></div>${bar(d.byDepartment.slice(0, 10), 'count')}</div>
      </div>
      <div class="grid grid-3">
        <div class="card"><div class="card-head"><h3>借阅情况</h3><span class="sub">共 ${d.loanStats.total} 次</span></div>
          ${tbl(d.loanStats.byMode, (r) => r.name)}</div>
        <div class="card"><div class="card-head"><h3>鉴定情况</h3><span class="sub">共 ${d.appraisalStats.total} 次</span></div>
          ${tbl(d.appraisalStats.byDecision, (r) => r.name)}</div>
        <div class="card"><div class="card-head"><h3>销毁与移交</h3></div>
          <div class="dl" style="grid-template-columns:1fr">
            <div><span class="k">已销毁批次</span><span class="v">${d.destroyStats.batches} 个 / ${d.destroyStats.items} 件</span></div>
            <div><span class="k">移交批次</span><span class="v">${d.transferStats.batches} 个 / ${d.transferStats.items} 件</span></div>
            <div><span class="k">已接收</span><span class="v">${d.transferStats.accepted} 个批次</span></div>
          </div></div>
      </div>`;

    $('#rep-year').onchange = (e) => setView('report', e.target.value ? { year: e.target.value } : {});
    $('#rep-print').onclick = () => window.open('/api/stats/report/print' + (year ? '?year=' + encodeURIComponent(year) : ''), '_blank');
    $('#rep-csv').onclick = () => { window.location.href = '/api/stats/report.csv' + (year ? '?year=' + encodeURIComponent(year) : ''); };
  }

  // ---------------- 系统管理 ----------------
  async function renderManage(params) {
    let tab = (params && params.tab) || 'users';
    // 页签与"能不能改"都按**服务端下发的动作**判定（v4.17.0）。
    // 原来这里是 `role === 'admin'`：后果是系统管理员（sysadmin）登录后，
    // 档号规则、全宗号、二维码这些**本该他管的**设置全是灰的 —— 而他正是这个角色的职责所在。
    const canUsers = can('user:manage');        // 账号与角色
    const canMeta = can('meta:manage');         // 分类与门类
    const canSystem = can('system:manage');     // 档号规则、系统参数、二维码
    const canBackup = can('backup');            // 数据备份与调度
    const isAdmin = canSystem;
    const content = $('#content');

    // 停在没权限的页签上时自动退到「系统信息」（所有登录用户都看得到）。
    // 不这么做的话会渲染出一个"全是灰按钮"的空页面，使用者只会以为系统坏了。
    const tabAllowed = { users: canUsers, contacts: canUsers, cats: canMeta, numbering: canSystem, data: canBackup, trash: canDeleteArchive(), about: true,
      retention: canMeta, grants: canSecretClassify(), usage: can('audit:view') || can('log:view'),
      license: canSystem || can('audit:view') };
    if (!tabAllowed[tab]) tab = 'about';

    const numBtn = (t, label, ok) => (ok ? `<button class="btn btn-sm${tab === t ? ' btn-primary' : ''}" data-tab="${t}">${label}</button>` : '');
    let head = `<div class="card"><div class="card-head"><h3>系统管理</h3>
      <div class="flex">
        ${numBtn('users', '用户管理', canUsers)}
        ${numBtn('contacts', '找回方式', canUsers)}
        ${numBtn('cats', '分类与门类', canMeta)}
        ${numBtn('numbering', '档号规则', canSystem)}
        ${numBtn('retention', '保管期限表', canMeta)}
        ${numBtn('grants', '件级授权', canSecretClassify())}
        ${numBtn('usage', '利用登记', can('audit:view') || can('log:view'))}
        ${numBtn('license', '授权与外存', canSystem || can('audit:view'))}
        ${numBtn('data', '数据备份', canBackup)}
        ${numBtn('trash', '回收站', canDeleteArchive())}
        ${numBtn('about', '系统信息', true)}
      </div></div></div>`;

    // ---- 授权与外存（v4.33.0）----
    // 两件事放在一页：① 这套系统授权给谁、到什么时候（授权文件可换，读一次即可）；
    // ② 审计日志的"库外锚点"写到哪里（本机一份，另一块盘/NAS 再一份）。
    if (tab === 'license') {
      const lv = await api('/api/license').catch(() => null);
      const an = await api('/api/audit/anchor?limit=20').catch(() => null);
      const stTag = { ok: 'tag-green', none: 'tag-gray', expired: 'tag-amber', mismatch: 'tag-red', invalid: 'tag-red', unreadable: 'tag-red' };
      const lic = lv || {};
      const anchors = (an && an.local && an.local.list) || [];
      const mir = (an && an.mirror) || {};
      const settings = ((await api('/api/settings').catch(() => null)) || {}).settings || {};
      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>授权</h3>
            ${canSystem ? '<button class="btn btn-sm" id="lic-reload">重新读取授权</button>' : ''}</div>
          <div class="dl">
            <div><span>状态</span><b><span class="tag ${stTag[lic.state] || 'tag'}">${esc({
              ok: '有效', none: '未放置授权文件', expired: '已到期', mismatch: '机器码不符',
              invalid: '签名无效', unreadable: '文件读不出',
            }[lic.state] || lic.state || '')}</span></b></div>
            <div><span>授权单位</span><b>${esc(lic.unit || '—')}</b></div>
            <div><span>版本 / 模块</span><b>${esc(lic.edition || '—')}${(lic.modules || []).length ? `（${esc((lic.modules || []).join('、'))}）` : ''}</b></div>
            <div><span>有效期</span><b>${lic.expires_at ? `${esc(lic.expires_at)}${lic.remainDays !== null && lic.remainDays !== undefined ? `（剩 ${lic.remainDays} 天）` : ''}` : '—'}</b></div>
            <div><span>本机机器码</span><b class="mono">${esc((lic.machine || {}).code || '—')}</b></div>
            <div><span>授权文件</span><b class="mono" style="font-size:11.5px">${esc(lic.path || '—')}</b></div>
          </div>
          <div class="hint-box ${lic.readOnly ? 'warn' : ''}">${esc(lic.message || '')}</div>
          <div class="help">换机、续期时：把机器码报给发行方 → 拿到新的 license.json → 放到上面那个路径 → 点「重新读取授权」（或重启服务）。
            授权失效只会降级为<b>只读</b>：档案照常查、导出、备份，不会锁住数据。</div>
        </div>
        <div class="card">
          <div class="card-head"><h3>审计日志库外留存</h3>
            <button class="btn btn-sm btn-primary" id="an-run">立即生成锚点</button></div>
          <div class="hint-box">哈希链只能证明"库里的日志没被改"，挡不住"整库被换回旧备份"。
            每次锚点会记下"此刻日志共多少条、链尾是哪条、哈希多少"，并写到库外；
            配了外存目录时，新增日志还会追加成 JSONL 副本。</div>
          <div class="form-grid" style="margin-bottom:8px">
            <label class="field span-2"><span>外存目录（另一块盘 / NAS / U 盘，留空=只写本机）</span>
              <input type="text" id="an-dir" value="${esc(settings['audit.mirror_dir'] || '')}"
                placeholder="如 D:\\档案审计外存 或 \\\\192.168.1.10\\share\\archive-audit">
              <div class="help">只写本机同一块盘，挡不住整盘被换；真正的证据要落在别的地方。</div></label>
            <label class="field"><span>锚点间隔（小时）</span>
              <input type="number" id="an-hours" min="1" max="168" value="${esc(settings['audit.anchor_hours'] || 24)}"></label>
            <label class="field" style="align-self:end">${canSystem ? '<button class="btn btn-sm" id="an-save">保存设置</button>' : '<span class="muted">需要系统管理员权限修改</span>'}</label>
          </div>
          <div class="dl">
            <div><span>本地锚点</span><b>${anchors.length} 个（保留 ${(an && an.local && an.local.count) || 0} 个）</b></div>
            <div><span>最近一次</span><b>${anchors[0] ? `${fmtTime(anchors[0].at)}｜日志 ${anchors[0].logs_total} 条｜链${anchors[0].chain_ok ? '完整' : '<span style="color:#b91c1c">异常</span>'}` : '<span class="muted">还没有</span>'}</b></div>
            <div><span>外存状态</span><b>${mir.configured
    ? (mir.exists ? `${esc(mir.dir)}（${mir.files} 个副本文件，已同步到 #${mir.lastId || 0}）` : `<span style="color:#b91c1c">目录不可访问：${esc(mir.dir)}</span>`)
    : '<span class="muted">未配置</span>'}</b></div>
            <div><span>当前链</span><b>${an && an.tail ? `${an.tail.total} 条，链尾 #${an.tail.lastId}，校验${an.tail.chainOk ? '完整' : '<span style="color:#b91c1c">异常</span>'}` : '—'}</b></div>
          </div>
          ${anchors.length ? `<div class="table-wrap mt8"><table><thead><tr>
              <th class="nowrap">锚点时间</th><th class="nowrap">日志条数</th><th class="nowrap">链尾</th>
              <th class="nowrap">链校验</th><th>说明</th></tr></thead><tbody>
            ${anchors.slice(0, 12).map((x) => `<tr>
              <td class="nowrap muted">${fmtTime(x.at)}</td>
              <td class="nowrap">${x.logs_total}</td>
              <td class="nowrap mono" style="font-size:11px">#${x.last_id} ${esc(String(x.last_hash || '').slice(0, 10))}…</td>
              <td class="nowrap">${x.chain_ok ? '<span class="tag tag-green">完整</span>' : '<span class="tag tag-red">异常</span>'}</td>
              <td class="muted" style="font-size:12px">${esc(x.note || '')}${x.chain_reason ? '；' + esc(x.chain_reason) : ''}</td></tr>`).join('')}
            </tbody></table></div>` : ''}
        </div>`;

      const rl = $('#lic-reload');
      if (rl) rl.onclick = async () => {
        try {
          const r = await api('/api/license/reload', { method: 'POST', body: {} });
          toast(r.state === 'ok' ? `授权有效：${r.unit}` : ('授权未通过：' + r.message), r.state === 'ok' ? 'ok' : 'warn', 8000);
          setView('manage', { tab: 'license' });
        } catch (e) { toast(e.message, 'err'); }
      };
      const save = $('#an-save');
      if (save) save.onclick = async () => {
        try {
          await api('/api/settings', { method: 'PUT', body: {
            settings: { 'audit.mirror_dir': $('#an-dir').value.trim(), 'audit.anchor_hours': $('#an-hours').value.trim() || '24' },
          } });
          toast('已保存（锚点间隔下次启动生效）', 'ok');
          setView('manage', { tab: 'license' });
        } catch (e) { toast(e.message, 'err'); }
      };
      const run = $('#an-run');
      if (run) run.onclick = async () => {
        run.disabled = true; run.textContent = '生成中…';
        try {
          const r = await api('/api/audit/anchor/run', { method: 'POST', body: {} });
          toast(r.errors && r.errors.length
            ? '锚点已生成，但有提示：' + r.errors.join('；')
            : `锚点已生成：日志 ${r.anchor.logs_total} 条，外存追加 ${r.mirror.appended} 条`,
          r.errors && r.errors.length ? 'warn' : 'ok', 8000);
          setView('manage', { tab: 'license' });
        } catch (e) { toast(e.message, 'err'); run.disabled = false; run.textContent = '立即生成锚点'; }
      };
      return;
    }

    // ---- 保管期限表（v4.32.0）----
    // 期限不是一个填在每份档案上的自由文本：它来自本单位的《归档范围与保管期限表》。
    // 把这张表搬进系统，著录时才能"选事项、带期限、显依据"，而不是凭记忆填。
    if (tab === 'retention') {
      const d = await api('/api/retention/schedule');
      const list = d.list || [];
      const types = d.types || [];
      const rows = list.map((x) => `<tr>
          <td class="nowrap">${esc(x.type_name || x.type_code || '通用')}<div class="muted mono" style="font-size:11px">${esc(x.type_code || '—')}</div></td>
          <td>${esc(x.item)}${x.note ? `<div class="muted" style="font-size:11.5px">${esc(x.note)}</div>` : ''}</td>
          <td class="nowrap"><b>${esc(x.retention)}</b>${Number(x.years) > 0 ? `<div class="muted" style="font-size:11px">${Number(x.years)} 年后到期</div>` : ''}</td>
          <td class="muted" style="font-size:12px">${esc(x.basis || '')}</td>
          <td class="nowrap">${x.status === '停用' ? '<span class="tag tag-gray">停用</span>' : '<span class="tag tag-green">启用</span>'}</td>
          <td class="nowrap">
            <button class="btn btn-sm" data-rs-edit="${x.id}">改</button>
            <button class="btn btn-sm btn-danger" data-rs-del="${x.id}">删</button>
          </td></tr>`).join('') || '<tr><td colspan="6" class="muted">保管期限表还是空的，先加几条。</td></tr>';
      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>保管期限表（${list.length}）</h3>
            <button class="btn btn-sm btn-primary" id="rs-add">＋ 新增条目</button></div>
          <div class="hint-box">这张表是著录时"带出保管期限"的依据来源。改这里不会追溯修改已归档档案的期限
            —— 已归档的期限由<b>价值鉴定</b>变更，两者分开，才说得清"当初为什么定这个期限"。</div>
          <div class="table-wrap"><table><thead><tr>
            <th class="nowrap">门类</th><th>事项 / 文件材料</th><th class="nowrap">保管期限</th>
            <th>依据</th><th class="nowrap">状态</th><th class="nowrap">操作</th></tr></thead>
            <tbody>${rows}</tbody></table></div>
        </div>`;
      const editRow = (row) => promptDialog(row ? '修改保管期限条目' : '新增保管期限条目', [
        { name: 'type_code', label: '门类', type: 'select', value: row ? row.type_code : '',
          options: [{ value: '', label: '通用（不分门类）' }].concat(types.map((t) => ({ value: t.code, label: t.name }))) },
        { name: 'item', label: '事项 / 文件材料名称', required: true, value: row ? row.item : '' },
        { name: 'retention', label: '保管期限', type: 'select', value: row ? row.retention : '永久',
          options: d.retentions || ['永久', '定期30年', '定期10年', '定期5年', '长期'] },
        { name: 'basis', label: '依据', span2: true, value: row ? row.basis : '',
          help: '如《机关文件材料归档范围和文书档案保管期限规定》（国家档案局令第8号）第X条' },
        { name: 'note', label: '说明', span2: true, value: row ? row.note : '' },
        { name: 'status', label: '状态', type: 'select', value: row ? row.status : '启用', options: ['启用', '停用'] },
      ], async (data) => {
        if (row) await api('/api/retention/schedule/' + row.id, { method: 'PUT', body: data });
        else await api('/api/retention/schedule', { method: 'POST', body: data });
        toast('已保存', 'ok');
        setView('manage', { tab: 'retention' });
      }, { wide: true });
      const addBtn = $('#rs-add');
      if (addBtn) addBtn.onclick = () => editRow(null);
      content.querySelectorAll('[data-rs-edit]').forEach((b) => {
        b.onclick = () => editRow(list.find((x) => Number(x.id) === Number(b.dataset.rsEdit)));
      });
      content.querySelectorAll('[data-rs-del]').forEach((b) => {
        const row = list.find((x) => Number(x.id) === Number(b.dataset.rsDel));
        b.onclick = () => confirmDialog('删除保管期限条目',
          `确定删除「${row.item}」（${row.retention}）吗？已归档档案的期限不受影响。`, async () => {
            await api('/api/retention/schedule/' + row.id, { method: 'DELETE' });
            toast('已删除', 'ok');
            setView('manage', { tab: 'retention' });
          }, '确认删除');
      });
      return;
    }

    // ---- 件级授权台账（v4.32.0）----
    if (tab === 'grants') {
      const d = await api('/api/archive-grants');
      const list = d.list || [];
      const rows = list.map((x) => `<tr>
          <td class="nowrap mono">${esc(x.archive_code || '')}<div style="font-size:11px">${esc(x.title || '')}</div></td>
          <td class="nowrap">${esc(x.user_name || '')}<div class="muted" style="font-size:11px">${esc(x.user_department || '')}</div></td>
          <td>${esc(x.reason || '')}</td>
          <td class="nowrap">${esc(x.expires_at || '长期')}</td>
          <td class="nowrap">${x.status === '有效'
    ? (x.expires_at && x.expires_at < new Date().toISOString().slice(0, 10)
      ? '<span class="tag tag-amber">已过期</span>' : '<span class="tag tag-green">有效</span>')
    : `<span class="tag tag-gray">${esc(x.status)}</span>`}</td>
          <td class="nowrap muted">${esc(x.granted_name || '')}<div style="font-size:11px">${fmtTime(x.at)}</div></td>
          <td class="nowrap">${x.status === '有效' ? `<button class="btn btn-sm btn-danger" data-g-rev="${x.id}" data-g-a="${x.archive_id}">撤销</button>` : '<span class="muted">—</span>'}</td>
        </tr>`).join('') || '<tr><td colspan="7" class="muted">还没有件级授权。在档案详情页点「授权查阅」即可单独开一件。</td></tr>';
      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>件级授权台账（${list.length}）</h3></div>
          <div class="hint-box">密级与部门是<b>两道硬门槛</b>，件级授权是<b>第三把钥匙</b>：
            只对指定的一件、指定的一个账号、在指定期限内放行。每次凭授权查阅都会写一条审计，
            所以"谁看过这份机密件、凭什么看的"事后查得到。</div>
          <div class="table-wrap"><table><thead><tr>
            <th class="nowrap">档案</th><th class="nowrap">授权给</th><th>理由</th>
            <th class="nowrap">到期</th><th class="nowrap">状态</th><th class="nowrap">授权人</th><th class="nowrap">操作</th>
          </tr></thead><tbody>${rows}</tbody></table></div>
        </div>`;
      content.querySelectorAll('[data-g-rev]').forEach((b) => {
        b.onclick = () => confirmDialog('撤销件级授权', '撤销后该账号将立即无法查阅这一件（已产生审计不动）。', async () => {
          await api(`/api/archives/${b.dataset.gA}/grants/${b.dataset.gRev}`, { method: 'DELETE' });
          toast('已撤销', 'ok');
          setView('manage', { tab: 'grants' });
        }, '确认撤销');
      });
      return;
    }

    // ---- 利用登记（v4.32.0）----
    // 「谁用了什么、什么时候用的」——数字档案室年度统计与保密检查都要这份台账。
    if (tab === 'usage') {
      const kw = (params && params.kw) || '';
      const d = await api('/api/usage-registry?limit=100' + (kw ? '&kw=' + encodeURIComponent(kw) : ''));
      const list = d.list || [];
      const rows = list.map((x) => `<tr>
          <td class="nowrap muted">${fmtTime(x.at)}</td>
          <td class="nowrap">${esc(x.username || '')}<div class="muted" style="font-size:11px">${esc(x.department || '')}</div></td>
          <td class="nowrap"><span class="tag ${x.action === '下载' ? 'tag-amber' : 'tag-blue'}">${esc(x.action)}</span></td>
          <td class="nowrap mono">${esc(x.archive_code || '')}<div style="font-size:11px">${esc(x.title || '')}</div></td>
          <td class="muted" style="font-size:12px">${esc(x.target || '')}</td>
          <td class="nowrap muted mono" style="font-size:11px">${esc(x.ip || '')}</td></tr>`).join('')
        || '<tr><td colspan="6" class="muted">还没有利用记录。</td></tr>';
      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>利用登记（共 ${d.total || 0} 条）</h3>
            <div class="flex"><input id="ur-kw" placeholder="档号 / 题名 / 姓名" value="${esc(kw)}"
              style="padding:5px 8px;border:1px solid var(--c-line);border-radius:4px;width:180px">
              <button class="btn btn-sm" id="ur-go">查</button></div></div>
          <div class="hint-box">查阅、下载、预览都自动记一行 —— 不需要使用者手工登记。
            下载类记录同时是保密检查的取证材料（谁把哪份文件带出了系统）。</div>
          <div class="table-wrap"><table><thead><tr>
            <th class="nowrap">时间</th><th class="nowrap">使用人</th><th class="nowrap">动作</th>
            <th class="nowrap">档案</th><th>对象</th><th class="nowrap">IP</th></tr></thead>
            <tbody>${rows}</tbody></table></div>
        </div>`;
      const go = $('#ur-go');
      if (go) go.onclick = () => setView('manage', { tab: 'usage', kw: $('#ur-kw').value.trim() });
      const inp = $('#ur-kw');
      if (inp) inp.onkeydown = (e) => { if (e.key === 'Enter') go.click(); };
      return;
    }

    // ---- 回收站（v4.22.0）----
    // 删除不再是不可逆的：档案先进这里，保留期内可恢复；彻底清除才动物理附件。
    if (tab === 'trash') {
      const tr = await api('/api/trash');
      const list = tr.list || [];
      const rows = list.map((x) => `<tr>
          <td class="mono nowrap">${esc(x.archive_code || '')}
            <div class="muted" style="font-size:11px">${esc(x.archive_number || '')}</div></td>
          <td>${esc(x.title || '')}</td>
          <td class="nowrap">${esc(x.deleted_by_name || '')}
            <div class="muted" style="font-size:11px">${fmtTime(x.deleted_at)}</div></td>
          <td>${esc(x.reason || '')}</td>
          <td class="nowrap">${x.file_count || 0} 个</td>
          <td class="nowrap">${x.expired ? '<span class="tag tag-red">已到期</span>' : ((x.days_left === null || x.days_left === undefined) ? '—' : x.days_left + ' 天')}</td>
          <td class="nowrap">
            <button class="btn btn-sm" data-tact="restore" data-tid="${x.id}">恢复</button>
            <button class="btn btn-sm btn-danger" data-tact="purge" data-tid="${x.id}">彻底清除</button>
          </td></tr>`).join('');
      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>回收站（${tr.total || 0}）</h3></div>
          <div class="hint-box">删除的档案先放到这里，保留 <b>${tr.keepDays}</b> 天，期间可随时恢复。
            <b>物理附件在彻底清除之前不会删除</b> —— 所以恢复回来是真能拿到文件的。</div>
          <div class="hint-box warn">「彻底清除」不可恢复：档案、附件记录与磁盘上的附件文件都会被删掉。
            建议先确认保留期内确实不需要了再清。</div>
          ${list.length ? `<div class="table-wrap"><table><thead><tr>
              <th class="nowrap">档号</th><th>题名</th><th class="nowrap">删除人 / 时间</th>
              <th>删除原因</th><th class="nowrap">附件</th><th class="nowrap">剩余</th><th class="nowrap">操作</th>
            </tr></thead><tbody>${rows}</tbody></table></div>`
          : '<div class="empty"><b>回收站是空的</b>删除的档案会出现在这里，保留期内随时可以恢复。</div>'}
        </div>`;
      content.querySelectorAll('[data-tact]').forEach((b) => {
        const tid = Number(b.dataset.tid);
        const row = list.find((x) => Number(x.id) === tid) || {};
        if (b.dataset.tact === 'restore') {
          b.onclick = () => confirmDialog('恢复档案',
            `确定把《${row.title}》恢复到档案库吗？档号会原样恢复（${row.archive_code}），附件一并回来。`,
            async () => {
              const r = await api(`/api/trash/${tid}/restore`, { method: 'POST' });
              toast((r && r.note) || `已恢复：${row.archive_code}`, (r && r.missingFiles) ? 'warn' : 'ok', 8000);
              setView('manage', { tab: 'trash' });
            }, '确认恢复');
        } else {
          b.onclick = () => confirmDialog('彻底清除（不可恢复）',
            `确定彻底清除《${row.title}》吗？档案、附件记录与磁盘上的附件文件都会被删除，之后无法找回。`,
            async () => {
              const r = await api(`/api/trash/${tid}`, { method: 'DELETE' });
              toast(`已彻底清除：删除附件文件 ${r.removedFiles} 个`
                + (r.keptFiles ? `（另有 ${r.keptFiles} 个仍被其它档案引用，已保留）` : ''), 'ok', 8000);
              setView('manage', { tab: 'trash' });
            }, '确认清除');
        }
      });
    }

    if (tab === 'numbering') {
      const setRes = await api('/api/settings');
      const s = setRes.settings || {};
      let net = {
        base_url: '', lan_open: true, bind_host: '', port: '', qr_mode: 'url', candidates: [],
        base_kind: 'invalid', base_is_public: false, base_reason: '', base_source: '',
        archive_mode: 'url', qr_border: 6, qr_box_size: 15,
        qr_python_available: false, qr_python_exe: '', qr_python_version: '',
      };
      try { net = await api('/api/system/net'); } catch (_) { /* 取不到不影响其它设置项 */ }
      content.innerHTML = head + `
        <div class="grid grid-2">
          <div class="card">
            <div class="card-head"><h3>档号生成规则</h3></div>
            <div class="hint-box">档号规则决定系统自动编号的结果。现行标准（<b>DA/T 22—2015 §5.4</b>、<b>DA/T 13—2022</b>）规定的档号结构是「<b>全宗号-档案门类代码·年度-保管期限-机构(问题)代码-件号</b>」，例如 <span class="mono">Z001-WS·2026-D30-XZ-0001</span>，便于排架、移交与上级检查。<b>简化编号</b>适合刚开始规范化的小单位。旧的「全宗号-分类号-目录号-案卷号-件号」属于 <b>DA/T 13—1994</b> 的案卷级结构，已不是现行标准，仅为兼容既有单位保留。修改后只影响新档案，已有档案不受影响。</div>
            <label class="field"><span>全局档号模板</span>
              <input type="text" id="set-tpl" value="${esc(s['archive.code_template'] || '')}" ${isAdmin ? '' : 'disabled'}></label>
            <div class="help">可用占位符：<span class="mono">{unit} 全宗号 · {type} 门类代码 · {typeYear} 门类·年度 · {retention} 保管期限代码 · {org} 机构(问题) · {category} 分类号 · {catalog} 目录号 · {year} 年度 · {yy} 两位年度 · {seq4} 四位流水 · {volume} 案卷号 · {item} 件号</span></div>
            <div class="flex mt8">
              <button class="btn btn-sm" id="tpl-preset-dat22" ${isAdmin ? '' : 'disabled'}>套用：DA/T 22—2015 标准档号</button>
              <button class="btn btn-sm" id="tpl-preset-simple" ${isAdmin ? '' : 'disabled'}>套用：简化编号</button>
              <button class="btn btn-sm" id="tpl-preset-standard" ${isAdmin ? '' : 'disabled'}>套用：旧版案卷级档号</button>
              <button class="btn btn-sm btn-primary" id="tpl-preview" ${isAdmin ? '' : 'disabled'}>校验并预览</button>
            </div>
            <div id="tpl-result" class="mt16"></div>
            <div class="section-title">基础信息</div>
            <label class="field"><span>全宗号（{unit}）</span><input type="text" id="set-unit" value="${esc(s['archive.unit_code'] || '')}" ${isAdmin ? '' : 'disabled'}></label>
            <label class="field"><span>全宗名称（打印目录用）</span><input type="text" id="set-unitname" value="${esc(s['archive.unit_name'] || '')}" ${isAdmin ? '' : 'disabled'}></label>
            <label class="field"><span>目录号（{catalog}）</span><input type="text" id="set-catalog" value="${esc(s['archive.catalog_no'] || '01')}" ${isAdmin ? '' : 'disabled'}></label>
            <div class="form-actions">
              <button class="btn btn-primary" id="btn-save-settings" ${isAdmin ? '' : 'disabled'}>保存设置</button>
            </div>
          </div>
          <div class="card">
            <div class="card-head"><h3>借阅与到期提醒</h3></div>
            <label class="field"><span>借阅到期处理</span>
              <select id="set-autoreturn" ${isAdmin ? '' : 'disabled'}>
                <option value="1"${s['loans.auto_return'] === '1' ? ' selected' : ''}>到期自动归还（推荐）</option>
                <option value="0"${s['loans.auto_return'] === '0' ? ' selected' : ''}>到期标记逾期，人工办理归还</option>
              </select></label>
            <div class="help">电子档案借阅可选择到期自动归还；纸质原件建议改为人工办理，以便确认实物状态。</div>
            <label class="field mt16"><span>到期提醒提前年数</span>
              <input type="text" id="set-warn" value="${esc(s['appraisal.warn_years'] || '1')}" ${isAdmin ? '' : 'disabled'}></label>
            <div class="help">「到期与鉴定」默认展示最近这些年度的到期档案。</div>
            ${isAdmin ? '' : '<div class="hint-box warn mt16">只有管理员可以修改系统设置。</div>'}
            <div class="section-title">门类级规则</div>
            <div class="table-wrap"><table><thead><tr><th>门类</th><th>代码</th><th>专属档号模板</th></tr></thead>
              <tbody>${state.types.map((t) => `<tr><td>${esc(t.name)}</td><td class="mono">${esc(t.code)}</td>
                <td class="mono">${esc(t.code_template || '（沿用全局）')}</td></tr>`).join('')}</tbody></table></div>
            <div class="help">如需为某个门类单独设置档号规则，可在下方命令中设置，或在「分类与门类」中维护。</div>
          </div>
          <div class="card">
            <div class="card-head"><h3>二维码与手机扫码</h3></div>
            <div class="hint-box">手机扫码后能打开系统，需要三件事同时成立：<b>①</b>二维码内容是手机能访问的网址；<b>②</b>服务已开启局域网访问；<b>③</b>手机与本机在同一局域网。任何一条不成立，表现都是「扫不出来」。</div>
            <label class="field"><span>档案二维码内容</span>
              <select id="set-qrarchmode" ${isAdmin ? '' : 'disabled'}>
                <option value="url"${s['qr.archive_mode'] !== 'both' && s['qr.archive_mode'] !== 'code' ? ' selected' : ''}>网址（推荐）：扫码打开落地页，先显示档案号，再点链接进详情</option>
                <option value="both"${s['qr.archive_mode'] === 'both' ? ' selected' : ''}>档案号 + 网址：扫码器直接能看到编号，但链接可能点不动</option>
                <option value="code"${s['qr.archive_mode'] === 'code' ? ' selected' : ''}>只有档案号：给老式扫码枪 / 离线标签机</option>
              </select></label>
            <div class="help">一个二维码里只能装「一段文字」，所以「既显示档案号又能点链接」是靠落地页做到的：
              二维码写网址 → 打开落地页 → 页面上第一行大字就是档案号，下面才是「打开档案详情」的可点链接。
              选「档案号 + 网址」时，微信这类扫码器通常只当文本显示，链接点不动。</div>
            <label class="field"><span>二维码网址前缀（扫码的设备要能访问到这台机器）</span>
              <input type="text" id="set-qrbase" value="${esc(s['qr.base_url'] || '')}"
                     placeholder="http://10.20.30.40:8787　或　https://dangan.example.com" ${isAdmin ? '' : 'disabled'}></label>
            <div class="help">当前二维码里用的地址：<b class="mono">${esc(net.base_url || '—')}</b>
              ${net.base_kind === 'public' ? '<span class="tag tag-green">公网地址</span>'
    : (net.base_kind === 'private' ? '<span class="tag tag-blue">内网地址</span>'
      : '<span class="tag tag-red">不可用</span>')}<br>
              ${net.base_kind === 'private'
    ? '内网部署用这个地址是<b>正确</b>的：同一内网（政务内网/局域网）里的手机和电脑都能打开，不需要改成公网。'
      + '只有连不上这个内网的设备打不开 —— 那种情况本来也无法解决，除非让 IT 开通访问。'
      + '<br><b>但要留意 IP 会不会变：</b>如果这台机器的地址是自动获取的（DHCP），'
      + '换 IP 后屏幕上显示的二维码会自动重写（系统会比对内容并重做），'
      + '可<b>已经打印贴在盒子上的旧标签不会自己更新，需要重新打印</b>。'
      + '要彻底避免，请让 IT 给这台机器做「DHCP 保留（按 MAC 绑定固定 IP）」，'
      + '或者在内网 DNS 里加一条域名记录 —— 二维码里写域名就永远不会因换 IP 而失效。'
    : (net.base_kind === 'public'
      ? '对外可访问的地址，扫码的设备只要网络通就能打开。'
      : '这个地址只有本机自己能打开，手机一定打不开。请改成这台机器在内网里的地址'
        + '（如 <b>http://10.x.x.x:8787</b>，可在「扫码自检」里看到候选地址）或内网域名。')}</div>
            <div class="grid grid-2" style="gap:0 14px">
              <label class="field"><span>静区（留白）模块数</span>
                <input type="number" id="set-qrborder" min="0" max="16" value="${esc(s['qr.border'] || '6')}" ${isAdmin ? '' : 'disabled'}></label>
              <label class="field"><span>每模块像素（box_size）</span>
                <input type="number" id="set-qrbox" min="1" max="40" value="${esc(s['qr.box_size'] || '15')}" ${isAdmin ? '' : 'disabled'}></label>
            </div>
            <div class="help">静区规范最低要求 <b>4</b> 个模块，默认 <b>6</b> 更保险（多留一圈白边，剪裁或贴花背景时不容易扫不出）。
              每模块像素默认 <b>15</b>，调大只是图片更清晰、文件更大，不改变二维码内容。改完点「全部重新生成」重写已有图片。</div>
            <label class="field"><span>落地页是否显示题名</span>
              <select id="set-qrshowtitle" ${isAdmin ? '' : 'disabled'}>
                <option value="1"${s['qr.scan_show_title'] !== '0' ? ' selected' : ''}>显示（拿着实物档案的人才能扫到，信息更有用）</option>
                <option value="0"${s['qr.scan_show_title'] === '0' ? ' selected' : ''}>不显示（落地页只出现档案号，最保守）</option>
              </select></label>
            <div class="help">落地页带了签名令牌，别人无法顺着档案号枚举；
              但落地页本身不需要登录，建议按单位保密要求决定是否显示题名。</div>
            <label class="field"><span>档案盒二维码内容</span>
              <select id="set-qrmode" ${isAdmin ? '' : 'disabled'}>
                <option value="url"${s['qr.mode'] !== 'code' ? ' selected' : ''}>网址（手机扫码可打开盒内清单，推荐）</option>
                <option value="code"${s['qr.mode'] === 'code' ? ' selected' : ''}>纯编号（老式扫码枪 / 离线标签机）</option>
              </select></label>
            <label class="field"><span>每份档案二维码的生成引擎</span>
              <select id="set-qrengine" ${isAdmin ? '' : 'disabled'}>
                <option value="auto"${s['qr.engine'] !== 'python' && s['qr.engine'] !== 'builtin' ? ' selected' : ''}>自动（本机有 Python + qrcode 就用它，没有则用内置引擎）</option>
                <option value="python"${s['qr.engine'] === 'python' ? ' selected' : ''}>Python 的 qrcode 库（ERROR_CORRECT_H + border/box_size 同上）</option>
                <option value="builtin"${s['qr.engine'] === 'builtin' ? ' selected' : ''}>只用系统内置引擎（不需要 Python）</option>
              </select></label>
            <div class="help">本机 Python 检测：${net.qr_python_available
    ? '<b>可用</b>（' + esc(net.qr_python_exe || '') + (net.qr_python_version ? ' / Python ' + esc(net.qr_python_version) : '') + '）'
    : '<b>不可用</b>，将自动使用内置引擎'}<br>
              两个引擎的参数、二维码内容与文件命名规则完全一致，随时切换不会产生重复文件。</div>
            <div class="flex mt8" style="flex-wrap:wrap">
              <button class="btn btn-sm btn-primary" id="btn-scan-check">扫码自检</button>
              <button class="btn btn-sm" id="btn-qr-debug">二维码调试页</button>
            </div>
          </div>
        </div>`;

      // 事件绑定要在任何 await 之前完成：
      // 这一页后面还要 await 校验档号模板，若把绑定写在 await 之后，
      // 页面已经显示出来但按钮还没生效，手快的人点了没反应（冒烟测试抓到过）。
      const scanBtn = $('#btn-scan-check');
      if (scanBtn) scanBtn.onclick = () => openScanCheck();
      const dbgBtn = $('#btn-qr-debug');
      if (dbgBtn) dbgBtn.onclick = () => window.open('/api/qrcode/debug', '_blank');

      const doPreview = async () => {
        const r = await api('/api/settings/check-template', {
          method: 'POST',
          body: {
            template: $('#set-tpl').value,
            type_code: state.types[0] ? state.types[0].code : 'WS',
            category_id: state.catFlat[1] ? state.catFlat[1].id : null,
            year: String(new Date().getFullYear()),
          },
        });
        $('#tpl-result').innerHTML = r.valid
          ? `<div class="hint-box">校验通过。按此规则，下一条档案的档号将是：<b class="mono">${esc(r.preview)}</b></div>`
            + ((r.warnings && r.warnings.length)
              ? r.warnings.map((w) => `<div class="hint-box warn">标准符合性提示：${esc(w)}</div>`).join('')
              : '')
          : `<div class="hint-box warn">规则有问题：${esc(r.error)}</div>`;
      };
      if (isAdmin) {
        $('#tpl-preset-dat22').onclick = () => { $('#set-tpl').value = '{unit}-{typeYear}-{retention}-{org}-{item}'; doPreview(); };
        $('#tpl-preset-simple').onclick = () => { $('#set-tpl').value = '{unit}-{category}-{year}-{seq4}'; doPreview(); };
        $('#tpl-preset-standard').onclick = () => { $('#set-tpl').value = '{unit}-{category}-{catalog}-{volume}-{item}'; doPreview(); };
        $('#tpl-preview').onclick = doPreview;
        $('#btn-save-settings').onclick = async () => {
          try {
            const r = await api('/api/settings', {
              method: 'PUT',
              body: {
                settings: {
                  'archive.code_template': $('#set-tpl').value,
                  'archive.unit_code': $('#set-unit').value,
                  'archive.unit_name': $('#set-unitname').value,
                  'archive.catalog_no': $('#set-catalog').value,
                  'loans.auto_return': $('#set-autoreturn').value,
                  'appraisal.warn_years': $('#set-warn').value,
                  'qr.mode': $('#set-qrmode').value,
                  'qr.base_url': $('#set-qrbase').value,
                  'qr.engine': $('#set-qrengine').value,
                  'qr.archive_mode': $('#set-qrarchmode').value,
                  'qr.border': $('#set-qrborder').value,
                  'qr.box_size': $('#set-qrbox').value,
                  'qr.scan_show_title': $('#set-qrshowtitle').value,
                },
              },
            });
            state.settings = null;
            await loadMeta();
            // 二维码参数改了，已有图片还是旧的参数，提醒重生成
            const qrChanged = ['qr.border', 'qr.box_size', 'qr.base_url', 'qr.archive_mode']
              .some((k) => (r.changed || []).includes(k));
            // 提醒（不是错误）：内网地址是内网部署时的正常选择，用中性样式，
            // 不要用红色错误提示吓人 —— 曾经把内网地址当成错误拦下来过，教训。
            if (r.warning) toast(r.warning, 'warn', 9000);
            else toast('设置已保存' + (qrChanged ? '（二维码参数变了，建议到「数据备份 → 档案二维码 → 全部重新生成」重写已有图片）' : ''),
              'ok', qrChanged ? 8000 : 3000);
            if (qrChanged) setView('manage', { tab: 'numbering' });
          } catch (e) { toast(e.message, 'err', 9000); }
        };
        await doPreview();
      }
      $$('#content [data-tab]').forEach((b) => { b.onclick = () => setView('manage', { tab: b.dataset.tab }); });
      return;
    }

    if (tab === 'contacts') {
      // 找回方式登记（v4.30.9）：给每个账号提前登记手机号与邮箱。
      // 单独做成一个页签、而不是塞进用户管理，是因为"登记联系方式"是日常维护动作，
      // 与"改角色/停用账号"这类危险操作分开 —— 少一次误点的机会。
      const d = await api('/api/users');
      const rec = d.recovery || {};
      const list = d.list.filter((x) => x.status === 'active');
      const hasPhone = list.filter((x) => x.phone).length;
      const hasMail = list.filter((x) => x.email).length;
      const stateTag = (u) => {
        if (u.phone && u.email) return '<span class="tag tag-green">手机 + 邮箱</span>';
        if (u.phone) return '<span class="tag tag-blue">仅手机号</span>';
        if (u.email) return '<span class="tag tag-blue">仅邮箱</span>';
        return '<span class="tag tag-amber">未登记</span>';
      };
      const rows = list.map((u) => `<tr>
          <td class="mono">${esc(u.username)}</td>
          <td>${esc(u.display_name)}</td>
          <td class="muted">${esc(state.roleNames[u.role] || u.role)}</td>
          <td class="mono">${u.phone ? esc(u.phone) : '<span style="color:var(--c-warn)">未登记</span>'}</td>
          <td class="mono">${u.email ? esc(u.email) : '<span style="color:var(--c-warn)">未登记</span>'}</td>
          <td>${stateTag(u)}</td>
          <td class="nowrap"><button class="btn btn-sm${(!u.phone || !u.email) ? ' btn-primary' : ''}" data-cact="edit" data-uid="${u.id}">${(!u.phone && !u.email) ? '登记' : '修改'}</button></td>
        </tr>`).join('') || '<tr><td colspan="7" class="empty"><b>没有启用的账号</b></td></tr>';

      content.innerHTML = head + `
        <div class="card">
          <div class="card-head"><h3>找回方式登记 <span class="sub">手机号 ${hasPhone}/${list.length} · 邮箱 ${hasMail}/${list.length}</span></h3></div>
          <div class="hint-box">在这里提前把每个人的<b>手机号</b>和<b>邮箱</b>登记好，以后他们忘记口令时才能自己找回来，
            不必每次都麻烦管理员重置。<br>
            · <b>手机号</b>：11 位手机号，一个号码只能对应一个账号；${rec.smsConfigured
    ? `短信通道已配置（${esc(rec.smsProvider || '已配置')}），登记后即可用验证码自己重置。`
    : '<span style="color:var(--c-warn)">短信通道还没配置</span>，登记了暂时也发不出验证码 —— 配置方法见程序目录下的《短信登录配置说明.txt》。'}<br>
            · <b>邮箱</b>：每个账号一个邮箱（一个邮箱只能对应一个账号），找回时用各自的邮箱收验证码。${rec.emailConfigured
      ? `邮件通道已配置（发件人 ${esc(rec.emailFrom || rec.emailProvider || 'smtp')}），登记后即可自己找回。`
      : '<span style="color:var(--c-warn)">邮件通道还没配置</span>，登记了暂时也发不出验证码 —— 配置方法见程序目录下的《邮件找回配置说明.txt》。'}<br>
            · 三员账号（系统管理员 / 安全保密员 / 审计员）出于职责分离，不支持自助找回，只能由管理员重置。</div>
          <div class="table-wrap"><table><thead><tr><th>账号</th><th>姓名</th><th>角色</th><th>手机号</th><th>邮箱</th><th>登记情况</th><th></th></tr></thead>
            <tbody>${rows}</tbody></table></div>
        </div>`;

      $$('#content [data-cact="edit"]').forEach((b) => {
        const uid = Number(b.dataset.uid);
        const u = list.find((x) => x.id === uid);
        b.onclick = () => promptDialog('登记找回方式：' + u.username, [
          { name: 'phone', label: '手机号（找回口令用）', value: u.phone, placeholder: '11 位手机号，可留空',
            help: '一个手机号只能对应一个账号；改了立即生效。' },
          { name: 'email', label: '邮箱（备用，邮件找回待开通）', value: u.email, placeholder: 'name@example.com，可留空',
            help: '目前只做登记、不会立即发信；开通邮件找回后直接生效。' },
        ], async (data) => {
          await api('/api/users/' + uid, { method: 'PUT', body: data });
          toast('已保存', 'ok'); setView('manage', { tab: 'contacts' });
        }, { wide: true });
      });
    } else if (tab === 'users') {
      if (!isAdmin) {
        content.innerHTML = head + '<div class="card"><div class="empty"><b>权限不足</b>仅管理员可管理用户</div></div>';
      } else {
        const d = await api('/api/users');
        // 默认只列**启用**的账号（v4.20.1）。
        // 为什么会有停用账号：账号一旦被业务记录或审计日志引用，系统就只停用不删除 ——
        // 删掉用户行，审计日志里"这是谁做的"就查不出来了（《档案法》第三十五条要求可追溯）。
        // 所以列表默认把它们折叠起来，需要时点一下展开，既不碍眼、也不丢可追溯性。
        const showDisabled = !!(params && params.showDisabled);
        const shown = showDisabled ? d.list : d.list.filter((x) => x.status === 'active');
        const disabledCount = d.list.filter((x) => x.status !== 'active').length;
        const rows = shown.map((u) => `
          <tr><td class="mono">${esc(u.username)}</td><td>${esc(u.display_name)}</td>
          <td><span class="tag ${u.role === 'admin' ? 'tag-red' : (u.role === 'clerk' ? 'tag-blue' : 'tag-gray')}">${esc(state.roleNames[u.role] || u.role)}</span></td>
          <td>${esc(u.department || '')}</td><td class="muted">${u.phone ? esc(u.phone) : '<span style="color:var(--c-warn)">未登记</span>'}</td>
          <td class="muted">${u.email ? esc(u.email) : '<span style="color:var(--c-warn)">未登记</span>'}</td>
          <td>${u.status === 'active' ? '<span class="tag tag-green">启用</span>' : '<span class="tag tag-gray">停用</span>'}</td>
          <td class="nowrap muted">${fmtDay(u.created_at)}</td>
          <td class="nowrap">
            <button class="btn btn-sm" data-uact="edit" data-uid="${u.id}">编辑</button>
            <button class="btn btn-sm" data-uact="pwd" data-uid="${u.id}">重置密码</button>
            ${u.id === state.user.id ? '' : `<button class="btn btn-sm btn-danger" data-uact="del" data-uid="${u.id}">删除</button>`}
          </td></tr>`).join('') || '<tr><td colspan="9" class="empty"><b>没有启用的账号</b></td></tr>';
        content.innerHTML = head + `
          <div class="card">
            <div class="card-head"><h3>用户管理 <span class="sub">共 ${shown.length} 个启用账号${disabledCount ? `（另有 ${disabledCount} 个已停用）` : ''}</span></h3>
              <div class="flex">
                ${disabledCount ? `<button class="btn btn-sm" id="toggle-disabled">${showDisabled ? '只看启用' : `显示已停用 ${disabledCount}`}</button>` : ''}
                <button class="btn btn-sm btn-primary" id="add-user">＋ 新增用户</button>
              </div></div>
            <div class="hint-box">当前只有两种身份：<b>档案管理员</b> 能操作一切（含账号管理、系统设置、备份）；
              <b>其他人员</b> 只能查阅（检索、看正文、申请借阅），不能新建、修改、删除。<br>
              <b>手机号</b>与<b>邮箱</b>用于「忘记口令」时自己找回：手机号要填 11 位、
              且<b>短信通道必须先配置好</b>（未配置时登录页会直接提示，不会假装发出）；
              邮箱与手机号一样，一个只能对应一个账号（找回时按地址投递，重复了就说不清该重置谁）。批量登记建议用旁边「找回方式」页签。</div>
            <div class="table-wrap"><table><thead><tr><th>用户名</th><th>姓名</th><th>角色</th><th>部门</th><th>手机号</th><th>邮箱</th><th>状态</th><th>创建日期</th><th>操作</th></tr></thead>
              <tbody>${rows}</tbody></table></div>
          </div>`;
        const toggle = $('#toggle-disabled');
        if (toggle) toggle.onclick = () => setView('manage', { tab: 'users', showDisabled: !showDisabled });
        $('#add-user').onclick = () => promptDialog('新增用户', [
          { name: 'username', label: '用户名', required: true, placeholder: '3-32 位字母数字' },
          { name: 'display_name', label: '姓名', required: true },
          { name: 'password', label: '初始密码', required: true, placeholder: '至少 8 位，且不能包含用户名' },
          { name: 'role', label: '角色', type: 'select', options: roleOptions(), value: 'reader' },
          { name: 'department', label: '部门' },
          { name: 'phone', label: '手机号（找回口令用）', placeholder: '11 位手机号，可留空',
            help: '填了以后，这个人忘记口令时可以用手机验证码自己重置；一个手机号只能对应一个账号。' },
          { name: 'email', label: '邮箱（备用）', placeholder: 'name@example.com，可留空',
            help: '先登记备用；邮件找回功能开通后立即生效。' },
        ], async (data) => {
          await api('/api/users', { method: 'POST', body: data });
          toast('已新增用户', 'ok'); setView('manage', { tab: 'users' });
        }, { wide: true });

        $$('#content [data-uact]').forEach((b) => {
          const uid = Number(b.dataset.uid);
          const u = d.list.find((x) => x.id === uid);
          b.onclick = async () => {
            const act = b.dataset.uact;
            if (act === 'edit') {
              promptDialog('编辑用户：' + u.username, [
                { name: 'display_name', label: '姓名', value: u.display_name },
                { name: 'role', label: '角色', type: 'select', value: u.role, options: roleOptions(u.role) },
                { name: 'department', label: '部门', value: u.department },
                { name: 'phone', label: '手机号（找回口令用）', value: u.phone, placeholder: '11 位手机号，可留空',
                  help: '改了就立即生效；一个手机号只能对应一个账号。' },
                { name: 'email', label: '邮箱（备用）', value: u.email, placeholder: 'name@example.com，可留空',
                  help: '先登记备用；邮件找回功能开通后立即生效。' },
                { name: 'status', label: '状态', type: 'select', value: u.status, options: [{ value: 'active', label: '启用' }, { value: 'disabled', label: '停用' }] },
              ], async (data) => {
                await api('/api/users/' + uid, { method: 'PUT', body: data });
                toast('已保存', 'ok'); setView('manage', { tab: 'users' });
              }, { wide: true });
            } else if (act === 'pwd') {
              const h = pwdHint();
              promptDialog('重置密码：' + u.username,
                [{ name: 'password', label: '新密码', required: true, placeholder: h.placeholder, help: h.help, span2: true }],
                async (data) => {
                  await api(`/api/users/${uid}/reset-password`, { method: 'POST', body: data });
                  toast('密码已重置，该用户需重新登录', 'ok');
                }, { wide: true });
            } else if (act === 'del') {
              confirmDialog('删除用户', `确定删除账号「${u.username}」吗？`, async () => {
                const r = await api('/api/users/' + uid, { method: 'DELETE' });
                toast(r && r.disabled ? '该用户有业务记录，已改为停用' : '已删除', 'ok');
                setView('manage', { tab: 'users' });
              }, '确认删除');
            }
          };
        });
      }
    } else if (tab === 'cats') {
      const catData = await api('/api/categories');
      const typeData = await api('/api/types');
      const catRows = catData.flat.map((c) => `
        <tr><td style="padding-left:${c.level === 1 ? 10 : 34}px">
            ${c.level === 1 ? `<b>${esc(c.name)}</b>` : '└ ' + esc(c.name)}</td>
          <td class="mono">${esc(c.code)}</td>
          <td class="num">${c.archive_count}</td>
          <td class="muted">${esc(c.remark || '')}</td>
          <td class="nowrap">${isAdmin ? `<button class="btn btn-sm" data-cact="edit" data-cid="${c.id}">编辑</button>
            <button class="btn btn-sm btn-danger" data-cact="del" data-cid="${c.id}">删除</button>` : ''}</td></tr>`).join('');
      const typeRows = typeData.list.map((t) => `
        <tr data-tid="${t.id}"><td><b>${esc(t.name)}</b></td><td class="mono">${esc(t.code)}</td>
        <td>${esc(t.retention)}</td><td class="num">${t.archive_count}</td>
        <td class="muted">${t.fields.map((f) => esc(f.label)).join('、') || '—'}</td>
        <td class="nowrap">${isAdmin ? `<button class="btn btn-sm" data-tact="fields" data-tid="${t.id}">配置著录项</button>` : ''}</td></tr>`).join('');

      content.innerHTML = head + `
        <div class="grid cats-grid">
          <div class="card">
            <div class="card-head"><h3>档案分类</h3>${isAdmin ? '<button class="btn btn-sm btn-primary" id="add-cat">＋ 新增分类</button>' : ''}</div>
            <div class="table-wrap"><table><thead><tr><th>分类名称</th><th>代码</th><th class="num">档案数</th><th>备注</th><th></th></tr></thead>
              <tbody>${catRows}</tbody></table></div>
          </div>
          <div class="card" id="type-card">
            <div class="card-head"><h3>档案门类与著录项</h3>${isAdmin ? '<button class="btn btn-sm btn-primary" id="add-type">＋ 新增门类</button>' : ''}</div>
            <div class="table-wrap"><table><thead><tr><th>门类</th><th>代码</th><th>默认保管期限</th><th class="num">档案数</th><th>专用著录项</th><th></th></tr></thead>
              <tbody>${typeRows}</tbody></table></div>
            <div class="help">${isAdmin ? '<b>右键</b>门类行可快速“新增门类 / 调整名称与期限 / 配置著录项”。' : ''}著录项以 JSON 配置，例如：<span class="mono">[{"key":"hth","label":"合同编号","type":"text"}]</span></div>
          </div>
        </div>`;

      const addCat = $('#add-cat');
      if (addCat) addCat.onclick = () => promptDialog('新增分类', [
        { name: 'parent_id', label: '上级分类', type: 'select', options: [{ value: '', label: '（作为一级分类）' }].concat(catData.flat.filter((c) => c.level === 1).map((c) => ({ value: c.id, label: c.name }))) },
        { name: 'name', label: '分类名称', required: true },
        { name: 'code', label: '分类代码', required: true, placeholder: '如 WS-XZ2' },
        { name: 'remark', label: '备注' },
      ], async (d) => {
        await api('/api/categories', { method: 'POST', body: d });
        toast('已新增', 'ok'); setView('manage', { tab: 'cats' });
      });

      // —— 门类：新增 / 编辑 / 著录项，三个入口（按钮、右键菜单、行内按钮）复用同一套对话框 ——
      const openTypeAdd = () => typeAddDialog(() => setView('manage', { tab: 'cats' }));

      const openTypeEdit = (t) => promptDialog('编辑门类：' + t.name, [
        { name: 'name', label: '门类名称', value: t.name, required: true },
        { name: 'retention', label: '默认保管期限', type: 'select', value: t.retention, options: state.meta.retentions },
        // 下拉的默认项只能是第一项（promptDialog 不回填 select），所以按当前值排序
        { name: 'filing_mode', label: '整理方式', type: 'select', span2: true,
          options: t.filing_mode === 'project'
            ? [{ value: 'project', label: '按项目整理（长期项目跨年度连续编号）' },
              { value: 'year', label: '按年度整理（一年一组，跨年断开）' }]
            : [{ value: 'year', label: '按年度整理（一年一组，跨年断开）' },
              { value: 'project', label: '按项目整理（长期项目跨年度连续编号）' }],
          help: '改了整理方式只影响以后新编的档号，已经编好的档号不会变。' },
        { name: 'prefix', label: '档号前缀', value: t.prefix, placeholder: '如 WS-' },
        { name: 'sort_no', label: '排序号', value: t.sort_no, help: '数字越小越靠前，新增菜单按此排序' },
      ], async (d) => {
        await api('/api/types/' + t.id, { method: 'PUT', body: { name: d.name, retention: d.retention, prefix: d.prefix, sort_no: d.sort_no, filing_mode: d.filing_mode } });
        state.types = []; state.meta = {};
        toast('已保存', 'ok'); setView('manage', { tab: 'cats' });
      });

      const openTypeFields = (t) => promptDialog('配置著录项：' + t.name, [
        { name: 'fields', label: '专用著录项（JSON 数组）', type: 'textarea', span2: true, value: JSON.stringify(t.fields, null, 1) },
        { name: 'retention', label: '默认保管期限', type: 'select', value: t.retention, options: state.meta.retentions },
      ], async (d) => {
        let fields;
        try { fields = JSON.parse(d.fields); } catch (_) { throw new Error('JSON 格式错误'); }
        if (!Array.isArray(fields)) throw new Error('必须是数组');
        await api('/api/types/' + t.id, { method: 'PUT', body: { fields, retention: d.retention } });
        state.types = []; state.meta = {};
        toast('已保存', 'ok'); setView('manage', { tab: 'cats' });
      }, { wide: true });

      const addType = $('#add-type');
      if (addType) addType.onclick = openTypeAdd;

      $$('#content [data-cact]').forEach((b) => {
        const cid = Number(b.dataset.cid);
        const c = catData.flat.find((x) => x.id === cid);
        b.onclick = async () => {
          if (b.dataset.cact === 'edit') {
            promptDialog('编辑分类：' + c.name, [
              { name: 'name', label: '分类名称', value: c.name, required: true },
              { name: 'code', label: '分类代码', value: c.code, required: true },
              { name: 'sort_no', label: '排序号', value: c.sort_no },
              { name: 'remark', label: '备注', value: c.remark || '' },
            ], async (d) => {
              await api('/api/categories/' + cid, { method: 'PUT', body: d });
              toast('已保存', 'ok'); setView('manage', { tab: 'cats' });
            });
          } else {
            confirmDialog('删除分类', `确定删除分类「${c.name}」吗？`, async () => {
              await api('/api/categories/' + cid, { method: 'DELETE' });
              toast('已删除', 'ok'); setView('manage', { tab: 'cats' });
            }, '确认删除');
          }
        };
      });

      $$('#content [data-tact]').forEach((b) => {
        const tid = Number(b.dataset.tid);
        const t = typeData.list.find((x) => x.id === tid);
        b.onclick = () => openTypeFields(t);
      });

      // 右键门类列表：新增最常用，放第一项；行上再给“调整名称/期限”
      const typeCard = $('#type-card');
      if (typeCard) {
        typeCard.addEventListener('contextmenu', (ev) => {
          if (!isAdmin) return;
          ev.preventDefault();
          const tr = ev.target.closest('tr[data-tid]');
          const t = tr ? typeData.list.find((x) => x.id === Number(tr.dataset.tid)) : null;
          const items = t
            ? [
                { label: '＋ 新增门类', onClick: openTypeAdd },
                { sep: true },
                { label: `✎ 调整「${t.name}」名称/期限`, onClick: () => openTypeEdit(t) },
                { label: '⚙ 配置专用著录项', onClick: () => openTypeFields(t) },
                { sep: true },
                { label: '↻ 刷新门类列表', onClick: () => setView('manage', { tab: 'cats' }) },
              ]
            : [
                { label: '＋ 新增门类', onClick: openTypeAdd },
                { label: '↻ 刷新门类列表', onClick: () => setView('manage', { tab: 'cats' }) },
              ];
          showContextMenu(ev.clientX, ev.clientY, items);
        });
      }
    } else if (tab === 'data') {
      const s = await api('/api/stats/overview');
      let qrs = { archives: 0, images: 0, missing: 0, bytes: 0, dir: '', ec_level: 'H', margin: 4, scale: 10 };
      try { qrs = await api('/api/qrcodes/stats'); } catch (_) { /* 取不到不影响本页其它内容 */ }
      content.innerHTML = head + `
        <div class="grid grid-2">
          <div class="card">
            <div class="card-head"><h3>全库备份导出</h3></div>
            <div class="hint-box">导出的 ZIP 包含：数据库快照 db/archive.db、全部电子附件 files/、以及说明文件 manifest.json。</div>
            <p style="line-height:1.9;color:var(--c-text-2)">
              当前馆藏 <b>${s.total}</b> 条档案、<b>${s.fileCount}</b> 个附件，占用 <b>${fmtSize(s.storageBytes)}</b>。
            </p>
            <div class="flex">
              <button class="btn btn-primary" id="btn-backup" ${isAdmin ? '' : 'disabled'}>立即导出备份</button>
              <button class="btn" id="btn-csv">导出档案目录 CSV</button>
            </div>
            ${isAdmin ? '' : '<div class="help">备份导出需要管理员权限。</div>'}
            <div class="section-title">恢复方法</div>
            <ol style="line-height:1.9;color:var(--c-text-2);margin:0;padding-left:20px">
              <li>停止系统（关闭启动窗口，或按 Ctrl+C）</li>
              <li>解压备份 ZIP，用其中的 <span class="mono">db/archive.db</span> 覆盖 <span class="mono">data/archive.db</span></li>
              <li>把备份中的 <span class="mono">files/</span> 目录整体放回 <span class="mono">data/files/</span></li>
              <li>重新启动系统即可</li>
            </ol>
          </div>
          <div class="card">
            <div class="card-head"><h3>数据体检</h3></div>
            <div class="dl" style="grid-template-columns:1fr">
              <div><span class="k">档案总数</span><span class="v">${s.total}</span></div>
              <div><span class="k">无附件档案</span><span class="v">${s.noFile} ${s.noFile ? '<span class="tag tag-amber">建议补充扫描件</span>' : ''}</span></div>
              <div><span class="k">电子附件</span><span class="v">${s.fileCount} 个 / ${fmtSize(s.storageBytes)}</span></div>
              <div><span class="k">借出未还</span><span class="v">${s.loanStats.active} ${s.loanStats.overdue ? `<span class="tag tag-red">逾期 ${s.loanStats.overdue}</span>` : ''}</span></div>
              <div><span class="k">待审批申请</span><span class="v">${s.loanStats.pending}</span></div>
            </div>
            <div class="section-title">保管期限提示</div>
            <div class="table-wrap"><table><thead><tr><th>保管期限</th><th class="num">档案数</th></tr></thead>
              <tbody>${s.byRetention.map((r) => `<tr><td>${esc(r.name)}</td><td class="num">${r.count}</td></tr>`).join('')}</tbody></table></div>
          </div>
          <div class="card">
            <div class="card-head"><h3>档案二维码</h3></div>
            <div class="hint-box">系统每次启动都会自动为每份档案生成一张二维码图片（纠错等级 H、静区 4 模块、模块 10 像素），
              文件名按档号自动命名，存放在 <span class="mono">data/qrcodes</span>，同时写一份「清单.csv」。</div>
            <div class="dl" style="grid-template-columns:1fr">
              <div><span class="k">档案总数</span><span class="v">${qrs.archives}</span></div>
              <div><span class="k">已生成图片</span><span class="v">${qrs.images} ${qrs.missing ? `<span class="tag tag-amber">缺 ${qrs.missing} 张</span>` : '<span class="tag tag-green">齐全</span>'}</span></div>
              <div><span class="k">占用空间</span><span class="v">${fmtSize(qrs.bytes)}</span></div>
              <div><span class="k">二维码参数</span><span class="v">纠错 ${esc(qrs.ec_level)} · 静区 ${qrs.margin} · 模块 ${qrs.scale}px</span></div>
              <div><span class="k">生成引擎</span><span class="v">${qrs.engine === 'builtin' ? '系统内置引擎' : (qrs.engine === 'python' ? 'Python 的 qrcode 库' : '自动')}
                ${qrs.python_available
    ? `<span class="tag tag-green">Python 可用${qrs.python_version ? ' ' + esc(qrs.python_version) : ''}</span>`
    : '<span class="tag tag-gray">本机无 Python，用内置引擎</span>'}</span></div>
              <div><span class="k">存放目录</span><span class="v mono" style="font-size:12px;word-break:break-all">${esc(qrs.dir)}</span></div>
            </div>
            <div class="flex mt8">
              <button class="btn" id="btn-qr-fill" ${isAdmin ? '' : 'disabled'}>补齐缺失的二维码</button>
              <button class="btn" id="btn-qr-all" ${isAdmin ? '' : 'disabled'}>全部重新生成</button>
            </div>
            <div class="help">「补齐」只处理还没有图片的档案，很快；「全部重新生成」会重写所有图片，档案很多时需要等一会儿。
              ${qrs.python_available ? '当前会调用 Python 的 qrcode 库生成。' : '当前本机没有 Python + qrcode，使用系统内置引擎（效果一致）。'}
              ${qrs.python_reason ? '<br>Python 探测详情：' + esc(qrs.python_reason) : ''}</div>
          </div>
        </div>`;
      $('#btn-backup').onclick = () => {
        toast('正在打包备份，数据量大时请耐心等待…', '', 5000);
        window.location.href = '/api/backup/download';
      };
      $('#btn-csv').onclick = () => { window.location.href = '/api/export/archives.csv'; };
      const runQr = async (force) => {
        toast(force ? '正在重新生成全部二维码…' : '正在补齐缺失的二维码…', '', 4000);
        try {
          const r = await api('/api/qrcodes/rebuild', { method: 'POST', body: { force } });
          toast(`完成：新生成 ${r.created} 张，已存在 ${r.skipped} 张${r.failed ? `，失败 ${r.failed} 张` : ''}`, 'ok', 6000);
          setView('manage', { tab: 'data' });
        } catch (e) { toast(e.message, 'err'); }
      };
      const bFill = $('#btn-qr-fill');
      if (bFill) bFill.onclick = () => runQr(false);
      const bAll = $('#btn-qr-all');
      if (bAll) bAll.onclick = () => runQr(true);
    } else {
      const info = await api('/api/system/info');
      content.innerHTML = head + `
        <div class="grid grid-2">
          <div class="card">
            <div class="card-head"><h3>运行环境</h3></div>
            <div class="dl" style="grid-template-columns:1fr">
              <div><span class="k">系统版本</span><span class="v">档案管理系统 v${esc(info.version)}</span></div>
              <div><span class="k">运行平台</span><span class="v">${esc(info.platform)} / Node ${esc(info.nodeVersion)}</span></div>
              <div><span class="k">已运行</span><span class="v">${Math.floor(info.uptimeSeconds / 3600)} 小时 ${Math.floor((info.uptimeSeconds % 3600) / 60)} 分</span></div>
              <div><span class="k">启动时间</span><span class="v">${fmtTime(info.startedAt)}</span></div>
              <div><span class="k">在线会话</span><span class="v">${info.sessions}</span></div>
              <div><span class="k">数据库大小</span><span class="v">${fmtSize(info.dbSize)}</span></div>
              <div><span class="k">附件占用</span><span class="v">${info.storageFiles} 个 / ${fmtSize(info.storageBytes)}</span></div>
            </div>
          </div>
          <div class="card">
            <div class="card-head"><h3>数据目录</h3></div>
            <div class="dl" style="grid-template-columns:1fr">
              <div><span class="k">程序目录</span><span class="v mono">${esc(info.appRoot)}</span></div>
              <div><span class="k">数据目录</span><span class="v mono">${esc(info.dataDir)}</span></div>
              <div><span class="k">附件目录</span><span class="v mono">${esc(info.filesRoot)}</span></div>
            </div>
            <div class="hint-box mt16">备份只需复制整个 <b>data</b> 目录，即可完整保留数据库与全部附件。</div>
            <div class="hint-box warn">不要把系统暴露在公网。若要多人使用，可把启动参数改为 <span class="mono">--host 0.0.0.0</span> 供局域网访问，并在防火墙中限制来源网段。</div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>帮助文档</h3></div>
          <div class="hint-box">说明文档直接在这里用浏览器打开，不用去安装目录里找文件 ——
            <span class="mono">.md</span> 这种扩展名会被机器上其它软件抢去当自己的文档类型
            （双击往往打不开，报「文件资源不可用」），
            所以交付包里只放 <span class="mono">.html</span> / <span class="mono">.txt</span>，不放 .md。</div>
          <div class="flex" style="flex-wrap:wrap">
            <button class="btn" id="doc-usage">使用说明（怎么用）</button>
            <button class="btn" id="doc-upgrade">升级说明（这一版改了什么）</button>
            <button class="btn" id="doc-roadmap">升级路线与市场对比</button>
          </div>
          <div class="hint-box mt16">想下载到本机看或打印：
            升级说明 <a href="/docs/升级说明.docx">Word</a> / <a href="/docs/升级说明.txt">记事本</a>
            · 使用说明 <a href="/docs/使用说明.docx">Word</a> / <a href="/docs/使用说明.txt">记事本</a>
            · 路线图 <a href="/docs/升级路线与市场对比.docx">Word</a> / <a href="/docs/升级路线与市场对比.txt">记事本</a>
            <br>三种形式内容一致（同一份源文件生成），看着方便用网页版，打印或转给别人用 Word 版。</div>
        </div>`;

      // 帮助文档：在新标签页里打开，走的是 /docs/ 路由（本机服务），
      // 与文件关联彻底解耦 —— .md 会被第三方软件抢走（双击报「文件资源不可用」），这里不存在这个问题。
      const docLinks = {
        'doc-usage': '/docs/使用说明.html',
        'doc-upgrade': '/docs/升级说明.html',
        'doc-roadmap': '/docs/升级路线与市场对比.html',
      };
      for (const [id, href] of Object.entries(docLinks)) {
        const btn = $('#' + id);
        if (btn) btn.onclick = () => window.open(href, '_blank', 'noopener');
      }
    }

    $$('#content [data-tab]').forEach((b) => { b.onclick = () => setView('manage', { tab: b.dataset.tab }); });
  }

  /**
   * 扫码深层链接。
   *   二维码里的网址形如 https://你的域名/#/archive/123，
   *   手机扫码 → 落地页显示档案号 → 点「打开档案详情」→ 打开本页 →
   *   若未登录先登录，登录成功后回到这里，直接弹出那份档案的详情。
   * 这样「扫码看到档案号 + 点链接进详情」就闭环了。
   */
  async function handleDeepLink() {
    // 注意：某些环境（如前端冒烟测试用的 DOM 仿真桩）没有 location，
    // 这里做存在性判断，避免整个启动流程被一个不存在的全局对象打断。
    const h = (typeof location !== 'undefined' && location.hash) ? String(location.hash) : '';
    const m = /^#\/archive\/(\d+)/.exec(h);
    if (m) {
      const id = Number(m[1]);
      try { await openArchiveDetail(id); }
      catch (e) { toast('打开档案失败：' + e.message, 'err'); }
      return true;
    }
    const b = /^#\/box\/([^/?#]+)/.exec(h);
    if (b) {
      setView('storage', { tab: 'boxes' });
      toast('已跳到档案盒列表（盒号 ' + decodeURIComponent(b[1]) + '）', 'ok', 5000);
      return true;
    }
    return false;
  }

  // ---------------- 登录 / 会话 ----------------
  /**
   * 手机端的侧栏抽屉（v4.15.0）。
   *
   * 此前 ≤720px 时侧栏被 `display:none` 直接拿掉 —— 手机上等于**没有导航**：
   * 登录后只能停在工作台，想去别的页面只能手改地址栏。
   * 现在侧栏默认移出屏幕，顶栏的 ☰ 滑出；选中菜单、点遮罩、按 Esc 都会收回。
   *
   * 状态只放在 body 的 `nav-open` 类上，不存 JS 变量 ——
   * 这样"打开没打开"只有一个事实来源，也不会和浏览器的返回手势打架。
   */
  function setNavDrawer(open) {
    if (typeof document === 'undefined' || !document.body) return;
    document.body.classList.toggle('nav-open', !!open);
    const btn = $('#btn-nav');
    // aria-expanded 是给读屏软件看的："这个按钮现在展开了没有"
    if (btn && typeof btn.setAttribute === 'function') btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function closeNavDrawer() { setNavDrawer(false); }

  /**
   * 撤掉启动画面（v4.16.0）。
   *
   * 「已登录」和「未登录」两条路径都必须撤 —— 启动画面唯一不可原谅的错就是撤不掉。
   * 撤的时候走一次淡出（CSS .done），淡完再加 .hidden 彻底移出：
   * 留着虽然已经 pointer-events:none，但仍在层叠里，弹窗 backdrop 之类会受它影响。
   *
   * 最短停留时间（v4.16.2）：本地服务第一次往返通常不到半秒，启动画面会"一闪而过"，
   * 单位名都来不及看清。所以在 boot() 里记下进入视野的时间，这里若还没满
   * SPLASH_MIN_MS，就等满那个点再撤（只延一次；与 8 秒兜底超时互不干扰 ——
   * 兜底触发时早已超过最短时长，会直接走真撤）。
   */
  const SPLASH_MIN_MS = 2000;
  let bootShownAt = 0;
  let bootSplashGone = false;
  function hideBootSplash() {
    if (bootSplashGone) return;
    const remain = SPLASH_MIN_MS - (Date.now() - bootShownAt);
    if (remain > 0) { setTimeout(hideBootSplash, remain); return; }
    bootSplashGone = true;
    const el = $('#boot-splash');
    if (!el) return;
    el.classList.add('done');
    setTimeout(() => el.classList.add('hidden'), 450);
  }

  function showApp() {
    $('#login-view').classList.add('hidden');
    $('#app-view').classList.remove('hidden');
    const u = state.user;
    $('#user-name').textContent = u.display_name || u.username;
    $('#user-role').textContent = (state.roleNames[u.role] || u.role) + (u.department ? ' · ' + u.department : '');
    $('#user-avatar').textContent = (u.display_name || u.username).slice(0, 1);
    // 按服务端下发的可见菜单显示（v4.17.0）。
    // 此前这里是一张写死的"普通用户看不到这些"清单，后果是**安全审计员能看到全部菜单**
    // ——包括档案著录、导入导出——点进去才发现没权限。现在判断依据只有一个：
    // 服务端按 policy.can() 算出来的 views。界面显示什么，接口就允许什么。
    const allowedView = new Set(Array.isArray(state.views) ? state.views : []);
    $$('#nav .nav-item').forEach((n) => {
      n.classList.toggle('hidden', !allowedView.has(n.dataset.view));
    });
    // 整组菜单都被权限滤掉时，把分组标题一起隐掉（v4.15.0）：
    // 留下"质量与合规"这种只有标题没有条目的空组，会让人以为菜单没加载出来
    const secsWithItems = new Set();
    $$('#nav .nav-item').forEach((n) => {
      if (!n.classList.contains('hidden') && n.dataset.sec) secsWithItems.add(n.dataset.sec);
    });
    $$('#nav .nav-sec').forEach((s) => s.classList.toggle('hidden', !secsWithItems.has(s.dataset.sec)));
    // 手机上"选了菜单"就该收回抽屉，否则新页面被抽屉挡着
    closeNavDrawer();
    // 已经登录：启动画面的使命结束（v4.16.0）
    hideBootSplash();
    // 在微信/QQ 等内置浏览器里打开时，顶部常驻一条说明（v4.20.10）：
    // 这类容器不能下载文件，与其让人反复点下载反复失败，不如一次讲清楚。
    webViewNotice();
    setView('workbench');
    loadLicenseHint();
    loadStorageHint();
    // 登录后立刻拉一次待办红点：进系统第一眼就该看到"有没有该处理的事"
    refreshTodoBadge();
    // 首次使用向导已删除（v4.20.0）：登录页已经定死两种身份，向导那套建号/定角色成了废动作。
    // 唯一保留下来的是工作台上那条"全宗号还是出厂占位值"的提醒（见 renderDashboard）。
    // 扫码链接可能带 #/archive/<id>：登录后直接打开那份档案的详情
    setTimeout(() => { try { handleDeepLink(); } catch (_) { /* 不影响正常使用 */ } }, 60);
    if (u.must_change) {
      setTimeout(() => {
        toast('当前使用的是初始密码，请立即修改', 'warn', 5000);
        changePasswordDialog();
      }, 600);
    }
  }

  /**
   * 授权状态（v4.33.0）：登录后取一次。
   * 三件事：① 授权单位名替换左上角的默认单位名（白牌化，拷走也得改）：
   *        ② 版本行后面挂授权到期日；
   *        ③ 只读/到期/机器码不符时，在页面顶部挂一条常驻提示（不能只弹一下红条就没了）。
   */
  let licenseSubTail = '';
  async function loadLicenseHint() {
    let v;
    try { v = await api('/api/license'); } catch (_) { return; }
    if (!v) return;
    if (v.unit) {
      const org = $('#brand-org');
      if (org) org.textContent = v.unit;
    }
    const sub = $('#brand-sub');
    if (sub) {
      // 版本行由 loadStorageHint 写 v4.x.x，这里只追加授权尾巴，别把版本号冲掉
      licenseSubTail = v.state === 'ok'
        ? ` · 授权至 ${v.expires_at}`
        : v.state === 'none' ? ' · 未授权' : ' · 授权只读';
      const base = String(sub.textContent || '').replace(/ · (授权至 .*|未授权|授权只读)$/, '');
      sub.textContent = base + licenseSubTail;
    }
    const bar = $('#license-bar');
    if (bar) bar.remove();
    if (v.state !== 'ok') {
      const kind = v.readOnly ? 'warn' : '';
      const box = el('div', { id: 'license-bar', class: 'hint-box ' + kind,
        style: 'margin:8px 16px 0;font-size:13px' },
      `授权提示：${esc(v.message)}${v.machine ? `　本机机器码 <b class="mono">${esc(v.machine.code)}</b>` : ''}`);
      const host = $('#app-view');
      if (host && typeof host.insertBefore === 'function') host.insertBefore(box, host.firstChild);
      else if (host && typeof host.appendChild === 'function') host.appendChild(box);
    }
  }

  async function loadStorageHint() {
    try {
      const info = await api('/api/system/info').catch(() => null);
      if (!info) return;
      $('#brand-sub').textContent = `v${info.version}${licenseSubTail}`;
      const cap = 10 * 1024 * 1024 * 1024;
      const pct = Math.min(100, (info.storageBytes / cap) * 100);
      $('#storage-bar').innerHTML = `<i style="width:${pct.toFixed(1)}%"></i>`;
      $('#storage-text').textContent = `附件 ${info.storageFiles} 个 · 占用 ${fmtSize(info.storageBytes)}`;
    } catch (_) { /* 忽略 */ }
  }

  function logoutLocal() {
    state.user = null;
    $('#app-view').classList.add('hidden');
    $('#login-view').classList.remove('hidden');
    $('#login-password').value = '';
    // 退出后必须回到口令登录卡片（v4.27.0）：如果上一次有人在找回流程里，
    // 下一个使用者坐下时看到的是"手机号找回"，会以为系统坏了或以为在让他改密码。
    clearInterval(smsState.timer);
    smsState.ticket = '';
    smsToggleCard(false);
  }

  /**
   * 口令规则提示（v4.20.3）——**从服务端下发策略里取，不在前端写死**。
   *
   * 起因：用户管理里点"重置密码"填完却进不去，报的是"重置密码不成功"。
   * 查下来服务端没毛病（合规口令 200、新口令能登录、旧口令被拒），
   * 真正的问题是**对话框写的是"至少 6 位"**，而真实策略是 8 位起，
   * 外加"不能含用户名""不能在常见弱口令清单里""纯数字要 12 位、纯字母要 10 位"。
   * 使用者照着提示填，必然被拒 —— 提示跟规则不一致，比不提示还坏。
   */
  function pwdHint() {
    const p = state.passwordPolicy || {};
    const min = Number(p.min_length || p.minLength || 8);
    const rules = Array.isArray(p.rules) && p.rules.length
      ? p.rules
      : [`长度不少于 ${min} 位`, '不能与用户名相同或包含用户名', '不在常见弱口令清单中'];
    return { placeholder: `至少 ${min} 位`, help: '规则：' + rules.join('；') };
  }

  function changePasswordDialog() {
    const h = pwdHint();
    promptDialog('修改密码', [
      { name: 'oldPassword', label: '原密码', type: 'password', required: true },
      { name: 'newPassword', label: '新密码', type: 'password', required: true, placeholder: h.placeholder, help: h.help, span2: true },
      { name: 'confirm', label: '确认新密码', type: 'password', required: true, span2: true },
    ], async (d) => {
      if (d.newPassword !== d.confirm) throw new Error('两次输入的新密码不一致');
      await api('/api/me/password', { method: 'POST', body: d });
      toast('密码已修改', 'ok');
      state.user.must_change = 0;
    }, { wide: true });
  }

  // ---------------- 手机号找回口令（v4.27.0）----------------
  //
  // 三步：手机号 → 短信验证码 → 设置新口令。
  //
  // 票据（ticket）**只放在内存里**，不进 localStorage / sessionStorage：
  // 它等价于"一次改口令的权利"，留在浏览器存储里就多了一个可以被顺走、
  // 也可能在公用电脑上留到下一个人的东西。刷新页面即失效 —— 重走一遍只要一分钟，
  // 而"在档案室那台公用机器上留下一个改密凭证"是不可接受的。
  const smsState = { ticket: '', phone: '', timer: 0, channel: 'sms' };

  /**
   * 切换找回通道（v4.31.0）：手机号 ⇄ 邮箱。
   *
   * 为什么不给两条通道各做一张卡：三步流程完全一样（发码 → 校验 → 改口令），
   * 复制一份界面就得复制一份状态机与错误提示，改一处忘一处是最常见的漂移源。
   * 这里只换提示文案、输入类型与接口路径。
   */
  const REC_CHANNEL_UI = {
    sms: {
      label: '已登记的手机号',
      help: '手机号需由档案管理员在「系统管理 → 找回方式」中登记。',
      placeholder: '请输入 11 位手机号',
      type: 'tel',
      mode: 'numeric',
      maxlength: '11',
      codeLabel: '短信验证码',
      tip: '短信验证码',
    },
    email: {
      label: '已登记的邮箱',
      help: '邮箱需由档案管理员在「系统管理 → 找回方式」中登记；收不到时请顺手看一眼垃圾邮件。',
      placeholder: '请输入邮箱地址，例如 name@example.com',
      type: 'email',
      mode: 'email',
      maxlength: '120',
      codeLabel: '邮件验证码',
      tip: '邮件验证码',
    },
  };

  function recSetChannel(channel) {
    const ch = channel === 'email' ? 'email' : 'sms';
    smsState.channel = ch;
    const ui = REC_CHANNEL_UI[ch];
    for (const b of document.querySelectorAll('.rec-tab')) {
      b.classList.toggle('active', b.dataset.channel === ch);
    }
    const label = $('#rec-target-label');
    if (label) label.textContent = ui.label;
    const help = $('#rec-target-help');
    if (help) help.textContent = ui.help;
    const codeLabel = $('#rec-code-label');
    if (codeLabel) codeLabel.textContent = ui.codeLabel;
    const input = $('#sms-phone');
    if (input) {
      input.type = ui.type;
      input.setAttribute('inputmode', ui.mode);
      input.setAttribute('maxlength', ui.maxlength);
      input.placeholder = ui.placeholder;
      input.setAttribute('autocomplete', ch === 'email' ? 'email' : 'tel');
      input.value = '';
    }
    // 换通道等于换一次找回：上一条通道的验证码、票据、倒计时全部作废
    smsState.ticket = '';
    smsState.phone = '';
    clearInterval(smsState.timer);
    const code = $('#sms-code');
    if (code) code.value = '';
    for (const id of ['#sms-error1', '#sms-error2', '#sms-error3']) {
      const el = $(id);
      if (el) el.textContent = '';
    }
    smsShowStep(1);
    setTimeout(() => { try { $('#sms-phone').focus(); } catch (_) { /* 移动端可能不支持 */ } }, 30);
  }

  /** 在三个步骤之间切换（只显示当前步） */
  function smsShowStep(step) {
    $('#sms-step1').classList.toggle('hidden', step !== 1);
    $('#sms-step2').classList.toggle('hidden', step !== 2);
    $('#sms-step3').classList.toggle('hidden', step !== 3);
  }

  /** 登录卡片 ⇄ 找回卡片 */
  function smsToggleCard(toSms) {
    $('#login-form').classList.toggle('hidden', toSms);
    $('#login-sms').classList.toggle('hidden', !toSms);
    if (toSms) {
      // 每次打开都回到第一步、默认走手机号：上次可能停在"用邮箱"上，
      // 留着那个状态会让人对着"已登记的邮箱"发愣（他分明想用手机号）
      recSetChannel('sms');
      $('#sms-error1').textContent = '';
      $('#sms-error2').textContent = '';
      $('#sms-error3').textContent = '';
      setTimeout(() => { try { $('#sms-phone').focus(); } catch (_) { /* 移动端可能不支持 */ } }, 30);
    } else {
      $('#login-error').textContent = '';
      $('#login-password').value = '';
      $('#sms-pwd').value = '';
      $('#sms-pwd2').value = '';
    }
  }

  /** 重发倒计时：按钮上直接显示还剩几秒，比只把它变灰更清楚 */
  function smsCooldown(seconds) {
    const btn = $('#sms-resend');
    clearInterval(smsState.timer);
    let left = Math.max(0, Math.ceil(Number(seconds) || 0));
    const render = () => {
      if (left <= 0) {
        clearInterval(smsState.timer);
        btn.disabled = false;
        btn.textContent = '重新发送';
        return;
      }
      btn.disabled = true;
      btn.textContent = `重新发送（${left}s）`;
      left--;
    };
    render();
    if (left > 0) smsState.timer = setInterval(render, 1000);
  }

  async function smsSendCode(btn) {
    // 错误显示在哪一步上：「获取验证码」仍在第一步，「重新发送」已在第二步
    const err = $('#sms-step2').classList.contains('hidden') ? $('#sms-error1') : $('#sms-error2');
    err.textContent = '';
    const ch = smsState.channel === 'email' ? 'email' : 'sms';
    const raw = String($('#sms-phone').value || '').trim();
    let target = '';
    if (ch === 'sms') {
      target = raw.replace(/[\s-]/g, '');
      if (!/^1[3-9]\d{9}$/.test(target)) {
        err.textContent = '请输入正确的 11 位手机号';
        return;
      }
    } else {
      // 前端只做"看起来像邮箱"的粗筛，真正的规范化与判重交给服务端
      target = raw.replace(/\s/g, '').toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(target)) {
        err.textContent = '请输入正确的邮箱地址，例如 name@example.com';
        return;
      }
    }
    btn.disabled = true;
    const oldText = btn.textContent;
    btn.textContent = '发送中…';
    try {
      const d = await api(`/api/login/${ch}/send`, {
        method: 'POST', body: ch === 'sms' ? { phone: target } : { email: target },
      });
      smsState.phone = target;
      const tip = $('#sms-sent-tip');
      if (d.sent === false) {
        // 冷却中 / 当日次数用尽：如实说，并把倒计时接上，别让人一直点
        tip.innerHTML = esc(d.hint || '请稍后再试');
        if (d.retryAfterSeconds) smsCooldown(d.retryAfterSeconds);
      } else {
        tip.innerHTML = `<b>验证码已发送</b>，${Math.round((d.ttlSeconds || 300) / 60)} 分钟内有效。`
          + (d.hint ? `<br>${esc(d.hint)}` : '');
        $('#sms-code').value = '';
        smsShowStep(2);
        setTimeout(() => { try { $('#sms-code').focus(); } catch (_) { /* ignore */ } }, 30);
        smsCooldown(d.resendSeconds || 60);
      }
    } catch (ex) {
      // 通道未配置、被限流、厂商拒绝：都是**必须让人看懂**的失败，
      // 所以这里把服务端的原话显示出来，而不是笼统的"发送失败"
      err.textContent = ex.message;
    } finally {
      // 「重新发送」按钮的可用状态与文案由 smsCooldown 独占管理，
      // 在这里还原就会把倒计时覆盖掉（按钮立刻又能点）
      if (btn.id === 'sms-send') {
        btn.disabled = false;
        btn.textContent = oldText;
      }
    }
  }

  async function smsVerifyCode(btn) {
    const err = $('#sms-error2');
    err.textContent = '';
    const code = String($('#sms-code').value || '').replace(/\s/g, '');
    if (!/^\d{6}$/.test(code)) {
      err.textContent = '请输入 6 位数字验证码';
      return;
    }
    btn.disabled = true;
    const oldText = btn.textContent;
    btn.textContent = '校验中…';
    try {
      const d = await api(`/api/login/${smsState.channel === 'email' ? 'email' : 'sms'}/verify`, {
        method: 'POST',
        body: smsState.channel === 'email'
          ? { email: smsState.phone, code }
          : { phone: smsState.phone, code },
      });
      smsState.ticket = d.ticket || '';
      // 口令规则随应答下发（v4.27.0）：登录前拿不到 /api/me，不能靠前端猜"至少几位"
      if (d.passwordPolicy) state.passwordPolicy = d.passwordPolicy;
      $('#sms-pwd-rule').innerHTML = '设置新口令的要求：' + esc(pwdHint().help.replace(/^规则：/, ''));
      $('#sms-pwd').value = '';
      $('#sms-pwd2').value = '';
      smsShowStep(3);
      setTimeout(() => { try { $('#sms-pwd').focus(); } catch (_) { /* ignore */ } }, 30);
    } catch (ex) {
      err.textContent = ex.message;
      if (/次数过多|已作废/.test(ex.message || '')) {
        // 码已经废了，留在第二步只会让人反复填同一个错码
        setTimeout(() => { $('#sms-code').value = ''; }, 0);
      }
    } finally {
      btn.disabled = false;
      btn.textContent = oldText;
    }
  }

  async function smsSetPassword(btn) {
    const err = $('#sms-error3');
    err.textContent = '';
    const pwd = String($('#sms-pwd').value || '');
    const pwd2 = String($('#sms-pwd2').value || '');
    if (!pwd) { err.textContent = '请设置新口令'; return; }
    if (pwd !== pwd2) { err.textContent = '两次输入的口令不一致'; return; }
    if (!smsState.ticket) { err.textContent = '重置凭证已失效，请重新获取验证码'; smsShowStep(1); return; }
    btn.disabled = true;
    const oldText = btn.textContent;
    btn.textContent = '提交中…';
    try {
      const d = await api(`/api/login/${smsState.channel === 'email' ? 'email' : 'sms'}/reset`, {
        method: 'POST', body: { ticket: smsState.ticket, newPassword: pwd },
      });
      // 服务端已经建好会话并下发了 Cookie —— 这里与口令登录走同一条收尾路径
      smsState.ticket = '';
      $('#sms-pwd').value = '';
      $('#sms-pwd2').value = '';
      state.user = d.user;
      state.roleNames = d.roleNames || state.roleNames;
      state.identities = d.identities || state.identities;
      state.passwordPolicy = d.passwordPolicy || state.passwordPolicy;
      state.actions = d.actions || {};
      state.views = d.views || [];
      await loadMeta();
      smsToggleCard(false);
      showApp();
      toast('口令已更新，已为你登录', 'ok', 4000);
    } catch (ex) {
      err.textContent = ex.message;
    } finally {
      btn.disabled = false;
      btn.textContent = oldText;
    }
  }

  function setupSmsLogin() {
    const forgot = $('#btn-forgot');
    if (forgot) forgot.onclick = () => smsToggleCard(true);
    // 两条通道的切换（v4.31.0）
    for (const tab of document.querySelectorAll('.rec-tab')) {
      tab.onclick = () => recSetChannel(tab.dataset.channel);
    }
    const back = $('#sms-back');
    if (back) back.onclick = () => { clearInterval(smsState.timer); smsToggleCard(false); };
    const send = $('#sms-send');
    if (send) send.onclick = () => smsSendCode(send);
    const resend = $('#sms-resend');
    if (resend) resend.onclick = () => smsSendCode(resend);
    const verify = $('#sms-verify');
    if (verify) verify.onclick = () => smsVerifyCode(verify);
    const submit = $('#sms-submit');
    if (submit) submit.onclick = () => smsSetPassword(submit);
    // 回车即下一步：手机上表单被拆成三个 div，回车不会自动提交，必须手动接住
    const phone = $('#sms-phone');
    if (phone) phone.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); smsSendCode(send); } });
    const code = $('#sms-code');
    if (code) code.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); smsVerifyCode(verify); } });
    const pwd2 = $('#sms-pwd2');
    if (pwd2) pwd2.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); smsSetPassword(submit); } });
  }

  // ---------------- 初始化 ----------------
  async function boot() {
    // 启动画面从这一刻进入视野（用于"至少停留 SPLASH_MIN_MS"的最短时长判断，v4.16.2）
    bootShownAt = Date.now();
    // 启动画面的兜底撤除（v4.16.0）：正常路径由 showApp / 登录页撤，
    // 但万一第一次请求卡住（服务刚起来、网线松了、接口超时），
    // 也**绝不能**把人一直扣在启动画面上 —— 宁可让人看到登录页并自己去试，
    // 也不能给一个永远转圈的界面。8 秒是"明显不对劲"的阈值。
    setTimeout(hideBootSplash, 8000);
    // 扫码枪全局监听：装一次即可，之后在任何页面扣扳机都能被接住
    setupScanner();
    // 登录页显示版本号（v4.26.3，使用者要求）。
    // 数据取自 `/api/ping` —— 它不登录也能访问，而且启动横幅、批处理脚本用的就是它，
    // 所以**界面显示的和窗口/脚本里看到的一定是同一个版本**，不会各说各话。
    fetch('/api/ping', { credentials: 'same-origin' })
      .then((r) => r.text())
      .then((t) => {
        const m = /版本：(\S+)/.exec(t || '');
        const node = $('#login-version');
        if (m && node) node.textContent = '版本 v' + m[1];
      })
      .catch(() => { /* 取不到就不显示，绝不因为它影响登录 */ });
    // 内置浏览器里打开时，**登录页**就先说清楚（v4.25.0）。
    // 这些浏览器不能下载任何格式的文件；等使用者登进去、点了下载才失败，就白折腾一轮。
    // 提前讲清楚，他可以直接点「⋯ → 在浏览器打开」，省掉"登一次、试一次、失败一次"。
    try {
      const wvBoot = inAppBrowser();
      const hint = $('#login-webview-hint');
      if (wvBoot && hint) {
        hint.innerHTML = `<b>注意：你现在是在「${esc(wvBoot)}」内置浏览器里打开的。</b>`
          + `查阅档案没问题，但它<b>不能下载任何格式的文件</b>（这是它自身的限制，不是系统的问题）。<br>`
          + `需要下载时，请点右上角 <b>⋯</b> → <b>在浏览器打开</b>，在手机浏览器里访问 `
          + `<span class="mono">${esc(location.origin)}</span>，登录一次并存成书签即可。`;
        hint.classList.remove('hidden');
      }
    } catch (_) { /* 提示不出来不影响登录 */ }
    $('#login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btnSub = $('#login-submit');
      const err = $('#login-error');
      err.textContent = '';
      btnSub.disabled = true;
      try {
        const d = await api('/api/login', {
          method: 'POST',
          body: {
            // 登录页只有「身份 + 口令」两个框（v4.19.0）。
            // 身份在"进门"这一步交给服务端核对；服务端在**该身份的账号里按口令比对**，
            // 命中哪个账号就是哪个 —— 界面简化了，账号仍然一人一个，日志仍能查到人。
            identity: ($('#login-identity') || {}).value || '',
            password: $('#login-password').value,
          },
        });
        state.user = d.user;
        state.roleNames = d.roleNames || state.roleNames;
        state.identities = d.identities || state.identities;
        state.passwordPolicy = d.passwordPolicy || state.passwordPolicy;
        state.actions = d.actions || {};
        state.views = d.views || [];
        await loadMeta();
        showApp();
      } catch (ex) {
        err.textContent = ex.message;
      } finally {
        btnSub.disabled = false;
      }
    });

    // 手机号找回（v4.27.0）：绑定「忘记密码」与三步流程上的所有按钮
    setupSmsLogin();

    $('#btn-logout').onclick = async () => {
      try { await api('/api/logout', { method: 'POST' }); } catch (_) { /* ignore */ }
      logoutLocal();
    };
    $('#btn-pwd').onclick = () => changePasswordDialog();
    // 手机端抽屉：☰ 开合、点遮罩收回、按 Esc 收回（v4.15.0）
    const navBtn = $('#btn-nav');
    if (navBtn) {
      navBtn.onclick = () => setNavDrawer(!document.body.classList.contains('nav-open'));
    }
    const navScrim = $('#nav-scrim');
    if (navScrim) navScrim.onclick = closeNavDrawer;
    document.addEventListener('keydown', (ev) => {
      // 只处理 Esc，且不拦截在输入框里的 Esc（那里 Esc 有别的含义）
      if (ev.key !== 'Escape') return;
      if (typeof document.body.classList.contains === 'function' && document.body.classList.contains('nav-open')) {
        closeNavDrawer();
      }
    });
    $$('#nav .nav-item').forEach((n) => {
      n.onclick = () => { closeNavDrawer(); setView(n.dataset.view); };
      // 菜单是 <a> 而不是 <button>，默认不进 Tab 顺序；补了 tabindex 之后
      // 回车/空格也必须能激活 —— 否则键盘用户"焦点到了却点不动"
      n.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); n.onclick(); }
      });
    });
    // 已登录状态下点链接（或手动改 hash）也能直接打开
    if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
      window.addEventListener('hashchange', () => { if (state.user) handleDeepLink(); });
    }

    // **每次打开都必须先登录**（v4.20.2）。
    //
    // 原来这里是"自动登录"：只要浏览器还留着会话 cookie，打开页面就直接进工作台，
    // 连登录页都不出现。在公用电脑（档案室那台机器）上这等于**谁坐下去都能接着用**，
    // 使用者看到的现象就是"它自己进去了，没让我登录"。
    //
    // 现在不管有没有会话，一律先显示登录页，必须重新选身份 + 输口令才能进。
    // 会话仍然保留（服务端照旧认 cookie），只是**不再替你自动进门**。
    // 这样也顺手解决了另一个隐患：换人轮班时，上一个人的身份不会一直挂着。
    $('#login-view').classList.remove('hidden');
    hideBootSplash();   // 未登录也要撤掉启动画面，否则登录卡片被它盖着点不到（v4.16.0）
    setTimeout(() => { const p = $('#login-password'); if (p) p.focus(); }, 100);
  }

  async function loadMeta() {
    const [types, cats, setRes] = await Promise.all([
      api('/api/types'),
      api('/api/categories'),
      api('/api/settings').catch(() => ({ settings: {} })),
    ]);
    state.types = types.list;
    state.meta = types;
    state.categories = cats.list;
    state.catFlat = cats.flat;
    state.settings = setRes.settings || {};
  }

  let booted = false;
  const bootOnce = () => { if (booted) return; booted = true; boot(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootOnce);
  else bootOnce();
})();
