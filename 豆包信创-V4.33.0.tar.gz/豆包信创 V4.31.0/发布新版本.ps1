﻿<#
  档案管理系统 - 发布新版本
  ------------------------------------------------------------
  做三件事，保证「桌面上永远有一个和最新版一致的快捷方式」：
    1) 生成给同事的 zip（排除真实数据 data\ 与 .git）
    2) 重建桌面与 D:\我做的软件 下的快捷方式，指向当前目录
    3) 提交 git 并打版本标签（加 -Push 则推送到 GitHub）

  用法：在 PowerShell 里执行
        .\发布新版本.ps1              只打包 + 快捷方式 + 本地提交
        .\发布新版本.ps1 -Push        额外推送到 GitHub（需已配置 origin）
        .\发布新版本.ps1 -SkipZip     不重新打包
#>
[CmdletBinding()]
param(
  [switch]$Push,
  [switch]$SkipZip
)

$ErrorActionPreference = 'Stop'
$root   = $PSScriptRoot
$parent = Split-Path $root -Parent

function Write-Step($msg){ Write-Host "`n=== $msg ===" -ForegroundColor Cyan }

# ---------- 0. 读版本号并校验目录名 ----------
Write-Step '检查版本'
$serverJs = Join-Path $root 'server\server.js'
if(-not (Test-Path $serverJs)){ throw "找不到 server\server.js，请在程序目录里运行本脚本。" }
$m = Select-String -Path $serverJs -Pattern "const\s+VERSION\s*=\s*'([0-9]+\.[0-9]+\.[0-9]+)'" | Select-Object -First 1
if(-not $m){ throw "无法从 server.js 里读到 VERSION。" }
$version = $m.Matches[0].Groups[1].Value
$版本文件 = Join-Path $root '版本.txt'
# 版本.txt 是人工维护的更新日志，脚本只做一致性检查，绝不覆盖。
if (Test-Path $版本文件) {
  $首行 = (Get-Content $版本文件 -TotalCount 1) -replace '^\uFEFF', ''
  if ($首行.Trim() -ne "V$version") { Write-Warning "版本.txt 首行是「$($首行.Trim())」，与代码版本 V$version 不一致。" }
} else {
  "V$version" | Out-File $版本文件 -Encoding UTF8 -NoNewline
}
Write-Host "代码版本: v$version"

$期望目录名 = "档案管理系统 V$version"
if((Split-Path $root -Leaf) -ne $期望目录名){
  Write-Warning "目录名是「$(Split-Path $root -Leaf)」，与版本对不上（应为「$期望目录名」）。"
  Write-Warning "建议先关掉正在运行的服务窗口，把目录改名后再发布。"
}

# ---------- 1. 打 zip ----------
# 发布包统一放到 D:\给同事的zip（该目录不存在时退回程序目录旁边）
$distDir = 'D:\给同事的zip'
if(-not (Test-Path $distDir)){ $distDir = $parent }
$zipPath = Join-Path $distDir "$期望目录名.zip"
if(-not $SkipZip){
  Write-Step '生成发布包'
  $stage = Join-Path $env:TEMP ("ams_pack_" + [Guid]::NewGuid().ToString('N'))
  $stageRoot = Join-Path $stage $期望目录名
  New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null
  try{
    foreach($d in @('public','server','runtime')){
      $src = Join-Path $root $d
      if(Test-Path $src){ robocopy $src (Join-Path $stageRoot $d) /E /NFL /NDL /NJH /NJS /NP | Out-Null }
    }
    Get-ChildItem $root -File | Where-Object { $_.Name -ne '发布新版本.ps1' } | Copy-Item -Destination $stageRoot -Force

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if(Test-Path $zipPath){ Remove-Item $zipPath -Force }
    [IO.Compression.ZipFile]::CreateFromDirectory($stageRoot, $zipPath, [IO.Compression.CompressionLevel]::Optimal, $true)
    "已生成: $zipPath  （{0} MB）" -f [math]::Round((Get-Item $zipPath).Length/1MB,2) | Write-Host
  } finally {
    Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  }
} else { Write-Step '跳过打包' }

# ---------- 2. 快捷方式 ----------
Write-Step '重建快捷方式'
$ico = Get-ChildItem $root -Filter '*.ico' | Select-Object -First 1
$sh  = New-Object -ComObject WScript.Shell
$目标 = Join-Path $root '双击启动-档案管理系统.bat'
$links = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) '档案管理系统.lnk'),
  (Join-Path $parent '档案管理系统.lnk')
)
foreach($lnk in $links){
  $s = $sh.CreateShortcut($lnk)
  $s.TargetPath       = $目标
  $s.WorkingDirectory = $root
  if($ico){ $s.IconLocation = "$($ico.FullName),0" }
  $s.Description = "档案管理系统 v$version"
  $s.Save()
  Write-Host "已更新: $lnk"
}

# ---------- 3. git 提交与标签 ----------
Write-Step '整理版本库'
Push-Location $root
try{
  if(-not (Test-Path (Join-Path $root '.git'))){ git init -q -b main }
  git add -A
  $dirty = (git status --porcelain | Measure-Object -Line).Lines
  if($dirty -gt 0){
    git -c core.quotepath=false commit -q -m "v$version"
    Write-Host "已提交 $dirty 项改动"
  } else { Write-Host '没有改动，无需提交' }

  $tag = "v$version"
  if(-not ((git tag) -contains $tag)){ git tag -a $tag -m "v$version 发布"; Write-Host "已打标签 $tag" }

  $hasRemote = (git remote) -contains 'origin'
  if($Push){
    if($hasRemote){ git push origin main --tags; Write-Host '已推送到 GitHub' }
    else { Write-Warning '还没有配置远端，先执行：git remote add origin <仓库地址>' }
  } elseif($hasRemote){
    Write-Host '本地已提交；要同步到 GitHub 请加 -Push'
  }
} finally { Pop-Location }

Write-Step '完成'
Write-Host "版本 v$version 已就绪。桌面快捷方式与 D:\我做的软件\档案管理系统.lnk 均指向本目录。" -ForegroundColor Green
