#!/bin/sh
# ============================================================
#  档案管理系统 —— 数据备份脚本（Linux / 麒麟 / 统信 UOS / macOS）
#
#  把 data 目录（数据库 + 全部电子附件 + 每份档案的二维码图片）
#  完整复制到 backup/backup_日期_时间/ 下。
#
#  用法：sh backup.sh
# ============================================================

cd "$(dirname "$0")" || exit 1

if [ ! -d "data" ]; then
  echo ""
  echo "  [错误] 没有找到 data 目录，系统可能还从未启动过。"
  echo ""
  exit 1
fi

STAMP=$(date +%Y%m%d_%H%M%S)
DEST="backup/backup_$STAMP"

mkdir -p "$DEST" || exit 1

echo ""
echo "  正在备份到：$DEST"
echo ""

# -a 保留权限与时间戳；数据库文件、附件、二维码图片一起备份
cp -a data/archive.db "$DEST/" 2>/dev/null
[ -f "data/archive.db-wal" ] && cp -a data/archive.db-wal "$DEST/" 2>/dev/null
[ -f "data/archive.db-shm" ] && cp -a data/archive.db-shm "$DEST/" 2>/dev/null

if [ -d "data/files" ]; then
  mkdir -p "$DEST/files"
  cp -a data/files/. "$DEST/files/" 2>/dev/null
  echo "  已备份电子附件"
fi

if [ -d "data/qrcodes" ]; then
  mkdir -p "$DEST/qrcodes"
  cp -a data/qrcodes/. "$DEST/qrcodes/" 2>/dev/null
  echo "  已备份档案二维码图片"
fi

SIZE=$(du -sh "$DEST" 2>/dev/null | awk '{print $1}')
echo ""
echo "  备份完成：$DEST     ${SIZE:-}"
echo ""
echo "  恢复方法："
echo "      1) 先停止系统（在启动窗口按 Ctrl+C）"
echo "      2) 把备份里的 archive.db 覆盖回 data/archive.db"
echo "      3) 把备份里的 files/ 覆盖回 data/files/"
echo "      4) 重新执行 sh start.sh"
echo ""
