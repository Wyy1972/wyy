﻿/**
 * 档案管理系统 服务端入口
 * 零第三方依赖：仅使用 Node 内置模块（node:http / node:sqlite / node:crypto）
 *
 * 启动：node server/server.js [--port 8787] [--host 127.0.0.1] [--open]
 */
'use strict';

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');

// 版本守卫必须放在 require('./db') 之前：
// db.js 会加载 node:sqlite，低版本 Node 上会直接抛 "Cannot find module"，
// 那句报错对用户没有意义，这里先换成能照着做的提示。
const { requireNodeVersion } = require('./lib/node-version');
requireNodeVersion();

const { openDatabase, verifyPassword } = require('./db');
const { createSessions } = require('./lib/auth');
const { createApi } = require('./api');
const { mimeOf, fail, contentDisposition } = require('./lib/http');
const { lanIPv4List } = require('./lib/net');
const banner = require('./lib/banner');

const APP_ROOT = path.resolve(__dirname, '..');
/**
 * 应用版本号。
 *
 * 与数据库结构版本（db.js 的 SCHEMA_VERSION）**分开表述**：
 *   应用版本 4.11.0  ←→  结构版本 schema 18
 *   （4.1.0 定时任务与待办中心；4.1.1 缺陷修复；4.2.0 首次使用向导；4.3.0 扫码枪工作台；
 *     4.4.0 归档章/备考表/下载审批/元数据界面；4.5.0 移交进馆标准数据包；
 *     4.6.0 常用检索（结构 13 → 14，新增 saved_searches 表）；
 *     4.7.0 高级检索表达式（无结构变更，仍为 14）；
 *     4.8.0 档号治理（结构 14 → 15，新增 number_sequences 号段表）；
 *     4.9.0 补充归档（结构 15 → 16，新增 archive_links 与 file_replacements）；
 *     4.10.0 鉴定扩展（结构 16 → 17，新增 appraisal_batches，archives/appraisals 补鉴定字段）；
 *     4.11.0 检索智能化（结构 17 → 18，archives 补拼音检索键 py_full/py_initials，
 *            file_text 补正文来源 via/engine，新增 OCR 适配层与检索结果分面）；
 *     4.12.0 全文搜索补全（**结构不变，仍为 18**：新增 OLE2/CFB 读取器与旧版 .doc/.xls 提取、
 *            按字节嗅探真实格式、关键词统一检索附件正文、Windows 自带 OCR 零安装接入）；
 *     4.13.0 好用性改进（结构不变仍为 18：连续著录、OCR 探测移出请求路径、空状态指路）；
 *     4.14.0 导入与列表细节修正（**结构不变，仍为 18**：导入模板拆成"精简 9 列/全字段"两套、
 *            修掉示例行整排错位的真 bug、模板说明不再算错误行、档案列表补回完整档号）；
 *     4.15.0 界面版面重做（**结构不变，仍为 18**：设计令牌化、菜单分组、手机端抽屉导航、
 *            修掉 --c-bg-2 未定义与 .stat 重复定义这两处"说不出哪里不对"的样式错）；
 *     4.16.0 启动体验与底色（**结构不变，仍为 18**：控制台启动横幅按显示宽度重排并上色、
 *            新增浏览器启动画面、登录页改双栏、全局底色加点阵与渐变）；
 *     4.16.1 说明文档改用网页提供（**结构不变，仍为 18**：新增 /docs/ 路由 + 「系统信息」页
 *            加帮助文档入口；本机 .md 无关联，双击 .md 会报「文件资源不可用」）；
 *     4.16.2 品牌与启动时长（**结构不变，仍为 18**：系统名改为单位名+产品名、
 *            启动画面至少停留 2 秒）；
 *     4.16.3 角色定义单一来源（**结构不变，仍为 18**：删掉 api.js 里那份只有 3 个旧角色的
 *            副本，改用 policy 的 6 个角色；修掉审计日志写 undefined、三员名空白）；
 *     4.17.0 按角色分权（**结构不变，仍为 18**：权限由服务端下发（actions/views），
 *            前端不再自己判角色；审计员收紧为"只审计"；系统管理员不再被挡在系统设置外）；
 *     4.18.0 登录身份门禁（**结构不变，仍为 18**：登录页改为"下拉选身份 + 用户名 + 密码"，
 *            对外只暴露两种身份（档案管理员 / 其他人员）；三员等保留角色不再出现在界面上）；
 *     4.19.0 登录只要两个框（**结构不变，仍为 18**：登录页去掉用户名，改为"身份 + 口令"；
 *            服务端在该身份的账号里按口令比对，账号仍是一人一个，审计日志仍能查到人）；
 *     4.20.0 权限说定 + 向导下线（**结构不变，仍为 18**：档案管理员能操作一切、其他人员只能查阅
 *            （普通用户连著录和传附件都不行了）；首次使用向导整页删除，只留工作台一条全宗提醒）；
 *     4.20.1 向导彻底删除 + 账号收敛（**结构不变，仍为 18**：/api/setup/* 接口与回归套件一并删除；
 *            账号收敛到 2 个；"档案员=管理员"经实测属安全降级，已回退并记录原因）；
 *     4.20.2 每次打开都必须登录（**结构不变，仍为 18**：去掉自动登录，有会话也要先选身份+输口令；
 *            工作台的全宗提醒从卡片改成一行细条，免得被误认成向导又回来了）；
 *     4.21~4.26 删除留痕·回收站等（结构 18 → 19，新增 archive_trash 表）；
 *     4.27.0 手机号找回口令（结构 19 → 20，新增 login_codes 表；登录页加「忘记密码」，
 *            手机号 → 短信验证码 → 自设新口令 → 进系统；短信通道可配阿里云/腾讯云/通用 HTTP）；
 *     4.27.1 界面换配色（**结构不变，仍为 20**：主色深蓝→墨青，暖白底，樱粉/暖橙做强调；
 *            只改 CSS 令牌与少量硬编码色，不动任何选择器与布局））
 * 一次升级里结构可能连跳多版（v4~v12 各自加了表和列），而应用版本只在
 * 对外发布时跳一次；把两者混成同一个数字，用户就没法判断"我这台跑的是不是新版"。
 *
 * 注意：前端启动后会调 /api/system/info 用这里的值覆盖界面上的版本显示，
 * 所以**这里才是权威**，index.html 里那处只是首屏占位。
 */
const VERSION = '4.31.0';
/**
 * 单位名称（v4.16.2）：出现在控制台启动横幅、浏览器启动画面、侧栏与登录页的品牌位。
 *
 * 注意这是**部署级**的名字，不是"档案管理系统"这个产品名 —— 两者分开：
 * 单位名挂在前面，产品名跟在后面。要换单位时改这一处，并同步 public/index.html
 * 里的品牌位（index.html 是静态页，服务端没有模板注入，两处必须手动保持一致；
 * check-frontend.js 里有守卫盯着"两边都要有单位名"）。
 */
const ORG_NAME = '广州市南沙区排水和污水处理事务中心';

/**
 * 解析命令行参数。
 *
 * 同时支持两种写法：
 *   --port 8899        空格分隔
 *   --port=8899        等号（很多人习惯这么写，之前不支持，会静默当成没传）
 * 纯开关（后面不跟值或跟的是另一个 -- 开头）取 true：
 *   --open   --no-qr
 */
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const raw = a.slice(2);
      const eq = raw.indexOf('=');
      if (eq >= 0) { out[raw.slice(0, eq)] = raw.slice(eq + 1); continue; }
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) out[raw] = true;
      else { out[raw] = next; i++; }
    } else out._.push(a);
  }
  return out;
}

/** 把命令行开关统一解释成布尔（--no-qr / --no-qr=1 / --no-qr true 都算开） */
function argFlag(args, name) {
  const v = args[name];
  if (v === undefined || v === false) return false;
  if (v === true) return true;
  return !/^(0|false|no|off)$/i.test(String(v));
}

function loadConfig(args) {
  const cfgPath = path.join(APP_ROOT, 'server', 'config.json');
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8')); } catch (_) { cfg = {}; }
  const dataDir = args.data ? path.resolve(String(args.data)) : path.join(APP_ROOT, 'data');
  return {
    version: VERSION,
    appRoot: APP_ROOT,
    publicDir: path.join(APP_ROOT, 'public'),
    dataDir,
    dbPath: path.join(dataDir, 'archive.db'),
    filesRoot: path.join(dataDir, 'files'),
    sessionsFile: path.join(dataDir, 'sessions.json'),
    host: String(args.host || process.env.DSH_ARCHIVE_HOST || cfg.host || '127.0.0.1'),
    port: Number(args.port || process.env.DSH_ARCHIVE_PORT || cfg.port || 8787),
    // v4.27.0：短信通道配置（手机号找回口令用）。原样传给 lib/sms.js，
    // 那里再接环境变量 DSH_ARCHIVE_SMS_* 覆盖 —— 密钥写在配置文件里会被备份、截图带走，
    // 所以**推荐用环境变量**，config.json 只是给小规模部署的方便。
    sms: (cfg && typeof cfg.sms === 'object' && cfg.sms) ? cfg.sms : {},
    // v4.31.0：邮件通道配置（邮箱找回口令用）。同样原样传给 lib/mail.js，
    // 那里再接 ARCHIVE_MAIL_* 覆盖；邮箱授权码等同口令，建议走环境变量而不是写文件。
    mail: (cfg && typeof cfg.mail === 'object' && cfg.mail) ? cfg.mail : {},
    open: args.open === true || cfg.openBrowser === true,
    // v4.33.0：授权文件位置。不给就用 <data>/license.json 或程序目录 license.json（见 lib/license.js）
    licenseFile: String(args.license || process.env.DOUBAO_LICENSE || (cfg.licenseFile || '')),
    // v4.31.0（豆包信创）：HTTPS 传输。命令行优先，其次 config.json 的 tls 段，
    // 最后自动找 <data>/tls/ 下的 server.key+server.crt 或 server.pfx。
    // 为什么值得做：等保与测评里"鉴别信息明文传输"是必查项，内网也一样问。
    tls: {
      key: String(args['tls-key'] || (cfg.tls && cfg.tls.key) || ''),
      cert: String(args['tls-cert'] || (cfg.tls && cfg.tls.cert) || ''),
      pfx: String(args['tls-pfx'] || (cfg.tls && cfg.tls.pfx) || ''),
      passphrase: String(args['tls-pfx-pass'] || (cfg.tls && cfg.tls.passphrase) || ''),
      // 只监听本机时也允许开 HTTPS（自签证书浏览器会提示"不受信任"，内网可接受）
      autoDetect: args['no-tls'] === undefined,
    },
    startedAt: new Date().toISOString(),
  };
}

/**
 * 解析 TLS 材料。没有材料就返回 null（继续用 HTTP，启动横幅里明确说明"未启用 HTTPS"）。
 * 支持两种形态：PEM（key+crt）与 PFX（Windows 证书导出更常见，PFX 里带私钥）。
 * PFX 路径放在这里的原因是：Windows 上 `New-SelfSignedCertificate` 直接导出 PFX，
 * 而把它转成 PEM 需要额外工具 —— 少一个依赖就少一个装不上的理由。
 */
function resolveTls(config) {
  const t = (config && config.tls) || {};
  const tryRead = (p) => {
    try { return fs.readFileSync(p); } catch (_) { return null; }
  };
  const explicit = (t.key && t.cert) || t.pfx;
  const dflt = config && config.dataDir ? path.join(config.dataDir, 'tls') : '';
  if (explicit) {
    if (t.pfx) {
      const buf = tryRead(t.pfx);
      if (buf) return { mode: 'pfx', opts: { pfx: buf, passphrase: t.passphrase || undefined } };
    }
    if (t.key && t.cert) {
      const key = tryRead(t.key);
      const cert = tryRead(t.cert);
      if (key && cert) return { mode: 'pem', opts: { key, cert } };
    }
    // 显式给了路径却读不到：这是配置错误，必须说清楚，而不是静默退回 HTTP
    throw new Error(`TLS 证书读取失败：${t.pfx || (t.key + ' / ' + t.cert)}`);
  }
  if (dflt && t.autoDetect !== false) {
    const key = tryRead(path.join(dflt, 'server.key'));
    const cert = tryRead(path.join(dflt, 'server.crt'));
    if (key && cert) return { mode: 'pem(auto)', opts: { key, cert } };
    const pfx = tryRead(path.join(dflt, 'server.pfx'));
    if (pfx) {
      const passFile = path.join(dflt, 'server.pfx.pass');
      const pass = fs.existsSync(passFile) ? fs.readFileSync(passFile, 'utf8').trim() : '';
      return { mode: 'pfx(auto)', opts: { pfx, passphrase: pass || undefined } };
    }
  }
  return null;
}

function sendFile(res, absPath, { download, req }) {
  let stat;
  try { stat = fs.statSync(absPath); } catch (_) { return false; }
  if (!stat.isFile()) return false;
  // 缓存策略（v4.20.8 修）：
  //   HTML 必须 no-store —— 它里面写着 `?v=<版本号>`，一旦 HTML 被缓存住，
  //   浏览器会一直用老版本号去取老资产，服务端换了代码也传不到手机上。
  //   静态资产用 no-cache（每次带 If-Modified-Since 回来问一句）：
  //   正常情况下是一条廉价的 304；而版本一变 URL 就变，连问都不用问。
  const isHtml = /\.html?$/i.test(absPath);
  const headers = {
    'Content-Type': mimeOf(absPath),
    'Content-Length': stat.size,
    'Last-Modified': stat.mtime.toUTCString(),
    'Cache-Control': isHtml ? 'no-store, must-revalidate' : 'no-cache',
  };
  // 下载头必须兼容中文文件名（RFC 5987）。**不能直接把中文写进头部** ——
  // Node 会抛 ERR_INVALID_CHAR，而抛出点在 writeHead 之前，
  // 表现是"请求永远没有响应"，前端只能看到一直转圈。
  if (download) headers['Content-Disposition'] = contentDisposition(path.basename(absPath));
  res.writeHead(200, headers);
  if (req && req.method === 'HEAD') return res.end(), true;
  fs.createReadStream(absPath).pipe(res);
  return true;
}

function createServer(config, api) {
  const publicDir = config.publicDir;

  const handler = async (req, res) => {
    const started = Date.now();
    let url;
    try { url = new URL(req.url, 'http://localhost'); }
    catch (_) { return fail(res, 400, '非法请求地址'); }

    // 走 TLS 时补 HSTS（在 writeHead 之前设置，所以必须放在最前面）
    if (config.tlsResolved) res.setHeader('Strict-Transport-Security', 'max-age=31536000');

    res.on('finish', () => {
      if (config.verbose && !url.pathname.startsWith('/api/files')) {
        const ms = Date.now() - started;
        console.log(`${new Date().toLocaleTimeString('zh-CN')}  ${req.method} ${url.pathname}  ${res.statusCode}  ${ms}ms`);
      }
    });

    // 1) API 优先
    try {
      const handled = await api.handle(req, res, url);
      if (handled) return;
    } catch (e) {
      console.error('[未捕获的接口异常]', e);
      if (!res.headersSent) fail(res, 500, '服务器内部错误');
      return;
    }

    // 2) 文档：把根目录的 使用说明.html / 升级说明.html 挂到 /docs/ 下。
    //    起因（v4.16.1）：本机 `assoc .md` 没有关联，双击 .md 会报「文件资源不可用」。
    //    当时的处理是"再给一条能打开的路"（这个 /docs/ 路由 + 「系统信息」页的入口），
    //    但**那个 .md 一直留在分发包里** —— 结果就是使用者仍然会去点它，
    //    而且只有升级说明会报错（使用说明与路线图本来就没进包，只放了 .html/.txt）。
    //    v4.20.6 把这半截补上：**分发包里不再放任何 .md**，只放 .html / .txt。
    //    留一条后路不如把陷阱搬走 —— 只要那个文件还在，就总有人会去双击它。
    if (req.method === 'GET' || req.method === 'HEAD') {
      // 三种形式都从这里提供（v4.20.6 起）：.html 直接在浏览器里看，
      // .txt / .docx 下到本机再用记事本 / Word 打开 —— 使用者明确要求过这两种形式。
      // 好处是文档的可读性不再依赖文件关联（本机 .md 曾被第三方软件抢去处理）。
      const docM = /^\/docs\/(使用说明|升级说明|升级路线与市场对比)\.(html|txt|docx)$/.exec(
        decodeURIComponent(url.pathname)
      );
      if (docM) {
        const docAbs = path.join(config.appRoot, `${docM[1]}.${docM[2]}`);
        // .html 是"看"，.txt / .docx 是"拿走"：后者带下载头，落到下载目录里双击即用。
        if (fs.existsSync(docAbs)) return void sendFile(res, docAbs, { req, download: docM[2] !== 'html' });
      }
    }

    // 3) 静态资源（仅限 public 目录，防目录穿越）
    if (req.method === 'GET' || req.method === 'HEAD') {
      let rel = decodeURIComponent(url.pathname);
      if (rel === '/' || rel === '') rel = '/index.html';
      const abs = path.resolve(publicDir, '.' + rel);
      if (abs.startsWith(publicDir + path.sep) && fs.existsSync(abs) && fs.statSync(abs).isFile()) {
        return void sendFile(res, abs, { req });
      }
      // 单页应用回退：仅对浏览器页面导航生效，其他（含探测/穿越尝试）一律 404
      const wantsHtml = String(req.headers.accept || '').includes('text/html');
      if (!path.extname(rel) && wantsHtml) {
        const index = path.join(publicDir, 'index.html');
        if (fs.existsSync(index)) return void sendFile(res, index, { req });
      }
      return void fail(res, 404, '资源不存在：' + rel, 'NOT_FOUND');
    }

    fail(res, 405, '不支持的请求方法');
  };

  // HTTPS 由调用方在 config.tlsResolved 里给出（见 resolveTls）：有材料就走 TLS，
  // 没有就照旧 HTTP —— 不因为"想加密但没证书"直接起不来。
  const server = config.tlsResolved
    ? https.createServer(config.tlsResolved.opts, handler)
    : http.createServer(handler);

  server.on('clientError', (err, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
  });

  return server;
}

function openBrowser(url) {
  try {
    if (process.platform === 'win32') execFile('cmd', ['/c', 'start', '""', url], { windowsHide: true }, () => {});
    else if (process.platform === 'darwin') execFile('open', [url], () => {});
    else execFile('xdg-open', [url], () => {});
  } catch (_) { /* 打不开浏览器不影响服务 */ }
}

/**
 * 端口被占用时，先问一句："占用它的，是不是本系统自己？"（v4.20.5）
 *
 * 为什么必须问：原来端口被占就直接顺延（8787 → 8788 → … → 8794）另起一个实例。
 * 而两个实例**用的是同一份 data/**，于是出现最令人困惑的一种局面 ——
 * 桌面上认的是 8787、手机上（或自动打开的浏览器）却是 8794，
 * 使用者以为"同一个系统"，其实是两个进程在读写同一份数据；
 * 一旦哪个实例被关掉，手机上那个地址就彻底打不开，而屏幕上什么线索都没有。
 * 实测就撞上过：手机在 8794 上反复登录失败，而请求记录落在 8787 的那份库里，查了很久。
 *
 * `/api/ping` 是纯文本、不登录、不查库，且第一行是我们独有的标记，用它判断最稳。
 */
function isOurInstanceServing(port, scheme = 'http') {
  // 已启用 HTTPS 的实例，http 探测会被直接 reset，所以两种协议都试一遍：
  // 目的只是"认出是不是自己"，自签证书在这里不需要校验（同机、只看正文标记）。
  const probe = (mod, opts) => new Promise((resolve) => {
    const req = mod.get(opts, (res) => {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', (d) => { buf += d; if (buf.length > 400) req.destroy(); });
      res.on('end', () => resolve(buf.includes('豆包信创档案管理系统在运行')));
      res.on('error', () => resolve(false));
    });
    req.on('timeout', () => { req.destroy(); resolve(false); });
    req.on('error', () => resolve(false));
  });
  const order = scheme === 'https' ? [https, http] : [http, https];
  return (async () => {
    for (const mod of order) {
      const hit = await probe(mod, {
        host: '127.0.0.1', port, path: '/api/ping', timeout: 1500,
        rejectUnauthorized: false,
      });
      if (hit) return true;
    }
    return false;
  })();
}

function findFreePort(host, start, tries = 20) {
  return new Promise((resolve) => {
    let port = start;
    let left = tries;
    const tryOne = () => {
      const probe = http.createServer();
      probe.once('error', () => {
        port += 1;
        left -= 1;
        if (left <= 0) return resolve(start);
        setImmediate(tryOne);
      });
      probe.once('listening', () => probe.close(() => resolve(port)));
      probe.listen(port, host);
    };
    tryOne();
  });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const config = loadConfig(args);
  config.verbose = !args.quiet;

  // TLS 材料解析放在建库之前：证书配错要第一时间说清楚，而不是等库都升完级才报错
  try {
    config.tlsResolved = resolveTls(config);
  } catch (e) {
    console.error('[HTTPS] ' + e.message);
    console.error('  处理：检查 --tls-key/--tls-cert（或 --tls-pfx）路径是否存在；想继续用 HTTP 就加 --no-tls。');
    return 1;
  }
  const scheme = config.tlsResolved ? 'https' : 'http';

  fs.mkdirSync(config.dataDir, { recursive: true });
  fs.mkdirSync(config.filesRoot, { recursive: true });

  const db = openDatabase(config.dbPath);

  const { makeApi } = require('./lib/q');
  const q0 = makeApi(db);

  const sessions = createSessions(config.sessionsFile);
  const api = createApi({ db, filesRoot: config.filesRoot, sessions, appRoot: APP_ROOT, config });

  // ---------------------------------------------------------------- 定时任务（v13）
  // 组装顺序是刻意的：api 提供业务实现（runBackup / runStorageCheck / runDetectionSweep），
  // 调度器只负责"什么时候跑"，跑完再把调度器回注给 api（供状态与手动触发接口查询）。
  // 这样依赖是单向的：api 不需要 require scheduler，scheduler 也不需要认识路由。
  let scheduler = null;
  const schedulerEnabled = String(q0.scalar("SELECT value FROM settings WHERE key='scheduler.enabled'") || '1') !== '0';
  if (!args['no-scheduler'] && schedulerEnabled) {
    const { createScheduler } = require('./lib/scheduler');
    const { buildJobs } = require('./lib/jobs');
    scheduler = createScheduler({ db });
    for (const spec of buildJobs({ api, db })) scheduler.register(spec);
    api.attachScheduler(scheduler);
  }

  // 启动即处理借阅到期：按设置自动归还，或标记逾期
  try {
    const r = api.processLoanDue();
    if (r.autoReturned) console.log(`[借阅到期] 已自动归还 ${r.autoReturned} 条到期借出记录`);
    if (r.markedOverdue) console.log(`[借阅到期] 已标记 ${r.markedOverdue} 条逾期记录`);
  } catch (e) {
    console.warn('[借阅到期] 处理失败（不影响启动）：' + e.message);
  }
  // 修正历史档案的在库/借出状态，保证与借阅记录一致
  q0.run(`UPDATE archives SET status='借出'
          WHERE status='在库' AND id IN (SELECT archive_id FROM loans WHERE mode='借出' AND status IN ('已批准','逾期'))`);
  q0.run(`UPDATE archives SET status='在库'
          WHERE status='借出' AND id NOT IN (SELECT archive_id FROM loans WHERE mode='借出' AND status IN ('已批准','逾期'))`);

  if (args.demo) {
    const { seedDemo } = require('./tools/demo-data');
    const n = seedDemo(db, { filesRoot: config.filesRoot });
    console.log(n ? `已生成演示数据：${n} 条档案（含示例附件与借阅记录）` : '演示数据已存在，跳过生成');
  }

  // 启动即校验审计日志链。
  //
  // 为什么放在启动而不是等到查账：DA/T 92—2022 §9.5 要求审计跟踪"记录发现问题"。
  // 链一旦断开，说明历史操作日志被修改或删除过 —— 这是**必须马上知道**的事，
  // 拖到需要举证的时候才发现，证据价值已经没了。
  // 为了让启动不被超大日志拖慢，超过 10 万条时只校验最近的 10 万条并明确说明。
  try {
    const { verifyChain, GENESIS } = require('./lib/audit');
    const total = Number(q0.scalar('SELECT COUNT(*) AS c FROM logs') || 0);
    const CAP = 100000;
    let startPrev = GENESIS;
    let offset = 0;
    if (total > CAP) {
      offset = total - CAP;
      const before = db.prepare('SELECT hash FROM logs ORDER BY id LIMIT 1 OFFSET ?').get(offset - 1);
      startPrev = (before && before.hash) ? before.hash : GENESIS;
    }
    const rows = total
      ? db.prepare(`SELECT * FROM logs ORDER BY id LIMIT ${CAP} OFFSET ${offset}`).all()
      : [];
    const vr = verifyChain(rows, startPrev);
    if (!vr.ok) {
      console.error('');
      console.error('  ============================================================');
      console.error('   ！！ 审计日志链校验失败 —— 历史操作日志被改动过 ！！');
      console.error(`   断点：日志 id=${vr.brokenAt}`);
      console.error(`   原因：${vr.reason}`);
      console.error('  ============================================================');
      console.error('   请立即封存当前数据目录（不要继续写入），并用另一个备份比对排查。');
      console.error('   复核入口：系统管理 → 操作日志 → 校验日志链（/api/logs/verify）');
      console.error('');
    } else if (vr.count) {
      console.log(`[审计自检] 审计日志链完整：${vr.count} 条`
        + (total > CAP ? `（共 ${total} 条，本次校验最近 ${CAP} 条）` : '')
        + '，SHA-256 链式哈希');
    }
  } catch (e) {
    console.warn('[审计自检] 跳过（不影响启动）：' + e.message);
  }

  // 审计外存（v4.33.0）：启动即留一次锚点，之后按 audit.anchor_hours（默认 24h）定时再留，
  // 并把新增日志追加到外存目录（若已配置 audit.mirror_dir）。
  // 为什么必须在库外留：哈希链只能证明"库内没被改"，证明不了"整库被换回旧备份"。
  const auditAnchor = require('./lib/audit-anchor');
  const anchorOnce = (note) => {
    try {
      const mirrorDir = String(q0.scalar("SELECT value FROM settings WHERE key='audit.mirror_dir'") || '');
      const r = auditAnchor.runAnchor({ db, dataDir: config.dataDir, mirrorDir, note, byName: 'system' });
      if (r.errors.length) console.warn('[审计外存] ' + r.errors.join('；'));
      else if (r.anchor.logs_total) {
        console.log(`[审计外存] 锚点已生成：日志 ${r.anchor.logs_total} 条，链尾 #${r.anchor.last_id}`
          + `，链${r.anchor.chain_ok ? '完整' : '异常'}`
          + (mirrorDir ? `，外存追加 ${r.mirror.appended} 条 → ${mirrorDir}` : '（未配置外存目录）'));
      }
      if (!r.anchor.chain_ok) {
        console.error('  ！！ 审计外存校验发现链断裂：' + (r.anchor.chain_reason || ''));
      }
    } catch (e) {
      console.warn('[审计外存] 跳过（不影响启动）：' + e.message);
    }
  };
  anchorOnce('服务启动');
  let anchorTimer = null;
  try {
    const hours = Math.max(1, Number(q0.scalar("SELECT value FROM settings WHERE key='audit.anchor_hours'") || 24) || 24);
    anchorTimer = setInterval(() => anchorOnce('定时锚点'), hours * 3600 * 1000);
    anchorTimer.unref();
  } catch (_) { /* 定时器起不来不影响服务 */ }

  // 启动即自动为每份档案生成二维码图片。
  //
  // 默认走 Python 的 qrcode 库（纠错 H / 静区 6 / 每模块 15px，PNG 输出）；
  // 本机没有可用的 Python + qrcode 时，自动退回系统内置的二维码引擎，
  // 保证「同事电脑没装 Python」也不会让这个功能失效。
  // 放在演示数据之后，这样演示库也会一并生成。
  // 增量执行：已有且不比档案新的图片直接跳过，所以重复启动很快。
  //
  // 可用 --no-qr 临时关掉；用 --qr-engine=python|builtin|auto 指定引擎；
  // 静区与模块边长取系统设置 qr.border / qr.box_size，控制台会打印实际用的值。
  if (!argFlag(args, 'no-qr') && process.env.DSH_ARCHIVE_NO_QR !== '1') {
    try {
      const archiveQr = require('./lib/archive-qr');
      const engine = String(args['qr-engine'] || process.env.DSH_ARCHIVE_QR_ENGINE
        || q0.scalar("SELECT value FROM settings WHERE key='qr.engine'") || 'auto').toLowerCase();
      const border = Number(q0.scalar("SELECT value FROM settings WHERE key='qr.border'"));
      const boxSize = Number(q0.scalar("SELECT value FROM settings WHERE key='qr.box_size'"));
      // 二维码内容参数：公网地址、内容模式、落地页签名密钥
      const settingS = (k) => q0.scalar('SELECT value FROM settings WHERE key=?', k) || '';
      let signKey = settingS('qr.sign_key');
      if (!signKey) {
        signKey = require('./lib/qr-content').newSignKey();
        q0.run("INSERT INTO settings(key,value) VALUES('qr.sign_key',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", signKey);
      }
      const baseUrl = settingS('qr.base_url').trim().replace(/\/+$/, '')
        || (config.host === '0.0.0.0' && require('./lib/net').lanIPv4List().length
          ? 'http://' + require('./lib/net').lanIPv4List()[0].address + ':' + (config.actualPort || config.port)
          : '');
      const t0 = Date.now();
      const st = archiveQr.generateAllWithEngine({
        db, dataDir: config.dataDir, engine,
        border: Number.isFinite(border) && border > 0 ? border : undefined,
        boxSize: Number.isFinite(boxSize) && boxSize > 0 ? boxSize : undefined,
        baseUrl, archiveMode: settingS('qr.archive_mode') || 'url', signKey,
        onProgress: (done, total) => {
          if (total > 200) console.log(`[档案二维码] 生成中… ${done}/${total}`);
        },
      });
      const ms = Date.now() - t0;
      const engineLabel = st.engine === 'python-qrcode'
        ? `Python qrcode 库${st.pythonVersion ? '（Python ' + st.pythonVersion + '）' : ''}`
        : '内置引擎';
      if (!st.ok) {
        console.warn(`[档案二维码] 生成失败：${st.reason || '未知原因'}`);
        console.warn('[档案二维码] 指定了 --qr-engine=python，但本机 Python 不可用；'
          + '可改用 --qr-engine=auto 自动退回内置引擎。');
      } else {
        console.log(`[档案二维码] 共 ${st.total} 份档案：新生成 ${st.created}，已存在 ${st.skipped}`
          + `${st.failed ? '，失败 ' + st.failed : ''}`
          + `${st.orphansRemoved ? '，清理孤儿图片 ' + st.orphansRemoved : ''}（${ms}ms）`);
        console.log(`[档案二维码] 引擎：${engineLabel}　参数：纠错 H / 静区 ${st.border || border} / 每模块 ${st.box_size || boxSize}px　目录：${st.dir}`);
        // 地址变了（本机 IP 是 DHCP 的，随时会变）就自动把旧图全部重写，
        // 否则二维码看着好好的、扫出来却指向一个已经失效的地址。
        if (st.staleDetected && st.staleDetected.stale) {
          console.log(`[档案二维码] 检测到变化并已自动重写：`
            + `${st.staleDetected.contentChanged ? '网址/内容变了 ' + st.staleDetected.contentChanged + ' 张' : ''}`
            + `${st.staleDetected.paramsChanged ? (st.staleDetected.contentChanged ? '，' : '') + '静区/模块边长参数变了' : ''}`);
          console.log('[档案二维码] 提示：屏幕上显示的二维码已经是新地址；'
            + '此前**已经打印贴在盒子上的旧标签**不会自动更新，需要重新打印。');
        }
        if (st.fallbackReason) console.log(`[档案二维码] 说明：${st.fallbackReason}`);
        if (st.errors && st.errors.length) st.errors.slice(0, 5).forEach((e) => console.warn('  ! ' + e));
      }
    } catch (e) {
      console.warn('[档案二维码] 生成失败（不影响系统使用）：' + e.message);
    }
  }

  const host = config.host;
  const port = args['no-port-fallback'] ? config.port : await findFreePort(host, config.port);
  if (port !== config.port) {
    // 端口被占用：先确认占用者是不是本系统自己（见 isOurInstanceServing 的说明）。
    // 是 → **不再启动第二个实例**，直接把浏览器指到已在运行的那个，然后退出。
    // 这从根上消灭了"同一份数据、两个地址"的混乱。
    if (await isOurInstanceServing(config.port, scheme)) {
      const shown = config.port === 80 ? '127.0.0.1' : `${host === '0.0.0.0' ? '127.0.0.1' : host}`;
      const runningUrl = `${scheme}://${shown}:${config.port}/`;
      console.log('');
      console.log(`  本系统已经在运行（端口 ${config.port}），不再启动第二个实例。`);
      console.log(`  正在使用的地址：${runningUrl}`);
      console.log('  如需重启：先关掉那个正在运行的黑窗口（或在其中按 Ctrl+C），再运行本脚本。');
      console.log('');
      if (config.open) openBrowser(runningUrl);
      return 0;
    }
    console.log(`端口 ${config.port} 被占用（占用者不是本系统），已自动改用 ${port}`);
  }

  const server = createServer(config, api);

  /**
   * keep-alive 超时（v4.17.0）。
   *
   * Node 默认 `keepAliveTimeout = 5 秒`：连接空闲 5 秒就被服务端单方面关掉。
   * 问题出在**客户端还在复用那条连接**时 —— 它会收到一个 ECONNRESET，
   * 表现为 `TypeError: fetch failed`，而且**位置随机**（取决于两次请求之间隔了多久）。
   *
   * 这不是理论问题：本项目的回归套件里有 OCR 小节，要 spawnSync 起 PowerShell、
   * 一跑好几秒，之后的下一个请求就偶发 `fetch failed`；
   * 同一套件重跑有时过、有时不过，位置还会变（曾经查成"玄学抖动"）。
   * 真实使用场景里也一样：使用者在页面上停一会儿再点，浏览器会自己重连所以看不出来，
   * 但任何用连接池调本接口的程序（脚本、对接系统）都会踩到。
   *
   * 取 65 秒是业界惯例（nginx 也是这个量级），且必须 **headersTimeout > keepAliveTimeout**，
   * 否则会出现"连接刚被判定空闲、请求头又到了"的竞态。
   */
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 66000;

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, resolve);
  });

  // 让 API 层知道真实监听端口：二维码里要写进可被手机打开的网址，
  // 端口被占用自动顺延时必须用真实端口，否则手机上打不开。
  config.actualPort = port;

  const shownHost = host === '0.0.0.0' ? '127.0.0.1' : host;
  const url = `${scheme}://${shownHost}:${port}/`;
  const lanIps = host === '0.0.0.0' ? lanIPv4List().map((x) => x.address) : [];

  // 登录提示必须按**真实库状态**给出，不能写死出厂口令。
  // 沿用旧库时管理员口令通常不是 admin123（本机实例库里就是 123456），
  // 写死会把人直接带进"密码错误"，比不提示更糟。
  // （印之前用哈希验一遍：只有当库里确实还是出厂口令时才印 admin123）
  let account = '';
  let accountHint = '';
  try {
    const admins = db
      .prepare(
        "SELECT username, password_hash, password_salt, must_change FROM users " +
          "WHERE role='admin' AND status='active' ORDER BY id"
      )
      .all();
    const isFactory = (a) => verifyPassword('admin123', a.password_salt, a.password_hash);
    if (!admins.length) {
      account = '库中暂无启用中的管理员';
      accountHint = '请先初始化管理员账号';
    } else if (admins.every(isFactory) && admins.every((a) => a.must_change)) {
      account = admins.map((a) => a.username).join(' / ') + '  ·  admin123';
      accountHint = '首次登录会强制修改口令';
    } else {
      account = admins.map((a) => a.username).join(' / ');
      accountHint = '口令是你此前设置的，系统不显示';
      const mustChange = admins.filter((a) => a.must_change).map((a) => a.username);
      if (mustChange.length) accountHint += `；${mustChange.join(' / ')} 下次登录会被强制修改口令`;
    }
  } catch (e) {
    account = '无法读取账号表（' + e.message + '）';
  }

  // 启动横幅（v4.16.0）：版面细节与"为什么不能用右边框/不能按字符数对齐"见 lib/banner.js
  const notes = [];
  if (lanIps.length) {
    notes.push({ text: '手机扫码前请确认与本机在同一个 WiFi / 局域网' });
  } else if (host !== '0.0.0.0') {
    notes.push({ text: '手机扫码打不开：当前只监听本机，请改用「局域网访问.bat」启动，或加 --host 0.0.0.0', warn: true });
  }
  notes.push({ text: '用完在本窗口按 Ctrl+C 停止；关闭这个黑窗口，服务就停了' });
  // 手机号找回口令的通道状态（v4.27.0）。
  // 为什么要在启动时就说：这个功能**不配通道就等于没有**，而使用者只会在登录页上
  // 看到"短信通道未配置" —— 那时再去翻文档已经晚了。启动横幅是管理员一定看得到的位置。
  try {
    const smsStatus = require('./lib/sms').createSms(config.sms);
    const d = smsStatus.describe();
    notes.push({
      text: d.configured
        ? `手机号找回口令：已启用（${d.provider} 通道）`
        : '手机号找回口令：未配置短信通道（登录页只可用口令登录）',
    });
  } catch (e) {
    notes.push({ text: '手机号找回口令：短信通道加载失败（' + e.message + '）', warn: true });
  }
  notes.push({
    text: config.tlsResolved
      ? `传输加密：已启用 HTTPS（${config.tlsResolved.mode} 证书），口令与令牌不再明文过网`
      : '传输加密：未启用 HTTPS（内网可用；要过等保测评请配证书，见 信创-HTTPS配置\\说明.txt）',
    warn: !config.tlsResolved,
  });
  // 授权状态（v4.33.0）：管理员必须一开机就知道"授权还有多久、是不是只读"。
  try {
    const lic = require('./lib/license').checkLicense({ dataDir: config.dataDir, explicit: config.licenseFile });
    const pv = require('./lib/license').publicView(lic);
    notes.push({
      text: pv.state === 'ok'
        ? `授权：${pv.unit}（${pv.edition}）至 ${pv.expires_at}`
          + `${pv.remainDays !== null && pv.remainDays <= 30 ? `，剩余 ${pv.remainDays} 天，请续期` : ''}`
        : pv.state === 'none'
          ? '授权：未放置 license.json（未启用授权保护，正式交付请签发）'
          : `授权：${pv.state === 'expired' ? '已到期' : pv.state === 'mismatch' ? '机器码不符' : '文件无效'} —— 已进入只读模式（档案仍可查/导出/备份）`,
      warn: pv.state !== 'ok',
    });
  } catch (e) {
    notes.push({ text: '授权：校验失败（' + e.message + '）', warn: true });
  }
  for (const line of banner.renderBanner({
    version: VERSION,
    org: ORG_NAME,
    title: '豆包信创 · 档案管理系统',
    tagline: '零依赖 · 便携运行 · 数据全部留在本机',
    localUrl: url,
    lanUrls: lanIps.map((ip) => `${scheme}://${ip}:${port}/`),
    account,
    accountHint,
    dataDir: config.dataDir,
    scheduler: scheduler
      // 这里刻意用短横线分隔并省掉"已注册"三个字：整行显示宽度要压在 80 列以内，
      // 否则在最常见的 80 列控制台里会折行，折行后那行就再也不是"一个字段一行"了。
      ? `${scheduler.keys().length} 个 · 每日备份 / 四检巡检 / 哈希校验 / 到期提醒 / 记录清理`
      : '未启用（--no-scheduler 或 scheduler.enabled=0）',
    notes,
  })) console.log(line);

  // 登录尝试记录的定期清理（保留天数由 security.login_attempts_keep_days 决定）
  try {
    const pruned = api.pruneLoginAttempts();
    if (pruned) console.log(`[登录防护] 已清理 ${pruned} 条过期登录尝试记录`);
  } catch (e) {
    console.warn('[登录防护] 清理登录尝试记录失败：' + e.message);
  }

  // OCR 引擎探测**在启动后主动预热一次**（v4.13.0）。
  //
  // 为什么必须预热：探测要 spawnSync 起一次 PowerShell（Windows 自带 OCR），
  // 而 **spawnSync 会阻塞整个 Node 事件循环** —— 如果等到第一个请求才探测，
  // 那一刻全服务器都会卡住几秒（表现为"随便点哪一页都转圈"）。
  // 预热之后 `/api/ocr/status` 只读缓存，请求路径上不再有外部进程。
  // 放在横幅之后、异步执行，不拖慢"服务已就绪"。
  setTimeout(() => {
    try {
      const det = api.warmOcrDetect();
      if (det) {
        console.log(det.available
          ? `[OCR] 可用引擎：${det.engine}${(det.windows && det.windows.profileLang) ? '（' + det.windows.profileLang + '）' : ''}`
            + `${det.canPdf ? '，扫描版 PDF 也能识别' : ''}`
          : '[OCR] 本机没有可用的识别引擎；扫描件与图片的正文将无法检索（不影响其它功能）');
      }
    } catch (e) {
      console.warn('[OCR] 引擎探测失败（不影响其它功能）：' + e.message);
    }
  }, 800);

  // 弱口令审计放到启动之后异步跑：它要拿候选口令逐个比对已存储的哈希，
  // scrypt 每次几十毫秒，账号一多会明显拖慢启动，而这件事并不着急。
  setTimeout(() => {
    try { api.auditWeakPasswords(); } catch (_) { /* 静默，不影响服务 */ }
  }, 1500);

  // 调度器放在横幅之后启动：启动时的"补跑判定"可能要跑任务（例如停机一天后的自动备份），
  // 不能让它拖慢"服务已就绪"的提示 —— 用户看到地址就能用，任务在后台自己跑。
  if (scheduler) {
    scheduler.start().catch((e) => console.warn('[调度器] 启动失败：' + e.message));
  }

  if (config.open) setTimeout(() => openBrowser(url), 400);

  const shutdown = () => {
    console.log('\n正在停止服务...');
    if (scheduler) scheduler.stop();
    server.close(() => {
      try { db.close(); } catch (_) { /* ignore */ }
      console.log('服务已停止，数据已安全保存。');
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  process.on('unhandledRejection', (e) => console.error('[未处理的 Promise 异常]', e));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('\n启动失败：' + (e && e.message ? e.message : e));
    if (e && e.code === 'EADDRINUSE') console.error('端口被占用，请换一个端口：node server/server.js --port 8899');
    process.exit(1);
  });
}

module.exports = { loadConfig, createServer, main, APP_ROOT, VERSION };
