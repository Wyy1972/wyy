/**
 * 数据库初始化 —— 零依赖，使用 Node 内置 node:sqlite
 * 表结构覆盖：用户、分类树、档案门类、档案、附件、借阅、操作日志、全文索引
 */
'use strict';

/**
 * node:sqlite 是 Node 22.5 才加入的内置模块（22.13 起不需要额外标志）。
 * 这里包一层 try/catch：任何入口（服务端、各种自测脚本）加载到本文件时，
 * 只要 Node 版本不够，都能看到一句人能看懂的提示，而不是
 * "Cannot find module 'node:sqlite'"。
 */
let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  const { checkNodeVersion } = require('./lib/node-version');
  const r = checkNodeVersion();
  console.error(r.ok
    ? '无法加载内置 SQLite 模块（node:sqlite）：' + e.message
    : r.message);
  process.exit(1);
}
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const audit = require('./lib/audit');
const pinyin = require('./lib/pinyin');

const SCHEMA_VERSION = 27;

/** 与 Node 内置 crypto 保持一致的密码存储：scrypt 加盐哈希 */
function hashPassword(plain, salt) {
  const s = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(plain), s, 32).toString('hex');
  return { salt: s, hash };
}

function verifyPassword(plain, salt, hash) {
  const h = crypto.scryptSync(String(plain), salt, 32).toString('hex');
  const a = Buffer.from(h, 'hex');
  const b = Buffer.from(String(hash), 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/**
 * 国家档案分类方案（DA/T 参照）种子数据
 * children 表示下级分类，level 自动计算
 */
const SEED_CATEGORIES = [
  {
    name: '文书档案', code: 'WS', children: [
      { name: '党群工作', code: 'WS-DQ' },
      { name: '行政管理', code: 'WS-XZ' },
      { name: '业务管理', code: 'WS-YW' },
      { name: '上级来文', code: 'WS-SJ' },
      { name: '本单位发文', code: 'WS-BW' },
    ],
  },
  {
    name: '合同档案', code: 'HT', children: [
      { name: '采购合同', code: 'HT-CG' },
      { name: '销售合同', code: 'HT-XS' },
      { name: '服务合同', code: 'HT-FW' },
      { name: '租赁合同', code: 'HT-ZL' },
      { name: '劳动合同', code: 'HT-LD' },
    ],
  },
  {
    name: '人事档案', code: 'RS', children: [
      { name: '员工履历', code: 'RS-LL' },
      { name: '考核奖惩', code: 'RS-KH' },
      { name: '职称评审', code: 'RS-ZC' },
      { name: '培训记录', code: 'RS-PX' },
      { name: '离职退休', code: 'RS-LZ' },
    ],
  },
  {
    name: '财务档案', code: 'CW', children: [
      { name: '会计凭证', code: 'CW-PZ' },
      { name: '会计账簿', code: 'CW-ZB' },
      { name: '财务报告', code: 'CW-BG' },
      { name: '预算决算', code: 'CW-YS' },
      { name: '审计资料', code: 'CW-SJ' },
    ],
  },
  {
    name: '工程档案', code: 'GC', children: [
      { name: '立项审批', code: 'GC-LX' },
      { name: '设计图纸', code: 'GC-SJ' },
      { name: '施工资料', code: 'GC-SG' },
      { name: '竣工资料', code: 'GC-JG' },
      { name: '设备档案', code: 'GC-SB' },
    ],
  },
  {
    // 排水、污水处理单位的主业档案（v4.30.5 补入）：管网、农污设施、污水厂的养护
    name: '养护档案', code: 'YH', children: [
      { name: '排水管网养护', code: 'YH-GW' },
      { name: '农污养护', code: 'YH-NW' },
      { name: '污水厂养护', code: 'YH-WSC' },
    ],
  },
  {
    // 安全生产检查（v4.30.5 补入）
    name: '安全生产检查', code: 'AQ', children: [
      { name: '检查记录', code: 'AQ-JC' },
      { name: '隐患整改', code: 'AQ-ZG' },
    ],
  },
];

/**
 * 档案门类定义：每个门类带一组自定义著录字段（fields 为 JSON）
 * 字段类型支持：text / textarea / date / number / select
 */
const SEED_TYPES = [
  {
    code: 'WS',
    name: '文书档案',
    retention: '永久',
    fields: [
      { key: 'fwzh', label: '发文字号', type: 'text' },
      { key: 'mjmc', label: '密级', type: 'select', options: ['公开', '内部', '秘密', '机密'] },
      { key: 'zrz', label: '责任者', type: 'text' },
      { key: 'cjz', label: '成文日期', type: 'date' },
      { key: 'fs', label: '份数', type: 'number' },
      { key: 'ztc', label: '主题词', type: 'text' },
    ],
  },
  {
    code: 'HT',
    name: '合同档案',
    retention: '定期30年',
    fields: [
      { key: 'hth', label: '合同编号', type: 'text' },
      { key: 'jf', label: '甲方', type: 'text' },
      { key: 'yf', label: '乙方', type: 'text' },
      { key: 'je', label: '合同金额(元)', type: 'number' },
      { key: 'qdrq', label: '签订日期', type: 'date' },
      { key: 'yxq', label: '有效期至', type: 'date' },
      { key: 'ldr', label: '承办人', type: 'text' },
    ],
  },
  {
    code: 'RS',
    name: '人事档案',
    retention: '永久',
    fields: [
      { key: 'xm', label: '姓名', type: 'text' },
      { key: 'gh', label: '工号', type: 'text' },
      { key: 'bm', label: '部门', type: 'text' },
      { key: 'zw', label: '职务/职称', type: 'text' },
      { key: 'rzrq', label: '入职日期', type: 'date' },
      { key: 'mjmc', label: '密级', type: 'select', options: ['内部', '秘密', '机密'] },
    ],
  },
  {
    code: 'CW',
    name: '财务档案',
    retention: '定期30年',
    fields: [
      { key: 'pzh', label: '凭证/账簿号', type: 'text' },
      { key: 'kjqj', label: '会计期间', type: 'text' },
      { key: 'hje', label: '合计金额(元)', type: 'number' },
      { key: 'zdr', label: '制单人', type: 'text' },
      { key: 'shr', label: '审核人', type: 'text' },
      { key: 'jzrq', label: '记账日期', type: 'date' },
    ],
  },
  {
    code: 'GC',
    name: '工程档案',
    retention: '永久',
    fields: [
      { key: 'gcmc', label: '工程名称', type: 'text' },
      { key: 'tzh', label: '图纸编号', type: 'text' },
      { key: 'gch', label: '规格图号', type: 'text' },
      { key: 'bcr', label: '编制人', type: 'text' },
      { key: 'bcrq', label: '编制日期', type: 'date' },
      { key: 'sbr', label: '设计单位', type: 'text' },
    ],
  },
  {
    // 养护档案（v4.30.5）：排水管网、农污设施、污水厂的日常养护与专项养护记录
    code: 'YH',
    name: '养护档案',
    retention: '定期30年',
    fields: [
      { key: 'ssmc', label: '设施/路段名称', type: 'text' },
      { key: 'yhlb', label: '养护类别', type: 'select', options: ['排水管网养护', '农污', '污水厂'] },
      { key: 'yhfs', label: '养护方式', type: 'select', options: ['日常养护', '专项养护', '应急抢修'] },
      { key: 'kgrq', label: '开工日期', type: 'date' },
      { key: 'wgrq', label: '完工日期', type: 'date' },
      { key: 'yhdw', label: '养护单位', type: 'text' },
      { key: 'zrr', label: '责任人', type: 'text' },
      { key: 'gcl', label: '工程量', type: 'text' },
      { key: 'ysjl', label: '验收结论', type: 'select', options: ['合格', '不合格', '整改后合格'] },
      { key: 'bz', label: '备注', type: 'textarea' },
    ],
  },
  {
    // 安全生产检查（v4.30.5）
    code: 'AQ',
    name: '安全生产检查',
    retention: '定期10年',
    fields: [
      { key: 'jcmc', label: '检查名称', type: 'text' },
      { key: 'jclx', label: '检查类型', type: 'select', options: ['日常检查', '专项检查', '节前检查', '上级督查'] },
      { key: 'jcrq', label: '检查日期', type: 'date' },
      { key: 'jcdw', label: '检查单位', type: 'text' },
      { key: 'jcr', label: '检查人', type: 'text' },
      { key: 'wt', label: '发现问题', type: 'textarea' },
      { key: 'yhdj', label: '隐患等级', type: 'select', options: ['一般', '较大', '重大'] },
      { key: 'zgqk', label: '整改情况', type: 'textarea' },
      { key: 'zgrq', label: '整改完成日期', type: 'date' },
    ],
  },
];

function openDatabase(dbPath) {
  const dir = path.dirname(dbPath);
  fs.mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec('PRAGMA busy_timeout = 5000');
  migrate(db);
  seed(db);
  return db;
}

function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS meta (
      key   TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS users (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      username    TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL DEFAULT '',
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      -- 业务角色：clerk 档案员 | reader 普通用户
      -- 三员（《电子档案管理系统基本功能规定》第四十一条）：
      --   sysadmin 系统管理员 | secadmin 系统安全保密员 | auditor 系统安全审计员
      -- admin 为旧版超级角色，保留以兼容既有部署
      role        TEXT NOT NULL DEFAULT 'reader',
      -- 密级上限：该账号可见的最高密级。留空 = 按角色默认（见 lib/policy.js defaultClearance）
      clearance   TEXT NOT NULL DEFAULT '',
      department  TEXT NOT NULL DEFAULT '',
      phone       TEXT NOT NULL DEFAULT '',
      email       TEXT NOT NULL DEFAULT '',
      status      TEXT NOT NULL DEFAULT 'active',   -- active | disabled
      must_change INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS categories (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
      name      TEXT NOT NULL,
      code      TEXT NOT NULL UNIQUE,
      level     INTEGER NOT NULL DEFAULT 1,
      sort_no   INTEGER NOT NULL DEFAULT 0,
      remark    TEXT NOT NULL DEFAULT ''
    );

    -- 改前快照（v4.32.0 豆包信创）：「误改可回退」的数据底座。
    -- 每次修改档案前，把修改前的整行 JSON 存一份；发现改错了可以一键还原到任一历史版本。
    -- 与审计日志的区别：审计日志记"谁在什么时候改了什么"，这里存的是"改之前到底长什么样"。
    CREATE TABLE IF NOT EXISTS archive_versions (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id    INTEGER NOT NULL,
      archive_code  TEXT NOT NULL DEFAULT '',
      title         TEXT NOT NULL DEFAULT '',
      snapshot      TEXT NOT NULL,                 -- 修改前整行的 JSON
      action        TEXT NOT NULL DEFAULT '修改',   -- 修改 | 还原前自动备份 | 批量修改
      note          TEXT NOT NULL DEFAULT '',
      changed_by    TEXT NOT NULL DEFAULT '',
      changed_by_id INTEGER,
      changed_at    TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_archive_versions_aid ON archive_versions(archive_id, id DESC);

    -- 恢复演练台账（豆包信创）：备份"做过"不等于"能恢复"，验收时会当场让你恢复一次。
    -- 每次演练（不落盘，只开包核对）与实际恢复各记一条，成为可审计的证据链。
    CREATE TABLE IF NOT EXISTS backup_drills (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      at          TEXT NOT NULL,
      backup_no   TEXT NOT NULL DEFAULT '',
      mode        TEXT NOT NULL DEFAULT '演练',      -- 演练 | 实际恢复
      result      TEXT NOT NULL DEFAULT '',          -- 合格 | 不合格
      archives    INTEGER NOT NULL DEFAULT 0,
      files       INTEGER NOT NULL DEFAULT 0,
      users       INTEGER NOT NULL DEFAULT 0,
      logs        INTEGER NOT NULL DEFAULT 0,
      chain_ok    INTEGER NOT NULL DEFAULT 0,
      detail      TEXT NOT NULL DEFAULT '',
      by_user     INTEGER,
      by_name     TEXT NOT NULL DEFAULT '',
      ip          TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS archive_types (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      code      TEXT NOT NULL UNIQUE,
      name      TEXT NOT NULL,
      retention TEXT NOT NULL DEFAULT '永久',
      prefix    TEXT NOT NULL DEFAULT '',
      fields    TEXT NOT NULL DEFAULT '[]',
      sort_no   INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS archives (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_code  TEXT NOT NULL UNIQUE,
      title         TEXT NOT NULL,
      category_id   INTEGER NOT NULL REFERENCES categories(id),
      type_code     TEXT NOT NULL,
      retention     TEXT NOT NULL DEFAULT '永久',
      secret_level  TEXT NOT NULL DEFAULT '公开',
      year          TEXT NOT NULL DEFAULT '',
      archive_date  TEXT NOT NULL DEFAULT '',
      volume_no     TEXT NOT NULL DEFAULT '',
      item_no       TEXT NOT NULL DEFAULT '',
      pages         TEXT NOT NULL DEFAULT '',
      copies        INTEGER NOT NULL DEFAULT 1,
      carrier       TEXT NOT NULL DEFAULT '纸质',
      responsible   TEXT NOT NULL DEFAULT '',
      department    TEXT NOT NULL DEFAULT '',
      abstract      TEXT NOT NULL DEFAULT '',
      keywords      TEXT NOT NULL DEFAULT '',
      extra         TEXT NOT NULL DEFAULT '{}',
      location      TEXT NOT NULL DEFAULT '',
      status        TEXT NOT NULL DEFAULT '在库',    -- 在库 | 借出 | 待整理 | 已销毁 | 待销毁
      status_note   TEXT NOT NULL DEFAULT '',
      created_by    INTEGER REFERENCES users(id),
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_archives_cat  ON archives(category_id);
    CREATE INDEX IF NOT EXISTS idx_archives_type ON archives(type_code);
    CREATE INDEX IF NOT EXISTS idx_archives_year ON archives(year);
    CREATE INDEX IF NOT EXISTS idx_archives_st   ON archives(status);
    CREATE INDEX IF NOT EXISTS idx_archives_date ON archives(archive_date);

    CREATE TABLE IF NOT EXISTS files (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id   INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      original_name TEXT NOT NULL,
      stored_name  TEXT NOT NULL,
      rel_path     TEXT NOT NULL,
      mime         TEXT NOT NULL DEFAULT '',
      size         INTEGER NOT NULL DEFAULT 0,
      sha256       TEXT NOT NULL DEFAULT '',
      kind         TEXT NOT NULL DEFAULT '',        -- 正文 | 附件 | 扫描件
      sort_no      INTEGER NOT NULL DEFAULT 0,
      uploaded_by  INTEGER REFERENCES users(id),
      created_at   TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_files_archive ON files(archive_id);
    CREATE INDEX IF NOT EXISTS idx_files_sha ON files(sha256);

    CREATE TABLE IF NOT EXISTS loans (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      loan_no     TEXT NOT NULL UNIQUE,
      archive_id  INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      user_id     INTEGER NOT NULL REFERENCES users(id),
      purpose     TEXT NOT NULL DEFAULT '',
      mode        TEXT NOT NULL DEFAULT '借出',      -- 借出 | 查阅 | 复制
      status      TEXT NOT NULL DEFAULT '待审批',    -- 待审批 | 已批准 | 已拒绝 | 已归还 | 逾期
      apply_at    TEXT NOT NULL,
      approve_at  TEXT,
      approve_by  INTEGER REFERENCES users(id),
      approve_note TEXT NOT NULL DEFAULT '',
      due_date    TEXT NOT NULL DEFAULT '',
      return_at   TEXT,
      return_by   INTEGER REFERENCES users(id),
      return_note TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_loans_archive ON loans(archive_id);
    CREATE INDEX IF NOT EXISTS idx_loans_status ON loans(status);
    CREATE INDEX IF NOT EXISTS idx_loans_user ON loans(user_id);

    CREATE TABLE IF NOT EXISTS logs (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      at         TEXT NOT NULL,
      user_id    INTEGER,
      username   TEXT NOT NULL DEFAULT '',
      action     TEXT NOT NULL,
      target     TEXT NOT NULL DEFAULT '',
      detail     TEXT NOT NULL DEFAULT '',
      ip         TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_logs_at ON logs(at);
    CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id);

    -- 中文全文检索：trigram 分词（SQLite 内置，无需额外依赖）
    CREATE VIRTUAL TABLE IF NOT EXISTS archives_fts USING fts5(
      title, abstract, archive_code, keywords, responsible, department,
      content='archives', content_rowid='id', tokenize='trigram'
    );

    CREATE TRIGGER IF NOT EXISTS archives_ai AFTER INSERT ON archives BEGIN
      INSERT INTO archives_fts(rowid,title,abstract,archive_code,keywords,responsible,department)
      VALUES (new.id,new.title,new.abstract,new.archive_code,new.keywords,new.responsible,new.department);
    END;
    CREATE TRIGGER IF NOT EXISTS archives_ad AFTER DELETE ON archives BEGIN
      INSERT INTO archives_fts(archives_fts,rowid,title,abstract,archive_code,keywords,responsible,department)
      VALUES ('delete',old.id,old.title,old.abstract,old.archive_code,old.keywords,old.responsible,old.department);
    END;
    CREATE TRIGGER IF NOT EXISTS archives_au AFTER UPDATE ON archives BEGIN
      INSERT INTO archives_fts(archives_fts,rowid,title,abstract,archive_code,keywords,responsible,department)
      VALUES ('delete',old.id,old.title,old.abstract,old.archive_code,old.keywords,old.responsible,old.department);
      INSERT INTO archives_fts(rowid,title,abstract,archive_code,keywords,responsible,department)
      VALUES (new.id,new.title,new.abstract,new.archive_code,new.keywords,new.responsible,new.department);
    END;
  `);

  const row = db.prepare('SELECT value FROM meta WHERE key=?').get('schema_version');
  // 升级前的版本号：必须在任何迁移写入新版本号之前取到，否则「从几版升上来」就丢失了
  const prevVersion = row ? (Number(row.value) || 0) : 0;
  if (!row) {
    db.prepare('INSERT INTO meta(key,value) VALUES(?,?)').run('schema_version', String(SCHEMA_VERSION));
    db.prepare('INSERT INTO meta(key,value) VALUES(?,?)').run('installed_at', new Date().toISOString());
  }

  migrateToV2(db);
  migrateToV4(db, prevVersion);
  migrateToV5(db, prevVersion);
  migrateToV6(db, prevVersion);
  migrateToV7(db, prevVersion);
  migrateToV8(db, prevVersion);
  migrateToV9(db, prevVersion);
  migrateToV10(db, prevVersion);
  migrateToV11(db, prevVersion);
  migrateToV12(db, prevVersion);
  migrateToV13(db, prevVersion);
  migrateToV14(db, prevVersion);
  migrateToV15(db, prevVersion);
  migrateToV16(db, prevVersion);
  migrateToV17(db, prevVersion);
  migrateToV18(db, prevVersion);
  migrateToV20(db, prevVersion);
  migrateToV21(db, prevVersion);
  migrateToV22(db, prevVersion);
  migrateToV23(db, prevVersion);
  migrateToV24(db, prevVersion);
  migrateToV25(db, prevVersion);
  migrateToV26(db, prevVersion);
  migrateToV27(db, prevVersion);
  repairFtsIndex(db);
  repairFileTextFts(db);
}

/**
 * 附件正文索引自愈：核对索引行数与正文表行数，不一致时重建
 */
function repairFileTextFts(db) {
  try {
    const a = db.prepare('SELECT COUNT(*) AS c FROM file_text').get().c;
    const f = db.prepare('SELECT COUNT(*) AS c FROM file_text_fts').get().c;
    if (Number(a) !== Number(f)) {
      console.log(`[索引自检] 附件正文索引不一致（索引 ${f} / 正文 ${a}），正在重建…`);
      db.exec("INSERT INTO file_text_fts(file_text_fts) VALUES('rebuild')");
      console.log('[索引自检] 附件正文索引重建完成');
    }
  } catch (e) {
    console.warn('[索引自检] 附件正文索引跳过：' + e.message);
  }
}

/** 表是否存在 */
function tableExists(db, name) {
  return !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name);
}

/** 已有表的列清单 */
function columnNames(db, table) {
  try {
    return new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((r) => r.name));
  } catch (_) { return new Set(); }
}

/** 幂等加列：SQLite 不支持 ADD COLUMN IF NOT EXISTS，先查 table_info */
function addColumn(db, table, column, ddl) {
  if (!tableExists(db, table)) return false;
  if (columnNames(db, table).has(column)) return false;
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
  return true;
}

/**
 * 第 2 版数据模型：
 *  - 补齐著录规则要求的字段（档号结构、分类号、全宗号、保管期限代码等）
 *  - 保管期限到期计算与鉴定、销毁流程
 *  - 实体管理（库位、档案盒、条码）
 *  - 批量导入记录
 * 全部操作幂等，可在已有数据的库上安全重复执行。
 */
function migrateToV2(db) {
  // ---- 档案表：补齐著录字段与档号结构 ----
  const newArchiveCols = [
    ['archive_number', "TEXT NOT NULL DEFAULT ''"],   // 规范档号（全宗-分类-目录-案卷-件）
    ['unit_code', "TEXT NOT NULL DEFAULT ''"],        // 全宗号
    ['category_code', "TEXT NOT NULL DEFAULT ''"],    // 分类号
    ['catalog_no', "TEXT NOT NULL DEFAULT ''"],       // 目录号
    ['retention_code', "TEXT NOT NULL DEFAULT ''"],   // 保管期限代码 Y/D30/D10/D5/C
    ['retention_years', 'INTEGER NOT NULL DEFAULT 0'],// 定期年数，永久为 0
    ['retention_due_year', 'INTEGER NOT NULL DEFAULT 0'], // 到期（满期）年度
    ['open_state', "TEXT NOT NULL DEFAULT '未鉴定'"],  // 开放状态
    ['box_id', 'INTEGER'],
    ['electronic_flag', "TEXT NOT NULL DEFAULT '纸质'"],
    ['created_via', "TEXT NOT NULL DEFAULT '手工著录'"],
  ];
  for (const [c, ddl] of newArchiveCols) addColumn(db, 'archives', c, ddl);

  // ---- 门类：档号模板与保管期限代码 ----
  addColumn(db, 'archive_types', 'code_template', "TEXT NOT NULL DEFAULT ''");

  // ---- 借阅：自动归还与提醒 ----
  addColumn(db, 'loans', 'auto_return', 'INTEGER NOT NULL DEFAULT 0');
  addColumn(db, 'loans', 'returned_by_system', 'INTEGER NOT NULL DEFAULT 0');
  addColumn(db, 'loans', 'reminded_at', "TEXT NOT NULL DEFAULT ''");

  // ---- 新增表 ----
  db.exec(`
    CREATE TABLE IF NOT EXISTS locations (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      code      TEXT NOT NULL UNIQUE,          -- 库位编号，如 A库-A1-3
      name      TEXT NOT NULL,
      library   TEXT NOT NULL DEFAULT '',       -- 所属库房
      shelf     TEXT NOT NULL DEFAULT '',       -- 排/架
      layer     TEXT NOT NULL DEFAULT '',       -- 层
      capacity  INTEGER NOT NULL DEFAULT 0,     -- 可容纳盒数，0 表示不限
      remark    TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS archive_boxes (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      box_code    TEXT NOT NULL UNIQUE,         -- 档案盒号（与实体盒一一对应）
      title       TEXT NOT NULL DEFAULT '',
      type_code   TEXT NOT NULL DEFAULT '',
      year        TEXT NOT NULL DEFAULT '',
      location_id INTEGER REFERENCES locations(id) ON DELETE SET NULL,
      capacity    INTEGER NOT NULL DEFAULT 60,
      barcode     TEXT NOT NULL DEFAULT '',      -- 条码内容（默认取盒号）
      remark      TEXT NOT NULL DEFAULT '',
      created_by  INTEGER REFERENCES users(id),
      created_at  TEXT NOT NULL,
      updated_at  TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_boxes_location ON archive_boxes(location_id);
    CREATE INDEX IF NOT EXISTS idx_boxes_type ON archive_boxes(type_code);

    CREATE TABLE IF NOT EXISTS appraisals (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id    INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      decision      TEXT NOT NULL,               -- 延长保管期限 | 继续保管 | 建议销毁
      new_retention TEXT NOT NULL DEFAULT '',
      basis         TEXT NOT NULL DEFAULT '',     -- 鉴定依据/理由
      group_opinion TEXT NOT NULL DEFAULT '',     -- 鉴定小组意见
      member_count  INTEGER NOT NULL DEFAULT 0,
      appraiser_id  INTEGER REFERENCES users(id),
      appraiser     TEXT NOT NULL DEFAULT '',
      appraised_at  TEXT NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_appraisals_archive ON appraisals(archive_id);

    CREATE TABLE IF NOT EXISTS destructions (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_no       TEXT NOT NULL UNIQUE,        -- 销毁批次号
      title          TEXT NOT NULL DEFAULT '',
      archive_count  INTEGER NOT NULL DEFAULT 0,
      total_size     INTEGER NOT NULL DEFAULT 0,
      reason         TEXT NOT NULL DEFAULT '',
      basis          TEXT NOT NULL DEFAULT '',
      status         TEXT NOT NULL DEFAULT '待审批', -- 待审批 | 已批准 | 已拒绝 | 已销毁
      applicant_id   INTEGER REFERENCES users(id),
      applicant      TEXT NOT NULL DEFAULT '',
      applied_at     TEXT NOT NULL,
      approver_id    INTEGER REFERENCES users(id),
      approver       TEXT NOT NULL DEFAULT '',
      approved_at    TEXT,
      approve_note   TEXT NOT NULL DEFAULT '',
      supervisor     TEXT NOT NULL DEFAULT '',     -- 监销人
      witness        TEXT NOT NULL DEFAULT '',     -- 见证人
      destroyed_at   TEXT,
      destroy_note   TEXT NOT NULL DEFAULT '',
      created_at     TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_destructions_status ON destructions(status);

    CREATE TABLE IF NOT EXISTS destruction_items (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      destruction_id INTEGER NOT NULL REFERENCES destructions(id) ON DELETE CASCADE,
      archive_id    INTEGER NOT NULL,
      archive_code  TEXT NOT NULL DEFAULT '',
      archive_number TEXT NOT NULL DEFAULT '',
      title         TEXT NOT NULL DEFAULT '',
      type_code     TEXT NOT NULL DEFAULT '',
      year          TEXT NOT NULL DEFAULT '',
      retention     TEXT NOT NULL DEFAULT '',
      action        TEXT NOT NULL DEFAULT '待销毁',  -- 待销毁 | 已销毁 | 已移除
      remark        TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_ditems_batch ON destruction_items(destruction_id);
    CREATE INDEX IF NOT EXISTS idx_ditems_archive ON destruction_items(archive_id);

    CREATE TABLE IF NOT EXISTS stock_checks (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      check_no    TEXT NOT NULL UNIQUE,
      title       TEXT NOT NULL DEFAULT '',
      scope       TEXT NOT NULL DEFAULT '全库',
      status      TEXT NOT NULL DEFAULT '进行中',   -- 进行中 | 已完成
      checked     INTEGER NOT NULL DEFAULT 0,
      missing     INTEGER NOT NULL DEFAULT 0,
      mislocated  INTEGER NOT NULL DEFAULT 0,
      operator_id INTEGER REFERENCES users(id),
      operator    TEXT NOT NULL DEFAULT '',
      started_at  TEXT NOT NULL,
      finished_at TEXT,
      note        TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS stock_check_items (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      check_id     INTEGER NOT NULL REFERENCES stock_checks(id) ON DELETE CASCADE,
      archive_id   INTEGER NOT NULL,
      archive_code TEXT NOT NULL DEFAULT '',
      expect_location TEXT NOT NULL DEFAULT '',
      actual_location TEXT NOT NULL DEFAULT '',
      result       TEXT NOT NULL DEFAULT '待盘点',   -- 在架 | 缺失 | 位置不符 | 待盘点
      barcode      TEXT NOT NULL DEFAULT '',
      checked_at   TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_scitems_check ON stock_check_items(check_id);

    CREATE TABLE IF NOT EXISTS import_batches (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      filename    TEXT NOT NULL DEFAULT '',
      mode        TEXT NOT NULL DEFAULT '新增',
      total       INTEGER NOT NULL DEFAULT 0,
      succeeded   INTEGER NOT NULL DEFAULT 0,
      failed      INTEGER NOT NULL DEFAULT 0,
      errors      TEXT NOT NULL DEFAULT '[]',
      operator_id INTEGER REFERENCES users(id),
      operator    TEXT NOT NULL DEFAULT '',
      created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    );
  `);

  // ---- 设置项默认值 ----
  const defaults = {
    'archive.unit_code': 'Z001',
    'archive.unit_name': '本单位',
    'archive.code_template': '{unit}-{category}-{year}-{seq4}',
    'archive.catalog_no': '01',
    // 二维码相关：
    // qr.base_url    二维码里写死的网址前缀。留空＝自动探测本机局域网 IP。
    //                如果这台机器有多张网卡（虚拟网卡等）自动挑错了，就在这里手工填。
    // qr.mode        url＝二维码内容是可打开的网址（手机能扫出内容）；
    //                code＝二维码内容只是纯编号（老式扫码枪/离线标签机用）。
    // qr.scan_public 1＝手机扫码落地页免登录（否则手机没有 Cookie，扫了也打不开）。
    // qr.engine      每份档案二维码用哪个引擎生成：
    //                auto＝有 Python + qrcode 就用它，没有自动退回内置引擎（默认）
    //                python＝强制用 Python 的 qrcode 库
    //                builtin＝只用系统内置引擎（不需要 Python）
    // qr.border      静区（留白）模块数。QR 规范最低要求 4；调到 6 更保险，
    //                适合贴在花哨背景或容易被裁掉白边的情况。
    // qr.box_size    每个模块的像素边长（对应 Python 版的 box_size）。
    //                调大只是让图片更清晰、文件更大，不会改变二维码内容。
    // qr.archive_mode 档案二维码里写什么：
    //                url ＝ 公网网址（默认）。扫码打开落地页，落地页第一行大字显示档案号，
    //                      下面给可点链接进档案详情 —— 这是唯一能让链接真正可点的做法。
    //                both＝ 档案号 + 换行 + 网址。字面上「先看到编号」，
    //                      但微信等扫码器对非纯网址内容只当文本显示，链接点不动。
    //                code＝ 只写档案号，给老式扫码枪/离线标签机用。
    // qr.sign_key    落地页的签名密钥（首次使用自动生成）。
    //                落地页是公网可访问的，而档案号是连续可枚举的；
    //                有了这个密钥，只有系统自己生成的二维码能打开落地页。
    'qr.base_url': '',
    'qr.mode': 'url',
    'qr.scan_public': '1',
    'qr.engine': 'auto',
    'qr.border': '6',
    'qr.box_size': '15',
    'qr.archive_mode': 'url',
    'qr.sign_key': '',
    'loans.auto_return': '1',
    'loans.remind_days': '3',
    'appraisal.warn_years': '1',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  // ---- 索引 ----
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_archives_number ON archives(archive_number) WHERE archive_number <> ''");
  db.exec('CREATE INDEX IF NOT EXISTS idx_archives_due ON archives(retention_due_year)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_archives_box ON archives(box_id)');

  // ---- 附件正文与全文索引 ----
  db.exec(`
    CREATE TABLE IF NOT EXISTS file_text (
      file_id      INTEGER PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
      archive_id   INTEGER NOT NULL,
      content      TEXT NOT NULL DEFAULT '',
      char_count   INTEGER NOT NULL DEFAULT 0,
      status       TEXT NOT NULL DEFAULT '成功',
      kind         TEXT NOT NULL DEFAULT '',
      reason       TEXT NOT NULL DEFAULT '',
      extracted_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_filetext_archive ON file_text(archive_id);
    CREATE INDEX IF NOT EXISTS idx_filetext_status ON file_text(status);

    CREATE VIRTUAL TABLE IF NOT EXISTS file_text_fts USING fts5(
      content, content='file_text', content_rowid='file_id', tokenize='trigram'
    );
    CREATE TRIGGER IF NOT EXISTS file_text_ai AFTER INSERT ON file_text BEGIN
      INSERT INTO file_text_fts(rowid, content) VALUES (new.file_id, new.content);
    END;
    CREATE TRIGGER IF NOT EXISTS file_text_ad AFTER DELETE ON file_text BEGIN
      INSERT INTO file_text_fts(file_text_fts, rowid, content) VALUES ('delete', old.file_id, old.content);
    END;
    CREATE TRIGGER IF NOT EXISTS file_text_au AFTER UPDATE ON file_text BEGIN
      INSERT INTO file_text_fts(file_text_fts, rowid, content) VALUES ('delete', old.file_id, old.content);
      INSERT INTO file_text_fts(rowid, content) VALUES (new.file_id, new.content);
    END;
  `);

  // ---- 档案移交 ----
  db.exec(`
    CREATE TABLE IF NOT EXISTS transfers (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      transfer_no   TEXT NOT NULL UNIQUE,
      title         TEXT NOT NULL DEFAULT '',
      direction     TEXT NOT NULL DEFAULT '移交进馆',
      target_unit   TEXT NOT NULL DEFAULT '',
      source_unit   TEXT NOT NULL DEFAULT '',
      contact       TEXT NOT NULL DEFAULT '',
      phone         TEXT NOT NULL DEFAULT '',
      basis         TEXT NOT NULL DEFAULT '',
      carrier       TEXT NOT NULL DEFAULT '纸质+电子',
      archive_count INTEGER NOT NULL DEFAULT 0,
      total_pages   INTEGER NOT NULL DEFAULT 0,
      status        TEXT NOT NULL DEFAULT '待提交',
      applicant_id  INTEGER REFERENCES users(id),
      applicant     TEXT NOT NULL DEFAULT '',
      applied_at    TEXT NOT NULL,
      submitted_at  TEXT,
      accepted_at   TEXT,
      acceptor      TEXT NOT NULL DEFAULT '',
      accept_note   TEXT NOT NULL DEFAULT '',
      reject_reason TEXT NOT NULL DEFAULT '',
      remark        TEXT NOT NULL DEFAULT '',
      created_at    TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_transfers_status ON transfers(status);

    CREATE TABLE IF NOT EXISTS transfer_items (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      transfer_id    INTEGER NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
      archive_id     INTEGER NOT NULL,
      archive_code   TEXT NOT NULL DEFAULT '',
      archive_number TEXT NOT NULL DEFAULT '',
      title          TEXT NOT NULL DEFAULT '',
      type_code      TEXT NOT NULL DEFAULT '',
      year           TEXT NOT NULL DEFAULT '',
      retention      TEXT NOT NULL DEFAULT '',
      pages          TEXT NOT NULL DEFAULT '',
      location       TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_titems_transfer ON transfer_items(transfer_id);
    CREATE INDEX IF NOT EXISTS idx_titems_archive ON transfer_items(archive_id);
  `);

  // ---- 存量数据规范化（必须在回填之前）----
  normalizeRetention(db);

  // ---- 存量数据回填 ----
  backfillArchiveNumbers(db);

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
}

/**
 * 第 4 版数据模型：安全与合规基线
 *
 *  - **用户密级上限** `users.clearance`：约束该账号可见的最高密级（最小权限原则）。
 *    刻意留空字符串 = 「按角色默认」，由 lib/policy.js 的 defaultClearance() 决定：
 *    管理员/系统管理员/安全保密员=机密，档案员=秘密，普通用户=内部，安全审计员=公开。
 *    这样存量账号升级后**立刻按岗位获得合理上限**，而不是一律放行。
 *  - **安全设置项**：密级管控开关、三员分立开关、登录失败锁定、密码长度、日志保留期。
 *
 * 依据：
 *   - 《电子档案管理系统基本功能规定》（档办发〔2017〕3号）第四十一条：三员分立，
 *     并"按照功能和数据进行授权"（数据授权 = 本版的密级上限）。
 *   - GB/T 18894—2016 §5.2.4 / §5.4；DA/T 92—2022 §9.1.3。
 *
 * 全部操作幂等，可在已有数据的库上安全重复执行。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV4(db, fromVersion = 0) {
  // ---- 用户：密级上限 ----
  const addedClearance = addColumn(db, 'users', 'clearance', "TEXT NOT NULL DEFAULT ''");

  // ---- 安全设置项 ----
  const securityDefaults = {
    // 1 = 启用密级管控（按 users.clearance 过滤可见档案）；0 = 关闭，退回旧行为
    'security.enforce_secret': '1',
    // 1 = 启用三员分立校验（同一账号不得兼任三员中的多个）；0 = 只提供角色、不做强制校验
    // 默认 0：既有单管理员部署不会因为升级而无法使用；由管理员在界面上一键启用
    'security.three_roles': '0',
    // 登录失败锁定：连续失败达到该次数即锁定账号（0 = 不锁定）
    'security.login_max_fail': '5',
    // 锁定时长（分钟）
    'security.login_lock_minutes': '15',
    // 密码最小长度
    'security.password_min_length': '8',
    // 审计日志保留天数（0 = 永久保留）
    'security.log_retain_days': '0',
  };
  for (const [k, v] of Object.entries(securityDefaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (addedClearance) {
    console.log('[升级 v4] 用户表已增加「密级上限」字段；存量账号按角色默认'
      + '（管理员/系统管理员/安全保密员=机密，档案员=秘密，普通用户=内部，安全审计员=公开）');
  }
  if (fromVersion > 0 && fromVersion < 4) {
    console.log('[升级 v4] 已启用密级访问控制：档案是否可见，不再只由角色决定，还受账号密级上限约束');
  }
}

/**
 * 第 5 版数据模型：档案实体（装盒）合规
 *
 *  - 档案盒增加 `retention`（保管期限）与 `org_code`（机构/问题代码）两个**显式属性**，
 *    并按盒内现有档案回填，使存量数据也能参与校验。
 *
 *  依据 DA/T 22—2015 §6.4：**不同年度、机构(问题)、保管期限的归档文件不能装入同一盒**
 *  （盒脊上要标全宗号、年度、保管期限、起止件号、盒号，混装会让盒脊标注失去意义）。
 *
 *  v3.4.7 的装盒接口只做 `UPDATE archives SET box_id=?`，没有任何一致性校验，
 *  因此「盒脊写 2025 年度/永久、盒内混着 2026 年定期件」这类问题在系统里根本发现不了，
 *  排架、盘点和上级检查时都是硬伤。
 *
 *  - 新增开关 `box.enforce_mix`（默认 1 = 强制拒绝混装）。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV5(db, fromVersion = 0) {
  const addedRetention = addColumn(db, 'archive_boxes', 'retention', "TEXT NOT NULL DEFAULT ''");
  const addedOrg = addColumn(db, 'archive_boxes', 'org_code', "TEXT NOT NULL DEFAULT ''");
  db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run('box.enforce_mix', '1');

  // 用盒内现有档案回填盒属性：只补空值，不覆盖人工填过的内容
  try {
    db.exec(`UPDATE archive_boxes SET
        retention = CASE WHEN retention = '' THEN COALESCE((SELECT a.retention FROM archives a
          WHERE a.box_id = archive_boxes.id ORDER BY a.id LIMIT 1), retention) ELSE retention END,
        org_code  = CASE WHEN org_code = '' THEN COALESCE((SELECT a.category_code FROM archives a
          WHERE a.box_id = archive_boxes.id ORDER BY a.id LIMIT 1), org_code) ELSE org_code END,
        year      = CASE WHEN year = '' THEN COALESCE((SELECT a.year FROM archives a
          WHERE a.box_id = archive_boxes.id ORDER BY a.id LIMIT 1), year) ELSE year END,
        type_code = CASE WHEN type_code = '' THEN COALESCE((SELECT a.type_code FROM archives a
          WHERE a.box_id = archive_boxes.id ORDER BY a.id LIMIT 1), type_code) ELSE type_code END
      WHERE EXISTS (SELECT 1 FROM archives a WHERE a.box_id = archive_boxes.id)`);
  } catch (e) {
    console.warn('[升级 v5] 档案盒属性回填跳过（不影响使用）：' + e.message);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (addedRetention || addedOrg) {
    console.log('[升级 v5] 档案盒已增加「保管期限」「机构(问题)代码」属性，并按盒内现有档案回填');
  }
  if (fromVersion > 0 && fromVersion < 5) {
    console.log('[升级 v5] 已启用装盒一致性校验：不同年度/机构(问题)/保管期限不得同盒（DA/T 22—2015 §6.4）');
  }
}

/**
 * 第 6 版数据模型：审计跟踪（防篡改）
 *
 *  - `logs` 表增加 `step`（行为步骤）、`result`（成功/失败）、`category`（日志分类）、
 *    `prev_hash` / `hash`（哈希链）。
 *
 *  依据 DA/T 92—2022 §9.5：审计跟踪应记录**行为描述、行为步骤、行为对象、行为日期、
 *  行为人员**，保存时间不应低于电子档案保管期限，并纳入备份与恢复范围。
 *  另据《电子档案管理系统基本功能规定》（档办发〔2017〕3号）第四十二/四十三条：
 *  日志及分类管理；审计跟踪需覆盖关键业务过程、管理操作行为与**非系统授权访问**。
 *
 *  哈希链的意义：只有"能发现被改过"的日志才具备证据价值。
 *  每条记录前一条的哈希，改动/删除/插入任何历史记录都会让链在该处断开，
 *  `/api/logs/verify` 会精确报出断点。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV6(db, fromVersion = 0) {
  const added = [
    addColumn(db, 'logs', 'step', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'logs', 'result', "TEXT NOT NULL DEFAULT '成功'"),
    addColumn(db, 'logs', 'category', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'logs', 'prev_hash', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'logs', 'hash', "TEXT NOT NULL DEFAULT ''"),
  ].some(Boolean);

  db.exec('CREATE INDEX IF NOT EXISTS idx_logs_category ON logs(category)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_logs_action ON logs(action)');

  // 存量日志回填哈希链。
  // 关键点：**要么全链重算，要么一条都不动**。只补空白行会让链在新旧交界处断开，
  // 校验时会报出一个并不存在的"篡改点"，反而制造假警报、让真正的篡改被淹没。
  let backfilled = 0;
  try {
    const missing = Number(db.prepare("SELECT COUNT(*) AS c FROM logs WHERE hash='' OR hash IS NULL").get().c) || 0;
    if (missing > 0) {
      const rows = db.prepare('SELECT * FROM logs ORDER BY id').all();
      let prev = audit.GENESIS;
      const upd = db.prepare('UPDATE logs SET step=?, result=?, category=?, prev_hash=?, hash=? WHERE id=?');
      db.exec('BEGIN');
      try {
        for (const r of rows) {
          const rec = {
            at: r.at,
            user_id: r.user_id,
            username: r.username,
            action: r.action,
            target: r.target,
            detail: r.detail,
            ip: r.ip,
            step: r.step || '',
            result: r.result || '成功',
            category: r.category || audit.categoryOf(r.action),
            prev_hash: prev,
          };
          const hash = audit.hashRecord(rec);
          upd.run(rec.step, rec.result, rec.category, prev, hash, r.id);
          prev = hash;
        }
        db.exec('COMMIT');
        backfilled = rows.length;
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    }
  } catch (e) {
    console.warn('[升级 v6] 审计日志哈希链回填失败（不影响启动）：' + e.message);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (added) console.log('[升级 v6] 审计日志已增加「行为步骤/结果/分类/哈希链」字段');
  if (backfilled) console.log(`[升级 v6] 已为 ${backfilled} 条存量审计日志建立哈希链（全链重算，避免新旧交界处误报）`);
  if (fromVersion > 0 && fromVersion < 6) {
    console.log('[升级 v6] 已启用审计日志防篡改：任何对历史日志的修改/删除都会在 /api/logs/verify 处暴露');
  }
}

/**
 * 第 7 版数据模型：登录防护与口令策略
 *
 *  - `users` 增加 `locked_until`（锁定截止时间）、`failed_count`（连续失败次数）、
 *    `last_failed_at`（最近一次失败时间）。
 *  - 新增 `login_attempts` 表：逐次记录登录尝试（成功/失败、来源 IP、原因），
 *    既用于按 IP 限流，也是"登录失败处理"的取证依据。
 *  - 新增口令与限流相关设置项。
 *
 *  依据 GB/T 18894—2016 §5.2.4（身份鉴别）、《电子档案管理系统基本功能规定》
 *  （档办发〔2017〕3号）第三十八条（用户口令管理）、等保 2.0 登录失败处理要求。
 *
 * 说明：**连续失败次数用列存，不靠 count(login_attempts) 现算** ——
 * 后者会被"清理历史尝试记录"影响，导致锁定计数凭空归零。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV7(db, fromVersion = 0) {
  const added = [
    addColumn(db, 'users', 'locked_until', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'users', 'failed_count', 'INTEGER NOT NULL DEFAULT 0'),
    addColumn(db, 'users', 'last_failed_at', "TEXT NOT NULL DEFAULT ''"),
  ].some(Boolean);

  db.exec(`
    CREATE TABLE IF NOT EXISTS login_attempts (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      at       TEXT NOT NULL,
      username TEXT NOT NULL DEFAULT '',
      ip       TEXT NOT NULL DEFAULT '',
      success  INTEGER NOT NULL DEFAULT 0,
      reason   TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_login_at   ON login_attempts(at);
    CREATE INDEX IF NOT EXISTS idx_login_ip   ON login_attempts(ip, at);
    CREATE INDEX IF NOT EXISTS idx_login_user ON login_attempts(username, at);
  `);

  const defaults = {
    // 同一 IP 每分钟允许的登录尝试次数（0 = 不限流）
    'security.login_rate_per_minute': '20',
    // 1 = 口令需包含大写/小写/数字/符号中的至少三类
    'security.password_require_complexity': '0',
    // 登录尝试记录的保留天数（0 = 永久）
    'security.login_attempts_keep_days': '30',
    // 1 = 带 Cookie 的写操作校验 Origin/Referer（CSRF 纵深防御）
    'security.csrf_origin_check': '1',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (added) console.log('[升级 v7] 用户表已增加「锁定截止时间/连续失败次数/最近失败时间」字段');
  if (fromVersion > 0 && fromVersion < 7) {
    console.log('[升级 v7] 已启用登录防护：连续失败锁定、按 IP 限流、口令强度策略、Origin 校验');
  }
}

/**
 * 第 8 版数据模型：四性检测
 *
 *  - `detections`：一次检测的批次（环境、范围、结论、逐项统计、操作者、来源）。
 *  - `detection_items`：该次检测的逐项结果（检查项编号、四性维度、严重程度、
 *    通过与否、依据、说明）—— 报告、追溯与"责任人确认"都靠它。
 *
 *  依据：
 *   - DA/T 70—2018《文书类电子档案检测一般要求》：按**归档 / 移交与接收 / 长期保存**
 *     三个管理环节分别规定真实性、完整性、可用性、安全性检测（§4 检测内容、§5 检测方案、
 *     §6 检测项目汇总、附录 A 规范性对照表）。
 *   - DA/T 92—2022 §9.4：归档环节与移交接收环节应检测；**归档后每年至少 1 次**。
 *   - 《电子档案管理办法》（国家档案局令第22号）第十八条/第二十一条/第二十二条/第二十八条：
 *     归档前、移交前、接收时、转换迁移后均应检测，**合格后方可**办理，并由责任人确认。
 *
 *  把检测结果**落库**而不是只打印一下，是因为标准要求"检测合格后方可移交/接收"，
 *  必须有可追溯的凭据；否则"检测过"这件事本身无法举证。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV8(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS detections (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      detection_no TEXT NOT NULL UNIQUE,
      environment  TEXT NOT NULL DEFAULT 'archive',  -- archive | transfer | preservation
      archive_id   INTEGER,
      scope        TEXT NOT NULL DEFAULT '单件',      -- 单件 | 批量
      total        INTEGER NOT NULL DEFAULT 0,
      passed       INTEGER NOT NULL DEFAULT 0,
      failed       INTEGER NOT NULL DEFAULT 0,
      errors       INTEGER NOT NULL DEFAULT 0,       -- 不合格项（影响合格结论）
      warns        INTEGER NOT NULL DEFAULT 0,       -- 提示项（不影响合格结论）
      qualified    INTEGER NOT NULL DEFAULT 0,
      conclusion   TEXT NOT NULL DEFAULT '',
      source       TEXT NOT NULL DEFAULT '手工',      -- 手工 | 归档上传 | 移交前 | 接收时 | 定期
      operator_id  INTEGER,
      operator     TEXT NOT NULL DEFAULT '',
      created_at   TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_detections_archive ON detections(archive_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_detections_env ON detections(environment, created_at);

    CREATE TABLE IF NOT EXISTS detection_items (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      detection_id INTEGER NOT NULL REFERENCES detections(id) ON DELETE CASCADE,
      code         TEXT NOT NULL,
      dimension    TEXT NOT NULL,
      severity     TEXT NOT NULL DEFAULT 'error',
      title        TEXT NOT NULL,
      basis        TEXT NOT NULL DEFAULT '',
      pass         INTEGER NOT NULL DEFAULT 0,
      detail       TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_detection_items ON detection_items(detection_id);
  `);

  const defaults = {
    // 1 = 移交提交前要求每件档案都有通过的归档环节检测记录（《电子档案管理办法》第二十一条）
    'detection.enforce_transfer': '1',
    // 1 = 上传附件后自动跑一次归档环节检测（把"检测"嵌进日常流程，而不是靠人记得点）
    'detection.auto_on_upload': '1',
    // 长期保存环节"至少每年 1 次"的天数阈值（DA/T 92—2022 §9.4.1）
    'detection.yearly_days': '365',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 8) {
    console.log('[升级 v8] 已启用四性检测：归档/移交接收/长期保存三个环节 × 真实性/完整性/可用性/安全性');
  }
}

/**
 * 第 9 版数据模型：元数据方案（DA/T 46）
 *
 *  - `archive_metadata`：每件档案的元数据值（按元素编号存一行）。
 *  - `metadata_changes`：元数据变更留痕，**包括被拒绝的修改尝试** ——
 *    "禁止修改背景/结构/管理过程元数据"这条要求，只有留下拦截记录才算真正落实。
 *
 *  依据：
 *   - DA/T 46—2009《文书类电子文件元数据方案》。
 *   - DA/T 92—2022 §8.1.1：按 DA/T 46 定义元数据项，约束性为"必选"的为必备项。
 *   - 《数字档案室建设指南》§5.1.2 元数据实体模型（文件/机构人员/业务实体）、
 *     §5.3.4 文书类至少 20 项元数据；**禁止修改背景、结构、管理过程元数据**。
 *   - GB/T 18894—2016 §6.2；《电子档案管理办法》第十六条（元数据随文件一并归档）。
 *
 *  为什么元数据要独立成表，而不是直接用 archives 的列：
 *   同一条元数据要能回答"属于哪个实体、是否必备、是自动捕获还是手工著录、
 *   归档后还能不能改、依据哪条标准"。这些是**方案（scheme）**层面的属性，
 *   塞进业务表的列里就没地方表达了。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV9(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS archive_metadata (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id   INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      element_code TEXT NOT NULL,
      entity       TEXT NOT NULL DEFAULT 'file',
      value        TEXT NOT NULL DEFAULT '',
      source       TEXT NOT NULL DEFAULT '自动捕获',   -- 自动捕获 | 手工著录
      captured_at  TEXT NOT NULL DEFAULT '',
      updated_at   TEXT NOT NULL DEFAULT '',
      updated_by   INTEGER,
      UNIQUE(archive_id, element_code)
    );
    CREATE INDEX IF NOT EXISTS idx_armeta_archive ON archive_metadata(archive_id);
    CREATE INDEX IF NOT EXISTS idx_armeta_element ON archive_metadata(element_code);

    CREATE TABLE IF NOT EXISTS metadata_changes (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id   INTEGER,
      element_code TEXT NOT NULL,
      old_value    TEXT NOT NULL DEFAULT '',
      new_value    TEXT NOT NULL DEFAULT '',
      action       TEXT NOT NULL DEFAULT '修改',        -- 修改 | 拒绝修改 | 自动捕获
      reason       TEXT NOT NULL DEFAULT '',
      operator_id  INTEGER,
      operator     TEXT NOT NULL DEFAULT '',
      at           TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_metachg_archive ON metadata_changes(archive_id, at);
    CREATE INDEX IF NOT EXISTS idx_metachg_element ON metadata_changes(element_code, at);
  `);

  const defaults = {
    // 1 = 元数据必选项不全时在界面上给出提示（不阻断著录，因为存量数据需要时间补齐）
    'metadata.warn_incomplete': '1',
    // 1 = 禁止手工修改背景/结构/管理过程元数据（标准要求，不建议关闭）
    'metadata.enforce_immutable': '1',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 9) {
    console.log('[升级 v9] 已启用元数据方案：文件/机构人员/业务三实体共 20 项（DA/T 46、数字档案室建设指南 §5.3.4）');
  }
}

/**
 * 第 10 版数据模型：归档章与备考表
 *
 *  依据 **DA/T 22—2015《归档文件整理规则》**：
 *   - §6.4 档案盒尺寸 310mm×220mm，**盒脊厚度 20/30/40/50mm**；
 *     盒脊与底边必备项：全宗号、年度、保管期限、起止件号、盒号。
 *   - §6.5 **备考表**五项：盒内文件情况说明、整理人、整理日期、检查人、检查日期；
 *     备考表置于盒内文件之后。
 *   - §5.4.4/§5.4.5 归档章必备项：全宗号、年度、保管期限、件号、页数（机构(问题)为选择项）。
 *
 *  归档章不入库：它的值全部由档案行推导（见 lib/archive-stamp.js），存一份只会带来不一致。
 *  备考表必须入库：整理人/检查人/日期是**人的签署行为**，系统无从推导。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV10(db, fromVersion = 0) {
  const added = [
    addColumn(db, 'archive_boxes', 'preparer', "TEXT NOT NULL DEFAULT ''"),       // 整理人
    addColumn(db, 'archive_boxes', 'prepared_at', "TEXT NOT NULL DEFAULT ''"),    // 整理日期
    addColumn(db, 'archive_boxes', 'checker', "TEXT NOT NULL DEFAULT ''"),        // 检查人
    addColumn(db, 'archive_boxes', 'checked_at', "TEXT NOT NULL DEFAULT ''"),     // 检查日期
    addColumn(db, 'archive_boxes', 'inventory_note', "TEXT NOT NULL DEFAULT ''"), // 盒内文件情况说明
    addColumn(db, 'archive_boxes', 'spine_mm', 'INTEGER NOT NULL DEFAULT 30'),    // 盒脊厚度（mm）
  ].some(Boolean);

  const defaults = {
    // 盒脊厚度默认值。标准只允许 20/30/40/50，其它值会让实体盒装不进档案柜。
    'box.spine_mm_default': '30',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  // 存量盒的盒脊厚度兜底为合法值（旧数据该列默认 30，这里只防脏数据）
  try {
    db.exec('UPDATE archive_boxes SET spine_mm=30 WHERE spine_mm NOT IN (20,30,40,50)');
  } catch (_) { /* 忽略 */ }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (added) console.log('[升级 v10] 档案盒已增加备考表字段（整理人/整理日期/检查人/检查日期/情况说明）与盒脊厚度');
  if (fromVersion > 0 && fromVersion < 10) {
    console.log('[升级 v10] 已启用归档章与备考表：归档章六项按 DA/T 22—2015 §5.4.4 自动生成');
  }
}

/**
 * 第 11 版数据模型：借阅强化（授权阅读时间、下载审批、水印备案）
 *
 *  依据 **《数字档案室建设指南》§4.4.2 借阅利用**：在线查看/打印目录或原文；
 *  **限制可阅读范围（到组件或具体页面）**；**数字水印**；**授权阅读时间**；
 *  按岗位/职责设置利用权限。另据 GB/T 18894—2016 §9.3（利用登记）。
 *
 *  - `loans` 增加 `read_from` / `read_to`（**授权阅读时间窗**）与 `watermark_text`。
 *  - 新增 `download_grants`：**下载审批**凭据（申请人、用途、审批人、有效期、次数上限、
 *    页数范围、水印文字、已用次数）。为什么单独建表而不挂在 loans 上：
 *      借阅的客体是"这件档案"，下载的客体可能是"某个附件、某几页"，生命周期也不同
 *      （借阅按应还日期，下载按凭据有效期与次数），挂在一起会让两者互相牵制。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV11(db, fromVersion = 0) {
  const added = [
    addColumn(db, 'loans', 'read_from', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'loans', 'read_to', "TEXT NOT NULL DEFAULT ''"),
    addColumn(db, 'loans', 'watermark_text', "TEXT NOT NULL DEFAULT ''"),
  ].some(Boolean);

  db.exec(`
    CREATE TABLE IF NOT EXISTS download_grants (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      grant_no       TEXT NOT NULL UNIQUE,
      archive_id     INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      file_id        INTEGER,
      user_id        INTEGER NOT NULL,
      applicant      TEXT NOT NULL DEFAULT '',
      purpose        TEXT NOT NULL DEFAULT '',
      status         TEXT NOT NULL DEFAULT '待审批',   -- 待审批 | 已批准 | 已拒绝 | 已用尽 | 已过期
      apply_at       TEXT NOT NULL,
      approve_by     INTEGER,
      approve_at     TEXT NOT NULL DEFAULT '',
      approve_note   TEXT NOT NULL DEFAULT '',
      read_from      TEXT NOT NULL DEFAULT '',
      read_to        TEXT NOT NULL DEFAULT '',
      max_times      INTEGER NOT NULL DEFAULT 1,
      used_times     INTEGER NOT NULL DEFAULT 0,
      page_from      INTEGER NOT NULL DEFAULT 0,       -- 0 表示不限制
      page_to        INTEGER NOT NULL DEFAULT 0,
      watermark_text TEXT NOT NULL DEFAULT '',
      last_used_at   TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_dg_archive ON download_grants(archive_id);
    CREATE INDEX IF NOT EXISTS idx_dg_user ON download_grants(user_id, status);
  `);

  const defaults = {
    // 1 = 普通用户下载需审批（档案员及以上作为审批方，下载直接放行并留痕）
    // **默认 0**：开启后普通用户连自己密级范围内的附件都下载不了，
    // 对小单位档案室是过重的默认值。能力齐备、由单位按制度开启。
    'download.require_approval': '0',
    // 凭据默认有效期（小时）
    'download.default_valid_hours': '24',
    // 凭据默认可用次数
    'download.max_times_default': '1',
    // 借阅默认授权阅读时长（小时）
    'loan.default_read_hours': '8',
    // 1 = 普通用户在线阅读须处于借阅/下载授权的**授权阅读时间窗**内（默认关，避免影响既有单位）
    'loan.enforce_read_window': '0',
    // 水印开关与模板（占位符见 lib/watermark.js）
    'watermark.enabled': '1',
    'watermark.template': '{unit}　{username}　{at}　凭据 {grantNo}',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (added) console.log('[升级 v11] 借阅记录已增加「授权阅读时间窗」与「水印文字」字段');
  if (fromVersion > 0 && fromVersion < 11) {
    console.log('[升级 v11] 已启用下载审批、授权阅读时间与利用水印（数字档案室建设指南 §4.4.2）');
  }
}

/**
 * 第 12 版数据模型：备份合规与存储状况监控
 *
 *  依据：
 *   - **《电子档案管理办法》（国家档案局令第22号）第二十六条**：
 *     应当在磁介质、光介质、缩微胶片等介质中选择**至少两种**符合长期安全管理要求的存储介质，
 *     以在线方式和离线方式保存**至少三套完整数据**（每种介质上保存一套完整数据，
 *     **一套在线应用，两套备份**）；应当制定检测策略，**定期对电子档案可读状况、
 *     所处软硬件环境、存储介质完好程度等保管情况进行检测**，发现问题及时处理。
 *   - 同法**第二十七条**：应当对重要电子档案进行**异地备份**。
 *   - 《电子档案管理系统基本功能规定》（档办发〔2017〕3号）第二十一至二十四条：
 *     备份与恢复（策略、制作、登记/检测/管理、恢复过程记录）；
 *     **存储状况监控与警告**（介质不稳定、空间不足、非授权访问、系统响应超时）。
 *   - DA/T 92—2022 §9.2：离线/近线/在线中至少两种 + 异质异地。
 *
 *  三张表各司其职：
 *    `backup_media`   介质台账（这台移动硬盘、那张光盘在哪、多大、状不状）
 *    `backups`        备份实例登记（哪一次、多大、摘要多少、链是否完整、校验过没有）
 *    `storage_checks` 保管状况检测记录（空间、数据库完整性、抽样可读性、介质状况）
 *
 *  为什么"备份"要建表和登记：只有**登记在案**的备份才能被核查"够不够三套、有没有离线"。
 *  光有文件躺在盘上，谁也说不清到底备份了几份、在哪。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV12(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS backup_media (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      medium_no       TEXT NOT NULL UNIQUE,
      type            TEXT NOT NULL DEFAULT '磁盘',    -- 磁盘 | 移动硬盘 | 光盘 | 缩微胶片 | 网络位置 | 其他
      location        TEXT NOT NULL DEFAULT '在线',    -- 在线 | 同城离线 | 异地
      label           TEXT NOT NULL DEFAULT '',
      capacity_bytes  INTEGER NOT NULL DEFAULT 0,
      used_bytes      INTEGER NOT NULL DEFAULT 0,
      condition       TEXT NOT NULL DEFAULT '良好',    -- 良好 | 需关注 | 不可用
      last_checked_at TEXT NOT NULL DEFAULT '',
      note            TEXT NOT NULL DEFAULT '',
      created_by      INTEGER,
      created_at      TEXT NOT NULL,
      updated_at      TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS backups (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      backup_no       TEXT NOT NULL UNIQUE,
      kind            TEXT NOT NULL DEFAULT '全量',     -- 全量 | 增量（当前实现为全量）
      target_type     TEXT NOT NULL DEFAULT '在线',     -- 在线 | 离线 | 异地
      medium_id       INTEGER REFERENCES backup_media(id) ON DELETE SET NULL,
      medium_no       TEXT NOT NULL DEFAULT '',
      dest_path       TEXT NOT NULL DEFAULT '',
      file_name       TEXT NOT NULL DEFAULT '',
      size_bytes      INTEGER NOT NULL DEFAULT 0,
      sha256          TEXT NOT NULL DEFAULT '',
      archives_count  INTEGER NOT NULL DEFAULT 0,
      files_count     INTEGER NOT NULL DEFAULT 0,
      logs_count      INTEGER NOT NULL DEFAULT 0,
      chain_ok        INTEGER NOT NULL DEFAULT 0,       -- 制作时的审计链校验结论
      restore_tested  INTEGER NOT NULL DEFAULT 0,       -- 是否做过恢复演练
      verify_at       TEXT NOT NULL DEFAULT '',
      verify_result   TEXT NOT NULL DEFAULT '',
      note            TEXT NOT NULL DEFAULT '',
      created_by      INTEGER,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_backups_target ON backups(target_type, created_at);

    CREATE TABLE IF NOT EXISTS storage_checks (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      check_no      TEXT NOT NULL UNIQUE,
      total_bytes   INTEGER NOT NULL DEFAULT 0,
      free_bytes    INTEGER NOT NULL DEFAULT 0,
      db_bytes      INTEGER NOT NULL DEFAULT 0,
      files_bytes   INTEGER NOT NULL DEFAULT 0,
      db_integrity  INTEGER NOT NULL DEFAULT 0,      -- PRAGMA integrity_check 是否通过
      chain_ok      INTEGER NOT NULL DEFAULT 0,      -- 审计日志链是否完整
      fixity_ok     INTEGER NOT NULL DEFAULT 1,      -- 抽样摘要校验是否通过
      fixity_checked INTEGER NOT NULL DEFAULT 0,     -- 抽样件数
      fixity_failed INTEGER NOT NULL DEFAULT 0,
      media_total   INTEGER NOT NULL DEFAULT 0,
      media_bad     INTEGER NOT NULL DEFAULT 0,
      warning_count INTEGER NOT NULL DEFAULT 0,
      warnings      TEXT NOT NULL DEFAULT '[]',
      conclusion    TEXT NOT NULL DEFAULT '',
      operator_id   INTEGER,
      operator      TEXT NOT NULL DEFAULT '',
      created_at    TEXT NOT NULL
    );
  `);

  const defaults = {
    // 合规要求：至少三套完整数据、至少两种介质、至少一套离线、重要档案异地备份
    'backup.required_copies': '3',
    'backup.required_media_types': '2',
    'backup.require_offline': '1',
    'backup.require_offsite': '0',
    // 保管状况检测周期（天）与空间告警阈值（剩余占比 %）
    'storage.check_interval_days': '30',
    'storage.warn_free_ratio': '10',
    // 抽样可读性校验每次抽查的附件件数
    'storage.fixity_sample': '20',
    // 备份默认输出目录（相对数据目录）
    'backup.default_dir': 'backups',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 12) {
    console.log('[升级 v12] 已启用备份合规与存储状况监控：备份/介质登记、三套两介质体检、定期保管状况检测');
  }
}

/**
 * v13：定时任务与待办中心
 *
 * 依据：
 *   - 《电子档案管理办法》（国家档案局令第22号）要求**定期**检测电子档案的可读性、
 *     完整性、可用性与安全性 —— "定期"这件事不能靠人记着做，必须由系统自己执行。
 *   - DA/T 70—2018 四性检测应在电子档案管理全过程中持续/定期进行，不是做一次就算。
 *   - GB/T 18894—2016、DA/T 92—2022 §9.5：审计跟踪应覆盖系统自身的**后台行为**
 *     （自动备份、自动检测同样要留痕，否则"谁在半夜动了数据"无从追查）。
 *   - 《电子档案管理系统基本功能规定》（档办发〔2017〕3号）：系统应能提醒到期鉴定、
 *     保管期限届满、借阅逾期等事项。
 *
 * 两张新表：
 *   scheduler_state  每个任务的运行状态（上次跑完的时间/结果/计数）。
 *                    它是**重启补跑**的唯一依据：服务重启是常态（关机、升级、断电），
 *                    状态只放内存的话，一重启要么任务永远不再跑、要么全部重跑，两种都不能接受。
 *   todos            站内待办与提醒。关键在于 dedupe_key 唯一键：
 *                    同一件事每天扫描一遍，只更新不重复插入，否则待办列表会被刷屏。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV13(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS scheduler_state (
      task_key      TEXT PRIMARY KEY,
      last_run_at   TEXT NOT NULL DEFAULT '',
      last_status   TEXT NOT NULL DEFAULT '',      -- ok | fail | running | skip
      last_detail   TEXT NOT NULL DEFAULT '',
      last_ms       INTEGER NOT NULL DEFAULT 0,
      runs          INTEGER NOT NULL DEFAULT 0,
      fails         INTEGER NOT NULL DEFAULT 0,
      next_run_at   TEXT NOT NULL DEFAULT '',
      updated_at    TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS todos (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      dedupe_key    TEXT NOT NULL UNIQUE,
      kind          TEXT NOT NULL DEFAULT 'system',   -- backup | detection | fixity | retention | loan | security | system
      level         TEXT NOT NULL DEFAULT 'info',     -- info | warn | critical
      title         TEXT NOT NULL,
      detail        TEXT NOT NULL DEFAULT '',
      ref_type      TEXT NOT NULL DEFAULT '',
      ref_id        INTEGER,
      due_at        TEXT NOT NULL DEFAULT '',
      status        TEXT NOT NULL DEFAULT 'open',     -- open | done | dismissed
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL,
      handled_by    INTEGER,
      handled_at    TEXT NOT NULL DEFAULT '',
      handled_note  TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_todos_status ON todos(status, level, id DESC);
    CREATE INDEX IF NOT EXISTS idx_todos_kind ON todos(kind, status);
  `);

  const defaults = {
    // 调度器总开关：关掉后不注册任何任务（已登记的任务状态保留，便于下次开启接续）
    'scheduler.enabled': '1',
    // 每日自动备份的触发时刻（本机时间，0-23 时）
    'scheduler.backup_hour': '2',
    // 重启补跑的时间上限（小时）：停机超过这个时长就不再补跑，避免开机后连环爆跑
    'scheduler.catch_up_hours': '24',
    // 在线自动备份的保留份数（0 = 不限制）。注意：只影响"登记口径与告警"，不删文件
    'backup.keep_copies': '7',
    // 四性检测巡检周期（天）
    'detection.sweep_interval_days': '30',
    // 首页红点最多显示的数字（超过就显示 99+）
    'todo.badge_limit': '99',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 13) {
    console.log('[升级 v13] 已启用定时任务与待办中心：每日自动备份、定期四性检测巡检、哈希校验、到期提醒');
  }
}

/**
 * v14：常用检索（保存检索策略）
 *
 * 依据与动机：
 *   - 《电子档案管理系统基本功能规定》（档办发〔2017〕3号）要求检索功能完备；
 *   - 实务上档案员每天反复用的是同一批条件（"某门类 + 某年度 + 在库未鉴定"、
 *     "某部门今年移交来的"……），每次都从表单里重新点一遍既慢又容易点漏一项。
 *
 * 只加一张表，不动任何既有结构：
 *   saved_searches  保存的检索条件。`query` 存的是前端检索表单的**原始条件 JSON**，
 *                   服务端不解释它 —— 解释权归列表接口一套（buildFilters），
 *                   这里若再实现一遍解析，两边口径迟早不一致。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV14(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS saved_searches (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL,
      query       TEXT NOT NULL DEFAULT '{}',   -- 检索条件 JSON（与列表接口同一口径）
      note        TEXT NOT NULL DEFAULT '',
      shared      INTEGER NOT NULL DEFAULT 0,   -- 1 = 共享给同系统其他人（默认私有）
      owner_id    INTEGER REFERENCES users(id) ON DELETE CASCADE,
      owner       TEXT NOT NULL DEFAULT '',
      used_count  INTEGER NOT NULL DEFAULT 0,
      last_used_at TEXT NOT NULL DEFAULT '',
      created_at  TEXT NOT NULL,
      updated_at  TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_saved_searches_owner ON saved_searches(owner_id, shared);
  `);

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 14) {
    console.log('[升级 v14] 已启用「常用检索」：可以把反复使用的检索条件存下来，一键调出');
  }
}

/**
 * v15：档号号段表（号码只增不回退）
 *
 * 依据与动机：
 *   - DA/T 22—2015 与档案管理实务的基本原则：**档号一经编定，不得重复使用**。
 *     档案被销毁、移交出馆或误删后，它的档号应当作废，而不是被下一条档案捡回去用。
 *   - 改这里之前的行为是「下一个档号 = 该门类·年度里已有档号的 MAX + 1」，
 *     于是有个洞：**删掉序号最大的那一条，下一条新档案会把它的档号再用一次。**
 *     （已实测复现：建 0001/0002/0003 → 删 0003 → 新建又拿到 0003。）
 *
 * 只加一张表，不动任何既有结构、也不动任何既有档号：
 *   number_sequences  已发放到的最大号，按「门类 + 年度 + 种类」记录。
 *                     取号时与表内既有档号取较大者，保证单调不减；
 *                     即使该门类·年度的档案被删光，号段也不会回落。
 *
 * 升级时**必须回填**：否则升级后的第一条新档案会从 1 开始算，直接重号。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV15(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS number_sequences (
      type_code  TEXT NOT NULL,               -- 档案门类代码
      year       TEXT NOT NULL,               -- 年度
      kind       TEXT NOT NULL DEFAULT 'archive',
      last_seq   INTEGER NOT NULL DEFAULT 0,  -- 已发放到的最大顺序号
      updated_at TEXT NOT NULL DEFAULT '',
      PRIMARY KEY (type_code, year, kind)
    );
  `);

  // 回填号段：取该门类·年度既有序号的最大值。可安全重复执行。
  let filled = 0;
  try {
    const rows = db.prepare(
      `SELECT type_code, year, MAX(CAST(substr(archive_code, -4) AS INTEGER)) AS m
         FROM archives WHERE archive_code GLOB '*[0-9][0-9][0-9][0-9]'
        GROUP BY type_code, year`,
    ).all();
    const ins = db.prepare(
      `INSERT INTO number_sequences(type_code,year,kind,last_seq,updated_at) VALUES(?,?,?,?,?)
       ON CONFLICT(type_code,year,kind)
       DO UPDATE SET last_seq=MAX(last_seq, excluded.last_seq), updated_at=excluded.updated_at`,
    );
    const ts = new Date().toISOString();
    for (const r of rows) {
      const m = Number(r.m) || 0;
      if (m <= 0) continue;
      ins.run(String(r.type_code || ''), String(r.year || ''), 'archive', m, ts);
      filled++;
    }
  } catch (e) {
    // 空库或结构异常时忽略：号段表为空只是退回旧行为，不会比升级前更糟
    console.warn('[升级 v15] 号段回填跳过：' + e.message);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  // 把「出厂默认档号模板」升到现行标准结构。
  // **只在用户没改过时才动**：值仍等于旧出厂默认，说明是系统写的、不是人配的；
  // 一旦单位自己改过模板（沿用旧编号体系是他们的选择），这里一个字都不碰。
  const OLD_DEFAULT = '{unit}-{category}-{year}-{seq4}';
  const NEW_DEFAULT = '{unit}-{typeYear}-{retention}-{org}-{item}';
  let templateUpgraded = false;
  try {
    const row = db.prepare("SELECT value FROM settings WHERE key='archive.code_template'").get();
    if (row && String(row.value).trim() === OLD_DEFAULT) {
      db.prepare("UPDATE settings SET value=? WHERE key='archive.code_template'").run(NEW_DEFAULT);
      templateUpgraded = true;
    }
  } catch (e) {
    console.warn('[升级 v15] 档号模板升级跳过：' + e.message);
  }

  if (fromVersion > 0 && fromVersion < 15) {
    console.log(`[升级 v15] 档号号段已建立（回填 ${filled} 个门类·年度）：`
      + '删除或销毁档案后，它的档号不会再被下一条档案重复使用');
    if (templateUpgraded) {
      console.log(`[升级 v15] 出厂默认档号模板已升级为 DA/T 22—2015 标准结构：${NEW_DEFAULT}`);
      console.log('            （存量档案的档号不受影响；单位自定义过的模板也不会被改动）');
    }
  }
}

/**
 * v16：补充归档（关联件 + 正文替换留痕）
 *
 * 依据与动机：
 *   - DA/T 22—2015《归档文件整理规则》以「件」为整理单位。**新资料要归入已有档案时，
 *     标准做法是另立一件并建立关联**，而不是往已编好的件里插页 ——
 *     插页会让该件的页数、归档章、元数据 M05/M07、已打印的移交清册全部对不上。
 *     但"另立一件"之后，两份材料在业务上仍是同一事由，**必须能互相找得到**，
 *     而且这次补入本身要能追溯：谁、何时、为什么、补的是哪一件。
 *   - 另一个现实：原件的扫描件缺页或质量不合格时要**重新扫描替换**。
 *     "删掉再传"等于抹掉了"它曾经是什么" —— 旧版哈希与大小没了，事后无法证明替换过。
 *
 * 只加两张表，不动任何既有结构、也不动任何既有档案：
 *   archive_links       件与件之间的关联（参见 / 补充归档 / 同一事由）。
 *                       `pair_key` = 「较小id|较大id|种类」，**无论方向如何都唯一** ——
 *                       双向各存一行迟早会出现"只解除了其中一边"的脏数据。
 *   file_replacements   正文替换留痕：旧版名称/哈希/大小/类型/原因/经办人/时间。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV16(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS archive_links (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      from_id    INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      to_id      INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      kind       TEXT NOT NULL DEFAULT '参见',   -- 参见 | 补充归档 | 同一事由
      note       TEXT NOT NULL DEFAULT '',
      pair_key   TEXT NOT NULL,                  -- min|max|kind，保证 A↔B 只存一条
      created_by INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL,
      CHECK (from_id <> to_id)                   -- 自关联没有意义，且会让"双向"查询出重复
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_archive_links_pair ON archive_links(pair_key);
    CREATE INDEX IF NOT EXISTS idx_archive_links_from ON archive_links(from_id);
    CREATE INDEX IF NOT EXISTS idx_archive_links_to   ON archive_links(to_id);

    CREATE TABLE IF NOT EXISTS file_replacements (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id   INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      file_id      INTEGER,                      -- 替换件当前的文件行（之后可能被删）
      old_name     TEXT NOT NULL DEFAULT '',
      old_sha256   TEXT NOT NULL DEFAULT '',
      old_size     INTEGER NOT NULL DEFAULT 0,
      old_mime     TEXT NOT NULL DEFAULT '',
      reason       TEXT NOT NULL DEFAULT '',
      replaced_by  INTEGER REFERENCES users(id),
      replaced_at  TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_file_replacements_archive ON file_replacements(archive_id);
  `);

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 16) {
    console.log('[升级 v16] 已启用「补充归档」：新资料另立一件并与原档案建立关联（含补充归档登记、正文替换留痕）');
  }
}

/**
 * 第 17 版数据模型：鉴定扩展（密级鉴定 / 价值鉴定 / 开放鉴定）。
 *
 * 为什么必须补这一版 —— 现行法规要求的是**三种不同的鉴定**，而系统此前只有"到期鉴定"：
 *
 *  ① 价值鉴定（保管期限到期 → 延长/继续保管/建议销毁）
 *     依据：《机关文件材料归档范围和文书档案保管期限规定》（国家档案局令第 8 号）、
 *           DA/T 22—2015。系统已有大半（retention_years / retention_due_year / appraisals）。
 *
 *  ② 密级鉴定（保密期限届满 → 解密 / 延长保密期限 / 降低密级）
 *     ★ 完全没有。`secret_level` 只有取值，没有**保密期限**，于是"什么时候到期、
 *       什么时候必须审一次"这个法定义务在系统里根本无从体现。
 *     依据：《保守国家秘密法》第十九、二十条（保密期限届满自行解密；需延长的应在期限届满前
 *           重新确定）；《保守国家秘密法实施条例》；《国家秘密定密管理暂行规定》
 *           （定密责任人、定期审核、解密条件）。
 *
 *  ③ 开放鉴定（自形成之日起满 25 年 → 开放 / 部分开放 / 控制使用）
 *     ★ 只有 `open_state` 一个字段且无人维护，永远停在"未鉴定"。
 *     依据：《档案法》第二十七条（馆藏档案一般自形成之日起满二十五年向社会开放）、
 *           第二十八条（涉及国家安全或重大利益等到期不宜开放的，可以延期开放）；
 *           《各级国家档案馆馆藏档案解密和划分控制使用范围的暂行规定》。
 *
 * 设计取舍（写在代码里，免得后人以为漏了）：
 *  - **不给历史数据编造保密期限与开放状态**。存量档案的密级是当年定的、保密期限当年可能根本没写，
 *    系统凭空填一个"10年"是伪造档案管理事实。所以这三鉴需要的字段一律留空，
 *    由体检列出"缺保密期限/未开放鉴定"作为**提醒**，逼人去补真实信息。
 *  - **鉴定批次不可变**。鉴定错了不能"撤销"，只能重新鉴定一次（保留两次记录）——
 *    这才是真实档案工作的做法，也避免了"回滚"把档案状态改回去这种危险操作。
 *  - `appraisals.before_state` 存**鉴定前的快照**。清册上要能写出
 *    「原 定期10年 → 延长为 定期30年」这种前后对照，只存结论是印不出依据的。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV17(db, fromVersion = 0) {
  // ---- 档案表：密级鉴定的期限与依据、开放鉴定的结论与延期 ----
  const newCols = [
    // 密级鉴定（②）
    ['secret_term', "TEXT NOT NULL DEFAULT ''"],          // 保密期限：10年 / 20年 / 30年 / 长期 / 解密条件成就前
    ['secret_from', "TEXT NOT NULL DEFAULT ''"],          // 定密（保密期限起算）日期
    ['secret_to', "TEXT NOT NULL DEFAULT ''"],            // 保密期限届满日期（长期/条件解密留空）
    ['secret_basis', "TEXT NOT NULL DEFAULT ''"],         // 定密依据（保密事项范围及条款）
    ['declassify_condition', "TEXT NOT NULL DEFAULT ''"], // 解密条件（如"公开后不再造成损害"）
    // 开放鉴定（③）
    ['open_review_at', "TEXT NOT NULL DEFAULT ''"],       // 最近一次开放鉴定日期
    ['open_control_reason', "TEXT NOT NULL DEFAULT ''"],  // 控制使用（延期开放）理由与依据
    ['open_delay_to', "TEXT NOT NULL DEFAULT ''"],        // 延期开放至（日期）
    ['open_scope_note', "TEXT NOT NULL DEFAULT ''"],      // 部分开放的范围说明
  ];
  for (const [c, ddl] of newCols) addColumn(db, 'archives', c, ddl);

  // ---- 鉴定表：区分三种鉴定，并记录各自的结论字段 ----
  const appraisalCols = [
    ['kind', "TEXT NOT NULL DEFAULT '价值鉴定'"],          // 价值鉴定 | 密级鉴定 | 开放鉴定
    ['new_secret_level', "TEXT NOT NULL DEFAULT ''"],      // 密级鉴定结论：解密后为「公开」
    ['new_secret_to', "TEXT NOT NULL DEFAULT ''"],         // 密级鉴定结论：新的保密期限届满日期
    ['new_open_state', "TEXT NOT NULL DEFAULT ''"],        // 开放鉴定结论：开放 | 部分开放 | 控制使用
    ['control_reason', "TEXT NOT NULL DEFAULT ''"],        // 控制使用的理由与依据
    ['open_delay_to', "TEXT NOT NULL DEFAULT ''"],         // 延期开放至
    ['basis_ref', "TEXT NOT NULL DEFAULT ''"],             // 依据条款（法条/规范条款号）
    ['before_state', "TEXT NOT NULL DEFAULT '{}'"],        // 鉴定前快照（JSON），用于清册前后对照
    ['batch_id', 'INTEGER'],                               // 所属鉴定批次（0/NULL = 单件鉴定）
  ];
  for (const [c, ddl] of appraisalCols) addColumn(db, 'appraisals', c, ddl);

  db.exec(`
    CREATE TABLE IF NOT EXISTS appraisal_batches (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_no       TEXT NOT NULL UNIQUE,          -- JD202609-001
      kind           TEXT NOT NULL DEFAULT '价值鉴定',
      title          TEXT NOT NULL DEFAULT '',
      scope_note     TEXT NOT NULL DEFAULT '',      -- 鉴定范围说明
      basis          TEXT NOT NULL DEFAULT '',      -- 鉴定依据/理由
      basis_ref      TEXT NOT NULL DEFAULT '',      -- 依据条款
      conclusion     TEXT NOT NULL DEFAULT '',      -- 本批次统一结论
      organizer      TEXT NOT NULL DEFAULT '',      -- 组织鉴定部门
      organizer_id   INTEGER REFERENCES users(id),
      members        TEXT NOT NULL DEFAULT '',      -- 鉴定小组成员（姓名，顿号分隔）
      member_count   INTEGER NOT NULL DEFAULT 0,
      meeting_date   TEXT NOT NULL DEFAULT '',      -- 鉴定日期
      approver       TEXT NOT NULL DEFAULT '',      -- 审核人（定密责任人 / 馆领导）
      approved_at    TEXT NOT NULL DEFAULT '',      -- 审核同意日期
      approve_note   TEXT NOT NULL DEFAULT '',
      archive_count  INTEGER NOT NULL DEFAULT 0,
      summary        TEXT NOT NULL DEFAULT '',      -- 结论分布摘要（如「延长保管期限 5 件」）
      created_at     TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_appraisal_batches_kind ON appraisal_batches(kind, id DESC);
    CREATE INDEX IF NOT EXISTS idx_appraisals_batch ON appraisals(batch_id);
  `);

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 17) {
    console.log('[升级 v17] 已启用「鉴定扩展」：密级鉴定（保密期限届满解密/延长）、'
      + '开放鉴定（满 25 年开放/控制使用）与鉴定批次文据；存量档案的保密期限一律留空，'
      + '由数据体检提醒补录，不由系统代为编造');
  }
}

/**
 * 第 18 版数据模型：检索智能化（拼音检索键 / OCR 来源标记 / 检索设置）。
 *
 * 这一版解决的是**"搜得到"**，三件事：
 *
 *  ① 拼音检索键（`archives.py_full` / `archives.py_initials`）
 *     让"只记得怎么念、不记得怎么写"的人也能查到档案。字表来自 lib/pinyin-data.js，
 *     生成方式与词表版本见升级说明 v4.11.0 章节（如实交代数据来源）。
 *
 *  ② OCR 来源标记（`file_text.via` / `file_text.engine`）
 *     扫描件经 OCR 识别出的正文，必须与原生文字层分得开：
 *     OCR 一定会有错字，把它混进原生文本里，使用者就无法判断该不该信这段内容。
 *     存量行一律标 `native`（它们确实都是原生提取的）。
 *
 *  ③ 检索设置默认值（ocr.* / search.*）
 *
 * **回填是必须的**：只用建库时写入的话，存量档案的拼音键全是空的 ——
 * 表现为"升级后新档案能用拼音搜到、老档案搜不到"，这种"一半好一半坏"最难排查。
 * 回填按 id 分批、可重复执行，幂等。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV18(db, fromVersion = 0) {
  addColumn(db, 'archives', 'py_full', "TEXT NOT NULL DEFAULT ''");
  addColumn(db, 'archives', 'py_initials', "TEXT NOT NULL DEFAULT ''");
  addColumn(db, 'file_text', 'via', "TEXT NOT NULL DEFAULT 'native'");
  addColumn(db, 'file_text', 'engine', "TEXT NOT NULL DEFAULT ''");

  // 存量附件正文全部是原生提取的（OCR 是本版才有的能力），统一标 native。
  // 不这样兜一次的话，旧行会因为 DEFAULT 才能拿到值 —— 而 DEFAULT 只在加列那一刻生效，
  // 之后插入的行由代码负责；这里补一次 UPDATE 是为了让语义明确：**历史数据就是原生文本**。
  try {
    db.prepare("UPDATE file_text SET via='native' WHERE via IS NULL OR via=''").run();
  } catch (_) { /* 表可能还不存在，忽略 */ }

  const defaults = {
    // OCR：none 表示明确关闭（即使装了引擎也不调用）；auto 表示探测到就用
    'ocr.mode': 'auto',
    // 引擎选择：auto = 优先用 Windows 自带识别（**零安装**），再退 tesseract / ocrmypdf
    'ocr.engine': 'auto',
    // 用自己的 OCR 可执行文件（需符合 tesseract 命令行契约），留空表示自动探测
    'ocr.engine_path': '',
    // PDF → 图片的中间件路径，留空自动探测
    'ocr.raster_path': '',
    // 识别语言：中文简体 + 英文数字
    'ocr.lang': 'chi_sim+eng',
    // 单个文件的识别超时（毫秒）
    'ocr.timeout_ms': '120000',
    // PDF 逐页识别时的分辨率（DPI）：太高又慢又大，太低小字识别不出
    'ocr.dpi': '200',
    // 单个 PDF 最多识别多少页（防止一本几百页的书把进程挂住）
    'ocr.max_pages': '50',
    // 单个附件超过多少 MB 不做 OCR（扫描大图识别很慢，且多半是把整册扫成一个 PDF）
    'ocr.max_mb': '50',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  // ---- 回填拼音检索键 ----
  let backfilled = 0;
  try {
    const rows = db.prepare(
      "SELECT id, title, keywords, responsible FROM archives WHERE py_full='' OR py_initials=''",
    ).all();
    const upd = db.prepare('UPDATE archives SET py_full=?, py_initials=? WHERE id=?');
    for (const r of rows) {
      const k = pinyin.archiveKeys(r);
      upd.run(k.full, k.initials, r.id);
      backfilled++;
    }
  } catch (e) {
    console.warn('[升级 v18] 拼音检索键回填失败（不影响其它功能，可用工具重建）：' + e.message);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 18) {
    console.log(`[升级 v18] 已启用「检索智能化」：拼音检索键（回填 ${backfilled} 条）、`
      + 'OCR 来源标记与检索设置。OCR 引擎需本机自行安装，系统只做适配不做捆绑');
  }

  // ---- v19：删除留痕 · 回收站（v4.22.0）----
  //
  // **纯新增一张表，不动任何现有表、不改任何现有查询。**
  //
  // 为什么不做"软删除"（给 archives 加 deleted_at、所有查询加 deleted_at IS NULL）：
  // 那要改遍全项目的档案读取路径（搜索、导出、二维码、统计、打印、盘点…），
  // 漏掉任何一处，已删除的档案就会在某个界面重新冒出来 —— 而这种错很难被发现。
  // 改成"删除时把整行快照搬进回收站表、再从 archives 删掉"，
  // 现有查询一行都不用改，行为与今天完全一致：它压根不在 archives 里了。
  //
  // 设计全文见工作区的《回收站设计.md》。这一步只建表建索引，是零破坏性的；
  // 失败时删掉这张表即可回退（不涉及任何已有数据）。
  db.exec(`
    CREATE TABLE IF NOT EXISTS archive_trash (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      original_id      INTEGER NOT NULL,
      archive_code     TEXT,
      archive_number   TEXT,
      title            TEXT,
      type_code        TEXT,
      year             INTEGER,
      secret_level     TEXT,
      file_count       INTEGER NOT NULL DEFAULT 0,
      snapshot         TEXT NOT NULL,
      files_snapshot   TEXT NOT NULL DEFAULT '[]',
      relation_snapshot TEXT NOT NULL DEFAULT '{}',
      reason           TEXT,
      deleted_by       INTEGER,
      deleted_by_name  TEXT,
      deleted_at       TEXT NOT NULL,
      expires_at       TEXT,
      purged_at        TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_archive_trash_deleted_at ON archive_trash(deleted_at);
  `);
  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
  if (fromVersion > 0 && fromVersion < 19) {
    console.log('[升级 v19] 已启用「删除留痕 · 回收站」：删除档案将改为先移入回收站'
      + '（保留期内可恢复），物理附件在彻底清除之前不会被删除');
  }
}

/**
 * 第 20 版数据模型：手机号找回口令（v4.27.0）
 *
 * 为什么只加一张表、**不加任何列到 users**：
 *   找回流程的全部状态（验证码、有效期、尝试次数、一次性票据）都是**短期、可丢弃**的，
 *   与账号本身无关。混进 users 会让每一次账号查询都多带几个与业务无关的字段，
 *   而且"过期清理"变成一次 UPDATE users —— 一旦清理脚本写错，伤到的是账号表本尊。
 *   单独一张表出问题，`DROP TABLE login_codes` 就能回退，零影响。
 *
 * 三条设计约束（改代码时别破坏）：
 *   1. **码与票据都只存哈希**（scrypt / SHA-256）。库文件被拿走也拿不到可用的码 ——
 *      这跟口令存储是同一条底线，不能因为"验证码只有 6 位、5 分钟"就放宽。
 *   2. **一次性**：`used_at` 记录码被核销的时刻；票据用掉后 `ticket_expires_at` 置空，
 *      重放同一条记录查不到。
 *   3. **attempts 计数存在行上**，不靠 count(*) 现算：核销和计数必须原子，
 *      否则并发猜码时"第 6 次尝试"能从两个请求里各读到 4 次而漏过去。
 *
 * 依据：《电子档案管理系统基本功能规定》第四十一条身份鉴别、档办发〔2017〕3号
 * 第三十八条口令管理 —— 自助找回必须留有可审计的完整过程，且不得降低口令强度要求。
 */
function migrateToV20(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS login_codes (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id           INTEGER NOT NULL,
      phone             TEXT NOT NULL,
      purpose           TEXT NOT NULL DEFAULT 'reset',
      code_salt         TEXT NOT NULL,
      code_hash         TEXT NOT NULL,
      sent_at           TEXT NOT NULL,
      expires_at        TEXT NOT NULL,
      attempts          INTEGER NOT NULL DEFAULT 0,
      used_at           TEXT NOT NULL DEFAULT '',
      ticket_hash       TEXT NOT NULL DEFAULT '',
      ticket_expires_at TEXT NOT NULL DEFAULT '',
      ip                TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_login_codes_user  ON login_codes(user_id, sent_at);
    CREATE INDEX IF NOT EXISTS idx_login_codes_phone ON login_codes(phone, sent_at);
    CREATE INDEX IF NOT EXISTS idx_login_codes_ip    ON login_codes(ip, sent_at);
  `);

  // 手机号是找回口令的唯一入口，按号查人必须快；**不建唯一索引**，
  // 原因见 api.js 里登记手机号时的处理：存量库里可能已经有重复号码，
  // 建唯一索引会让升级直接失败，而失败发生在"程序起不来"这一步，最难查。
  // 改由写入路径拒绝重复（并给出中文提示），既保住升级，又把脏数据挡在门外。
  try {
    db.exec('CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone)');
  } catch (_) { /* 老库没有 phone 列时忽略：v2 之前的结构由前面的迁移负责补齐 */ }

  const defaults = {
    // 总开关：0 = 关闭手机号找回（只保留口令登录）
    'security.sms_login': '1',
    // 验证码有效期（分钟）
    'security.sms_code_ttl_minutes': '5',
    // 同一手机号两次发送的最小间隔（秒）
    'security.sms_resend_seconds': '60',
    // 同一手机号每天最多发送几次
    'security.sms_daily_limit': '5',
    // 一个验证码最多允许输错几次；超过即作废，必须重新获取
    'security.sms_max_attempts': '5',
    // 验证码通过后签发的重置票据有效期（分钟）
    'security.sms_ticket_ttl_minutes': '10',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 20) {
    console.log('[升级 v20] 已启用「手机号找回口令」：登录页可凭手机号 + 短信验证码重置口令'
      + '（需在 server/config.json 配置短信通道，见《短信登录配置说明.txt》）');
  }
}

/**
 * 第 21 版数据模型：扫描件按档号规范存储。
 *
 * 背景：扫描仪输出的是**多页 PDF**，一件档案 = 一个 PDF。要让"实体页数"与
 * "PDF 实际页数"能一键核对，就必须在文件记录上留下 PDF 页数与数字化元数据；
 * 这些也是《数字档案室建设指南》§5.6.2 要求捕获的数字化元数据
 * （分辨率、色彩空间、格式、文件大小、数字化设备、数字化日期时间）。
 *
 * 新增列：
 *   pages        PDF 页数（0 = 未解析/非 PDF），用于与 archives.pages 做缺页核对
 *   dpi          扫描分辨率（水平/垂直相同，取一个值）
 *   color_mode   彩色 / 灰度 / 黑白
 *   device       扫描设备（型号或"扫描仪"）
 *   scanned_at   数字化日期时间
 *   storage_kind 存储布局：archive = 按档号目录（v4.28 起），hash = 旧的哈希目录
 *
 * `storage_kind` 不是内部细节：迁移工具要靠它判断"哪些文件还没搬到档号目录"，
 * 而"搬没搬过"必须能如实查询，不能靠猜路径形状。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV21(db, fromVersion = 0) {
  const fileCols = [
    ['pages', 'INTEGER NOT NULL DEFAULT 0'],
    ['dpi', 'INTEGER NOT NULL DEFAULT 0'],
    ['color_mode', "TEXT NOT NULL DEFAULT ''"],
    ['device', "TEXT NOT NULL DEFAULT ''"],
    ['scanned_at', "TEXT NOT NULL DEFAULT ''"],
    ['storage_kind', "TEXT NOT NULL DEFAULT ''"],
  ];
  for (const [c, ddl] of fileCols) addColumn(db, 'files', c, ddl);

  // 存量文件先如实标注布局：旧版内容寻址的路径形如 `WS/2026/ea/<64位hex>.xlsx`。
  // 这个判断只在"storage_kind 为空"的行上做，可重复执行，也不会覆盖后来手工订正的值。
  try {
    const rows = db.prepare("SELECT id, rel_path FROM files WHERE storage_kind=''").all();
    const upd = db.prepare('UPDATE files SET storage_kind=? WHERE id=?');
    const legacyRe = /^[A-Za-z0-9_-]+\/\d{4}\/[0-9a-f]{2}\/[0-9a-f]{64}\.[A-Za-z0-9]{1,10}$/;
    for (const r of rows) upd.run(legacyRe.test(String(r.rel_path || '')) ? 'hash' : 'archive', r.id);
  } catch (_) { /* 空库或表结构异常：不影响启动 */ }

  const defaults = {
    'scan.default_dpi': '300',
    'scan.default_color': '彩色',
    // 页数核对开关：1 = 导入扫描件时对照实体页数给出提示（只提示，不阻断）
    'scan.pages_check': '1',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 21) {
    console.log('[升级 v21] 扫描件改为按档号目录存储：新上传文件落在「全宗/门类·年度/期限/机构/件号」下，'
      + '并自动记录 PDF 页数用于缺页核对。存量文件位置不变，可运行 server\\tools\\migrate-files-layout.js 搬迁');
  }
}

/**
 * 第 22 版数据模型：**过程接收**（项目 + 批次 + 时间轴）。
 *
 * 与档案馆的根本差别：档案馆接收的是"已经形成完毕、整理定稿"的档案，
 * 一次性、成体系；本单位交来的是**还在形成中的过程资料** —— 工程没竣工就先交开工、
 * 基础、主体资料，养护按季度一批一批来。
 *
 * 所以这一版不套"档号目录"那一层，而是把"谁、在什么时候、为哪个项目、交了哪一批"记清楚：
 *
 *   projects        项目（一个工程 / 一个养护标段）—— 终身容器
 *   intake_batches  接收批次 = 一次交接 —— 时间轴上的一个点
 *   archives        每件挂到 project_id + batch_id，并记 received_at（接收日期）
 *   archive_state   '过程' | '已归档'：过程中在"过程区"按项目/时间存放，
 *                   竣工或年度终了做一次"归档定稿"再进"归档区"（按档号）
 *
 * 时间排序不靠界面：批次目录名以日期打头，资源管理器按名字排就是时间顺序。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV22(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      project_no  TEXT NOT NULL UNIQUE,          -- GC-2026-003 / YH-2026-001
      name        TEXT NOT NULL DEFAULT '',
      kind        TEXT NOT NULL DEFAULT '工程',   -- 工程 | 养护 | 其他
      status      TEXT NOT NULL DEFAULT '在建',   -- 在建 | 已完工 | 已归档
      start_date  TEXT NOT NULL DEFAULT '',
      end_date    TEXT NOT NULL DEFAULT '',
      note        TEXT NOT NULL DEFAULT '',
      created_by  INTEGER REFERENCES users(id),
      created_at  TEXT NOT NULL,
      updated_at  TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_projects_kind ON projects(kind, status);

    CREATE TABLE IF NOT EXISTS intake_batches (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_no     TEXT NOT NULL UNIQUE,         -- SR-20260312-01
      project_id   INTEGER REFERENCES projects(id) ON DELETE SET NULL,
      title        TEXT NOT NULL DEFAULT '',     -- 第1批 开工资料
      stage        TEXT NOT NULL DEFAULT '',     -- 开工 / 主体施工 / 竣工 …
      received_at  TEXT NOT NULL,                -- 接收日期 YYYY-MM-DD（时间轴排序依据）
      source_unit  TEXT NOT NULL DEFAULT '',     -- 移交部门/单位
      handover_by  TEXT NOT NULL DEFAULT '',     -- 移交人
      receive_by   TEXT NOT NULL DEFAULT '',     -- 接收人
      note         TEXT NOT NULL DEFAULT '',
      status       TEXT NOT NULL DEFAULT '接收中', -- 接收中 | 已归档
      archive_count INTEGER NOT NULL DEFAULT 0,
      created_by   INTEGER REFERENCES users(id),
      created_at   TEXT NOT NULL,
      updated_at   TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_batches_project ON intake_batches(project_id, received_at DESC);
    CREATE INDEX IF NOT EXISTS idx_batches_time ON intake_batches(received_at DESC);
  `);

  const archCols = [
    ['project_id', 'INTEGER'],
    ['batch_id', 'INTEGER'],
    ['received_at', "TEXT NOT NULL DEFAULT ''"],
    ['archive_state', "TEXT NOT NULL DEFAULT '过程'"],   // 过程 | 已归档
  ];
  for (const [c, ddl] of archCols) addColumn(db, 'archives', c, ddl);
  try {
    db.exec('CREATE INDEX IF NOT EXISTS idx_archives_project ON archives(project_id)');
    db.exec('CREATE INDEX IF NOT EXISTS idx_archives_batch ON archives(batch_id)');
    db.exec("CREATE INDEX IF NOT EXISTS idx_archives_recv ON archives(received_at)");
  } catch (_) { /* 索引失败不影响启动 */ }

  const defaults = {
    // 阶段词表：做成设置项而不是写死，各单位叫法不同（如"监理资料"有的并进"施工"）
    'intake.stage_engineering': '开工,主体施工,安装,竣工',
    'intake.stage_maintenance': '月度,季度,年度',
    // 项目号前缀：工程 GC、养护 YH
    'intake.prefix_engineering': 'GC',
    'intake.prefix_maintenance': 'YH',
    // 归档定稿后是否把项目自动置为"已归档"
    'intake.auto_project_archived': '1',
  };
  for (const [k, v] of Object.entries(defaults)) {
    db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k, v);
  }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 22) {
    console.log('[升级 v22] 已启用「过程接收」：项目 + 接收批次 + 接收日期；'
      + '过程资料按「项目/批次日期」存放，竣工或年度终了再做归档定稿进档号目录');
  }
}

/**
 * 第 23 版数据模型：接收批次补「交件人电话」。
 *
 * 为什么单独一版而不是并进 v22：v22 已经在真机上跑过（D 盘库已是 22），
 * 再改 v22 的建表语句不会对已升级的库生效 —— 必须走新的一版加列，否则
 * 真机升级后这一列永远不存在，表现为"登记时能填、保存后丢了"。
 *
 * 电话不设校验格式（手机、座机、分机都可能有），只在接口层限长。
 */
function migrateToV23(db, fromVersion = 0) {
  addColumn(db, 'intake_batches', 'handover_phone', "TEXT NOT NULL DEFAULT ''");
  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
  if (fromVersion > 0 && fromVersion < 23) {
    console.log('[升级 v23] 接收批次已增加「交件人电话」，老批次该字段为空，可在批次里补填');
  }
}

/**
 * v24：门类增加「整理方式」。
 *
 * 为什么要这一列：同一批档案有两种整理线，单位往往并存 ——
 *   · 按年度整理（year）：文书、人事、财务这类，一年一组，跨年即断开；
 *   · 按项目整理（project）：工程、养护这类，一个项目动辄十几年，
 *     若按年度截断，同一个项目会被拆成几十段、档号在项目内不连续。
 *
 * 默认 'year'，与升级前的行为完全一致，存量数据不受影响。
 */
function migrateToV24(db, fromVersion = 0) {
  addColumn(db, 'archive_types', 'filing_mode', "TEXT NOT NULL DEFAULT 'year'");
  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
  if (fromVersion > 0 && fromVersion < 24) {
    console.log('[升级 v24] 门类已增加「整理方式」：默认按年度整理；工程、养护这类长期项目可改成「按项目整理」');
  }
}

/**
 * v25：给账号加「邮箱」列（v4.30.9）。
 *
 * 为什么加：手机号找回依赖云短信通道（要资质、要花钱），而邮箱是单位本来就有的。
 * 这一列先把邮箱登记下来，登录页的「忘记口令」才能按登记信息去发重置链接/验证码；
 * 不做唯一约束 —— 同一科室共用一个邮箱地址是常见做法，重复不影响按账号投递。
 *
 * 默认空串，与升级前行为完全一致，存量数据不受影响。
 */
function migrateToV25(db, fromVersion = 0) {
  addColumn(db, 'users', 'email', "TEXT NOT NULL DEFAULT ''");
  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
  if (fromVersion > 0 && fromVersion < 25) {
    console.log('[升级 v25] 账号已增加「邮箱」：可在「系统管理 → 找回方式」里登记手机号与邮箱，供忘记口令时使用');
  }
}

/**
 * v26：找回验证码同时支持「短信」与「邮件」两条通道（v4.31.0）。
 *
 * 原来 login_codes 只有 phone 一列，等于把"通道"焊死在手机号上。
 * 加 channel + target 之后：channel='sms' 时 target 是手机号、'email' 时是邮箱，
 * 同一套三步流程（发码 → 校验 → 凭票据改口令）可以服务两条通道，
 * 审计日志里也能一眼看出这次找回走的是哪条路。
 *
 * 存量行按 channel='sms'、target=phone 回填 —— 升级前它们确实都是短信。
 */
function migrateToV26(db, fromVersion = 0) {
  addColumn(db, 'login_codes', 'channel', "TEXT NOT NULL DEFAULT 'sms'");
  addColumn(db, 'login_codes', 'target', "TEXT NOT NULL DEFAULT ''");
  try {
    db.prepare("UPDATE login_codes SET target = phone WHERE target = '' AND phone <> ''").run();
  } catch (e) {
    console.warn('[升级 v26] 回填 target 失败（不影响使用）：' + e.message);
  }
  try {
    db.prepare('CREATE INDEX IF NOT EXISTS idx_login_codes_target ON login_codes(channel, target, sent_at)').run();
  } catch (_) { /* 索引建不上不影响主流程 */ }
  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));
  if (fromVersion > 0 && fromVersion < 26) {
    console.log('[升级 v26] 口令找回已支持「邮箱验证码」：在 server\\config.json 配好 mail 段即可用');
  }
}

/**
 * 第 27 版数据模型：制度五项（V4.32.0）
 *
 *  1. 保管期限表建模 —— 原来保管期限只能手填，缺"按门类/事项查表"的依据。
 *     新增 `retention_schedule`：门类 × 事项 → 保管期限 + 依据；著录时可按门类查表带出，
 *     到期提醒也能说清"依据哪一条"。
 *  2. 件级状态机 —— 原来 `status` 是自由字段。新增 `archives.lifecycle`
 *     （接收→整理→著录→归档→上架→借阅→鉴定→销毁/移交）与 `archive_transitions` 流转留痕；
 *     与既有 status 并存（status 是"实体在哪"，lifecycle 是"办到哪一步"）。
 *  3. 四性证据链 —— 新增 `integrity_evidence`：真实性/完整性/可用性/安全性 逐项留证
 *     （完整性用文件 SHA-256 实测值，其余记方法、结论与操作人）。
 *  4. 件级权限与利用登记 —— 新增 `archive_grants`（把某一件授权给某个人）
 *     与 `usage_registry`（谁在什么时候查阅/下载/打印/借出过哪一件）。
 *  5. 管理者驾驶舱 —— 不新增表，由上述数据 + 既有统计汇总得出。
 *
 * @param {object} db
 * @param {number} fromVersion 升级前的 schema 版本（0 = 全新库）
 */
function migrateToV27(db, fromVersion = 0) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS retention_schedule (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      type_code    TEXT NOT NULL DEFAULT '',
      item         TEXT NOT NULL,
      retention    TEXT NOT NULL DEFAULT '永久',
      years        INTEGER NOT NULL DEFAULT 0,
      basis        TEXT NOT NULL DEFAULT '',
      note         TEXT NOT NULL DEFAULT '',
      status       TEXT NOT NULL DEFAULT '启用',
      created_at   TEXT NOT NULL,
      updated_at   TEXT NOT NULL DEFAULT ''
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_rs_type_item ON retention_schedule(type_code, item);

    CREATE TABLE IF NOT EXISTS archive_transitions (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id  INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      seq         INTEGER NOT NULL DEFAULT 1,
      from_state  TEXT NOT NULL DEFAULT '',
      to_state    TEXT NOT NULL,
      reason      TEXT NOT NULL DEFAULT '',
      by_user     INTEGER,
      by_name     TEXT NOT NULL DEFAULT '',
      at          TEXT NOT NULL,
      ip          TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_at_archive ON archive_transitions(archive_id, id);

    CREATE TABLE IF NOT EXISTS integrity_evidence (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id  INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      file_id     INTEGER,
      aspect      TEXT NOT NULL,          -- 真实性 | 完整性 | 可用性 | 安全性
      method      TEXT NOT NULL DEFAULT '',  -- 如 SHA-256 实测 / 格式可解析 / 权限校验
      value       TEXT NOT NULL DEFAULT '',
      result      TEXT NOT NULL DEFAULT '通过',   -- 通过 | 存疑 | 不通过
      note        TEXT NOT NULL DEFAULT '',
      at          TEXT NOT NULL,
      by_user     INTEGER,
      by_name     TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_ie_archive ON integrity_evidence(archive_id, aspect);

    CREATE TABLE IF NOT EXISTS archive_grants (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id   INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      reason       TEXT NOT NULL DEFAULT '',
      granted_by   INTEGER,
      granted_name TEXT NOT NULL DEFAULT '',
      at           TEXT NOT NULL,
      expires_at   TEXT NOT NULL DEFAULT '',
      status       TEXT NOT NULL DEFAULT '有效'   -- 有效 | 已撤销 | 已过期
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_ag_pair ON archive_grants(archive_id, user_id);

    CREATE TABLE IF NOT EXISTS usage_registry (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      archive_id  INTEGER NOT NULL REFERENCES archives(id) ON DELETE CASCADE,
      file_id     INTEGER,
      user_id     INTEGER,
      username    TEXT NOT NULL DEFAULT '',
      department  TEXT NOT NULL DEFAULT '',
      action      TEXT NOT NULL,           -- 查阅 | 下载 | 打印 | 借出 | 复制
      target      TEXT NOT NULL DEFAULT '',
      at          TEXT NOT NULL,
      ip          TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_ur_archive ON usage_registry(archive_id, id);
    CREATE INDEX IF NOT EXISTS idx_ur_user ON usage_registry(user_id, id);
  `);

  addColumn(db, 'archives', 'lifecycle', "TEXT NOT NULL DEFAULT ''");
  addColumn(db, 'archives', 'lifecycle_at', "TEXT NOT NULL DEFAULT ''");

  // 保管期限表：按现有门类各给一条"一般文件材料"的默认行，让表开箱就有依据可查
  try { seedRetentionSchedule(db); } catch (e) {
    console.warn('[升级 v27] 保管期限表初始行跳过：' + e.message);
  }

  // 存量档案：按现有 status 推断一个合理的初始生命周期节点，避免"全是空"
  try {
    db.prepare(`UPDATE archives SET lifecycle = CASE
        WHEN status='借出' THEN '借阅'
        WHEN status='待销毁' THEN '鉴定'
        WHEN status='已销毁' THEN '销毁'
        WHEN status='待整理' THEN '接收'
        ELSE '归档' END
      WHERE lifecycle=''`).run();
  } catch (_) { /* 推断失败不影响使用，用户可逐件流转 */ }

  db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run('schema_version', String(SCHEMA_VERSION));

  if (fromVersion > 0 && fromVersion < 27) {
    console.log('[升级 v27] 已启用：保管期限表、件级状态机、四性证据链、件级授权与利用登记');
  }
}

/**
 * 保管期限表初始行：每个门类一条「<门类>一般文件材料」默认期限。
 *
 * 为什么单独抽成函数：全新库的调用顺序是 migrate → seed，迁移执行时门类表还是空的，
 * 全靠迁移播种会得到一张空表；所以迁移时播一次（老库），seed 完成后再补一次（新库）。
 * meta 标记只在**确实播到了行**时才写，避免把"没播成"记成"播过了"。
 */
function seedRetentionSchedule(db, now = new Date().toISOString()) {
  const types = db.prepare('SELECT code,name,retention FROM archive_types').all();
  if (!types.length) return 0;
  const ins = db.prepare(`INSERT OR IGNORE INTO retention_schedule
    (type_code,item,retention,years,basis,note,status,created_at)
    VALUES(?,?,?,?,?,?,'启用',?)`);
  const yearsOf = (r) => (r === '永久' || r === '长期' ? 0 : Number(String(r).replace(/[^0-9]/g, '')) || 0);
  let n = 0;
  for (const t of types) {
    const r = ins.run(t.code, `${t.name}一般文件材料`, t.retention || '永久', yearsOf(t.retention),
      '《机关文件材料归档范围和文书档案保管期限规定》（国家档案局令第8号）',
      '按门类默认期限，可按本单位《归档范围与保管期限表》细化', now);
    n += Number(r.changes) || 0;
  }
  if (n > 0) db.prepare("INSERT OR REPLACE INTO meta(key,value) VALUES('seed.v27_retention',?)").run(now);
  return n;
}

/**
 * 规范化保管期限取值。
 *
 * 早期内置的门类默认保管期限写成 '30年'，而系统认可的取值是 '定期30年'。
 * 这类“看起来对、实际不在合法集合里”的值有两个危害：
 *   1. 保管期限代码与到期年度永远算不出来（到期提醒、鉴定流程失效）
 *   2. 在界面上打开编辑时下拉框匹配不到该值，一保存就静默变成默认的「永久」
 * 因此这里把历史值统一规范为合法取值，并同步门类默认值。可安全重复执行。
 */
function normalizeRetention(db) {
  try {
    const alias = {
      '30年': '定期30年', '定期30年': '定期30年',
      '10年': '定期10年', '定期10年': '定期10年',
      '5年': '定期5年', '定期5年': '定期5年',
      '永久': '永久', '长期': '长期',
    };
    let fixed = 0;
    // 档案表
    for (const [bad, good] of Object.entries(alias)) {
      if (bad === good) continue;
      const r = db.prepare('UPDATE archives SET retention=? WHERE retention=?').run(good, bad);
      fixed += Number(r.changes) || 0;
    }
    // 回收无法识别的值（避免留下既非合法值、又无法参与计算的脏数据）
    const unknown = db.prepare(
      "SELECT DISTINCT retention FROM archives WHERE retention NOT IN ('永久','定期30年','定期10年','定期5年','长期')"
    ).all();
    for (const row of unknown) {
      const raw = String(row.retention || '');
      const m = /(\d+)\s*年/.exec(raw);
      const mapped = m ? `定期${m[1]}年` : '永久';
      // 只接受 5/10/30 这类常见期限，其他一律归为永久
      const finalVal = ['定期5年', '定期10年', '定期30年'].includes(mapped) ? mapped : '永久';
      const r = db.prepare('UPDATE archives SET retention=? WHERE retention=?').run(finalVal, raw);
      fixed += Number(r.changes) || 0;
    }
    // 门类默认保管期限
    db.exec("UPDATE archive_types SET retention='定期30年' WHERE retention='30年'");
    db.exec("UPDATE archive_types SET retention='定期10年' WHERE retention='10年'");
    if (fixed) console.log(`[数据规范化] 已修正 ${fixed} 条档案的保管期限取值（如 30年 → 定期30年）`);
  } catch (e) {
    console.warn('[数据规范化] 保管期限规范化失败（不影响启动）：' + e.message);
  }
}

/**
 * 为存量档案回填规范档号、保管期限代码与到期年度。
 * 只处理字段为空白的记录，不覆盖用户后来手工填写的内容；可安全重复执行。
 */
function backfillArchiveNumbers(db) {
  const map = RETENTION_MAP;
  let rows;
  try {
    rows = db.prepare(
      "SELECT id, archive_code, category_id, year, archive_date, retention FROM archives " +
      "WHERE unit_code='' OR archive_number='' OR retention_code='' OR retention_due_year=0"
    ).all();
  } catch (_) { return; }
  if (!rows.length) return;

  const getSetting = (k, dft) => {
    try {
      const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k);
      return r && r.value !== undefined && r.value !== null && r.value !== '' ? String(r.value) : dft;
    } catch (_) { return dft; }
  };
  const unit = getSetting('archive.unit_code', 'Z001');
  const catalogDefault = getSetting('archive.catalog_no', '01');
  const catStmt = db.prepare('SELECT code FROM categories WHERE id=?');
  const upd = db.prepare(
    "UPDATE archives SET unit_code=?, category_code=?, catalog_no=?, retention_code=?, retention_years=?, " +
    "retention_due_year=?, archive_number=?, open_state=?, electronic_flag=?, created_via=? WHERE id=?"
  );

  db.exec('BEGIN IMMEDIATE');
  try {
    for (const r of rows) {
      const cat = r.category_id ? catStmt.get(r.category_id) : null;
      const catCode = cat ? String(cat.code) : '';
      const year = Number(r.year) || Number(String(r.archive_date || '').slice(0, 4)) || new Date().getFullYear();
      const info = map[r.retention] || { code: '', years: 0 };
      const due = info.years > 0 ? year + info.years : 0;
      // 案卷号沿用原档案号末尾流水，保证迁移后仍能对上实物
      const seq = (String(r.archive_code || '').match(/(\d{1,6})\s*$/) || [])[1] || '';
      const number = [unit, catCode, catalogDefault, String(year)]
        .filter((x) => x !== '').join('-') + (seq ? '-' + seq.padStart(4, '0') : '');
      upd.run(unit, catCode, catalogDefault, info.code, info.years, due, number,
        '未鉴定', '纸质', '存量迁移', r.id);
    }
    db.exec('COMMIT');
    console.log(`[数据迁移] 已为 ${rows.length} 条存量档案补全档号与保管期限信息`);
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) { /* ignore */ }
    console.warn('[数据迁移] 回填失败（不影响启动）：' + e.message);
  }
}

/** 保管期限 → 代码与年数（DA/T 参照） */
const RETENTION_MAP = {
  '永久': { code: 'Y', years: 0 },
  '长期': { code: 'C', years: 0 },
  '定期30年': { code: 'D30', years: 30 },
  '定期10年': { code: 'D10', years: 10 },
  '定期5年': { code: 'D5', years: 5 },
};

/**
 * 全文索引自愈：核对索引行数与档案行数，不一致时重建
 * （FTS5 外部内容表一旦与主表失步，检索会漏结果，此处做兜底修复）
 */
function repairFtsIndex(db) {
  try {
    const a = db.prepare('SELECT COUNT(*) AS c FROM archives').get().c;
    const f = db.prepare('SELECT COUNT(*) AS c FROM archives_fts').get().c;
    if (Number(a) !== Number(f)) {
      console.log(`[索引自检] 全文索引与档案表不一致（索引 ${f} / 档案 ${a}），正在重建…`);
      db.exec("INSERT INTO archives_fts(archives_fts) VALUES('rebuild')");
      const after = db.prepare('SELECT COUNT(*) AS c FROM archives_fts').get().c;
      console.log(`[索引自检] 重建完成，当前索引 ${after} 条`);
    }
  } catch (e) {
    console.warn('[索引自检] 跳过（不影响使用）：' + e.message);
  }
}

function seed(db) {
  const now = new Date().toISOString();

  // 分类树
  const catCount = db.prepare('SELECT COUNT(*) AS c FROM categories').get().c;
  if (catCount === 0) {
    const insTop = db.prepare('INSERT INTO categories(parent_id,name,code,level,sort_no) VALUES(NULL,?,?,1,?)');
    const insSub = db.prepare('INSERT INTO categories(parent_id,name,code,level,sort_no) VALUES(?,?,?,2,?)');
    SEED_CATEGORIES.forEach((top, ti) => {
      const r = insTop.run(top.name, top.code, ti + 1);
      const pid = Number(r.lastInsertRowid);
      (top.children || []).forEach((c, ci) => insSub.run(pid, c.name, c.code, ci + 1));
    });
  }

  // 档案门类
  const typeCount = db.prepare('SELECT COUNT(*) AS c FROM archive_types').get().c;
  if (typeCount === 0) {
    const ins = db.prepare('INSERT INTO archive_types(code,name,retention,prefix,fields,sort_no) VALUES(?,?,?,?,?,?)');
    SEED_TYPES.forEach((t, i) => ins.run(t.code, t.name, t.retention, t.code + '-', JSON.stringify(t.fields), i + 1));
  }

  // 默认管理员
  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) {
    const { salt, hash } = hashPassword('admin123');
    db.prepare(`INSERT INTO users(username,display_name,password_hash,password_salt,role,department,status,must_change,created_at)
                VALUES(?,?,?,?,'admin',?,'active',1,?)`)
      .run('admin', '系统管理员', hash, salt, '档案室', now);
  }

  // v4.30.5：老库一次性补入「养护档案」「安全生产检查」门类与分类。
  // 排水、污水处理单位的主业是管网、农污与污水厂的养护，也常被查安全，
  // 出厂清单里缺这两类，每台机器都得手工加一遍；按 meta 标记只补一次，
  // 用户之后自己删掉也不会再长回来。
  const yhSeeded = db.prepare("SELECT value FROM meta WHERE key='seed.v4305_yh'").get();
  if (!yhSeeded) {
    const insType = db.prepare('INSERT INTO archive_types(code,name,retention,prefix,fields,sort_no) VALUES(?,?,?,?,?,?)');
    const insTop = db.prepare('INSERT INTO categories(parent_id,name,code,level,sort_no) VALUES(NULL,?,?,1,?)');
    const insSub = db.prepare('INSERT INTO categories(parent_id,name,code,level,sort_no) VALUES(?,?,?,2,?)');
    ['YH', 'AQ'].forEach((code) => {
      const hasType = db.prepare('SELECT id FROM archive_types WHERE code=?').get(code);
      if (!hasType) {
        const t = SEED_TYPES.find((x) => x.code === code);
        const maxSort = Number(db.prepare('SELECT COALESCE(MAX(sort_no),0) AS m FROM archive_types').get().m) + 1;
        insType.run(t.code, t.name, t.retention, t.code + '-', JSON.stringify(t.fields), maxSort);
      }
      const hasCat = db.prepare('SELECT id FROM categories WHERE code=?').get(code);
      if (!hasCat) {
        const top = SEED_CATEGORIES.find((c) => c.code === code);
        const topSort = Number(db.prepare('SELECT COALESCE(MAX(sort_no),0) AS m FROM categories WHERE parent_id IS NULL').get().m) + 1;
        const r = insTop.run(top.name, top.code, topSort);
        const pid = Number(r.lastInsertRowid);
        (top.children || []).forEach((c, ci) => insSub.run(pid, c.name, c.code, ci + 1));
      }
    });
    db.prepare("INSERT OR REPLACE INTO meta(key,value) VALUES('seed.v4305_yh',?)").run(now);
  }

  // v27：新库此时门类才齐，这里补保管期限表初始行（老库在迁移里已播过，函数内含幂等判断）
  try { seedRetentionSchedule(db, now); } catch (e) {
    console.warn('[初始化] 保管期限表初始行跳过：' + e.message);
  }
}

module.exports = {
  openDatabase, hashPassword, verifyPassword, SEED_CATEGORIES, SEED_TYPES, SCHEMA_VERSION,
  repairFtsIndex, RETENTION_MAP, migrateToV2, migrateToV4, migrateToV5, migrateToV6, migrateToV7, migrateToV8, migrateToV9, migrateToV10, migrateToV11, migrateToV12, backfillArchiveNumbers,
};
