﻿/**
 * 档案管理系统 REST API
 * 所有接口统一返回 { ok: true, data } 或 { ok: false, error }
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { makeApi } = require('./lib/q');
const { ok, fail, readJson, parseCookies, setCookie, clientIp, toCsv, mimeOf, contentDisposition } = require('./lib/http');
const { parseMultipart } = require('./lib/multipart');
const storage = require('./lib/storage');
const { saveArchiveFile, absPath, removeStored, dirStats, sha256 } = storage;
// v4.26.5：「用本机默认程序打开附件」要用它启动系统程序（Excel/Word/看图/PDF 阅读器）。
const { execFile } = require('node:child_process');
const { can, ROLE_LEVEL, SESSION_TTL_MS } = require('./lib/auth');
const policy = require('./lib/policy');
const audit = require('./lib/audit');
const loginGuard = require('./lib/login-guard');
const detection = require('./lib/detection');
const licenseLib = require('./lib/license');
const auditAnchor = require('./lib/audit-anchor');
const metadata = require('./lib/metadata');
const archiveStamp = require('./lib/archive-stamp');
const watermark = require('./lib/watermark');
const { hashPassword, verifyPassword, RETENTION_MAP } = require('./db');
const { ZipWriter } = require('./lib/zip');
const numbering = require('./lib/numbering');
const importer = require('./lib/importer');
const qrcode = require('./lib/qrcode');
const textExtract = require('./lib/text-extract');
const pinyinLib = require('./lib/pinyin');
const ocrLib = require('./lib/ocr');
const { lanIPv4List, isLoopbackHost } = require('./lib/net');
const archiveQrLib = require('./lib/archive-qr');
const boxQrLib = require('./lib/box-qr');
const pythonQrLib = require('./lib/python-qr');
const qrContent = require('./lib/qr-content');
const scanParse = require('./lib/scan-parse');
const pdfInfo = require('./lib/pdf-info');
const queryExpr = require('./lib/query-expr');
// v4.27.0：手机号找回口令用的短信通道（零依赖，可换阿里云/腾讯云/通用 HTTP）
const smsLib = require('./lib/sms');
const mailLib = require('./lib/mail');

/** 生成检索命中片段（关键词前后各取一段上下文） */
function makeSnippet(content, kw, span = 60) {
  const s = String(content || '');
  const idx = s.toLowerCase().indexOf(String(kw).toLowerCase());
  if (idx < 0) return s.replace(/\s+/g, ' ').slice(0, span * 2);
  const start = Math.max(0, idx - span);
  const end = Math.min(s.length, idx + String(kw).length + span);
  return (start > 0 ? '…' : '') + s.slice(start, end).replace(/\s+/g, ' ')
    + (end < s.length ? '…' : '');
}

/** HTML 转义（打印视图用） */
/**
 * 手机扫码落地页外壳。
 * 面向手机屏幕，字号大、无依赖、不引外部资源（内网可能没有外网）。
 */
function scanShell(title, inner) {
  return `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title>
<style>
  * { box-sizing:border-box; -webkit-text-size-adjust:100%; }
  body { margin:0; padding:16px; font-family:"Microsoft YaHei","Source Han Sans SC",
         "Noto Sans CJK SC","WenQuanYi Micro Hei","PingFang SC",sans-serif;
         color:#111; background:#f4f6f9; font-size:16px; line-height:1.7; }
  .card { background:#fff; border-radius:12px; padding:16px; box-shadow:0 1px 4px rgba(0,0,0,.08); }
  h1 { font-size:19px; margin:0 0 12px; color:#1b4d8f; }
  .kv { display:flex; padding:8px 0; border-bottom:1px solid #eef1f5; }
  .kv:last-child { border-bottom:0; }
  .kv .k { width:82px; color:#6b7280; flex:none; }
  .kv .v { flex:1; word-break:break-all; font-weight:600; }
  .big { font-size:22px; font-weight:700; letter-spacing:1px; margin-bottom:8px; word-break:break-all; }
  .muted { color:#6b7280; font-size:14px; }
  .list { margin:12px 0 0; padding:0; list-style:none; }
  .list li { padding:7px 0; border-bottom:1px dashed #e5e7eb; font-family:Consolas,monospace; font-size:15px; }
  .list li:last-child { border-bottom:0; }
  .tag { display:inline-block; padding:1px 8px; border-radius:10px; background:#e8f0fb;
         color:#1b4d8f; font-size:12px; font-family:inherit; margin-left:6px; }
  .foot { text-align:center; color:#9ca3af; font-size:12px; margin:14px 0 4px; }
</style></head><body>
${inner}
<div class="foot">档案管理系统 · 手机扫码</div>
</body></html>`;
}

function esc(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function fmtDay(iso) {
  return iso ? String(iso).slice(0, 10) : '';
}

/**
 * 打印视图外壳：A4 版式 + 打印样式。
 * auto=1 时进入页面即调起打印对话框。
 */
function printShell(title, inner, autoPrint) {
  return `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>${title}</title>
<style>
  @page { size: A4; margin: 14mm 12mm; }
  * { box-sizing: border-box; }
  body { font-family: "Microsoft YaHei","Source Han Sans SC","Noto Sans CJK SC",
         "WenQuanYi Micro Hei","PingFang SC",SimSun,sans-serif;
         color:#111; margin:0; padding:10px 14px; }
  .print-head { text-align:center; margin-bottom:10px; }
  .print-head h1 { font-size:20px; letter-spacing:4px; margin:0 0 8px; font-weight:600; }
  .print-head .meta { font-size:12px; line-height:1.8; }
  .print-table { width:100%; border-collapse:collapse; font-size:12px; }
  .print-table th, .print-table td { border:1px solid #333; padding:4px 6px; text-align:left; }
  .print-table th { background:#f0f0f0; text-align:center; font-weight:600; }
  .print-table td:nth-child(1) { text-align:center; }
  .sign-row { display:flex; justify-content:space-between; margin-top:26px; font-size:12.5px; flex-wrap:wrap; gap:10px; }
  .page-break { page-break-before: always; }
  /* ---- 归档章（DA/T 22—2015 §5.4.4：全宗号/年度/保管期限/件号/页数，机构(问题)为选择项）----
     用章红色是为了"像一枚章"，但它毕竟不是真印章：实体件上仍须按单位规定加盖红章。
     这里生成的是**电子文件上应当标识的那一份**（§5.4.5 允许由系统生成归档章样式）。 */
  .archive-stamp { display:inline-block; color:#c0392b; border:1.4px solid #c0392b; border-radius:2px; padding:0; }
  .archive-stamp .stamp-table { border-collapse:collapse; }
  .archive-stamp .stamp-cell { border:0.7px solid #c0392b; padding:2px 8px; min-width:74px; text-align:center; }
  .archive-stamp .stamp-label { font-size:9px; letter-spacing:1px; opacity:.85; }
  .archive-stamp .stamp-value { font-size:13px; font-weight:600; letter-spacing:1px; min-height:17px; }
  .archive-stamp-large .stamp-cell { min-width:104px; padding:4px 12px; }
  .archive-stamp-large .stamp-label { font-size:11px; }
  .archive-stamp-large .stamp-value { font-size:18px; min-height:24px; }
  .archive-stamp .stamp-empty .stamp-value { color:#e08a80; }
  .stamp-warn { font-size:10.5px; color:#b03030; margin-top:3px; }
  .stamp-sheet { margin-top:8px; }
  .stamp-sheet-row { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px; }
  .stamp-sheet-item { border:1px dashed #bbb; padding:6px; }
  .stamp-note { font-size:11px; color:#555; margin-top:6px; }
  /* ---- 备考表（DA/T 22—2015 §6.5：盒内文件情况说明、整理人、整理日期、检查人、检查日期）---- */
  .beikao { border:1px solid #333; padding:0; margin-top:10px; }
  .beikao h2 { font-size:16px; letter-spacing:6px; text-align:center; margin:0; padding:8px 0;
               border-bottom:1px solid #333; font-weight:600; }
  .beikao .bk-body { padding:10px 12px; font-size:12.5px; line-height:1.9; }
  .beikao .bk-note { min-height:120px; border:1px solid #666; padding:6px 8px; white-space:pre-wrap; margin:4px 0 10px; }
  .beikao .bk-sign { display:flex; flex-wrap:wrap; gap:18px 40px; margin-top:6px; }
  .beikao .bk-line { border-bottom:1px solid #333; display:inline-block; min-width:150px; padding:0 4px; }
  .spine-wrap { display:flex; gap:12px; justify-content:center; flex-wrap:wrap; margin-top:16px; }
  /* 盒脊宽度 208 → 216px、间距 16 → 12px，目的是把二维码的像素预算从 204 提到 212。
     为什么非要这 8px：二维码内容里现在带了盒号（扫出来一眼能看到编号），
     格数从 49 涨到 53 —— 53×4=212，预算不到 212 就只能退到每模块 3px（0.79mm）。
     三张 216px + 两道 12px 间距 = 672px，A4 去掉页边距后可用约 675px，刚好放得下。
     换句话说：档号进网址这个需求，靠排版调整就吃掉了，不牺牲打印尺寸。 */
  .spine { width:216px; height:430px; border:1px dashed #999; border-radius:4px;
           display:flex; flex-direction:column; align-items:center; justify-content:space-between;
           padding:12px 2px; }
  .spine-title { font-size:12px; writing-mode:vertical-rl; letter-spacing:2px; }
  .spine-box { font-size:16px; font-weight:700; writing-mode:vertical-rl; letter-spacing:2px; }
  /* 二维码打印尺寸：SVG 已按整数模块边长生成，这里绝不能再缩放，
     否则模块边缘被插值糊掉，手机就扫不出了。宽度自适应，按原生尺寸打印。 */
  .spine-qr svg { width:auto; height:auto; max-width:100%; display:block; }
  .spine-loc { font-size:11px; writing-mode:vertical-rl; }
  /* 单件档案二维码标签：A4 一页 12 枚（3 列 × 4 行） */
  .label-wrap { display:flex; flex-wrap:wrap; gap:6px; margin-top:10px; }
  .qr-label { width:60mm; min-height:58mm; border:1px dashed #999; border-radius:3px;
              padding:3mm; display:flex; flex-direction:column; align-items:center;
              justify-content:space-between; text-align:center; page-break-inside:avoid; }
  .qr-label .lbl-head { font-size:11px; color:#333; letter-spacing:2px; }
  .qr-label .lbl-code { font-size:13px; font-weight:700; font-family:Consolas,monospace; }
  .qr-label .lbl-title { font-size:11px; line-height:1.35; max-height:2.7em; overflow:hidden; }
  /* 标签上的二维码：**物理尺寸由服务端按模块数算好后用内联 mm 写进来**，这里绝不能再写死。
     踩过的坑：写死 30mm 时，内容还是短档号（37 格）每模块 0.81mm 勉强能扫；
     内容换成落地页网址后变成 61 格，30mm 只剩 0.49mm/模块 —— 实测扫不出来，
     而且 915px 的图被浏览器压到 113px（8.1 倍降采样），模块会整行丢像素。 */
  .qr-label .lbl-qr { image-rendering:pixelated; max-width:100%; }
  .qr-label .lbl-foot { font-size:10px; color:#555; }
  .muted { color:#888; }
  .toolbar { position:sticky; top:0; background:#fff; padding:8px 0; border-bottom:1px solid #ddd; margin-bottom:12px; }
  .toolbar button { padding:7px 16px; font-size:13px; cursor:pointer; border:1px solid #1b4d8f;
                    background:#1b4d8f; color:#fff; border-radius:6px; font-family:inherit; }
  .toolbar button.ghost { background:#fff; color:#1b4d8f; }
  @media print { .toolbar { display:none; } body { padding:0; } .spine { page-break-inside: avoid; } }
</style></head><body>
<div class="toolbar">
  <button onclick="window.print()">打印 / 另存为 PDF</button>
  <button class="ghost" onclick="window.close()">关闭</button>
</div>
${inner}
${autoPrint ? '<script>window.addEventListener("load",function(){setTimeout(function(){window.print()},300)})</script>' : ''}
</body></html>`;
}

const RETENTIONS = ['永久', '定期30年', '定期10年', '定期5年', '长期'];
const SECRET_LEVELS = ['公开', '内部', '秘密', '机密'];

/**
 * 鉴定扩展（v4.10.0）的枚举 —— 三鉴共用一套"结论"词汇表。
 *
 * 为什么要把这三个数组写在最上面：鉴定的结论是**法定表述**，
 * 界面上写"销毁"而清册上写"建议销毁"、或者把"控制使用"写成"不开放"，
 * 都会让打印出来的文据对不上规范用语。词汇表只此一份，前后端都从这里取。
 */
const APPRAISAL_KINDS = ['价值鉴定', '密级鉴定', '开放鉴定'];
/** 价值鉴定：DA/T 22—2015 / 国家档案局令第 8 号 */
const VALUE_DECISIONS = ['延长保管期限', '继续保管', '建议销毁'];
/** 密级鉴定：《保守国家秘密法》第十九、二十条 —— 期满自行解密；需延长的应在期满前重新确定 */
const SECRET_DECISIONS = ['解密', '降低密级', '延长保密期限', '维持原密级'];
/** 开放鉴定：《档案法》第二十七、二十八条 —— 开放 / 部分开放 / 控制使用（延期开放） */
const OPEN_DECISIONS = ['开放', '部分开放', '控制使用'];
/** 档案开放状态（archives.open_state 的取值域，与建表默认值一致） */
const OPEN_STATES = ['未鉴定', '开放', '部分开放', '控制使用'];
/** 保密期限的常见取值；也可自由填 `N年` */
const SECRET_TERMS = ['10年', '20年', '30年', '长期', '解密条件成就前'];
/** 《档案法》第二十七条：馆藏档案一般自形成之日起满 25 年向社会开放 */
const OPEN_PUBLIC_YEARS = 25;
/** 保密期限届满前的提醒窗口（天）：留出组织鉴定的时间 */
const SECRET_WARN_DAYS = 90;
const CARRIERS = ['纸质', '电子', '纸质+电子', '照片', '录音录像', '实物'];
const STATUSES = ['在库', '借出', '待整理', '待销毁', '已销毁'];
/**
 * 角色与角色名 —— **必须指向 policy，不许在本文件再写一份**（v4.16.3 修正）。
 *
 * 这里原本硬写着一份只有 3 个旧角色的副本（admin/clerk/reader），
 * 而 lib/policy.js 里才是权威的 6 个角色（含三员 sysadmin/secadmin/auditor）。
 * 两份表并存造成的后果是**实打实的**：
 *   · 合规体检的"三员尚未配齐"提示变成「undefined、undefined、undefined 暂无账号」
 *     （因为 THREE_ROLES 里的三个键在这份旧表里都不存在）；
 *   · 新增/修改用户的审计日志写成「undefined｜密级上限=机密」——
 *     审计日志里出现 undefined，对档案系统来说是要出事的；
 *   · 三员账号在顶栏、用户列表里显示成英文代号 secadmin 而不是「系统安全保密员」。
 * lib/auth.js 早就通过 re-export 复用 policy 了，只有这里漏了 —— 现在补齐，
 * 全系统角色定义只剩 policy 一处。
 */
const ROLES = policy.ROLES;
const ROLE_NAMES = policy.ROLE_NAMES;

/**
 * 「我的权限」——把服务端的权限矩阵如实下发给前端（v4.17.0）。
 *
 * 为什么必须由服务端下发、而不是前端自己判断角色：
 * 前端此前散布着 60 处 `role === 'admin'`、`role !== 'reader'` 这类零散判断，
 * 等于把权限规则**又实现了一遍**，而且实现错了三处（都实测复现过）：
 *   · 系统管理员（sysadmin）登录后系统设置**全是灰的** —— 可那正是他的本职；
 *   · 安全审计员能看到档案著录、导入导出等全部菜单，点进去才发现没权限；
 *   · 改用户时的角色下拉只有 3 个旧角色，**根本选不到三员**。
 * 规则只该有一处（lib/policy.js 的 can()），前端只做"显示/隐藏"这一件事。
 * 这样界面与实际权限**不可能对不上**：界面显示什么，接口就允许什么。
 */
const UI_ACTIONS = [
  'archive:create', 'archive:read', 'archive:update', 'archive:delete', 'archive:destroy',
  'file:upload', 'file:delete', 'file:download',
  'loan:apply', 'loan:approve', 'loan:return',
  'appraisal:run', 'appraisal:approve', 'secret:classify',
  'box:manage', 'transfer:manage',
  'detection:run', 'detection:view',
  'log:view', 'audit:view', 'security:manage', 'system:manage',
  'todo:read', 'todo:handle', 'scheduler:view', 'scheduler:run',
  'user:manage', 'meta:manage', 'backup',
];

/**
 * 左侧菜单项 → 需要哪个动作（数组内是"或"关系；空数组 = 所有登录用户都看得到）。
 *
 * 刻意与 policy.can 的动作用同一套词汇：**界面显示什么，接口就允许什么**。
 * 例如"数据体检"要 archive:read —— 安全审计员按 policy 不能读档案正文，
 * 那他也就不该看到这个会列出档案题名的页面。
 */
const NAV_ACTIONS = {
  workbench: [],
  dashboard: [],
  todos: ['todo:read'],
  archives: ['archive:read'],
  textsearch: ['archive:read'],
  scan: ['archive:read'],
  create: ['archive:create'],
  retention: ['appraisal:run'],
  storage: ['box:manage'],
  transfer: ['transfer:manage'],
  quality: ['archive:read'],
  detection: ['detection:view'],
  compliance: ['security:manage', 'audit:view'],
  backup: ['backup'],
  import: ['archive:create'],
  loans: ['loan:apply'],
  downloads: ['loan:approve'],
  logs: ['log:view'],
  manage: ['user:manage', 'system:manage', 'security:manage'],
};

/** 计算某个账号的动作集合与可见菜单 */
function myAccess(user) {
  const actions = {};
  for (const a of UI_ACTIONS) actions[a] = policy.can(user, a);
  const views = Object.keys(NAV_ACTIONS).filter((v) => {
    const need = NAV_ACTIONS[v];
    return !need.length || need.some((a) => actions[a]);
  });
  return { actions, views };
}

/**
 * 登录页的「身份」下拉（v4.18.0）。
 *
 * 使用者要的是：**进门这一步就选定身份**，而不是进去以后再谈角色。
 * 目前对外只暴露两种身份：
 *   · 档案管理员 —— 日常那把钥匙，所有功能都能做（role = admin）
 *   · 其他人员   —— 只能检索、申请借阅（role = reader）
 *
 * 三员（sysadmin/secadmin/auditor）与 clerk 仍然完整保留在 policy 里、账号也还在库里，
 * 只是**不出现在任何界面上** —— 哪天上级要求三员分立，不用重做，把这张表加一行即可。
 *
 * ⚠ 它**不是安全边界**：真正拦住人的始终是口令。身份下拉的作用是
 * ① 让人明确知道自己在以什么身份进门；② 选错身份时立刻拒绝，而不是进去后才发现权限不对。
 * 所以 LoginIdentityOK 只做"一致性校验"，绝不因为它是 admin 就放宽任何东西。
 */
const LOGIN_IDENTITIES = [
  { key: 'manager', label: '档案管理员', role: 'admin' },
  { key: 'staff', label: '其他人员', role: 'reader' },
];

/** 界面上一律只出现这两种身份（用户管理、首次向导的角色下拉都用它） */
const IDENTITIES = LOGIN_IDENTITIES.map((x) => ({ key: x.key, label: x.label, role: x.role }));

/**
 * 全宗信息的出厂占位值（v4.20.0 提到模块级）。
 *
 * 原先是写在「首次使用向导」状态接口里的局部常量。向导页已经删掉，
 * 但**这条判断不能跟着消失**：全宗号若还是 Z001，之后每一件档案的档号都会带着 Z001，
 * 而档号印在归档章、盒脊、报表上，改起来要一件一件返工。
 * 所以工作台保留一条不阻塞的提醒，并与下面这个常量共用同一份判断 ——
 * 两处各写一份的话迟早会分叉。
 */
const FACTORY_UNIT_CODE = 'Z001';
const FACTORY_UNIT_NAME = '本单位';

const MAX_UPLOAD_MB = 512;
/**
 * 上传附件后自动跑归档环节四性检测的附件总量上限。
 * 自动检测要重读附件重算摘要（这正是"固化信息校验"的意义），
 * 对超大附件代价明显，所以超过此上限就跳过并明确告知，而不是悄悄不做。
 */
const AUTO_DETECT_MAX_BYTES = 64 * 1024 * 1024;

function nowIso() { return new Date().toISOString(); }
function today() { return nowIso().slice(0, 10); }

/** 中文全文检索关键字清理：FTS5 trigram 下用双引号包成短语，短词走 LIKE */
function ftsPhrase(kw) {
  return '"' + String(kw).replace(/"/g, '""') + '"';
}

function createApi(ctx) {
  const { db, filesRoot, sessions, appRoot, config } = ctx;
  const q = makeApi(db);

  /**
   * 短信通道实例（v4.27.0）。
   * 配置读 `server/config.json` 的 `sms` 段，环境变量可覆盖（见 lib/sms.js 文件头）。
   * 没配置也能正常启动 —— 登录页会明确告诉使用者"短信通道未配置，请联系管理员"，
   * 而不是给出一个"验证码已发送"却永远收不到短信的死胡同。
   */
  const sms = smsLib.createSms((config && config.sms) || {});

  /**
   * 邮件通道（v4.31.0）。
   * 与短信同理：没配置也能启动，登录页会明确说"邮件通道未配置"，
   * 而不是给出一个"验证码已发送"却永远收不到信的死胡同。
   */
  const mail = mailLib.createMail((config && config.mail) || {});

  /**
   * 离线授权状态（v4.33.0）。
   *
   * 判定一次、缓存在内存里：授权文件不会在运行中被频繁改动，改了就「重新读取」或重启。
   * 校验失败**只降级为只读**，绝不锁库 —— 档案数据属于国家和单位，
   * 授权到期或换机器时，用户必须仍能把档案查出来、导出去、备份走。
   */
  const dataDir = (config && config.dataDir) || path.dirname(filesRoot);
  let lic = licenseLib.checkLicense({ dataDir, explicit: config && config.licenseFile });
  const licenseView = () => licenseLib.publicView(lic);
  const isReadOnly = () => !!lic.readOnly;

  // 只读模式仍必须放行的写接口：登录、改密、登出、重新读取授权。
  // 少放一个，用户就会被"授权过期后连密码都改不了"卡死。
  const READONLY_ALLOW = [
    '/api/login', '/api/logout', '/api/me/password', '/api/license/reload',
    '/api/login/sms', '/api/login/email', '/api/login/code', '/api/forgot', '/api/forgot/code',
  ];


  // ---------- 通用小工具 ----------

  /**
   * 写入审计日志（含哈希链）。
   *
   * DA/T 92—2022 §9.5 要求审计跟踪记录**行为描述、行为步骤、行为对象、行为日期、行为人员**。
   * 对应关系：action=行为描述、step=行为步骤（多步流程用）、target=行为对象、
   * at=行为日期、username/user_id=行为人员。
   *
   * 每条记录携带前一条的哈希（prev_hash）并算出自身哈希（hash），构成哈希链：
   * 事后修改、删除或插入任何一条历史记录，都会让链在该处断开，
   * `/api/logs/verify` 能精确报出断点。这是"日志具备证据价值"的前提。
   *
   * @param {object|null} user 操作者（登录失败时可能为 null，此时只有 username）
   * @param {string} action 行为描述
   * @param {string} target 行为对象
   * @param {string} detail 细节
   * @param {string} ip 来源 IP
   * @param {{step?:string,result?:string,category?:string,username?:string}} extra
   */
  function log(user, action, target, detail, ip, extra = {}) {
    // 统一走 lib/audit 的唯一实现：日志链只能有一处写入逻辑，
    // 任何一处自己拼 INSERT，都会把链断开成"疑似篡改"的假警报。
    audit.appendLog(db, {
      at: nowIso(),
      user_id: user ? user.id : null,
      username: user ? user.username : (extra.username || ''),
      action,
      target: target || '',
      detail: detail || '',
      ip: ip || '',
      step: extra.step || '',
      result: extra.result || '成功',
      category: extra.category || '',
    });
  }

  function userRow(id) {
    return q.get(
      'SELECT id,username,display_name,role,clearance,department,phone,status,must_change,created_at FROM users WHERE id=?', id,
    );
  }

  function archiveRow(id) {
    const a = q.get(`SELECT a.*, c.name AS category_name, c.code AS category_code,
                            u.display_name AS creator_name
                     FROM archives a
                     LEFT JOIN categories c ON c.id = a.category_id
                     LEFT JOIN users u ON u.id = a.created_by
                     WHERE a.id = ?`, id);
    if (!a) return null;
    a.extra = safeParse(a.extra, {});
    // 带上 sha256：用户需要能自行核对文件完整性，四性检测的 fixity 也读它；
    // 不含 rel_path 等内部存储路径。v4.9.0 起正文替换留痕要靠它做前后比对。
    a.files = q.all(`SELECT id,original_name,stored_name,mime,size,sha256,kind,sort_no,created_at,
                            pages,dpi,color_mode,device,scanned_at
                       FROM files WHERE archive_id=? ORDER BY sort_no, id`, id);
    a.loans = q.all(`SELECT l.*, u.display_name AS user_name FROM loans l
                     LEFT JOIN users u ON u.id=l.user_id WHERE l.archive_id=? ORDER BY l.id DESC`, id);
    // 过程接收归属：详情页要能直接看到"这个项目、哪一批、什么时候交的"
    a.project = a.project_id
      ? q.get('SELECT id,project_no,name,kind,status FROM projects WHERE id=?', a.project_id) : null;
    a.batch = a.batch_id
      ? q.get('SELECT id,batch_no,title,stage,received_at,status FROM intake_batches WHERE id=?', a.batch_id) : null;
    return a;
  }

  // ---------- 密级管控（数据层兜底）----------
  //
  // 为什么必须做在数据层而不是"每个接口记得检查一下"：
  // v3.4.7 的 serveFile() 明明查出了 a.secret_level，却从未据此拦截，
  // 结果是标注"机密"的档案，任何 reader 账号都能检索、预览、下载、打印。
  // 结论：密级过滤必须与「取档案行」这个动作绑定，而不是与某个接口绑定。

  /** 是否启用密级管控（设置项 security.enforce_secret，默认开启） */
  function enforceSecret() {
    return String(numbering.getSetting(q, 'security.enforce_secret', '1')) !== '0';
  }

  /** 当前用户的密级作用域；sql 自带前导 " AND "，params 为允许的密级列表 */
  function secretScope(user, col = 'a.secret_level') {
    return policy.secretFilter(user, col, enforceSecret());
  }

  /**
   * 单条档案可见性判定。不可见时统一按 **404** 回应，而不是 403：
   * 403 等于告诉对方"这份档案存在"，而涉密档案的**存在性本身就是需要保护的信息**。
   * 越权尝试会写审计日志，便于安全审计员发现。
   *
   * @returns {boolean} true = 可见，可继续处理；false = 已响应错误，调用方必须立即 return
   */
  function assertArchiveVisible(req, res, user, row) {
    if (!row) { fail(res, 404, '档案不存在或已删除'); return false; }
    if (policy.canSeeSecret(user, row.secret_level, enforceSecret())) return true;
    // 件级授权（V4.32.0）：超出本人密级上限/部门范围的件，可被逐件授权放行。
    // 口径是"密级 × 部门 × 件级授权"三者合成 —— 授权只放宽到这一件，不外溢到同类。
    const grant = validGrantOf(user, row.id);
    if (grant) {
      try {
        log(user, '件级授权放行', String(row.archive_code || row.id),
          `档案密级=${row.secret_level}，凭授权 #${grant.id} 查阅${grant.expires_at ? '，到期 ' + grant.expires_at : ''}`,
          clientIp(req), { result: '成功', category: 'security', step: '件级权限' });
      } catch (_) { /* 审计失败不影响放行 */ }
      return true;
    }
    try {
      log(user, '越权访问被拒', String(row.archive_code || row.id),
        `档案密级=${row.secret_level}，账号密级上限=${user.clearance || policy.defaultClearance(user.role)}（按角色默认）`,
        clientIp(req),
        // 非授权访问属于标准明确要求记录的安全事件（档办发〔2017〕3号第四十三条）
        { result: '拒绝', category: 'security', step: '密级鉴别' });
    } catch (_) { /* 审计失败不影响拒绝 */ }
    fail(res, 404, '档案不存在或已删除');
    return false;
  }

  /**
   * 按 id 取档案并做密级校验；不可见/不存在时返回 null 且**已经响应**。
   */
  function loadVisibleArchive(req, res, user, id) {
    const row = q.get('SELECT * FROM archives WHERE id=?', Number(id));
    return assertArchiveVisible(req, res, user, row) ? row : null;
  }

  function safeParse(s, dft) {
    try { const v = JSON.parse(s); return v === null ? dft : v; } catch (_) { return dft; }
  }

  function mustStr(v, max = 2000) {
    return v === null || v === undefined ? '' : String(v).slice(0, max);
  }

  function numOr(v, dft) {
    const n = Number(v);
    return Number.isFinite(n) ? n : dft;
  }

  /**
   * 规范化账号邮箱（v4.30.9）。
   *
   * 只做"能不能投递"的最低要求校验：本地部分 + @ + 域名 + 至少两位后缀。
   * 不做唯一性校验 —— 同一科室共用一个邮箱是常见做法，重复不影响按账号投递；
   * 也不做 DNS/MX 验证 —— 内网环境往往连不上外网 DNS，那会把正确地址误判成非法。
   *
   * @returns {string} 规范化后的邮箱；不合法返回空串（调用方据此回 400）
   */
  function normalizeEmail(v) {
    const s = String(v || '').trim().toLowerCase();
    if (!s) return '';
    if (s.length > 120) return '';
    return /^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(s) ? s : '';
  }

  /** 生成档案号：门类前缀 + 年度 + 4 位流水 */
  function nextArchiveCode(typeCode, year) {
    const t = q.get('SELECT code,name FROM archive_types WHERE code=?', typeCode);
    if (!t) throw Object.assign(new Error('未知的档案门类：' + typeCode), { statusCode: 400 });
    const y = String(year || new Date().getFullYear());
    const key = `seq:${t.code}:${y}`;
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0);
    let n = cur;
    let code;
    // 保证唯一：若人工已占用同名档案号则继续自增
    for (let i = 0; i < 9999; i++) {
      n = n + 1;
      code = `${t.code}-${y}-${String(n).padStart(4, '0')}`;
      const exists = q.scalar('SELECT id FROM archives WHERE archive_code=?', code);
      if (!exists) break;
    }
    q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(n));
    return code;
  }

  function peekNextCode(typeCode, year) {
    const t = q.get('SELECT code FROM archive_types WHERE code=?', typeCode);
    if (!t) return '';
    const y = String(year || new Date().getFullYear());
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', `seq:${t.code}:${y}`) || 0);
    return `${t.code}-${y}-${String(cur + 1).padStart(4, '0')}`;
  }

  function nextLoanNo() {
    const d = new Date();
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    const key = `loanseq:${day}`;
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0) + 1;
    q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(cur));
    return `JY${day}-${String(cur).padStart(3, '0')}`;
  }

  /**
   * 借阅到期处理：
   *  1) 应还日期已过的“借出”，按设置自动归还（电子档案借阅到期自动归还）
   *  2) 其余超期未还的标记为逾期
   * 返回本次自动归还的数量
   */
  function processLoanDue() {
    const t = today();
    let autoReturned = 0;
    if (numbering.getSetting(q, 'loans.auto_return', '1') === '1') {
      const rows = q.all(`SELECT id, archive_id FROM loans
                          WHERE status='已批准' AND mode='借出' AND due_date<>'' AND due_date < ?`, t);
      for (const l of rows) {
        q.run(`UPDATE loans SET status='已归还', return_at=?, return_note=?, returned_by_system=1 WHERE id=?`,
          nowIso(), '系统按到期日自动归还', l.id);
        autoReturned++;
      }
      if (autoReturned) {
        for (const l of rows) syncArchiveStatus(l.archive_id);
        // 系统自动动作也必须进同一条审计链（这里原先是一段自拼的 INSERT，
        // 不进哈希链，直接把链断在这里 —— 校验会把它误报成篡改）
        log(null, '借阅到期自动归还', String(autoReturned),
          `${autoReturned} 条借出记录到期自动归还`, '',
          { username: 'system', step: '到期处理', category: 'use' });
      }
    }
    // 查阅/复制类过期只标记逾期，涉及实物归还的已在上一步处理
    const overdue = q.run(`UPDATE loans SET status='逾期'
                           WHERE status='已批准' AND due_date<>'' AND due_date < ?`, t);
    return { autoReturned, markedOverdue: overdue.changes };
  }

  /** 借出到期未还自动置为逾期 */
  function refreshOverdue() {
    const t = today();
    const r = q.run(`UPDATE loans SET status='逾期'
                     WHERE status='已批准' AND mode='借出' AND due_date<>'' AND due_date < ?`, t);
    return r.changes;
  }

  /** 归档附件在库状态维护：有未归还借出记录则标记为借出 */
  function syncArchiveStatus(archiveId) {
    const active = q.scalar(`SELECT COUNT(*) FROM loans
                             WHERE archive_id=? AND mode='借出' AND status IN ('已批准','逾期')`, archiveId);
    const a = q.get('SELECT status FROM archives WHERE id=?', archiveId);
    if (!a) return;
    if (active > 0 && a.status === '在库') {
      q.run('UPDATE archives SET status=?, updated_at=? WHERE id=?', '借出', nowIso(), archiveId);
    } else if (active === 0 && a.status === '借出') {
      q.run('UPDATE archives SET status=?, updated_at=? WHERE id=?', '在库', nowIso(), archiveId);
    }
  }

  // ---------- 认证 ----------

  function currentUser(req) {
    const cookies = parseCookies(req);
    const token = cookies.dsh_archive_token || req.headers['x-auth-token'];
    const s = sessions.get(token);
    if (!s) return null;
    const u = userRow(s.userId);
    if (!u || u.status !== 'active') return null;
    return u;
  }

  /**
   * 强制改密门禁（千问版 v4.30.8）：must_change=1 的账号只许 查自己/改密/登出。
   *
   * 原来这道门只存在于前端弹窗（app.js 的 changePasswordDialog），直接调 API
   * 可以长期沿用出厂口令 admin123 —— 前端拦截不是安全边界，服务端必须自己拦。
   * 放在 requireAuth 里而不是分发入口：requireAuth/requireRole/requireCan 是全部
   * 受保护接口的唯一鉴权通道，在这里拦一次就全覆盖；且只影响**已登录**请求，
   * /api/ping、二维码落地页这类匿名接口不受牵连。
   * 豁免三条路径是闭环所需：/api/me 让前端知道该弹改密框，/api/me/password 完成改密，
   * /api/logout 允许放弃。改密成功后 must_change 清零，门禁自然解除。
   */
  const MUST_CHANGE_EXEMPT = new Set(['/api/me', '/api/me/password', '/api/logout']);
  function mustChangeBlocked(req, res, u) {
    if (Number(u.must_change) !== 1) return false;
    let p = '';
    try { p = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); } catch (_) { p = String(req.url || '').split('?')[0]; }
    if (MUST_CHANGE_EXEMPT.has(p)) return false;
    fail(res, 403, '当前账号使用的是初始密码，请先修改密码后再使用系统', 'PASSWORD_CHANGE_REQUIRED');
    return true;
  }

  function requireAuth(req, res) {
    const u = currentUser(req);
    if (!u) { fail(res, 401, '未登录或登录已过期，请重新登录', 'AUTH_REQUIRED'); return null; }
    if (mustChangeBlocked(req, res, u)) return null;
    return u;
  }

  function requireRole(req, res, minRole) {
    const u = requireAuth(req, res);
    if (!u) return null;
    if ((ROLE_LEVEL[u.role] || 0) < ROLE_LEVEL[minRole]) {
      fail(res, 403, '当前账号权限不足（需要' + ROLE_NAMES[minRole] + '及以上）', 'FORBIDDEN');
      return null;
    }
    return u;
  }

  /**
   * 按**动作**授权（细粒度）。
   *
   * 与 requireRole 的区别：requireRole 只能表达「不低于某角色档位」，
   * 无法表达三员分立这种「只有某角色能做」的规则 —— 例如安全审计员档位不低，
   * 但绝不能修改安全策略。这类规则必须走动作级判定。
   */
  function requireCan(req, res, action, ctx = {}) {
    const u = requireAuth(req, res);
    if (!u) return null;
    if (!policy.can(u, action, ctx)) {
      fail(res, 403, '当前账号没有执行该操作的权限', 'FORBIDDEN');
      return null;
    }
    return u;
  }

  /** 三员分立是否启用 */
  function threeRolesOn() {
    return String(numbering.getSetting(q, 'security.three_roles', '0')) === '1';
  }

  // ---------- 登录防护与口令策略 ----------

  /** 当前生效的口令策略（读设置项） */
  function pwdPolicy() {
    return {
      minLength: Number(numbering.getSetting(q, 'security.password_min_length', '8')) || 8,
      requireComplexity: String(numbering.getSetting(q, 'security.password_require_complexity', '0')) === '1',
    };
  }

  /** 校验新口令，并给出可操作的拒绝原因 */
  function validateNewPassword(plain, username) {
    const pol = pwdPolicy();
    return loginGuard.checkPassword(plain, {
      minLength: pol.minLength,
      username,
      requireComplexity: pol.requireComplexity,
    });
  }

  // ---------- 手机号找回口令（v4.27.0）----------
  //
  // 为什么把它做成"验证码 → 自设新口令 → 才进系统"，而不是"验证码直接登录"：
  //   验证码是一次性、会转发、会截图的东西。让它等价于登录凭证，等于给每个账号配了一把
  //   可以随手传给别人的钥匙 —— 而档案系统里还有密级和三员分立。
  //   所以验证码只换一张**一次性的重置票据**，票据只能用来设新口令，用完即废。
  //   这样即使手机号被别人看到，对方也拿不到一个"长期有效的入口"。

  /** 读数值型设置项 */
  function smsNum(key, dft) {
    const n = Number(numbering.getSetting(q, key, String(dft)));
    return Number.isFinite(n) && n >= 0 ? n : dft;
  }

  /** 手机号找回总开关 */
  function smsEnabled() {
    return String(numbering.getSetting(q, 'security.sms_login', '1')) !== '0';
  }

  /**
   * 该角色能否走手机号找回。
   *
   * **三员一律不行**：三员分立的意义是"系统管理员、安全保密员、审计员互不兼任、互相牵制"。
   * 如果审计员能靠一条短信自己重置口令，那么掌握手机号的人就能接管审计岗 ——
   * 牵制关系当场失效。三员口令必须由本人当面申请、由另一位管理角色重置并留痕。
   */
  const SMS_BLOCKED_ROLES = new Set(['sysadmin', 'secadmin', 'auditor']);
  function smsEligible(user) {
    return !!user && user.status === 'active' && !SMS_BLOCKED_ROLES.has(user.role);
  }

  /**
   * 按手机号查账号。
   * 用全表匹配而不是只挑启用账号：停用账号若也占用同一个号，说明库里已有冲突数据，
   * 这时必须**宁可不让任何人找回**，也不能悄悄挑一个启用账号重置 —— 那可能改错人。
   * @returns {{user:object|null, conflict:boolean}}
   */
  function userByPhone(phone) {
    const rows = q.all("SELECT * FROM users WHERE phone=? AND phone<>''", phone);
    if (rows.length > 1) return { user: null, conflict: true };
    return { user: rows[0] || null, conflict: false };
  }

  /** 当天 0 点（本地时区）的 ISO 时间串，用于"每天最多发几条" */
  function startOfTodayIso() {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.toISOString();
  }

  /** 清理过期的验证码记录：保留 7 天，够查"谁在什么时候试过找回" */
  function pruneLoginCodes() {
    try {
      const before = new Date(Date.now() - 7 * 86400000).toISOString();
      q.run('DELETE FROM login_codes WHERE sent_at < ?', before);
    } catch (_) { /* 清理失败不影响主流程 */ }
  }

  /**
   * 登录成功后的统一应答。
   *
   * 抽出来是因为 v4.27.0 起有两条进门路径（口令登录 / 手机号找回后自动登录），
   * 两条路径下发的字段必须**完全一致** —— 少一个 actions 或 passwordPolicy，
   * 前端就会渲染出一个按钮全灰、提示"至少 6 位"的界面，而实际规则是 8 位。
   * 这类"两条路各写一份"的漂移，是这个项目里反复踩过的坑。
   */
  function loginPayload(userId, token) {
    return {
      token,
      user: userRow(userId),
      roleNames: ROLE_NAMES,
      identities: IDENTITIES,
      passwordPolicy: loginGuard.policySummary(pwdPolicy()),
      ...myAccess(userRow(userId)),
    };
  }

  /** 记录一次登录尝试：既是限流依据，也是"登录失败处理"的取证材料 */
  function recordLoginAttempt(username, ip, success, reason) {
    try {
      q.run('INSERT INTO login_attempts(at,username,ip,success,reason) VALUES(?,?,?,?,?)',
        nowIso(), username || '', ip || '', success ? 1 : 0, reason || '');
    } catch (e) {
      // 记录失败不能影响登录本身
      console.warn('[登录防护] 尝试记录写入失败：' + e.message);
    }
  }

  /** 某 IP 在最近 N 秒内的失败次数 */
  function recentFailuresByIp(ip, seconds = 60) {
    const since = new Date(Date.now() - seconds * 1000).toISOString();
    return Number(q.scalar(
      'SELECT COUNT(*) FROM login_attempts WHERE ip=? AND success=0 AND at>=?', ip, since) || 0);
  }

  /** 清理过期的登录尝试记录（保留天数由设置决定，0 = 永久保留） */
  function pruneLoginAttempts() {
    const keepDays = Number(numbering.getSetting(q, 'security.login_attempts_keep_days', '30')) || 0;
    if (keepDays <= 0) return 0;
    const before = new Date(Date.now() - keepDays * 86400000).toISOString();
    const r = q.run('DELETE FROM login_attempts WHERE at < ?', before);
    return Number(r.changes) || 0;
  }

  /**
   * 弱口令审计（后台任务）。
   *
   * 为什么放后台跑：只能拿"候选口令"逐个去比对已存储的哈希，而 scrypt 每次约几十毫秒，
   * 账号一多就会拖住启动。所以放在启动之后异步执行，结果缓存在 meta 里供查询。
   * 它回答的正是最实际的那个问题：**这套系统里到底有没有人在用弱口令？**
   */
  function auditWeakPasswords() {
    try {
      const users = q.all("SELECT id,username,password_salt,password_hash FROM users WHERE status='active'");
      const hit = [];
      for (const u of users) {
        const cands = new Set(loginGuard.WEAK_PASSWORDS);
        const lower = String(u.username).toLowerCase();
        cands.add(lower);
        cands.add(lower + '123');
        cands.add(lower + '123456');
        for (const c of cands) {
          if (verifyPassword(c, u.password_salt, u.password_hash)) {
            hit.push({ id: u.id, username: u.username, weak: c });
            break;
          }
        }
      }
      const result = {
        at: nowIso(), checked: users.length, dictionarySize: loginGuard.WEAK_PASSWORDS.length, weak: hit,
      };
      q.run("INSERT INTO meta(key,value) VALUES('weak_password_audit',?) "
        + 'ON CONFLICT(key) DO UPDATE SET value=excluded.value', JSON.stringify(result));
      if (hit.length) {
        console.warn(`[口令审计] 发现 ${hit.length} 个账号在使用常见弱口令：`
          + `${hit.map((x) => x.username).join('、')} —— 请尽快在「系统管理 → 用户管理」中要求其修改`);
      }
      return result;
    } catch (e) {
      console.warn('[口令审计] 跳过（不影响使用）：' + e.message);
      return null;
    }
  }

  /** 读取缓存的弱口令审计结果 */
  function weakPasswordAuditCached() {
    try {
      const raw = q.scalar("SELECT value FROM meta WHERE key='weak_password_audit'");
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  // ---------- 路由表 ----------
  // key: 'METHOD /path/pattern'   :name 为路径参数
  const routes = [];
  function route(method, pattern, handler, opts = {}) {
    const names = [];
    const rx = new RegExp('^' + pattern.replace(/:[A-Za-z_]+/g, (m) => { names.push(m.slice(1)); return '([^/]+)'; }) + '$');
    const methods = String(opts.methods || method).split(',').map((s) => s.trim().toUpperCase());
    routes.push({ methods, rx, names, handler, opts });
  }

  // ===== 会话 =====

  /**
   * 纯文本连通性自检：/api/ping
   *
   * 为什么需要它：手机扫码后「打不开」有好几种完全不同的原因 ——
   *   ① 服务器根本没在运行      ② 手机和这台机器不在同一个网络
   *   ③ 防火墙拦住了端口        ④ 页面本身有问题
   * 这几种在手机上的表现都是一片空白，分不清。这个接口只回一行纯文本、
   * 不登录、不查库、不依赖任何资源，所以「能看到 OK」就等价于
   * 「网络通、服务在跑、页面渲染不是问题」，剩下的就只有页面本身了。
   *
   * 让用户直接用手机浏览器敲：http://本机地址:端口/api/ping
   */
  route('GET', '/api/ping', async (req, res) => {
    const body = `OK 豆包信创档案管理系统在运行\n`
      + `时间：${new Date().toLocaleString('zh-CN')}\n`
      + `监听：${(config && config.host) || '?'}:${(config && (config.actualPort || config.port)) || '?'}\n`
      + `版本：${(config && config.version) || ''}\n`
      + `你（手机）的地址：${clientIp(req)}\n`
      + `本机可用地址：${lanIPv4List().map((x) => `${urlScheme()}://${x.address}:${(config && (config.actualPort || config.port)) || 8787}`).join('　') || '（无）'}\n`;
    res.writeHead(200, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Length': Buffer.byteLength(body),
    });
    res.end(body);
  });

  route('POST', '/api/login', async (req, res) => {
    const body = await readJson(req);
    let username = mustStr(body.username, 64).trim();
    const password = String(body.password || '');
    // 身份下拉（v4.18.0 起）：给了就必须与账号角色一致。
    // v4.19.0 起身份还可以**替代用户名** —— 登录页只有"身份 + 口令"两个框。
    const identity = mustStr(body.identity, 32).trim();
    const idDef = identity ? LOGIN_IDENTITIES.find((x) => x.key === identity) : null;
    if (identity && !idDef) return fail(res, 400, '身份不正确，请重新选择');
    const ip = clientIp(req);
    if (!password) return fail(res, 400, '请输入密码');
    if (!username && !idDef) return fail(res, 400, '请选择身份或输入用户名');

    const maxFail = Number(numbering.getSetting(q, 'security.login_max_fail', '5')) || 0;
    const lockMinutes = Number(numbering.getSetting(q, 'security.login_lock_minutes', '15')) || 0;
    const perMinute = Number(numbering.getSetting(q, 'security.login_rate_per_minute', '20')) || 0;

    // ① 按来源 IP 限流：挡住"固定口令、换着用户名试"的爆破
    if (loginGuard.rateLimited(recentFailuresByIp(ip, 60), perMinute)) {
      recordLoginAttempt(username, ip, false, '触发限流');
      log(null, '登录被限流', username, `来源 ${ip} 一分钟内失败次数达上限`, ip,
        { username, result: '拒绝', category: 'security', step: '登录限流' });
      res.setHeader('Retry-After', '60');
      return fail(res, 429, '登录尝试过于频繁，请稍后再试');
    }

    // 解析账号（v4.19.0）：
    //   · 给了用户名 → 按用户名取（脚本、旧调用，以及"想指明是谁"的场合）
    //   · 只给了身份 → 在该身份的账号里按口令逐个比对，命中哪个就是哪个
    //
    // 为什么保留"一人一账号"而不是把口令做成身份口令：
    // 界面只要两个框就够了，但账号仍是一人一个 —— 以后档案室添了第二位档案管理员
    // （单独账号、单独口令），审计日志里记的仍然是他本人的账号名，
    // 而不是笼统的"档案管理员"。界面简单与日志可追溯，这两件事可以同时要。
    // 开销：scrypt 一次约 80ms，账号数是个位数，逐个比对约几百毫秒，登录完全够用。
    let u = username ? q.get('SELECT * FROM users WHERE username=?', username) : null;
    let resolvedByIdentity = false;
    let lockedRemain = 0;
    if (!u && !username && idDef) {
      const cands = q.all("SELECT * FROM users WHERE role=? AND status='active' ORDER BY id LIMIT 30", idDef.role);
      for (const cand of cands) {
        // 已锁定的账号不参与比对，否则锁定就形同虚设。
        // 千问版 v4.30.8：失败计数达阈值也视为锁定（哪怕 locked_until 已过期）——
        // 否则锁定期一过爆破者又能继续试，锁定变成"每 15 分钟歇一会儿"。
        // 解锁/重置/成功登录都会清零 failed_count，正常用户不受影响。
        const ls = loginGuard.lockState(cand, Date.now());
        const countLocked = maxFail > 0 && Number(cand.failed_count || 0) >= maxFail;
        if (ls.locked || countLocked) {
          lockedRemain = Math.max(lockedRemain, ls.remainingMinutes || lockMinutes || 0);
          continue;
        }
        if (verifyPassword(password, cand.password_salt, cand.password_hash)) { u = cand; break; }
      }
      if (u) { resolvedByIdentity = true; username = u.username; }
      // 没命中也要做一次等价开销的运算（下面 dummyVerify），与按用户名登录保持一致
    }

    /**
     * 「按身份登录」这条路上，被锁定的账号会被**跳过** —— 如果该身份下的账号正锁着，
     * 使用者拿**正确**的口令也只会得到一句"用户名或密码错误"，永远想不到是被锁了，
     * 只会一遍遍重试。所以这里单独判一次：该身份下确实有账号在锁定期，就如实说清楚。
     */
    if (!u && lockedRemain && idDef) {
      const nm = username || `（按身份登录：${idDef.label}）`;
      recordLoginAttempt(nm, ip, false, '账号锁定中');
      log(null, '锁定期间登录被拒', nm, `该身份下有账号处于锁定期（剩余约 ${lockedRemain} 分钟）`, ip,
        { result: '拒绝', category: 'security', step: '账号锁定' });
      return fail(res, 423, `账号已锁定，请约 ${lockedRemain} 分钟后再试，或联系档案管理员解锁`);
    }

    // ② 账号锁定检查（连续失败达阈值后锁定一段时间）
    if (u) {
      const ls = loginGuard.lockState(u, Date.now());
      if (ls.locked) {
        recordLoginAttempt(username, ip, false, '账号锁定中');
        log(u, '锁定期间登录被拒', username, `剩余约 ${ls.remainingMinutes} 分钟`, ip,
          { result: '拒绝', category: 'security', step: '账号锁定' });
        return fail(res, 423, `账号已锁定，请约 ${ls.remainingMinutes} 分钟后再试，或联系管理员解锁`);
      }
    }

    // ③ 校验口令。账号不存在时也做一次等价开销的运算，
    //    否则响应时间会泄露"这个用户名存不存在"，前面"不区分失败原因"就白做了。
    //    按身份登录时口令在上面比对过程中已经验过，不重复算一遍（省 80ms）。
    const pwdOk = resolvedByIdentity ? true : (u ? verifyPassword(password, u.password_salt, u.password_hash) : false);
    if (!u) loginGuard.dummyVerify(password);
    // 按身份登录但没命中任何账号：日志里不能留空用户名，否则这条失败记录查不出是怎么来的
    const logName = username || (idDef ? `（按身份登录：${idDef.label}）` : '');

    if (!pwdOk) {
      let detail = u ? '口令错误' : (idDef && !username ? '该身份下无匹配账号' : '账号不存在');
      let extra = '';
      if (u) {
        const failed = Number(u.failed_count || 0) + 1;
        if (loginGuard.shouldLock(failed, maxFail)) {
          const until = new Date(Date.now() + lockMinutes * 60000).toISOString();
          q.run('UPDATE users SET failed_count=?, last_failed_at=?, locked_until=? WHERE id=?',
            failed, nowIso(), until, u.id);
          detail = `连续失败 ${failed} 次，账号已锁定至 ${until}`;
          extra = `；连续失败已达 ${maxFail} 次，账号已锁定 ${lockMinutes} 分钟`;
          log(u, '账号锁定', username, `连续失败 ${failed} 次`, ip,
            { result: '拒绝', category: 'security', step: '登录锁定' });
        } else {
          q.run('UPDATE users SET failed_count=?, last_failed_at=? WHERE id=?', failed, nowIso(), u.id);
          detail = `口令错误（连续第 ${failed} 次）`;
        }
        recordLoginAttempt(logName, ip, false, detail);
      } else if (idDef && !username) {
        // 千问版 v4.30.8：身份登录失败也要计数 —— 原来这条路不写 failed_count，
        // 对"身份+口令"的在线爆破没有上限（IP 限流又可被伪造头绕过，见 lib/http.js）。
        // 现在把失败记到该身份下每个未锁定候选账号上：猜错一次，所有候选各记一次，
        // 达阈值即锁。代价是同身份多账号时一人猜错会连带锁住同人，
        // 但登录页只有两个身份、账号个位数，且管理员可解锁/重置，安全收益远大于此。
        const targets = q.all("SELECT id,username,failed_count FROM users WHERE role=? AND status='active' AND failed_count < ? LIMIT 30",
          idDef.role, maxFail > 0 ? maxFail : 2147483647);
        let lockedAny = false;
        for (const t of targets) {
          const failed = Number(t.failed_count || 0) + 1;
          if (loginGuard.shouldLock(failed, maxFail)) {
            const until = new Date(Date.now() + lockMinutes * 60000).toISOString();
            q.run('UPDATE users SET failed_count=?, last_failed_at=?, locked_until=? WHERE id=?', failed, nowIso(), until, t.id);
            lockedAny = true;
            log(userRow(t.id), '账号锁定', t.username, `按身份登录连续失败 ${failed} 次`, ip,
              { result: '拒绝', category: 'security', step: '登录锁定' });
          } else {
            q.run('UPDATE users SET failed_count=?, last_failed_at=? WHERE id=?', failed, nowIso(), t.id);
          }
        }
        if (lockedAny) extra = `；连续失败已达 ${maxFail} 次，该身份下账号已锁定 ${lockMinutes} 分钟`;
        recordLoginAttempt(logName, ip, false, '该身份下无匹配账号（候选账号已计失败次数）');
      } else {
        recordLoginAttempt(logName, ip, false, idDef ? '该身份下无匹配账号' : '账号不存在');
      }
      // 对外统一话术：不区分"用户名不存在 / 口令错误 / 身份下无匹配账号"，
      // 避免系统变成账号枚举器
      log(null, '登录失败', logName, detail, ip,
        { username: logName, result: '失败', category: 'auth', step: '身份鉴别' });
      return fail(res, 401, '用户名或密码错误' + extra);
    }

    // ④ 账号状态：对外同样不透露细节（与口令错误同一句话）
    if (u.status !== 'active') {
      recordLoginAttempt(username, ip, false, '账号已停用');
      log(u, '停用账号登录被拒', username, '', ip,
        { result: '拒绝', category: 'security', step: '身份鉴别' });
      return fail(res, 401, '用户名或密码错误');
    }

    // ⑤ 身份与账号角色必须一致（v4.18.0）。
    //    放在口令校验**之后**：口令不对时不应泄露"这个账号是什么角色"。
    //    选错身份当场拒绝，而不是让人进去以后才发现菜单不对。
    if (idDef && u.role !== idDef.role) {
      recordLoginAttempt(username, ip, false, '身份选择与账号不符');
      log(u, '登录身份不符', username, `选择了「${idDef.label}」，账号角色为「${ROLE_NAMES[u.role] || u.role}」`, ip,
        { result: '拒绝', category: 'security', step: '身份鉴别' });
      return fail(res, 401, `该账号不是「${idDef.label}」身份，请核对身份选择（或联系管理员）`);
    }

    // ⑤ 成功：清零失败计数与锁定
    recordLoginAttempt(username, ip, true, '');
    if (Number(u.failed_count || 0) > 0 || u.locked_until) {
      q.run("UPDATE users SET failed_count=0, locked_until='' WHERE id=?", u.id);
    }
    const token = sessions.create(u.id);
    setCookie(res, 'dsh_archive_token', token, sessionCookieOpts());
    log(userRow(u.id), '登录', username, '', ip);
    // 应答字段由 loginPayload 统一生成（v4.27.0）：
    // 手机号找回后自动登录走的也是这个函数，两条路下发的字段必须一模一样。
    ok(res, loginPayload(u.id, token));
  });

  // ============================================================
  //  口令找回（v4.27.0 手机号 / v4.31.0 邮箱）—— 三条接口，全程无需登录
  // ============================================================
  //
  // 流程：地址 --(send)--> 验证码 --(verify)--> 一次性票据 --(reset)--> 新口令 + 自动登录
  //
  // 为什么拆成三步而不是一步"验证码直接登录"：
  //   ① 验证码只用来证明"这个手机/邮箱在你手上"，它不该等价于登录凭证；
  //   ② 拆开之后，任何一步被重放都没用：码核销即作废、票据只能设一次口令；
  //   ③ 三步各自能独立限流与留痕，出事时日志能说清卡在哪一步。
  //
  // 为什么短信与邮件共用一套实现：见下方 RECOVERY 表的注释。
/**
   * 找回验证码的数值型策略。
   *
   * 先读本通道自己的键（security.email_*），没有就复用短信那套（security.sms_*）——
   * 这样升级后行为不变、也不需要逼管理员再去填一遍新键；想单独调邮件频次时再写 email_* 即可。
   */
  function recNum(channel, name, dft) {
    const own = String(numbering.getSetting(q, `security.${channel}_${name}`, '') || '');
    const raw = own !== '' ? own : numbering.getSetting(q, `security.sms_${name}`, String(dft));
    const n = Number(raw);
    return Number.isFinite(n) && n >= 0 ? n : dft;
  }

  /** 某通道的找回总开关（security.sms_login / security.email_login） */
  function recEnabled(channel) {
    return String(numbering.getSetting(q, `security.${channel}_login`, '1')) !== '0';
  }

  /** 邮箱打码：zhang***@qq.com —— 日志里不该出现完整邮箱 */
  function maskEmail(email) {
    const s = String(email || '');
    const at = s.indexOf('@');
    if (at <= 0) return s ? s.slice(0, 1) + '***' : '';
    const name = s.slice(0, at);
    const keep = name.slice(0, Math.min(2, name.length));
    return keep + '***' + s.slice(at);
  }

  /** 按邮箱查账号。与手机号同一条规矩：同地址多账号时宁可谁都不给找回 */
  function userByEmail(email) {
    const rows = q.all("SELECT * FROM users WHERE email=? AND email<>''", email);
    if (rows.length > 1) return { user: null, conflict: true };
    return { user: rows[0] || null, conflict: false };
  }

  /**
   * 两条找回通道的差异全部收在这张表里。
   *
   * 三步流程（发码 → 校验 → 凭票据改口令）共用一套实现：
   * 拆成两份写，等于把"限流、冷却、作废、审计"这些容易漏的细节各抄一遍，
   * 迟早会漂移成一套严、一套松。通道差异只剩：怎么规范化地址、怎么发出去、日志里怎么写。
   */
  const RECOVERY = {
    sms: {
      key: 'sms',
      step: '短信找回',
      badInput: '请输入正确的 11 位手机号',
      normalize: (v) => smsLib.normalizePhone(v),
      mask: (v) => smsLib.maskPhone(v),
      disabledMsg: '手机号找回已关闭。请联系档案管理员在「系统管理 → 用户管理」中重置口令',
      disabledShort: '手机号找回已关闭',
      genericHint: '如果该手机号已登记，验证码会在几秒内送达。'
        + '收不到请确认号码已由档案管理员登记，或直接联系管理员重置口令。',
      notRegistered: '该手机号未登记任何账号',
      ready: () => !!sms.configured,
      unavailable: () => {
        const d = sms.describe();
        return '短信通道未配置'
          + (d.missing.length ? `（缺少：${d.missing.join('、')}）` : '')
          + '，请联系档案管理员。配置方法见程序目录下的《短信登录配置说明.txt》';
      },
      deliver: async (target, code, ttlMinutes) => {
        const r = await sms.send(target, code, { ttlMinutes });
        return { ok: r.ok, error: r.error, via: r.provider || sms.provider };
      },
      who: (t) => `手机 ${smsLib.maskPhone(t)}`,
      logDup: '找回口令：手机号重复登记',
      logUnusable: '找回口令：号码不可用',
      logDaily: '找回口令：当日次数用尽',
      logFail: '找回口令：短信发送失败',
      logSent: '找回口令：已发送验证码',
      logBadCode: '找回口令：验证码错误',
      logVerified: '找回口令：验证码校验通过',
      logReset: '手机验证码重置口令',
      viaLabel: '通道',
      rateLimitLog: '验证码发送被限流',
    },
    email: {
      key: 'email',
      step: '邮件找回',
      badInput: '请输入正确的邮箱地址，例如 name@example.com',
      normalize: (v) => normalizeEmail(v),
      mask: (v) => maskEmail(v),
      disabledMsg: '邮件找回已关闭。请联系档案管理员在「系统管理 → 用户管理」中重置口令',
      disabledShort: '邮件找回已关闭',
      genericHint: '如果该邮箱已登记，验证码会在几秒内送达（若没看到请查一下垃圾邮件）。'
        + '收不到请确认邮箱已由档案管理员登记，或直接联系管理员重置口令。',
      notRegistered: '该邮箱未登记任何账号',
      ready: () => !!mail.configured,
      unavailable: () => {
        const d = mail.describe();
        return '邮件通道未配置'
          + (d.missing.length ? `（缺少：${d.missing.join('、')}）` : '')
          + '，请联系档案管理员。配置方法见程序目录下的《邮件找回配置说明.txt》';
      },
      deliver: async (target, code, ttlMinutes) => {
        const minutes = Math.max(1, Number(ttlMinutes) || 5);
        const text = [
          '您好：',
          '',
          '下面是档案管理系统的口令重置验证码：',
          '',
          `    ${code}`,
          '',
          `${minutes} 分钟内有效，只能使用一次。`,
          '如果您没有申请重置口令，请忽略本邮件，您的口令不会改变。',
          '',
          '—— 广州市南沙区排水和污水处理事务中心 档案管理系统',
        ].join('\n');
        const r = await mail.send({ to: target, subject: '【档案管理系统】口令重置验证码', text });
        return { ok: r.ok, error: r.error, via: 'smtp' };
      },
      who: (t) => `邮箱 ${maskEmail(t)}`,
      logDup: '找回口令：邮箱重复登记',
      logUnusable: '找回口令：邮箱不可用',
      logDaily: '找回口令：当日次数用尽',
      logFail: '找回口令：邮件发送失败',
      logSent: '找回口令：已发送验证码',
      logBadCode: '找回口令：验证码错误',
      logVerified: '找回口令：验证码校验通过',
      logReset: '邮件验证码重置口令',
      viaLabel: '通道',
      rateLimitLog: '验证码发送被限流',
    },
  };

  function recUserBy(channel, target) {
    return channel === 'email' ? userByEmail(target) : userByPhone(target);
  }

  /**
   * 第一步：发送验证码。
   *
   * 对外话术与口令登录保持同一口径 —— **不透露该号码/邮箱是否已登记**。
   * 理由和"登录失败不区分账号不存在/口令错误"完全一样：否则登录页就变成了
   * 一个可以挨个试探的"存在性查询器"，而手机号、邮箱本身都是个人信息。
   */
  async function sendRecoveryCode(channel, req, res) {
    const rec = RECOVERY[channel];
    const ip = clientIp(req);
    const body = await readJson(req);
    const target = rec.normalize(body.phone || body.email || body.target);
    if (!target) return fail(res, 400, rec.badInput);
    if (!recEnabled(channel)) return fail(res, 403, rec.disabledMsg);
    // 通道没配就说清楚。这里必须报错而不是回"已发送"：
    // 让人对着一个永远收不到验证码的界面等 5 分钟，比一句实话糟糕得多。
    if (!rec.ready()) return fail(res, 503, rec.unavailable());

    // ① 按来源 IP 限流：防"拿一批号码刷验证码"——既骚扰别人，也真花钱
    const since10 = new Date(Date.now() - 10 * 60000).toISOString();
    const ipCount = Number(q.scalar('SELECT COUNT(*) FROM login_codes WHERE ip=? AND sent_at>=?', ip, since10) || 0);
    if (ipCount >= 20) {
      log(null, rec.rateLimitLog, '', `来源 ${ip} 十分钟内已发送 ${ipCount} 次`, ip,
        { result: '拒绝', category: 'security', step: rec.step });
      return fail(res, 429, '获取验证码过于频繁，请稍后再试');
    }

    const ttl = recNum(channel, 'code_ttl_minutes', 5);
    const resend = recNum(channel, 'resend_seconds', 60);
    const generic = {
      sent: true,
      ttlSeconds: ttl * 60,
      resendSeconds: resend,
      hint: rec.genericHint,
    };

    const { user, conflict } = recUserBy(channel, target);
    // 同一号码/邮箱对应多个账号：宁可谁都不给找回，也不能替管理员"猜"应该重置哪一个
    if (conflict) {
      log(null, rec.logDup, rec.mask(target),
        '同一地址绑定了多个账号，已拒绝本次找回', ip,
        { result: '拒绝', category: 'security', step: rec.step });
      return ok(res, generic);
    }
    if (!user || !smsEligible(user)) {
      // 未登记 / 已停用 / 三员账号：对外一律同一句话
      log(null, rec.logUnusable, rec.mask(target),
        !user ? rec.notRegistered : (SMS_BLOCKED_ROLES.has(user.role) ? `三员账号（${ROLE_NAMES[user.role] || user.role}）不允许自助找回` : '账号已停用'),
        ip, { result: '失败', category: 'security', step: rec.step });
      return ok(res, generic);
    }

    // ② 单地址每天上限
    const dailyLimit = recNum(channel, 'daily_limit', 5);
    const usedToday = Number(q.scalar(
      "SELECT COUNT(*) FROM login_codes WHERE channel=? AND target=? AND sent_at>=?",
      channel, target, startOfTodayIso()) || 0);
    if (dailyLimit > 0 && usedToday >= dailyLimit) {
      log(user, rec.logDaily, rec.mask(target), `今日已发送 ${usedToday} 次`, ip,
        { result: '拒绝', category: 'security', step: rec.step });
      return ok(res, {
        ...generic,
        sent: false,
        hint: '今天的验证码次数已用完，请联系档案管理员重置口令',
      });
    }

    // ③ 单地址冷却：连点"获取验证码"不该连发三条，否则前两条立刻作废，
    //    使用者手上可能正好是作废的那条，只会得到"验证码不正确"
    const last = q.get(
      'SELECT sent_at FROM login_codes WHERE channel=? AND target=? ORDER BY id DESC LIMIT 1', channel, target);
    if (last && resend > 0) {
      const waitMs = resend * 1000 - (Date.now() - Date.parse(last.sent_at));
      if (waitMs > 0) {
        return ok(res, { ...generic, sent: false, retryAfterSeconds: Math.ceil(waitMs / 1000), hint: '刚发过一条，请稍后再试' });
      }
    }

    const code = smsLib.generateCode();
    const { salt, hash } = smsLib.hashCode(code);
    const sentAt = nowIso();
    // phone 列保留（老库非空约束），短信通道照旧填手机号；邮件通道填空串，
    // 真正用于检索的是 channel + target
    const ins = q.run(
      `INSERT INTO login_codes(user_id,phone,channel,target,purpose,code_salt,code_hash,sent_at,expires_at,ip)
       VALUES(?,?,?,?,?,?,?,?,?,?)`,
      user.id, channel === 'sms' ? target : '', channel, target, 'reset', salt, hash, sentAt,
      new Date(Date.now() + ttl * 60000).toISOString(), ip,
    );
    const r = await rec.deliver(target, code, ttl);
    if (!r.ok) {
      // 发送失败就把这行作废：否则它照样占掉今天的次数和冷却时间，
      // 使用者点一次失败、再点就要再等一分钟，看起来像"系统坏了"
      q.run("UPDATE login_codes SET used_at=? WHERE id=?", nowIso(), ins.lastInsertRowid);
      log(user, rec.logFail, rec.mask(target), r.error || '', ip,
        { result: '失败', category: 'security', step: rec.step });
      return fail(res, 502, '验证码发送失败：' + (r.error || '通道无响应')
        + '。请稍后重试，或联系档案管理员重置口令');
    }
    log(user, rec.logSent, rec.mask(target),
      `${rec.viaLabel} ${r.via || ''}`.trim(), ip, { category: 'security', step: rec.step });
    pruneLoginCodes();
    return ok(res, generic);
  }

  /**
   * 第二步：校验验证码，换一张**一次性重置票据**。
   *
   * 票据存的是 SHA-256，库里只有哈希：即便库文件被拿走，也拿不到能直接用的票据
   * （和验证码存 scrypt 哈希是同一个道理）。
   */
  async function verifyRecoveryCode(channel, req, res) {
    const rec = RECOVERY[channel];
    const ip = clientIp(req);
    const body = await readJson(req);
    const target = rec.normalize(body.phone || body.email || body.target);
    const code = String(body.code || '').replace(/[\s-]/g, '');
    if (!target) return fail(res, 400, rec.badInput);
    if (!/^\d{6}$/.test(code)) return fail(res, 400, '请输入 6 位数字验证码');
    if (!recEnabled(channel)) return fail(res, 403, rec.disabledShort);

    const maxAttempts = recNum(channel, 'max_attempts', 5);
    const row = q.get(
      `SELECT c.*, u.status AS u_status, u.role AS u_role, u.username AS u_username
         FROM login_codes c JOIN users u ON u.id = c.user_id
        WHERE c.channel=? AND c.target=? AND c.used_at='' AND c.expires_at>?
        ORDER BY c.id DESC LIMIT 1`, channel, target, nowIso(),
    );
    // 统一话术：不区分"没发过""已过期""码不对""账号停用"
    const bad = '验证码不正确或已过期，请重新获取';
    if (!row) return fail(res, 400, bad);
    if (row.u_status !== 'active') return fail(res, 400, bad);
    if (maxAttempts > 0 && Number(row.attempts) >= maxAttempts) {
      q.run('UPDATE login_codes SET used_at=? WHERE id=?', nowIso(), row.id);
      return fail(res, 400, '该验证码输错次数过多，已作废，请重新获取');
    }

    const hit = smsLib.timingSafeEqualHex(
      smsLib.hashCode(code, row.code_salt).hash, row.code_hash,
    );
    if (!hit) {
      const cur = Number(row.attempts) + 1;
      q.run('UPDATE login_codes SET attempts=? WHERE id=?', cur, row.id);
      log(null, rec.logBadCode, rec.mask(target), `第 ${cur} 次`, ip,
        { username: row.u_username || '', result: '失败', category: 'security', step: rec.step });
      const left = maxAttempts > 0 ? Math.max(0, maxAttempts - cur) : -1;
      return fail(res, 400, bad + (left > 0 ? `（还可尝试 ${left} 次）` : ''));
    }

    const ticket = require('node:crypto').randomBytes(24).toString('hex');
    const ttlTicket = recNum(channel, 'ticket_ttl_minutes', 10);
    q.run(
      'UPDATE login_codes SET used_at=?, attempts=?, ticket_hash=?, ticket_expires_at=? WHERE id=?',
      nowIso(), Number(row.attempts) + 1, smsLib.sha256(ticket),
      new Date(Date.now() + ttlTicket * 60000).toISOString(), row.id,
    );
    log(userRow(row.user_id), rec.logVerified, rec.mask(target), '', ip,
      { category: 'security', step: rec.step });
    return ok(res, {
      ticket,
      expiresInSeconds: ttlTicket * 60,
      // 口令规则随这一条应答下发：此时使用者还没登录，拿不到 /api/me，
      // 而第三步马上要填新口令 —— 若不给他真实规则，前端只能猜（以前就是猜成"至少 6 位"）。
      passwordPolicy: loginGuard.policySummary(pwdPolicy()),
    });
  }

  /**
   * 第三步：凭票据设置新口令，成功后**直接建立会话**。
   *
   * 到这里使用者已经证明了手机/邮箱在他手上，并且当场设置了自己知道的新口令 ——
   * 相当于完成了一次"本人 + 双因素"的身份鉴别，所以直接放进门是合理的。
   * 这与"验证码直接登录"的区别在于：**必须先自设新口令**，
   * 系统的口令强度策略一条都不少（长度、弱口令清单、不得同于旧口令）。
   */
  async function resetByTicket(req, res) {
    const ip = clientIp(req);
    const body = await readJson(req);
    const ticket = String(body.ticket || '').trim();
    const newPwd = String(body.newPassword || '');
    if (!/^[a-f0-9]{32,}$/.test(ticket)) return fail(res, 400, '重置凭证无效，请重新获取验证码');
    if (!newPwd) return fail(res, 400, '请设置新口令');

    const row = q.get(
      "SELECT * FROM login_codes WHERE ticket_hash=? AND ticket_expires_at>? AND ticket_expires_at<>''",
      smsLib.sha256(ticket), nowIso(),
    );
    if (!row) return fail(res, 400, '重置凭证已失效，请重新获取验证码');
    // 通道从库里那行读回来：票据本身就是发码那一行的一部分，不该由调用方指定
    const rec = RECOVERY[String(row.channel || 'sms')] || RECOVERY.sms;
    if (!recEnabled(rec.key)) return fail(res, 403, rec.disabledShort);
    const u = userRow(row.user_id);
    if (!u || u.status !== 'active') return fail(res, 400, '账号不可用，请联系档案管理员');

    const chk = validateNewPassword(newPwd, u.username);
    if (!chk.ok) return fail(res, 400, chk.error);
    const cur = q.get('SELECT * FROM users WHERE id=?', u.id);
    if (verifyPassword(newPwd, cur.password_salt, cur.password_hash)) {
      return fail(res, 400, '新口令不能与原口令相同');
    }

    const { salt, hash } = hashPassword(newPwd);
    q.run(`UPDATE users SET password_hash=?, password_salt=?, must_change=0,
             failed_count=0, locked_until='', last_failed_at='' WHERE id=?`, hash, salt, u.id);
    // 票据一次性：有效期置空，同一张票据再提交一次就查不到了
    q.run("UPDATE login_codes SET ticket_expires_at='' WHERE id=?", row.id);
    // 口令已变，旧会话必须全部作废 —— 否则"口令泄漏后改口令"就白改了
    const kicked = sessions.destroyByUser(u.id);
    log(u, rec.logReset, u.username,
      `${rec.who(row.target || row.phone)}；已注销 ${kicked} 个旧会话`, ip,
      { category: 'security', step: '口令找回' });
    // 口令变了，之前那份弱口令审计结果就过期了
    try { auditWeakPasswords(); } catch (_) { /* 不影响改密本身 */ }

    const token = sessions.create(u.id);
    setCookie(res, 'dsh_archive_token', token, sessionCookieOpts());
    log(userRow(u.id), '登录', u.username, `${rec.key === 'email' ? '邮箱' : '手机'}验证码找回后自动登录`, ip);
    return ok(res, loginPayload(u.id, token));
  }

  route('POST', '/api/login/sms/send', (req, res) => sendRecoveryCode('sms', req, res));
  route('POST', '/api/login/sms/verify', (req, res) => verifyRecoveryCode('sms', req, res));
  route('POST', '/api/login/sms/reset', (req, res) => resetByTicket(req, res));
  route('POST', '/api/login/email/send', (req, res) => sendRecoveryCode('email', req, res));
  route('POST', '/api/login/email/verify', (req, res) => verifyRecoveryCode('email', req, res));
  route('POST', '/api/login/email/reset', (req, res) => resetByTicket(req, res));

  route('POST', '/api/logout', async (req, res) => {
    const u = currentUser(req);
    const token = parseCookies(req).dsh_archive_token;
    if (token) sessions.destroy(token);
    if (u) log(u, '退出登录', u.username, '', clientIp(req));
    setCookie(res, 'dsh_archive_token', '', { maxAge: 0 });
    ok(res, true);
  });

  route('GET', '/api/me', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const pol = pwdPolicy();
    ok(res, {
      user: u,
      roleNames: ROLE_NAMES,
      identities: IDENTITIES,
      ...myAccess(u),
      passwordPolicy: loginGuard.policySummary(pol),
      overdue: q.scalar("SELECT COUNT(*) FROM loans WHERE status='逾期'"),
    });
  });

  route('POST', '/api/me/password', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const body = await readJson(req);
    const oldPwd = String(body.oldPassword || '');
    const newPwd = String(body.newPassword || '');
    const row = q.get('SELECT * FROM users WHERE id=?', u.id);
    if (!verifyPassword(oldPwd, row.password_salt, row.password_hash)) {
      log(u, '修改密码失败', u.username, '原密码不正确', clientIp(req),
        { result: '失败', category: 'auth', step: '口令变更' });
      return fail(res, 400, '原密码不正确');
    }
    const chk = validateNewPassword(newPwd, u.username);
    if (!chk.ok) return fail(res, 400, chk.error);
    if (verifyPassword(newPwd, row.password_salt, row.password_hash)) {
      return fail(res, 400, '新口令不能与原口令相同');
    }
    const { salt, hash } = hashPassword(newPwd);
    q.run('UPDATE users SET password_hash=?, password_salt=?, must_change=0 WHERE id=?', hash, salt, u.id);
    log(u, '修改密码', u.username, '', clientIp(req), { step: '口令变更' });
    // 口令变了，之前那份弱口令审计结果就过期了：重算一次（单账号，开销很小）
    try { auditWeakPasswords(); } catch (_) { /* 不影响改密本身 */ }
    ok(res, true);
  });

  // ===== 基础元数据 =====
  route('GET', '/api/categories', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const rows = q.all(`SELECT c.*, (SELECT COUNT(*) FROM archives a WHERE a.category_id=c.id) AS archive_count
                        FROM categories c ORDER BY c.level, c.sort_no, c.id`);
    // 组装树
    const byId = new Map();
    for (const r of rows) { r.children = []; byId.set(r.id, r); }
    const tree = [];
    for (const r of rows) {
      if (r.parent_id && byId.has(r.parent_id)) byId.get(r.parent_id).children.push(r);
      else tree.push(r);
    }
    ok(res, { list: tree, flat: rows });
  });

  route('POST', '/api/categories', async (req, res) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req);
    const name = mustStr(b.name, 60).trim();
    const code = mustStr(b.code, 40).trim().toUpperCase();
    if (!name || !code) return fail(res, 400, '分类名称和代码不能为空');
    if (q.scalar('SELECT id FROM categories WHERE code=?', code)) return fail(res, 400, '分类代码已存在');
    const parentId = b.parent_id ? Number(b.parent_id) : null;
    let level = 1;
    if (parentId) {
      const p = q.get('SELECT id,level FROM categories WHERE id=?', parentId);
      if (!p) return fail(res, 400, '上级分类不存在');
      level = Number(p.level) + 1;
    }
    const r = q.run('INSERT INTO categories(parent_id,name,code,level,sort_no,remark) VALUES(?,?,?,?,?,?)',
      parentId, name, code, level, numOr(b.sort_no, 99), mustStr(b.remark, 200));
    log(u, '新增分类', code, name, clientIp(req));
    ok(res, { id: r.lastInsertRowid });
  });

  route('PUT', '/api/categories/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req);
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM categories WHERE id=?', id);
    if (!cur) return fail(res, 404, '分类不存在');
    const code = mustStr(b.code, 40).trim().toUpperCase() || cur.code;
    if (code !== cur.code && q.scalar('SELECT id FROM categories WHERE code=?', code)) {
      return fail(res, 400, '分类代码已存在');
    }
    q.run('UPDATE categories SET name=?, code=?, sort_no=?, remark=? WHERE id=?',
      mustStr(b.name, 60).trim() || cur.name, code, numOr(b.sort_no, cur.sort_no), mustStr(b.remark, 200), id);
    log(u, '修改分类', code, '', clientIp(req));
    ok(res, true);
  });

  route('DELETE', '/api/categories/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const id = Number(params.id);
    const used = q.scalar('SELECT COUNT(*) FROM archives WHERE category_id=?', id);
    if (used) return fail(res, 400, `该分类下还有 ${used} 条档案，不能删除`);
    const child = q.scalar('SELECT COUNT(*) FROM categories WHERE parent_id=?', id);
    if (child) return fail(res, 400, '请先删除下级分类');
    q.run('DELETE FROM categories WHERE id=?', id);
    log(u, '删除分类', String(id), '', clientIp(req));
    ok(res, true);
  });

  route('GET', '/api/types', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const rows = q.all(`SELECT t.*, (SELECT COUNT(*) FROM archives a WHERE a.type_code=t.code) AS archive_count
                        FROM archive_types t ORDER BY t.sort_no, t.id`);
    for (const r of rows) r.fields = safeParse(r.fields, []);
    ok(res, {
      list: rows, retentions: RETENTIONS, secretLevels: SECRET_LEVELS, carriers: CARRIERS, statuses: STATUSES,
      openStates: OPEN_STATES, secretTerms: SECRET_TERMS,
      appraisalKinds: APPRAISAL_KINDS,
      appraisalDecisions: { 价值鉴定: VALUE_DECISIONS, 密级鉴定: SECRET_DECISIONS, 开放鉴定: OPEN_DECISIONS },
      openPublicYears: OPEN_PUBLIC_YEARS,
    });
  });

  route('POST', '/api/types', async (req, res) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req);
    const code = mustStr(b.code, 16).trim().toUpperCase();
    const name = mustStr(b.name, 40).trim();
    if (!/^[A-Z0-9_]{1,16}$/.test(code)) return fail(res, 400, '门类代码只能是字母、数字或下划线');
    if (!name) return fail(res, 400, '门类名称不能为空');
    if (q.scalar('SELECT id FROM archive_types WHERE code=?', code)) return fail(res, 400, '门类代码已存在');
    const fields = Array.isArray(b.fields) ? b.fields : [];
    // 整理方式（v4.30.7）：year=按年度整理 / project=按项目整理（长期项目跨年度连续编号）
    const filingMode = String(b.filing_mode || 'year') === 'project' ? 'project' : 'year';
    const r = q.run('INSERT INTO archive_types(code,name,retention,prefix,fields,sort_no,filing_mode) VALUES(?,?,?,?,?,?,?)',
      code, name, mustStr(b.retention, 20) || '永久', mustStr(b.prefix, 20) || code + '-',
      JSON.stringify(fields), numOr(b.sort_no, 99), filingMode);
    log(u, '新增门类', code, name, clientIp(req));
    ok(res, { id: r.lastInsertRowid });
  });

  route('PUT', '/api/types/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req);
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM archive_types WHERE id=?', id);
    if (!cur) return fail(res, 404, '门类不存在');
    const fields = Array.isArray(b.fields) ? b.fields : safeParse(cur.fields, []);
    const filingMode = b.filing_mode === undefined
      ? String(cur.filing_mode || 'year')
      : (String(b.filing_mode) === 'project' ? 'project' : 'year');
    q.run('UPDATE archive_types SET name=?, retention=?, prefix=?, fields=?, sort_no=?, filing_mode=? WHERE id=?',
      mustStr(b.name, 40).trim() || cur.name,
      mustStr(b.retention, 20) || cur.retention,
      mustStr(b.prefix, 20) || cur.prefix,
      JSON.stringify(fields),
      numOr(b.sort_no, cur.sort_no),
      filingMode, id);
    log(u, '修改门类', cur.code, '', clientIp(req));
    ok(res, true);
  });

  // ===== 档案 =====

  /**
   * 列表口径的**唯一**筛选构造器。列表 / 打印 / 导出 CSV / 批量修改 / 批量归档章 全部走这里，
   * 保证同一条条件在各出口的行为完全一致。
   *
   * 两条不得破坏的不变量：
   *   1. 字段 → 列名的映射取自 lib/query-expr（表单条件与高级检索表达式共用一份定义），
   *      本函数里**不再出现裸的列名**；
   *   2. 密级范围过滤**永远放在最后、永远是与其它条件 AND 的一个独立项** ——
   *      这样高级检索表达式无论怎么写（哪怕写 `secret:机密`）都不可能扩大可读范围。
   */
  /**
   * 把查询参数编译成 WHERE 子句。
   *
   * @param {URLSearchParams} sp
   * @param {object} user 当前用户（密级过滤用）
   * @param {Set<string>} [skip] 忽略某些参数 —— **只给检索分面用**：
   *   分面的标准语义是"算某一维度时，不应用该维度自己的筛选条件"
   *   （否则门类分面永远只剩当前选中的那个门类，计数全变成 0 或全等于总数，毫无意义）。
   */
  function buildFilters(sp, user, skip) {
    const sk = (skip && typeof skip.has === 'function') ? skip : null;
    const skipIt = (k) => !!(sk && sk.has(k));
    const where = [];
    const params = [];
    const kw = (sp.get('kw') || '').trim();
    if (kw && !skipIt('kw')) {
      // 关键字：题名/档案号/关键词/摘要/责任者/部门/全文索引 + 拼音两路 + **附件正文两路**。
      // 子句与表达式里的「裸词」共用 query-expr 的 kwClause，避免两处口径漂移。
      // `noText=1` 时只搜档案行本身（导出目录、批量套打归档章这类"要的是档案行"的场景用）。
      const c = queryExpr.kwClause(kw, { text: sp.get('noText') !== '1' });
      where.push(c.sql);
      params.push(...c.params);
    }

    // 表单条件：等值字段统一走 queryExpr.eq（同一套列映射与取值口径）
    const EQ_PARAMS = [
      ['type', 'type'], ['category', 'category'], ['year', 'year'], ['status', 'status'],
      ['retention', 'retention'], ['secret', 'secret'], ['department', 'department'],
      // v4.30.8：项目 / 接收批次进检索（值可以是 id，也可以是项目号/批次号）
      ['project', 'project'], ['batch', 'batch'],
    ];
    for (const [param, field] of EQ_PARAMS) {
      if (skipIt(param)) continue;
      const v = sp.get(param);
      if (v === null || v === undefined || v === '') continue;
      const c = queryExpr.eq(field, v);
      where.push(c.sql);
      params.push(...c.params);
    }
    if (!skipIt('dateFrom') && sp.get('dateFrom')) { const c = queryExpr.cmp('date', '>=', sp.get('dateFrom')); where.push(c.sql); params.push(...c.params); }
    if (!skipIt('dateTo') && sp.get('dateTo')) { const c = queryExpr.cmp('date', '<=', sp.get('dateTo')); where.push(c.sql); params.push(...c.params); }
    if (!skipIt('hasFile') && sp.get('hasFile') === '1') { const c = queryExpr.eq('hasfile', '1'); where.push(c.sql); params.push(...c.params); }
    if (!skipIt('hasFile') && sp.get('hasFile') === '0') { const c = queryExpr.eq('hasfile', '0'); where.push(c.sql); params.push(...c.params); }

    // 高级检索表达式：`字段:值 AND/OR/NOT`。编译失败会抛 statusCode=400（带 position），
    // 由 buildFiltersOrFail 统一转成响应 —— 见下方。
    const expr = (sp.get('expr') || '').trim();
    if (expr) {
      const c = queryExpr.compile(expr);
      where.push(c.sql);
      params.push(...c.params);
    }

    // 密级范围过滤：**放在最后，且不可省略**。
    // 漏传 user 时按「仅公开」处理（fail-closed）—— 宁可少给数据，不可多给。
    const scope = user ? secretScope(user) : { sql: " AND a.secret_level = '公开'", params: [] };
    if (scope.sql) {
      where.push(scope.sql.replace(/^ AND /, ''));
      params.push(...scope.params);
    }
    return { sql: where.length ? ' WHERE ' + where.join(' AND ') : '', params };
  }

  /**
   * buildFilters 的响应层包装。
   *
   * 表达式写错属于**用户输入错误**，必须回 400 并带上出错位置（前端要把它指出来），
   * 而不是让它冒成 500 —— 那样用户会以为系统坏了，然后去翻日志。
   * 所有列表口径的出口都走这里，顺带保证"同一条表达式在所有出口的报错完全一致"。
   *
   * @returns {{sql:string,params:any[]}|null} null 表示已经写过 400 响应，调用方应当直接 return。
   */
  function buildFiltersOrFail(res, sp, user, skip) {
    try {
      return buildFilters(sp, user, skip);
    } catch (e) {
      if (e && (e.statusCode === 400 || e.position !== undefined)) {
        fail(res, 400, e.message, null, { position: Number(e.position) || 0 });
        return null;
      }
      throw e;
    }
  }

  const SORT_COLUMNS = ['created_at', 'updated_at', 'archive_date', 'archive_code', 'archive_number', 'title', 'year'];

  route('GET', '/api/archives', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sp = url.searchParams;
    const page = Math.max(1, numOr(sp.get('page'), 1));
    const size = Math.min(200, Math.max(1, numOr(sp.get('size'), 20)));
    const f = buildFiltersOrFail(res, sp, u);
    if (!f) return;   // 表达式语法错误，已回 400（含出错位置）
    const sort = q.ident(sp.get('sort') || 'created_at', SORT_COLUMNS);
    const order = String(sp.get('order') || 'desc').toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    const total = Number(q.scalar(`SELECT COUNT(*) FROM archives a ${f.sql}`, ...f.params) || 0);
    const rows = q.all(
      // archive_number（完整档号）必须一起返回（v4.14.0）：
      // 前端列表一律按 `archive_number || archive_code` 显示，缺了这一列时
      // 那个兜底永远走不到，用户看到的就只剩短档案号（Z001-WS·2026-0001 少了前面几段）。
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.type_code, a.category_id, a.retention,
              a.secret_level,
              a.year, a.archive_date, a.status, a.department, a.responsible, a.keywords, a.location, a.updated_at,
              c.name AS category_name,
              p.project_no, p.name AS project_name,
              b.batch_no, b.title AS batch_title, b.received_at AS batch_received_at,
              (SELECT COUNT(*) FROM files f WHERE f.archive_id = a.id) AS file_count,
              (SELECT COUNT(*) FROM loans l WHERE l.archive_id=a.id AND l.status IN ('已批准','逾期')) AS loan_count
       FROM archives a
       LEFT JOIN categories c ON c.id = a.category_id
       LEFT JOIN projects p ON p.id = a.project_id
       LEFT JOIN intake_batches b ON b.id = a.batch_id
       ${f.sql}
       ORDER BY a.${sort} ${order}, a.id DESC
       LIMIT ? OFFSET ?`,
      ...f.params, size, (page - 1) * size,
    );
    // 关键词现在也能命中附件正文 —— 那就必须告诉使用者"这条是靠附件内容命中的"，
    // 否则用户看到一条题名里没有关键词的结果会以为是系统乱给。
    // 只为当前页做（≤200 条），一次查询，不会拖慢列表。
    annotateTextHits(rows, sp.get('kw') || '', u, sp.get('noText') !== '1');
    ok(res, { list: rows, total, page, size, pages: Math.max(1, Math.ceil(total / size)) });
  });

  /**
   * 给当前页的档案补上「命中于附件正文」的标注与片段。
   *
   * 密级：`file_text` 里是附件正文本身，片段同样是涉密内容 ——
   * 所以这里必须逐条确认附件所属档案在用户的可见范围内（rows 已经是可见的，
   * 只要按 rows 里的 id 去查就不会越权）。
   */
  function annotateTextHits(rows, kw, user, withText) {
    if (!withText || !kw.trim() || !rows.length) return;
    let like;
    let fts;
    try {
      like = queryExpr.likeParam(kw);
      fts = queryExpr.ftsPhrase(kw);
    } catch (_) { return; }   // 关键词不构成合法检索式 → 不标注（列表本身已由 buildFilters 处理）
    const ids = rows.map((r) => Number(r.id)).filter(Boolean);
    if (!ids.length) return;
    const holes = ids.map(() => '?').join(',');
    let hits = [];
    try {
      hits = q.all(
        `SELECT t.archive_id, t.file_id, t.content, t.via, t.engine, f.original_name
           FROM file_text t JOIN files f ON f.id=t.file_id
          WHERE t.archive_id IN (${holes})
            AND (t.content LIKE ? ESCAPE '\\'
                 OR t.file_id IN (SELECT rowid FROM file_text_fts WHERE file_text_fts MATCH ?))
          ORDER BY t.char_count DESC`,
        ...ids, like, fts,
      );
    } catch (_) { return; }   // 标注是锦上添花，出错也不能影响检索结果
    const first = new Map();
    for (const h of hits) if (!first.has(h.archive_id)) first.set(h.archive_id, h);
    for (const r of rows) {
      const h = first.get(r.id);
      if (!h) continue;
      r.text_hit = {
        file_id: h.file_id,
        original_name: h.original_name,
        via: h.via || 'native',
        engine: h.engine || '',
        snippet: makeSnippet(h.content, kw),
      };
    }
  }

  /**
   * 档号预览的**唯一**实现。
   *
   * 原先 next-code 与 next-number 是两份几乎一样的代码（只有返回字段名不同）。
   * 后果在 v4.8.0 暴露了：修「没传保管期限时要回退到门类默认值」时只改到一处，
   * 另一处照旧报错 —— 同一个信息两个口径，正是本系统反复吃亏的地方。现在两个路由都走这里。
   */
  function previewArchiveNumber(q, url) {
    const type = url.searchParams.get('type') || 'WS';
    const year = url.searchParams.get('year') || String(new Date().getFullYear());
    const categoryId = Number(url.searchParams.get('category')) || null;
    // 保管期限与分类号会影响 {retention}/{org} 两个占位符。
    // 没传保管期限时**回退到门类默认值** —— 必须与著录同口径（normalizeArchiveInput 就是这么回退的）；
    // 否则用含 {retention} 的标准模板预览会直接报"取不到值"，而正式著录却能成功。
    let retentionName = url.searchParams.get('retention') || '';
    let retentionCode = url.searchParams.get('retention_code') || '';
    if (!retentionName && !retentionCode) {
      const tr = q.get('SELECT retention FROM archive_types WHERE code=?', type);
      retentionName = tr ? String(tr.retention || '') : '';
    }
    if (!retentionCode) retentionCode = RETENTION_MAP[retentionName] ? RETENTION_MAP[retentionName].code : '';
    // 按项目整理的门类要项目号参与编号，预览也必须带上，否则预览与正式出号对不上
    const projectId = Number(url.searchParams.get('project_id')) || 0;
    const projectRow = projectId ? q.get('SELECT project_no FROM projects WHERE id=?', projectId) : null;
    return numbering.previewNumber(q, {
      typeCode: type, year, categoryId, retentionCode,
      categoryCode: url.searchParams.get('category_code') || '',
      projectId, projectNo: projectRow ? String(projectRow.project_no || '') : '',
    });
  }

  route('GET', '/api/archives/next-code', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    try {
      // 走档号规则引擎，保证与正式著录时生成的号码一致
      const p = previewArchiveNumber(q, url);
      ok(res, { code: p.archive_code, archive_number: p.archive_number, template: p.template });
    } catch (e) {
      fail(res, e.statusCode || 400, e.message);
    }
  });

  // 注意：以下为固定具体路径，必须注册在 /api/archives/:id 之前，
  // 否则会被参数路由抢先匹配（把 "next-number" 当成档案 id）。
  /**
   * 高级检索表达式的**字段表**。
   *
   * 为什么要开这个接口：前端要显示「可用字段」和语法提示，如果前端自己抄一份字段名，
   * 就又多了一处会跟 lib/query-expr 漂移的副本 —— 而这正是本系统反复吃过亏的地方
   * （同一套规则写两遍，迟早对不上）。所以字段表只从注册表读，改一处两端同时生效。
   */
  route('GET', '/api/archives/query-fields', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const fields = Object.entries(queryExpr.FIELDS).map(([name, def]) => ({
      name,
      label: def.label || name,
      kind: def.kind,
      aliases: def.aliases || [],
      compare: def.kind === 'num' || def.kind === 'date',   // 是否支持 > >= < <=
      list: def.kind !== 'special',                        // 是否支持 字段:[a,b]
      special: def.special || null,
    }));
    ok(res, { fields, limits: queryExpr.LIMITS, syntax: '字段:值 AND/OR/NOT，支持括号与 "带空格的短语"' });
  });

  route('GET', '/api/archives/next-number', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    try {
      // 与 next-code 同一份实现，只有返回字段名不同（历史上先有 next-number，故保留）
      ok(res, previewArchiveNumber(q, url));
    } catch (e) {
      fail(res, e.statusCode || 400, e.message);
    }
  });

  route('POST', '/api/archives/check-code', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const b = await readJson(req);
    const code = mustStr(b.archive_code, 60).trim();
    const number = mustStr(b.archive_number, 100).trim();
    if (!code && !number) return fail(res, 400, '请提供要查重的档案号或档号');
    const row = code
      ? q.get('SELECT id,title,archive_code,archive_number FROM archives WHERE archive_code=?', code)
      : null;
    const row2 = (!row && number)
      ? q.get('SELECT id,title,archive_code,archive_number FROM archives WHERE archive_number=?', number)
      : null;
    const hit = row || row2;
    ok(res, { available: !hit, conflict: hit || null });
  });

  /**
   * 检索结果分面（v4.11.0）：按各维度给出计数，让使用者一眼看出"这批结果由什么构成"，
   * 并点一下就能收窄。
   *
   * 三条设计决定：
   *  1. **标准分面语义**：算「门类」这一维时，不应用「门类」自己的筛选条件，
   *     其余条件照用。否则选定门类=文书之后，门类分面里就只剩"文书 N 条"，
   *     再也看不到别的门类有多少 —— 那就不是分面，只是把当前条件复述一遍。
   *  2. **计数必须过密级**。数量本身就是涉密信息：一个秘密级用户不该从"机密 12 条"
   *     这种计数里推断出库里有 12 份机密档案。所以每个分面查询都走 buildFilters（自带密级范围）。
   *  3. **不放进 /api/archives 的响应里**。分面要跑 7 条 GROUP BY，
   *     而 /api/archives 还有别的调用方（工作台、常用检索、导出）。分开一个接口，
   *     谁需要谁请求，列表接口该多快还多快。
   *
   * 局限（如实写明）：`expr` 高级表达式在所有分面里都会生效，不会按维度剔除。
   * 因为表达式是任意组合，判断"这一项属不属于门类维度"会变成解析器的活；
   * 使用者若用表达式筛选，分面计数会随之收窄 —— 这是可接受的近似。
   */
  route('GET', '/api/archives/facets', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sp = url.searchParams;
    const limit = Math.min(30, Math.max(3, Number(sp.get('facetLimit')) || 8));

    // 先整体验一次表达式语法，避免"列表能查、分面报错"这种不一致
    const base = buildFiltersOrFail(res, sp, u);
    if (!base) return;
    const total = Number(q.scalar(`SELECT COUNT(*) FROM archives a ${base.sql}`, ...base.params) || 0);

    /** 跑一个维度的分面：忽略该维度自己的筛选条件 */
    const facet = (key, skipKeys, sqlBuilder) => {
      const f = buildFilters(sp, u, new Set(skipKeys));
      const rows = q.all(sqlBuilder(f.sql), ...f.params);
      const values = rows.filter((r) => r.v !== null && r.v !== undefined && String(r.v) !== '')
        .map((r) => ({ value: String(r.v), label: String(r.label || r.v), count: Number(r.c) || 0 }));
      const shown = values.slice(0, limit);
      const restCount = Number(q.scalar(`SELECT COUNT(*) FROM archives a ${f.sql}`, ...f.params) || 0);
      return {
        key,
        values: shown,
        total: restCount,
        more: Math.max(0, values.length - shown.length),
        // 被过滤掉的空值（如未填部门）不计入 values，但要让人知道有多少条没算进来
        blank: Math.max(0, restCount - values.reduce((s, x) => s + x.count, 0)),
      };
    };

    const facets = [
      facet('type', ['type'], (w) => `SELECT a.type_code AS v, t.name AS label, COUNT(*) AS c
          FROM archives a LEFT JOIN archive_types t ON t.code=a.type_code ${w}
          GROUP BY a.type_code ORDER BY c DESC`),
      facet('year', ['year'], (w) => `SELECT a.year AS v, a.year AS label, COUNT(*) AS c
          FROM archives a ${w} GROUP BY a.year ORDER BY a.year DESC`),
      facet('retention', ['retention'], (w) => `SELECT a.retention AS v, a.retention AS label, COUNT(*) AS c
          FROM archives a ${w} GROUP BY a.retention ORDER BY c DESC`),
      facet('secret', ['secret'], (w) => `SELECT a.secret_level AS v, a.secret_level AS label, COUNT(*) AS c
          FROM archives a ${w} GROUP BY a.secret_level ORDER BY c DESC`),
      facet('status', ['status'], (w) => `SELECT a.status AS v, a.status AS label, COUNT(*) AS c
          FROM archives a ${w} GROUP BY a.status ORDER BY c DESC`),
      facet('category', ['category'], (w) => `SELECT a.category_id AS v, c.name AS label, COUNT(*) AS c
          FROM archives a LEFT JOIN categories c ON c.id=a.category_id ${w}
          GROUP BY a.category_id ORDER BY c DESC`),
      facet('department', ['department'], (w) => `SELECT a.department AS v, a.department AS label, COUNT(*) AS c
          FROM archives a ${w} GROUP BY a.department ORDER BY c DESC`),
      // 「有无附件」是布尔维度，用 SUM(CASE) 一次算出两个值，不需要 GROUP BY
      (() => {
        const f = buildFilters(sp, u, new Set(['hasFile']));
        const r = q.get(`SELECT
            COALESCE(SUM(CASE WHEN EXISTS (SELECT 1 FROM files f2 WHERE f2.archive_id=a.id) THEN 1 ELSE 0 END),0) AS with_f,
            COALESCE(SUM(CASE WHEN NOT EXISTS (SELECT 1 FROM files f2 WHERE f2.archive_id=a.id) THEN 1 ELSE 0 END),0) AS without_f
          FROM archives a ${f.sql}`, ...f.params) || {};
        return {
          key: 'hasFile',
          values: [
            { value: '1', label: '有电子附件', count: Number(r.with_f) || 0 },
            { value: '0', label: '无电子附件', count: Number(r.without_f) || 0 },
          ],
          total: (Number(r.with_f) || 0) + (Number(r.without_f) || 0),
          more: 0, blank: 0,
        };
      })(),
      // 正文可检索性：有附件但没提出正文的，就是"搜不到"的那一批（OCR 的主要目标）
      (() => {
        const f = buildFilters(sp, u, []);
        const r = q.get(`SELECT
            COALESCE(SUM(CASE WHEN EXISTS (SELECT 1 FROM file_text t WHERE t.archive_id=a.id AND t.status='成功') THEN 1 ELSE 0 END),0) AS indexed,
            COALESCE(SUM(CASE WHEN EXISTS (SELECT 1 FROM files f3 WHERE f3.archive_id=a.id)
              AND NOT EXISTS (SELECT 1 FROM file_text t WHERE t.archive_id=a.id AND t.status='成功') THEN 1 ELSE 0 END),0) AS unindexed
          FROM archives a ${f.sql}`, ...f.params) || {};
        return {
          key: 'textIndex',
          values: [
            { value: 'indexed', label: '正文已可检索', count: Number(r.indexed) || 0 },
            { value: 'unindexed', label: '有附件但正文搜不到', count: Number(r.unindexed) || 0 },
          ],
          total,
          more: 0,
          blank: 0,
          note: '「正文搜不到」多为扫描件，可在「数据体检 → 正文索引」中做 OCR',
        };
      })(),
    ];

    // 分面里的"当前已选值"回传给前端，前端才知道哪些是激活的
    const active = {};
    for (const [k, field] of [['type', 'type'], ['category', 'category'], ['year', 'year'],
      ['status', 'status'], ['retention', 'retention'], ['secret', 'secret'],
      ['department', 'department'], ['hasFile', 'hasFile']]) {
      const v = sp.get(field);
      if (v) active[k] = v;
    }
    ok(res, { total, facets, active, kw: sp.get('kw') || '', limit });
  });

  route('GET', '/api/archives/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    // 先做密级校验再取详情：超出密级上限时按 404 响应，不泄露存在性
    if (!loadVisibleArchive(req, res, u, id)) return;
    const row = archiveRow(id);
    if (!row) return fail(res, 404, '档案不存在或已删除');
    // 利用登记（V4.32.0）：查详情=一次"查阅"，记在台账上
    recordUsage(u, id, '查阅', { target: row.archive_code || String(id), ip: clientIp(req) });
    // 关联件：件级整理下「新资料另立一件 + 与原件建立关联」是标准做法，详情页要直接看得到
    row.links = archiveLinksOf(id, u);
    // 正文替换留痕：替换过就该在详情页看得到，而不是埋在另一个接口里等人想起来查
    row.replacements = q.all(
      `SELECT r.id, r.file_id, r.old_name, r.old_sha256, r.old_size, r.reason, r.replaced_at,
              usr.display_name AS by_name
         FROM file_replacements r LEFT JOIN users usr ON usr.id=r.replaced_by
        WHERE r.archive_id=? ORDER BY r.id DESC LIMIT 50`, id,
    );
    // 鉴定历史（v4.10.0）：三鉴合在一处按类别显示 —— 一件档案先后被价值/密级/开放鉴定过什么，
    // 是"它为什么现在处于这个保管期限、这个密级、这个开放状态"的唯一解释。
    row.appraisals = q.all(
      `SELECT p.id, p.kind, p.decision, p.new_retention, p.new_secret_level, p.new_secret_to,
              p.new_open_state, p.control_reason, p.open_delay_to, p.basis, p.basis_ref,
              p.group_opinion, p.member_count, p.appraised_at, p.batch_id, p.before_state,
              usr.display_name AS appraiser_name, b.batch_no
         FROM appraisals p LEFT JOIN users usr ON usr.id=p.appraiser_id
         LEFT JOIN appraisal_batches b ON b.id=p.batch_id
        WHERE p.archive_id=? ORDER BY p.id DESC LIMIT 50`, id,
    );
    ok(res, row);
  });

  // ===== 关联件与补充归档（v4.9.0）=====
  /**
   * 关联件查询。
   *
   * 三个刻意的设计：
   *   1. **一条记录表示一个关系，两个方向都算**。双向各存一行迟早会出现
   *      "只解除了其中一边"的脏数据，那时两份档案对彼此的显示就矛盾了。
   *      `pair_key`（较小id|较大id|种类）在数据库层面保证同一对档案同一种关系只有一条。
   *   2. **对方档案看不到时，整条关联静默省略，连数量都不给**。
   *      关联件的题名本身就是涉密信息 —— 报"还有 1 条你看不到"等于确认了它的存在。
   *      这与本系统"数量本身就是涉密信息"的口径一致。
   *   3. kind 区分「参见 / 补充归档 / 同一事由」：三者业务含义不同，
   *      补充归档要能单独统计与出登记表，不能混成一种"相关"。
   */
  const LINK_KINDS = ['参见', '补充归档', '同一事由'];

  function linkPairKey(a, b, kind) {
    return `${Math.min(Number(a), Number(b))}|${Math.max(Number(a), Number(b))}|${kind}`;
  }

  function archiveLinksOf(id, user) {
    const scope = user ? secretScope(user) : { sql: " AND a.secret_level = '公开'", params: [] };
    const rows = q.all(
      `SELECT l.id, l.kind, l.note, l.created_at, l.created_by, l.from_id, l.to_id,
              a.id AS aid, a.archive_code, a.archive_number, a.title, a.year, a.type_code, a.status,
              usr.display_name AS by_name
         FROM archive_links l
         JOIN archives a ON a.id = CASE WHEN l.from_id = ? THEN l.to_id ELSE l.from_id END
         LEFT JOIN users usr ON usr.id = l.created_by
        WHERE (l.from_id = ? OR l.to_id = ?)${scope.sql}
        ORDER BY l.kind, l.id DESC`,
      id, id, id, ...scope.params,
    );
    return rows.map((r) => ({
      id: r.id, kind: r.kind, note: r.note, created_at: r.created_at, by: r.by_name || '',
      direction: Number(r.from_id) === Number(id) ? 'out' : 'in',
      archive: {
        id: r.aid, archive_code: r.archive_code, archive_number: r.archive_number,
        title: r.title, year: r.year, type_code: r.type_code, status: r.status,
      },
    }));
  }

  route('GET', '/api/archives/:id/links', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    ok(res, { list: archiveLinksOf(id, u), kinds: LINK_KINDS });
  });

  /** 建立关联（可一次关联多件） */
  route('POST', '/api/archives/:id/links', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const me = loadVisibleArchive(req, res, u, id);
    if (!me) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有建立关联的权限');
    const b = await readJson(req);
    const kind = mustStr(b.kind, 20) || '参见';
    if (!LINK_KINDS.includes(kind)) return fail(res, 400, `关联种类只能是：${LINK_KINDS.join(' / ')}`);
    const toIds = (Array.isArray(b.to_ids) ? b.to_ids : []).map(Number).filter(Boolean);
    if (!toIds.length) return fail(res, 400, '请选择要关联的档案');
    if (toIds.length > 50) return fail(res, 400, '一次最多关联 50 件');
    const note = mustStr(b.note, 300);

    const created = [];
    const skipped = [];
    for (const tid of toIds) {
      if (tid === id) { skipped.push({ id: tid, reason: '不能与自身关联' }); continue; }
      const other = q.get('SELECT id, secret_level, archive_code FROM archives WHERE id=?', tid);
      // 看不到的档案按"不存在"处理：不能借关联接口确认它的存在
      const visible = other && (() => {
        const sc = secretScope(u);
        return Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.id=?${sc.sql}`, tid, ...sc.params)) > 0;
      })();
      if (!visible) { skipped.push({ id: tid, reason: '档案不存在或不可见' }); continue; }
      const key = linkPairKey(id, tid, kind);
      if (q.scalar('SELECT COUNT(*) FROM archive_links WHERE pair_key=?', key)) {
        skipped.push({ id: tid, reason: '这两件之间已有同类关联' }); continue;
      }
      const r = q.run(
        `INSERT INTO archive_links(from_id,to_id,kind,note,pair_key,created_by,created_at) VALUES(?,?,?,?,?,?,?)`,
        id, tid, kind, note, key, u.id, nowIso(),
      );
      created.push({ id: Number(r.lastInsertRowid), to_id: tid, kind });
    }
    if (created.length) {
      log(u, '建立关联件', me.archive_code,
        `${kind}：关联 ${created.length} 件${note ? '　备注：' + note : ''}`, clientIp(req), { step: '关联件' });
    }
    ok(res, { created, skipped, links: archiveLinksOf(id, u) });
  });

  /** 解除关联 */
  route('DELETE', '/api/links/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有解除关联的权限');
    const lid = Number(params.id);
    const l = q.get('SELECT * FROM archive_links WHERE id=?', lid);
    if (!l) return fail(res, 404, '关联不存在');
    // 关联的两端任一可见即可解除（否则跨密级的关联谁都解不掉，只能改库）
    const sc = secretScope(u);
    const visible = Number(q.scalar(
      `SELECT COUNT(*) FROM archives a WHERE a.id IN (?,?)${sc.sql}`, l.from_id, l.to_id, ...sc.params)) > 0;
    if (!visible) return fail(res, 404, '关联不存在');
    const from = q.get('SELECT archive_code FROM archives WHERE id=?', l.from_id);
    q.run('DELETE FROM archive_links WHERE id=?', lid);
    log(u, '解除关联件', (from && from.archive_code) || '', `关联 #${lid}（${l.kind}）`, clientIp(req), { step: '关联件' });
    ok(res, true);
  });

  /**
   * 补充归档登记（DA/T 22—2015 件级整理下的标准做法）。
   *
   * 为什么不是"把新资料插进原件"：DA/T 22—2015 以**件**为整理单位，
   * 往一个已编好的件里插页会让它的页数、归档章、元数据 M05/M07、
   * 已打印的移交清册全部对不上。所以标准做法是**另立一件**（编新件号），
   * 再与原档案建立「补充归档」关联，并在这里登记原因与经办人。
   *
   * body: `{ new_ids: [新件id], reason, note, add_to_box_note? }`
   */
  route('POST', '/api/archives/:id/supplement', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const me = loadVisibleArchive(req, res, u, id);
    if (!me) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有补充归档的权限');
    const b = await readJson(req);
    const newIds = (Array.isArray(b.new_ids) ? b.new_ids : []).map(Number).filter(Boolean);
    if (!newIds.length) return fail(res, 400, '请选择要补充归档的新增档案');
    if (newIds.length > 50) return fail(res, 400, '一次最多补充归档 50 件');
    const reason = mustStr(b.reason, 200);
    if (!reason.trim()) return fail(res, 400, '请填写补充归档的原因（例如：原件附件后补）');
    const note = mustStr(b.note, 300);

    const created = [];
    const skipped = [];
    for (const tid of newIds) {
      if (tid === id) { skipped.push({ id: tid, reason: '不能把档案补充归档到它自己' }); continue; }
      const sc = secretScope(u);
      const visible = Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.id=?${sc.sql}`, tid, ...sc.params)) > 0;
      if (!visible) { skipped.push({ id: tid, reason: '档案不存在或不可见' }); continue; }
      const key = linkPairKey(id, tid, '补充归档');
      if (q.scalar('SELECT COUNT(*) FROM archive_links WHERE pair_key=?', key)) {
        skipped.push({ id: tid, reason: '这件已经登记过补充归档' }); continue;
      }
      const r = q.run(
        `INSERT INTO archive_links(from_id,to_id,kind,note,pair_key,created_by,created_at) VALUES(?,?,?,?,?,?,?)`,
        id, tid, '补充归档', [reason, note].filter(Boolean).join('　'), key, u.id, nowIso(),
      );
      created.push({ id: Number(r.lastInsertRowid), to_id: tid });
    }
    if (!created.length) {
      return fail(res, 400, '没有可登记的档案：' + skipped.map((s) => s.reason).join('；'));
    }

    // 写进备考表的「盒内文件情况说明」：这是纸质实体上唯一能留下补充归档痕迹的地方
    // （DA/T 22—2015 §6.5 备考表置于盒内文件之后，用来记盒内文件的特殊情况）。
    let boxNoteUpdated = false;
    let boxCode = '';
    if (b.add_to_box_note) {
      const cur = q.get('SELECT id, box_id, archive_code, archive_number FROM archives WHERE id=?', id);
      if (cur && cur.box_id) {
        const box = q.get('SELECT id, box_code, inventory_note FROM archive_boxes WHERE id=?', cur.box_id);
        if (box) {
          boxCode = box.box_code;
          const nums = created.map((c) => {
            const r = q.get('SELECT archive_number, archive_code FROM archives WHERE id=?', c.to_id);
            return (r && (r.archive_number || r.archive_code)) || ('#' + c.to_id);
          });
          const line = `${nowIso().slice(0, 10)} 补充归档：${cur.archive_number || cur.archive_code} 之后补入 `
            + `${nums.join('、')}（${reason}）`;
          const next = [String(box.inventory_note || '').trim(), line].filter(Boolean).join('\n');
          q.run('UPDATE archive_boxes SET inventory_note=?, updated_at=? WHERE id=?', next.slice(0, 2000), nowIso(), box.id);
          boxNoteUpdated = true;
        }
      }
    }

    log(u, '补充归档登记', me.archive_code,
      `补入 ${created.length} 件　原因：${reason}${boxNoteUpdated ? `　已写入备考表（${boxCode}）` : ''}`,
      clientIp(req), { step: '补充归档', category: 'business' });
    ok(res, {
      created, skipped, box_note_updated: boxNoteUpdated, box_code: boxCode,
      links: archiveLinksOf(id, u),
      print_url: `/api/archives/${id}/supplement/print`,
    });
  });

  /** 补充归档登记表（可打印，供纸质卷内留痕与签字） */
  route('GET', '/api/archives/:id/supplement/print', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const me = loadVisibleArchive(req, res, u, id);
    if (!me) return;
    const links = archiveLinksOf(id, u).filter((l) => l.kind === '补充归档');
    const rows = links.map((l, i) => `<tr>
      <td>${i + 1}</td>
      <td class="mono">${esc(l.archive.archive_number || l.archive.archive_code || '')}</td>
      <td>${esc(l.archive.title || '')}</td>
      <td>${esc(l.archive.year || '')}</td>
      <td>${esc((l.note || '').split('　')[0] || '')}</td>
      <td>${esc(String(l.created_at || '').slice(0, 10))}</td>
      <td>${esc(l.by || '')}</td>
    </tr>`).join('') || '<tr><td colspan="7" style="text-align:center">（这件档案尚无补充归档记录）</td></tr>';
    const body = `
      <div class="print-head"><h1>补 充 归 档 登 记 表</h1><div class="meta">
        原档案档号：<span class="mono">${esc(me.archive_number || me.archive_code || '')}</span>　
        年度：${esc(me.year || '—')}　门类：${esc(me.type_code || '—')}　保管期限：${esc(me.retention || '—')}<br>
        题名：${esc(me.title || '')}</div></div>

      <div class="rep-block">
        <div class="rep-title">补充归档明细（共 ${links.length} 件）</div>
        <table class="print-table"><thead><tr>
          <th style="width:44px">序号</th><th style="width:168px">补入件档号</th><th>题名</th>
          <th style="width:54px">年度</th><th style="width:140px">补充原因</th>
          <th style="width:84px">登记日期</th><th style="width:72px">经办人</th>
        </tr></thead>
        <tbody>${rows}</tbody></table>
      </div>

      <div class="beikao" style="margin-top:14px">
        <h2>说明</h2>
        <div class="bk-body">
          <div class="bk-note">依据 DA/T 22—2015《归档文件整理规则》，归档文件以「件」为整理单位：
            新发现的材料应<b>另立一件并编新件号</b>，与本表所列原档案建立关联，
            <b>不在原件的页序中插入</b> —— 插页会使原件的页数、归档章、元数据与已打印的移交清册全部对不上。
            本表随该件一并归档，作为补充归档的书面凭据。</div>
          <div class="bk-sign">
            <div>整理人：<span class="bk-line">&nbsp;</span></div>
            <div>整理日期：<span class="bk-line">&nbsp;</span></div>
            <div>检查人：<span class="bk-line">&nbsp;</span></div>
            <div>检查日期：<span class="bk-line">&nbsp;</span></div>
          </div>
        </div>
      </div>`;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(printShell(`补充归档登记表 ${me.archive_code || ''}`, body, url.searchParams.get('print') === '1'));
  });

  function normalizeArchiveInput(b, cur) {
    const typeCode = mustStr(b.type_code || (cur && cur.type_code), 16) || 'WS';
    const t = q.get('SELECT * FROM archive_types WHERE code=?', typeCode);
    if (!t) throw Object.assign(new Error('未知的档案门类：' + typeCode), { statusCode: 400 });
    const title = mustStr(b.title, 300).trim();
    if (!title) throw Object.assign(new Error('题名不能为空'), { statusCode: 400 });
    const year = mustStr(b.year, 8).trim() || (mustStr(b.archive_date, 12).slice(0, 4)) || String(new Date().getFullYear());
    const fields = safeParse(t.fields, []);
    const allowedKeys = new Set(fields.map((f) => f.key));
    const extraIn = (b.extra && typeof b.extra === 'object') ? b.extra : {};
    const extra = {};
    for (const [k, v] of Object.entries(extraIn)) {
      if (allowedKeys.has(k)) extra[k] = mustStr(v, 500);
    }
    // 保管期限：同步维护代码与到期年度，供“到期提醒/鉴定”使用
    // 注意：不要静默回退为默认值 —— 前端若传来不在合法集合里的值（例如早期数据里的 '30年'），
    // 静默回退会把用户的保管期限改错。这里要求显式传合法值。
    let retention;
    if (b.retention !== undefined && b.retention !== null && String(b.retention).trim() !== '') {
      const want = String(b.retention).trim();
      if (!RETENTIONS.includes(want)) {
        throw Object.assign(
          new Error(`保管期限取值不合法：「${want}」。可选：${RETENTIONS.join(' / ')}`),
          { statusCode: 400 },
        );
      }
      retention = want;
    } else {
      retention = cur ? cur.retention : t.retention;
    }
    const rInfo = RETENTION_MAP[retention] || { code: '', years: 0 };
    const archiveDate = mustStr(b.archive_date, 12).trim() || (cur ? cur.archive_date : today());
    // 到期年度从**归档年度**起算（国家档案局令第 8 号：定期保管期限自归档年度起算）。
    // 早先这里用的是 archive_date 的年份，于是「给了 year=2015、没给 archive_date」
    // 会算出 今天+5 年 —— 年度与到期年度自相矛盾，到期提醒整整晚报 11 年。
    // 现在以 year 为准（year 本身已回落到 archive_date 的年、再回落到今年），口径唯一。
    const dueYear = rInfo.years > 0
      ? (Number(year) || Number(String(archiveDate).slice(0, 4))) + rInfo.years
      : 0;
    // 拼音检索键（v4.11.0）：在**写入路径**上算一次，检索路径上就只做 LIKE。
    // 放在 normalizeArchiveInput 里是为了让"新建 / 修改 / 导入 / 批量修改"四条路径共用同一份计算。
    const pyKeys = pinyinLib.archiveKeys({
      title, keywords: mustStr(b.keywords, 300), responsible: mustStr(b.responsible, 200),
    });
    const categoryId = Number(b.category_id || (cur && cur.category_id) || 0) || null;
    const catRow = categoryId ? q.get('SELECT code FROM categories WHERE id=?', categoryId) : null;
    return {
      type_code: typeCode,
      title,
      category_id: categoryId,
      retention,
      retention_code: rInfo.code,
      retention_years: rInfo.years,
      retention_due_year: dueYear,
      secret_level: SECRET_LEVELS.includes(b.secret_level) ? b.secret_level : (cur ? cur.secret_level : '公开'),
      year,
      archive_date: archiveDate,
      volume_no: mustStr(b.volume_no, 30),
      item_no: mustStr(b.item_no, 30),
      pages: mustStr(b.pages, 30),
      copies: Math.max(1, numOr(b.copies, cur ? cur.copies : 1)),
      carrier: CARRIERS.includes(b.carrier) ? b.carrier : (cur ? cur.carrier : '纸质'),
      responsible: mustStr(b.responsible, 100),
      department: mustStr(b.department, 100),
      abstract: mustStr(b.abstract, 4000),
      keywords: mustStr(b.keywords, 300),
      extra: JSON.stringify(extra),
      location: mustStr(b.location, 100),
      status: STATUSES.includes(b.status) ? b.status : (cur ? cur.status : '在库'),
      status_note: mustStr(b.status_note, 200),
      unit_code: mustStr(b.unit_code, 40) || numbering.getSetting(q, 'archive.unit_code', 'Z001'),
      category_code: mustStr(b.category_code, 40) || (catRow ? String(catRow.code) : (cur ? cur.category_code : '')),
      catalog_no: mustStr(b.catalog_no, 20) || numbering.getSetting(q, 'archive.catalog_no', '01'),
      open_state: OPEN_STATES.includes(b.open_state) ? b.open_state : (cur ? cur.open_state : '未鉴定'),
      electronic_flag: mustStr(b.electronic_flag, 20) || (cur ? cur.electronic_flag : '纸质'),
      // ---- 密级鉴定所需的定密信息（v4.10.0）----
      // 这里只是**登记**（著录时把当年定的保密期限如实录进来），不是"定密"，
      // 所以不在这里卡 secret:classify 权限；真正的解密/降密走 /appraise 与 /secret。
      secret_term: mustStr(b.secret_term, 20) || (cur ? cur.secret_term : ''),
      secret_from: mustStr(b.secret_from, 12).slice(0, 10) || (cur ? cur.secret_from : ''),
      secret_to: mustStr(b.secret_to, 12).slice(0, 10) || (cur ? cur.secret_to : ''),
      secret_basis: mustStr(b.secret_basis, 200) || (cur ? cur.secret_basis : ''),
      declassify_condition: mustStr(b.declassify_condition, 200) || (cur ? cur.declassify_condition : ''),
      py_full: pyKeys.full,
      py_initials: pyKeys.initials,
      // ---- 过程接收（v4.22 数据模型）----
      // 项目与批次决定"这批资料是谁什么时候交的"，也是过程区目录的依据。
      // 给了批次但没给项目时自动跟随批次的项目；接收日期默认取批次的接收日期。
      //
      // 未传时**沿用原值**而不是清空：修改著录、批量改字段、导入更新这些路径
      // 不一定带着这三项，若默认清零，一次无关的修改就会把已归档的件打回过程、把项目归属丢掉。
      project_id: b.project_id === undefined ? (cur ? cur.project_id : null) : (Number(b.project_id) || null),
      batch_id: b.batch_id === undefined ? (cur ? cur.batch_id : null) : (Number(b.batch_id) || null),
      received_at: mustStr(b.received_at, 12).slice(0, 10) || (cur ? cur.received_at : '') || '',
      archive_state: b.archive_state === undefined
        ? (cur ? cur.archive_state : '过程')
        : (String(b.archive_state) === '已归档' ? '已归档' : '过程'),
      // 门类整理方式（v4.30.7）：year=按年度 / project=按项目
      filing_mode: String(t.filing_mode || 'year') === 'project' ? 'project' : 'year',
    };
  }

  /**
   * 把一件档案挂到「项目 + 批次」上（过程接收，v4.29.0）。
   *
   * 三个默认值都是有意的：
   *   · 给了批次没给项目 → 跟随批次的项目（一件资料不可能属于另一个项目）
   *   · 没给接收日期 → 取批次的接收日期（"这批是什么时候交来的"）
   *   · 归档状态默认"过程"，只有归档定稿才改成"已归档"
   *
   * 为什么单独成一个函数：新建、修改、批量导入三条路径都要做同一件事，
   * 分散写三份迟早会出现"新建的挂上了、改过的没挂上"这种半对半错的状态。
   */
  function applyIntake(archiveId, v) {
    const batch = v.batch_id ? q.get('SELECT * FROM intake_batches WHERE id=?', v.batch_id) : null;
    const projectId = v.project_id || (batch && batch.project_id) || null;
    const receivedAt = v.received_at || (batch && batch.received_at) || '';
    q.run('UPDATE archives SET project_id=?, batch_id=?, received_at=?, archive_state=? WHERE id=?',
      projectId, v.batch_id || null, receivedAt, v.archive_state || '过程', archiveId);
    for (const bid of new Set([v.batch_id, batch && batch.id])) {
      if (!bid) continue;
      const n = Number(q.scalar('SELECT COUNT(*) FROM archives WHERE batch_id=?', bid) || 0);
      q.run('UPDATE intake_batches SET archive_count=? WHERE id=?', n, bid);
    }
    return { projectId, batchId: v.batch_id || null, receivedAt };
  }

  route('POST', '/api/archives', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:create')) return fail(res, 403, '没有新建档案的权限');
    const b = await readJson(req);
    const v = normalizeArchiveInput(b, null);
    if (!v.category_id) return fail(res, 400, '请选择档案分类');
    if (!q.get('SELECT id FROM categories WHERE id=?', v.category_id)) return fail(res, 400, '档案分类不存在');

    // 按项目整理的门类：项目号要进档号，没选项目就没法编号 —— 与其生成一个
    // 缺项目号的档号（出馆移交时才发现），不如当场说清楚缺什么。
    if (v.filing_mode === 'project' && !v.project_id) {
      return fail(res, 400, '该门类按「项目」整理，请先选择所属项目（项目号会写进档号）');
    }
    const projectRow = v.project_id ? q.get('SELECT project_no FROM projects WHERE id=?', v.project_id) : null;
    if (v.filing_mode === 'project' && !projectRow) {
      return fail(res, 400, '所选项目不存在，请重新选择');
    }

    let code = mustStr(b.archive_code, 60).trim();
    let number = mustStr(b.archive_number, 100).trim();
    if (!code || !number) {
      // 由档号规则引擎生成（含规范档号与兼容短档案号）
      const gen = numbering.nextNumber(q, {
        typeCode: v.type_code,
        year: v.year,
        categoryId: v.category_id,
        // {retention} 与 {org} 依赖这两项，必须传进去，
        // 否则模板里用到它们时生成出来的档号会缺段
        retentionCode: v.retention_code,
        categoryCode: v.category_code,
        // 按项目整理时的取号维度
        projectId: v.project_id,
        projectNo: projectRow ? String(projectRow.project_no || '') : '',
      });
      if (!code) code = gen.archive_code;
      if (!number) number = gen.archive_number;
    }
    if (q.scalar('SELECT id FROM archives WHERE archive_code=?', code)) {
      return fail(res, 409, `档案号 ${code} 已存在，请更换`);
    }
    if (number && q.scalar('SELECT id FROM archives WHERE archive_number=?', number)) {
      return fail(res, 409, `档号 ${number} 已存在，请更换`);
    }
    const ts = nowIso();
    const r = q.run(
      `INSERT INTO archives(archive_code,archive_number,title,category_id,type_code,retention,retention_code,
        retention_years,retention_due_year,secret_level,year,archive_date,volume_no,item_no,pages,copies,carrier,
        responsible,department,abstract,keywords,extra,location,status,status_note,unit_code,category_code,
        catalog_no,open_state,electronic_flag,secret_term,secret_from,secret_to,secret_basis,declassify_condition,
        py_full,py_initials,created_via,created_by,created_at,updated_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      code, number, v.title, v.category_id, v.type_code, v.retention, v.retention_code,
      v.retention_years, v.retention_due_year, v.secret_level, v.year, v.archive_date, v.volume_no, v.item_no,
      v.pages, v.copies, v.carrier, v.responsible, v.department, v.abstract, v.keywords, v.extra, v.location,
      v.status, v.status_note, v.unit_code, v.category_code, v.catalog_no, v.open_state, v.electronic_flag,
      v.secret_term, v.secret_from, v.secret_to, v.secret_basis, v.declassify_condition,
      v.py_full, v.py_initials,
      '手工著录', u.id, ts, ts,
    );
    log(u, '新建档案', code, `${v.title}（档号 ${number}）`, clientIp(req));
    // 新建后立刻生成该档案的二维码图片，不用等到下次重启系统
    const newId = r.lastInsertRowid;
    // 过程接收归属：批次/项目/接收日期（不给批次时保持为空，不影响老的著录流程）
    try { applyIntake(newId, v); } catch (e) {
      console.warn('[过程接收] 归属写入失败（不影响著录）：' + e.message);
    }
    try {
      const created = archiveForQr(newId);
      if (created) ensureArchiveQr(created, { force: true });
    } catch (e) {
      console.warn('[档案二维码] 生成失败（不影响著录）：' + e.message);
    }
    // 新建即自动捕获元数据：元数据"以自动捕获为主、手工著录为辅"（《数字档案室建设指南》§5.1.2）
    let metaSnap = null;
    try { metaSnap = captureAndSaveMetadata(newId, u, '新建档案时自动捕获'); } catch (e) {
      console.warn('[元数据] 自动捕获失败（不影响著录）：' + e.message);
    }
    ok(res, {
      id: newId, archive_code: code, archive_number: number,
      metadata_completeness: metaSnap ? metaSnap.completeness : null,
    });
  });

  /**
   * 存一份「改前快照」（v4.32.0 豆包信创）。
   * 用法：在任何会改档案行的操作**之前**调用，把当前整行留档；
   * 之后发现改错了，/api/archives/:id/versions/:vid/restore 能一键还原。
   * 快照写失败只告警、不阻断主流程 —— 存不了历史版本，也不该让人改不了档案。
   */
  function snapshotArchive(row, user, action, note) {
    if (!row) return null;
    try {
      const info = q.run(
        `INSERT INTO archive_versions(archive_id, archive_code, title, snapshot, action, note,
           changed_by, changed_by_id, changed_at)
         VALUES(?,?,?,?,?,?,?,?,?)`,
        row.id, row.archive_code || '', row.title || '', JSON.stringify(row),
        action || '修改', note || '',
        user ? (user.display_name || user.username || '') : '系统', user ? user.id : null, nowIso(),
      );
      return info && info.lastInsertRowid;
    } catch (e) {
      console.warn('[历史版本] 快照写入失败（不影响主流程）：' + e.message);
      return null;
    }
  }

  route('PUT', '/api/archives/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM archives WHERE id=?', id);
    if (!cur) return fail(res, 404, '档案不存在');
    if (!can(u, 'archive:update', { ownerId: cur.created_by })) return fail(res, 403, '没有修改该档案的权限');
    // 记下「修改前」的二维码文件名，改完要把它清掉（否则档号一改就留下孤儿图片）
    const oldQrName = archiveQrLib.plannedBaseName(db, cur);
    const b = await readJson(req);
    const v = normalizeArchiveInput(b, cur);
    if (!v.category_id) return fail(res, 400, '请选择档案分类');
    let code = mustStr(b.archive_code, 60).trim() || cur.archive_code;
    if (code !== cur.archive_code && q.scalar('SELECT id FROM archives WHERE archive_code=?', code)) {
      return fail(res, 409, `档案号 ${code} 已存在`);
    }
    let number = mustStr(b.archive_number, 100).trim() || cur.archive_number;
    if (number && number !== cur.archive_number && q.scalar('SELECT id FROM archives WHERE archive_number=?', number)) {
      return fail(res, 409, `档号 ${number} 已存在`);
    }
    // 改密级要过定密权限：三员分立下密级由安全保密员定，档案员改不了（v4.10.0）
    if (v.secret_level !== cur.secret_level && !can(u, 'secret:classify')) {
      return fail(res, 403, '变更密级需系统安全保密员或管理员权限');
    }
    // 改之前先留个底：万一改坏了（改错年度、错门类、错档号），能一键回到这一版
    snapshotArchive(cur, u, '修改', '编辑前自动留底');
    q.run(
      `UPDATE archives SET archive_code=?, archive_number=?, title=?, category_id=?, type_code=?,
        retention=?, retention_code=?, retention_years=?, retention_due_year=?, secret_level=?,
        year=?, archive_date=?, volume_no=?, item_no=?, pages=?, copies=?, carrier=?, responsible=?,
        department=?, abstract=?, keywords=?, extra=?, location=?, status=?, status_note=?,
        unit_code=?, category_code=?, catalog_no=?, open_state=?, electronic_flag=?,
        secret_term=?, secret_from=?, secret_to=?, secret_basis=?, declassify_condition=?,
        py_full=?, py_initials=?, updated_at=?
       WHERE id=?`,
      code, number, v.title, v.category_id, v.type_code, v.retention, v.retention_code,
      v.retention_years, v.retention_due_year, v.secret_level, v.year, v.archive_date,
      v.volume_no, v.item_no, v.pages, v.copies, v.carrier, v.responsible, v.department, v.abstract,
      v.keywords, v.extra, v.location, v.status, v.status_note, v.unit_code, v.category_code,
      v.catalog_no, v.open_state, v.electronic_flag,
      v.secret_term, v.secret_from, v.secret_to, v.secret_basis, v.declassify_condition,
      v.py_full, v.py_initials, nowIso(), id,
    );
    // 过程接收归属：改档时可能把一件从这批挪到那批，或从过程改成已归档
    try { applyIntake(id, v); } catch (e) {
      console.warn('[过程接收] 归属更新失败（不影响修改）：' + e.message);
    }
    // 密级变了要单独留痕：审计里"修改档案"四个字看不出密级被动过，
    // 而密级变更恰恰是安全审计最关心的动作。
    if (v.secret_level !== cur.secret_level) {
      log(u, '变更密级', code, `${cur.secret_level} → ${v.secret_level}`, clientIp(req),
        { step: '定密', category: 'security' });
    }
    log(u, '修改档案', code, v.title, clientIp(req));
    // 档号或题名变了，二维码内容/文件名也要跟着变：
    // 先按「修改前」的全库计划算出旧文件名并删掉，再按新信息生成，避免留下两份对不上的图片。
    try {
      if (oldQrName) archiveQrLib.removeOne(cur, qrDir(), oldQrName);
      const after = archiveForQr(id);
      if (after) ensureArchiveQr(after, { force: true });
    } catch (e) {
      console.warn('[档案二维码] 更新失败（不影响修改）：' + e.message);
    }
    // 档案改了，元数据要跟着重新捕获（背景/结构/管理过程元数据的值都来源于档案行）
    try { captureAndSaveMetadata(id, u, '档案信息修改后同步'); } catch (e) {
      console.warn('[元数据] 同步失败（不影响修改）：' + e.message);
    }
    ok(res, true);
  });

  // 历史版本列表（v4.32.0 豆包信创）：谁在什么时候改过、改之前是什么样
  route('GET', '/api/archives/:id/versions', (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const a = q.get('SELECT id, archive_code, title, created_by FROM archives WHERE id=?', id);
    if (!a) return fail(res, 404, '档案不存在');
    if (!can(u, 'archive:read', { ownerId: a.created_by })) return fail(res, 403, '没有查看该档案的权限');
    const list = q.all(
      `SELECT id, archive_code, title, action, note, changed_by, changed_at
         FROM archive_versions WHERE archive_id=? ORDER BY id DESC LIMIT 100`, id,
    );
    ok(res, { list, can_restore: !!can(u, 'archive:update', { ownerId: a.created_by }) });
  });

  // 一键还原到某个历史版本。
  // 还原本身也是一次修改：先把"还原前"的现状再存一版，还原错了还能再退回来（不会丢东西）。
  route('POST', '/api/archives/:id/versions/:vid/restore', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const vid = Number(params.vid);
    const cur = q.get('SELECT * FROM archives WHERE id=?', id);
    if (!cur) return fail(res, 404, '档案不存在');
    if (!can(u, 'archive:update', { ownerId: cur.created_by })) return fail(res, 403, '没有修改该档案的权限');
    const vrow = q.get('SELECT * FROM archive_versions WHERE id=? AND archive_id=?', vid, id);
    if (!vrow) return fail(res, 404, '该历史版本不存在（可能已被清理）');
    let snap;
    try { snap = JSON.parse(vrow.snapshot); } catch (e) { return fail(res, 500, '历史版本数据损坏，无法还原'); }

    // 密级回退同样过定密权限：不能靠"还原"绕过三员分立
    if (snap.secret_level !== cur.secret_level && !can(u, 'secret:classify')) {
      return fail(res, 403, '该版本会变更密级，需系统安全保密员或管理员权限');
    }
    // 档号被别的件占用了就不能还原（否则会撞号）
    if (snap.archive_code && snap.archive_code !== cur.archive_code
      && q.scalar('SELECT id FROM archives WHERE archive_code=? AND id<>?', snap.archive_code, id)) {
      return fail(res, 409, `还原失败：档案号 ${snap.archive_code} 已被其它档案占用，请先处理冲突`);
    }
    if (snap.archive_number && snap.archive_number !== cur.archive_number
      && q.scalar('SELECT id FROM archives WHERE archive_number=? AND id<>?', snap.archive_number, id)) {
      return fail(res, 409, `还原失败：档号 ${snap.archive_number} 已被其它档案占用`);
    }

    snapshotArchive(cur, u, '还原前自动备份', `还原到版本 #${vid}`);
    q.run(
      `UPDATE archives SET archive_code=?, archive_number=?, title=?, category_id=?, type_code=?,
        retention=?, retention_code=?, retention_years=?, retention_due_year=?, secret_level=?,
        year=?, archive_date=?, volume_no=?, item_no=?, pages=?, copies=?, carrier=?, responsible=?,
        department=?, abstract=?, keywords=?, extra=?, location=?, status=?, status_note=?,
        unit_code=?, category_code=?, catalog_no=?, open_state=?, electronic_flag=?,
        secret_term=?, secret_from=?, secret_to=?, secret_basis=?, declassify_condition=?,
        py_full=?, py_initials=?, updated_at=?
       WHERE id=?`,
      snap.archive_code, snap.archive_number, snap.title, snap.category_id, snap.type_code,
      snap.retention, snap.retention_code, snap.retention_years, snap.retention_due_year, snap.secret_level,
      snap.year, snap.archive_date, snap.volume_no, snap.item_no, snap.pages, snap.copies, snap.carrier,
      snap.responsible, snap.department, snap.abstract, snap.keywords, snap.extra, snap.location,
      snap.status, snap.status_note, snap.unit_code, snap.category_code, snap.catalog_no,
      snap.open_state, snap.electronic_flag,
      snap.secret_term, snap.secret_from, snap.secret_to, snap.secret_basis, snap.declassify_condition,
      snap.py_full, snap.py_initials, nowIso(), id,
    );
    if (snap.secret_level !== cur.secret_level) {
      log(u, '变更密级', snap.archive_code, `${cur.secret_level} → ${snap.secret_level}（历史版本还原）`, clientIp(req),
        { step: '定密', category: 'security' });
    }
    log(u, '还原历史版本', snap.archive_code || cur.archive_code,
      `还原到 ${vrow.changed_at} 的版本（${vrow.changed_by}）`, clientIp(req));
    // 档号可能变了，二维码跟着重做
    try {
      const after = archiveForQr(id);
      if (after) ensureArchiveQr(after, { force: true });
    } catch (e) {
      console.warn('[档案二维码] 还原后更新失败（不影响还原）：' + e.message);
    }
    try { captureAndSaveMetadata(id, u, '历史版本还原后同步'); } catch (e) {
      console.warn('[元数据] 同步失败（不影响还原）：' + e.message);
    }
    ok(res, { restored: true, archive_code: snap.archive_code });
  });

  route('POST', '/api/archives/bulk-status', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    let ids = Array.isArray(b.ids) ? b.ids.map(Number).filter(Boolean) : [];
    const status = mustStr(b.status, 10);
    if (!ids.length) return fail(res, 400, '请选择要操作的档案');
    if (!STATUSES.includes(status)) return fail(res, 400, '状态值不合法');

    // 与批量修改同理：显式传 ids 也必须逐条过密级校验，
    // 否则猜到 id 就能改自己看不到的涉密档案的状态（改状态会直接影响在库/借出管理）。
    const scope = secretScope(u);
    const holes = ids.map(() => '?').join(',');
    const allow = new Set(
      q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${scope.sql}`, ...ids, ...scope.params)
        .map((r) => Number(r.id)),
    );
    const before = ids.length;
    ids = ids.filter((id) => allow.has(id));
    if (ids.length !== before) {
      log(u, '批量改状态跳过无权档案', `${before - ids.length} 条`, '超出账号密级上限', clientIp(req),
        { result: '拒绝', category: 'security', step: '密级鉴别' });
    }
    if (!ids.length) return fail(res, 403, '所选档案均超出你的密级权限范围');

    let n = 0;
    q.tx(() => {
      for (const id of ids) {
        const r = q.run('UPDATE archives SET status=?, status_note=?, updated_at=? WHERE id=?',
          status, mustStr(b.status_note, 200), nowIso(), id);
        n += r.changes;
      }
    });
    log(u, '批量改状态', status, `${n} 条`, clientIp(req));
    ok(res, { changes: n });
  });

  /** 回收站保留天数（v4.22.0）。设置项 trash.keep_days，默认 30 天 */
  function trashKeepDays() {
    const n = Number(settingOf('trash.keep_days', 30));
    return Number.isFinite(n) && n >= 1 ? Math.min(3650, Math.floor(n)) : 30;
  }

  /**
   * 删除档案 → **移入回收站**（v4.22.0）。
   *
   * 改造前后的差别只有两点，但都很要紧：
   *   ① **物理附件不再删**：今天这里会 removeStored 把文件从磁盘抹掉，
   *      照旧的话回收站里全是一堆"有记录、没文件"的空壳，比没有回收站更误导人。
   *      所以文件要活到"彻底清除"那一刻。
   *   ② **删除原因必填**：回收站的意义就是留痕，没有原因就没有留痕。
   *
   * 做法上不是"打个删除标记"（那要改遍全项目的档案读取路径），而是把整行快照
   * 搬进 archive_trash 再从 archives 删掉 —— 现有查询一行都不用改。
   */
  route('DELETE', '/api/archives/:id', async (req, res, params, url) => {
    // 用动作级授权而不是角色档位：审计员档位不低，但绝不能删档（v4.17.0 的"只审计"口径）
    const u = requireCan(req, res, 'archive:delete');
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM archives WHERE id=?', id);
    if (!cur) return fail(res, 404, '档案不存在');
    const activeLoan = q.scalar(`SELECT COUNT(*) FROM loans WHERE archive_id=? AND status IN ('已批准','逾期')`, id);
    if (activeLoan) return fail(res, 400, '该档案有未归还的借阅记录，不能删除');

    let body = {};
    try { body = (await readJson(req)) || {}; } catch (_) { body = {}; }
    // 删除原因（v4.22.0）：留痕的核心，界面已做成**必填**。
    //
    // 服务端这一轮刻意**不做硬拒**，而是记成「（未填写）」并在返回值里给出 warning。
    // 原因：回归套件里有 17 个文件、28 处夹具清理调用都不带原因，
    // 服务端一转 400，这些套件会集体变红 —— 一片红会掩盖真正的问题。
    // v4.22.1 已把这 27 个文件、87 处调用补上原因（改写脚本先备份再改，回归验证通过），
    // 所以这里正式转成 400 硬拒。
    const reasonRaw = String((body && body.reason) || (url && url.searchParams.get('reason')) || '').trim();
    // 删除原因**硬拒**（v4.22.1）：留痕的核心，没原因就不许删。
    // 界面早就做成必填；服务端这一层也补上了，接口调用同样绕不过去。
    if (!reasonRaw) {
      return fail(res, 400, '请填写删除原因。档案删除必须留痕 —— 原因会一并记入回收站与审计日志，事后可查是谁、为什么删的。');
    }
    const reasonMissing = false;
    const reason = reasonRaw;

    const files = q.all('SELECT * FROM files WHERE archive_id=? ORDER BY sort_no, id', id);
    // 关联行尽力快照：不同版本的表结构略有差异，取不到就记空，绝不因此让删除失败
    const relations = {};
    for (const [key, sql] of [
      ['loans', 'SELECT * FROM loans WHERE archive_id=?'],
      ['appraisals', 'SELECT * FROM appraisals WHERE archive_id=?'],
      ['links', 'SELECT * FROM archive_links WHERE archive_id=?'],
    ]) {
      try { relations[key] = q.all(sql, id); } catch (_) { relations[key] = []; }
    }
    const keepDays = trashKeepDays();
    const qrName = archiveQrLib.plannedBaseName(db, cur);   // 删之前先按全库计划算出文件名
    const now = nowIso();
    const expires = new Date(Date.now() + keepDays * 86400000).toISOString();
    let trashId = 0;
    q.tx(() => {
      // 顺序不能反：**先把快照写进回收站，再删原行**
      const r = q.run(
        `INSERT INTO archive_trash(original_id,archive_code,archive_number,title,type_code,year,secret_level,
           file_count,snapshot,files_snapshot,relation_snapshot,reason,deleted_by,deleted_by_name,deleted_at,expires_at)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        id, cur.archive_code, cur.archive_number, cur.title, cur.type_code, cur.year, cur.secret_level,
        files.length, JSON.stringify(cur), JSON.stringify(files), JSON.stringify(relations),
        reason, u.id, u.display_name || u.username, now, expires);
      trashId = Number(r.lastInsertRowid);
      q.run('DELETE FROM files WHERE archive_id=?', id);
      q.run('DELETE FROM loans WHERE archive_id=?', id);
      q.run('DELETE FROM archives WHERE id=?', id);
    });
    // 二维码图片仍然清掉（它可由档号随时重建，留在目录里只会变成孤儿文件）
    try { archiveQrLib.removeOne(cur, qrDir(), qrName); } catch (_) { /* 删不掉不影响主流程 */ }
    log(u, '删除档案（移入回收站）', cur.archive_code,
      `${cur.title}｜原因：${reason}`, clientIp(req));
    ok(res, {
      trashed: true, trashId, filesKept: files.length,
      keepDays, expiresAt: expires,
      reasonMissing,
      warning: reasonMissing
        ? '本次删除没有填写原因，已记为「（未填写）」。界面里原因必填；直接用接口调用时请带上 reason。'
        : undefined,
      note: `已移入回收站，${keepDays} 天内可随时恢复；物理附件在彻底清除之前不会被删除。`,
    });
  });

  /** 回收站列表（v4.22.0）。只回列表字段，不回整行快照 —— 快照可能很大 */
  route('GET', '/api/trash', async (req, res) => {
    const u = requireCan(req, res, 'archive:delete');
    if (!u) return;
    const keepDays = trashKeepDays();
    const list = q.all(
      `SELECT id,original_id,archive_code,archive_number,title,type_code,year,secret_level,file_count,
              reason,deleted_by_name,deleted_at,expires_at
         FROM archive_trash ORDER BY id DESC LIMIT 200`);
    const today = Date.now();
    for (const it of list) {
      const left = it.expires_at ? Math.ceil((new Date(it.expires_at).getTime() - today) / 86400000) : null;
      it.days_left = left;
      it.expired = left !== null && left <= 0;
    }
    ok(res, { list, keepDays, total: q.scalar('SELECT COUNT(*) FROM archive_trash') });
  });

  /** 从回收站恢复（v4.22.0）：档号原样还原，绝不改号 —— 档号不复用是治理底线 */
  route('POST', '/api/trash/:id/restore', async (req, res, params) => {
    const u = requireCan(req, res, 'archive:delete');
    if (!u) return;
    const t = q.get('SELECT * FROM archive_trash WHERE id=?', Number(params.id));
    if (!t) return fail(res, 404, '回收站里没有这条记录（可能已被恢复或清除）');
    const snap = JSON.parse(t.snapshot);
    const files = JSON.parse(t.files_snapshot || '[]');
    const relations = JSON.parse(t.relation_snapshot || '{}');

    // id 复用问题：SQLite 会把最大 rowid 让给新行，所以原 id 可能已经被别的档案占住。
    // 占住了就换一个新 id，并把附件的 archive_id 一并改写 ——
    // 绝不能插成"附件指向别人"的串档状态。
    const taken = q.get('SELECT id FROM archives WHERE id=?', t.original_id);
    const reuseId = !taken;
    let realId = 0;
    let restoredFiles = 0;
    q.tx(() => {
      const cols = Object.keys(snap).filter((c) => c !== 'id');
      const r = q.run(
        `INSERT INTO archives(id,${cols.join(',')}) VALUES(?${cols.map(() => ',?').join('')})`,
        reuseId ? snap.id : null, ...cols.map((c) => snap[c]));
      realId = reuseId ? snap.id : Number(r.lastInsertRowid);
      for (const f of files) {
        const fcols = Object.keys(f).filter((c) => c !== 'id' && c !== 'archive_id');
        q.run(`INSERT INTO files(archive_id,${fcols.join(',')}) VALUES(?${fcols.map(() => ',?').join('')})`,
          realId, ...fcols.map((c) => f[c]));
        restoredFiles++;
      }
      // 关联行尽力恢复（结构与版本相关，失败不影响档案本身恢复）
      for (const [key, rows] of Object.entries(relations)) {
        if (!Array.isArray(rows) || !rows.length) continue;
        const table = key === 'links' ? 'archive_links' : key;
        for (const row of rows) {
          try {
            const rc = Object.keys(row).filter((c) => c !== 'id');
            const vals = rc.map((c) => (c === 'archive_id' ? realId : row[c]));
            q.run(`INSERT INTO ${table}(${rc.join(',')}) VALUES(${rc.map(() => '?').join(',')})`, ...vals);
          } catch (_) { /* 关联行恢复尽力而为 */ }
        }
      }
      q.run('DELETE FROM archive_trash WHERE id=?', t.id);
    });

    // 物理文件本来就还在（删除时特意没删）——这里核对一遍，如实报告有没有对不上的
    let missing = 0;
    for (const f of files) {
      if (!f.rel_path) continue;
      try { if (!fs.existsSync(path.join(filesRoot, f.rel_path))) missing++; } catch (_) { missing++; }
    }
    log(u, '从回收站恢复档案', t.archive_code,
      `${t.title}｜原删除原因：${t.reason || ''}${reuseId ? '' : '｜id 已被占用，已改用新 id'}`, clientIp(req));
    ok(res, {
      id: realId, archive_code: t.archive_code, files: restoredFiles,
      idChanged: !reuseId, missingFiles: missing,
      note: missing
        ? `已恢复，但有 ${missing} 个附件的物理文件没找到（可能是磁盘上被手工删过），请核对。`
        : '已恢复，档号与删除前一致，附件文件齐全。',
    });
  });

  /** 彻底清除（v4.22.0）：不可恢复，物理文件此时才删 */
  route('DELETE', '/api/trash/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'archive:delete');
    if (!u) return;
    const t = q.get('SELECT * FROM archive_trash WHERE id=?', Number(params.id));
    if (!t) return fail(res, 404, '回收站里没有这条记录');
    const files = JSON.parse(t.files_snapshot || '[]');
    let removed = 0, kept = 0;
    for (const f of files) {
      if (!f.rel_path) continue;
      // 附件按哈希去重：同一份物理文件若仍被别的档案引用，就不能删
      const still = q.scalar('SELECT COUNT(*) FROM files WHERE rel_path=?', f.rel_path);
      if (still) { kept++; continue; }
      try { removeStored(filesRoot, f.rel_path); removed++; } catch (_) { /* 删不掉就留着，不阻断 */ }
    }
    q.run('DELETE FROM archive_trash WHERE id=?', t.id);
    // 彻底清除之后**审计日志里仍留着档号、题名、删除人与原因** —— 这就是"删除留痕"的落点
    log(u, '彻底清除档案（不可恢复）', t.archive_code,
      `${t.title}｜原删除原因：${t.reason || ''}｜删除人：${t.deleted_by_name || ''}`, clientIp(req));
    ok(res, { removedFiles: removed, keptFiles: kept, archive_code: t.archive_code });
  });

  // ===== 附件 =====
  /**
   * 读取扫描参数（数字化元数据，《数字档案室建设指南》§5.6.2）。
   *
   * 扫描仪输出的 PDF 自带不了"多少 dpi、彩色还是灰度、用哪台机器扫的"，
   * 这些必须由上传界面随文件一起报上来；缺省时按系统设置补默认值，
   * 并自动打上扫描时间 —— 否则事后没人说得清这份数字副本是怎么来的。
   */
  function readScanMeta(fields, kind) {
    const f = fields || {};
    const isScan = kind === '扫描件';
    return {
      dpi: Math.max(0, Number(f.dpi) || (isScan ? Number(numbering.getSetting(q, 'scan.default_dpi', '300')) || 0 : 0)),
      color_mode: mustStr(f.color_mode, 20)
        || (isScan ? String(numbering.getSetting(q, 'scan.default_color', '彩色') || '') : ''),
      device: mustStr(f.device, 120) || '',
      scanned_at: mustStr(f.scanned_at, 40) || (isScan ? nowIso() : ''),
    };
  }

  /**
   * 实体页数 vs 扫描件页数。
   *
   * 数字化最常见的质量问题就是漏扫（双面只扫了正面）、重扫、把附件当正文扫。
   * 这里只**如实对比并给提示**，绝不阻断 —— 页数对不上时人还要能继续干活，
   * 但必须让人当场看见"差了几页"。
   */
  function scanPagesCheck(archiveId) {
    const a = q.get('SELECT pages FROM archives WHERE id=?', archiveId) || {};
    const declared = Number(String(a.pages || '').replace(/[^0-9]/g, '')) || 0;
    const scanned = Number(q.scalar("SELECT COALESCE(SUM(pages),0) FROM files WHERE archive_id=? AND kind='扫描件'", archiveId) || 0);
    const files = Number(q.scalar("SELECT COUNT(*) FROM files WHERE archive_id=? AND kind='扫描件'", archiveId) || 0);
    const unknown = Number(q.scalar("SELECT COUNT(*) FROM files WHERE archive_id=? AND kind='扫描件' AND pages=0", archiveId) || 0);
    let level = 'ok';
    let note = '';
    if (!declared) {
      level = 'none';
      note = '著录里还没填实体页数，无法核对扫描件是否完整';
    } else if (unknown) {
      level = 'warn';
      note = `有 ${unknown} 个扫描件读不出页数（可能是加密或结构异常的 PDF），请手工核对`;
    } else if (scanned === declared) {
      note = `实体 ${declared} 页，扫描件共 ${scanned} 页，一致`;
    } else {
      level = 'warn';
      note = `实体 ${declared} 页，扫描件共 ${scanned} 页，相差 ${Math.abs(declared - scanned)} 页`
        + (scanned < declared ? '（可能漏扫）' : '（可能重扫或双面扫）');
    }
    return { declared, scanned, files, unknown, level, note };
  }

  /** 一件档案的文件该落在哪个目录：过程区按项目/批次，归档区按档号（v4.29.0） */
  function storageCtxOf(a) {
    const project = a.project_id ? q.get('SELECT * FROM projects WHERE id=?', a.project_id) : null;
    const batch = a.batch_id ? q.get('SELECT * FROM intake_batches WHERE id=?', a.batch_id) : null;
    return {
      dir: storage.relDirFor({ archive: a, project, batch }),
      base: storage.fileBaseName(a),
    };
  }

  /**
   * 附件类型白名单（千问版 v4.30.8）。
   *
   * 原来上传不校验扩展名，.html/.svg/.exe 都能挂到档案上；预览又按客户端报的
   * MIME 内联输出 —— 一份伪装成档案的 .html 被管理员点开，脚本就以管理员身份
   * 在同源执行（存储型 XSS，可调用销毁审批等全部接口）。
   * 这里只收**文档类**扩展名，与「用本机程序打开」的 OPEN_LOCAL_EXT 同一口径；
   * 可执行/脚本类型一律拒收。上传与替换正文共用这一套规则。
   */
  const UPLOAD_EXT_OK = new Set([
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'rtf', 'odt', 'ods', 'odp', 'wps', 'et', 'dps',
    'txt', 'csv', 'md', 'log', 'json', 'xml',
    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tif', 'tiff',
    'dwg', 'dxf', 'zip', 'rar', '7z',
    'wav', 'mp3', 'mp4', 'avi', 'mov', 'ofd',
  ]);
  /** 输出时即使存量库里有，也绝不允许内联执行的类型（强制 attachment） */
  const DANGEROUS_INLINE_EXT = new Set([
    'html', 'htm', 'xhtml', 'svg', 'js', 'mjs', 'xml', 'xsl', 'xslt', 'hta', 'vbs', 'swf',
  ]);
  function uploadExtBlocked(filename) {
    const ext = String(filename || '').slice(String(filename || '').lastIndexOf('.') + 1).toLowerCase();
    return !UPLOAD_EXT_OK.has(ext);
  }

  route('POST', '/api/archives/:id/files', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    // archive_number 决定文件名；project/batch 决定落在过程区哪个目录；pages 用于扫描页数核对
    const a = q.get(`SELECT id,type_code,archive_code,archive_number,pages,year,project_id,batch_id,
                            archive_state,created_by,secret_level
                       FROM archives WHERE id=?`, id);
    if (!a) return fail(res, 404, '档案不存在');
    // 密级校验：看不到的档案，也不允许往上挂文件（否则等于变相确认其存在并可污染内容）
    if (!assertArchiveVisible(req, res, u, a)) return;
    if (!can(u, 'file:upload', { ownerId: a.created_by })) return fail(res, 403, '没有上传附件的权限');

    const form = await parseMultipart(req, {
      maxFileSize: MAX_UPLOAD_MB * 1024 * 1024,
      maxTotalSize: MAX_UPLOAD_MB * 4 * 1024 * 1024,
      maxFiles: 30,
    });
    if (!form.files.length) return fail(res, 400, '没有收到文件');
    // 千问版 v4.30.8：类型白名单 —— 整批里只要有一个危险类型就整批拒收，
    // 并点名是哪个文件，让上传者知道该转换格式而不是反复重试。
    const blocked = form.files.filter((f) => uploadExtBlocked(f.filename));
    if (blocked.length) {
      return fail(res, 400, `以下文件类型不允许上传：${blocked.map((f) => f.filename).join('、')}。`
        + '只接收文档类附件（Office/PDF/图片/文本/CAD/压缩包等）；网页、脚本、可执行程序请先转换为 PDF 或图片');
    }
    const kind = mustStr(form.fields.kind, 20) || '正文';
    const scan = readScanMeta(form.fields, kind);
    const saved = [];
    const textResults = [];
    const newIds = [];
    // 插入位置（可选，1 基）：把新附件插到第 position 件**之前**；不传则追加到末尾（与历史行为一致）。
    // 为什么要能插：后补到的材料在顺序上常常属于中间（例如原件第 3 页的扫描件后来才找到），
    // 只追加会让附件顺序与实体件顺序对不上 —— 打印卷内目录时最明显。
    const insertPos = Math.max(0, Number(form.fields.position) || 0);
    // 目录算一次：同一批文件都落在这件档案的目录里，不必每题都查项目/批次
    const uploadCtx = storageCtxOf(a);
    const zoneKind = uploadCtx.dir.startsWith('归档/') ? 'archive' : 'process';
    q.tx(() => {
      const before = q.all('SELECT id FROM files WHERE archive_id=? ORDER BY sort_no, id', id).map((r) => r.id);
      let sort = before.length;
      for (const f of form.files) {
        sort += 1;
        const s = saveArchiveFile(filesRoot, uploadCtx, f, { seq: sort });
        // PDF 页数：只对 PDF 解析；解析不出来就是 0，界面会提示"读不出页数"
        const pages = pdfInfo.isPdf(f.filename, f.mime) ? pdfInfo.pageCount(f.data) : 0;
        const r = q.run(`INSERT INTO files(archive_id,original_name,stored_name,rel_path,mime,size,sha256,kind,sort_no,
                           uploaded_by,created_at,pages,dpi,color_mode,device,scanned_at,storage_kind)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          id, s.original_name, s.stored_name, s.rel_path, s.mime || mimeOf(f.filename), s.size, s.sha256,
          kind, sort, u.id, nowIso(), pages, scan.dpi, scan.color_mode, scan.device, scan.scanned_at, zoneKind);
        newIds.push(r.lastInsertRowid);
        saved.push({
          id: r.lastInsertRowid, name: s.original_name, size: s.size, pages, rel_path: s.rel_path,
        });
        // 同时提取正文并进入全文索引
        const tr = indexFileText(r.lastInsertRowid, id, f.data, f.filename);
        textResults.push({
          name: s.original_name, ok: tr.ok, kind: tr.kind,
          chars: (tr.text || '').length, reason: tr.reason || '',
        });
      }
      // 指定了插入位置：整体重排 —— sort_no 只表达"相对顺序"，重排比在稀疏序号里找空隙更不容易出错
      if (insertPos >= 1 && newIds.length) {
        const at = Math.min(insertPos - 1, before.length);
        const ordered = before.slice(0, at).concat(newIds, before.slice(at));
        ordered.forEach((fid, i) => q.run('UPDATE files SET sort_no=? WHERE id=?', i + 1, fid));
      }
      q.run('UPDATE archives SET updated_at=? WHERE id=?', nowIso(), id);
    });
    log(u, kind === '扫描件' ? '导入扫描件' : '上传附件', a.archive_code,
      saved.map((s) => s.name + (s.pages ? `（${s.pages} 页）` : '')).join(', '), clientIp(req));

    // 归档环节四性检测：把"检测"嵌进日常流程，而不是指望有人记得点。
    // 超过附件总量上限时跳过并明确告知（仍可在「四性检测」页手工发起或按年度周期执行）。
    let detectionResult = null;
    if (String(numbering.getSetting(q, 'detection.auto_on_upload', '1')) === '1') {
      const totalBytes = Number(q.scalar('SELECT COALESCE(SUM(size),0) FROM files WHERE archive_id=?', id) || 0);
      if (totalBytes <= AUTO_DETECT_MAX_BYTES) {
        try {
          detectionResult = runAndSaveDetection(u, id, 'archive', '归档上传');
        } catch (e) {
          console.warn('[四性检测] 上传后自动检测失败：' + e.message);
        }
      } else {
        detectionResult = {
          skipped: true,
          reason: `附件总量 ${(totalBytes / 1048576).toFixed(1)} MB 超过自动检测上限，请到「四性检测」手工发起`,
        };
      }
    }
    // 附件变了，"形式特征""存储位置"等结构元数据要重新捕获
    try { captureAndSaveMetadata(id, u, '上传附件后同步'); } catch (e) {
      console.warn('[元数据] 同步失败（不影响上传）：' + e.message);
    }
    ok(res, {
      files: saved, textResults, detection: detectionResult,
      scanCheck: String(numbering.getSetting(q, 'scan.pages_check', '1')) === '1' ? scanPagesCheck(id) : null,
    });
  });

  /**
   * 写正文索引（原生提取与 OCR 共用的唯一落库口）。
   *
   * `via` 必须如实区分：
   *   native —— 文档自带的文字层（PDF 文字层、docx/xlsx、纯文本）
   *   ocr    —— 图像识别出来的（一定有错字）
   * 把两者混在一起，使用者就无法判断"这段正文该不该信"——
   * 而正文检索给出的片段会直接影响"要不要调这份档案"的判断。
   */
  function saveFileText(fileId, archiveId, r) {
    q.run(`INSERT INTO file_text(file_id,archive_id,content,char_count,status,kind,reason,via,engine,extracted_at)
           VALUES(?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(file_id) DO UPDATE SET content=excluded.content, char_count=excluded.char_count,
             status=excluded.status, kind=excluded.kind, reason=excluded.reason,
             via=excluded.via, engine=excluded.engine, extracted_at=excluded.extracted_at`,
      fileId, archiveId, r.content || '', (r.content || '').length, r.status || '成功',
      r.kind || '', r.reason || '', r.via || 'native', r.engine || '', nowIso());
  }

  function indexFileText(fileId, archiveId, buf, filename, opts = {}) {
    const r = textExtract.extractText(buf, filename);
    const status = r.ok ? '成功'
      : (/不支持|旧版二进制|无法直接提取/.test(r.reason || '') ? '跳过' : '失败');
    saveFileText(fileId, archiveId, {
      content: r.text, status, kind: r.kind, reason: r.reason,
      via: opts.via || 'native', engine: opts.engine || '',
    });
    return r;
  }

  // ============================================================
  // 附件正文检索
  // ============================================================
  /** 按附件正文检索，返回命中的档案与片段 */
  route('GET', '/api/search/text', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const kw = String(url.searchParams.get('kw') || '').trim();
    if (!kw) return fail(res, 400, '请输入检索关键词');
    const page = Math.max(1, Number(url.searchParams.get('page')) || 1);
    const size = Math.min(100, Math.max(1, Number(url.searchParams.get('size')) || 20));
    const type = url.searchParams.get('type') || '';
    const year = url.searchParams.get('year') || '';
    // 按正文来源筛：`native`（原生文字层，准确）/ `ocr`（识别出来的，可能有错字）
    const via = ['native', 'ocr'].includes(url.searchParams.get('via')) ? url.searchParams.get('via') : '';

    const like = '%' + kw.replace(/[%_]/g, (m) => '\\' + m) + '%';
    const conds = ['(t.content LIKE ? ESCAPE \'\\\' OR t.file_id IN (SELECT rowid FROM file_text_fts WHERE file_text_fts MATCH ?))'];
    const args = [like, '"' + kw.replace(/"/g, '""') + '"'];
    if (type) { conds.push('a.type_code = ?'); args.push(type); }
    if (year) { conds.push('a.year = ?'); args.push(year); }
    if (via === 'ocr') { conds.push("t.via='ocr'"); }
    if (via === 'native') { conds.push("(t.via IS NULL OR t.via<>'ocr')"); }
    // 正文检索是最容易被忽略的越权入口：能搜到正文片段，就等于看到了涉密内容本身。
    const scope = secretScope(u);
    if (scope.sql) { conds.push(scope.sql.replace(/^ AND /, '')); args.push(...scope.params); }
    const where = ' WHERE ' + conds.join(' AND ');

    const total = Number(q.scalar(
      `SELECT COUNT(*) FROM file_text t JOIN files f ON f.id=t.file_id
       JOIN archives a ON a.id=t.archive_id ${where}`, ...args) || 0);
    const rows = q.all(
      `SELECT t.file_id, t.archive_id, t.char_count, t.content, t.via, t.engine,
              f.original_name, f.size, f.mime,
              a.archive_code, a.archive_number, a.title, a.type_code, a.year, a.retention,
              c.name AS category_name
       FROM file_text t
       JOIN files f ON f.id=t.file_id
       JOIN archives a ON a.id=t.archive_id
       LEFT JOIN categories c ON c.id=a.category_id
       ${where}
       ORDER BY t.char_count DESC, a.id DESC
       LIMIT ? OFFSET ?`, ...args, size, (page - 1) * size);
    const list = rows.map((r) => ({
      file_id: r.file_id,
      archive_id: r.archive_id,
      archive_code: r.archive_code,
      archive_number: r.archive_number,
      title: r.title,
      type_code: r.type_code,
      year: r.year,
      retention: r.retention,
      category_name: r.category_name,
      original_name: r.original_name,
      size: r.size,
      mime: r.mime,
      char_count: r.char_count,
      // 正文的来源必须如实带出来：OCR 文本一定有错字，
      // 界面要能提示"这段是识别出来的"，使用者才知道该不该照它判断
      via: r.via || 'native',
      engine: r.engine || '',
      snippet: makeSnippet(r.content, kw),
    }));
    ok(res, { list, total, page, size, pages: Math.max(1, Math.ceil(total / size)), kw, via });
  });

  /** 正文索引状态统计 */
  route('GET', '/api/search/text/stats', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const rows = q.all(`SELECT status, COUNT(*) AS count, SUM(char_count) AS chars FROM file_text GROUP BY status`);
    const byKind = q.all(`SELECT kind, COUNT(*) AS count FROM file_text WHERE status='成功' GROUP BY kind ORDER BY count DESC LIMIT 10`);
    const total = Number(q.scalar('SELECT COUNT(*) FROM files') || 0);
    const indexed = Number(q.scalar("SELECT COUNT(*) FROM file_text WHERE status='成功'") || 0);
    const skipped = Number(q.scalar("SELECT COUNT(*) FROM file_text WHERE status<>'成功'") || 0);
    ok(res, {
      total, indexed, skipped, notProcessed: Math.max(0, total - indexed - skipped),
      byStatus: rows, byKind,
    });
  });

  /** 为已有附件补做正文提取（管理员） */
  route('POST', '/api/search/text/reindex', async (req, res) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req);
    const limit = Math.min(500, Math.max(1, Number(b.limit) || 100));
    const rows = q.all(
      `SELECT f.id, f.archive_id, f.original_name, f.rel_path FROM files f
       WHERE f.id NOT IN (SELECT file_id FROM file_text)
       ORDER BY f.id LIMIT ?`, limit);
    let okCount = 0, skipCount = 0, failCount = 0, chars = 0;
    for (const f of rows) {
      let abs;
      try { abs = absPath(filesRoot, f.rel_path); } catch (_) { failCount++; continue; }
      if (!fs.existsSync(abs)) { failCount++; continue; }
      let buf;
      try { buf = fs.readFileSync(abs); } catch (_) { failCount++; continue; }
      const r = indexFileText(f.id, f.archive_id, buf, f.original_name);
      if (r.ok) { okCount++; chars += (r.text || '').length; }
      else if (/不支持|旧版二进制|无法直接提取/.test(r.reason || '')) skipCount++;
      else failCount++;
    }
    const remaining = Number(q.scalar('SELECT COUNT(*) FROM files WHERE id NOT IN (SELECT file_id FROM file_text)') || 0);
    log(u, '补建附件正文索引', String(rows.length), `成功 ${okCount} / 跳过 ${skipCount} / 失败 ${failCount}`, clientIp(req));
    ok(res, { processed: rows.length, ok: okCount, skipped: skipCount, failed: failCount, chars, remaining });
  });

  // ============================================================
  // OCR：把扫描件变成可检索正文（v4.11.0）
  //
  // 立场（与 lib/ocr.js 一致，这里再写一遍因为这是对外行为的边界）：
  //   1. 不打包、不下载任何 OCR 引擎。本机装了就调用，没装就如实说明并给安装指引。
  //   2. OCR 结果写进正文索引时标 `via='ocr'`，检索界面会提示"可能有错字"。
  //   3. **不覆盖已有的原生文字层**：一份 PDF 本来就有文字层时，OCR 只会更差。
  // ============================================================

  function ocrSettings() {
    return {
      mode: numbering.getSetting(q, 'ocr.mode', 'auto'),
      engine: numbering.getSetting(q, 'ocr.engine', 'auto'),
      enginePath: numbering.getSetting(q, 'ocr.engine_path', ''),
      rasterPath: numbering.getSetting(q, 'ocr.raster_path', ''),
      lang: numbering.getSetting(q, 'ocr.lang', 'chi_sim+eng'),
      timeout: Number(numbering.getSetting(q, 'ocr.timeout_ms', '120000')) || 120000,
      dpi: Number(numbering.getSetting(q, 'ocr.dpi', '200')) || 200,
      maxPages: Number(numbering.getSetting(q, 'ocr.max_pages', '50')) || 50,
      maxMb: Number(numbering.getSetting(q, 'ocr.max_mb', '50')) || 50,
      envOverride: !!process.env.DSH_ARCHIVE_OCR,
    };
  }

  /** 探测（带设置门）。mode=none 时直接回"已关闭"，不去调用任何外部程序。 */
  function ocrDetect(force) {
    const s = ocrSettings();
    if (s.mode === 'none') {
      return {
        available: false, engine: 'none', canPdf: false, notes: [],
        reason: 'OCR 已在设置中关闭（ocr.mode = none）。改为 auto 即可在探测到引擎时启用。',
        checkedAt: nowIso(),
      };
    }
    return ocrLib.detect({
      enginePath: s.enginePath, rasterPath: s.rasterPath, engine: s.engine, force,
    });
  }

  /** OCR 能处理的扩展名条件（图片 + PDF） */
  function ocrExtWhere() {
    const exts = [...ocrLib.IMAGE_EXT, '.pdf'];
    return {
      sql: '(' + exts.map(() => 'lower(f.original_name) LIKE ?').join(' OR ') + ')',
      args: exts.map((e) => '%' + e),
    };
  }

  /**
   * 对单个附件执行 OCR 并落库。
   * 所有入口（单件 / 批量 / 将来可能的定时任务）都走这里 —— 落库口径只写一遍。
   */
  function runOcrOnFile(f, s, det) {
    let abs;
    try { abs = absPath(filesRoot, f.rel_path); } catch (_) { return { file_id: f.id, ok: false, reason: '附件路径不合法' }; }
    if (!fs.existsSync(abs)) return { file_id: f.id, ok: false, reason: '附件文件不在磁盘上' };

    const sizeMb = Number(f.size || 0) / 1048576;
    if (sizeMb > s.maxMb) {
      return {
        file_id: f.id, ok: false,
        reason: `附件 ${sizeMb.toFixed(1)} MB 超过 OCR 上限 ${s.maxMb} MB（可在「系统管理 → 设置」调整 ocr.max_mb）`,
      };
    }

    const cur = q.get('SELECT * FROM file_text WHERE file_id=?', f.id);
    // 有原生文字层且已成功 → 不动它。OCR 的识别质量一定不如原生文字层，
    // 用 OCR 覆盖原生文本是"越做越差"，而且会让原本准确的正文检索开始出错。
    if (cur && cur.status === '成功' && cur.via !== 'ocr') {
      return { file_id: f.id, ok: false, skipped: true, reason: '已有原生文字层，不需要 OCR（也不会被 OCR 覆盖）' };
    }

    const r = ocrLib.ocrFile(abs, f.original_name, {
      det, lang: s.lang, timeout: s.timeout, dpi: s.dpi, maxPages: s.maxPages, textExtract,
    });
    if (!r.ok) {
      saveFileText(f.id, f.archive_id, {
        content: (cur && cur.content) || '', status: '失败',
        kind: 'OCR 识别', reason: r.reason, via: 'ocr', engine: '',
      });
      return { file_id: f.id, ok: false, reason: r.reason };
    }
    saveFileText(f.id, f.archive_id, {
      content: r.text, status: '成功', kind: 'OCR 识别文本',
      reason: r.truncated ? `内容较长，仅识别了前 ${r.pages} 页` : '',
      via: 'ocr', engine: r.engine,
    });
    return {
      file_id: f.id, ok: true, chars: (r.text || '').length, engine: r.engine,
      pages: r.pages || 0, truncated: !!r.truncated, ms: r.ms || 0,
    };
  }

  /** OCR 状态：引擎探测结果 + 待处理/已完成计数（计数按密级过滤） */
  route('GET', '/api/ocr/status', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const force = url.searchParams.get('force') === '1';
    const det = ocrDetect(force);
    const s = ocrSettings();
    const sc = secretScope(u);
    const ew = ocrExtWhere();

    const candidates = Number(q.scalar(
      `SELECT COUNT(*) FROM files f JOIN archives a ON a.id=f.archive_id
        LEFT JOIN file_text t ON t.file_id=f.id
        WHERE (t.file_id IS NULL OR t.status<>'成功') AND a.status<>'已销毁' AND ${ew.sql}${sc.sql}`,
      ...ew.args, ...sc.params,
    ) || 0);
    const cnt = (viaCond, statusCond) => Number(q.scalar(
      `SELECT COUNT(*) FROM file_text t JOIN archives a ON a.id=t.archive_id
        WHERE ${viaCond} AND ${statusCond}${sc.sql}`, ...sc.params,
    ) || 0);
    const ocrDone = cnt("t.via='ocr'", "t.status='成功'");
    const ocrFailed = cnt("t.via='ocr'", "t.status<>'成功'");
    const nativeDone = cnt("t.via<>'ocr'", "t.status='成功'");
    const ocrChars = Number(q.scalar(
      `SELECT COALESCE(SUM(t.char_count),0) FROM file_text t JOIN archives a ON a.id=t.archive_id
        WHERE t.via='ocr' AND t.status='成功'${sc.sql}`, ...sc.params,
    ) || 0);

    ok(res, {
      detect: det,
      settings: s,
      counts: { candidates, ocrDone, ocrFailed, nativeDone, ocrChars },
      imageExt: ocrLib.IMAGE_EXT,
    });
  });

  /** 强制重新探测引擎（装了 tesseract 之后不用重启系统） */
  route('POST', '/api/ocr/detect', async (req, res) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    ocrLib.reset();
    const det = ocrDetect(true);
    const ver = (det.tesseract && det.tesseract.version) || (det.ocrmypdf && det.ocrmypdf.version) || '';
    log(u, '重新探测 OCR 引擎', det.engine || 'none',
      det.available ? `${det.engine} ${ver}` : (det.reason || ''), clientIp(req));
    ok(res, det);
  });

  /** 识别单个附件 */
  route('POST', '/api/files/:id/ocr', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有重新识别正文的权限');
    const fileId = Number(params.id);
    const f = q.get(`SELECT f.*, a.secret_level, a.created_by, a.archive_code FROM files f
                     JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, fileId);
    if (!f) return fail(res, 404, '文件不存在');
    if (!assertArchiveVisible(req, res, u, f)) return;

    const det = ocrDetect(false);
    if (!det.available) return fail(res, 400, det.reason || '本机没有可用的 OCR 引擎');
    const s = ocrSettings();
    const r = runOcrOnFile(f, s, det);
    if (!r.ok) {
      if (r.skipped) return ok(res, r);
      log(u, 'OCR 识别失败', f.archive_code || '', `${f.original_name}：${r.reason}`, clientIp(req), { result: '失败' });
      return fail(res, 400, r.reason);
    }
    log(u, 'OCR 识别正文', f.archive_code || '',
      `${f.original_name}：${r.chars} 字（${r.engine}${r.pages ? '，' + r.pages + ' 页' : ''}）`,
      clientIp(req), { step: '正文索引' });
    ok(res, r);
  });

  /**
   * 批量识别。**同步、限量、按密级**：
   *   - 限量（默认 10、上限 50）是因为 OCR 很慢（一页一秒起），
   *     不设上限的批量接口会让浏览器等到超时、还会让服务器看起来像挂了；
   *   - 按密级是因为识别结果会进正文索引 —— 让低密级账号借 OCR 把涉密扫描件的内容读出来，
   *     等于给正文检索开了个后门。
   */
  route('POST', '/api/ocr/batch', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const limit = Math.min(50, Math.max(1, Number(b.limit) || 10));
    const det = ocrDetect(false);
    if (!det.available) return fail(res, 400, det.reason || '本机没有可用的 OCR 引擎');
    const s = ocrSettings();
    const sc = secretScope(u);
    const ew = ocrExtWhere();

    let rows;
    if (Array.isArray(b.file_ids) && b.file_ids.length) {
      const ids = b.file_ids.map(Number).filter(Boolean).slice(0, limit);
      const holes = ids.map(() => '?').join(',');
      rows = q.all(`SELECT f.id, f.archive_id, f.original_name, f.rel_path, f.size, a.archive_code, a.secret_level
                    FROM files f JOIN archives a ON a.id=f.archive_id
                    WHERE f.id IN (${holes})${sc.sql}`, ...ids, ...sc.params);
    } else {
      rows = q.all(`SELECT f.id, f.archive_id, f.original_name, f.rel_path, f.size, a.archive_code, a.secret_level
                    FROM files f JOIN archives a ON a.id=f.archive_id
                    LEFT JOIN file_text t ON t.file_id=f.id
                    WHERE (t.file_id IS NULL OR t.status<>'成功')
                      AND a.status<>'已销毁' AND ${ew.sql}${sc.sql}
                    ORDER BY f.id LIMIT ?`, ...ew.args, ...sc.params, limit);
    }
    if (!rows.length) {
      return ok(res, {
        processed: 0, ok: 0, failed: 0, skipped: 0, results: [], engine: det.engine,
        note: '没有待识别的附件（图片/PDF 且正文尚未提取）。若刚上传过附件，说明它们已提取到原生文字层。',
      });
    }

    const results = [];
    let okCount = 0; let failCount = 0; let skipCount = 0; let chars = 0;
    const t0 = Date.now();
    for (const f of rows) {
      const r = runOcrOnFile(f, s, det);
      results.push(Object.assign({ original_name: f.original_name, archive_code: f.archive_code }, r));
      if (r.ok) { okCount++; chars += r.chars || 0; }
      else if (r.skipped) skipCount++;
      else failCount++;
    }
    const remaining = Number(q.scalar(
      `SELECT COUNT(*) FROM files f JOIN archives a ON a.id=f.archive_id
        LEFT JOIN file_text t ON t.file_id=f.id
        WHERE (t.file_id IS NULL OR t.status<>'成功') AND a.status<>'已销毁' AND ${ew.sql}${sc.sql}`,
      ...ew.args, ...sc.params,
    ) || 0);
    log(u, '批量 OCR 识别', `${rows.length} 个附件`,
      `成功 ${okCount} / 失败 ${failCount} / 跳过 ${skipCount}，共 ${chars} 字，`
      + `用时 ${((Date.now() - t0) / 1000).toFixed(1)}s`, clientIp(req), { step: '正文索引' });
    ok(res, {
      processed: rows.length, ok: okCount, failed: failCount, skipped: skipCount, chars,
      results, engine: det.engine, remaining, ms: Date.now() - t0,
    });
  });

  /** 单个附件的正文提取结果 */
  route('GET', '/api/files/:id/text', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const fileId = Number(params.id);
    const t = q.get(`SELECT t.*, f.original_name FROM file_text t JOIN files f ON f.id=t.file_id WHERE t.file_id=?`, fileId);
    if (!t) return ok(res, { status: '未处理', content: '', reason: '尚未提取正文（可在“检索 → 正文索引”中补建）', via: '', engine: '' });
    const preview = url.searchParams.get('preview') === '1';
    ok(res, {
      status: t.status, kind: t.kind, reason: t.reason, char_count: t.char_count,
      original_name: t.original_name, extracted_at: t.extracted_at,
      // 来源必须带出来：界面要能提示"这段是 OCR 识别的、可能有错字"
      via: t.via || 'native', engine: t.engine || '',
      content: preview ? String(t.content || '').slice(0, 2000) : String(t.content || ''),
    });
  });

  // HEAD 与 GET 共用同一处理器：serveFile 内部会正确处理 HEAD（只回响应头）
  /**
   * 「先看再传」：对**还没上传**的本地文件做一次正文提取，**什么都不保存**（v4.26.4）。
   *
   * 为什么需要它：著录页的本地预览只能当场看出图片、PDF、文本三类的样子，
   * 而 Excel / Word 浏览器根本渲染不了 —— 使用者选了一个 .xlsx 点预览，
   * 只得到一句"这种格式看不了"（使用者正是这么反馈的）。而 Excel 恰恰是档案室最常传的格式之一。
   *
   * 这里复用服务端**已有的**提取器（Office、旧版 .doc/.xls、按字节嗅探真实格式都支持），
   * 但**只提取、不落盘**：不写 files、不写 file_text、不建任何记录、不碰号码。
   * 所以"预览不会在服务器上留下任何东西"这句承诺仍然成立。
   */
  route('POST', '/api/preview-extract', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!policy.can(u, 'file:upload')) return fail(res, 403, '没有上传附件的权限', 'FORBIDDEN');
    const form = await parseMultipart(req, {
      maxFileSize: MAX_UPLOAD_MB * 1024 * 1024, maxTotalSize: MAX_UPLOAD_MB * 1024 * 1024, maxFiles: 1,
    });
    const file = form.files[0];
    if (!file) return fail(res, 400, '没有收到文件');
    let r;
    try {
      r = textExtract.extractText(file.data, file.filename);
    } catch (e) {
      return fail(res, 400, '提取失败：' + (e && e.message ? e.message : e));
    }
    return ok(res, {
      ok: !!r.ok,
      kind: r.kind || '',
      reason: r.reason || '',
      chars: (r.text || '').length,
      text: (r.text || '').slice(0, 200000),
      note: r.ok ? '' : (r.reason || '这份文件的正文没能提取出来'),
    });
  });

  /**
   * 「用本机默认程序打开」（v4.26.5）—— 也就是使用者要的"按照相应的格式打开"。
   *
   * 为什么需要它：网页里**做不到**用 Excel 打开本地文件（浏览器拿不到真实路径、
   * 也不许启动本机程序，任何网站都一样）。但这套系统就跑在档案室那台电脑上，
   * 所以可以让**服务端**用系统默认程序打开这份附件 —— Excel 开 .xlsx、Word 开 .docx、
   * 图片走看图程序，这才是"按格式打开"。
   *
   * 三处安全约束（这是个能执行文件的能力，必须收紧）：
   *   ① **只允许本机访问**（来源 IP 必须是回环地址）——
   *      否则局域网里任何人点一下，就会在服务器那台电脑上弹出程序；
   *   ② **扩展名白名单**：只允许 Office / PDF / 图片 / 文本 / CAD 这类**文档**，
   *      明确拒绝 .exe/.bat/.cmd/.ps1/.js 等可执行类型 ——
   *      否则等于给了"上传一个文件就能在这台电脑上执行"的口子；
   *   ③ **留痕**：写审计日志，事后能查"谁在什么时候用什么程序打开了哪份附件"。
   */
  const OPEN_LOCAL_EXT = new Set([
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'rtf', 'odt', 'ods', 'odp',
    'txt', 'csv', 'md', 'log', 'json', 'xml',
    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tif', 'tiff',
    'dwg', 'dxf', 'zip', 'rar', '7z',
  ]);
  const OPEN_LOCAL_DENY = new Set(['exe', 'bat', 'cmd', 'com', 'scr', 'ps1', 'vbs', 'js', 'jse',
    'wsf', 'wsh', 'msi', 'msp', 'cpl', 'hta', 'reg', 'jar', 'lnk', 'pif', 'dll', 'sys']);

  route('POST', '/api/files/:id/open-local', async (req, res, params) => {
    const u = requireCan(req, res, 'file:download');
    if (!u) return;
    const ip = String(clientIp(req) || '');
    const isLocal = ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
    if (!isLocal) {
      return fail(res, 403, '只能在运行本系统的那台电脑上这样做（当前你是从 ' + (ip || '其它设备') + ' 访问的）。'
        + '其它设备请用「下载」把文件取过去打开。', 'FORBIDDEN');
    }
    const f = q.get('SELECT f.*, a.archive_code FROM files f JOIN archives a ON a.id=f.archive_id WHERE f.id=?',
      Number(params.id));
    if (!f) return fail(res, 404, '文件不存在');
    const ext = String(f.original_name || '').split('.').pop().toLowerCase();
    if (OPEN_LOCAL_DENY.has(ext) || !OPEN_LOCAL_EXT.has(ext)) {
      // 明确拒绝（而不是"默认允许"）：这个能力一旦放开，就等于
      // "往库里传一个文件就能在那台电脑上执行它"。宁可少支持几种格式。
      return fail(res, 400, `出于安全考虑，不在这台电脑上直接打开 .${ext || '未知'} 类型的文件。`
        + '可以先下载，确认来源可靠后再自行打开。');
    }
    const abs = absPath(filesRoot, f.rel_path);
    if (!fs.existsSync(abs)) return fail(res, 404, '文件不在磁盘上（可能已被移动或清理）');
    try {
      if (process.platform === 'win32') {
        execFile('cmd', ['/c', 'start', '""', abs], { windowsHide: true }, () => {});
      } else if (process.platform === 'darwin') {
        execFile('open', [abs], () => {});
      } else {
        execFile('xdg-open', [abs], () => {});
      }
    } catch (e) {
      return fail(res, 500, '启动本机程序失败：' + (e && e.message ? e.message : e));
    }
    log(u, '用本机程序打开附件', f.archive_code, `${f.original_name}`, clientIp(req));
    return ok(res, {
      opened: true,
      note: '已交给本机默认程序打开。若没看到窗口，可能被其它窗口挡住，或本机没有关联这个格式的程序。',
    });
  });

  // ---- 附件下载票据（v4.20.7）----
  //
  // 手机上"下载附件"两头都堵：
  //   ① 整页直链 —— 安卓会把请求交给**系统下载器**，那是另一个进程，不带会话 cookie，
  //      服务端回 401，使用者看到的是一坨 JSON（v4.20.4 之前的现象）；
  //   ② fetch + Blob —— 很多手机浏览器 / WebView **不支持 blob 下载**，
  //      浏览器自己弹「暂无可用的打开方式」（v4.20.4 之后的现象）。
  //
  // 正解是让直链**不依赖 cookie**：先用已登录会话换一张短时票据，再把带票据的直链交给浏览器。
  // 票据**只替代"身份认证"，绝不替代"权限判定"** —— 下载时按票据里的用户重跑
  // 权限、密级与利用控制，走的是与带 cookie 完全同一条 serveFile；审计日志记的仍是这个用户。
  // 票据有效期 10 分钟（v4.20.9 从 120 秒放宽）。
  // 原因：前端现在**在打开详情时就把票据取好、写进「下载」链接的 href**，
  // 使用者可能看几分钟才点 —— 120 秒会在点下去的那一刻过期，
  // 浏览器就会跳到一个 401 页面。有效期必须覆盖"看完再点"的整个阅读过程。
  const DL_TTL_MS = 10 * 60 * 1000;
  // 只用来拒绝"明显在未来"的到期时间（防伪造），必须**明显大于有效期**。
  //
  // ⚠ 这里踩过一次坑（v4.20.10 修）：有效期从 120 秒提到 10 分钟后，
  //   本值仍是 10 分钟，于是判定退化成
  //     exp < now + DL_MAX_SKEW_MS  ⇔  mint + TTL < now + TTL  ⇔  mint < now
  //   —— 只要签发与校验之间过了哪怕 1 毫秒就为真，票据**一律被判无效（401）**。
  //   表现极具迷惑性：本地单跑同一毫秒内通过，全量回归里就偶发 401。
  //   所以：这个上界必须由有效期**推导**出来，不能各写一个数字。
  const DL_MAX_FUTURE_MS = DL_TTL_MS + 60 * 1000;

  function dlSignKey() {
    let k = settingOf('security.download_sign_key', '');
    if (!k) { k = qrContent.newSignKey(); setSetting('security.download_sign_key', k); }
    return k;
  }
  const dlSignValue = (uid, fileId, exp, mode) => `${fileId}:${uid}:${exp}:${mode}`;

  route('GET', '/api/files/:id/download-ticket', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const mode = url.searchParams.get('mode') === 'inline' ? 'inline' : 'download';
    // 与直链同一口径先判一次：没权限的人连票据都拿不到
    if (!policy.can(u, mode === 'inline' ? 'archive:read' : 'file:download')) {
      return fail(res, 403, mode === 'inline' ? '没有查看原文的权限' : '没有下载附件的权限', 'FORBIDDEN');
    }
    const id = Number(params.id);
    const f = q.get('SELECT id, original_name FROM files WHERE id=?', id);
    if (!f) return fail(res, 404, '文件不存在');
    const exp = Date.now() + DL_TTL_MS;
    const t = qrContent.sign(dlSignKey(), 'download', dlSignValue(u.id, id, exp, mode));
    return ok(res, {
      url: `/api/files/${id}/download?t=${encodeURIComponent(t)}&e=${exp}&u=${u.id}` +
           (mode === 'inline' ? '&inline=1' : ''),
      name: f.original_name,
      mode,
      expiresInSeconds: Math.round(DL_TTL_MS / 1000),
    });
  });

  route('GET', '/api/files/:id/download', async (req, res, params, url) => {
    const inline = url.searchParams.get('inline') === '1';
    const mode = inline ? 'inline' : 'download';
    let u = currentUser(req);
    if (!u) {
      // 无会话：用票据恢复身份。票据被篡改、过期、或与文件/用户对不上，一律 401。
      const tk = String(url.searchParams.get('t') || '');
      const exp = Number(url.searchParams.get('e') || 0);
      const uid = Number(url.searchParams.get('u') || 0);
      const now = Date.now();
      const fresh = exp > now && exp < now + DL_MAX_FUTURE_MS;
      if (tk && uid && fresh &&
          qrContent.verify(dlSignKey(), 'download', dlSignValue(uid, Number(params.id), exp, mode), tk)) {
        u = q.get("SELECT * FROM users WHERE id=? AND status='active'", uid);
      }
      if (!u) return fail(res, 401, '未登录或登录已过期，请重新登录', 'AUTH_REQUIRED');
    }
    serveFile(res, req, Number(params.id), inline, u);
  }, { methods: 'GET,HEAD' });

  // HEAD 与 GET 共用同一处理器：serveFile 内部会正确处理 HEAD（只回响应头）。
  // ⚠ 必须显式写 `methods: 'GET,HEAD'`（v4.20.4 修）：
  //   原来只写 GET，HEAD 就匹配不上这条路由，落到 404 处理器回一个
  //   `application/json` 的 404 —— 而前端是**先 HEAD 问类型再决定怎么显示**的，
  //   拿到 `application/json` 就走进了"当纯文本铺出来"的分支，
  //   于是图片、PDF、Office 全都被铺成二进制乱码（手机上看到的满屏 PK、worksheets/ 就是这个）。
  route('GET', '/api/files/:id/preview', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    serveFile(res, req, Number(params.id), true, u);
  }, { methods: 'GET,HEAD' });

  function serveFile(res, req, fileId, inline, u) {
    if (!can(u, inline ? 'archive:read' : 'file:download')) {
      return fail(res, 403, inline ? '没有查看原文的权限' : '没有下载附件的权限', 'FORBIDDEN');
    }
    const f = q.get(`SELECT f.*, a.archive_code, a.title AS archive_title, a.secret_level
                     FROM files f JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, fileId);
    if (!f) return fail(res, 404, '文件不存在');
    // 密级校验（v3.4.7 的漏洞点：这里查出了 secret_level，却从未据此拦截，
    // 于是标注「机密」的档案，任何 reader 账号都能预览和下载）
    if (!policy.canSeeSecret(u, f.secret_level, enforceSecret())) {
      try {
        log(u, '越权下载被拒', String(f.archive_code || fileId),
          `档案密级=${f.secret_level}，超出账号密级上限`, clientIp(req),
          { result: '拒绝', category: 'security', step: '密级鉴别' });
      } catch (_) { /* 审计失败不影响拒绝 */ }
      return fail(res, 404, '文件不存在');
    }

    // 利用控制（《数字档案室建设指南》§4.4.2）：
    //   下载     —— 普通用户须持有效**下载凭据**；档案员及以上是审批方，直接放行但同样留痕
    //   在线阅读 —— 开启「授权阅读时间」后，普通用户须处于借阅或下载授权的时间窗内
    const isDownload = !inline;
    const approver = can(u, 'loan:approve');
    let grant = null;
    let readWin = null;
    if (!approver) {
      if (isDownload && downloadRequireApproval()) {
        grant = findValidGrant(u, f.id, f.archive_id);
        if (!grant) {
          // 有申请但不满足条件时，把**具体原因**告诉用户（"未到时间"/"已超期"/"已用尽"），
          // 只回一句"没有凭据"会让人反复提交申请却查不出为什么。
          const any = q.get(`SELECT * FROM download_grants WHERE user_id=? AND archive_id=?
                             AND (file_id IS NULL OR file_id=?) ORDER BY id DESC LIMIT 1`,
            u.id, f.archive_id, f.id);
          const st = any ? grantState(any) : null;
          const detail = (any && st && st.reason) ? `（你最近一次申请 ${any.grant_no}：${st.reason}）` : '';
          log(u, '受控下载被拒', String(f.archive_code || fileId),
            st ? st.reason : '无有效下载凭据', clientIp(req),
            { result: '拒绝', category: 'security', step: '下载授权' });
          return fail(res, 403,
            '该附件受控：请先提交下载申请并经档案员审批（《数字档案室建设指南》§4.4.2 下载审批）' + detail,
            'DOWNLOAD_NOT_GRANTED');
        }
      } else if (!isDownload && readWindowEnforced()) {
        readWin = readWindowOk(u, f.archive_id);
        if (!readWin.ok) {
          log(u, '阅读时间窗外被拒', String(f.archive_code || fileId), readWin.reason, clientIp(req),
            { result: '拒绝', category: 'security', step: '授权阅读时间' });
          return fail(res, 403, readWin.reason, 'READ_WINDOW');
        }
      }
    }

    // 利用登记（V4.32.0）：谁在什么时候动了哪一件 —— 与"能不能"无关，是事后可查的台账号。
    recordUsage(u, f.archive_id, isDownload ? '下载' : '查阅',
      { fileId: f.id, target: f.original_name, ip: clientIp(req) });

    let abs;
    try { abs = absPath(filesRoot, f.rel_path); } catch (e) { return fail(res, 400, e.message); }
    if (!fs.existsSync(abs)) return fail(res, 410, '文件实体已丢失，请重新上传');
    const stat = fs.statSync(abs);
    const name = f.original_name || f.stored_name;

    // 利用水印：人 + 时间 + 凭据编号（缺一不可追溯）
    const wm = wmTextFor(u, f, grant ? grant.grant_no : '', grant ? grant.purpose : '', '');
    // 千问版 v4.30.8 输出加固（防存储型 XSS 的"出门"一道，与上传白名单互为纵深）：
    //   ① MIME 以**扩展名**重算，不信库里存的客户端申报值 —— 旧记录可能谎报 text/html；
    //   ② 危险类型（html/svg/xml/脚本）即使存量库里有，也强制 attachment，绝不内联执行；
    //   ③ 恒带 nosniff，禁止浏览器自行嗅探类型。
    const outExt = String(name).slice(String(name).lastIndexOf('.') + 1).toLowerCase();
    const dangerousInline = DANGEROUS_INLINE_EXT.has(outExt);
    const safeInline = inline && !dangerousInline;
    const headers = {
      'Content-Type': mimeOf(name),
      'Content-Disposition': contentDisposition(name, safeInline),
      'X-Content-Type-Options': 'nosniff',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'private, max-age=0, must-revalidate',
      'X-Archive-Code': encodeURIComponent(f.archive_code || ''),
    };
    if (wm) headers['X-Watermark-Text'] = encodeURIComponent(wm);
    if (grant) headers['X-Download-Grant'] = grant.grant_no;
    // 页面级限制：凭据可限定"只授权第几页到第几页"。
    // 说明：PDF 的页数无法在零依赖下物理裁剪，因此这里以响应头 + 预览页跳转提示的方式
    // **登记并提示**授权范围（诚实告知，不做"看起来限制了其实没有"的假象）。
    if (grant && (Number(grant.page_from) || Number(grant.page_to))) {
      headers['X-Page-Range'] = `${Number(grant.page_from) || 1}-${Number(grant.page_to) || 'end'}`;
    }

    // 文本类附件做**内容级水印**（首尾各一段：裁掉首尾就缺内容）。
    // 只对**利用者**（非审批方）施加：档案员/管理员本就是原始件的管理者，
    // 给他们的副本加水印既没有追溯意义，又会破坏字节一致性与 HTTP Range
    // （Range 是断点续传与浏览器内预览的基础）。
    let wmBuf = null;
    if (isDownload && !approver && wm && watermark.isTextLike(name) && stat.size <= 8 * 1024 * 1024) {
      try { wmBuf = watermark.applyTextWatermark(fs.readFileSync(abs), wm).buffer; } catch (_) { wmBuf = null; }
    }
    if (wmBuf) {
      const h = Object.assign({}, headers, { 'Content-Length': wmBuf.length });
      delete h['Accept-Ranges'];
      delete h['Content-Range'];
      res.writeHead(200, h);
      if (req.method === 'HEAD') return res.end();
      if (grant) consumeGrant(grant, u, f);
      else {
        log(u, '下载附件（已加水印）', String(f.archive_code || fileId), wm, clientIp(req),
          { category: 'output', step: '下载' });
      }
      return res.end(wmBuf);
    }

    // 二进制附件：不做内容层注入（原因见 lib/watermark.js 的能力边界说明），
    // 以"登记凭据 + 响应头 + 哈希链审计日志"实现可追溯，并把原因明确告知
    if (isDownload && wm) {
      headers['X-Watermark-Note'] = encodeURIComponent(watermark.binaryNote(name));
    }

    const range = req.headers.range;
    if (range && /^bytes=\d*-\d*$/.test(range)) {
      const [s, e] = range.replace('bytes=', '').split('-');
      let start = s ? parseInt(s, 10) : 0;
      let end = e ? parseInt(e, 10) : stat.size - 1;
      if (Number.isNaN(start)) start = 0;
      if (Number.isNaN(end) || end >= stat.size) end = stat.size - 1;
      if (start > end) {
        res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
        return res.end();
      }
      headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
      headers['Content-Length'] = end - start + 1;
      res.writeHead(206, headers);
      if (isDownload) {
        if (grant) consumeGrant(grant, u, f);
        else log(u, '下载附件', String(f.archive_code || fileId), name, clientIp(req), { category: 'output', step: '下载' });
      }
      return fs.createReadStream(abs, { start, end }).pipe(res);
    }
    headers['Content-Length'] = stat.size;
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    if (isDownload) {
      if (grant) consumeGrant(grant, u, f);
      else log(u, '下载附件', String(f.archive_code || fileId), name, clientIp(req), { category: 'output', step: '下载' });
    }
    fs.createReadStream(abs).pipe(res);
  }

  /**
   * 带水印的在线预览页（《数字档案室建设指南》§4.4.2「数字水印」的在线部分）。
   *
   * 为什么单独做一个页面而不是直接 inline 原始文件：
   *   inline 出去的是**干净的原件**，水印无从附着；预览页由服务端渲染，
   *   水印层是页面的一部分，用户无法通过"另存为"把它去掉。
   */
  route('GET', '/api/files/:id/view', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const fileId = Number(params.id);
    const f = q.get(`SELECT f.*, a.archive_code, a.title AS archive_title, a.secret_level, a.archive_number
                     FROM files f JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, fileId);
    if (!f) return fail(res, 404, '文件不存在');
    if (!policy.canSeeSecret(u, f.secret_level, enforceSecret())) return fail(res, 404, '文件不存在');
    const approver = can(u, 'loan:approve');
    let win = null;
    if (!approver && readWindowEnforced()) {
      win = readWindowOk(u, f.archive_id);
      if (!win.ok) return fail(res, 403, win.reason, 'READ_WINDOW');
    }
    const wm = wmTextFor(u, f, win && win.ref ? win.ref : '', '', '');
    const name = f.original_name || f.stored_name;
    const ext = String(name).slice(String(name).lastIndexOf('.') + 1).toLowerCase();
    const src = `/api/files/${fileId}/preview`;
    let embed = '';
    if (ext === 'pdf') {
      // 页面级限制：PDF 用浏览器查看器的 #page= 直接跳到授权起始页
      const pf = win && win.pageFrom ? `#page=${win.pageFrom}` : '';
      embed = `<embed src="${src}${pf}" type="application/pdf" class="wm-doc"/>`;
    } else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'].includes(ext)) {
      embed = `<img src="${src}" class="wm-img" alt="${esc(name)}">`;
    } else if (watermark.isTextLike(name)) {
      let text = '';
      try {
        const abs = absPath(filesRoot, f.rel_path);
        if (fs.existsSync(abs)) text = fs.readFileSync(abs, 'utf8').slice(0, 200000);
      } catch (_) { text = ''; }
      embed = `<pre class="wm-text">${esc(text)}</pre>`;
    } else {
      embed = `<div class="wm-none">该格式不支持在线预览（${esc(ext || '未知格式')}）。
        请通过「下载」取得副本；下载行为会登记凭据并写入审计日志。</div>`;
    }
    const html = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>${esc(name)}</title>
<style>
  body { margin:0; font-family:"Microsoft YaHei","Noto Sans CJK SC",sans-serif; background:#f5f5f5; }
  .wm-bar { background:#1b4d8f; color:#fff; padding:8px 14px; font-size:13px; display:flex;
            justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; }
  .wm-bar b { font-weight:600; }
  .wm-wrap { position:relative; margin:12px; background:#fff; box-shadow:0 1px 4px rgba(0,0,0,.15); overflow:hidden; }
  .wm-doc { width:100%; height:calc(100vh - 130px); border:0; display:block; background:#fff; }
  .wm-img { max-width:100%; display:block; margin:0 auto; }
  .wm-text { padding:18px 22px; white-space:pre-wrap; word-break:break-all; font-size:13px; line-height:1.7; margin:0; }
  .wm-none { padding:40px 24px; text-align:center; color:#666; font-size:14px; line-height:2; }
  ${watermark.OVERLAY_CSS}
</style></head>
<body>
  <div class="wm-bar">
    <div>${esc(f.archive_number || f.archive_code || '')}　<b>${esc(f.archive_title || '')}</b>　—　${esc(name)}</div>
    <div>密级：${esc(f.secret_level)}${win && win.from ? `　授权阅读：${esc(win.from.slice(0, 16).replace('T', ' '))} ~ ${esc((win.to || '').slice(0, 16).replace('T', ' '))}` : ''}</div>
  </div>
  <div class="wm-wrap">
    ${watermark.overlayHtml(wm)}
    ${embed}
  </div>
  <div class="wm-bar" style="background:#333">
    <div>本页为受控副本，水印含使用者与时间，外传可追溯。</div>
    <div>${esc(wm)}</div>
  </div>
</body></html>`;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  route('PUT', '/api/files/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const f = q.get(`SELECT f.*, a.created_by FROM files f JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, id);
    if (!f) return fail(res, 404, '文件不存在');
    if (!can(u, 'file:delete', { ownerId: f.created_by })) return fail(res, 403, '没有修改权限');
    const b = await readJson(req);
    q.run('UPDATE files SET original_name=?, kind=?, sort_no=? WHERE id=?',
      mustStr(b.original_name, 200) || f.original_name,
      mustStr(b.kind, 20) || f.kind,
      numOr(b.sort_no, f.sort_no), id);
    ok(res, true);
  });

  /**
   * 调整附件顺序（上移 / 下移 / 挪到第 N 位）。
   *
   * 为什么不直接让前端改 sort_no：sort_no 只表达**相对顺序**，
   * 单独改一个值会出现重复或空洞（两条都是 3，谁在前就退化成"看 id"），
   * 所以这里统一「把某件挪到目标位置，然后整体重排 1..n」。
   *
   * body: `{ to: 目标位置(1 基) }` 或 `{ dir: 'up' | 'down' }`
   */
  route('POST', '/api/files/:id/move', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const f = q.get(`SELECT f.*, a.created_by, a.archive_code, a.secret_level FROM files f
                     JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, id);
    if (!f) return fail(res, 404, '文件不存在');
    if (!assertArchiveVisible(req, res, u, f)) return;
    if (!can(u, 'archive:update', { ownerId: f.created_by })) return fail(res, 403, '没有调整附件顺序的权限');

    const b = await readJson(req);
    const ids = q.all('SELECT id FROM files WHERE archive_id=? ORDER BY sort_no, id', f.archive_id).map((r) => r.id);
    const cur = ids.indexOf(id);
    let target;
    if (b.dir === 'up') target = cur - 1;
    else if (b.dir === 'down') target = cur + 1;
    else target = (Number(b.to) || 0) - 1;
    // 已经在两端时不算错误：界面上的"上移/下移"按钮点到底就该是静默无效
    if (target < 0 || target >= ids.length || target === cur) {
      return ok(res, { moved: false, position: cur + 1, order: ids });
    }
    ids.splice(target, 0, ids.splice(cur, 1)[0]);
    q.tx(() => { ids.forEach((fid, i) => q.run('UPDATE files SET sort_no=? WHERE id=?', i + 1, fid)); });
    log(u, '调整附件顺序', f.archive_code,
      `${f.original_name}：第 ${cur + 1} 位 → 第 ${target + 1} 位`, clientIp(req), { step: '附件排序' });
    ok(res, { moved: true, position: target + 1, order: ids });
  });

  /**
   * 替换附件内容（补页 / 重扫）。
   *
   * 与「删掉再传」的关键区别：**保留旧版留痕** —— 旧文件名、SHA-256、大小、类型、
   * 原因、经办人、时间都写进 `file_replacements`。否则事后无法证明这份电子原文被替换过、
   * 原来是什么；而"电子档案的完整性"恰恰要求说得出这一点。
   *
   * 落在**同一行 files** 上（id 不变），所以归档章、元数据 M05/M07、二维码里的引用都不用改。
   */
  route('POST', '/api/files/:id/replace', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const f = q.get(`SELECT f.*, a.created_by, a.archive_code, a.type_code, a.secret_level FROM files f
                     JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, id);
    if (!f) return fail(res, 404, '文件不存在');
    if (!assertArchiveVisible(req, res, u, f)) return;
    if (!can(u, 'archive:update', { ownerId: f.created_by })) return fail(res, 403, '没有替换正文的权限');

    const form = await parseMultipart(req, {
      maxFileSize: MAX_UPLOAD_MB * 1024 * 1024,
      maxTotalSize: MAX_UPLOAD_MB * 1024 * 1024,
      maxFiles: 1,
    });
    if (!form.files.length) return fail(res, 400, '没有收到替换文件');
    const nf = form.files[0];
    // 千问版 v4.30.8：替换与上传同一套白名单 —— 否则"先传合规件再替换成 .html"就绕过去了
    if (uploadExtBlocked(nf.filename)) {
      return fail(res, 400, `文件类型不允许：${nf.filename}。只接收文档类附件；网页、脚本、可执行程序请先转换为 PDF 或图片`);
    }
    const reason = mustStr(form.fields.reason, 200);
    const keepName = String(form.fields.keep_name || '') === '1';
    const newName = keepName ? f.original_name : nf.filename;

    // 替换**原地写**：路径不变（档号改过也不让文件漂移），旧内容由 file_replacements 留痕
    const s = saveArchiveFile(filesRoot, storageCtxOf(f), nf, { relPath: f.rel_path, overwrite: true });
    const pages = pdfInfo.isPdf(nf.filename, nf.mime) ? pdfInfo.pageCount(nf.data) : 0;
    q.tx(() => {
      q.run(`INSERT INTO file_replacements(archive_id,file_id,old_name,old_sha256,old_size,old_mime,reason,replaced_by,replaced_at)
             VALUES(?,?,?,?,?,?,?,?,?)`,
        f.archive_id, id, f.original_name, f.sha256, f.size, f.mime, reason, u.id, nowIso());
      q.run(`UPDATE files SET original_name=?, stored_name=?, rel_path=?, mime=?, size=?, sha256=?,
               pages=?, scanned_at=?, storage_kind=? WHERE id=?`,
        newName, s.stored_name, s.rel_path, s.mime || mimeOf(nf.filename), s.size, s.sha256,
        pages, f.kind === '扫描件' ? nowIso() : f.scanned_at || '',
        String(f.rel_path || '').startsWith('归档/') ? 'archive' : 'process', id);
      q.run('UPDATE archives SET updated_at=? WHERE id=?', nowIso(), f.archive_id);
    });
    // 旧实体若已无人引用才删盘（内容寻址：同一份文件可能还被别的记录指着）
    const still = q.scalar('SELECT COUNT(*) FROM files WHERE rel_path=?', f.rel_path);
    if (!still) removeStored(filesRoot, f.rel_path);

    const tr = indexFileText(id, f.archive_id, nf.data, nf.filename);
    try { captureAndSaveMetadata(f.archive_id, u, '替换正文后同步'); } catch (e) {
      console.warn('[元数据] 同步失败（不影响替换）：' + e.message);
    }
    let detectionResult = null;
    if (String(numbering.getSetting(q, 'detection.auto_on_upload', '1')) === '1') {
      const totalBytes = Number(q.scalar('SELECT COALESCE(SUM(size),0) FROM files WHERE archive_id=?', f.archive_id) || 0);
      if (totalBytes <= AUTO_DETECT_MAX_BYTES) {
        try { detectionResult = runAndSaveDetection(u, f.archive_id, 'archive', '替换正文'); }
        catch (e) { console.warn('[四性检测] 替换后自动检测失败：' + e.message); }
      }
    }
    log(u, '替换正文', f.archive_code,
      `${f.original_name}（旧 SHA-256 ${String(f.sha256 || '').slice(0, 12)}…）${reason ? '　原因：' + reason : ''}`,
      clientIp(req), { step: '正文替换' });
    ok(res, {
      id, name: newName, sha256: s.sha256, pages,
      text: { ok: tr.ok, chars: (tr.text || '').length, reason: tr.reason || '' },
      detection: detectionResult,
      scanCheck: String(numbering.getSetting(q, 'scan.pages_check', '1')) === '1' ? scanPagesCheck(f.archive_id) : null,
    });
  });

  /** 正文替换留痕（谁、何时、为什么、旧版是什么） */
  route('GET', '/api/archives/:id/replacements', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = q.get('SELECT id, secret_level, created_by FROM archives WHERE id=?', Number(params.id));
    if (!a) return fail(res, 404, '档案不存在');
    if (!assertArchiveVisible(req, res, u, a)) return;
    const list = q.all(`SELECT r.*, usr.display_name AS by_name FROM file_replacements r
                        LEFT JOIN users usr ON usr.id=r.replaced_by
                        WHERE r.archive_id=? ORDER BY r.id DESC LIMIT 200`, a.id);
    ok(res, { list, total: list.length });
  });

  route('DELETE', '/api/files/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const f = q.get(`SELECT f.*, a.created_by, a.archive_code FROM files f JOIN archives a ON a.id=f.archive_id WHERE f.id=?`, id);
    if (!f) return fail(res, 404, '文件不存在');
    if (!can(u, 'file:delete', { ownerId: f.created_by })) return fail(res, 403, '没有删除权限');
    q.run('DELETE FROM files WHERE id=?', id);
    // 内容寻址存储：确认没有其他记录引用同一实体后再删盘
    const still = q.scalar('SELECT COUNT(*) FROM files WHERE rel_path=?', f.rel_path);
    if (!still) removeStored(filesRoot, f.rel_path);
    log(u, '删除附件', f.archive_code, f.original_name, clientIp(req));
    ok(res, true);
  });

  // ===== 过程接收：项目 / 批次 / 归档定稿（v4.29.0）=====
  //
  // 本单位交来的是**还在形成的资料**：工程没竣工就先交开工、基础、主体；养护按季度一批一批来。
  // 所以这里不套"档案馆那套一次成型的档号目录"，而是把"谁、什么时候、为哪个项目、交了哪一批"记清楚，
  // 时间轴靠 received_at 排序，目录靠"日期打头的批次目录"排序 —— 两处一致。

  function todayStr() { return new Date().toISOString().slice(0, 10); }

  const PROJECT_KINDS = ['工程', '养护', '其他'];
  const PROJECT_STATUSES = ['在建', '已完工', '已归档'];

  /** 项目号：GC-2026-003 / YH-2026-001（前缀可在设置里改） */
  function nextProjectNo(kind) {
    const isMaint = String(kind || '') === '养护';
    const prefix = String(numbering.getSetting(
      q, isMaint ? 'intake.prefix_maintenance' : 'intake.prefix_engineering', isMaint ? 'YH' : 'GC',
    ));
    const year = new Date().getFullYear();
    let n = Number(q.scalar('SELECT COUNT(*) FROM projects WHERE project_no LIKE ?', `${prefix}-${year}-%`) || 0);
    let no = `${prefix}-${year}-${String(n + 1).padStart(3, '0')}`;
    let guard = 0;
    while (q.scalar('SELECT id FROM projects WHERE project_no=?', no) && guard++ < 999) {
      n += 1;
      no = `${prefix}-${year}-${String(n + 1).padStart(3, '0')}`;
    }
    return no;
  }

  /** 批次号：SR-20260312-01（SR = 收入；按接收日期分段，天然可读可排） */
  function nextBatchNo(receivedAt) {
    const d = String(receivedAt || todayStr()).slice(0, 10).replace(/-/g, '');
    let n = Number(q.scalar('SELECT COUNT(*) FROM intake_batches WHERE batch_no LIKE ?', `SR-${d}-%`) || 0);
    let no = `SR-${d}-${String(n + 1).padStart(2, '0')}`;
    let guard = 0;
    while (q.scalar('SELECT id FROM intake_batches WHERE batch_no=?', no) && guard++ < 999) {
      n += 1;
      no = `SR-${d}-${String(n + 1).padStart(2, '0')}`;
    }
    return no;
  }

  route('GET', '/api/projects', (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:read')) return fail(res, 403, '没有查看项目的权限');
    const sp = url.searchParams;
    const where = [];
    const args = [];
    const kind = mustStr(sp.get('kind'), 10);
    if (kind) { where.push('p.kind=?'); args.push(kind); }
    const status = mustStr(sp.get('status'), 10);
    if (status) { where.push('p.status=?'); args.push(status); }
    const kw = mustStr(sp.get('kw'), 100).trim();
    if (kw) { where.push('(p.name LIKE ? OR p.project_no LIKE ?)'); args.push('%' + kw + '%', '%' + kw + '%'); }
    const sql = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const list = q.all(`SELECT p.*,
        (SELECT COUNT(*) FROM intake_batches b WHERE b.project_id=p.id) AS batch_count,
        (SELECT COALESCE(SUM(b.archive_count),0) FROM intake_batches b WHERE b.project_id=p.id) AS archive_count,
        (SELECT MAX(b.received_at) FROM intake_batches b WHERE b.project_id=p.id) AS last_received
      FROM projects p${sql}
      ORDER BY CASE p.status WHEN '在建' THEN 0 WHEN '已完工' THEN 1 ELSE 2 END, p.id DESC
      LIMIT 500`, ...args);
    ok(res, { list });
  });

  route('GET', '/api/projects/:id', (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:read')) return fail(res, 403, '没有查看项目的权限');
    const p = q.get('SELECT * FROM projects WHERE id=?', Number(params.id));
    if (!p) return fail(res, 404, '项目不存在');
    const batches = q.all(`
      SELECT b.*,
        (SELECT COUNT(*) FROM archives a WHERE a.batch_id=b.id) AS item_count,
        (SELECT COALESCE(SUM(f.pages),0) FROM files f JOIN archives a ON a.id=f.archive_id
          WHERE a.batch_id=b.id AND f.kind='扫描件') AS scanned_pages,
        (SELECT COUNT(DISTINCT a.id) FROM archives a JOIN files f ON f.archive_id=a.id
          WHERE a.batch_id=b.id AND f.kind='扫描件') AS scanned_items
      FROM intake_batches b WHERE b.project_id=?
      ORDER BY b.received_at DESC, b.id DESC`, p.id);
    ok(res, { project: p, batches });
  });

  route('POST', '/api/projects', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:create')) return fail(res, 403, '没有新建项目的权限');
    const b = await readJson(req);
    const name = mustStr(b.name, 200).trim();
    if (!name) return fail(res, 400, '项目名称不能为空');
    const kind = PROJECT_KINDS.includes(b.kind) ? b.kind : '工程';
    const no = mustStr(b.project_no, 40).trim() || nextProjectNo(kind);
    if (q.scalar('SELECT id FROM projects WHERE project_no=?', no)) return fail(res, 409, `项目号 ${no} 已存在`);
    const ts = nowIso();
    const r = q.run(`INSERT INTO projects(project_no,name,kind,status,start_date,end_date,note,created_by,created_at,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)`,
      no, name, kind, PROJECT_STATUSES.includes(b.status) ? b.status : '在建',
      String(b.start_date || '').slice(0, 10), String(b.end_date || '').slice(0, 10),
      mustStr(b.note, 500), u.id, ts, ts);
    log(u, '新建项目', no, `${name}（${kind}）`, clientIp(req), { step: '过程接收' });
    ok(res, { id: r.lastInsertRowid, project_no: no });
  });

  route('PUT', '/api/projects/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有修改项目的权限');
    const p = q.get('SELECT * FROM projects WHERE id=?', Number(params.id));
    if (!p) return fail(res, 404, '项目不存在');
    const b = await readJson(req);
    const name = mustStr(b.name, 200).trim() || p.name;
    const status = PROJECT_STATUSES.includes(b.status) ? b.status : p.status;
    const kind = PROJECT_KINDS.includes(b.kind) ? b.kind : p.kind;
    q.run('UPDATE projects SET name=?, kind=?, status=?, start_date=?, end_date=?, note=?, updated_at=? WHERE id=?',
      name, kind, status,
      String(b.start_date || p.start_date || '').slice(0, 10),
      String(b.end_date || p.end_date || '').slice(0, 10),
      b.note === undefined ? p.note : mustStr(b.note, 500), nowIso(), p.id);
    log(u, '修改项目', p.project_no, `${p.name} → ${name}${status !== p.status ? `　状态 ${p.status} → ${status}` : ''}`,
      clientIp(req), { step: '过程接收' });
    ok(res, true);
  });

  /** 时间轴：所有批次按接收日期倒序（这就是"所有交过来的都按时间排序"） */
  route('GET', '/api/batches', (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:read')) return fail(res, 403, '没有查看接收批次的权限');
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (sp.get('project_id')) { where.push('b.project_id=?'); args.push(Number(sp.get('project_id'))); }
    if (sp.get('status')) { where.push('b.status=?'); args.push(mustStr(sp.get('status'), 10)); }
    const kw = mustStr(sp.get('kw'), 100).trim();
    if (kw) { where.push('(b.title LIKE ? OR b.batch_no LIKE ? OR p.name LIKE ?)'); args.push('%' + kw + '%', '%' + kw + '%', '%' + kw + '%'); }
    const sql = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const limit = Math.min(500, Math.max(1, Number(sp.get('limit')) || 100));
    const list = q.all(`SELECT b.*, p.project_no, p.name AS project_name, p.kind AS project_kind,
        (SELECT COUNT(*) FROM archives a WHERE a.batch_id=b.id) AS item_count,
        (SELECT COALESCE(SUM(f.pages),0) FROM files f JOIN archives a ON a.id=f.archive_id
          WHERE a.batch_id=b.id AND f.kind='扫描件') AS scanned_pages
      FROM intake_batches b LEFT JOIN projects p ON p.id=b.project_id
      ${sql} ORDER BY b.received_at DESC, b.id DESC LIMIT ${limit}`, ...args);
    ok(res, { list });
  });

  route('GET', '/api/batches/:id', (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:read')) return fail(res, 403, '没有查看接收批次的权限');
    const b = q.get(`SELECT b.*, p.project_no, p.name AS project_name, p.kind AS project_kind,
        (SELECT COUNT(*) FROM archives a WHERE a.batch_id=b.id) AS item_count,
        (SELECT COALESCE(SUM(f.pages),0) FROM files f JOIN archives a ON a.id=f.archive_id
          WHERE a.batch_id=b.id AND f.kind='扫描件') AS scanned_pages,
        (SELECT COUNT(DISTINCT a.id) FROM archives a JOIN files f ON f.archive_id=a.id
          WHERE a.batch_id=b.id AND f.kind='扫描件') AS scanned_items
      FROM intake_batches b LEFT JOIN projects p ON p.id=b.project_id WHERE b.id=?`, Number(params.id));
    if (!b) return fail(res, 404, '批次不存在');
    const scope = secretScope(u);
    const items = q.all(`SELECT a.id, a.archive_code, a.archive_number, a.title, a.year, a.retention,
        a.status, a.archive_state, a.pages,
        (SELECT COUNT(*) FROM files f WHERE f.archive_id=a.id) AS file_count,
        (SELECT COALESCE(SUM(f.pages),0) FROM files f WHERE f.archive_id=a.id AND f.kind='扫描件') AS scanned_pages
      FROM archives a WHERE a.batch_id=?${scope.sql} ORDER BY a.archive_number, a.id`, b.id, ...scope.params);
    ok(res, { batch: b, items });
  });

  route('POST', '/api/batches', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:create')) return fail(res, 403, '没有登记接收批次的权限');
    const b = await readJson(req);
    const projectId = Number(b.project_id) || null;
    let project = null;
    if (projectId) {
      project = q.get('SELECT * FROM projects WHERE id=?', projectId);
      if (!project) return fail(res, 400, '项目不存在');
    }
    const receivedAt = String(b.received_at || '').slice(0, 10) || todayStr();
    const title = mustStr(b.title, 200).trim() || '第1批';
    const stage = mustStr(b.stage, 40).trim();
    const ts = nowIso();
    const no = mustStr(b.batch_no, 40).trim() || nextBatchNo(receivedAt);
    if (q.scalar('SELECT id FROM intake_batches WHERE batch_no=?', no)) return fail(res, 409, `批次号 ${no} 已存在`);
    const r = q.run(`INSERT INTO intake_batches(batch_no,project_id,title,stage,received_at,source_unit,
                       handover_by,handover_phone,receive_by,note,status,archive_count,created_by,created_at,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)`,
      no, projectId, title, stage, receivedAt, mustStr(b.source_unit, 100), mustStr(b.handover_by, 50),
      mustStr(b.handover_phone, 20),
      mustStr(b.receive_by, 50) || (u.display_name || ''), mustStr(b.note, 500), '接收中', u.id, ts, ts);
    log(u, '登记接收批次', no, `${project ? project.project_no + ' ' + project.name + '｜' : ''}${title}（${receivedAt}）`,
      clientIp(req), { step: '过程接收' });
    ok(res, { id: r.lastInsertRowid, batch_no: no });
  });

  route('PUT', '/api/batches/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有修改接收批次的权限');
    const b = q.get('SELECT * FROM intake_batches WHERE id=?', Number(params.id));
    if (!b) return fail(res, 404, '批次不存在');
    const v = await readJson(req);
    q.run(`UPDATE intake_batches SET title=?, stage=?, received_at=?, source_unit=?, handover_by=?,
             handover_phone=?, receive_by=?, note=?, updated_at=? WHERE id=?`,
      mustStr(v.title, 200) || b.title, v.stage === undefined ? b.stage : mustStr(v.stage, 40),
      String(v.received_at || b.received_at).slice(0, 10),
      v.source_unit === undefined ? b.source_unit : mustStr(v.source_unit, 100),
      v.handover_by === undefined ? b.handover_by : mustStr(v.handover_by, 50),
      v.handover_phone === undefined ? b.handover_phone : mustStr(v.handover_phone, 20),
      v.receive_by === undefined ? b.receive_by : mustStr(v.receive_by, 50),
      v.note === undefined ? b.note : mustStr(v.note, 500), nowIso(), b.id);
    log(u, '修改接收批次', b.batch_no, mustStr(v.title, 200) || b.title, clientIp(req), { step: '过程接收' });
    ok(res, true);
  });

  /**
   * 归档定稿：把这一批的件从"过程区"移到"归档区"（按档号逐级目录）。
   *
   * 为什么要单独一个动作，而不是自动：归档意味着"这批资料到此定稿"，
   * 定稿之后就不该再随手补件。人来点这一下，系统才敢把它标成已归档。
   */
  route('POST', '/api/batches/:id/finalize', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'archive:update')) return fail(res, 403, '没有归档定稿的权限');
    const batch = q.get('SELECT * FROM intake_batches WHERE id=?', Number(params.id));
    if (!batch) return fail(res, 404, '批次不存在');
    const project = batch.project_id ? q.get('SELECT * FROM projects WHERE id=?', batch.project_id) : null;
    const list = q.all('SELECT * FROM archives WHERE batch_id=?', batch.id);
    let movedFiles = 0;
    let failed = 0;
    let archivedArchives = 0;
    for (const a of list) {
      if (String(a.archive_state) === '已归档') continue;
      const targetDir = storage.relDirFor({ zone: 'archive', archive: a });
      const base = storage.fileBaseName(a);
      const files = q.all('SELECT * FROM files WHERE archive_id=? ORDER BY sort_no, id', a.id);
      let okAll = true;
      files.forEach((f, i) => {
        const ext = storage.extOf(f.original_name) || storage.extOf(f.rel_path);
        const name = base + (i === 0 ? '' : '-' + String(i + 1).padStart(2, '0')) + ext;
        try {
          const newRel = storage.moveStored(filesRoot, f.rel_path, `${targetDir}/${name}`);
          q.run("UPDATE files SET rel_path=?, stored_name=?, storage_kind='archive' WHERE id=?", newRel, name, f.id);
          movedFiles += 1;
        } catch (e) {
          okAll = false;
          failed += 1;
          console.warn(`[归档定稿] 移动失败 ${f.rel_path}：${e.message}`);
        }
      });
      if (okAll) {
        q.run("UPDATE archives SET archive_state='已归档', updated_at=? WHERE id=?", nowIso(), a.id);
        archivedArchives += 1;
      }
    }
    q.run("UPDATE intake_batches SET status='已归档', updated_at=? WHERE id=?", nowIso(), batch.id);
    if (project && String(numbering.getSetting(q, 'intake.auto_project_archived', '1')) === '1') {
      const left = Number(q.scalar("SELECT COUNT(*) FROM intake_batches WHERE project_id=? AND status<>'已归档'", project.id) || 0);
      if (!left) q.run("UPDATE projects SET status='已归档', updated_at=? WHERE id=?", nowIso(), project.id);
    }
    log(u, '归档定稿', batch.batch_no,
      `${project ? project.project_no + '｜' : ''}${batch.title}：${archivedArchives} 件、${movedFiles} 个文件移入归档区`
      + (failed ? `，失败 ${failed} 个` : ''), clientIp(req), { step: '过程接收' });
    ok(res, {
      archived: archivedArchives, movedFiles, failed,
      batch_no: batch.batch_no, status: '已归档',
    });
  });

  // ===== 借阅 =====
  route('GET', '/api/loans', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    processLoanDue();
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (sp.get('status')) { where.push('l.status=?'); args.push(sp.get('status')); }
    if (sp.get('mine') === '1') { where.push('l.user_id=?'); args.push(u.id); }
    if (sp.get('archive_id')) { where.push('l.archive_id=?'); args.push(Number(sp.get('archive_id'))); }
    const kw = (sp.get('kw') || '').trim();
    if (kw) {
      where.push('(a.title LIKE ? OR a.archive_code LIKE ? OR l.loan_no LIKE ? OR u.display_name LIKE ?)');
      const like = '%' + kw + '%';
      args.push(like, like, like, like);
    }
    const sql = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const page = Math.max(1, numOr(sp.get('page'), 1));
    const size = Math.min(200, Math.max(1, numOr(sp.get('size'), 20)));
    const total = Number(q.scalar(`SELECT COUNT(*) FROM loans l
      LEFT JOIN archives a ON a.id=l.archive_id LEFT JOIN users u ON u.id=l.user_id ${sql}`, ...args) || 0);
    const list = q.all(`SELECT l.*, a.archive_code, a.title AS archive_title, a.type_code,
                               u.display_name AS user_name, u.department AS user_department,
                               ab.display_name AS approver_name
                        FROM loans l
                        LEFT JOIN archives a ON a.id=l.archive_id
                        LEFT JOIN users u ON u.id=l.user_id
                        LEFT JOIN users ab ON ab.id=l.approve_by
                        ${sql}
                        ORDER BY (l.status='待审批') DESC, l.id DESC
                        LIMIT ? OFFSET ?`, ...args, size, (page - 1) * size);
    const counts = {
      pending: Number(q.scalar("SELECT COUNT(*) FROM loans WHERE status='待审批'") || 0),
      active: Number(q.scalar("SELECT COUNT(*) FROM loans WHERE status IN ('已批准','逾期')") || 0),
      overdue: Number(q.scalar("SELECT COUNT(*) FROM loans WHERE status='逾期'") || 0),
      total,
    };
    ok(res, { list, total, page, size, pages: Math.max(1, Math.ceil(total / size)), counts });
  });

  route('POST', '/api/loans', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    // 动作级鉴权：借阅是业务行为，安全审计员参与审计但不参与业务，不能借阅
    if (!can(u, 'loan:apply')) return fail(res, 403, '当前账号没有借阅申请的权限', 'FORBIDDEN');
    const b = await readJson(req);
    const archiveId = Number(b.archive_id);
    // 借阅申请同样受密级约束：看不到的档案不允许申请借阅（否则等于绕开密级去调阅）
    const a = loadVisibleArchive(req, res, u, archiveId);
    if (!a) return;
    if (a.status === '待销毁' || a.status === '已销毁') return fail(res, 400, `该档案状态为「${a.status}」，不能借阅`);
    const mode = ['借出', '查阅', '复制'].includes(b.mode) ? b.mode : '借出';
    const dup = q.get(`SELECT id FROM loans WHERE archive_id=? AND user_id=? AND status IN ('待审批','已批准','逾期')`, archiveId, u.id);
    if (dup) return fail(res, 400, '你已有该档案的未完成借阅申请');
    if (mode === '借出') {
      const busy = q.scalar(`SELECT COUNT(*) FROM loans WHERE archive_id=? AND mode='借出' AND status IN ('已批准','逾期')`, archiveId);
      if (busy) return fail(res, 400, '该档案当前已借出，可申请查阅或等待归还');
    }
    const due = mustStr(b.due_date, 12).trim();
    // 档案员及以上可直接批准
    const auto = (ROLE_LEVEL[u.role] || 0) >= ROLE_LEVEL.clerk;
    const status = auto ? '已批准' : '待审批';
    const ts = nowIso();
    // 授权阅读时间窗（《数字档案室建设指南》§4.4.2）：
    // 批准即开始计时，默认给一段可用时长；未批准时为空 —— 空窗口不授予任何阅读权。
    const hours = Math.max(1, Math.min(8760, Number(numbering.getSetting(q, 'loan.default_read_hours', '8')) || 8));
    const readFrom = auto ? ts : '';
    const readTo = auto ? new Date(Date.now() + hours * 3600000).toISOString() : '';
    const wm = auto ? wmTextFor(u, a, '', mustStr(b.purpose, 100), ts) : '';
    const r = q.run(`INSERT INTO loans(loan_no,archive_id,user_id,purpose,mode,status,apply_at,approve_at,approve_by,
                       due_date,read_from,read_to,watermark_text)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      nextLoanNo(), archiveId, u.id, mustStr(b.purpose, 300), mode, status, ts,
      auto ? ts : null, auto ? u.id : null, due || defaultDue(mode), readFrom, readTo, wm);
    if (auto) syncArchiveStatus(archiveId);
    log(u, auto ? '借阅登记' : '借阅申请', a.archive_code, `${mode}｜${mustStr(b.purpose, 100)}`, clientIp(req),
      { step: auto ? '借阅登记' : '借阅申请' });
    ok(res, { id: r.lastInsertRowid, status, read_from: readFrom, read_to: readTo, watermark_text: wm });
  });

  function defaultDue(mode) {
    const d = new Date();
    d.setDate(d.getDate() + (mode === '借出' ? 30 : 7));
    return d.toISOString().slice(0, 10);
  }

  route('POST', '/api/loans/:id/approve', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const l = q.get('SELECT * FROM loans WHERE id=?', id);
    if (!l) return fail(res, 404, '借阅记录不存在');
    if (l.status !== '待审批') return fail(res, 400, `该申请当前状态为「${l.status}」，无法审批`);
    const b = await readJson(req);
    const agree = b.approve !== false;
    const due = mustStr(b.due_date, 12).trim() || l.due_date || defaultDue(l.mode);
    // 批准时写入授权阅读时间窗与利用水印（§4.4.2 授权阅读时间 + 数字水印）
    const hours = Math.max(1, Math.min(8760, Number(b.read_hours)
      || Number(numbering.getSetting(q, 'loan.default_read_hours', '8')) || 8));
    const ts = nowIso();
    const readFrom = agree ? ts : '';
    const readTo = agree ? new Date(Date.now() + hours * 3600000).toISOString() : '';
    const loanArch = agree ? q.get('SELECT * FROM archives WHERE id=?', l.archive_id) : null;
    const loanUser = agree ? q.get('SELECT * FROM users WHERE id=?', l.user_id) : null;
    const wm = agree ? wmTextFor(loanUser, loanArch, '', l.purpose, ts) : '';
    q.run(`UPDATE loans SET status=?, approve_at=?, approve_by=?, approve_note=?, due_date=?,
             read_from=?, read_to=?, watermark_text=? WHERE id=?`,
      agree ? '已批准' : '已拒绝', ts, u.id, mustStr(b.note, 200), due, readFrom, readTo, wm, id);
    if (agree) syncArchiveStatus(l.archive_id);
    log(u, agree ? '批准借阅' : '拒绝借阅', l.loan_no,
      mustStr(b.note, 100) + (agree ? `｜授权阅读 ${hours} 小时` : ''), clientIp(req),
      { step: '借阅审批' });
    ok(res, { approved: agree, read_from: readFrom, read_to: readTo, watermark_text: wm });
  });

  route('POST', '/api/loans/:id/return', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const l = q.get('SELECT * FROM loans WHERE id=?', id);
    if (!l) return fail(res, 404, '借阅记录不存在');
    if (!['已批准', '逾期'].includes(l.status)) return fail(res, 400, `该记录状态为「${l.status}」，无法办理归还`);
    const b = await readJson(req);
    q.run(`UPDATE loans SET status='已归还', return_at=?, return_by=?, return_note=? WHERE id=?`,
      nowIso(), u.id, mustStr(b.note, 200), id);
    syncArchiveStatus(l.archive_id);
    log(u, '办理归还', l.loan_no, mustStr(b.note, 100), clientIp(req));
    ok(res, true);
  });

  route('DELETE', '/api/loans/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const l = q.get('SELECT * FROM loans WHERE id=?', id);
    if (!l) return fail(res, 404, '记录不存在');
    // 借阅记录是档案流转的凭证，已生效或已完成的记录必须留存备查
    if (['已批准', '逾期', '已归还'].includes(l.status)) {
      return fail(res, 400, `该记录已完成（${l.status}），属于借阅留痕，不能删除`);
    }
    q.run('DELETE FROM loans WHERE id=?', id);
    log(u, '删除借阅记录', l.loan_no, '', clientIp(req));
    ok(res, true);
  });

  // ===== 统计 =====
  route('GET', '/api/stats/overview', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    processLoanDue();
    const storage = dirStats(filesRoot);
    // 统计口径同样受密级约束。
    // 这不是"多此一举"：**数字本身就是涉密信息** ——「机密件 12 份」这句话
    // 泄露的内容不比看到那 12 份的题名少。所以按密级/门类/部门的统计、
    // "最近入库"与逾期清单，都必须在自己能看到的范围内统计。
    const sc = secretScope(u);
    const scSql = sc.sql;
    const scArgs = sc.params;
    // 供 LEFT JOIN ... ON 使用：条件写进 ON 而不是 WHERE，
    // 否则 LEFT JOIN 退化为 INNER JOIN，没有可见档案的门类会整个消失
    const scOn = scSql;
    const total = Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE 1=1${scSql}`, ...scArgs) || 0);
    const byType = q.all(`SELECT t.code, t.name, COUNT(a.id) AS count FROM archive_types t
                          LEFT JOIN archives a ON a.type_code=t.code${scOn}
                          GROUP BY t.code ORDER BY t.sort_no`, ...scArgs);
    const byStatus = q.all(`SELECT status AS name, COUNT(*) AS count FROM archives a
                            WHERE 1=1${scSql} GROUP BY status ORDER BY count DESC`, ...scArgs);
    const byYear = q.all(`SELECT year AS name, COUNT(*) AS count FROM archives a
                          WHERE 1=1${scSql} GROUP BY year ORDER BY year DESC LIMIT 12`, ...scArgs);
    const byRetention = q.all(`SELECT retention AS name, COUNT(*) AS count FROM archives a
                               WHERE 1=1${scSql} GROUP BY retention ORDER BY count DESC`, ...scArgs);
    const bySecret = q.all(`SELECT secret_level AS name, COUNT(*) AS count FROM archives a
                            WHERE 1=1${scSql} GROUP BY secret_level`, ...scArgs);
    const byCategory = q.all(`SELECT c.name, COUNT(a.id) AS count FROM categories c
                              LEFT JOIN archives a ON a.category_id=c.id${scOn}
                              WHERE c.level=1 GROUP BY c.id ORDER BY count DESC`, ...scArgs);
    const byDepartment = q.all(`SELECT CASE WHEN department='' THEN '未填写' ELSE department END AS name,
                                       COUNT(*) AS count
                                FROM archives a WHERE 1=1${scSql}
                                GROUP BY name ORDER BY count DESC LIMIT 10`, ...scArgs);
    const recent = q.all(`SELECT a.id,a.archive_code,a.title,a.type_code,a.status,a.created_at,u.display_name AS creator
                          FROM archives a LEFT JOIN users u ON u.id=a.created_by
                          WHERE 1=1${scSql}
                          ORDER BY a.id DESC LIMIT 8`, ...scArgs);
    const monthly = q.all(`SELECT substr(created_at,1,7) AS name, COUNT(*) AS count FROM archives a
                           WHERE 1=1${scSql} GROUP BY name ORDER BY name DESC LIMIT 12`, ...scArgs);
    const noFile = Number(q.scalar(`SELECT COUNT(*) FROM archives a
                                    WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.archive_id=a.id)${scSql}`, ...scArgs) || 0);
    // 全宗信息是否还是出厂占位值：工作台据此给一条"去改成贵单位的"提醒（v4.20.0）。
    // 只有能改系统设置的角色会用到它，但这里对所有人都返回 —— 免得前端还要按角色分支。
    const unitCode = String(numbering.getSetting(q, 'archive.unit_code', FACTORY_UNIT_CODE) || '');
    const unitName = String(numbering.getSetting(q, 'archive.unit_name', FACTORY_UNIT_NAME) || '');
    // 借阅统计与逾期清单也走可见范围（逾期清单里带着档号与题名）
    const loanCount = (cond) => Number(q.scalar(
      `SELECT COUNT(*) FROM loans l JOIN archives a ON a.id=l.archive_id
       WHERE ${cond}${scSql}`, ...scArgs) || 0);
    const loanStats = {
      pending: loanCount("l.status='待审批'"),
      active: loanCount("l.status IN ('已批准','逾期')"),
      overdue: loanCount("l.status='逾期'"),
      returned: loanCount("l.status='已归还'"),
    };
    ok(res, {
      total,
      fileCount: storage.files,
      storageBytes: storage.bytes,
      noFile,
      unitCode,
      unitName,
      unitIsFactory: (unitCode === FACTORY_UNIT_CODE && unitName === FACTORY_UNIT_NAME),
      userCount: Number(q.scalar("SELECT COUNT(*) FROM users WHERE status='active'") || 0),
      categoryCount: Number(q.scalar('SELECT COUNT(*) FROM categories') || 0),
      typeCount: Number(q.scalar('SELECT COUNT(*) FROM archive_types') || 0),
      byType, byStatus, byYear, byRetention, bySecret, byCategory, byDepartment, recent, monthly, loanStats,
      overdueLoans: q.all(`SELECT l.id,l.loan_no,l.due_date,a.archive_code,a.title,u.display_name AS user_name
                           FROM loans l LEFT JOIN archives a ON a.id=l.archive_id
                           LEFT JOIN users u ON u.id=l.user_id
                           WHERE l.status='逾期'${scSql} ORDER BY l.due_date LIMIT 10`, ...scArgs),
    });
  });

  // ===== 用户管理 =====
  route('GET', '/api/users', async (req, res) => {
    const u = requireCan(req, res, 'user:manage');
    if (!u) return;
    const list = q.all(`SELECT id,username,display_name,role,clearance,department,phone,email,status,must_change,created_at,
                              failed_count,locked_until,last_failed_at FROM users ORDER BY id`);
    // 回填「按角色默认」的密级上限与锁定状态，供界面直接显示，避免前端重复实现这套规则
    const listNow = Date.now();
    for (const r of list) {
      r.clearance_effective = r.clearance || policy.defaultClearance(r.role);
      r.clearance_is_default = !r.clearance;
      const ls = loginGuard.lockState(r, listNow);
      r.locked = ls.locked;
      r.locked_remaining_minutes = ls.remainingMinutes;
      r.failed_count = Number(r.failed_count || 0);
    }
    ok(res, {
      list,
      roleNames: ROLE_NAMES,
      roles: policy.ROLES,
      secretLevels: SECRET_LEVELS,
      defaultClearance: policy.defaultClearance,
      threeRoles: policy.THREE_ROLES,
      threeRolesEnabled: threeRolesOn(),
      passwordPolicy: loginGuard.policySummary(pwdPolicy()),
      // 找回通道现状（v4.30.9）：界面据此提示"登记了也发不出去"，
      // 免得管理员登记完手机号、员工去试却只收到 503。
      recovery: {
        smsConfigured: !!sms.configured,
        smsProvider: String((config.sms && config.sms.provider) || ''),
        smsLoginEnabled: String(numbering.getSetting(q, 'security.sms_login', '1')) !== '0',
        // 邮件通道（v4.31.0）：邮箱找回不需要花钱买短信，通常才是单位真能开起来的那条路
        emailConfigured: !!mail.configured,
        emailProvider: String((config.mail && config.mail.provider) || ''),
        emailLoginEnabled: String(numbering.getSetting(q, 'security.email_login', '1')) !== '0',
        emailFrom: mail.describe().from || '',
      },
      loginProtection: {
        maxFail: Number(numbering.getSetting(q, 'security.login_max_fail', '5')) || 0,
        lockMinutes: Number(numbering.getSetting(q, 'security.login_lock_minutes', '15')) || 0,
      },
    });
  });

  route('POST', '/api/users', async (req, res) => {
    const u = requireCan(req, res, 'user:manage');
    if (!u) return;
    const b = await readJson(req);
    const username = mustStr(b.username, 32).trim();
    if (!/^[A-Za-z0-9_.@-]{3,32}$/.test(username)) return fail(res, 400, '用户名需为 3-32 位字母、数字或 _ . @ -');
    if (q.scalar('SELECT id FROM users WHERE username=?', username)) return fail(res, 400, '用户名已存在');
    const pwd = String(b.password || '');
    // 口令策略统一走 lib/login-guard：长度、弱口令清单、与用户名关系、字符类型
    const pwdChk = validateNewPassword(pwd, username);
    if (!pwdChk.ok) return fail(res, 400, '初始口令不合规：' + pwdChk.error);
    const role = policy.ROLES.includes(b.role) ? b.role : 'reader';
    // 三员分立校验：同一账号不得兼任三员中的多个（本系统为单角色模型，故此处只校验一次）
    if (threeRolesOn()) {
      const t = policy.checkThreeRoles(role);
      if (!t.ok) return fail(res, 400, t.reason);
    }
    // 密级上限：未指定则按角色默认；显式指定则必须合法
    let clearance = '';
    if (b.clearance !== undefined && b.clearance !== null && String(b.clearance) !== '') {
      const want = String(b.clearance).trim();
      if (!SECRET_LEVELS.includes(want)) return fail(res, 400, `密级上限不合法，可选：${SECRET_LEVELS.join(' / ')}`);
      clearance = want;
    }
    // 三员分立：建账号是系统管理员的职责，「定密级」是系统安全保密员的职责，两者分离
    if (clearance && !policy.can(u, 'security:manage')) {
      return fail(res, 403, '指定密级上限需要「系统安全保密员」权限（三员分立要求定密与建号分离）', 'FORBIDDEN');
    }
    // 手机号（v4.27.0）：有值就必须是合法手机号，且**全库唯一**。
    // 为什么唯一性放在写入路径而不是建唯一索引：存量库里可能已经有重复号码，
    // 建唯一索引会让升级在"程序起不来"那一步失败，最难查；写路径拒绝既保住升级，
    // 又把脏数据挡在门外 —— 而"一号两人"的后果是找回口令重置到别人账上。
    const rawPhone = mustStr(b.phone, 30).trim();
    const phone = rawPhone ? smsLib.normalizePhone(rawPhone) : '';
    if (rawPhone && !phone) return fail(res, 400, '手机号格式不正确：请填写 11 位手机号（找回口令要用）');
    if (phone) {
      const dup = q.get('SELECT id,username FROM users WHERE phone=?', phone);
      if (dup) return fail(res, 400, `该手机号已登记在账号「${dup.username}」上，一个号码只能对应一个账号`);
    }
    const { salt, hash } = hashPassword(pwd);
    // 邮箱（v4.30.9）：可留空；填了就必须像邮箱。
    // 查重（v4.31.0）：口径是"每人一个邮箱、用各自邮箱找回"——同一邮箱挂两个账号时，
    // 找回流程只能拒绝服务（见 userByEmail 的 conflict 分支），不如在这里挡掉。
    const rawEmail = mustStr(b.email, 120).trim();
    const email = rawEmail ? normalizeEmail(rawEmail) : '';
    if (rawEmail && !email) return fail(res, 400, '邮箱格式不正确：请填写形如 name@example.com 的地址（找回口令要用）');
    if (email) {
      const dupMail = q.get('SELECT id,username FROM users WHERE email=?', email);
      if (dupMail) return fail(res, 400, `该邮箱已登记在账号「${dupMail.username}」上，一个邮箱只能对应一个账号`);
    }
    const r = q.run(`INSERT INTO users(username,display_name,password_hash,password_salt,role,clearance,department,phone,email,status,must_change,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?, 'active',1,?)`,
      username, mustStr(b.display_name, 40) || username, hash, salt, role, clearance,
      mustStr(b.department, 60), phone, email, nowIso());
    log(u, '新增用户', username,
      `${ROLE_NAMES[role]}｜密级上限=${clearance || policy.defaultClearance(role) + '(按角色默认)'}`, clientIp(req));
    ok(res, { id: r.lastInsertRowid, clearance_effective: clearance || policy.defaultClearance(role) });
  });

  route('PUT', '/api/users/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    // 三员分立下本接口被两类角色使用，但**能改的字段不同**：
    //   系统管理员    —— 账号信息与角色（建号、赋角色、停用）
    //   系统安全保密员 —— 只有密级上限（定密）
    // 所以不能用 requireCan('user:manage') 一刀切：那样安全保密员连定密都做不了，
    // 而"定密"恰恰是它存在的理由。职责隔离必须落到字段级。
    const canManageUser = policy.can(u, 'user:manage');
    const canManageSecurity = policy.can(u, 'security:manage');
    if (!canManageUser && !canManageSecurity) {
      return fail(res, 403, '没有修改用户的权限', 'FORBIDDEN');
    }
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM users WHERE id=?', id);
    if (!cur) return fail(res, 404, '用户不存在');
    const b = await readJson(req);
    const role = policy.ROLES.includes(b.role) ? b.role : cur.role;

    // ---- 账号信息与角色：系统管理员的职责 ----
    const touchesProfile = ['display_name', 'department', 'phone', 'email', 'status', 'role']
      .some((k) => b[k] !== undefined && b[k] !== null && String(b[k]) !== '');
    if (touchesProfile && !canManageUser) {
      return fail(res, 403, '修改账号信息或角色需要「系统管理员」权限（三员分立要求建号与定密分离）', 'FORBIDDEN');
    }
    if (cur.role === 'admin' && role !== 'admin') {
      const admins = q.scalar("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active'");
      if (admins <= 1) return fail(res, 400, '系统必须保留至少一个管理员账号');
    }
    if (role !== cur.role && threeRolesOn()) {
      const t = policy.checkThreeRoles(role);
      if (!t.ok) return fail(res, 400, t.reason);
    }
    // ---- 密级上限：安全保密员的职责，系统管理员不能自行提权 ----
    let clearance = cur.clearance;
    if (b.clearance !== undefined && b.clearance !== null) {
      const want = String(b.clearance).trim();
      if (want === '') clearance = '';
      else if (!SECRET_LEVELS.includes(want)) return fail(res, 400, `密级上限不合法，可选：${SECRET_LEVELS.join(' / ')}`);
      else clearance = want;
    }
    if (String(clearance || '') !== String(cur.clearance || '') && !canManageSecurity) {
      return fail(res, 403, '调整密级上限需要「系统安全保密员」权限（三员分立要求定密与运维分离）', 'FORBIDDEN');
    }
    // 手机号（v4.27.0）：未传就保持原值 —— 否则一次"只改部门"的保存会把号码清空，
    // 而这个账号从此再也走不了手机号找回，且界面不会提示任何异常。
    const rawPhone = (b.phone === undefined || b.phone === null)
      ? String(cur.phone || '') : String(b.phone).trim();
    const phone = rawPhone ? smsLib.normalizePhone(rawPhone) : '';
    if (rawPhone && !phone) return fail(res, 400, '手机号格式不正确：请填写 11 位手机号（找回口令要用）');
    if (phone) {
      const dup = q.get('SELECT id,username FROM users WHERE phone=? AND id<>?', phone, id);
      if (dup) return fail(res, 400, `该手机号已登记在账号「${dup.username}」上，一个号码只能对应一个账号`);
    }
    // 邮箱（v4.30.9）：未传就保持原值（同手机号，避免"只改部门"把邮箱清空）
    const rawEmail = (b.email === undefined || b.email === null)
      ? String(cur.email || '') : String(b.email).trim();
    const email = rawEmail ? normalizeEmail(rawEmail) : '';
    if (rawEmail && !email) return fail(res, 400, '邮箱格式不正确：请填写形如 name@example.com 的地址（找回口令要用）');
    if (email) {
      const dupMail = q.get('SELECT id,username FROM users WHERE email=? AND id<>?', email, id);
      if (dupMail) return fail(res, 400, `该邮箱已登记在账号「${dupMail.username}」上，一个邮箱只能对应一个账号`);
    }
    q.run('UPDATE users SET display_name=?, role=?, clearance=?, department=?, phone=?, email=?, status=? WHERE id=?',
      (b.display_name === undefined || b.display_name === null)
        ? cur.display_name : (mustStr(b.display_name, 40) || cur.display_name),
      role, clearance,
      (b.department === undefined || b.department === null)
        ? cur.department : mustStr(b.department, 60),
      phone, email,
      (b.status === undefined || b.status === null)
        ? cur.status : (b.status === 'disabled' ? 'disabled' : 'active'),
      id);
    if (b.status === 'disabled') sessions.destroyByUser(id);
    log(u, '修改用户', cur.username,
      `角色=${ROLE_NAMES[role]}｜密级上限=${clearance || policy.defaultClearance(role) + '(按角色默认)'}`, clientIp(req));
    ok(res, true);
  });

  route('POST', '/api/users/:id/reset-password', async (req, res, params) => {
    const u = requireCan(req, res, 'user:manage');
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM users WHERE id=?', id);
    if (!cur) return fail(res, 404, '用户不存在');
    const b = await readJson(req);
    const pwd = String(b.password || '');
    const pwdChk = validateNewPassword(pwd, cur.username);
    if (!pwdChk.ok) return fail(res, 400, '新口令不合规：' + pwdChk.error);
    const { salt, hash } = hashPassword(pwd);
    // 重置口令同时解除锁定并清零失败计数：管理员重置口令的常见动机就是"用户被锁了"
    q.run("UPDATE users SET password_hash=?, password_salt=?, must_change=1, failed_count=0, locked_until='' WHERE id=?",
      hash, salt, id);
    sessions.destroyByUser(id);
    log(u, '重置密码', cur.username, '已同时解除账号锁定', clientIp(req), { step: '口令重置' });
    ok(res, true);
  });

  /** 手动解锁账号（管理员/安全保密员）：口令重置与排障时都要用 */
  route('POST', '/api/users/:id/unlock', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!policy.can(u, 'user:manage') && !policy.can(u, 'security:manage')) {
      return fail(res, 403, '没有解锁账号的权限', 'FORBIDDEN');
    }
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM users WHERE id=?', id);
    if (!cur) return fail(res, 404, '用户不存在');
    q.run("UPDATE users SET failed_count=0, locked_until='', last_failed_at='' WHERE id=?", id);
    log(u, '解锁账号', cur.username, `原失败次数 ${cur.failed_count || 0}`, clientIp(req),
      { step: '账号解锁' });
    ok(res, true);
  });

  route('DELETE', '/api/users/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'user:manage');
    if (!u) return;
    const id = Number(params.id);
    if (id === u.id) return fail(res, 400, '不能删除自己的账号');
    const cur = q.get('SELECT * FROM users WHERE id=?', id);
    if (!cur) return fail(res, 404, '用户不存在');

    // 引用检查必须**覆盖所有引用 users 的表**。
    // 原实现只查了 archives 与 loans 两张表，于是：
    //   用户只要有盘点/鉴定/销毁/移交/导入等记录，就会绕过"降级为停用"这条保护，
    //   直接执行 DELETE 并撞上外键约束（PRAGMA foreign_keys=ON），返回 500。
    //   也就是说，文档里承诺的"有业务记录自动降级为停用"在多数情况下是失效的。
    const refTables = [
      ['archives', 'created_by'], ['loans', 'user_id'], ['files', 'uploaded_by'],
      ['logs', 'user_id'], ['archive_boxes', 'created_by'], ['stock_checks', 'operator_id'],
      ['appraisals', 'appraiser_id'], ['destructions', 'applicant_id'],
      ['transfers', 'applicant_id'], ['import_batches', 'operator_id'],
    ];
    const used = [];
    let refs = 0;
    for (const [tbl, col] of refTables) {
      try {
        const c = Number(q.scalar(`SELECT COUNT(*) FROM ${tbl} WHERE ${col}=?`, id) || 0);
        if (c) { refs += c; used.push(`${tbl}.${col}=${c}`); }
      } catch (_) { /* 该表/列在本版本不存在，忽略 */ }
    }
    if (refs) {
      q.run("UPDATE users SET status='disabled' WHERE id=?", id);
      sessions.destroyByUser(id);
      log(u, '停用用户', cur.username, `存在 ${refs} 条关联记录，改为停用（${used.join('，')}）`, clientIp(req));
      return ok(res, {
        disabled: true,
        reason: '该用户存在业务记录，已改为停用而非删除',
        references: used,
      });
    }
    // 兜底：即使上面的清单漏了某张表，外键报错也不能变成 500
    try {
      q.run('DELETE FROM users WHERE id=?', id);
    } catch (e) {
      q.run("UPDATE users SET status='disabled' WHERE id=?", id);
      sessions.destroyByUser(id);
      log(u, '停用用户', cur.username, `删除失败（${e.message}），已改为停用`, clientIp(req),
        { result: '失败', category: 'system', step: '用户删除' });
      return ok(res, {
        disabled: true,
        reason: '该用户仍被其它数据引用，已改为停用而非删除',
        error: e.message,
      });
    }
    log(u, '删除用户', cur.username, '', clientIp(req));
    ok(res, true);
  });

  // ===== 安全合规状态 =====
  /**
   * 三员分立与密级管控的落实情况体检。
   *
   * 为什么需要这个接口：《电子档案管理系统基本功能规定》（档办发〔2017〕3号）第四十一条
   * 要求"三员分立"并按功能和数据授权。但"三个角色建好了"不等于"落实了"——
   * 还需要知道三员是否配齐、是否由不同账号担任、有多少账号的密级上限还停在默认值。
   * 把这些做成可查询的状态，管理员才能自查，检查时也拿得出凭据。
   */
  route('GET', '/api/security/status', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!policy.can(u, 'security:manage') && !policy.can(u, 'audit:view')) {
      return fail(res, 403, '仅系统安全保密员、安全审计员或管理员可查看安全合规状态', 'FORBIDDEN');
    }
    const users = q.all('SELECT id,username,display_name,role,clearance,status,failed_count,locked_until,last_failed_at FROM users');
    const active = users.filter((x) => x.status === 'active');
    const holders = {};
    for (const r of policy.THREE_ROLES) {
      holders[r] = active.filter((x) => x.role === r).map((x) => x.username);
    }
    const staffedCount = policy.THREE_ROLES.filter((r) => holders[r].length > 0).length;
    const distinctAccounts = new Set(policy.THREE_ROLES.flatMap((r) => holders[r])).size;

    const warnings = [];
    if (staffedCount < 3) {
      const missing = policy.THREE_ROLES.filter((r) => holders[r].length === 0).map((r) => ROLE_NAMES[r]);
      warnings.push(`三员尚未配齐：${missing.join('、')} 暂无账号`);
    }
    if (distinctAccounts < staffedCount) warnings.push('存在同一账号兼任多个三员角色，违反三员分立');
    const stillDefault = users.filter((x) => !x.clearance).length;
    if (stillDefault) warnings.push(`${stillDefault} 个账号的密级上限仍为「按角色默认」，建议按岗位逐一核定`);
    const adminCount = active.filter((x) => x.role === 'admin').length;
    if (adminCount && threeRolesOn()) {
      warnings.push(`仍有 ${adminCount} 个超级管理员账号；启用三员分立后建议逐步收敛为三员账号`);
    }
    if (!enforceSecret()) warnings.push('密级管控（security.enforce_secret）已关闭，所有登录用户可见全部档案');

    // 登录防护与口令状况
    const nowMs = Date.now();
    const locked = users.filter((x) => loginGuard.lockState(x, nowMs).locked);
    const weakAudit = weakPasswordAuditCached();
    const loginProtection = {
      maxFail: Number(numbering.getSetting(q, 'security.login_max_fail', '5')) || 0,
      lockMinutes: Number(numbering.getSetting(q, 'security.login_lock_minutes', '15')) || 0,
      ratePerMinute: Number(numbering.getSetting(q, 'security.login_rate_per_minute', '20')) || 0,
      csrfOriginCheck: String(numbering.getSetting(q, 'security.csrf_origin_check', '1')) === '1',
      passwordPolicy: loginGuard.policySummary(pwdPolicy()),
      recentFailures24h: Number(q.scalar(
        'SELECT COUNT(*) FROM login_attempts WHERE success=0 AND at>=?',
        new Date(nowMs - 86400000).toISOString()) || 0),
      lockedUsers: locked.map((x) => ({
        id: x.id,
        username: x.username,
        until: x.locked_until,
        remainingMinutes: loginGuard.lockState(x, nowMs).remainingMinutes,
        failedCount: Number(x.failed_count || 0),
      })),
      weakPasswords: weakAudit,
    };
    if (locked.length) {
      warnings.push(`有 ${locked.length} 个账号处于锁定状态：${locked.map((x) => x.username).join('、')}`
        + '（可在用户管理中解锁，或重置其口令）');
    }
    if (weakAudit && weakAudit.weak && weakAudit.weak.length) {
      warnings.push(`口令审计发现 ${weakAudit.weak.length} 个账号正在使用常见弱口令：`
        + `${weakAudit.weak.map((x) => x.username).join('、')}，请立即要求其修改`);
    }
    if (!loginProtection.maxFail) {
      warnings.push('登录失败锁定已关闭（security.login_max_fail=0），建议开启以抵御口令爆破');
    }
    if (!loginProtection.csrfOriginCheck) {
      warnings.push('Origin 校验已关闭（security.csrf_origin_check=0），CSRF 防护仅剩 Cookie 的 SameSite=Lax');
    }

    // 审计日志链与保留期：也是合规要点，一并放进安全体检
    let auditInfo = null;
    try {
      const chain = verifyLogChain();
      auditInfo = {
        total: chain.total,
        chainIntact: chain.ok,
        checked: chain.checked,
        algorithm: 'SHA-256 链式哈希',
        firstAt: chain.firstAt,
        lastAt: chain.lastAt,
        broken: chain.broken,
        retention: logRetentionPolicy(),
        exportUrl: '/api/logs/export.csv',
        verifyUrl: '/api/logs/verify',
      };
      if (!chain.ok) {
        warnings.push(`审计日志链在 id=${chain.broken.id} 处断开：${chain.broken.reason}。请立即封存数据并排查`);
      }
      for (const w of auditInfo.retention.warnings) warnings.push('审计日志保留期：' + w);
    } catch (e) {
      warnings.push('审计日志链校验失败：' + e.message);
    }

    ok(res, {
      enforceSecret: enforceSecret(),
      threeRolesEnabled: threeRolesOn(),
      threeRoles: policy.THREE_ROLES,
      holders,
      staffed: staffedCount === 3,
      staffedCount,
      distinctAccounts,
      audit: auditInfo,
      loginProtection,
      warnings,
      users: users.map((x) => ({
        id: x.id,
        username: x.username,
        display_name: x.display_name,
        role: x.role,
        role_name: ROLE_NAMES[x.role] || x.role,
        clearance: x.clearance || '',
        clearance_effective: x.clearance || policy.defaultClearance(x.role),
        clearance_is_default: !x.clearance,
        status: x.status,
        failed_count: Number(x.failed_count || 0),
        locked: loginGuard.lockState(x, nowMs).locked,
        locked_until: x.locked_until || '',
      })),
    });
  });

  /**
   * 手动触发弱口令审计（系统安全保密员/管理员）。
   * 启动时会在后台自动跑一次，这个接口用于"改完口令后立刻复查"。
   */
  route('POST', '/api/security/audit-passwords', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!policy.can(u, 'security:manage')) {
      return fail(res, 403, '需要「系统安全保密员」权限（三员分立：定密与口令安全归安全保密员）', 'FORBIDDEN');
    }
    const r = auditWeakPasswords();
    log(u, '执行口令审计', `${r ? r.checked : 0} 个账号`,
      r && r.weak && r.weak.length ? `发现弱口令 ${r.weak.length} 个` : '未发现弱口令',
      clientIp(req), { category: 'security', step: '口令审计' });
    ok(res, r || { checked: 0, weak: [], error: '审计未完成，请查看服务端日志' });
  });

  // ---------- 四性检测 ----------

  /** 生成检测单号：JC<年月日>-<三位流水> */
  function nextDetectionNo(d = new Date()) {
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    let n = Number(q.scalar('SELECT COUNT(*) FROM detections WHERE detection_no LIKE ?', `JC${day}-%`) || 0);
    for (let i = 0; i < 999; i++) {
      n += 1;
      const no = `JC${day}-${String(n).padStart(3, '0')}`;
      if (!q.scalar('SELECT id FROM detections WHERE detection_no=?', no)) return no;
    }
    return `JC${day}-${Date.now().toString().slice(-6)}`;
  }

  /** 存储介质剩余空间（字节）。取不到返回 0，对应检查项会自行跳过而不是误判不合格。 */
  function diskFreeBytes() {
    try {
      const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');
      const st = fs.statfsSync(dataDir);
      return Number(st.bavail) * Number(st.bsize);
    } catch (_) { return 0; }
  }

  /**
   * 组装四性检测上下文。
   *
   * 检测引擎刻意**不直接访问数据库与文件系统**，全部由这里注入：
   * 好处是引擎可以离线单测，而且杜绝了"检测过程顺手改了数据"——
   * 检测器一旦能写数据，"检测结论"就不再可信。
   */
  function buildDetectionCtx(archiveId) {
    const a = q.get('SELECT * FROM archives WHERE id=?', archiveId);
    if (!a) return null;
    const files = q.all('SELECT * FROM files WHERE archive_id=? ORDER BY sort_no, id', archiveId);
    const fileTexts = q.all('SELECT * FROM file_text WHERE archive_id=?', archiveId);
    const lastOk = q.get(`SELECT created_at FROM detections
                          WHERE archive_id=? AND environment='archive' AND qualified=1
                          ORDER BY id DESC LIMIT 1`, archiveId);
    return {
      archive: a,
      files,
      fileTexts,
      hashOf: (f) => {
        try {
          const abs = absPath(filesRoot, f.rel_path);
          if (!fs.existsSync(abs)) return null;
          return sha256(fs.readFileSync(abs));
        } catch (_) { return null; }
      },
      fileExists: (f) => {
        try { return fs.existsSync(absPath(filesRoot, f.rel_path)); } catch (_) { return false; }
      },
      sizeOf: (f) => {
        try {
          const abs = absPath(filesRoot, f.rel_path);
          return fs.existsSync(abs) ? fs.statSync(abs).size : null;
        } catch (_) { return null; }
      },
      diskFreeBytes: diskFreeBytes(),
      settings: { secretLevels: SECRET_LEVELS },
      lastDetectionAt: lastOk ? lastOk.created_at : '',
      archiveDetectionOk: !!lastOk,
      now: Date.now(),
    };
  }

  /**
   * 执行一次四性检测并落库。
   * 落库而不是只打印，是因为标准要求"检测合格后方可移交/接收"——
   * 必须有可追溯的凭据，否则"检测过"这件事本身无法举证。
   */
  function runAndSaveDetection(user, archiveId, environment, source) {
    const ctx = buildDetectionCtx(archiveId);
    if (!ctx) throw Object.assign(new Error('档案不存在'), { statusCode: 404 });
    const r = detection.runDetection(ctx, environment);
    const no = nextDetectionNo();
    const s = r.summary;
    const conclusion = s.qualified
      ? `合格（${s.passed}/${s.total} 项通过${s.warns ? `，另有 ${s.warns} 项提示` : ''}）`
      : `不合格（${s.errors} 项不合格、${s.warns} 项提示）`;
    let id = 0;
    q.tx(() => {
      const ins = q.run(`INSERT INTO detections(detection_no,environment,archive_id,scope,total,passed,failed,
                         errors,warns,qualified,conclusion,source,operator_id,operator,created_at)
                         VALUES(?,?,?,'单件',?,?,?,?,?,?,?,?,?,?,?)`,
        no, environment, archiveId, s.total, s.passed, s.failed, s.errors, s.warns,
        s.qualified ? 1 : 0, conclusion, source || '手工',
        user ? user.id : null, user ? user.username : '', nowIso());
      id = ins.lastInsertRowid;
      for (const it of r.items) {
        q.run(`INSERT INTO detection_items(detection_id,code,dimension,severity,title,basis,pass,detail)
               VALUES(?,?,?,?,?,?,?,?)`,
          id, it.code, it.dimension, it.severity, it.title, it.basis, it.pass ? 1 : 0, it.detail);
      }
    });
    return { id, detection_no: no, archive_id: archiveId, environment, conclusion, qualified: s.qualified, result: r };
  }

  /** 单件档案在归档环节是否已有合格记录（移交闸门用） */
  function hasPassingArchiveDetection(archiveId) {
    return !!q.scalar(`SELECT id FROM detections
                       WHERE archive_id=? AND environment='archive' AND qualified=1 LIMIT 1`, archiveId);
  }

  const ENV_LABELS = { archive: '归档环节', transfer: '移交与接收环节', preservation: '长期保存环节' };

  /**
   * 执行四性检测（可批量）。
   * 环境决定跑哪一组检查项：归档 / 移交与接收 / 长期保存。
   */
  route('POST', '/api/detections', async (req, res) => {
    const u = requireCan(req, res, 'detection:run');
    if (!u) return;
    const b = await readJson(req);
    const env = detection.ENVIRONMENTS.some((e) => e.code === b.environment) ? b.environment : 'archive';
    let ids = Array.isArray(b.archive_ids) ? b.archive_ids.map(Number).filter(Boolean)
      : (Number(b.archive_id) ? [Number(b.archive_id)] : []);
    if (!ids.length) return fail(res, 400, '请指定要检测的档案');
    // 密级约束：看不到的档案不允许检测（检测报告里会带题名与档号）
    const sc = secretScope(u);
    const holes = ids.map(() => '?').join(',');
    const allow = new Set(
      q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${sc.sql}`, ...ids, ...sc.params)
        .map((r) => Number(r.id)),
    );
    const before = ids.length;
    ids = ids.filter((id) => allow.has(id));
    if (ids.length !== before) {
      log(u, '四性检测跳过无权档案', `${before - ids.length} 件`, '超出账号密级上限', clientIp(req),
        { result: '拒绝', category: 'security', step: '密级鉴别' });
    }
    if (!ids.length) return fail(res, 403, '所选档案均超出你的密级权限范围');

    const results = [];
    for (const id of ids) {
      try {
        results.push(runAndSaveDetection(u, id, env, mustStr(b.source, 20) || '手工'));
      } catch (e) {
        results.push({ archive_id: id, error: e.message });
      }
    }
    const qualified = results.filter((r) => r.qualified).length;
    const unqualified = results.filter((r) => r.conclusion && !r.qualified).length;
    log(u, '执行四性检测', ENV_LABELS[env] || env,
      `${results.length} 件，合格 ${qualified} / 不合格 ${unqualified}`, clientIp(req),
      { category: 'detection', step: '四性检测' });
    ok(res, {
      environment: env,
      environmentLabel: ENV_LABELS[env] || env,
      summary: { archives: results.length, qualified, unqualified },
      results,
    });
  });

  /** 检测记录列表 */
  route('GET', '/api/detections', async (req, res, params, url) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const sp = url.searchParams;
    const page = Math.max(1, numOr(sp.get('page'), 1));
    const size = Math.min(100, Math.max(1, numOr(sp.get('size'), 20)));
    const where = ['1=1'];
    const args = [];
    if (sp.get('environment')) { where.push('d.environment=?'); args.push(sp.get('environment')); }
    if (sp.get('archive_id')) { where.push('d.archive_id=?'); args.push(Number(sp.get('archive_id'))); }
    if (sp.get('qualified') === '0' || sp.get('qualified') === '1') {
      where.push('d.qualified=?'); args.push(Number(sp.get('qualified')));
    }
    const sc = secretScope(u, 'a.secret_level');
    const w = ' WHERE ' + where.join(' AND ') + sc.sql;
    const total = Number(q.scalar(`SELECT COUNT(*) FROM detections d
                                   LEFT JOIN archives a ON a.id=d.archive_id ${w}`, ...args, ...sc.params) || 0);
    const list = q.all(`SELECT d.*, a.archive_code, a.title, a.secret_level
                        FROM detections d LEFT JOIN archives a ON a.id=d.archive_id
                        ${w} ORDER BY d.id DESC LIMIT ? OFFSET ?`,
      ...args, ...sc.params, size, (page - 1) * size);
    ok(res, {
      list, total, page, size, pages: Math.max(1, Math.ceil(total / size)),
      environments: detection.ENVIRONMENTS, dimensions: detection.DIMENSIONS,
      severityLabels: detection.SEVERITY_LABELS,
    });
  });

  /** 检测覆盖率与整体状况 */
  route('GET', '/api/detections/stats', async (req, res) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const sc = secretScope(u);
    const yearlyDays = Number(numbering.getSetting(q, 'detection.yearly_days', '365')) || 365;
    const since = new Date(Date.now() - yearlyDays * 86400000).toISOString();
    const total = Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE 1=1${sc.sql}`, ...sc.params) || 0);
    const detected = Number(q.scalar(
      `SELECT COUNT(DISTINCT d.archive_id) FROM detections d JOIN archives a ON a.id=d.archive_id
       WHERE d.environment='archive' AND d.qualified=1${sc.sql}`, ...sc.params) || 0);
    const overdue = Number(q.scalar(
      `SELECT COUNT(*) FROM archives a WHERE 1=1${sc.sql} AND NOT EXISTS (
         SELECT 1 FROM detections d WHERE d.archive_id=a.id AND d.environment='archive'
           AND d.qualified=1 AND d.created_at >= ?)`, ...sc.params, since) || 0);
    ok(res, {
      total, detected, undetected: Math.max(0, total - detected), overdue, yearlyDays,
      coverage: total ? Math.round((detected / total) * 100) : 100,
      byEnvironment: q.all('SELECT environment, COUNT(*) AS count, SUM(qualified) AS qualified FROM detections GROUP BY environment'),
      recent: q.all(`SELECT d.*, a.archive_code, a.title FROM detections d
                     LEFT JOIN archives a ON a.id=d.archive_id
                     WHERE 1=1${sc.sql} ORDER BY d.id DESC LIMIT 10`, ...sc.params),
      environments: detection.ENVIRONMENTS, dimensions: detection.DIMENSIONS,
      checks: detection.CHECKS.map((c) => ({
        code: c.code, dimension: c.dimension, severity: c.severity, title: c.title,
        environments: c.environments, basis: c.basis,
      })),
    });
  });

  /** 待检测清单：从未通过归档检测，或距上次通过已超过设定天数（实现见 dueDetectionList） */
  route('GET', '/api/detections/due', async (req, res, params, url) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const r = dueDetectionList(u, Number(url.searchParams.get('limit')) || 500);
    ok(res, { list: r.list, total: r.list.length, yearlyDays: r.yearlyDays });
  });

  /** 检测详情（含逐项结果） */
  route('GET', '/api/detections/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const d = q.get('SELECT * FROM detections WHERE id=?', Number(params.id));
    if (!d) return fail(res, 404, '检测记录不存在');
    let archive = null;
    if (d.archive_id) {
      archive = q.get('SELECT * FROM archives WHERE id=?', d.archive_id);
      // 按档案密级判定可见性：不可见时同样回 404，不泄露"这份档案做过检测"
      if (archive && !policy.canSeeSecret(u, archive.secret_level, enforceSecret())) {
        log(u, '越权查看检测报告被拒', String(archive.archive_code || d.archive_id), '', clientIp(req),
          { result: '拒绝', category: 'security', step: '密级鉴别' });
        return fail(res, 404, '检测记录不存在');
      }
    }
    d.items = q.all('SELECT * FROM detection_items WHERE detection_id=? ORDER BY id', d.id);
    ok(res, {
      detection: d,
      archive: archive ? { id: archive.id, archive_code: archive.archive_code, title: archive.title, secret_level: archive.secret_level } : null,
      environmentLabel: ENV_LABELS[d.environment] || d.environment,
      dimensions: detection.DIMENSIONS,
      severityLabels: detection.SEVERITY_LABELS,
    });
  });

  /** 打印四性检测报告（含责任人确认栏 —— 《电子档案管理办法》第十八条要求由责任人确认） */
  route('GET', '/api/detections/:id/print', async (req, res, params, url) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const d = q.get('SELECT * FROM detections WHERE id=?', Number(params.id));
    if (!d) return fail(res, 404, '检测记录不存在');
    let archive = null;
    if (d.archive_id) {
      archive = q.get('SELECT * FROM archives WHERE id=?', d.archive_id);
      if (archive && !policy.canSeeSecret(u, archive.secret_level, enforceSecret())) {
        return fail(res, 404, '检测记录不存在');
      }
    }
    const items = q.all('SELECT * FROM detection_items WHERE detection_id=? ORDER BY id', d.id);
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const rows = items.map((it, i) => `<tr>
      <td>${i + 1}</td><td class="mono">${esc(it.code)}</td><td>${esc(it.dimension)}</td>
      <td>${esc(it.title)}</td>
      <td style="text-align:center">${it.pass ? '通过' : (it.severity === 'error' ? '<b>不合格</b>' : '提示')}</td>
      <td>${esc(it.detail)}</td></tr>`).join('');
    const html = printShell(`四性检测报告 ${esc(d.detection_no)}`, `
      <div class="print-head"><h1>电 子 档 案 四 性 检 测 报 告</h1><div class="meta">
        全宗名称：${esc(unit)}　检测单号：${esc(d.detection_no)}　检测环节：${esc(ENV_LABELS[d.environment] || d.environment)}<br>
        ${archive ? `档号：${esc(archive.archive_number || archive.archive_code)}　题名：${esc(archive.title)}　密级：${esc(archive.secret_level)}<br>` : ''}
        检测时间：${esc(d.created_at)}　检测人：${esc(d.operator)}　数据来源：${esc(d.source)}</div></div>
      <div class="rep-block"><div class="rep-title">检测结论</div>
        <table class="print-table"><tbody>
          <tr><td style="width:160px">结论</td><td><b>${esc(d.conclusion)}</b></td></tr>
          <tr><td>检测项总数</td><td>${d.total} 项（通过 ${d.passed}　不合格 ${d.errors}　提示 ${d.warns}）</td></tr>
          <tr><td>依据</td><td>DA/T 70—2018（三环节×四性框架）；DA/T 92—2022 §9.4；《电子档案管理办法》第十八/二十一/二十二/二十八条</td></tr>
        </tbody></table></div>
      <div class="rep-block"><div class="rep-title">逐项检测结果</div>
        <table class="print-table"><thead><tr>
          <th style="width:36px">序号</th><th style="width:80px">项号</th><th style="width:70px">四性</th>
          <th>检查项</th><th style="width:70px">结果</th><th style="width:30%">说明</th></tr></thead>
        <tbody>${rows}</tbody></table></div>
      <div class="sign-row">
        <div>检测人：____________</div>
        <div>复核人：____________</div>
        <div>责任人确认：____________</div>
        <div>日期：______年____月____日</div>
      </div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  // ---------- 元数据（DA/T 46）----------

  /**
   * 允许通过元数据接口**写回档案表**的描述性元素。
   * 其它可编辑元素（如"机构人员名称"由责任者+部门合成）没有 1:1 映射，
   * 一律在档案著录表单里维护，避免两处写同一份数据而互相覆盖。
   */
  const META_WRITE_THROUGH = { M08: 'abstract', M09: 'title', M10: 'archive_date', M11: 'secret_level' };

  /** 组装元数据捕获上下文（只读） */
  function buildMetadataCtx(archiveId) {
    const a = q.get('SELECT * FROM archives WHERE id=?', archiveId);
    if (!a) return null;
    const box = a.box_id ? q.get('SELECT box_code FROM archive_boxes WHERE id=?', a.box_id) : null;
    const files = q.all(`SELECT id, original_name, stored_name, mime, size, kind, sha256
                         FROM files WHERE archive_id=? ORDER BY sort_no, id`, archiveId);
    return {
      archive: Object.assign({}, a, { box_code: box ? box.box_code : '' }),
      files,
      settings: {
        unitName: q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位',
        unitCode: q.scalar("SELECT value FROM settings WHERE key='archive.unit_code'") || '',
      },
    };
  }

  /** 读取某档案的元数据值 */
  function metadataValues(archiveId) {
    const out = {};
    for (const r of q.all('SELECT element_code, value FROM archive_metadata WHERE archive_id=?', archiveId)) {
      out[r.element_code] = r.value;
    }
    return out;
  }

  /** 记一条元数据变更留痕（含被拒绝的修改尝试） */
  function logMetadataChange(archiveId, elementCode, oldValue, newValue, action, reason, user) {
    try {
      q.run(`INSERT INTO metadata_changes(archive_id,element_code,old_value,new_value,action,reason,operator_id,operator,at)
             VALUES(?,?,?,?,?,?,?,?,?)`,
        archiveId, elementCode, String(oldValue == null ? '' : oldValue), String(newValue == null ? '' : newValue),
        action, reason || '', user ? user.id : null, user ? user.username : 'system', nowIso());
    } catch (e) { console.warn('[元数据] 变更留痕失败：' + e.message); }
  }

  /**
   * 自动捕获并保存元数据。
   *
   * 核心规则：**带捕获函数的元素一律以系统数据为准**。
   * 背景 / 结构 / 管理过程元数据因此天然不可篡改 —— 不是靠"界面上不给编辑框"，
   * 而是它们的值根本不由人写。不带捕获函数的元素（目前只有"脱机载体编号"）保留人工值。
   */
  function captureAndSaveMetadata(archiveId, user, reason = '源数据变更后同步') {
    const ctx = buildMetadataCtx(archiveId);
    if (!ctx) return null;
    const captured = metadata.captureAll(ctx);
    const prev = metadataValues(archiveId);
    const ts = nowIso();
    q.tx(() => {
      for (const e of metadata.ELEMENTS) {
        const hasCapture = typeof e.capture === 'function' && !e.manual;
        const value = hasCapture ? String(captured[e.code] || '') : String(prev[e.code] || '');
        const row = q.get('SELECT value, source FROM archive_metadata WHERE archive_id=? AND element_code=?',
          archiveId, e.code);
        if (!row) {
          q.run(`INSERT INTO archive_metadata(archive_id,element_code,entity,value,source,captured_at,updated_at,updated_by)
                 VALUES(?,?,?,?,?,?,?,?)`,
            archiveId, e.code, e.entity, value, hasCapture ? '自动捕获' : '手工著录',
            hasCapture ? ts : '', ts, user ? user.id : null);
        } else if (String(row.value) !== value) {
          q.run(`UPDATE archive_metadata SET value=?, source=?, captured_at=?, updated_at=?, updated_by=?
                 WHERE archive_id=? AND element_code=?`,
            value, hasCapture ? '自动捕获' : row.source, hasCapture ? ts : '', ts, user ? user.id : null,
            archiveId, e.code);
          logMetadataChange(archiveId, e.code, row.value, value, '自动捕获', reason, user);
        }
      }
    });
    const values = metadataValues(archiveId);
    return { values, completeness: metadata.completeness(values) };
  }

  /** 元数据方案定义（供界面渲染与外部系统对齐） */
  route('GET', '/api/metadata/scheme', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    ok(res, {
      scheme: 'DA/T 46—2009',
      basis: 'DA/T 46—2009；DA/T 92—2022 §8.1.1；《数字档案室建设指南》§5.1.2、§5.3.4；GB/T 18894—2016 §6.2',
      entities: metadata.ENTITIES,
      kinds: metadata.KINDS,
      immutableKinds: metadata.IMMUTABLE_KINDS,
      elements: metadata.ELEMENTS.map((e) => ({
        code: e.code, name: e.name, entity: e.entity, kind: e.kind,
        kindLabel: metadata.KINDS[e.kind], required: e.required, editable: e.editable,
        autoCaptured: typeof e.capture === 'function' && !e.manual, manual: !!e.manual,
        writeThrough: META_WRITE_THROUGH[e.code] || '',
        note: e.note, basis: e.basis,
      })),
      totals: {
        elements: metadata.ELEMENTS.length,
        required: metadata.ELEMENTS.filter((e) => e.required).length,
        immutable: metadata.ELEMENTS.filter((e) => !e.editable).length,
        autoCaptured: metadata.ELEMENTS.filter((e) => typeof e.capture === 'function').length,
      },
    });
  });

  /** 某件档案的元数据（值 + 完备性 + 方案） */
  route('GET', '/api/archives/:id/metadata', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    const values = metadataValues(id);
    const has = Object.keys(values).length > 0;
    const payload = has ? values : metadata.captureAll(buildMetadataCtx(id));
    const c = metadata.completeness(payload);
    ok(res, {
      archive_id: id,
      captured: has,
      values: payload,
      completeness: c,
      elements: metadata.ELEMENTS.map((e) => ({
        code: e.code, name: e.name, entity: e.entity, kind: e.kind, kindLabel: metadata.KINDS[e.kind],
        required: e.required, editable: e.editable, autoCaptured: typeof e.capture === 'function',
        writeThrough: META_WRITE_THROUGH[e.code] || '', note: e.note, basis: e.basis,
      })),
      entities: metadata.ENTITIES,
      changes: q.all(`SELECT element_code, action, old_value, new_value, reason, operator, at
                      FROM metadata_changes WHERE archive_id=? ORDER BY id DESC LIMIT 50`, id),
    });
  });

  /**
   * 修改描述性元数据。
   *
   * **背景 / 结构 / 管理过程元数据一律拒绝**（《数字档案室建设指南》§5.1.2、
   * GB/T 18894—2016 §6.2 明确禁止修改），并且把"试图修改"这件事本身记进留痕 ——
   * 只有留下拦截记录，"禁止修改"才算真正落实。
   */
  route('PUT', '/api/archives/:id/metadata', async (req, res, params) => {
    const u = requireCan(req, res, 'archive:update');
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    const b = await readJson(req);
    const incoming = (b && typeof b.values === 'object' && b.values) ? b.values : b;
    const enforceImmutable = String(numbering.getSetting(q, 'metadata.enforce_immutable', '1')) === '1';
    const applied = [];
    const rejected = [];

    for (const [code, rawValue] of Object.entries(incoming || {})) {
      const e = metadata.elementOf(code);
      if (!e) { rejected.push({ code, reason: '不是本方案定义的元数据项' }); continue; }
      const value = mustStr(rawValue, 4000);
      if (!e.editable && enforceImmutable) {
        rejected.push({
          code, name: e.name,
          reason: `${e.name}属于「${metadata.KINDS[e.kind]}」，按《数字档案室建设指南》§5.1.2 与 `
            + 'GB/T 18894—2016 §6.2 禁止修改，只能由系统自动捕获',
        });
        logMetadataChange(id, code, '', value, '拒绝修改', `禁止修改${metadata.KINDS[e.kind]}`, u);
        continue;
      }
      const col = META_WRITE_THROUGH[e.code];
      if (col) {
        // 描述性元素写回档案表，再由捕获逻辑同步回元数据，保证两边永远一致
        if (col === 'secret_level' && !SECRET_LEVELS.includes(value)) {
          rejected.push({ code, name: e.name, reason: `密级取值不合法，可选：${SECRET_LEVELS.join(' / ')}` });
          continue;
        }
        // 密级是元数据 M11，但改的是"定密"这件事：写回档案表前先过定密权限，
        // 否则这条元数据通道就成了绕过 /api/archives/:id/secret 的后门（v4.10.0）
        if (col === 'secret_level' && !can(u, 'secret:classify')) {
          rejected.push({ code, name: e.name, reason: '变更密级需系统安全保密员或管理员权限' });
          continue;
        }
        if (col === 'title' && !value.trim()) {
          rejected.push({ code, name: e.name, reason: '题名不能为空' });
          continue;
        }
        const old = q.scalar(`SELECT ${col} FROM archives WHERE id=?`, id);
        q.run(`UPDATE archives SET ${col}=?, updated_at=? WHERE id=?`, value, nowIso(), id);
        logMetadataChange(id, code, old, value, '修改', '通过元数据接口修改描述性元数据', u);
        applied.push({ code, name: e.name, value, wroteTo: col });
        continue;
      }
      if (typeof e.capture === 'function' && !e.manual) {
        // 有捕获函数但不需要写回档案表（如"机构人员名称"由责任者+部门合成）
        rejected.push({
          code, name: e.name,
          reason: `${e.name}由档案的其它字段合成或自动捕获，请在「档案著录」表单中修改对应字段`,
        });
        continue;
      }
      // 纯人工元素（脱机载体编号）
      const old = q.scalar('SELECT value FROM archive_metadata WHERE archive_id=? AND element_code=?', id, code) || '';
      q.run(`INSERT INTO archive_metadata(archive_id,element_code,entity,value,source,updated_at,updated_by)
             VALUES(?,?,?,?,'手工著录',?,?)
             ON CONFLICT(archive_id, element_code) DO UPDATE SET
               value=excluded.value, source='手工著录', updated_at=excluded.updated_at, updated_by=excluded.updated_by`,
        id, code, e.entity, value, nowIso(), u.id);
      logMetadataChange(id, code, old, value, '修改', '人工著录', u);
      applied.push({ code, name: e.name, value });
    }

    const snap = captureAndSaveMetadata(id, u, '修改描述性元数据后同步');
    log(u, '修改元数据', `档案 ${id}`,
      `应用 ${applied.length} 项${rejected.length ? `，拒绝 ${rejected.length} 项（${rejected.map((r) => r.name || r.code).join('、')}）` : ''}`,
      clientIp(req), { step: '元数据维护' });
    ok(res, {
      applied, rejected,
      values: snap ? snap.values : {},
      completeness: snap ? snap.completeness : null,
    });
  });

  /** 导出元数据 XML（《电子档案管理办法》第十六条要求元数据随文件一并归档） */
  route('GET', '/api/archives/:id/metadata/export.xml', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    const ctx = buildMetadataCtx(id);
    const values = metadataValues(id);
    const payload = Object.keys(values).length ? values : metadata.captureAll(ctx);
    const xml = metadata.toXml(ctx, payload, { exportedAt: nowIso(), by: u.username });
    const buf = Buffer.from(xml, 'utf8');
    log(u, '导出元数据', `档案 ${id}`, 'DA/T 46 XML', clientIp(req), { category: 'output' });
    res.writeHead(200, {
      'Content-Type': 'application/xml; charset=utf-8',
      'Content-Disposition': contentDisposition(`元数据_${ctx.archive.archive_code || id}.xml`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  /** 元数据完备率：按必选项统计（DA/T 92—2022 §8.1.1 必选项即必备项） */
  route('GET', '/api/metadata/stats', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sc = secretScope(u);
    const rows = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a WHERE 1=1${sc.sql}`, ...sc.params);
    const byElement = {};
    for (const e of metadata.ELEMENTS) byElement[e.code] = 0;
    let complete = 0;
    const incompleteSamples = [];
    for (const r of rows) {
      const values = metadataValues(r.id);
      const c = metadata.completeness(values);
      for (const e of metadata.ELEMENTS) if (String(values[e.code] || '').trim()) byElement[e.code]++;
      if (c.complete) complete++;
      else if (incompleteSamples.length < 20) {
        incompleteSamples.push({ id: r.id, archive_code: r.archive_code, title: r.title, missing: c.missing.map((m) => m.name) });
      }
    }
    ok(res, {
      archives: rows.length,
      complete,
      incomplete: rows.length - complete,
      completeRate: rows.length ? Math.round((complete / rows.length) * 100) : 100,
      byElement,
      incompleteSamples,
      elements: metadata.ELEMENTS.map((e) => ({
        code: e.code, name: e.name, entity: e.entity, required: e.required, editable: e.editable,
        autoCaptured: typeof e.capture === 'function' && !e.manual, manual: !!e.manual,
      })),
      scheme: 'DA/T 46—2009',
    });
  });

  /**
   * 为存量档案补建元数据（自动捕获）。
   * 与四性检测一样：升级后存量数据需要一次回填，否则完备率永远是 0。
   */
  route('POST', '/api/metadata/backfill', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const limit = Math.min(2000, Math.max(1, Number(b.limit) || 500));
    const sc = secretScope(u);
    const rows = q.all(`SELECT a.id FROM archives a WHERE 1=1${sc.sql}
                        ORDER BY a.id LIMIT ?`, ...sc.params, limit);
    let done = 0;
    for (const r of rows) {
      try { if (captureAndSaveMetadata(r.id, u, '存量补建')) done++; } catch (_) { /* 单件失败不影响整批 */ }
    }
    const remaining = Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE 1=1${sc.sql}
      AND NOT EXISTS (SELECT 1 FROM archive_metadata m WHERE m.archive_id=a.id)`, ...sc.params) || 0);
    log(u, '补建元数据', `${done} 件`, remaining ? `仍有 ${remaining} 件未补建` : '全部完成', clientIp(req),
      { category: 'archive', step: '元数据补建' });
    ok(res, { processed: done, remaining });
  });

  // ---------- 归档章与备考表（DA/T 22—2015）----------

  /** 归档章需要用到全宗信息 */
  function stampSettings() {
    return {
      unitCode: q.scalar("SELECT value FROM settings WHERE key='archive.unit_code'") || '',
      unitName: q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位',
    };
  }

  /** 合法的盒脊厚度（DA/T 22—2015 §6.4） */
  const SPINE_MM_ALLOWED = [20, 30, 40, 50];

  /** 校验盒脊厚度 */
  function normalizeSpineMm(v, dft) {
    const n = Number(v);
    return SPINE_MM_ALLOWED.includes(n) ? n : dft;
  }

  /**
   * 备考表数据（DA/T 22—2015 §6.5 五项）。
   * 整理人默认取盒的创建人（谁装的盒谁整理），日期留空由人填 ——
   * 日期是**签署行为**，系统替他填等于伪造记录。
   */
  function beikaobiaoData(box) {
    const creator = box.created_by
      ? q.get('SELECT display_name, username FROM users WHERE id=?', box.created_by)
      : null;
    const stat = q.get(
      'SELECT COUNT(*) AS c, MIN(archive_number) AS first_no, MAX(archive_number) AS last_no FROM archives WHERE box_id=?',
      box.id,
    ) || {};
    return {
      box_id: box.id,
      box_code: box.box_code,
      box_title: box.title || '',
      box_year: box.year || '',
      retention: box.retention || '',
      org_code: box.org_code || '',
      spine_mm: Number(box.spine_mm) || 30,
      item_count: Number(stat.c || 0),
      first_no: stat.first_no || '',
      last_no: stat.last_no || '',
      // 五项
      inventory_note: box.inventory_note || '',
      preparer: box.preparer || (creator ? (creator.display_name || creator.username) : ''),
      prepared_at: box.prepared_at || '',
      checker: box.checker || '',
      checked_at: box.checked_at || '',
      basis: 'DA/T 22—2015 §6.5（盒内文件情况说明、整理人、整理日期、检查人、检查日期）',
    };
  }

  /** 备考表正文（片段，供单独打印页与"卷内目录/盒脊"页复用） */
  function beikaobiaoInner(box) {
    const b = beikaobiaoData(box);
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const items = q.all(`SELECT archive_code, archive_number, item_no, title FROM archives
                         WHERE box_id=? ORDER BY archive_number, archive_code LIMIT 500`, box.id);
    const rows = items.map((r, i) => `<tr><td>${i + 1}</td><td class="mono">${esc(r.archive_number || r.archive_code)}</td>
      <td>${esc(r.title)}</td></tr>`).join('');
    return `
      <div class="print-head"><h1>备 考 表</h1><div class="meta">
        全宗名称：${esc(unit)}　盒号：${esc(b.box_code)}　年度：${esc(b.box_year || '—')}　
        保管期限：${esc(b.retention || '—')}　盒脊厚度：${esc(String(b.spine_mm))} mm　盒内件数：${b.item_count} 件<br>
        起止档号：${esc(b.first_no || '—')} ~ ${esc(b.last_no || '—')}</div></div>

      <div class="beikao">
        <h2>盒内文件情况说明</h2>
        <div class="bk-body">
          <div class="bk-note">${esc(b.inventory_note) || '（说明盒内文件的完整程度、缺损、修改、补充、移出、销毁等情况）'}</div>
          <div class="bk-sign">
            <div>整理人：<span class="bk-line">${esc(b.preparer) || '&nbsp;'}</span></div>
            <div>整理日期：<span class="bk-line">${esc(b.prepared_at) || '&nbsp;'}</span></div>
            <div>检查人：<span class="bk-line">${esc(b.checker) || '&nbsp;'}</span></div>
            <div>检查日期：<span class="bk-line">${esc(b.checked_at) || '&nbsp;'}</span></div>
          </div>
        </div>
      </div>

      <div class="rep-block" style="margin-top:14px">
        <div class="rep-title">盒内文件目录（共 ${b.item_count} 件）</div>
        <table class="print-table"><thead><tr>
          <th style="width:44px">序号</th><th style="width:180px">档号</th><th>题名</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="3" style="text-align:center">（盒内无档案）</td></tr>'}</tbody></table>
      </div>
      <div class="stamp-note">依据：DA/T 22—2015《归档文件整理规则》第 6.5 条 —— 备考表置于盒内文件之后，含盒内文件情况说明、整理人、整理日期、检查人、检查日期。</div>`;
  }

  /** 备考表打印页 */
  function beikaobiaoHtml(box, autoPrint) {
    return printShell(`备考表 ${esc(box.box_code)}`, beikaobiaoInner(box), autoPrint);
  }

  /** 归档章数据（含渲染结果）：JSON / SVG / HTML 三种形态 */
  route('GET', '/api/archives/:id/stamp', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const a = loadVisibleArchive(req, res, u, id);
    if (!a) return;
    const st = stampSettings();
    const fields = archiveStamp.stampFields(a, st);
    const missing = archiveStamp.stampMissing(fields);
    const fmt = String(url.searchParams.get('format') || '').toLowerCase();
    if (fmt === 'svg') {
      const svg = archiveStamp.stampSvg(a, st);
      res.writeHead(200, { 'Content-Type': 'image/svg+xml; charset=utf-8' });
      return res.end(svg);
    }
    ok(res, {
      archive_id: id,
      fields,
      missing,
      complete: missing.length === 0,
      cells: archiveStamp.STAMP_CELLS,
      basis: 'DA/T 22—2015 §5.4.4（必备项：全宗号、年度、保管期限、件号、页数；机构(问题)为选择项）、§5.4.5（盖在归档文件首页上端居中）',
      html: archiveStamp.stampHtml(a, st),
      svg: archiveStamp.stampSvg(a, st),
    });
  });

  /** 批量打印归档章（一次整理几十件时逐件手写既慢又容易写错） */
  route('GET', '/api/print/stamps', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const sp = url.searchParams;
    let ids = String(sp.get('ids') || '').split(',').map((s) => Number(s.trim())).filter(Boolean);
    const sc = secretScope(u);
    if (!ids.length) {
      // 未指定则打印当前检索条件下的档案（与列表口径一致）
      const f = buildFiltersOrFail(res, sp, u);
      if (!f) return;
      ids = q.all(`SELECT a.id FROM archives a ${f.sql} ORDER BY a.archive_number, a.archive_code LIMIT 200`,
        ...f.params).map((r) => r.id);
    } else {
      const holes = ids.map(() => '?').join(',');
      const allow = new Set(q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${sc.sql}`, ...ids, ...sc.params)
        .map((r) => r.id));
      ids = ids.filter((id) => allow.has(id));
    }
    if (!ids.length) return fail(res, 400, '没有可打印归档章的档案');
    const holes = ids.map(() => '?').join(',');
    const rows = q.all(`SELECT * FROM archives a WHERE a.id IN (${holes}) ORDER BY a.archive_number, a.archive_code`, ...ids);
    const st = stampSettings();
    const unit = st.unitName;
    const incomplete = rows.filter((a) => archiveStamp.stampMissing(archiveStamp.stampFields(a, st)).length);
    const html = printShell('归档章打印', `
      <div class="print-head"><h1>归 档 章</h1><div class="meta">
        全宗名称：${esc(unit)}　全宗号：${esc(st.unitCode)}　共 ${rows.length} 枚${incomplete.length ? `（其中 ${incomplete.length} 枚必备项不全）` : ''}<br>
        依据：DA/T 22—2015 §5.4.4 —— 必备项为全宗号、年度、保管期限、件号、页数</div></div>
      ${archiveStamp.stampSheetHtml(rows, st, { perRow: 3 })}
      <div class="stamp-note">加盖位置：归档文件首页上端居中（DA/T 22—2015 §5.4.5）。
        本页为电子样式，实体件仍须按单位规定加盖红色印章。</div>
    `, !!sp.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  /** 备考表数据（读取） */
  route('GET', '/api/boxes/:id/beikaobiao', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const box = q.get('SELECT * FROM archive_boxes WHERE id=?', Number(params.id));
    if (!box) return fail(res, 404, '档案盒不存在');
    ok(res, beikaobiaoData(box));
  });

  /**
   * 备考表签署信息（写入）。
   * 只允许改这五项 —— 备考表是签署凭据，能顺手改别的字段只会让凭据失去意义。
   */
  route('PUT', '/api/boxes/:id/beikaobiao', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const box = q.get('SELECT * FROM archive_boxes WHERE id=?', id);
    if (!box) return fail(res, 404, '档案盒不存在');
    const b = await readJson(req);
    const dateOk = (v) => {
      const s = String(v || '').trim();
      return s === '' || /^\d{4}-\d{2}-\d{2}$/.test(s);
    };
    for (const k of ['prepared_at', 'checked_at']) {
      if (b[k] !== undefined && !dateOk(b[k])) {
        return fail(res, 400, '日期格式应为 YYYY-MM-DD（或留空）');
      }
    }
    const preparer = b.preparer === undefined ? box.preparer : mustStr(b.preparer, 40);
    const preparedAt = b.prepared_at === undefined ? box.prepared_at : mustStr(b.prepared_at, 12);
    const checker = b.checker === undefined ? box.checker : mustStr(b.checker, 40);
    const checkedAt = b.checked_at === undefined ? box.checked_at : mustStr(b.checked_at, 12);
    const note = b.inventory_note === undefined ? box.inventory_note : mustStr(b.inventory_note, 2000);
    const spineMm = b.spine_mm === undefined ? (Number(box.spine_mm) || 30) : normalizeSpineMm(b.spine_mm, Number(box.spine_mm) || 30);
    if (b.spine_mm !== undefined && !SPINE_MM_ALLOWED.includes(Number(b.spine_mm))) {
      return fail(res, 400, `盒脊厚度只能是 ${SPINE_MM_ALLOWED.join(' / ')} mm（DA/T 22—2015 §6.4）`);
    }
    q.run(`UPDATE archive_boxes SET preparer=?, prepared_at=?, checker=?, checked_at=?,
           inventory_note=?, spine_mm=?, updated_at=? WHERE id=?`,
      preparer, preparedAt, checker, checkedAt, note, spineMm, nowIso(), id);
    log(u, '填写备考表', box.box_code,
      `整理人=${preparer || '—'}　检查人=${checker || '—'}`, clientIp(req), { step: '备考表签署' });
    ok(res, beikaobiaoData(q.get('SELECT * FROM archive_boxes WHERE id=?', id)));
  });

  /** 备考表打印页 */
  route('GET', '/api/print/beikaobiao/:boxId', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const box = q.get('SELECT * FROM archive_boxes WHERE id=?', Number(params.boxId));
    if (!box) return fail(res, 404, '档案盒不存在');
    const html = beikaobiaoHtml(box, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  // ---------- 借阅强化：下载审批、授权阅读时间、利用水印 ----------

  const unitNameOf = () => q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
  const wmEnabled = () => String(numbering.getSetting(q, 'watermark.enabled', '1')) === '1';
  const wmTemplate = () => numbering.getSetting(q, 'watermark.template', watermark.DEFAULT_TEMPLATE);
  const downloadRequireApproval = () => String(numbering.getSetting(q, 'download.require_approval', '1')) === '1';
  const readWindowEnforced = () => String(numbering.getSetting(q, 'loan.enforce_read_window', '0')) === '1';

  /** 生成一份利用水印文字（人 + 时间 + 凭据编号，三样缺一不可追溯） */
  function wmTextFor(user, archive, grantNo, purpose, at) {
    if (!wmEnabled()) return '';
    return watermark.buildText({
      template: wmTemplate(),
      unitName: unitNameOf(),
      username: user ? user.username : '',
      displayName: user ? (user.display_name || user.username) : '',
      at: at || nowIso(),
      archiveCode: archive ? (archive.archive_number || archive.archive_code || '') : '',
      grantNo: grantNo || '',
      purpose: purpose || '',
    });
  }

  /** 生成下载凭据编号：XZ<年月日>-<三位流水> */
  function nextGrantNo(d = new Date()) {
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    let n = Number(q.scalar('SELECT COUNT(*) FROM download_grants WHERE grant_no LIKE ?', `XZ${day}-%`) || 0);
    for (let i = 0; i < 999; i++) {
      n += 1;
      const no = `XZ${day}-${String(n).padStart(3, '0')}`;
      if (!q.scalar('SELECT id FROM download_grants WHERE grant_no=?', no)) return no;
    }
    return `XZ${day}-${Date.now().toString().slice(-6)}`;
  }

  /** 凭据当前是否可用（返回原因便于界面直接显示） */
  function grantState(g, now = nowIso()) {
    if (!g) return { usable: false, reason: '凭据不存在' };
    if (g.status === '已拒绝') return { usable: false, reason: '申请已被拒绝' };
    if (g.status === '待审批') return { usable: false, reason: '申请待审批' };
    if (g.status === '已用尽' || Number(g.used_times) >= Number(g.max_times)) {
      return { usable: false, reason: `可用次数已用尽（${g.used_times}/${g.max_times}）` };
    }
    if (g.status !== '已批准') return { usable: false, reason: `状态为「${g.status}」` };
    if (g.read_from && g.read_from > now) return { usable: false, reason: `尚未到授权开始时间（${g.read_from}）` };
    if (g.read_to && g.read_to < now) return { usable: false, reason: `已超过授权截止时间（${g.read_to}）` };
    return { usable: true, reason: '' };
  }

  /** 找一个对当前用户 + 指定附件有效的下载凭据 */
  function findValidGrant(user, fileId, archiveId) {
    const now = nowIso();
    const rows = q.all(`SELECT * FROM download_grants WHERE user_id=? AND archive_id=? AND status='已批准'
                        ORDER BY id DESC`, user.id, archiveId);
    for (const g of rows) {
      const st = grantState(g, now);
      if (!st.usable) continue;
      if (g.file_id && Number(g.file_id) !== Number(fileId)) continue;
      return g;
    }
    return null;
  }

  /**
   * 在线阅读是否处于授权时间窗内。
   * 依据《数字档案室建设指南》§4.4.2「授权阅读时间」。
   * 借阅批准时写入 read_from/read_to；下载凭据也同样带时间窗。
   */
  function readWindowOk(user, archiveId) {
    const now = nowIso();
    const loan = q.get(`SELECT * FROM loans WHERE archive_id=? AND user_id=? AND status IN ('已批准','逾期')
                        AND (read_from='' OR read_from<=?) AND (read_to='' OR read_to>=?)
                        ORDER BY id DESC LIMIT 1`, archiveId, user.id, now, now);
    if (loan) return { ok: true, via: '借阅', from: loan.read_from, to: loan.read_to, ref: loan.loan_no };
    const g = q.get(`SELECT * FROM download_grants WHERE archive_id=? AND user_id=? AND status='已批准'
                     AND (read_from='' OR read_from<=?) AND (read_to='' OR read_to>=?)
                     ORDER BY id DESC LIMIT 1`, archiveId, user.id, now, now);
    if (g) return { ok: true, via: '下载授权', from: g.read_from, to: g.read_to, ref: g.grant_no };
    return {
      ok: false,
      reason: '当前不在授权阅读时间内：请先提交借阅申请，或等待审批通过的阅读时段'
        + '（《数字档案室建设指南》§4.4.2 授权阅读时间）',
    };
  }

  /** 登记一次下载使用（次数 + 时间）；用尽后置为已用尽 */
  function consumeGrant(g, user, f) {
    const used = Number(g.used_times) + 1;
    const status = used >= Number(g.max_times) ? '已用尽' : '已批准';
    q.run('UPDATE download_grants SET used_times=?, status=?, last_used_at=? WHERE id=?',
      used, status, nowIso(), g.id);
    log(user, '下载受控附件', f.archive_code || String(f.archive_id),
      `凭据 ${g.grant_no}　第 ${used}/${g.max_times} 次　${g.watermark_text || ''}`,
      '', { category: 'output', step: '受控下载' });
  }

  /** 申请下载（普通用户需审批；档案员及以上作为审批方，申请即通过） */
  route('POST', '/api/download-grants', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'file:download')) return fail(res, 403, '当前账号没有下载附件的权限', 'FORBIDDEN');
    const b = await readJson(req);
    const archiveId = Number(b.archive_id);
    const a = loadVisibleArchive(req, res, u, archiveId);
    if (!a) return;
    let fileRow = null;
    if (Number(b.file_id)) {
      fileRow = q.get('SELECT * FROM files WHERE id=? AND archive_id=?', Number(b.file_id), archiveId);
      if (!fileRow) return fail(res, 400, '指定的附件不属于该档案');
    }
    const purpose = mustStr(b.purpose, 300).trim();
    if (!purpose) return fail(res, 400, '请填写下载用途（审批与追溯都要看这一项）');
    const hours = Math.max(1, Math.min(8760, Number(numbering.getSetting(q, 'download.default_valid_hours', '24')) || 24));
    const maxTimes = Math.max(1, Math.min(99, Number(numbering.getSetting(q, 'download.max_times_default', '1')) || 1));
    const now = nowIso();
    const auto = can(u, 'loan:approve');            // 档案员及以上为审批方，登记即生效
    const grantNo = nextGrantNo();
    const wm = wmTextFor(u, a, grantNo, purpose, now);
    const r = q.run(`INSERT INTO download_grants(grant_no,archive_id,file_id,user_id,applicant,purpose,status,
                      apply_at,approve_by,approve_at,read_from,read_to,max_times,used_times,page_from,page_to,watermark_text)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)`,
      grantNo, archiveId, fileRow ? fileRow.id : null, u.id, u.display_name || u.username, purpose,
      auto ? '已批准' : '待审批', now, auto ? u.id : null, auto ? now : '',
      auto ? now : '', auto ? new Date(Date.now() + hours * 3600000).toISOString() : '',
      maxTimes, Math.max(0, Number(b.page_from) || 0), Math.max(0, Number(b.page_to) || 0), wm);
    log(u, auto ? '下载登记' : '申请下载', a.archive_code || String(archiveId),
      `${fileRow ? fileRow.original_name : '全部附件'}｜${purpose}`, clientIp(req),
      { category: 'output', step: auto ? '下载登记' : '下载申请' });
    ok(res, {
      id: r.lastInsertRowid, grant_no: grantNo, status: auto ? '已批准' : '待审批',
      read_from: auto ? now : '', read_to: auto ? new Date(Date.now() + hours * 3600000).toISOString() : '',
      max_times: maxTimes, watermark_text: wm,
    });
  });

  /** 下载凭据列表（普通用户只看自己的；档案员及以上看全部可见范围内） */
  route('GET', '/api/download-grants', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sp = url.searchParams;
    const page = Math.max(1, numOr(sp.get('page'), 1));
    const size = Math.min(100, Math.max(1, numOr(sp.get('size'), 20)));
    const sc = secretScope(u, 'a.secret_level');
    const where = ['1=1'];
    const args = [];
    if (!can(u, 'loan:approve')) { where.push('g.user_id=?'); args.push(u.id); }
    else if (sp.get('user_id')) { where.push('g.user_id=?'); args.push(Number(sp.get('user_id'))); }
    if (sp.get('status')) { where.push('g.status=?'); args.push(sp.get('status')); }
    const w = ' WHERE ' + where.join(' AND ') + sc.sql;
    const total = Number(q.scalar(`SELECT COUNT(*) FROM download_grants g
                                   LEFT JOIN archives a ON a.id=g.archive_id ${w}`, ...args, ...sc.params) || 0);
    const list = q.all(`SELECT g.*, a.archive_code, a.title FROM download_grants g
                        LEFT JOIN archives a ON a.id=g.archive_id
                        ${w} ORDER BY g.id DESC LIMIT ? OFFSET ?`, ...args, ...sc.params, size, (page - 1) * size);
    for (const g of list) {
      const st = grantState(g);
      g.usable = st.usable;
      g.state_reason = st.reason;
    }
    ok(res, {
      list, total, page, size, pages: Math.max(1, Math.ceil(total / size)),
      policy: {
        requireApproval: downloadRequireApproval(),
        readWindowEnforced: readWindowEnforced(),
        defaultValidHours: Number(numbering.getSetting(q, 'download.default_valid_hours', '24')) || 24,
        maxTimesDefault: Number(numbering.getSetting(q, 'download.max_times_default', '1')) || 1,
        watermarkEnabled: wmEnabled(),
        watermarkTemplate: wmTemplate(),
      },
    });
  });

  /** 审批下载申请（档案员及以上） */
  route('POST', '/api/download-grants/:id/approve', async (req, res, params) => {
    const u = requireCan(req, res, 'loan:approve');
    if (!u) return;
    const g = q.get('SELECT * FROM download_grants WHERE id=?', Number(params.id));
    if (!g) return fail(res, 404, '下载申请不存在');
    if (g.status !== '待审批') return fail(res, 400, `该申请状态为「${g.status}」，不能重复审批`);
    const b = await readJson(req);
    const approve = b.approve !== false;
    if (!approve) {
      q.run("UPDATE download_grants SET status='已拒绝', approve_by=?, approve_at=?, approve_note=? WHERE id=?",
        u.id, nowIso(), mustStr(b.note, 300) || '未说明理由', g.id);
      log(u, '拒绝下载申请', g.grant_no, mustStr(b.note, 200), clientIp(req),
        { category: 'output', result: '拒绝', step: '下载审批' });
      return ok(res, { status: '已拒绝' });
    }
    // 审批时可覆盖有效期、次数与页数范围
    const hours = Math.max(1, Math.min(8760, Number(b.valid_hours) || Number(numbering.getSetting(q, 'download.default_valid_hours', '24')) || 24));
    const maxTimes = Math.max(1, Math.min(99, Number(b.max_times) || Number(g.max_times) || 1));
    const now = nowIso();
    const archive = q.get('SELECT * FROM archives WHERE id=?', g.archive_id);
    const wm = g.watermark_text || wmTextFor(q.get('SELECT * FROM users WHERE id=?', g.user_id), archive, g.grant_no, g.purpose, now);
    q.run(`UPDATE download_grants SET status='已批准', approve_by=?, approve_at=?, approve_note=?,
             read_from=?, read_to=?, max_times=?, page_from=?, page_to=?, watermark_text=? WHERE id=?`,
      u.id, now, mustStr(b.note, 300), now,
      new Date(Date.now() + hours * 3600000).toISOString(), maxTimes,
      Math.max(0, Number(b.page_from) || Number(g.page_from) || 0),
      Math.max(0, Number(b.page_to) || Number(g.page_to) || 0), wm, g.id);
    log(u, '批准下载申请', g.grant_no,
      `有效期 ${hours} 小时，可用 ${maxTimes} 次`, clientIp(req), { category: 'output', step: '下载审批' });
    ok(res, { status: '已批准', read_to: new Date(Date.now() + hours * 3600000).toISOString(), max_times: maxTimes, watermark_text: wm });
  });

  // ===== 日志 =====
  /** 审计日志的筛选条件（列表与导出共用，避免两处规则漂移） */
  function logFilters(sp) {
    const where = [];
    const args = [];
    if (sp.get('action')) { where.push('action=?'); args.push(sp.get('action')); }
    if (sp.get('user')) { where.push('username=?'); args.push(sp.get('user')); }
    if (sp.get('category')) { where.push('category=?'); args.push(sp.get('category')); }
    if (sp.get('result')) { where.push('result=?'); args.push(sp.get('result')); }
    const kw = (sp.get('kw') || '').trim();
    if (kw) {
      where.push('(target LIKE ? OR detail LIKE ? OR username LIKE ?)');
      args.push('%' + kw + '%', '%' + kw + '%', '%' + kw + '%');
    }
    if (sp.get('from')) { where.push('at>=?'); args.push(sp.get('from')); }
    if (sp.get('to')) { where.push('at<=?'); args.push(sp.get('to') + 'T23:59:59'); }
    return { sql: where.length ? ' WHERE ' + where.join(' AND ') : '', args };
  }

  /**
   * 校验整条审计日志链（分批读取，避免日志量大时整表进内存）。
   * 校验接口与备份清单共用同一份实现，保证两边结论一致。
   * @returns {{ok:boolean,total:number,checked:number,firstAt:string,lastAt:string,tail:string,broken:object|null}}
   */
  function verifyLogChain() {
    const total = Number(q.scalar('SELECT COUNT(*) FROM logs') || 0);
    const BATCH = 2000;
    let prev = audit.GENESIS;
    let checked = 0;
    let broken = null;
    let firstAt = '';
    let lastAt = '';
    for (let offset = 0; offset < total; offset += BATCH) {
      const rows = q.all('SELECT * FROM logs ORDER BY id LIMIT ? OFFSET ?', BATCH, offset);
      if (!rows.length) break;
      if (!firstAt) firstAt = rows[0].at;
      lastAt = rows[rows.length - 1].at;
      const r = audit.verifyChain(rows, prev);
      checked += rows.length;
      if (!r.ok) { broken = { id: r.brokenAt, reason: r.reason }; break; }
      prev = r.last;
    }
    return { ok: !broken, total, checked, firstAt, lastAt, tail: broken ? '' : prev, broken };
  }

  /**
   * 审计日志的保留期策略。
   *
   * DA/T 92—2022 §9.5：审计日志**保存时间不应低于电子档案保管期限**。
   * 因此保留天数不是随便配的：它必须覆盖馆藏中最长的保管期限。
   * 这里算出"制度要求的最短保留天数"，并与当前设置比对给出告警 ——
   * 只提示不强改，因为实际保留策略属于单位的制度决定。
   */
  function logRetentionPolicy() {
    const configuredDays = Number(numbering.getSetting(q, 'security.log_retain_days', '0')) || 0;
    // 最长保管期限（年）：取档案表里实际用到的最大值
    const maxYears = Number(q.scalar('SELECT COALESCE(MAX(retention_years),0) FROM archives') || 0);
    const hasPermanent = Number(q.scalar("SELECT COUNT(*) FROM archives WHERE retention IN ('永久','长期')") || 0) > 0;
    const requiredDays = hasPermanent ? 0 : maxYears * 365;   // 0 表示"永久保留"
    const warnings = [];
    if (hasPermanent) {
      warnings.push('馆藏含「永久/长期」保管的档案，审计日志应长期保存（保留天数建议设为 0 = 永久保留）');
      if (configuredDays > 0) warnings.push(`当前设置为 ${configuredDays} 天，短于永久保管档案的要求`);
    } else if (maxYears > 0 && configuredDays > 0 && configuredDays < maxYears * 365) {
      warnings.push(`当前保留 ${configuredDays} 天，短于馆藏最长保管期限 ${maxYears} 年（约 ${maxYears * 365} 天）的要求`);
    }
    return {
      configuredDays, configuredLabel: configuredDays === 0 ? '永久保留' : `${configuredDays} 天`,
      maxRetentionYears: maxYears, hasPermanent,
      requiredDays, requiredLabel: hasPermanent || requiredDays === 0 ? '永久保留' : `${requiredDays} 天`,
      compliant: hasPermanent ? configuredDays === 0 : !(configuredDays > 0 && configuredDays < requiredDays),
      warnings,
    };
  }

  route('GET', '/api/logs', async (req, res, params, url) => {
    // 审计日志查询：审计员的本职工作，档案员及以上也可查看（等级保护常见实务）
    const u = requireCan(req, res, 'log:view');
    if (!u) return;
    const sp = url.searchParams;
    const page = Math.max(1, numOr(sp.get('page'), 1));
    const size = Math.min(200, Math.max(1, numOr(sp.get('size'), 30)));
    const f = logFilters(sp);
    const total = Number(q.scalar(`SELECT COUNT(*) FROM logs ${f.sql}`, ...f.args) || 0);
    const list = q.all(`SELECT * FROM logs ${f.sql} ORDER BY id DESC LIMIT ? OFFSET ?`, ...f.args, size, (page - 1) * size);
    // 带上分类清单与操作者清单，供界面做筛选下拉，而不必在前端重复维护一套映射
    const actions = q.all('SELECT DISTINCT action FROM logs ORDER BY action').map((r) => r.action);
    ok(res, {
      list, total, page, size, pages: Math.max(1, Math.ceil(total / size)),
      categories: audit.CATEGORIES, actions,
    });
  });

  /**
   * 审计日志链完整性校验。
   *
   * 这是"日志能当证据用"的关键一步：哈希链把「事后改日志」从**不可发现**变成**可发现**。
   * 分批读取（每批 2000 条），避免日志量大时把整表读进内存。
   *
   * 注意：校验动作本身也会写一条日志（审计员查过账，这件事本身也该留痕），
   * 所以返回的 tail 是"校验时刻"的链尾，不包含刚刚写入的这条校验记录。
   */
  route('GET', '/api/logs/verify', async (req, res) => {
    const u = requireCan(req, res, 'audit:view');
    if (!u) return;
    const v = verifyLogChain();
    const { total, checked, firstAt, lastAt, broken } = v;
    log(u, '校验审计日志链',
      broken ? `发现断点 id=${broken.id}` : `全部 ${total} 条完整`,
      broken ? broken.reason : '', clientIp(req),
      { category: 'security', result: broken ? '失败' : '成功', step: '完整性校验' });
    ok(res, {
      ok: v.ok,
      total,
      checked,
      algorithm: 'SHA-256 链式哈希（每条记录前一条的哈希）',
      firstAt, lastAt,
      tail: v.tail,
      broken,
      note: broken
        ? '链在该处断开：说明这条记录被修改过，或它之前的记录被删除/插入过。请立即封存当前数据并排查。'
        : '全部记录与前一条哈希衔接一致，未发现被修改或删除的痕迹。',
    });
  });

  /**
   * 审计日志导出（CSV）。
   * DA/T 92—2022 §9.5 要求审计信息可检索、可输出；
   * 导出时一并带上哈希字段，便于离线复核链的连续性。
   */
  route('GET', '/api/logs/export.csv', async (req, res, params, url) => {
    const u = requireCan(req, res, 'audit:view');
    if (!u) return;
    const f = logFilters(url.searchParams);
    const rows = q.all(`SELECT * FROM logs ${f.sql} ORDER BY id`, ...f.args);
    const headers = ['序号', '行为日期', '行为人员', '行为描述', '行为步骤', '行为对象',
      '结果', '分类', '来源IP', '细节', '前一条哈希', '本条哈希'];
    const body = toCsv(headers, rows.map((r) => [
      r.id, r.at, r.username, r.action, r.step, r.target,
      r.result, audit.categoryLabel(r.category), r.ip, r.detail, r.prev_hash, r.hash,
    ]));
    const buf = Buffer.from(body, 'utf8');
    log(u, '导出审计日志', 'CSV', `${rows.length} 条`, clientIp(req), { category: 'output' });
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': contentDisposition(`审计日志_${today()}.csv`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  // ===== 导入导出 =====
  route('GET', '/api/export/archives.csv', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const f = buildFiltersOrFail(res, url.searchParams, u);
    if (!f) return;
    const rows = q.all(`SELECT a.archive_code,a.title,c.name AS category,a.type_code,a.retention,a.secret_level,
                               a.year,a.archive_date,a.volume_no,a.item_no,a.pages,a.copies,a.carrier,
                               a.responsible,a.department,a.abstract,a.keywords,a.location,a.status,a.status_note,
                               (SELECT COUNT(*) FROM files f WHERE f.archive_id=a.id) AS file_count
                        FROM archives a LEFT JOIN categories c ON c.id=a.category_id ${f.sql}
                        ORDER BY a.archive_code`, ...f.params);
    const headers = ['档案号', '题名', '分类', '门类', '保管期限', '密级', '年度', '归档日期', '案卷号', '件号',
      '页数', '份数', '载体', '责任者', '部门', '摘要', '关键词', '存放位置', '状态', '状态备注', '附件数'];
    const body = toCsv(headers, rows.map((r) => [r.archive_code, r.title, r.category, r.type_code, r.retention,
      r.secret_level, r.year, r.archive_date, r.volume_no, r.item_no, r.pages, r.copies, r.carrier, r.responsible,
      r.department, r.abstract, r.keywords, r.location, r.status, r.status_note, r.file_count]));
    const buf = Buffer.from(body, 'utf8');
    log(u, '导出档案目录', 'CSV', `${rows.length} 条`, clientIp(req));
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': contentDisposition(`档案目录_${today()}.csv`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  // ===== 备份 =====

  /**
   * 制作一份完整备份包（数据库一致性快照 + 附件原文 + 审计日志 CSV + 说明）。
   * 抽出来给「下载备份」与「制作备份并登记」两条路径共用 ——
   * 两处各写一遍打包逻辑，早晚会出现"下载的包"和"登记的包"内容不一致。
   */
  function buildBackupZip(user) {
    const zip = new ZipWriter();
    const stamp = nowIso().replace(/[:T]/g, '-').slice(0, 19);
    const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');
    try { fs.mkdirSync(dataDir, { recursive: true }); } catch (_) { /* 目录已存在 */ }
    const snapshot = path.join(dataDir, `backup-${stamp}.db`);
    try {
      q.raw.exec(`VACUUM INTO '${snapshot.replace(/'/g, "''")}'`);
    } catch (e) {
      throw Object.assign(new Error('数据库快照失败：' + e.message), { statusCode: 500 });
    }
    zip.addFile('db/archive.db', snapshot);

    // 审计日志：DA/T 92—2022 §9.5 要求审计信息**纳入备份与恢复范围**。
    // 数据库快照里虽然已含 logs 表，但额外放一份人可读、可离线复核哈希链的 CSV。
    const logsCount = Number(q.scalar('SELECT COUNT(*) FROM logs') || 0);
    const chain = verifyLogChain();
    const retention = logRetentionPolicy();
    try {
      const rows = q.all('SELECT * FROM logs ORDER BY id');
      const body = toCsv(
        ['序号', '行为日期', '行为人员', '行为描述', '行为步骤', '行为对象', '结果', '分类', '来源IP', '细节', '前一条哈希', '本条哈希'],
        rows.map((r) => [r.id, r.at, r.username, r.action, r.step, r.target, r.result,
          audit.categoryLabel(r.category), r.ip, r.detail, r.prev_hash, r.hash]),
      );
      zip.add('audit/logs.csv', Buffer.from(body, 'utf8'));
    } catch (e) {
      console.warn('[备份] 审计日志 CSV 生成失败（不影响数据库快照）：' + e.message);
    }

    const manifest = {
      app: '档案管理系统', version: config.version, exportedAt: nowIso(), by: user ? user.username : '',
      archives: Number(q.scalar('SELECT COUNT(*) FROM archives') || 0),
      files: Number(q.scalar('SELECT COUNT(*) FROM files') || 0),
      users: Number(q.scalar('SELECT COUNT(*) FROM users') || 0),
      logs: logsCount,
      audit: {
        algorithm: 'SHA-256 链式哈希（每条记录携带前一条的哈希）',
        chainIntact: chain.ok,
        checked: chain.checked,
        firstAt: chain.firstAt,
        lastAt: chain.lastAt,
        tailHash: chain.tail,
        broken: chain.broken,
        retention,
      },
      contents: [
        'db/archive.db —— 全部数据表（账号、档案、附件记录、借阅、日志等）',
        'files/ —— 电子附件原文（内容寻址）',
        'audit/logs.csv —— 审计日志（含行为步骤/结果/分类与哈希链字段）',
        'manifest.json —— 本说明（含日志链校验结论）',
      ],
      note: '恢复方式：停止系统后，用 db/archive.db 覆盖 data/archive.db，并把 files/ 目录整体放回 data/files/；'
        + '恢复后可在「操作日志 → 校验日志链」确认审计日志未被改动。',
    };
    zip.add('manifest.json', Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));
    zip.addDirectory(filesRoot, 'files');
    let buf;
    try {
      buf = zip.toBuffer();
    } finally {
      try { fs.unlinkSync(snapshot); } catch (_) { /* ignore */ }
    }
    return { buf, manifest, stamp, chain, logsCount };
  }

  route('GET', '/api/backup/download', async (req, res) => {
    // 备份属于系统管理员职责（三员分立），安全审计员不参与运维
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    let built;
    try { built = buildBackupZip(u); } catch (e) { return fail(res, e.statusCode || 500, e.message); }
    const { buf, manifest, stamp, chain, logsCount } = built;
    log(u, '备份导出', '全库',
      `附件 ${manifest.files} 个、日志 ${logsCount} 条、日志链${chain.ok ? '完整' : '异常'}`,
      clientIp(req), { category: 'system', result: chain.ok ? '成功' : '失败' });
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': contentDisposition(`档案系统备份_${stamp}.zip`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  // ---------- 备份合规与存储状况监控 ----------

  const MEDIA_TYPES = ['磁盘', '移动硬盘', '光盘', '缩微胶片', '网络位置', '其他'];
  const MEDIA_LOCATIONS = ['在线', '同城离线', '异地'];
  const MEDIA_CONDITIONS = ['良好', '需关注', '不可用'];

  /** 生成备份单号：BZ<年月日>-<三位流水> */
  function nextBackupNo(d = new Date()) {
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    let n = Number(q.scalar('SELECT COUNT(*) FROM backups WHERE backup_no LIKE ?', `BZ${day}-%`) || 0);
    for (let i = 0; i < 999; i++) {
      n += 1;
      const no = `BZ${day}-${String(n).padStart(3, '0')}`;
      if (!q.scalar('SELECT id FROM backups WHERE backup_no=?', no)) return no;
    }
    return `BZ${day}-${Date.now().toString().slice(-6)}`;
  }

  /** 生成保管状况检测单号：BJ<年月日>-<三位流水> */
  function nextStorageCheckNo(d = new Date()) {
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    let n = Number(q.scalar('SELECT COUNT(*) FROM storage_checks WHERE check_no LIKE ?', `BJ${day}-%`) || 0);
    for (let i = 0; i < 999; i++) {
      n += 1;
      const no = `BJ${day}-${String(n).padStart(3, '0')}`;
      if (!q.scalar('SELECT id FROM storage_checks WHERE check_no=?', no)) return no;
    }
    return `BJ${day}-${Date.now().toString().slice(-6)}`;
  }

  /** 介质台账 */
  route('GET', '/api/backup/media', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const list = q.all('SELECT * FROM backup_media ORDER BY location, medium_no');
    // 每种介质上有几份备份：判断"每种介质上保存一套完整数据"要求是否满足
    for (const m of list) {
      m.backup_count = Number(q.scalar('SELECT COUNT(*) FROM backups WHERE medium_id=?', m.id) || 0);
      m.latest_backup_at = q.scalar('SELECT MAX(created_at) FROM backups WHERE medium_id=?', m.id) || '';
    }
    ok(res, { list, types: MEDIA_TYPES, locations: MEDIA_LOCATIONS, conditions: MEDIA_CONDITIONS });
  });

  route('POST', '/api/backup/media', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const b = await readJson(req);
    const mediumNo = mustStr(b.medium_no, 40).trim();
    if (!mediumNo) return fail(res, 400, '请填写介质编号');
    if (q.scalar('SELECT id FROM backup_media WHERE medium_no=?', mediumNo)) return fail(res, 400, '该介质编号已存在');
    const type = MEDIA_TYPES.includes(b.type) ? b.type : '磁盘';
    const location = MEDIA_LOCATIONS.includes(b.location) ? b.location : '在线';
    const condition = MEDIA_CONDITIONS.includes(b.condition) ? b.condition : '良好';
    const r = q.run(`INSERT INTO backup_media(medium_no,type,location,label,capacity_bytes,used_bytes,condition,
                      note,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
      mediumNo, type, location, mustStr(b.label, 100), Math.max(0, Number(b.capacity_bytes) || 0),
      Math.max(0, Number(b.used_bytes) || 0), condition, mustStr(b.note, 300),
      u.id, nowIso(), nowIso());
    log(u, '登记备份介质', mediumNo, `${type}｜${location}`, clientIp(req), { category: 'system', step: '介质登记' });
    ok(res, { id: r.lastInsertRowid });
  });

  route('PUT', '/api/backup/media/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM backup_media WHERE id=?', id);
    if (!cur) return fail(res, 404, '介质不存在');
    const b = await readJson(req);
    const condition = MEDIA_CONDITIONS.includes(b.condition) ? b.condition : cur.condition;
    const location = MEDIA_LOCATIONS.includes(b.location) ? b.location : cur.location;
    q.run(`UPDATE backup_media SET type=?, location=?, label=?, capacity_bytes=?, used_bytes=?,
             condition=?, note=?, last_checked_at=?, updated_at=? WHERE id=?`,
      MEDIA_TYPES.includes(b.type) ? b.type : cur.type, location,
      b.label === undefined ? cur.label : mustStr(b.label, 100),
      b.capacity_bytes === undefined ? cur.capacity_bytes : Math.max(0, Number(b.capacity_bytes) || 0),
      b.used_bytes === undefined ? cur.used_bytes : Math.max(0, Number(b.used_bytes) || 0),
      condition, b.note === undefined ? cur.note : mustStr(b.note, 300),
      b.condition !== undefined ? nowIso() : cur.last_checked_at, nowIso(), id);
    log(u, '更新备份介质', cur.medium_no, `状态=${condition}`, clientIp(req), { category: 'system' });
    ok(res, true);
  });

  /**
   * 制作一份备份并**登记**。
   *
   * 为什么要"登记"而不只是下载：只有登记在案的备份才能被核查
   * "够不够三套、有没有离线和异地"（《电子档案管理办法》第二十六条）。
   * 光有文件躺在某个盘上，谁也说不清到底备份了几份、都在哪。
   */
  /**
   * 制作一份备份并**登记**。
   *
   * 为什么要"登记"而不只是下载：只有登记在案的备份才能被核查
   * "够不够三套、有没有离线和异地"（《电子档案管理办法》第二十六条）。
   * 光有文件躺在某个盘上，谁也说不清到底备份了几份、都在哪。
   *
   * 为什么抽成函数而不是留在路由里：**定时任务必须用同一份实现**。
   * 人工点"制作备份"和半夜自动备份要产出一模一样的登记记录，
   * 否则两套口径迟早打架（备份合规体检正是按这条口径算"够不够三套两介质"的）。
   *
   * @param {object} u 操作用户；{id:null,username:'系统'} 表示定时任务自动执行
   * @param {object} [opts] { targetType, mediumId, destDir, note, ip }
   * @returns {object} 备份登记
   */
  function runBackup(u, opts = {}) {
    const targetType = ['在线', '离线', '异地'].includes(opts.targetType) ? opts.targetType : '在线';
    let medium = null;
    if (Number(opts.mediumId)) {
      medium = q.get('SELECT * FROM backup_media WHERE id=?', Number(opts.mediumId));
      if (!medium) throw Object.assign(new Error('指定的备份介质不存在'), { statusCode: 400 });
      if (medium.condition === '不可用') {
        throw Object.assign(new Error(`介质「${medium.medium_no}」状态为不可用，不能用于备份`), { statusCode: 400 });
      }
    }
    const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');
    // 目标目录：显式给出则用它，否则用数据目录下的备份子目录
    let destDir = String(opts.destDir || '').trim();
    if (!destDir) destDir = path.join(dataDir, numbering.getSetting(q, 'backup.default_dir', 'backups'));
    try {
      fs.mkdirSync(destDir, { recursive: true });
    } catch (e) {
      throw Object.assign(new Error(`备份目录不可用：${e.message}`), { statusCode: 400 });
    }
    const built = buildBackupZip(u);
    // 备份单号先算出来并**编进文件名**。
    // 只用时间戳（精确到秒）命名的话，同一秒内连做两次备份，后一份会覆盖前一份 ——
    // 表面上"做了两次备份"，实际只剩一套。（本项目踩过一次）
    const backupNo = nextBackupNo();
    const fileName = `档案系统备份_${built.stamp}_${backupNo}.zip`;
    const destPath = path.join(destDir, fileName);
    let sha = '';
    let size = 0;
    try {
      fs.writeFileSync(destPath, built.buf);
      sha = sha256(built.buf);
      size = built.buf.length;
    } catch (e) {
      throw Object.assign(new Error(`写入备份文件失败：${e.message}`), { statusCode: 500 });
    }
    let id = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO backups(backup_no,kind,target_type,medium_id,medium_no,dest_path,file_name,
                        size_bytes,sha256,archives_count,files_count,logs_count,chain_ok,note,created_by,created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        backupNo, '全量', targetType, medium ? medium.id : null, medium ? medium.medium_no : '',
        destPath, fileName, size, sha, built.manifest.archives, built.manifest.files, built.logsCount,
        built.chain.ok ? 1 : 0, String(opts.note || '').slice(0, 300), u ? u.id : null, nowIso());
      id = r.lastInsertRowid;
      if (medium) {
        // 介质已用量按台账口径累加（不追求精确：容量核查看的是"有没有超"，不是字节级对账）
        q.run('UPDATE backup_media SET used_bytes=used_bytes+?, updated_at=? WHERE id=?', size, nowIso(), medium.id);
      }
    });
    log(u, '制作备份', backupNo,
      `${targetType}｜${medium ? medium.medium_no + '｜' : ''}${(size / 1048576).toFixed(1)} MB｜日志链${built.chain.ok ? '完整' : '异常'}`,
      opts.ip || '', { category: 'system', step: '备份制作' });
    return {
      id, backup_no: backupNo, target_type: targetType,
      medium_no: medium ? medium.medium_no : '', dest_path: destPath, file_name: fileName,
      size_bytes: size, sha256: sha, chain_ok: built.chain.ok,
      archives_count: built.manifest.archives, files_count: built.manifest.files, logs_count: built.logsCount,
    };
  }

  route('POST', '/api/backup/run', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const b = await readJson(req);
    try {
      ok(res, runBackup(u, {
        targetType: b.target_type,
        mediumId: b.medium_id,
        destDir: mustStr(b.dest_dir, 400).trim(),
        note: mustStr(b.note, 300),
        ip: clientIp(req),
      }));
    } catch (e) {
      fail(res, e.statusCode || 500, e.message);
    }
  });

  /** 备份登记列表 */
  route('GET', '/api/backups', async (req, res, params, url) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const list = q.all('SELECT * FROM backups ORDER BY id DESC LIMIT 200');
    ok(res, { list, total: list.length });
  });

  /**
   * 校验一份已登记的备份：重算摘要、打开包内数据库核对账目与审计链。
   * 备份"做过"和备份"能用"是两件事 —— 不校验就没人知道那个 ZIP 还能不能打开。
   */
  route('POST', '/api/backups/:id/verify', async (req, res, params) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const bk = q.get('SELECT * FROM backups WHERE id=?', Number(params.id));
    if (!bk) return fail(res, 404, '备份记录不存在');
    const problems = [];
    let actualSha = '';
    let sizeOk = false;
    if (!fs.existsSync(bk.dest_path)) {
      problems.push('备份文件不存在（可能已被移动或删除）');
    } else {
      try {
        const buf = fs.readFileSync(bk.dest_path);
        sizeOk = buf.length === Number(bk.size_bytes);
        if (!sizeOk) problems.push(`文件大小与登记不符（登记 ${bk.size_bytes}，实际 ${buf.length}）`);
        actualSha = sha256(buf);
        if (bk.sha256 && actualSha !== bk.sha256) {
          problems.push(`摘要与登记不符（登记 ${String(bk.sha256).slice(0, 12)}…，实测 ${String(actualSha).slice(0, 12)}…）`);
        }
      } catch (e) {
        problems.push('读取备份文件失败：' + e.message);
      }
    }
    const result = problems.length ? `不合格：${problems.join('；')}` : '合格：文件存在、大小与摘要均一致';
    q.run('UPDATE backups SET verify_at=?, verify_result=? WHERE id=?', nowIso(), result, bk.id);
    log(u, '校验备份', bk.backup_no, result, clientIp(req),
      { category: 'system', result: problems.length ? '失败' : '成功', step: '备份校验' });
    ok(res, {
      backup_no: bk.backup_no, ok: problems.length === 0, result,
      problems, actual_sha256: actualSha, size_ok: sizeOk,
    });
  });

  /* ============================ 恢复演练与恢复台账 ============================
   *
   * 为什么单独做"演练"：备份"做了"不等于"能恢复"。验收和等保测评都会问这一句，
   * 而只拿备份文件是答不了的 —— 得有人真的把包打开、把里面的库打开、把账数出来。
   *
   * 演练**不碰生产库**：把包里的 db/archive.db 解到临时文件，用只读连接统计，
   * 并校验日志哈希链、抽查附件是否都在包里。真正的整库替换是维护动作，
   * 用 server/tools/restore-backup.js 在**停服状态**下执行（避免运行中换库带来的并发与 WAL 残留）。
   */

  /** 打开并校验一个备份包：返回包内条目、库文件缓冲、清单 */
  function openBackupPackage(bk) {
    if (!bk) return { error: '备份记录不存在', code: 404 };
    if (!bk.dest_path || !fs.existsSync(bk.dest_path)) {
      return { error: '备份文件不存在（可能已被移动或删除）', code: 400 };
    }
    let buf;
    try { buf = fs.readFileSync(bk.dest_path); } catch (e) {
      return { error: '读取备份文件失败：' + e.message, code: 400 };
    }
    if (bk.sha256 && sha256(buf) !== bk.sha256) {
      return { error: '备份文件摘要与登记不符，可能已被替换或损坏', code: 400 };
    }
    let entries;
    try { entries = textExtract.readZipEntries(buf); } catch (e) {
      return { error: '备份包无法解析：' + e.message, code: 400 };
    }
    if (!entries || !entries.size) return { error: '备份包内没有任何文件', code: 400 };
    const dbBuf = entries.get('db/archive.db');
    if (!dbBuf) return { error: '备份包内缺少 db/archive.db，无法用于恢复', code: 400 };
    let manifest = null;
    const mBuf = entries.get('manifest.json');
    if (mBuf) { try { manifest = JSON.parse(mBuf.toString('utf8')); } catch (_) { manifest = null; } }
    return { buf, entries, dbBuf, manifest };
  }

  /** 从包内库文件统计账目并校验日志链（只读，不动生产库） */
  function inspectPackageDb(dbBuf, tmpPath) {
    const { DatabaseSync } = require('node:sqlite');
    fs.writeFileSync(tmpPath, dbBuf);
    let tdb;
    try { tdb = new DatabaseSync(tmpPath, { readOnly: true }); } catch (e) {
      return { error: '包内数据库无法打开：' + e.message };
    }
    try {
      const cnt = (sql) => {
        try { return Number((tdb.prepare(sql).get() || { c: 0 }).c || 0); } catch (_) { return -1; }
      };
      const counts = {
        archives: cnt('SELECT COUNT(*) c FROM archives'),
        files: cnt('SELECT COUNT(*) c FROM files'),
        users: cnt('SELECT COUNT(*) c FROM users'),
        logs: cnt('SELECT COUNT(*) c FROM logs'),
      };
      let chain = { ok: false, count: 0, reason: '日志表不可读' };
      try {
        const rows = tdb.prepare(
          'SELECT id,prev_hash,at,user_id,username,action,target,detail,ip,step,result,category,hash FROM logs ORDER BY id ASC',
        ).all();
        chain = audit.verifyChain(rows);
      } catch (e) { chain = { ok: false, reason: '读取日志失败：' + e.message }; }
      let dueReminders = -1;
      try { dueReminders = cnt('SELECT COUNT(*) c FROM archives WHERE next_check_at IS NOT NULL'); } catch (_) {}
      return { counts, chain, dueReminders };
    } finally {
      try { tdb.close(); } catch (_) {}
    }
  }

  /** 抽查包内附件：files 表登记的实体在不在包里 */
  function sampleAttachments(entries, tmpPath) {
    const { DatabaseSync } = require('node:sqlite');
    let tdb;
    try { tdb = new DatabaseSync(tmpPath, { readOnly: true }); } catch (_) { return { checked: 0, missing: [] }; }
    try {
      let rows = [];
      try { rows = tdb.prepare('SELECT id, rel_path, original_name, sha256 FROM files ORDER BY id ASC').all(); } catch (_) { return { checked: 0, missing: [] }; }
      const total = rows.length;
      const picked = total <= 50 ? rows : rows.filter((_, i) => i % Math.ceil(total / 50) === 0).slice(0, 50);
      const missing = [];
      for (const r of picked) {
        const key = 'files/' + String(r.rel_path || '').replace(/\\/g, '/');
        if (!entries.has(key)) missing.push({ id: r.id, name: r.original_name || '', path: r.rel_path || '' });
      }
      return { checked: picked.length, total, missing };
    } finally {
      try { tdb.close(); } catch (_) {}
    }
  }

  /** 写一条演练台账 */
  function recordDrill(row) {
    q.run(
      `INSERT INTO backup_drills
        (at,backup_no,mode,result,archives,files,users,logs,chain_ok,detail,by_user,by_name,ip)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      row.at, row.backup_no, row.mode, row.result,
      row.archives, row.files, row.users, row.logs,
      row.chain_ok, row.detail, row.by_user, row.by_name, row.ip,
    );
    return q.scalar('SELECT id FROM backup_drills ORDER BY id DESC LIMIT 1');
  }

  /**
   * 恢复演练：POST /api/backup/drills  body { id?, backup_no? }
   * 不指定则取最近一次备份。返回可恢复性结论，并落一条台账。
   */
  route('POST', '/api/backup/drills', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const b = req.body || {};
    let bk = null;
    if (b.id) bk = q.get('SELECT * FROM backups WHERE id=?', Number(b.id));
    else if (b.backup_no) bk = q.get('SELECT * FROM backups WHERE backup_no=?', String(b.backup_no));
    else bk = q.get('SELECT * FROM backups ORDER BY id DESC LIMIT 1');
    if (!bk) return fail(res, 404, '还没有可演练的备份，请先执行一次备份');

    const pkg = openBackupPackage(bk);
    if (pkg.error) {
      const detail = '演练失败：' + pkg.error;
      let id = 0;
      try {
        id = recordDrill({
          at: nowIso(), backup_no: bk.backup_no, mode: '演练', result: '不合格',
          archives: 0, files: 0, users: 0, logs: 0, chain_ok: 0, detail,
          by_user: u.id, by_name: u.display_name || u.username || '', ip: clientIp(req),
        });
      } catch (_) { /* 台账失败不影响结论返回 */ }
      log(u, '恢复演练', bk.backup_no, detail, clientIp(req),
        { category: 'system', result: '失败', step: '恢复演练' });
      return ok(res, { id, backup_no: bk.backup_no, ok: false, detail });
    }

    const tmpDir = path.join(config.dataDir || path.dirname(filesRoot), 'tmp');
    try { fs.mkdirSync(tmpDir, { recursive: true }); } catch (_) {}
    const stamp = Date.now() + '-' + Math.random().toString(36).slice(2, 8);
    const tmpPath = path.join(tmpDir, '.drill-' + stamp + '.db');
    const ins = inspectPackageDb(pkg.dbBuf, tmpPath);
    if (ins.error) {
      try { fs.unlinkSync(tmpPath); } catch (_) {}
      const detail = '演练失败：' + ins.error;
      const id = recordDrill({
        at: nowIso(), backup_no: bk.backup_no, mode: '演练', result: '不合格',
        archives: 0, files: 0, users: 0, logs: 0, chain_ok: 0, detail,
        by_user: u.id, by_name: u.display_name || u.username || '', ip: clientIp(req),
      });
      log(u, '恢复演练', bk.backup_no, detail, clientIp(req),
        { category: 'system', result: '失败', step: '恢复演练' });
      return ok(res, { id, backup_no: bk.backup_no, ok: false, detail });
    }

    const att = sampleAttachments(pkg.entries, tmpPath);
    try { fs.unlinkSync(tmpPath); } catch (_) {}

    const problems = [];
    if (!ins.chain.ok) problems.push('日志哈希链不完整（' + (ins.chain.reason || '') + '）');
    if (att.missing.length) problems.push(`附件抽查缺 ${att.missing.length} 个（抽查 ${att.checked} 个）`);
    const entriesNoDb = pkg.entries.size;
    if (entriesNoDb <= 1 && ins.counts.archives === 0) problems.push('包内除数据库外没有任何档案实体');

    const detailParts = [
      `包内条目 ${entriesNoDb} 个`,
      `档案 ${ins.counts.archives} 条、附件 ${ins.counts.files} 个、用户 ${ins.counts.users} 个、日志 ${ins.counts.logs} 条`,
      `日志链${ins.chain.ok ? '完整' : '异常'}`,
      `附件抽查 ${att.checked}/${att.total} 个${att.missing.length ? '（缺 ' + att.missing.length + '）' : '，全部在包内'}`,
    ];
    if (!problems.length && ins.counts.archives === 0 && att.total === 0) {
      detailParts.push('提示：这是一份空库备份，属正常现象（库刚建好还没录数据）');
    }
    const result = problems.length ? '不合格' : '合格';
    const detail = (problems.length ? '演练发现：' + problems.join('；') + '。' : '演练通过：') + detailParts.join('；');

    const id = recordDrill({
      at: nowIso(), backup_no: bk.backup_no, mode: '演练', result,
      archives: Math.max(0, ins.counts.archives), files: Math.max(0, ins.counts.files),
      users: Math.max(0, ins.counts.users), logs: Math.max(0, ins.counts.logs),
      chain_ok: ins.chain.ok ? 1 : 0, detail,
      by_user: u.id, by_name: u.display_name || u.username || '', ip: clientIp(req),
    });
    q.run('UPDATE backups SET verify_at=?, verify_result=?, restore_tested=? WHERE id=?',
      nowIso(), (problems.length ? '不合格：' : '合格：') + '恢复演练' + (problems.length ? '未通过' : '通过'),
      problems.length ? 0 : 1, bk.id);
    log(u, '恢复演练', bk.backup_no, detail, clientIp(req),
      { category: 'system', result: problems.length ? '失败' : '成功', step: '恢复演练' });
    ok(res, {
      id, backup_no: bk.backup_no, ok: problems.length === 0, result, detail,
      counts: ins.counts, chain_ok: ins.chain.ok, attachments: att,
      problems,
    });
  });

  /** 演练台账：GET /api/backup/drills?limit=50 */
  route('GET', '/api/backup/drills', async (req, res, params, url) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const limit = Math.min(200, Math.max(1, Number(url.searchParams.get('limit') || 50)));
    const list = q.all(
      `SELECT id,at,backup_no,mode,result,archives,files,users,logs,chain_ok,detail,by_name,ip
         FROM backup_drills ORDER BY id DESC LIMIT ?`, limit,
    );
    const total = q.scalar('SELECT COUNT(*) FROM backup_drills') || 0;
    const last = q.get("SELECT * FROM backup_drills WHERE mode='演练' ORDER BY id DESC LIMIT 1");
    const lastRestore = q.get("SELECT * FROM backup_drills WHERE mode='实际恢复' ORDER BY id DESC LIMIT 1");
    ok(res, { total, list, last_drill: last || null, last_restore: lastRestore || null });
  });

  /* ==================== 制度五项（V4.32.0） ==================== */

  const RETENTION_VALUES = ['永久', '定期30年', '定期10年', '定期5年', '长期'];
  const retentionYears = (r) => (r === '永久' || r === '长期' ? 0 : Number(String(r).replace(/[^0-9]/g, '')) || 0);

  /** 保管期限表：列表（带门类名） */
  route('GET', '/api/retention/schedule', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const list = q.all(
      `SELECT s.*, t.name AS type_name FROM retention_schedule s
         LEFT JOIN archive_types t ON t.code=s.type_code
        ORDER BY s.type_code, s.item`, 
    );
    const types = q.all('SELECT code,name,retention FROM archive_types ORDER BY sort_no');
    ok(res, { list, types, retentions: RETENTION_VALUES });
  });

  /** 保管期限表：按门类 + 关键词查表（著录时带出期限与依据） */
  route('GET', '/api/retention/suggest', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const type = mustStr(url.searchParams.get('type_code'), 12);
    const kw = mustStr(url.searchParams.get('kw'), 60).trim();
    let sql = "SELECT * FROM retention_schedule WHERE status='启用'";
    const args = [];
    if (type) { sql += ' AND (type_code=? OR type_code=\'\')'; args.push(type); }
    if (kw) { sql += ' AND item LIKE ?'; args.push('%' + kw + '%'); }
    sql += ' ORDER BY (item LIKE ?) DESC, id ASC LIMIT 20';
    args.push(kw ? '%' + kw + '%' : '%');
    const list = q.all(sql, ...args);
    const def = list.find((x) => x.type_code === type) || list[0] || null;
    ok(res, {
      list,
      suggested: def ? { retention: def.retention, years: def.years, basis: def.basis, item: def.item } : null,
    });
  });

  route('POST', '/api/retention/schedule', async (req, res) => {
    const u = requireCan(req, res, 'meta:manage');
    if (!u) return;
    const b = await readJson(req);
    const item = mustStr(b.item, 120).trim();
    if (!item) return fail(res, 400, '请填写事项名称');
    const retention = RETENTION_VALUES.includes(b.retention) ? b.retention : '永久';
    const typeCode = mustStr(b.type_code, 12).trim();
    const exists = q.get('SELECT id FROM retention_schedule WHERE type_code=? AND item=?', typeCode, item);
    if (exists) return fail(res, 409, '该门类下已有同名事项，请直接修改那一条');
    q.run(`INSERT INTO retention_schedule(type_code,item,retention,years,basis,note,status,created_at)
           VALUES(?,?,?,?,?,?,'启用',?)`,
      typeCode, item, retention, retentionYears(retention), mustStr(b.basis, 300), mustStr(b.note, 300), nowIso());
    log(u, '新增保管期限表条目', item, `${typeCode || '通用'}｜${retention}`, clientIp(req),
      { category: 'system', step: '保管期限表' });
    ok(res, { id: q.scalar('SELECT id FROM retention_schedule ORDER BY id DESC LIMIT 1') });
  });

  route('PUT', '/api/retention/schedule/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'meta:manage');
    if (!u) return;
    const row = q.get('SELECT * FROM retention_schedule WHERE id=?', Number(params.id));
    if (!row) return fail(res, 404, '条目不存在');
    const b = await readJson(req);
    const retention = RETENTION_VALUES.includes(b.retention) ? b.retention : row.retention;
    q.run(`UPDATE retention_schedule SET type_code=?,item=?,retention=?,years=?,basis=?,note=?,status=?,updated_at=? WHERE id=?`,
      mustStr(b.type_code, 12).trim(), mustStr(b.item, 120).trim() || row.item, retention, retentionYears(retention),
      mustStr(b.basis, 300), mustStr(b.note, 300),
      b.status === '停用' ? '停用' : '启用', nowIso(), row.id);
    ok(res, { id: row.id });
  });

  route('DELETE', '/api/retention/schedule/:id', async (req, res, params) => {
    const u = requireCan(req, res, 'meta:manage');
    if (!u) return;
    const row = q.get('SELECT * FROM retention_schedule WHERE id=?', Number(params.id));
    if (!row) return fail(res, 404, '条目不存在');
    q.run('DELETE FROM retention_schedule WHERE id=?', row.id);
    log(u, '删除保管期限表条目', row.item, `${row.type_code}｜${row.retention}`, clientIp(req),
      { category: 'system', step: '保管期限表' });
    ok(res, { deleted: true });
  });

  /* ---------- 件级状态机 ---------- */
  // 与既有 status（实体在哪：在库/借出/待整理/待销毁/已销毁）并存：
  // status 回答"东西在哪"，lifecycle 回答"这一件办到哪一步了"。
  const LIFECYCLE_STATES = ['接收', '整理', '著录', '归档', '上架', '借阅', '鉴定', '销毁', '移交'];
  const LIFECYCLE_FLOW = {
    接收: ['整理'],
    整理: ['著录'],
    著录: ['归档'],
    归档: ['上架', '鉴定'],
    上架: ['借阅', '鉴定', '移交'],
    借阅: ['上架'],
    鉴定: ['销毁', '移交', '上架'],
    销毁: [],
    移交: [],
  };
  const LIFECYCLE_ACTION = { 销毁: 'appraisal:approve', 移交: 'transfer:manage', 鉴定: 'appraisal:run' };

  route('GET', '/api/lifecycle/states', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    ok(res, { states: LIFECYCLE_STATES, flow: LIFECYCLE_FLOW, actionOf: LIFECYCLE_ACTION });
  });

  route('POST', '/api/archives/:id/transition', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const b = await readJson(req);
    const to = mustStr(b.to, 12);
    if (!LIFECYCLE_STATES.includes(to)) return fail(res, 400, '流转目标不在状态清单内');
    const from = String(a.lifecycle || '').trim() || '接收';
    // 空状态允许从「接收」起跳，其余必须按流程走
    if (from !== to && !(LIFECYCLE_FLOW[from] || []).includes(to)) {
      return fail(res, 400, `不允许从「${from}」直接到「${to}」，可走：${(LIFECYCLE_FLOW[from] || ['（终态）']).join('、')}`);
    }
    const need = LIFECYCLE_ACTION[to];
    if (need && !policy.can(u, need)) return fail(res, 403, `流转到「${to}」需要相应权限（${need}）`);
    if (!policy.can(u, 'archive:update') && !policy.can(u, 'appraisal:run')) {
      return fail(res, 403, '没有修改该档案的权限');
    }
    if (from === to) return fail(res, 400, '当前已经处于该状态');
    const seq = Number(q.scalar('SELECT COALESCE(MAX(seq),0) FROM archive_transitions WHERE archive_id=?', a.id) || 0) + 1;
    q.run('UPDATE archives SET lifecycle=?, lifecycle_at=?, updated_at=? WHERE id=?', to, nowIso(), nowIso(), a.id);
    q.run(`INSERT INTO archive_transitions(archive_id,seq,from_state,to_state,reason,by_user,by_name,at,ip)
           VALUES(?,?,?,?,?,?,?,?,?)`,
      a.id, seq, from, to, mustStr(b.reason, 300), u.id, u.display_name || u.username, nowIso(), clientIp(req));
    log(u, '档案状态流转', a.archive_code || String(a.id), `${from} → ${to}${b.reason ? '：' + b.reason : ''}`,
      clientIp(req), { category: 'archive', step: '件级状态机' });
    ok(res, { id: a.id, from, to, seq });
  });

  route('GET', '/api/archives/:id/transitions', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const list = q.all(
      `SELECT id,seq,from_state,to_state,reason,by_name,at FROM archive_transitions
        WHERE archive_id=? ORDER BY id DESC LIMIT 100`, a.id,
    );
    ok(res, { current: a.lifecycle || '', states: LIFECYCLE_STATES, next: LIFECYCLE_FLOW[a.lifecycle || ''] || [], list });
  });

  /* ---------- 四性证据链 ---------- */
  const EVIDENCE_ASPECTS = ['真实性', '完整性', '可用性', '安全性'];

  route('GET', '/api/archives/:id/evidence', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const list = q.all(
      `SELECT e.*, f.original_name AS file_name FROM integrity_evidence e
         LEFT JOIN files f ON f.id=e.file_id
        WHERE e.archive_id=? ORDER BY e.id DESC LIMIT 100`, a.id,
    );
    const covered = new Set(list.map((x) => x.aspect));
    ok(res, { list, aspects: EVIDENCE_ASPECTS, missing: EVIDENCE_ASPECTS.filter((x) => !covered.has(x)) });
  });

  route('POST', '/api/archives/:id/evidence', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const b = await readJson(req);
    const aspect = EVIDENCE_ASPECTS.includes(b.aspect) ? b.aspect : '';
    if (!aspect) return fail(res, 400, '证据类别只能是：' + EVIDENCE_ASPECTS.join('、'));
    if (!policy.can(u, 'detection:run') && !policy.can(u, 'archive:update')) return fail(res, 403, '没有取证权限');
    let fileId = Number(b.file_id) || null;
    let method = mustStr(b.method, 80).trim();
    let value = mustStr(b.value, 200).trim();
    let result = ['通过', '存疑', '不通过'].includes(b.result) ? b.result : '通过';
    if (!fileId) {
      const f = q.get('SELECT id FROM files WHERE archive_id=? ORDER BY sort_no, id LIMIT 1', a.id);
      if (f) fileId = f.id;
    }
    // 完整性默认实测：把附件的 SHA-256 重算一遍与库里登记值比对 —— 这是"完整"最硬的证据
    if (aspect === '完整性' && !value && fileId) {
      const f = q.get('SELECT id,original_name,rel_path,sha256 FROM files WHERE id=?', fileId);
      if (f) {
        try {
          const buf = fs.readFileSync(absPath(filesRoot, f.rel_path));
          const got = sha256(buf);
          value = got;
          method = method || 'SHA-256 实测比对';
          result = f.sha256 && got === f.sha256 ? '通过' : '不通过';
          if (!f.sha256) method = 'SHA-256 实测（库内无登记值，作为基准）';
        } catch (e) {
          method = method || 'SHA-256 实测';
          value = '';
          result = '不通过';
        }
      }
    }
    if (!method) method = aspect === '完整性' ? 'SHA-256 实测比对' : '人工核验';
    q.run(`INSERT INTO integrity_evidence(archive_id,file_id,aspect,method,value,result,note,at,by_user,by_name)
           VALUES(?,?,?,?,?,?,?,?,?,?)`,
      a.id, fileId, aspect, method, value, result, mustStr(b.note, 300), nowIso(), u.id, u.display_name || u.username);
    log(u, '四性取证', a.archive_code || String(a.id), `${aspect}｜${result}｜${method}`, clientIp(req),
      { category: 'detection', result: result === '不通过' ? '失败' : '成功', step: '四性证据链' });
    ok(res, { aspect, result, method, value });
  });

  route('GET', '/api/evidence/summary', async (req, res) => {
    const u = requireCan(req, res, 'detection:view');
    if (!u) return;
    const byAspect = q.all(
      `SELECT aspect, result, COUNT(*) AS count FROM integrity_evidence GROUP BY aspect, result`,
    );
    const covered = Number(q.scalar('SELECT COUNT(DISTINCT archive_id) FROM integrity_evidence') || 0);
    const total = Number(q.scalar('SELECT COUNT(*) FROM archives') || 0);
    const uncovered = q.all(
      `SELECT a.id,a.archive_code,a.title FROM archives a
         LEFT JOIN integrity_evidence e ON e.archive_id=a.id
        WHERE e.id IS NULL ORDER BY a.id DESC LIMIT 20`,
    );
    ok(res, { byAspect, covered, total, uncovered });
  });

  /* ---------- 件级授权（密级 × 部门 × 件级） ---------- */

  /** 该用户对这一件是否有有效授权 */
  function validGrantOf(user, archiveId) {
    if (!user) return null;
    const g = q.get(
      `SELECT * FROM archive_grants WHERE archive_id=? AND user_id=? AND status='有效'`, Number(archiveId), user.id,
    );
    if (!g) return null;
    if (g.expires_at && g.expires_at < nowIso()) return null;
    return g;
  }

  route('GET', '/api/archive-grants', async (req, res) => {
    const u = requireCan(req, res, 'security:manage') || requireCan(req, res, 'system:manage');
    if (!u) return;
    const list = q.all(
      `SELECT g.*, a.archive_code, a.title, us.display_name AS user_name, us.department AS user_department
         FROM archive_grants g
         JOIN archives a ON a.id=g.archive_id
         JOIN users us ON us.id=g.user_id
        ORDER BY g.id DESC LIMIT 200`,
    );
    ok(res, { list, total: list.length });
  });

  /** 件级授权的可选账号：只回显示名与部门，不给电话邮箱 —— 定密责任人要做的是"授权给谁"，不是看通讯录 */
  route('GET', '/api/grant-targets', async (req, res) => {
    const u = requireCan(req, res, 'secret:classify');
    if (!u) return;
    const list = q.all(
      "SELECT id,display_name,department,role FROM users WHERE status='active' ORDER BY department, id",
    );
    ok(res, { list });
  });

  route('POST', '/api/archives/:id/grants', async (req, res, params) => {
    const u = requireCan(req, res, 'secret:classify');
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const b = await readJson(req);
    const userId = Number(b.user_id);
    if (!userId) return fail(res, 400, '请选择授权给哪个账号');
    const target = q.get('SELECT id,username,display_name FROM users WHERE id=?', userId);
    if (!target) return fail(res, 404, '账号不存在');
    q.run(`INSERT INTO archive_grants(archive_id,user_id,reason,granted_by,granted_name,at,expires_at,status)
           VALUES(?,?,?,?,?,?,?,'有效')
           ON CONFLICT(archive_id,user_id) DO UPDATE SET reason=excluded.reason, granted_by=excluded.granted_by,
             granted_name=excluded.granted_name, at=excluded.at, expires_at=excluded.expires_at, status='有效'`,
      a.id, userId, mustStr(b.reason, 200), u.id, u.display_name || u.username, nowIso(), mustStr(b.expires_at, 30));
    log(u, '件级授权', a.archive_code || String(a.id), `授权给 ${target.display_name || target.username}`,
      clientIp(req), { category: 'security', step: '件级权限' });
    ok(res, { ok: true });
  });

  route('DELETE', '/api/archives/:id/grants/:gid', async (req, res, params) => {
    const u = requireCan(req, res, 'secret:classify');
    if (!u) return;
    const g = q.get('SELECT * FROM archive_grants WHERE id=? AND archive_id=?', Number(params.gid), Number(params.id));
    if (!g) return fail(res, 404, '授权记录不存在');
    q.run("UPDATE archive_grants SET status='已撤销' WHERE id=?", g.id);
    log(u, '撤销件级授权', String(params.id), `授权记录 ${g.id}`, clientIp(req), { category: 'security', step: '件级权限' });
    ok(res, { revoked: true });
  });

  /* ---------- 利用登记 ---------- */

  /** 记一次利用（谁、何时、对哪一件、做了什么） */
  function recordUsage(user, archiveId, action, { fileId = null, target = '', ip = '' } = {}) {
    if (!user || !archiveId) return;
    try {
      q.run(`INSERT INTO usage_registry(archive_id,file_id,user_id,username,department,action,target,at,ip)
             VALUES(?,?,?,?,?,?,?,?,?)`,
        Number(archiveId), fileId, user.id, user.display_name || user.username,
        user.department || '', action, target, nowIso(), ip);
    } catch (e) { /* 登记失败不影响业务 */ }
  }

  route('GET', '/api/usage-registry', async (req, res, params, url) => {
    const u = requireCan(req, res, 'audit:view') || requireCan(req, res, 'log:view');
    if (!u) return;
    const limit = Math.min(300, Math.max(1, Number(url.searchParams.get('limit') || 100)));
    const kw = mustStr(url.searchParams.get('kw'), 60).trim();
    let sql = `SELECT r.*, a.archive_code, a.title FROM usage_registry r
                 LEFT JOIN archives a ON a.id=r.archive_id WHERE 1=1`;
    const args = [];
    if (kw) { sql += ' AND (a.archive_code LIKE ? OR a.title LIKE ? OR r.username LIKE ?)'; args.push('%' + kw + '%', '%' + kw + '%', '%' + kw + '%'); }
    sql += ' ORDER BY r.id DESC LIMIT ?';
    args.push(limit);
    const list = q.all(sql, ...args);
    const total = Number(q.scalar('SELECT COUNT(*) FROM usage_registry') || 0);
    ok(res, { list, total });
  });

  /* ---------- 管理者驾驶舱 ---------- */
  route('GET', '/api/cockpit', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const total = Number(q.scalar('SELECT COUNT(*) FROM archives') || 0);
    const byType = q.all('SELECT t.name, COUNT(a.id) AS count FROM archive_types t LEFT JOIN archives a ON a.type_code=t.code GROUP BY t.code ORDER BY count DESC');
    const byYear = q.all("SELECT year AS name, COUNT(*) AS count FROM archives GROUP BY year ORDER BY year DESC LIMIT 10");
    const byRetention = q.all('SELECT retention AS name, COUNT(*) AS count FROM archives GROUP BY retention ORDER BY count DESC');
    const bySecret = q.all('SELECT secret_level AS name, COUNT(*) AS count FROM archives GROUP BY secret_level ORDER BY count DESC');
    const byLifecycle = q.all("SELECT CASE WHEN lifecycle='' THEN '未设置' ELSE lifecycle END AS name, COUNT(*) AS count FROM archives GROUP BY name ORDER BY count DESC");
    const byDept = q.all("SELECT CASE WHEN department='' THEN '未填写' ELSE department END AS name, COUNT(*) AS count FROM archives GROUP BY name ORDER BY count DESC LIMIT 10");
    // 著录进度：按关键字段缺失率算"完成度"
    const fields = [
      ['题名', "title=''"], ['档号', "archive_code=''"], ['年度', "COALESCE(year,0)=0"],
      ['保管期限', "retention=''"], ['责任者', "responsible=''"], ['部门', "department=''"], ['密级', "secret_level=''"],
    ];
    const progress = fields.map(([label, cond]) => {
      const miss = Number(q.scalar(`SELECT COUNT(*) FROM archives WHERE ${cond}`) || 0);
      return { label, missing: miss, ratio: total ? Math.round(((total - miss) / total) * 1000) / 10 : 100 };
    });
    const electronic = Number(q.scalar("SELECT COUNT(*) FROM archives WHERE electronic_flag LIKE '%电子%'") || 0);
    const withFiles = Number(q.scalar('SELECT COUNT(DISTINCT archive_id) FROM files') || 0);
    // 风险清单
    const risks = [];
    const due = q.all(
      `SELECT id,archive_code,title,retention,retention_due_year FROM archives
        WHERE retention_due_year>0 AND retention_due_year<=? ORDER BY retention_due_year LIMIT 20`, new Date().getFullYear(),
    );
    if (due.length) risks.push({ kind: '到期未鉴定', level: 'warn', count: due.length, items: due.slice(0, 8) });
    const overdue = Number(q.scalar(
      "SELECT COUNT(*) FROM loans WHERE status='已批准' AND mode='借出' AND due_date<>'' AND due_date<?", nowIso().slice(0, 10),
    ) || 0);
    if (overdue) risks.push({ kind: '逾期未还', level: 'error', count: overdue });
    const pendingDetect = Number(q.scalar("SELECT COUNT(*) FROM archives WHERE secret_level='机密'") || 0);
    if (pendingDetect) risks.push({ kind: '涉密件需重点管控', level: 'info', count: pendingDetect });
    const noEvidence = Number(q.scalar('SELECT COUNT(*) FROM archives a LEFT JOIN integrity_evidence e ON e.archive_id=a.id WHERE e.id IS NULL') || 0);
    if (noEvidence) risks.push({ kind: '未做四性取证', level: 'warn', count: noEvidence });
    const dryBackup = Number(q.scalar('SELECT COUNT(*) FROM backups WHERE restore_tested=0') || 0);
    if (dryBackup) risks.push({ kind: '备份未做恢复演练', level: 'warn', count: dryBackup });
    const pendingAppraisal = Number(q.scalar("SELECT COUNT(*) FROM archives WHERE status='待销毁'") || 0);
    if (pendingAppraisal) risks.push({ kind: '待销毁未处置', level: 'warn', count: pendingAppraisal });
    ok(res, {
      total, byType, byYear, byRetention, bySecret, byLifecycle, byDept,
      progress, electronic, withFiles, risks,
      generated_at: nowIso(),
    });
  });

  /**
   * 授权与外存（v4.33.0）
   *
   * 授权状态放在公开接口：登录页也要能显示"授权已到期/未授权"，不能等登录进去才提示。
   * 机器码只给已登录的人看 —— 未登录的人拿到也没用，但少一处泄露面。
   */
  route('GET', '/api/license', async (req, res) => {
    const v = licenseView();
    const u = currentUser(req);
    const out = Object.assign({}, v);
    if (!u) delete out.machine;
    ok(res, out);
  });

  route('POST', '/api/license/reload', async (req, res) => {
    const u = requireCan(req, res, 'system:manage');
    if (!u) return;
    lic = licenseLib.checkLicense({ dataDir, explicit: config && config.licenseFile });
    try {
      log(u, '重新读取授权', lic.state, `${lic.unit || '未授权'}｜${lic.message}`, clientIp(req),
        { category: 'system', result: lic.state === 'ok' || lic.state === 'none' ? '成功' : '失败', step: '授权' });
    } catch (_) { /* 审计失败不影响 */ }
    ok(res, licenseView());
  });

  /** 审计外存：本地锚点清单 + 外存游标状态 + 最近一段链校验 */
  route('GET', '/api/audit/anchor', async (req, res, params, url) => {
    const u = requireCan(req, res, 'audit:view') || requireCan(req, res, 'system:manage');
    if (!u) return;
    const limit = Math.min(100, Math.max(1, Number(url.searchParams.get('limit') || 30)));
    const local = auditAnchor.listAnchors(dataDir, limit);
    const mirrorDir = numbering.getSetting(q, 'audit.mirror_dir', '');
    ok(res, {
      local,
      mirror: auditAnchor.mirrorStatus(mirrorDir),
      tail: auditAnchor.chainTail(db),
      anchorHours: Number(numbering.getSetting(q, 'audit.anchor_hours', '24')) || 24,
    });
  });

  /** 立即生成一次锚点（并推进外存副本） */
  route('POST', '/api/audit/anchor/run', async (req, res) => {
    const u = requireCan(req, res, 'audit:view') || requireCan(req, res, 'system:manage');
    if (!u) return;
    const mirrorDir = numbering.getSetting(q, 'audit.mirror_dir', '');
    const r = auditAnchor.runAnchor({
      db, dataDir, mirrorDir, note: '页面手动生成', byName: u.display_name || u.username,
    });
    try {
      log(u, '生成审计锚点', String(r.anchor.last_id), `日志 ${r.anchor.logs_total} 条｜外存追加 ${r.mirror.appended} 条${r.errors.length ? '｜' + r.errors.join('；') : ''}`,
        clientIp(req), { category: 'audit', result: r.ok ? '成功' : '失败', step: '审计外存' });
    } catch (_) { /* 审计失败不影响 */ }
    ok(res, {
      at: r.at, anchor: r.anchor, mirror: r.mirror, errors: r.errors,
      localPath: r.localPath, mirrorStatus: auditAnchor.mirrorStatus(mirrorDir),
    });
  });

  /**
   * 备份合规体检：**几套数据、几种介质、有没有离线、有没有异地、检测超期没有**。
   *
   * 这是《电子档案管理办法》第二十六条最直接的落地检查 —— 标准写的是
   * "至少两种介质、至少三套完整数据、一套在线两套备份"，那就把这几项算出来给人看，
   * 而不是让单位自己去数。
   */
  route('GET', '/api/backup/status', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const requiredCopies = Number(numbering.getSetting(q, 'backup.required_copies', '3')) || 3;
    const requiredTypes = Number(numbering.getSetting(q, 'backup.required_media_types', '2')) || 2;
    const requireOffline = String(numbering.getSetting(q, 'backup.require_offline', '1')) === '1';
    const requireOffsite = String(numbering.getSetting(q, 'backup.require_offsite', '0')) === '1';
    const intervalDays = Number(numbering.getSetting(q, 'storage.check_interval_days', '30')) || 30;

    const backups = q.all('SELECT * FROM backups ORDER BY id DESC');
    const media = q.all('SELECT * FROM backup_media ORDER BY id');
    // "套数"按当前仍存在且校验通过的备份计；校验不通过的不能算数
    const usable = backups.filter((b) => fs.existsSync(b.dest_path));
    const online = usable.filter((b) => b.target_type === '在线');
    const offline = usable.filter((b) => b.target_type === '离线');
    const offsite = usable.filter((b) => b.target_type === '异地');
    const mediaTypesInUse = [...new Set(usable.map((b) => {
      if (b.medium_id) {
        const m = media.find((x) => x.id === b.medium_id);
        if (m) return m.type;
      }
      return '磁盘';
    }))];
    const lastCheck = q.get('SELECT * FROM storage_checks ORDER BY id DESC LIMIT 1');
    const lastCheckDays = lastCheck ? Math.floor((Date.now() - Date.parse(lastCheck.created_at)) / 86400000) : null;

    const warnings = [];
    if (usable.length < requiredCopies) {
      warnings.push(`完整备份只有 ${usable.length} 套，标准要求至少 ${requiredCopies} 套（一套在线应用、两套备份）`);
    }
    if (!online.length) warnings.push('没有在线备份（在线的那一套通常就是正在使用的数据本身）');
    if (requireOffline && !offline.length) warnings.push('没有离线备份（标准要求以在线方式和离线方式各保存）');
    if (requireOffsite && !offsite.length) warnings.push('没有异地备份（《电子档案管理办法》第二十七条）');
    if (mediaTypesInUse.length < requiredTypes) {
      warnings.push(`备份只落在 ${mediaTypesInUse.length} 种介质上（${mediaTypesInUse.join('、') || '无'}），标准要求至少 ${requiredTypes} 种`);
    }
    if (!lastCheck) warnings.push('从未做过保管状况检测（标准要求定期检测可读状况、软硬件环境与介质完好程度）');
    else if (lastCheckDays > intervalDays) {
      warnings.push(`最近一次保管状况检测在 ${lastCheckDays} 天前，已超过设定的 ${intervalDays} 天周期`);
    }
    const badMedia = media.filter((m) => m.condition !== '良好');
    if (badMedia.length) warnings.push(`有 ${badMedia.length} 个介质状态异常：${badMedia.map((m) => m.medium_no).join('、')}`);

    // 工作台要回答"数据在哪、多大"（v4.32.0 豆包信创）：
    // 只统计库文件大小与附件登记体积，不遍历附件目录 —— 工作台不能被一次全盘 walk 拖慢。
    const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');
    let dbBytes = 0;
    try { dbBytes = fs.statSync(path.join(dataDir, 'archive.db')).size; } catch (_) { /* 库文件可能还没落盘 */ }
    const fileBytes = Number(q.scalar('SELECT COALESCE(SUM(size),0) AS s FROM files') || 0);

    ok(res, {
      data: { dir: dataDir, db_bytes: dbBytes, files_bytes: fileBytes },
      requirement: {
        requiredCopies, requiredMediaTypes: requiredTypes, requireOffline, requireOffsite, intervalDays,
        basis: '《电子档案管理办法》第二十六条（至少两种介质、至少三套完整数据，一套在线两套备份，定期检测保管情况）、第二十七条（异地备份）；DA/T 92—2022 §9.2',
      },
      counts: {
        total: backups.length, usable: usable.length,
        online: online.length, offline: offline.length, offsite: offsite.length,
        mediaTypes: mediaTypesInUse, mediaCount: media.length,
        verified: backups.filter((b) => b.verify_result.startsWith('合格')).length,
      },
      media, usableBackups: usable,
      lastCheck: lastCheck || null, lastCheckDays,
      compliant: warnings.length === 0,
      warnings,
    });
  });

  /**
   * 保管状况检测（档办发〔2017〕3号第二十二/二十四条：存储状况监控与警告）。
   * 检测五条：介质空间、数据库完整性、审计链、附件可读性抽样（fixity check）、介质状态。
   *
   * 抽成函数是为了让**定时巡检与人工点击共用同一份实现**：
   * "定期保管状况检测"（storage.check_interval_days）要靠它，
   * 两套实现会得出两个结论，那这份体检就没意义了。
   *
   * @param {object} u 操作用户；自动执行时传 {id:null,username:'系统'}
   * @param {object} [opts] { sample, ip }
   */
  function runStorageCheck(u, opts = {}) {
    const sampleSize = Math.max(1, Math.min(500, Number(opts.sample) || Number(numbering.getSetting(q, 'storage.fixity_sample', '20')) || 20));
    const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');

    // ① 介质空间
    let totalBytes = 0;
    let freeBytes = 0;
    try {
      const st = fs.statfsSync(dataDir);
      totalBytes = Number(st.blocks) * Number(st.bsize);
      freeBytes = Number(st.bavail) * Number(st.bsize);
    } catch (_) { /* 取不到就不报空间问题 */ }
    // ② 数据库完整性（SQLite 自带的 integrity_check 是权威口径）
    let dbIntegrity = false;
    let dbIntegrityMsg = '';
    try {
      const r = q.raw.prepare('PRAGMA integrity_check').get();
      const v = r ? Object.values(r)[0] : '';
      dbIntegrity = String(v).toLowerCase() === 'ok';
      dbIntegrityMsg = String(v);
    } catch (e) { dbIntegrityMsg = e.message; }
    // ③ 审计链
    const chain = verifyLogChain();
    // ④ 附件可读性抽样：重算摘要与登记值比对（这就是长期保存要求的 fixity check）
    //
    // 抽样必须**轮转**，不能只取最近入库的那几件。
    // 原先写的是 `ORDER BY id DESC LIMIT ?`，等于永远只校验最新的 N 个附件 ——
    // 而长期保存真正要防的是**老档案的比特腐坏**：那些档案可能十年都排到一次校验。
    // 这里用 meta 里的游标（`storage.fixity_cursor`，不需要改表结构）从上次结束处继续，
    // 走到末尾就绕回开头；这样每一轮的总覆盖量等于全量附件，且每件都会被轮到。
    const cursor = Number(q.scalar("SELECT value FROM meta WHERE key='storage.fixity_cursor'") || 0);
    const fixityCols = 'SELECT id, archive_id, original_name, rel_path, size, sha256 FROM files';
    let files = q.all(`${fixityCols} WHERE id > ? ORDER BY id LIMIT ?`, cursor, sampleSize);
    let fixityWrapped = false;
    if (files.length < sampleSize) {
      const more = q.all(`${fixityCols} WHERE id <= ? ORDER BY id LIMIT ?`, cursor, sampleSize - files.length);
      if (more.length) files = files.concat(more);
      // 已经走到末尾并绕回开头 → 下一轮从 0 开始（完整覆盖一轮）
      fixityWrapped = files.length > 0;
    }
    const fixityTotal = Number(q.scalar('SELECT COUNT(*) FROM files') || 0);
    const nextCursor = fixityWrapped ? 0 : (files.length ? files[files.length - 1].id : 0);
    try {
      q.run("INSERT INTO meta(key,value) VALUES('storage.fixity_cursor',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        String(nextCursor));
    } catch (_) { /* 游标写不进去不影响本次检测 */ }
    let fixityChecked = 0;
    let fixityFailed = 0;
    const badFiles = [];
    for (const f of files) {
      try {
        const abs = absPath(filesRoot, f.rel_path);
        if (!fs.existsSync(abs)) { fixityFailed++; badFiles.push(`${f.original_name}：实体缺失`); continue; }
        const got = sha256(fs.readFileSync(abs));
        fixityChecked++;
        if (f.sha256 && got !== f.sha256) { fixityFailed++; badFiles.push(`${f.original_name}：摘要不符`); }
      } catch (e) { fixityFailed++; badFiles.push(`${f.original_name}：${e.message}`); }
    }
    // ⑤ 介质状态
    const media = q.all('SELECT * FROM backup_media');
    const mediaBad = media.filter((m) => m.condition === '不可用');

    let dbBytes = 0;
    try { dbBytes = fs.statSync(path.join(dataDir, 'archive.db')).size; } catch (_) { /* ignore */ }
    const fileStats = dirStats(filesRoot);

    const warnings = [];
    const warnRatio = Number(numbering.getSetting(q, 'storage.warn_free_ratio', '10')) || 10;
    if (totalBytes && (freeBytes / totalBytes) * 100 < warnRatio) {
      warnings.push({ type: 'space', label: '存储空间不足',
        detail: `剩余 ${(freeBytes / 1073741824).toFixed(1)} GB，占 ${((freeBytes / totalBytes) * 100).toFixed(1)}%，低于告警阈值 ${warnRatio}%` });
    }
    if (!dbIntegrity) {
      warnings.push({ type: 'db', label: '数据库完整性异常', detail: dbIntegrityMsg });
    }
    if (!chain.ok) {
      warnings.push({ type: 'audit', label: '审计日志链断开', detail: `断点 id=${chain.broken.id}：${chain.broken.reason}` });
    }
    if (fixityFailed) {
      warnings.push({ type: 'fixity', label: '附件可读性/完整性异常',
        detail: `${fixityFailed} 个附件校验未通过：${badFiles.slice(0, 5).join('；')}` });
    }
    if (mediaBad.length) {
      warnings.push({ type: 'media', label: '备份介质不可用',
        detail: mediaBad.map((m) => m.medium_no).join('、') });
    }
    // 非授权访问：从审计日志里取最近一段时间的越权/拒绝记录（标准明确要求监控这一项）
    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const denied = Number(q.scalar(`SELECT COUNT(*) FROM logs
      WHERE result IN ('拒绝','失败') AND category='security' AND at>=?`, since) || 0);
    if (denied) {
      warnings.push({ type: 'access', label: '近期存在非授权访问尝试',
        detail: `最近 30 天有 ${denied} 条安全类拒绝/失败记录，建议由安全审计员核查（操作日志 → 按分类「安全事件」）` });
    }

    const conclusion = warnings.length
      ? `发现 ${warnings.length} 项需处理：${warnings.map((w) => w.label).join('、')}`
      : '保管状况正常：介质空间充足、数据库完整、审计链完整、抽样附件可读、介质状态良好';
    const checkNo = nextStorageCheckNo();
    let id = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO storage_checks(check_no,total_bytes,free_bytes,db_bytes,files_bytes,
                        db_integrity,chain_ok,fixity_ok,fixity_checked,fixity_failed,media_total,media_bad,
                        warning_count,warnings,conclusion,operator_id,operator,created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        checkNo, totalBytes, freeBytes, dbBytes, fileStats.bytes,
        dbIntegrity ? 1 : 0, chain.ok ? 1 : 0, fixityFailed ? 0 : 1,
        fixityChecked, fixityFailed, media.length, mediaBad.length,
        warnings.length, JSON.stringify(warnings), conclusion, u.id, u.username, nowIso());
      id = r.lastInsertRowid;
    });
    log(u, '保管状况检测', checkNo, conclusion, opts.ip || '',
      { category: 'system', result: warnings.length ? '失败' : '成功', step: '保管状况检测' });
    return {
      id, check_no: checkNo, total_bytes: totalBytes, free_bytes: freeBytes,
      db_bytes: dbBytes, files_bytes: fileStats.bytes,
      db_integrity: dbIntegrity, chain_ok: chain.ok,
      fixity_checked: fixityChecked, fixity_failed: fixityFailed, bad_files: badFiles,
      fixity_total: fixityTotal, fixity_cursor: nextCursor, fixity_wrapped: fixityWrapped,
      media_total: media.length, media_bad: mediaBad.length,
      denied_recent: denied, warnings, conclusion,
    };
  }

  route('POST', '/api/storage/check', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const b = await readJson(req);
    ok(res, runStorageCheck(u, { sample: b.sample, ip: clientIp(req) }));
  });

  /** 存储状况概览（含最近一次检测结论与实时告警） */
  route('GET', '/api/storage/status', async (req, res) => {
    const u = requireCan(req, res, 'backup');
    if (!u) return;
    const dataDir = (config && config.dataDir) ? config.dataDir : path.join(appRoot, 'data');
    let totalBytes = 0;
    let freeBytes = 0;
    try {
      const st = fs.statfsSync(dataDir);
      totalBytes = Number(st.blocks) * Number(st.bsize);
      freeBytes = Number(st.bavail) * Number(st.bsize);
    } catch (_) { /* ignore */ }
    const intervalDays = Number(numbering.getSetting(q, 'storage.check_interval_days', '30')) || 30;
    const warnRatio = Number(numbering.getSetting(q, 'storage.warn_free_ratio', '10')) || 10;
    const last = q.get('SELECT * FROM storage_checks ORDER BY id DESC LIMIT 1');
    const lastDays = last ? Math.floor((Date.now() - Date.parse(last.created_at)) / 86400000) : null;
    const files = dirStats(filesRoot);
    const alarms = [];
    const freeRatio = totalBytes ? (freeBytes / totalBytes) * 100 : 100;
    if (freeRatio < warnRatio) {
      alarms.push({ level: 'error', type: 'space', label: '存储空间不足',
        detail: `剩余 ${(freeBytes / 1073741824).toFixed(1)} GB（${freeRatio.toFixed(1)}%）` });
    } else if (freeRatio < warnRatio * 2) {
      alarms.push({ level: 'warn', type: 'space', label: '存储空间偏紧',
        detail: `剩余 ${(freeBytes / 1073741824).toFixed(1)} GB（${freeRatio.toFixed(1)}%）` });
    }
    if (!last) alarms.push({ level: 'warn', type: 'check', label: '从未做过保管状况检测', detail: '建议立即执行一次' });
    else if (lastDays > intervalDays) {
      alarms.push({ level: 'warn', type: 'check', label: '保管状况检测超期',
        detail: `最近一次在 ${lastDays} 天前，周期为 ${intervalDays} 天` });
    }
    const mediaBad = q.all("SELECT medium_no, condition FROM backup_media WHERE condition<>'良好'");
    for (const m of mediaBad) {
      alarms.push({ level: m.condition === '不可用' ? 'error' : 'warn', type: 'media', label: `介质「${m.medium_no}」${m.condition}`, detail: '' });
    }
    ok(res, {
      total_bytes: totalBytes, free_bytes: freeBytes,
      free_ratio: Number(freeRatio.toFixed(1)),
      db_bytes: (() => { try { return fs.statSync(path.join(dataDir, 'archive.db')).size; } catch (_) { return 0; } })(),
      files_bytes: files.bytes, files_count: files.files,
      warn_ratio: warnRatio, interval_days: intervalDays,
      last_check: last || null, last_check_days: lastDays,
      alarms, alarm_count: alarms.length,
      history: q.all('SELECT check_no, created_at, conclusion, warning_count, fixity_failed, free_bytes FROM storage_checks ORDER BY id DESC LIMIT 12'),
    });
  });

  // ===== 系统信息 =====
  route('GET', '/api/system/info', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const storage = dirStats(filesRoot);
    let dbSize = 0;
    try { dbSize = fs.statSync(path.join(appRoot, 'data', 'archive.db')).size; } catch (_) { /* ignore */ }
    ok(res, {
      version: config.version,
      nodeVersion: process.version,
      platform: process.platform,
      appRoot,
      dataDir: path.join(appRoot, 'data'),
      filesRoot,
      dbSize,
      storageFiles: storage.files,
      storageBytes: storage.bytes,
      startedAt: config.startedAt,
      uptimeSeconds: Math.floor(process.uptime()),
      sessions: sessions.size(),
      archives: Number(q.scalar('SELECT COUNT(*) FROM archives') || 0),
      users: Number(q.scalar('SELECT COUNT(*) FROM users') || 0),
      lastBackupHint: '建议每月导出一次全库备份（系统管理 → 数据备份）',
      // v4.27.0：手机号找回口令的通道状态。
      // 放在这里而不是新增一个"短信设置"页：管理员排障时第一站就是「系统信息」，
      // 而需要知道的就是一句话 —— 通道配没配、缺哪几项、开关在不在。
      smsLogin: {
        enabled: smsEnabled(),
        provider: sms.describe().provider,
        configured: sms.describe().configured,
        missing: sms.describe().missing,
        codeTtlMinutes: smsNum('security.sms_code_ttl_minutes', 5),
        dailyLimit: smsNum('security.sms_daily_limit', 5),
      },
      // v4.31.0：邮箱找回通道状态（单位一般开得起邮件，短信要资质和费用）
      mailLogin: {
        enabled: recEnabled('email'),
        provider: mail.describe().provider,
        configured: mail.describe().configured,
        missing: mail.describe().missing,
        from: mail.describe().from,
        tlsMode: mail.describe().tlsMode,
        codeTtlMinutes: recNum('email', 'code_ttl_minutes', 5),
        dailyLimit: recNum('email', 'daily_limit', 5),
      },
    });
  });

  // ============================================================
  // 档号规则与设置
  // ============================================================
  function allSettings() {
    const out = {};
    for (const r of q.all('SELECT key, value FROM settings')) out[r.key] = r.value;
    return out;
  }

  function setSetting(key, value) {
    q.run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, value);
  }

  route('GET', '/api/settings', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    ok(res, { settings: allSettings() });
  });

  route('PUT', '/api/settings', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const b = await readJson(req);
    const incoming = b && typeof b.settings === 'object' ? b.settings : b;
    const allowed = [
      'archive.unit_code', 'archive.unit_name', 'archive.code_template', 'archive.catalog_no',
      'loans.auto_return', 'loans.remind_days', 'appraisal.warn_years',
      'qr.base_url', 'qr.mode', 'qr.scan_public', 'qr.engine', 'qr.border', 'qr.box_size',
      'qr.archive_mode', 'qr.scan_show_title',
      // v4 安全与合规
      'security.enforce_secret', 'security.three_roles',
      'security.login_max_fail', 'security.login_lock_minutes',
      'security.password_min_length', 'security.log_retain_days',
      // v7 登录防护与口令策略
      'security.login_rate_per_minute', 'security.password_require_complexity',
      'security.login_attempts_keep_days', 'security.csrf_origin_check',
      // v4.27.0 手机号找回口令（短信验证码）
      'security.sms_login', 'security.sms_code_ttl_minutes', 'security.sms_resend_seconds',
      'security.sms_daily_limit', 'security.sms_max_attempts', 'security.sms_ticket_ttl_minutes',
      // v4.31.0 邮箱找回口令（邮件验证码）：数值项默认沿用 sms_*，需要单独调时再写 email_*
      'security.email_login', 'security.email_code_ttl_minutes', 'security.email_resend_seconds',
      'security.email_daily_limit', 'security.email_max_attempts', 'security.email_ticket_ttl_minutes',
      // v5 实体管理合规
      'box.enforce_mix',
      // v8 四性检测
      'detection.enforce_transfer', 'detection.auto_on_upload', 'detection.yearly_days',
      // v9 元数据方案
      'metadata.warn_incomplete', 'metadata.enforce_immutable',
      // v10 归档章与备考表
      'box.spine_mm_default',
      // v11 借阅强化
      'loan.default_read_hours', 'loan.enforce_read_window',
      'download.require_approval', 'download.default_valid_hours', 'download.max_times_default',
      'watermark.enabled', 'watermark.template',
      // v12 备份合规与存储状况监控
      'backup.required_copies', 'backup.required_media_types',
      'backup.require_offline', 'backup.require_offsite', 'backup.default_dir',
      'storage.check_interval_days', 'storage.warn_free_ratio', 'storage.fixity_sample',
      // v4.11.0 检索智能化：OCR 适配层（**只配置怎么调用本机已装的引擎，不会去下载引擎**）
      'ocr.mode', 'ocr.engine', 'ocr.engine_path', 'ocr.raster_path', 'ocr.lang',
      'ocr.timeout_ms', 'ocr.dpi', 'ocr.max_pages', 'ocr.max_mb',
      // v4.33.0 授权与外存：审计镜像目录（空=只写本机 data/audit-anchor）
      'audit.mirror_dir', 'audit.anchor_hours',
    ];
    // 三员分立：安全策略（security.*）归系统安全保密员，其余系统参数归系统管理员。
    // 原实现用 requireRole('admin') 一刀切，结果系统管理员连普通参数都改不了 ——
    // 三员分立的意义是"分工"，不是"谁都干不了"。
    const keys = Object.keys(incoming || {}).filter((k) => allowed.includes(k));
    const touchesSecurity = keys.some((k) => k.startsWith('security.'));
    const touchesOther = keys.some((k) => !k.startsWith('security.'));
    if (touchesSecurity && !policy.can(u, 'security:manage')) {
      return fail(res, 403, '修改安全策略需要「系统安全保密员」权限（三员分立）', 'FORBIDDEN');
    }
    if (touchesOther && !policy.can(u, 'system:manage')) {
      return fail(res, 403, '修改系统参数需要「系统管理员」权限', 'FORBIDDEN');
    }
    if (!keys.length) return fail(res, 400, '没有可修改的设置项（请检查键名是否在允许范围内）');
    const changed = [];
    // 二维码网址前缀先校验再落库。
    // 拦死的只有「任何别的设备都打不开」的地址（127.x / localhost / 0.0.0.0 / 169.254.x）。
    // 内网地址（10.x / 172.16-31.x / 192.168.x / 内网域名）**允许保存**并给提示 ——
    // 政务内网/局域网部署时，那就是唯一能用的地址，拦掉等于让功能不可用。
    if (incoming && Object.prototype.hasOwnProperty.call(incoming, 'qr.base_url')) {
      const v = String(incoming['qr.base_url'] || '').trim();
      if (v) {
        const c = qrContent.classifyBase(v);
        if (!c.ok) return fail(res, 400, `二维码网址前缀不能用：${c.reason}。当前填的是 ${v}`);
      }
    }
    for (const [k, v] of Object.entries(incoming || {})) {
      if (!allowed.includes(k)) continue;
      const val = mustStr(v, 200);
      // 开关类只能是 0/1；数值类必须落在合理区间。
      // 静默接受 "yes"/"true" 之类会让管理员以为开关生效了，实际没生效。
      if (['security.enforce_secret', 'security.three_roles', 'box.enforce_mix',
        'loans.auto_return', 'qr.scan_public',
        'security.password_require_complexity', 'security.csrf_origin_check',
        'security.sms_login',
        'security.email_login',
        'detection.enforce_transfer', 'detection.auto_on_upload',
        'metadata.warn_incomplete', 'metadata.enforce_immutable',
        'loan.enforce_read_window', 'download.require_approval', 'watermark.enabled',
        'backup.require_offline', 'backup.require_offsite'].includes(k)
        && !['0', '1'].includes(val)) {
        return fail(res, 400, `${k} 只能是 0 或 1（当前传入「${val}」）`);
      }
      const ranges = {
        'security.login_max_fail': [0, 100],
        'security.login_lock_minutes': [0, 1440],
        'security.password_min_length': [6, 64],
        'security.log_retain_days': [0, 36500],
        'security.login_rate_per_minute': [0, 600],
        'security.login_attempts_keep_days': [0, 3650],
        // 验证码类参数一律给上下限：ttl 太短等于收不到，太长等于码可以放着慢慢猜
        'security.sms_code_ttl_minutes': [1, 30],
        'security.sms_resend_seconds': [0, 600],
        'security.sms_daily_limit': [0, 100],
        'security.sms_max_attempts': [0, 20],
        'security.sms_ticket_ttl_minutes': [1, 60],
        'security.email_code_ttl_minutes': [1, 30],
        'security.email_resend_seconds': [0, 600],
        'security.email_daily_limit': [0, 100],
        'security.email_max_attempts': [0, 20],
        'security.email_ticket_ttl_minutes': [1, 60],
        'detection.yearly_days': [30, 3650],
        'loan.default_read_hours': [1, 8760],
        'download.default_valid_hours': [1, 8760],
        'download.max_times_default': [1, 99],
        'backup.required_copies': [1, 10],
        'backup.required_media_types': [1, 6],
        'storage.check_interval_days': [1, 3650],
        'storage.warn_free_ratio': [1, 50],
        'storage.fixity_sample': [1, 500],
        'loans.remind_days': [0, 90],
        'appraisal.warn_years': [0, 10],
        'ocr.timeout_ms': [5000, 1800000],
        'ocr.dpi': [72, 600],
        'ocr.max_pages': [1, 2000],
        'ocr.max_mb': [1, 2048],
        'qr.border': [4, 16],
        'qr.box_size': [4, 40],
      };
      if (ranges[k]) {
        const n = Number(val);
        const [lo, hi] = ranges[k];
        if (!Number.isFinite(n) || n < lo || n > hi) {
          return fail(res, 400, `${k} 需为 ${lo}~${hi} 之间的整数（当前传入「${val}」）`);
        }
      }
      // 枚举类设置：盒脊厚度只有 20/30/40/50 四种规格（DA/T 22—2015 §6.4）
      if (k === 'box.spine_mm_default' && ![20, 30, 40, 50].includes(Number(val))) {
        return fail(res, 400, '盒脊厚度默认值只能是 20 / 30 / 40 / 50 mm（DA/T 22—2015 §6.4）');
      }
      // OCR 模式只有两档：auto（探测到引擎就用）与 none（明确关闭，不调用任何外部程序）
      if (k === 'ocr.mode' && !['auto', 'none'].includes(val)) {
        return fail(res, 400, 'ocr.mode 只能是 auto（探测到就用）或 none（关闭）');
      }
      // 引擎选择：auto 时优先用 Windows 自带（零安装），也可明确指定
      if (k === 'ocr.engine' && !['auto', 'windows', 'tesseract', 'ocrmypdf'].includes(val)) {
        return fail(res, 400, 'ocr.engine 只能是 auto / windows / tesseract / ocrmypdf');
      }
      // OCR 引擎路径必须是真实存在的文件：填错了却保存成功，用户会以为"配好了但没用"
      if ((k === 'ocr.engine_path' || k === 'ocr.raster_path') && val) {
        if (!path.isAbsolute(val)) return fail(res, 400, `${k} 需要填绝对路径（当前传入「${val}」）`);
        if (!fs.existsSync(val)) return fail(res, 400, `${k} 指向的文件不存在：${val}`);
      }
      setSetting(k, val);
      changed.push(k);
    }
    // 模板必须合法，否则后续无法自动编号
    const tpl = q.scalar("SELECT value FROM settings WHERE key='archive.code_template'");
    const tplType = q.get("SELECT code_template FROM archive_types WHERE code_template<>''");
    if (tpl) {
      const v = numbering.validateTemplate(tpl);
      if (!v.ok) return fail(res, 400, '全局档号模板不合法：' + v.error);
    }
    if (tplType) {
      const v = numbering.validateTemplate(tplType.code_template);
      if (!v.ok) return fail(res, 400, `门类 ${tplType.code}' 的档号模板不合法：` + v.error);
    }
    // 提示（不拦截）：内网地址的二维码只有同一内网能打开 —— 内网部署时这是正常的
    let warning = '';
    const baseVal = settingOf('qr.base_url', '');
    if (baseVal) {
      const c = qrContent.classifyBase(baseVal);
      if (c.kind === 'private') {
        warning = `二维码网址前缀是内网地址（${baseVal}）：同一内网（政务内网/局域网）里的手机和电脑能打开，`
          + '连不上这个内网的设备打不开。内网部署用这个地址是正确的，无需修改。';
      }
      if (c.kind === 'loopback') {
        warning = `二维码网址前缀是本机地址（${baseVal}），只有这台电脑自己能打开，手机一定打不开。`
          + '请改成这台机器在内网里的地址（如 http://10.x.x.x:8787）或内网域名。';
      }
    }
    // OCR 相关设置改了就把探测缓存清掉：否则刚填好 engine_path，界面还显示"没探测到引擎"，
    // 用户会以为填错了 —— 这类"看起来没生效"最消耗信任
    if (changed.some((k) => k.startsWith('ocr.'))) {
      ocrLib.reset();
      const det = ocrDetect(true);
      const ver = (det.tesseract && det.tesseract.version) || (det.ocrmypdf && det.ocrmypdf.version) || '';
      warning += (warning ? '　' : '') + (det.available
        ? `OCR 引擎已就绪：${det.engine}${ver ? ' ' + ver : ''}`
        : `OCR 引擎仍不可用：${det.reason || ''}`);
    }
    log(u, '修改系统设置', changed.join(', '), '', clientIp(req));
    ok(res, { settings: allSettings(), changed, warning });
  });

  route('POST', '/api/settings/check-template', async (req, res) => {
    // 档号模板属于系统参数，归系统管理员（三员分立）
    const u = requireCan(req, res, 'system:manage');
    if (!u) return;
    const b = await readJson(req);
    const tpl = mustStr(b.template, 200).trim();
    const v = numbering.validateTemplate(tpl);
    const presets = {
      dat22: numbering.PRESET_DAT22,
      simple: numbering.PRESET_SIMPLE,
      legacy: numbering.PRESET_LEGACY,
    };
    if (!v.ok) return ok(res, { valid: false, error: v.error, preview: '', presets });
    const typeCode = mustStr(b.type_code, 16) || (q.scalar('SELECT code FROM archive_types ORDER BY sort_no LIMIT 1') || 'WS');
    const catId = Number(b.category_id) || null;
    const year = mustStr(b.year, 8) || String(new Date().getFullYear());
    // 与著录、档号预览同口径：没指定保管期限时回退到**门类默认值**。
    // 不回退的话，含 {retention} 的模板预览会显示成空段（Z001-WS·2026--DQ-0001），
    // 看起来像模板有问题 —— 其实只是没传这个参数。
    let retentionName = mustStr(b.retention, 20);
    let retentionCode = mustStr(b.retention_code, 10);
    if (!retentionName && !retentionCode) {
      const tr = q.get('SELECT retention FROM archive_types WHERE code=?', typeCode);
      retentionName = tr ? String(tr.retention || '') : '';
    }
    if (!retentionCode) retentionCode = RETENTION_MAP[retentionName] ? RETENTION_MAP[retentionName].code : '';
    let preview = '';
    let ctx = null;
    try {
      ctx = numbering.buildContext(q, {
        typeCode, year, categoryId: catId, retentionCode,
        categoryCode: mustStr(b.category_code, 40),
      });
      preview = numbering.render(tpl, ctx);
    } catch (e) { return ok(res, { valid: false, error: e.message, preview: '', presets }); }

    // 预览的是**模板**，所以这里不拦空段（用户还在编辑模板，看到"这段现在填不上"才是有用的）。
    // 但要说清楚：正式著录时若这些信息仍然缺，系统会拒绝出号。
    const gaps = numbering.unfilledSegments(tpl, ctx);
    const warnings = (v.warnings || []).slice();
    if (gaps.length) {
      warnings.push(`当前预览里「${gaps.map((g) => g.label).join('、')}」取不到值 —— `
        + '模板本身可以用，但正式著录时如果这些信息仍然缺，系统会拒绝生成空段档号（如 Z001-HT·2037--CG-0001）。'
        + '请确认这些信息在著录时一定能填上。');
    }
    ok(res, {
      valid: true,
      error: '',
      preview,
      unfilled: gaps,
      placeholders: numbering.PLACEHOLDERS,
      // 标准符合性提示：只告知差距，不阻断（既有单位可能沿用旧编号体系）
      warnings,
      compliant: !!v.compliant,
      structure: '全宗号-档案门类代码·年度-保管期限-机构(问题)代码-件号（DA/T 22—2015 §5.4）',
      presets,
    });
  });

  // ============================================================
  // 保管期限到期与鉴定
  // ============================================================
  /** 档案员及以上可鉴定 */
  route('GET', '/api/retention/due', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const sp = url.searchParams;
    const thisYear = new Date().getFullYear();
    const warnYears = Number(q.scalar("SELECT value FROM settings WHERE key='appraisal.warn_years'")) || 1;
    const fromYear = Number(sp.get('from')) || (thisYear - warnYears);
    const toYear = Number(sp.get('to')) || thisYear;
    const exact = sp.get('exact') === '1';
    const where = exact
      ? ['a.retention_due_year = ?', 'a.retention_years > 0']
      : ['a.retention_due_year BETWEEN ? AND ?', 'a.retention_years > 0'];
    const args = exact ? [toYear] : [fromYear, toYear];
    if (sp.get('type')) { where.push('a.type_code = ?'); args.push(sp.get('type')); }
    if (sp.get('status')) { where.push('a.status = ?'); args.push(sp.get('status')); } else { where.push("a.status NOT IN ('已销毁')"); }
    // 到期清单会列出档号与题名，必须按密级过滤
    const sc = secretScope(u);
    if (sc.sql) { where.push(sc.sql.replace(/^ AND /, '')); args.push(...sc.params); }
    const w = ' WHERE ' + where.join(' AND ');
    const list = q.all(
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.type_code, a.retention, a.retention_code,
              a.retention_years, a.retention_due_year, a.year, a.status, a.open_state, a.location,
              c.name AS category_name,
              (SELECT MAX(appraised_at) FROM appraisals p WHERE p.archive_id=a.id) AS last_appraised,
              (SELECT decision FROM appraisals p WHERE p.archive_id=a.id ORDER BY id DESC LIMIT 1) AS last_decision
       FROM archives a LEFT JOIN categories c ON c.id=a.category_id ${w}
       ORDER BY a.retention_due_year, a.archive_code LIMIT 500`, ...args,
    );
    const counts = {
      overdue: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year>0 AND a.retention_due_year < ?${sc.sql}`, thisYear, ...sc.params) || 0),
      thisYear: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year = ?${sc.sql}`, thisYear, ...sc.params) || 0),
      nextYear: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year = ?${sc.sql}`, thisYear + 1, ...sc.params) || 0),
      permanent: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention IN ('永久','长期')${sc.sql}`, ...sc.params) || 0),
    };
    ok(res, { list, total: list.length, counts, range: { from: fromYear, to: toYear }, thisYear, warnYears });
  });

  route('GET', '/api/retention/summary', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    // 汇总口径同样按密级过滤（数量本身就是涉密信息）
    const sc = secretScope(u);
    const byYear = q.all(`SELECT retention_due_year AS year, COUNT(*) AS count FROM archives a
                          WHERE a.retention_years>0 AND a.retention_due_year>0${sc.sql}
                          GROUP BY retention_due_year ORDER BY year`, ...sc.params);
    const byRetention = q.all(`SELECT retention, retention_code, COUNT(*) AS count FROM archives a
                               WHERE 1=1${sc.sql} GROUP BY retention ORDER BY count DESC`, ...sc.params);
    ok(res, { byYear, byRetention });
  });

  route('GET', '/api/archives/:id/appraisals', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    const list = q.all(`SELECT p.*, u.display_name AS appraiser_name FROM appraisals p
                        LEFT JOIN users u ON u.id=p.appraiser_id WHERE p.archive_id=? ORDER BY p.id DESC`, id);
    ok(res, { list });
  });

  // 单件鉴定（POST /api/archives/:id/appraise）见下方「鉴定扩展（v4.10.0）」一节：
  // 那里的实现同时支持价值/密级/开放三种鉴定，并且是批次接口共用的同一份核心。
  // 早期只支持价值鉴定的那一版已删除 —— 两份同名路由只会让先注册的那份悄悄生效。

  // ============================================================
  // 销毁清册与审批
  // ============================================================
  function nextDestructionNo() {
    const d = new Date();
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`;
    const key = `destroyseq:${day}`;
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0) + 1;
    q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(cur));
    return `XS${day}-${String(cur).padStart(3, '0')}`;
  }

  route('GET', '/api/destructions', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (sp.get('status')) { where.push('d.status=?'); args.push(sp.get('status')); }
    const w = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const list = q.all(`SELECT d.*, (SELECT COUNT(*) FROM destruction_items i WHERE i.destruction_id=d.id) AS item_count
                        FROM destructions d ${w} ORDER BY d.id DESC LIMIT 200`, ...args);
    const counts = {
      pending: Number(q.scalar("SELECT COUNT(*) FROM destructions WHERE status='待审批'") || 0),
      approved: Number(q.scalar("SELECT COUNT(*) FROM destructions WHERE status='已批准'") || 0),
      done: Number(q.scalar("SELECT COUNT(*) FROM destructions WHERE status='已销毁'") || 0),
      candidate: Number(q.scalar("SELECT COUNT(*) FROM archives WHERE status='待销毁'") || 0),
    };
    ok(res, { list, counts });
  });

  route('GET', '/api/destructions/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const d = q.get('SELECT * FROM destructions WHERE id=?', Number(params.id));
    if (!d) return fail(res, 404, '销毁批次不存在');
    d.items = q.all('SELECT * FROM destruction_items WHERE destruction_id=? ORDER BY id', d.id);
    ok(res, d);
  });

  route('POST', '/api/destructions', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    let ids = Array.isArray(b.archive_ids) ? b.archive_ids.map(Number).filter(Boolean) : [];
    // 销毁是不可逆动作，密级约束必须最严：显式 ids 与"全部待销毁"两条路径都要过滤，
    // 否则低密级档案员可以借"提交销毁清册"把涉密档案一并送进销毁流程。
    const sec = secretScope(u);
    if (!ids.length) {
      // 未指定则取全部“待销毁”（限自己可见范围）
      ids = q.all(`SELECT a.id FROM archives a WHERE a.status='待销毁'${sec.sql}`, ...sec.params).map((r) => r.id);
    } else {
      const holes = ids.map(() => '?').join(',');
      const allow = new Set(
        q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${sec.sql}`, ...ids, ...sec.params)
          .map((r) => Number(r.id)),
      );
      const before = ids.length;
      ids = ids.filter((id) => allow.has(id));
      if (ids.length !== before) {
        log(u, '销毁清册跳过无权档案', `${before - ids.length} 条`, '超出账号密级上限', clientIp(req),
          { result: '拒绝', category: 'security', step: '密级鉴别' });
      }
      if (!ids.length) return fail(res, 403, '所选档案均超出你的密级权限范围');
    }
    if (!ids.length) return fail(res, 400, '没有可提交销毁的档案，请先在“到期与鉴定”中对档案作出“建议销毁”结论');
    const items = [];
    for (const id of ids) {
      const a = q.get('SELECT * FROM archives WHERE id=?', id);
      if (!a) continue;
      if (a.status === '已销毁') continue;
      const active = q.scalar(`SELECT COUNT(*) FROM loans WHERE archive_id=? AND status IN ('已批准','逾期')`, id);
      if (active) return fail(res, 400, `档案 ${a.archive_code} 有未归还的借出记录，不能列入销毁清册`);
      items.push(a);
    }
    if (!items.length) return fail(res, 400, '所选档案均不可销毁');
    const batchNo = nextDestructionNo();
    let batchId = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO destructions(batch_no,title,archive_count,reason,basis,status,
                        applicant_id,applicant,applied_at,created_at)
                       VALUES(?,?,?,?,?,'待审批',?,?,?,?)`,
        batchNo, mustStr(b.title, 100) || `销毁批次 ${batchNo}`, items.length,
        mustStr(b.reason, 500), mustStr(b.basis, 500), u.id, u.display_name || u.username, nowIso(), nowIso());
      batchId = r.lastInsertRowid;
      for (const a of items) {
        q.run(`INSERT INTO destruction_items(destruction_id,archive_id,archive_code,archive_number,title,
                 type_code,year,retention,action) VALUES(?,?,?,?,?,?,?,?,'待销毁')`,
          batchId, a.id, a.archive_code, a.archive_number || '', a.title, a.type_code, a.year, a.retention);
      }
    });
    log(u, '提交销毁清册', batchNo, `${items.length} 件`, clientIp(req));
    ok(res, { id: batchId, batch_no: batchNo, count: items.length });
  });

  route('POST', '/api/destructions/:id/approve', async (req, res, params) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const id = Number(params.id);
    const d = q.get('SELECT * FROM destructions WHERE id=?', id);
    if (!d) return fail(res, 404, '销毁批次不存在');
    if (d.status !== '待审批') return fail(res, 400, `该批次状态为「${d.status}」，无法审批`);
    const b = await readJson(req);
    const agree = b.approve !== false;
    const supervisor = mustStr(b.supervisor, 60);
    if (agree && !supervisor) return fail(res, 400, '批准销毁必须指定监销人（按档案管理规定需有监销人在场）');
    q.run(`UPDATE destructions SET status=?, approver_id=?, approver=?, approved_at=?, approve_note=?,
           supervisor=?, witness=? WHERE id=?`,
      agree ? '已批准' : '已拒绝', u.id, u.display_name || u.username, nowIso(),
      mustStr(b.note, 300), supervisor, mustStr(b.witness, 60), id);
    if (!agree) {
      for (const it of q.all('SELECT archive_id FROM destruction_items WHERE destruction_id=?', id)) {
        q.run("UPDATE archives SET status='在库', status_note=?, updated_at=? WHERE id=? AND status='待销毁'",
          '销毁申请被否决，退回在库', nowIso(), it.archive_id);
      }
    }
    log(u, agree ? '批准销毁' : '否决销毁', d.batch_no, mustStr(b.note, 100), clientIp(req));
    ok(res, { status: agree ? '已批准' : '已拒绝' });
  });

  route('POST', '/api/destructions/:id/execute', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const d = q.get('SELECT * FROM destructions WHERE id=?', id);
    if (!d) return fail(res, 404, '销毁批次不存在');
    if (d.status !== '已批准') return fail(res, 400, `只有「已批准」的批次可以执行销毁，当前为「${d.status}」`);
    const b = await readJson(req);
    const supervisor = mustStr(b.supervisor, 60) || d.supervisor;
    if (!supervisor) return fail(res, 400, '请填写监销人');
    const items = q.all('SELECT * FROM destruction_items WHERE destruction_id=?', id);
    const filesToRemove = [];
    const qrToRemove = [];
    q.tx(() => {
      for (const it of items) {
        if (it.action === '已销毁') continue;
        for (const f of q.all('SELECT rel_path FROM files WHERE archive_id=?', it.archive_id)) filesToRemove.push(f.rel_path);
        // 销毁的档案也要把它的二维码图片带走，否则 qrcodes 目录会攒下一批孤儿图片
        const row = q.get('SELECT id, archive_number, archive_code, title FROM archives WHERE id=?', it.archive_id);
        if (row) {
          row.qrName = archiveQrLib.plannedBaseName(db, row);
          qrToRemove.push(row);
        }
        q.run('DELETE FROM files WHERE archive_id=?', it.archive_id);
        q.run('DELETE FROM loans WHERE archive_id=?', it.archive_id);
        // 保留条目作为销毁凭据，清空与档案表的关联值
        q.run("UPDATE destruction_items SET action='已销毁' WHERE id=?", it.id);
        q.run('DELETE FROM archives WHERE id=?', it.archive_id);
      }
      q.run(`UPDATE destructions SET status='已销毁', destroyed_at=?, destroy_note=?, supervisor=?, witness=?,
             archive_count=? WHERE id=?`,
        nowIso(), mustStr(b.note, 300), supervisor, mustStr(b.witness, 60) || d.witness, items.length, id);
    });
    for (const rel of filesToRemove) removeStored(filesRoot, rel);
    for (const row of qrToRemove) {
      try { archiveQrLib.removeOne(row, qrDir(), row.qrName); } catch (_) { /* 删不掉不影响销毁流程 */ }
    }
    log(u, '执行销毁', d.batch_no, `${items.length} 件，监销人 ${supervisor}`, clientIp(req));
    ok(res, { destroyed: items.length });
  });

  route('GET', '/api/destructions/:id/print', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const d = q.get('SELECT * FROM destructions WHERE id=?', Number(params.id));
    if (!d) return fail(res, 404, '销毁批次不存在');
    const items = q.all('SELECT * FROM destruction_items WHERE destruction_id=? ORDER BY id', d.id);
    const rows = items.map((it, i) => `<tr>
      <td>${i + 1}</td><td>${esc(it.archive_number || '')}</td><td>${esc(it.archive_code)}</td>
      <td>${esc(it.title)}</td><td>${esc(it.type_code)}</td><td>${esc(it.year)}</td>
      <td>${esc(it.retention)}</td><td>${esc(it.action)}</td></tr>`).join('');
    const html = printShell(`销毁清册 ${esc(d.batch_no)}`, `
      <div class="print-head"><h1>档 案 销 毁 清 册</h1><div class="meta">
        批次号：${esc(d.batch_no)}　批次名称：${esc(d.title)}<br>
        申请单位：${esc(q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '')}　
        申请人：${esc(d.applicant)}　申请日期：${esc(fmtDay(d.applied_at))}<br>
        销毁依据：${esc(d.basis || d.reason || '')}</div></div>
      <table class="print-table"><thead><tr>
        <th style="width:44px">序号</th><th>档号</th><th>档案号</th><th>题名</th>
        <th style="width:56px">门类</th><th style="width:56px">年度</th><th style="width:76px">保管期限</th>
        <th style="width:64px">状态</th></tr></thead><tbody>${rows}
      </tbody></table>
      <div class="sign-row">
        <div>鉴定小组负责人：____________</div><div>审批人：____________</div>
        <div>监销人：____________</div><div>销毁日期：______年____月____日</div>
      </div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  // ============================================================
  // 鉴定扩展（v4.10.0）：密级鉴定 / 价值鉴定 / 开放鉴定
  //
  // 现行法规要求的是**三种不同的鉴定**，触发条件、结论、依据各不相同：
  //
  //   ① 价值鉴定  触发：保管期限届满        结论：延长保管期限 / 继续保管 / 建议销毁
  //               依据：国家档案局令第 8 号、DA/T 22—2015
  //   ② 密级鉴定  触发：保密期限届满        结论：解密 / 降低密级 / 延长保密期限 / 维持原密级
  //               依据：《保守国家秘密法》第十九条（期满自行解密）、第二十条（需延长的应在
  //                     期限届满前重新确定）；《国家秘密定密管理暂行规定》（定密责任人定期审核）
  //   ③ 开放鉴定  触发：自形成之日起满 25 年  结论：开放 / 部分开放 / 控制使用（延期开放）
  //               依据：《档案法》第二十七条、第二十八条；《各级国家档案馆馆藏档案解密和
  //                     划分控制使用范围的暂行规定》
  //
  // 三者**不能合并成一个"鉴定"按钮**：结论不同、权限不同（解密要定密责任人、开放要馆领导）、
  // 触发时间不同（期限届满 vs 满 25 年）。混在一起的结果就是"到期了顺手点一下"，
  // 而涉密档案该不该解密、满 25 年的档案该不该开放，都是要单独做决定并签字的。
  // ============================================================

  /** 把「保密期限」换算成届满日期；长期 / 条件解密 / 从缺返回 ''（表示"没有确定日期"） */
  function secretDeadline(term, fromIso) {
    const m = /^(\d+)\s*年$/.exec(String(term || '').trim());
    if (!m) return '';
    const from = String(fromIso || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) return '';
    return `${Number(from.slice(0, 4)) + Number(m[1])}${from.slice(4)}`;
  }

  /** 开放鉴定的触发年度 = 形成（归档）年度 + 25；年度不明确返回 0（无法判定，需人工登记年度） */
  function openDueYear(a) {
    const y = Number(a.year) || Number(String(a.archive_date || '').slice(0, 4));
    return y > 0 ? y + OPEN_PUBLIC_YEARS : 0;
  }

  /** 密级鉴定的到期判定：有明确届满日、且已进入提醒窗口 */
  function secretDueState(a, todayIso, warnIso) {
    if (!a.secret_to) return a.secret_level === '公开' ? 'none' : 'noreg';  // 未登记保密期限
    if (a.secret_to <= todayIso) return 'overdue';
    if (a.secret_to <= warnIso) return 'soon';
    return 'ok';
  }

  /**
   * 三鉴工作台：一次性给出三类待鉴定清单与统计。
   *
   * 三个清单都按密级过滤，**数量本身也是涉密信息**（一个秘密级用户不该知道
   * 全库有多少机密件等待解密）。
   */
  route('GET', '/api/appraisals/workbench', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const kind = APPRAISAL_KINDS.includes(url.searchParams.get('kind')) ? url.searchParams.get('kind') : '价值鉴定';
    const thisYear = new Date().getFullYear();
    const today = nowIso().slice(0, 10);
    const warnIso = new Date(Date.now() + SECRET_WARN_DAYS * 86400000).toISOString().slice(0, 10);
    const sc = secretScope(u);
    const scw = sc.sql.replace(/^ AND /, '');
    const visible = (extra = []) => ['a.status NOT IN (\'已销毁\')', ...(scw ? [scw] : []), ...extra];

    // ---------- ① 价值鉴定：保管期限届满 ----------
    const warnYears = Number(q.scalar("SELECT value FROM settings WHERE key='appraisal.warn_years'")) || 1;
    const valueWhere = ` WHERE ${visible([
      'a.retention_years > 0', 'a.retention_due_year > 0', 'a.retention_due_year <= ?',
    ]).join(' AND ')}`;
    const valueList = q.all(
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.type_code, a.retention, a.retention_code,
              a.retention_years, a.retention_due_year, a.year, a.status, a.secret_level, a.open_state,
              c.name AS category_name,
              (SELECT MAX(appraised_at) FROM appraisals p WHERE p.archive_id=a.id AND p.kind='价值鉴定') AS last_appraised,
              (SELECT decision FROM appraisals p WHERE p.archive_id=a.id AND p.kind='价值鉴定' ORDER BY id DESC LIMIT 1) AS last_decision
         FROM archives a LEFT JOIN categories c ON c.id=a.category_id${valueWhere}
        ORDER BY a.retention_due_year, a.archive_code LIMIT 500`, thisYear, ...sc.params);
    const valueCounts = {
      overdue: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year>0 AND a.retention_due_year < ? AND a.status NOT IN ('已销毁')${sc.sql}`, thisYear, ...sc.params) || 0),
      thisYear: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year = ? AND a.status NOT IN ('已销毁')${sc.sql}`, thisYear, ...sc.params) || 0),
      nextYear: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention_years>0 AND a.retention_due_year = ? AND a.status NOT IN ('已销毁')${sc.sql}`, thisYear + 1, ...sc.params) || 0),
      permanent: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.retention IN ('永久','长期') AND a.status NOT IN ('已销毁')${sc.sql}`, ...sc.params) || 0),
      pendingDestroy: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.status='待销毁'${sc.sql}`, ...sc.params) || 0),
    };

    // ---------- ② 密级鉴定：保密期限届满（或从未登记保密期限） ----------
    const secretRows = q.all(
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.type_code, a.year, a.status,
              a.secret_level, a.secret_term, a.secret_from, a.secret_to, a.secret_basis, a.declassify_condition,
              a.open_state, c.name AS category_name,
              (SELECT MAX(appraised_at) FROM appraisals p WHERE p.archive_id=a.id AND p.kind='密级鉴定') AS last_appraised,
              (SELECT decision FROM appraisals p WHERE p.archive_id=a.id AND p.kind='密级鉴定' ORDER BY id DESC LIMIT 1) AS last_decision
         FROM archives a LEFT JOIN categories c ON c.id=a.category_id
        WHERE a.secret_level <> '公开' AND a.status NOT IN ('已销毁')${sc.sql}
        ORDER BY (a.secret_to='') DESC, a.secret_to, a.archive_code LIMIT 500`, ...sc.params);
    const secretList = secretRows.map((r) => Object.assign({}, r, { due_state: secretDueState(r, today, warnIso) }));
    const secretCounts = {
      overdue: secretList.filter((r) => r.due_state === 'overdue').length,
      soon: secretList.filter((r) => r.due_state === 'soon').length,
      noreg: secretList.filter((r) => r.due_state === 'noreg').length,
      total: secretList.length,
      windowDays: SECRET_WARN_DAYS,
    };

    // ---------- ③ 开放鉴定：满 25 年 ----------
    // 触发口径写在 SQL 里（年度 + 25），不能只在内存里算 —— 否则分页/统计会与清单不一致
    const openRows = q.all(
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.type_code, a.year, a.archive_date, a.status,
              a.secret_level, a.secret_to, a.open_state, a.open_review_at, a.open_control_reason, a.open_delay_to,
              a.open_scope_note, c.name AS category_name,
              (SELECT MAX(appraised_at) FROM appraisals p WHERE p.archive_id=a.id AND p.kind='开放鉴定') AS last_appraised,
              (SELECT decision FROM appraisals p WHERE p.archive_id=a.id AND p.kind='开放鉴定' ORDER BY id DESC LIMIT 1) AS last_decision
         FROM archives a LEFT JOIN categories c ON c.id=a.category_id
        WHERE a.status NOT IN ('已销毁')
          AND a.year <> '' AND CAST(a.year AS INTEGER) > 0
          AND CAST(a.year AS INTEGER) + ${OPEN_PUBLIC_YEARS} <= ?${sc.sql}
        ORDER BY a.year, a.archive_code LIMIT 500`, thisYear, ...sc.params);
    const openList = openRows.map((r) => Object.assign({}, r, { open_due_year: openDueYear(r) }));
    const openCounts = {
      pending: openList.filter((r) => r.open_state === '未鉴定').length,
      open: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.open_state='开放' AND a.status NOT IN ('已销毁')${sc.sql}`, ...sc.params) || 0),
      partial: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.open_state='部分开放' AND a.status NOT IN ('已销毁')${sc.sql}`, ...sc.params) || 0),
      controlled: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.open_state='控制使用' AND a.status NOT IN ('已销毁')${sc.sql}`, ...sc.params) || 0),
      notYet: Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.status NOT IN ('已销毁') AND a.year <> '' AND CAST(a.year AS INTEGER) > 0 AND CAST(a.year AS INTEGER) + ${OPEN_PUBLIC_YEARS} > ?${sc.sql}`, thisYear, ...sc.params) || 0),
      publicYears: OPEN_PUBLIC_YEARS,
    };

    const lists = { 价值鉴定: valueList, 密级鉴定: secretList, 开放鉴定: openList };
    const counts = { 价值鉴定: valueCounts, 密级鉴定: secretCounts, 开放鉴定: openCounts };
    ok(res, {
      kind, list: lists[kind] || [], total: (lists[kind] || []).length,
      counts, all_counts: counts, thisYear, today,
      kinds: APPRAISAL_KINDS,
      decisions: { 价值鉴定: VALUE_DECISIONS, 密级鉴定: SECRET_DECISIONS, 开放鉴定: OPEN_DECISIONS },
      openStates: OPEN_STATES, secretTerms: SECRET_TERMS,
      // 批次台账也一并给出，工作台可以少发一次请求
      batches: q.all(`SELECT b.*, (SELECT COUNT(*) FROM appraisals p WHERE p.batch_id=b.id) AS item_count
                        FROM appraisal_batches b ORDER BY b.id DESC LIMIT 100`),
    });
  });

  /**
   * 登记 / 变更定密信息（保密期限、定密依据、解密条件）。这不是"鉴定"，是"定密"：
   * 定密发生在文件形成（或归档）时，而鉴定发生在保密期限届满时 —— 两件事，两个接口。
   *
   * 权限：`secret:classify`（系统安全保密员 / 管理员）。定密责任人制度下，
   * 密级与保密期限不能由经手的档案员自行决定。
   */
  route('POST', '/api/archives/:id/secret', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    if (!can(u, 'secret:classify')) return fail(res, 403, '没有定密与变更密级的权限（需系统安全保密员或管理员）');
    const id = Number(params.id);
    const a = loadVisibleArchive(req, res, u, id);
    if (!a) return;
    const b = await readJson(req);

    const level = b.secret_level === undefined ? a.secret_level : mustStr(b.secret_level, 20);
    if (!SECRET_LEVELS.includes(level)) return fail(res, 400, `密级不合法，可选：${SECRET_LEVELS.join(' / ')}`);
    const term = mustStr(b.secret_term, 20);
    const from = mustStr(b.secret_from, 12).slice(0, 10) || a.archive_date || nowIso().slice(0, 10);
    // 届满日期：显式给了就用给的，否则按「期限 + 起算日」换算；长期/条件解密留空
    const explicitTo = mustStr(b.secret_to, 12).slice(0, 10);
    const to = explicitTo || secretDeadline(term, from);
    if (explicitTo && term && !secretDeadline(term, from)) {
      // 期限是"长期"却给了具体日期，属于自相矛盾
      return fail(res, 400, `保密期限「${term}」没有确定届满日期，不应再填届满日期`);
    }
    if (level !== '公开' && !mustStr(b.secret_basis, 200)) {
      return fail(res, 400, '定密必须写明依据（保密事项范围及其条款）—— 这是定密责任人的法定要求');
    }
    if (level !== '公开' && !term) {
      return fail(res, 400, '请填写保密期限（如 10年 / 30年 / 长期 / 解密条件成就前）');
    }

    q.tx(() => {
      q.run(`UPDATE archives SET secret_level=?, secret_term=?, secret_from=?, secret_to=?, secret_basis=?,
             declassify_condition=?, updated_at=? WHERE id=?`,
        level, level === '公开' ? '' : term, level === '公开' ? '' : from, level === '公开' ? '' : to,
        mustStr(b.secret_basis, 200), mustStr(b.declassify_condition, 200), nowIso(), id);
    });
    log(u, '定密登记', a.archive_code,
      `${a.secret_level} → ${level}${term ? '　保密期限：' + term : ''}${to ? '（至 ' + to + '）' : ''}`,
      clientIp(req), { step: '定密', category: 'security' });
    const after = q.get('SELECT * FROM archives WHERE id=?', id);
    ok(res, {
      secret_level: after.secret_level, secret_term: after.secret_term, secret_from: after.secret_from,
      secret_to: after.secret_to, secret_basis: after.secret_basis, declassify_condition: after.declassify_condition,
    });
  });

  function nextAppraisalBatchNo() {
    const d = new Date();
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`;
    const key = `appraisalpseq:${day}`;
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0) + 1;
    q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(cur));
    return `JD${day}-${String(cur).padStart(3, '0')}`;
  }

  /**
   * 执行一次鉴定（批量或单件）。批次与单件共用这一份实现 ——
   * 结论校验、状态写回、留痕只写一遍，避免"批量按规范走、单件漏一步"这类不一致。
   *
   * @returns {{done:Array, skipped:Array}} done 里带每件的前后对照，用于生成清册
   */
  function appraiseCore(u, req, ids, p, batchId) {
    const kind = APPRAISAL_KINDS.includes(p.kind) ? p.kind : '价值鉴定';
    const conclusion = mustStr(p.conclusion, 20) || mustStr(p.decision, 20);
    const allowed = { 价值鉴定: VALUE_DECISIONS, 密级鉴定: SECRET_DECISIONS, 开放鉴定: OPEN_DECISIONS }[kind];
    if (!allowed.includes(conclusion)) {
      throw Object.assign(new Error(`${kind}的结论只能是：${allowed.join(' / ')}`), { statusCode: 400 });
    }
    const basis = mustStr(p.basis, 500);
    const basisRef = mustStr(p.basis_ref, 200);
    const groupOpinion = mustStr(p.group_opinion, 500);
    const members = mustStr(p.members, 300);
    const memberCount = Number(p.member_count) || 0;
    const reviewedAt = mustStr(p.reviewed_at, 12).slice(0, 10) || nowIso().slice(0, 10);
    // 密级鉴定与开放鉴定都要求写明依据条款：解密/开放是法定决定，说不清依据就不成立
    if (kind !== '价值鉴定' && !basisRef) {
      throw Object.assign(new Error(`${kind}必须填写依据条款（如《档案法》第二十七条）`), { statusCode: 400 });
    }

    const sec = secretScope(u);
    const done = [];
    const skipped = [];

    for (const id of ids) {
      const a = q.get(`SELECT a.*, c.name AS category_name FROM archives a
                       LEFT JOIN categories c ON c.id=a.category_id WHERE a.id=?`, Number(id));
      if (!a) { skipped.push({ id: Number(id), reason: '档案不存在' }); continue; }
      // 可见性：看不见的档案按"不存在"处理，不能借鉴定接口确认它的存在
      const vis = Number(q.scalar(`SELECT COUNT(*) FROM archives a WHERE a.id=?${sec.sql}`, a.id, ...sec.params)) > 0;
      if (!vis) { skipped.push({ id: a.id, reason: '档案不存在或不可见' }); continue; }
      if (a.status === '已销毁') { skipped.push({ id: a.id, reason: '档案已销毁' }); continue; }

      const before = {
        retention: a.retention, retention_code: a.retention_code, retention_years: a.retention_years,
        retention_due_year: a.retention_due_year, secret_level: a.secret_level, secret_term: a.secret_term,
        secret_to: a.secret_to, open_state: a.open_state, status: a.status,
      };
      let newRetention = '';
      let newSecretLevel = '';
      let newSecretTo = '';
      let newOpenState = '';
      let controlReason = '';
      let openDelayTo = '';

      if (kind === '价值鉴定') {
        if (conclusion === '延长保管期限') {
          newRetention = mustStr(p.new_retention, 20);
          if (!RETENTIONS.includes(newRetention)) throw Object.assign(new Error('延长保管期限时需选择新的保管期限'), { statusCode: 400 });
          if (newRetention === a.retention) throw Object.assign(new Error(`档案 ${a.archive_code} 的新保管期限与当前一致，无需延长`), { statusCode: 400 });
        }
        if (conclusion === '建议销毁') {
          const active = q.scalar(`SELECT COUNT(*) FROM loans WHERE archive_id=? AND status IN ('已批准','逾期')`, a.id);
          if (active) throw Object.assign(new Error(`档案 ${a.archive_code} 有未归还的借出记录，不能建议销毁`), { statusCode: 400 });
        }
      } else if (kind === '密级鉴定') {
        if (conclusion === '解密') {
          newSecretLevel = '公开';
        } else if (conclusion === '降低密级') {
          newSecretLevel = mustStr(p.new_secret_level, 20);
          if (!SECRET_LEVELS.includes(newSecretLevel)) throw Object.assign(new Error('降低密级时需选择新的密级'), { statusCode: 400 });
          if (policy.secretRank(newSecretLevel) >= policy.secretRank(a.secret_level)) {
            throw Object.assign(new Error(`档案 ${a.archive_code} 当前为「${a.secret_level}」，「${newSecretLevel}」并不更低`), { statusCode: 400 });
          }
        } else if (conclusion === '延长保密期限') {
          newSecretLevel = a.secret_level;
          const term = mustStr(p.new_secret_term, 20) || a.secret_term;
          newSecretTo = mustStr(p.new_secret_to, 12).slice(0, 10) || secretDeadline(term, reviewedAt);
          if (!newSecretTo) {
            throw Object.assign(new Error('延长保密期限必须给出新的届满日期（或可换算的期限，如 10年）'), { statusCode: 400 });
          }
        } else { // 维持原密级
          newSecretLevel = a.secret_level;
          newSecretTo = a.secret_to;
        }
      } else { // 开放鉴定
        newOpenState = conclusion;
        if (conclusion === '开放') {
          // 先解密、后开放：《档案法》第二十七条的开放以不涉及国家秘密为前提。
          // 这里不做"顺手一起解密"的便利操作 —— 解密是定密责任人的职权，不能被开放鉴定顺带完成。
          if (a.secret_level !== '公开') {
            throw Object.assign(new Error(`档案 ${a.archive_code} 当前密级为「${a.secret_level}」，必须先完成密级鉴定（解密）才能开放`), { statusCode: 400 });
          }
        } else {
          controlReason = mustStr(p.control_reason, 300);
          if (!controlReason) throw Object.assign(new Error('作出「控制使用 / 部分开放」结论必须写明理由与依据'), { statusCode: 400 });
          openDelayTo = mustStr(p.open_delay_to, 12).slice(0, 10);
          if (conclusion === '控制使用' && !openDelayTo) {
            throw Object.assign(new Error('延期开放必须给出延期至的日期（《档案法》第二十八条要求明确延期期限）'), { statusCode: 400 });
          }
        }
      }

      q.tx(() => {
        q.run(`INSERT INTO appraisals(archive_id,kind,decision,new_retention,new_secret_level,new_secret_to,
                 new_open_state,control_reason,open_delay_to,basis,basis_ref,group_opinion,member_count,
                 appraiser_id,appraiser,appraised_at,before_state,batch_id,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          a.id, kind, conclusion,
          newRetention || (conclusion === '继续保管' || conclusion === '维持原密级' ? '' : ''),
          newSecretLevel, newSecretTo, newOpenState, controlReason, openDelayTo,
          basis, basisRef, groupOpinion, memberCount, u.id, u.display_name || u.username,
          reviewedAt, JSON.stringify(before), batchId || null, nowIso());

        if (kind === '价值鉴定') {
          if (conclusion === '延长保管期限') {
            const info = RETENTION_MAP[newRetention] || { code: '', years: 0 };
            const year = Number(a.year) || new Date().getFullYear();
            q.run(`UPDATE archives SET retention=?, retention_code=?, retention_years=?, retention_due_year=?,
                   status='在库', status_note=?, updated_at=? WHERE id=?`,
              newRetention, info.code, info.years, info.years > 0 ? year + info.years : 0,
              `已鉴定：延长为${newRetention}`, nowIso(), a.id);
          } else if (conclusion === '建议销毁') {
            q.run("UPDATE archives SET status='待销毁', status_note=?, updated_at=? WHERE id=?",
              '鉴定小组建议销毁，待审批', nowIso(), a.id);
          } else {
            q.run('UPDATE archives SET status=?, status_note=?, updated_at=? WHERE id=?',
              '在库', '鉴定结论：继续保管', nowIso(), a.id);
          }
        } else if (kind === '密级鉴定') {
          if (conclusion === '解密') {
            // 解密不是"把密级改成公开"这么简单：保密期限、定密依据一并清空，
            // 留下 declassify_condition 说明解密条件，开放鉴定才有可依据的起点。
            q.run(`UPDATE archives SET secret_level='公开', secret_term='', secret_to='', secret_basis='',
                   declassify_condition=?, updated_at=? WHERE id=?`,
              mustStr(p.declassify_condition, 200) || `经密级鉴定解密（${basisRef || '依据见鉴定意见书'}）`, nowIso(), a.id);
          } else if (conclusion === '降低密级') {
            q.run(`UPDATE archives SET secret_level=?, secret_term=?, secret_to=?, updated_at=? WHERE id=?`,
              newSecretLevel, mustStr(p.new_secret_term, 20), newSecretTo || '', nowIso(), a.id);
          } else {
            q.run('UPDATE archives SET secret_level=?, secret_to=?, updated_at=? WHERE id=?',
              newSecretLevel, newSecretTo || a.secret_to, nowIso(), a.id);
          }
        } else {
          q.run(`UPDATE archives SET open_state=?, open_review_at=?, open_control_reason=?, open_delay_to=?,
                 open_scope_note=?, updated_at=? WHERE id=?`,
            newOpenState, reviewedAt, controlReason, openDelayTo, mustStr(p.open_scope_note, 300), nowIso(), a.id);
        }
      });

      done.push({
        id: a.id, archive_code: a.archive_code, archive_number: a.archive_number, title: a.title,
        year: a.year, type_code: a.type_code, retention: a.retention, secret_level: a.secret_level,
        open_state: a.open_state, kind, conclusion, before,
        after: {
          retention: newRetention || a.retention, secret_level: newSecretLevel || a.secret_level,
          secret_to: newSecretTo, open_state: newOpenState || a.open_state,
        },
      });
    }

    if (done.length) {
      const brief = {
        价值鉴定: `价值鉴定：${conclusion}`, 密级鉴定: `密级鉴定：${conclusion}`, 开放鉴定: `开放鉴定：${conclusion}`,
      }[kind];
      log(u, '档案鉴定', done.map((d) => d.archive_code).slice(0, 5).join('、') + (done.length > 5 ? ` 等 ${done.length} 件` : ''),
        `${brief}${basisRef ? '　依据：' + basisRef : ''}`, clientIp(req), { step: kind, category: 'business' });
    }
    return { done, skipped };
  }

  /** 单件快速鉴定（保留原接口形态，扩展出 kind 与各鉴定的结论字段） */
  route('POST', '/api/archives/:id/appraise', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const a = loadVisibleArchive(req, res, u, id);
    if (!a) return;
    const b = await readJson(req);
    const kind = APPRAISAL_KINDS.includes(b.kind) ? b.kind : '价值鉴定';
    if (kind === '密级鉴定' && !can(u, 'secret:classify')) {
      return fail(res, 403, '密级鉴定（解密/降低密级）需系统安全保密员或管理员权限');
    }
    if (kind === '开放鉴定' && !can(u, 'appraisal:approve')) {
      return fail(res, 403, '开放鉴定需管理员或安全保密员权限（开放与否由馆领导批准）');
    }
    let out;
    try {
      out = appraiseCore(u, req, [id], Object.assign({}, b, { kind }), 0);
    } catch (e) {
      return fail(res, e.statusCode || 400, e.message);
    }
    if (!out.done.length) return fail(res, 400, (out.skipped[0] && out.skipped[0].reason) || '鉴定未执行');
    ok(res, { decision: out.done[0].conclusion, kind, item: out.done[0] });
  });

  /**
   * 组织鉴定：把一批档案作为一个鉴定批次送交鉴定，形成可打印的《档案鉴定意见书》与清册。
   *
   * 「批次」不是形式主义：鉴定在实际工作中就是一次鉴定小组会议 + 一份签字的意见书，
   * 逐件散落的记录没法证明"这批档案是哪次会上定的、谁签的字"。
   */
  route('POST', '/api/appraisal/batches', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const kind = APPRAISAL_KINDS.includes(b.kind) ? b.kind : '';
    if (!kind) return fail(res, 400, `请选择鉴定类别：${APPRAISAL_KINDS.join(' / ')}`);
    if (kind === '密级鉴定' && !can(u, 'secret:classify')) {
      return fail(res, 403, '密级鉴定（解密/降低密级）需系统安全保密员或管理员权限');
    }
    if (kind === '开放鉴定' && !can(u, 'appraisal:approve')) {
      return fail(res, 403, '开放鉴定需管理员或安全保密员权限（开放与否由馆领导批准）');
    }
    const ids = (Array.isArray(b.archive_ids) ? b.archive_ids : []).map(Number).filter(Boolean);
    if (!ids.length) return fail(res, 400, '请选择要鉴定的档案');
    if (ids.length > 500) return fail(res, 400, '一个鉴定批次最多 500 件');

    const batchNo = nextAppraisalBatchNo();
    let batchId = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO appraisal_batches(batch_no,kind,title,scope_note,basis,basis_ref,conclusion,
                        organizer,organizer_id,members,member_count,meeting_date,approver,approved_at,
                        approve_note,archive_count,summary,created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        batchNo, kind, mustStr(b.title, 120) || `${kind}批次 ${batchNo}`,
        mustStr(b.scope_note, 300), mustStr(b.basis, 500), mustStr(b.basis_ref, 200),
        mustStr(b.conclusion, 20), mustStr(b.organizer, 100), u.id, mustStr(b.members, 300),
        Number(b.member_count) || 0, mustStr(b.meeting_date, 12).slice(0, 10) || nowIso().slice(0, 10),
        mustStr(b.approver, 60), mustStr(b.approved_at, 12).slice(0, 10), mustStr(b.approve_note, 300), 0, '', nowIso());
      batchId = Number(r.lastInsertRowid);
    });

    let out;
    try {
      out = appraiseCore(u, req, ids, b, batchId);
    } catch (e) {
      // 一件不成立就整批不落地：半批鉴定比不做还糟（清册上的件数与实际结论对不上）
      q.run('DELETE FROM appraisals WHERE batch_id=?', batchId);
      q.run('DELETE FROM appraisal_batches WHERE id=?', batchId);
      return fail(res, e.statusCode || 400, e.message);
    }
    if (!out.done.length) {
      q.run('DELETE FROM appraisal_batches WHERE id=?', batchId);
      return fail(res, 400, '没有可鉴定的档案：' + (out.skipped.map((s) => s.reason).join('；') || '未选中有效档案'));
    }

    const dist = {};
    for (const d of out.done) dist[d.conclusion] = (dist[d.conclusion] || 0) + 1;
    const summary = Object.entries(dist).map(([k, v]) => `${k} ${v} 件`).join('；');
    q.run('UPDATE appraisal_batches SET archive_count=?, summary=? WHERE id=?', out.done.length, summary, batchId);

    log(u, '组织鉴定', batchNo,
      `${kind}　${out.done.length} 件　${summary}`, clientIp(req), { step: '鉴定批次', category: 'business' });
    ok(res, {
      batch_id: batchId, batch_no: batchNo, kind, summary,
      done: out.done.length, skipped: out.skipped,
      print_url: `/api/appraisal/batches/${batchId}/print`,
      items: out.done,
    });
  });

  route('GET', '/api/appraisal/batches', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (APPRAISAL_KINDS.includes(sp.get('kind'))) { where.push('b.kind=?'); args.push(sp.get('kind')); }
    const w = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const list = q.all(
      `SELECT b.*, u.display_name AS organizer_name,
              (SELECT COUNT(*) FROM appraisals p WHERE p.batch_id=b.id) AS item_count
         FROM appraisal_batches b LEFT JOIN users u ON u.id=b.organizer_id
         ${w} ORDER BY b.id DESC LIMIT 200`, ...args);
    ok(res, { list, total: list.length });
  });

  route('GET', '/api/appraisal/batches/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = q.get(`SELECT b.*, u.display_name AS organizer_name FROM appraisal_batches b
                     LEFT JOIN users u ON u.id=b.organizer_id WHERE b.id=?`, Number(params.id));
    if (!b) return fail(res, 404, '鉴定批次不存在');
    // 清册逐件列出档号与题名，必须按密级过滤；被过滤掉的件数如实报出，不假装批次只有几件
    const sc = secretScope(u);
    const items = q.all(
      `SELECT p.*, a.archive_code, a.archive_number, a.title, a.year, a.type_code, a.status, a.secret_level,
              usr.display_name AS appraiser_name
         FROM appraisals p JOIN archives a ON a.id=p.archive_id
         LEFT JOIN users usr ON usr.id=p.appraiser_id
        WHERE p.batch_id=?${sc.sql.replace('a.secret_level', 'a.secret_level')}
        ORDER BY a.archive_code`, b.id, ...sc.params);
    ok(res, { batch: b, items, visible: items.length, hidden: Math.max(0, Number(b.archive_count) - items.length) });
  });

  /**
   * 《档案鉴定意见书》＋《档案鉴定清册》—— 可打印、可签字、可归档的书面凭据。
   *
   * 意见书是"这次鉴定是怎么定的"，清册是"每一件定了什么"，两者必须成套：
   * 只有清册没有意见书，事后无法证明这批结论经过鉴定小组讨论与审核。
   */
  route('GET', '/api/appraisal/batches/:id/print', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = q.get('SELECT * FROM appraisal_batches WHERE id=?', Number(params.id));
    if (!b) return fail(res, 404, '鉴定批次不存在');
    const sc = secretScope(u);
    const items = q.all(
      `SELECT p.*, a.archive_code, a.archive_number, a.title, a.year, a.type_code, a.retention, a.secret_level
         FROM appraisals p JOIN archives a ON a.id=p.archive_id
        WHERE p.batch_id=?${sc.sql} ORDER BY a.archive_code`, b.id, ...sc.params);

    const beforeOf = (p) => { try { return JSON.parse(p.before_state || '{}'); } catch (_) { return {}; } };
    const KIND_COLS = {
      价值鉴定: ['原保管期限', '鉴定结论'],
      密级鉴定: ['原密级 / 保密期限', '鉴定结论'],
      开放鉴定: ['原开放状态', '鉴定结论'],
    };
    const cols = KIND_COLS[b.kind] || KIND_COLS['价值鉴定'];

    const rows = items.map((p, i) => {
      const bf = beforeOf(p);
      let beforeTxt = '';
      let afterTxt = p.decision;
      if (b.kind === '价值鉴定') {
        beforeTxt = `${esc(bf.retention || p.retention || '')}（${esc(bf.retention_due_year || '')} 年到期）`;
        if (p.decision === '延长保管期限') afterTxt = `延长为 ${esc(p.new_retention || '')}`;
      } else if (b.kind === '密级鉴定') {
        beforeTxt = `${esc(bf.secret_level || p.secret_level || '')}${bf.secret_to ? '（至 ' + esc(bf.secret_to) + '）' : ''}`;
        if (p.decision === '解密') afterTxt = '解密（公开）';
        else if (p.decision === '降低密级') afterTxt = `降为 ${esc(p.new_secret_level || '')}`;
        else if (p.decision === '延长保密期限') afterTxt = `延长至 ${esc(p.new_secret_to || '')}`;
        else afterTxt = '维持原密级';
      } else {
        beforeTxt = esc(bf.open_state || '未鉴定');
        afterTxt = esc(p.new_open_state || p.decision)
          + (p.open_delay_to ? `（延期至 ${esc(p.open_delay_to)}）` : '')
          + (p.control_reason ? `<br><span style="font-size:11px;color:#555">${esc(p.control_reason)}</span>` : '');
      }
      return `<tr>
        <td>${i + 1}</td>
        <td class="mono">${esc(p.archive_number || p.archive_code || '')}</td>
        <td class="mono">${esc(p.archive_code || '')}</td>
        <td>${esc(p.title || '')}</td>
        <td>${esc(p.year || '')}</td>
        <td>${beforeTxt}</td>
        <td>${afterTxt}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="7" style="text-align:center">（本批次没有你可查看的条目）</td></tr>';

    const op = `
      <div class="print-head">
        <h1>档 案 鉴 定 意 见 书</h1>
        <div class="meta">
          鉴定批次号：<span class="mono">${esc(b.batch_no)}</span>　
          鉴定类别：<b>${esc(b.kind)}</b>　
          鉴定日期：${esc(b.meeting_date || '')}<br>
          组织鉴定部门：${esc(b.organizer || '')}　
          鉴定小组成员：${esc(b.members || '')}（${b.member_count || 0} 人）　
          本批次件数：${b.archive_count} 件
        </div>
      </div>
      <div class="beikao">
        <h2>鉴 定 意 见</h2>
        <div class="bk-body">
          <div style="line-height:2">
            <b>一、鉴定范围</b>：${esc(b.scope_note || `${b.kind}批次 ${b.batch_no}，共 ${b.archive_count} 件`)}<br>
            <b>二、鉴定依据</b>：${esc(b.basis || '')}${b.basis_ref ? `　（${esc(b.basis_ref)}）` : ''}<br>
            <b>三、鉴定结论</b>：${esc(b.summary || '')}<br>
            <b>四、逐件结论</b>：见附表《档案鉴定清册》，共 ${b.archive_count} 件
            ${Number(b.archive_count) - items.length > 0
    ? `<span style="color:#b03030">（本页仅列出你有权查看的 ${items.length} 件，其余 ${Number(b.archive_count) - items.length} 件超出你的密级权限，未列入）</span>` : ''}
          </div>
          <div class="bk-sign">
            <div>鉴定小组负责人：<span class="bk-line">&nbsp;</span></div>
            <div>鉴定日期：<span class="bk-line">${esc(b.meeting_date || '')}</span></div>
            <div>审核人（定密责任人 / 馆领导）：<span class="bk-line">${esc(b.approver || '')}</span></div>
            <div>审核日期：<span class="bk-line">${esc(b.approved_at || '')}</span></div>
          </div>
          <div style="font-size:11.5px;color:#555;margin-top:6px">${b.approve_note ? '审核意见：' + esc(b.approve_note) : ''}</div>
        </div>
      </div>

      <div class="page-break"></div>
      <div class="print-head"><h1>档 案 鉴 定 清 册</h1>
        <div class="meta">批次号 <span class="mono">${esc(b.batch_no)}</span>　类别 ${esc(b.kind)}　
          共 ${b.archive_count} 件（本页 ${items.length} 件）</div></div>
      <table class="print-table"><thead><tr>
        <th style="width:40px">序号</th><th style="width:170px">档号</th><th style="width:110px">档案号</th>
        <th>题名</th><th style="width:50px">年度</th>
        <th style="width:170px">${cols[0]}</th><th style="width:180px">${cols[1]}</th>
      </tr></thead><tbody>${rows}</tbody></table>
      <div class="sign-row">
        <div>整理人：____________</div><div>检查人：____________</div>
        <div>审核人：____________</div><div>日期：______年____月____日</div>
      </div>`;

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(printShell(`档案鉴定意见书 ${b.batch_no}`, op, url.searchParams.get('auto') === '1'));
  });

  /** 单件鉴定历史里补上"鉴定类别"筛选，详情页要按类分组显示 */
  route('GET', '/api/appraisals/kinds', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    ok(res, {
      kinds: APPRAISAL_KINDS,
      decisions: { 价值鉴定: VALUE_DECISIONS, 密级鉴定: SECRET_DECISIONS, 开放鉴定: OPEN_DECISIONS },
      openStates: OPEN_STATES, secretTerms: SECRET_TERMS, publicYears: OPEN_PUBLIC_YEARS,
    });
  });

  // ============================================================
  // 库位、档案盒、二维码、盘点
  // ============================================================
  route('GET', '/api/locations', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const list = q.all(`SELECT l.*, (SELECT COUNT(*) FROM archive_boxes b WHERE b.location_id=l.id) AS box_count,
                               (SELECT COUNT(*) FROM archives a WHERE a.box_id IN
                                  (SELECT id FROM archive_boxes b2 WHERE b2.location_id=l.id)) AS archive_count
                        FROM locations l ORDER BY l.library, l.shelf, l.code`);
    ok(res, { list });
  });

  route('POST', '/api/locations', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const code = mustStr(b.code, 40).trim();
    const name = mustStr(b.name, 60).trim() || code;
    if (!code) return fail(res, 400, '库位编号不能为空');
    if (q.scalar('SELECT id FROM locations WHERE code=?', code)) return fail(res, 400, '库位编号已存在');
    const r = q.run('INSERT INTO locations(code,name,library,shelf,layer,capacity,remark,created_at) VALUES(?,?,?,?,?,?,?,?)',
      code, name, mustStr(b.library, 40), mustStr(b.shelf, 40), mustStr(b.layer, 20),
      Number(b.capacity) || 0, mustStr(b.remark, 200), nowIso());
    log(u, '新增库位', code, name, clientIp(req));
    ok(res, { id: r.lastInsertRowid });
  });

  route('PUT', '/api/locations/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM locations WHERE id=?', id);
    if (!cur) return fail(res, 404, '库位不存在');
    const b = await readJson(req);
    const code = mustStr(b.code, 40).trim() || cur.code;
    if (code !== cur.code && q.scalar('SELECT id FROM locations WHERE code=?', code)) return fail(res, 400, '库位编号已存在');
    q.run('UPDATE locations SET code=?, name=?, library=?, shelf=?, layer=?, capacity=?, remark=? WHERE id=?',
      code, mustStr(b.name, 60) || cur.name, mustStr(b.library, 40), mustStr(b.shelf, 40), mustStr(b.layer, 20),
      Number(b.capacity) || 0, mustStr(b.remark, 200), id);
    ok(res, true);
  });

  route('DELETE', '/api/locations/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const id = Number(params.id);
    const used = q.scalar('SELECT COUNT(*) FROM archive_boxes WHERE location_id=?', id);
    if (used) return fail(res, 400, `该库位下还有 ${used} 个档案盒，请先移出`);
    q.run('DELETE FROM locations WHERE id=?', id);
    ok(res, true);
  });

  route('GET', '/api/boxes', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (sp.get('type')) { where.push('b.type_code=?'); args.push(sp.get('type')); }
    if (sp.get('year')) { where.push('b.year=?'); args.push(sp.get('year')); }
    if (sp.get('location')) { where.push('b.location_id=?'); args.push(Number(sp.get('location'))); }
    const kw = (sp.get('kw') || '').trim();
    if (kw) { where.push('(b.box_code LIKE ? OR b.title LIKE ?)'); args.push('%' + kw + '%', '%' + kw + '%'); }
    const w = where.length ? ' WHERE ' + where.join(' AND ') : '';
    // 盒内件数按密级统计：否则"这个盒里有 30 件机密"这种信息会直接列给低密级用户
    const sec = secretScope(u);
    const list = q.all(`SELECT b.*, l.code AS location_code, l.name AS location_name,
                          (SELECT COUNT(*) FROM archives a WHERE a.box_id=b.id${sec.sql}) AS archive_count
                        FROM archive_boxes b LEFT JOIN locations l ON l.id=b.location_id
                        ${w} ORDER BY b.box_code LIMIT 500`, ...sec.params, ...args);
    // 顺带把每盒「二维码里应该写的那段文字」算好给前端。
    // 前端不要自己拼这个网址 —— 拼错一次（比如少一个签名、用错格式）就会出现
    // 「显示的是一个码、扫出来是另一个内容」，而且很难查。内容只由后端一处生成。
    for (const row of list) row.qr_text = boxQrText(row, null);
    ok(res, { list, total: list.length });
  });

  route('POST', '/api/boxes', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const boxCode = mustStr(b.box_code, 40).trim();
    if (!boxCode) return fail(res, 400, '档案盒号不能为空');
    if (q.scalar('SELECT id FROM archive_boxes WHERE box_code=?', boxCode)) return fail(res, 400, '档案盒号已存在');
    const locationId = Number(b.location_id) || null;
    if (locationId && !q.get('SELECT id FROM locations WHERE id=?', locationId)) return fail(res, 400, '库位不存在');
    // 保管期限/机构(问题)在盒上显式标注：装盒校验与盒脊打印都以此为准
    const retention = mustStr(b.retention, 20);
    if (retention && !RETENTIONS.includes(retention)) {
      return fail(res, 400, `保管期限取值不合法：「${retention}」。可选：${RETENTIONS.join(' / ')}`);
    }
    // 盒脊厚度：标准只允许 20/30/40/50mm，别的值实体盒装不进柜
    const spineMm = b.spine_mm === undefined || b.spine_mm === ''
      ? normalizeSpineMm(numbering.getSetting(q, 'box.spine_mm_default', '30'), 30)
      : normalizeSpineMm(b.spine_mm, 0);
    if (!spineMm) {
      return fail(res, 400, `盒脊厚度只能是 ${SPINE_MM_ALLOWED.join(' / ')} mm（DA/T 22—2015 §6.4）`);
    }
    const r = q.run(`INSERT INTO archive_boxes(box_code,title,type_code,year,retention,org_code,location_id,capacity,
                      barcode,remark,spine_mm,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      boxCode, mustStr(b.title, 120), mustStr(b.type_code, 16), mustStr(b.year, 8), retention,
      mustStr(b.org_code, 40), locationId,
      Number(b.capacity) || 60, mustStr(b.barcode, 80) || boxCode, mustStr(b.remark, 200), spineMm,
      u.id, nowIso(), nowIso());
    log(u, '新增档案盒', boxCode, mustStr(b.title, 60), clientIp(req));
    ok(res, { id: r.lastInsertRowid });
  });

  route('PUT', '/api/boxes/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const cur = q.get('SELECT * FROM archive_boxes WHERE id=?', id);
    if (!cur) return fail(res, 404, '档案盒不存在');
    const b = await readJson(req);
    const boxCode = mustStr(b.box_code, 40).trim() || cur.box_code;
    if (boxCode !== cur.box_code && q.scalar('SELECT id FROM archive_boxes WHERE box_code=?', boxCode)) {
      return fail(res, 400, '档案盒号已存在');
    }
    const locationId = b.location_id === '' || b.location_id === null ? null : Number(b.location_id);
    const retention = b.retention === undefined ? cur.retention : mustStr(b.retention, 20);
    if (retention && !RETENTIONS.includes(retention)) {
      return fail(res, 400, `保管期限取值不合法：「${retention}」。可选：${RETENTIONS.join(' / ')}`);
    }
    const orgCode = b.org_code === undefined ? cur.org_code : mustStr(b.org_code, 40);
    const capacity = Number(b.capacity) || 60;
    let spineMm = Number(cur.spine_mm) || 30;
    if (b.spine_mm !== undefined && b.spine_mm !== '') {
      if (!SPINE_MM_ALLOWED.includes(Number(b.spine_mm))) {
        return fail(res, 400, `盒脊厚度只能是 ${SPINE_MM_ALLOWED.join(' / ')} mm（DA/T 22—2015 §6.4）`);
      }
      spineMm = Number(b.spine_mm);
    }

    // 盒内已有档案时，改盒属性不能与盒内内容冲突 —— 否则会把一个合规的盒
    // 改成「盒脊标注与盒内档案不一致」，比拒绝修改更糟（而且打印出来才发现）。
    const existing = q.all('SELECT * FROM archives WHERE box_id=?', id);
    if (existing.length) {
      if (capacity > 0 && capacity < existing.length) {
        return fail(res, 400, `盒容量不能小于盒内已有件数（现有 ${existing.length} 件）`);
      }
      if (boxMixEnforced()) {
        const candidate = {
          year: mustStr(b.year, 8), type_code: mustStr(b.type_code, 16), retention, category_code: orgCode,
        };
        const conflict = boxCanonConflict(boxCanonOfArchive(existing[0]), candidate);
        if (conflict) {
          return fail(res, 400,
            `不能这样修改档案盒：盒内已有 ${existing.length} 件档案，${conflict}。`
            + '请先把盒内档案移出，或保持盒的年度/保管期限/机构(问题)与盒内档案一致。', 'BOX_MIX');
        }
      }
    }

    q.run(`UPDATE archive_boxes SET box_code=?, title=?, type_code=?, year=?, retention=?, org_code=?,
           location_id=?, capacity=?, barcode=?, remark=?, spine_mm=?, updated_at=? WHERE id=?`,
      boxCode, mustStr(b.title, 120), mustStr(b.type_code, 16), mustStr(b.year, 8), retention, orgCode,
      locationId, capacity, mustStr(b.barcode, 80) || boxCode, mustStr(b.remark, 200), spineMm, nowIso(), id);
    // 盒内档案的存放位置同步更新
    if (locationId) {
      const loc = q.get('SELECT code FROM locations WHERE id=?', locationId);
      if (loc) q.run('UPDATE archives SET location=?, updated_at=? WHERE box_id=?', loc.code, nowIso(), id);
    }
    ok(res, true);
  });

  route('DELETE', '/api/boxes/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const used = q.scalar('SELECT COUNT(*) FROM archives WHERE box_id=?', id);
    if (used) return fail(res, 400, `该盒内还有 ${used} 件档案，请先移出后再删除`);
    q.run('DELETE FROM archive_boxes WHERE id=?', id);
    ok(res, true);
  });

  // ---------- 档案盒混装校验（DA/T 22—2015 §6.4）----------
  //
  // 规则：**不同年度、机构(问题)、保管期限的归档文件不能装入同一盒**，门类自然也不能混。
  // 为什么必须做在服务端：盒脊上要印全宗号/年度/保管期限/起止件号/盒号，
  // 一旦混装，盒脊上的标注就是错的，排架、盘点、上级检查全都会对不上。
  // v3.4.7 的装盒接口只执行 `UPDATE archives SET box_id=?`，没有任何校验，
  // 因此这类问题在系统里根本发现不了。
  //
  // 一致性「基准」的取值优先级：盒内已有档案 > 盒自身属性 > 本批第一件。
  // 前者优先是因为**盒里已经装了什么才是既成事实**，改盒属性比改一盒档案容易。

  const BOX_CANON_LABELS = { year: '年度', type_code: '门类', retention: '保管期限', org_code: '机构(问题)' };

  function boxCanonOfArchive(a) {
    return {
      year: String(a.year || ''),
      type_code: String(a.type_code || ''),
      retention: String(a.retention || ''),
      // 机构(问题)代码：分类号即「机构(问题)分类法」下的类目代码，作为该维度的落点
      org_code: String(a.category_code || ''),
    };
  }

  function boxCanonOfBox(box, existing) {
    if (existing && existing.length) return boxCanonOfArchive(existing[0]);
    return {
      year: String(box.year || ''),
      type_code: String(box.type_code || ''),
      retention: String(box.retention || ''),
      org_code: String(box.org_code || ''),
    };
  }

  /** 返回第一处不一致的中文描述；全部一致返回 ''。空值视为「未标注」，不判冲突。 */
  function boxCanonConflict(canon, a) {
    const t = boxCanonOfArchive(a);
    for (const k of Object.keys(BOX_CANON_LABELS)) {
      const x = String(canon[k] || '');
      const y = String(t[k] || '');
      if (x && y && x !== y) {
        return `${BOX_CANON_LABELS[k]}不一致（盒内为「${x}」，待装档案为「${y}」）`;
      }
    }
    return '';
  }

  /** 是否强制拒绝混装（设置项 box.enforce_mix，默认开启） */
  function boxMixEnforced() {
    return String(numbering.getSetting(q, 'box.enforce_mix', '1')) !== '0';
  }

  /**
   * 装盒兼容性计算：返回基准、容量与逐条判定结果。
   * assign 与兼容性预检接口共用同一份逻辑，避免「预检说可以、装盒却被拒」。
   */
  function checkBoxCompat(box, incoming) {
    const existing = q.all('SELECT * FROM archives WHERE box_id=?', box.id);
    const canon = boxCanonOfBox(box, existing);
    const capacity = Number(box.capacity) || 0;
    const okIds = [];
    const bad = [];
    for (const a of incoming) {
      const conflict = boxCanonConflict(canon, a);
      if (conflict) bad.push({ id: a.id, archive_code: a.archive_code, reason: conflict });
      else okIds.push(a.id);
    }
    const problems = [];
    if (capacity > 0 && existing.length + okIds.length > capacity) {
      problems.push(`超出盒容量：盒内现有 ${existing.length} 件 + 待装 ${okIds.length} 件 = ${existing.length + okIds.length} 件，本盒容量为 ${capacity} 件`);
    }
    return { canon, existingCount: existing.length, capacity, okIds, bad, problems, canAdopt: existing.length === 0 };
  }

  /** 把待装档案按密级过滤（看不到的档案不允许装盒，也不允许借装盒之名确认其存在） */
  function visibleArchivesOf(user, ids) {
    if (!ids.length) return [];
    const scope = secretScope(user);
    const holes = ids.map(() => '?').join(',');
    return q.all(`SELECT * FROM archives a WHERE a.id IN (${holes})${scope.sql}`, ...ids, ...scope.params);
  }

  /** 把档案装入/移出档案盒 */
  route('POST', '/api/boxes/:id/assign', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const boxId = Number(params.id);
    const box = q.get('SELECT b.*, l.code AS loc_code FROM archive_boxes b LEFT JOIN locations l ON l.id=b.location_id WHERE b.id=?', boxId);
    if (!box) return fail(res, 404, '档案盒不存在');
    const b = await readJson(req);
    let ids = Array.isArray(b.archive_ids) ? b.archive_ids.map(Number).filter(Boolean) : [];
    if (!ids.length) return fail(res, 400, '请选择要装盒的档案');

    // 密级约束：看不到的档案不能装盒
    const incoming = visibleArchivesOf(u, ids);
    if (incoming.length !== ids.length) {
      log(u, '装盒跳过无权档案', box.box_code, `${ids.length - incoming.length} 件超出账号密级上限`, clientIp(req));
    }
    if (!incoming.length) return fail(res, 403, '所选档案均超出你的密级权限范围，或档案不存在');

    const compat = checkBoxCompat(box, incoming);
    if (boxMixEnforced()) {
      if (compat.bad.length) {
        const detail = compat.bad.slice(0, 3).map((x) => `${x.archive_code}：${x.reason}`).join('；');
        const more = compat.bad.length > 3 ? `（另有 ${compat.bad.length - 3} 件同类问题）` : '';
        return fail(res, 400,
          `装盒被拒绝：DA/T 22—2015 §6.4 要求不同年度、机构(问题)、保管期限的归档文件不得装入同一盒。${detail}${more}。`
          + '请改用与本盒一致的档案盒，或先修正盒的年度/保管期限后再装。'
          + '（如本单位确有特殊整理方式，可由管理员在系统设置中关闭「装盒一致性校验」）',
          'BOX_MIX');
      }
      if (compat.problems.length) return fail(res, 400, compat.problems.join('；'), 'BOX_MIX');
    }

    const assignIds = boxMixEnforced() ? compat.okIds : ids;
    const adopt = compat.canAdopt && assignIds.length
      ? incoming.find((x) => assignIds.includes(Number(x.id))) || null
      : null;
    let n = 0;
    q.tx(() => {
      for (const id of assignIds) {
        const r = q.run('UPDATE archives SET box_id=?, location=?, status=?, updated_at=? WHERE id=?',
          boxId, box.loc_code || box.box_code, '在库', nowIso(), id);
        n += r.changes;
      }
      // 空盒装盒后，把盒自身的年度/门类/保管期限/机构属性补齐：
      // 盒脊打印和后续校验都需要一个一致的依据，否则盒属性永远是空的。
      if (adopt) {
        q.run('UPDATE archive_boxes SET year=?, type_code=?, retention=?, org_code=?, updated_at=? WHERE id=?',
          String(adopt.year || ''), String(adopt.type_code || ''), String(adopt.retention || ''),
          String(adopt.category_code || ''), nowIso(), boxId);
      }
    });
    log(u, '档案装盒', box.box_code, `${n} 件`, clientIp(req));
    ok(res, { assigned: n, skipped: ids.length - n, canon: compat.canon });
  });

  /**
   * 装盒兼容性预检：前端在用户点「装盒」之前先问一次，
   * 把不兼容的档案当场标出来，而不是等用户点了才报错。
   * 与 assign 复用同一份 checkBoxCompat，保证两边判定永远一致。
   */
  route('GET', '/api/boxes/:id/compat', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const boxId = Number(params.id);
    const box = q.get('SELECT * FROM archive_boxes WHERE id=?', boxId);
    if (!box) return fail(res, 404, '档案盒不存在');
    const ids = String(url.searchParams.get('archive_ids') || '')
      .split(',').map((s) => Number(s.trim())).filter(Boolean);
    const incoming = visibleArchivesOf(u, ids);
    const compat = checkBoxCompat(box, incoming);
    ok(res, {
      box_code: box.box_code,
      enforce: boxMixEnforced(),
      canon: compat.canon,
      existing_count: compat.existingCount,
      capacity: compat.capacity,
      // 注意字段名不能叫 ok：API 信封本身已用 ok 表示「请求是否成功」，
      // 再叫 ok 会让调用方拿到永远为 true 的值（本项目踩过一次）。
      compatible: compat.bad.length === 0 && compat.problems.length === 0,
      bad: compat.bad,
      problems: compat.problems,
      labels: BOX_CANON_LABELS,
    });
  });

  route('POST', '/api/boxes/:id/remove', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const boxId = Number(params.id);
    const b = await readJson(req);
    const ids = Array.isArray(b.archive_ids) ? b.archive_ids.map(Number).filter(Boolean) : [];
    if (!ids.length) return fail(res, 400, '请选择要移出的档案');
    let n = 0;
    for (const id of ids) {
      n += q.run("UPDATE archives SET box_id=NULL, location='', updated_at=? WHERE id=? AND box_id=?", nowIso(), id, boxId).changes;
    }
    ok(res, { removed: n });
  });

  // ============================================================
  // 二维码 / 扫码
  // ============================================================

  /**
   * 生成盘点单号：PD<年月日>-<三位流水>。
   *
   * 这里以前用的是 3 位随机数，撞号概率不低（一天开几十个盘点就会失败），
   * 而 check_no 上又有唯一约束，用户看到的是「新建盘点失败」这种莫名其妙的报错。
   * 改成按当天已有单号取下一个流水，并逐个确认没被占用，实在找不到才用时间戳兜底。
   */
  function nextCheckNo(d) {
    const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    const prefix = `PD${day}-`;
    const row = q.get('SELECT check_no FROM stock_checks WHERE check_no LIKE ? ORDER BY check_no DESC LIMIT 1', prefix + '%');
    let seq = row ? (Number(String(row.check_no).slice(prefix.length)) || 0) : 0;
    for (let i = 0; i < 999; i++) {
      seq += 1;
      const cand = prefix + String(seq).padStart(3, '0');
      if (!q.get('SELECT id FROM stock_checks WHERE check_no=?', cand)) return cand;
    }
    return prefix + String(Date.now()).slice(-6);
  }

  function settingOf(key, dflt) {
    const row = q.get('SELECT value FROM settings WHERE key=?', key);
    if (!row || row.value === null || row.value === undefined) return dflt === undefined ? '' : dflt;
    return String(row.value);
  }

  /**
   * 二维码里要写的网址前缀。
   * 优先级：系统设置 qr.base_url > 浏览器请求的 Host（非回环）> 本机局域网 IP。
   * 绝不能默认给 127.0.0.1 —— 那个地址在手机上永远打不开，
   * 这是「二维码扫不出来」最容易被忽略的一个原因。
   */
  // 会话 Cookie 的写法：HTTPS 下带 Secure，HTTP 下不带（否则浏览器不回传，登录直接坏）
  function sessionCookieOpts() {
    return {
      maxAge: Math.floor(SESSION_TTL_MS / 1000),
      secure: !!(config && config.tlsResolved),
    };
  }
  /** 对外链接用哪个协议：配了 TLS 就是 https，否则 http。
   *  二维码、局域网地址、扫码落地页链接都走这里，避免 HTTPS 环境下发出 http 链接
   *  （浏览器会拦混合内容，手机扫码也会直接连不上）。 */
  function urlScheme() {
    return config && config.tlsResolved ? 'https' : 'http';
  }

  function qrBaseUrl(req) {
    const configured = settingOf('qr.base_url', '').trim().replace(/\/+$/, '');
    if (configured) return configured;
    const port = (config && (config.actualPort || config.port)) || 8787;
    const hostHdr = String((req && req.headers && req.headers.host) || '');
    if (hostHdr && !isLoopbackHost(hostHdr)) return urlScheme() + '://' + hostHdr;
    const lan = lanIPv4List();
    if (lan.length) return `${urlScheme()}://${lan[0].address}:${port}`;
    return `http://127.0.0.1:${port}`;
  }

  /**
   * 档案二维码落地页（公网可访问）。
   *
   * 扫码后看到的内容，按需求设计：
   *   ① 最上面、最大字号显示【档案号】
   *   ② 下面给一个可点的【打开档案详情】链接
   *
   * 安全设计（重要）：
   *   档案号是连续可枚举的（…0001、0002…），而这个页面是公网可访问的。
   *   如果只凭档案号就能打开，任何人都能顺着编号把全库档案翻一遍。
   *   所以链接里必须带 HMAC 签名令牌（?k=…&i=…），没有令牌一律不显示任何档案信息。
   *   档案详情本身仍然需要登录，这里只展示档案号等非敏感信息。
   */
  route('GET', '/api/a/:code', async (req, res, params, url) => {
    const pub = settingOf('qr.scan_public', '1') !== '0';
    if (!pub) {
      const u = requireAuth(req, res);
      if (!u) return;
    }
    const code = String(params.code || '').trim();
    const id = Number(url.searchParams.get('i')) || 0;
    const token = url.searchParams.get('k') || '';
    const key = qrSignKey();

    // 没有合法令牌 → 不透露任何信息（防枚举）
    if (!id || !qrContent.verify(key, 'archive', id, token)) {
      res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return void res.end(scanShell('请用系统生成的二维码访问', `
        <div class="card">
          <h1>这个链接无效</h1>
          <p class="muted">为了不让别人顺着档案号把全库档案翻一遍，落地页只接受系统自己生成的二维码链接。</p>
          <p class="muted">请用档案系统打印或显示的二维码扫码，或直接登录系统查看。</p>
        </div>
        <div class="card" style="margin-top:12px">
          <a class="btn" style="display:block;text-align:center;text-decoration:none;padding:12px;background:#1b4d8f;color:#fff;border-radius:10px"
             href="/">打开档案管理系统</a>
        </div>`));
    }
    serveArchiveLanding(req, res, id, code);
  });

  /**
   * 档案二维码的**短**落地页：/q/<令牌> 或 /q/<令牌>/<档号>
   *
   * 为什么单独做一条：二维码内容越短 → 版本越低 → 模块数越少 →
   * 打印在标签上每个模块越大、越好扫。原来的 /api/a/<档号>?k=…&i=… 有 65 个字符，
   * 在纠错 H 下是 61 格，贴到 30mm 标签上只有 0.49mm/模块（实测扫不出）；
   * 这条短路径只有 33 个字符 / 45 格，同样的标签有 0.67mm/模块。
   *
   * /q/<令牌>/<档号> 那一段档号**只为了扫码时能在显示的文字里一眼看到编号**，
   * 查找始终靠前面的令牌（令牌里编码内部 id），所以**改档号不会让旧标签失效**。
   *
   * /api/a/… 那条**保留不动**，因为已经打印出去、贴在盒子上的旧标签还在用它。
   */
  const serveShortArchive = async (req, res, params) => {
    if (settingOf('qr.scan_public', '1') === '0') {
      const u = requireAuth(req, res);
      if (!u) return;
    }
    const id = qrContent.parseShortArchiveToken(params.token, qrSignKey());
    if (!id) {
      res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return void res.end(scanShell('请用系统生成的二维码访问', `
        <div class="card">
          <h1>这个链接无效</h1>
          <p class="muted">为了不让别人顺着档案号把全库档案翻一遍，落地页只接受系统自己生成的二维码链接。</p>
          <p class="muted">请用档案系统打印或显示的二维码扫码，或直接登录系统查看。</p>
        </div>
        <div class="card" style="margin-top:12px">
          <a class="btn" style="display:block;text-align:center;text-decoration:none;padding:12px;background:#1b4d8f;color:#fff;border-radius:10px"
             href="/">打开档案管理系统</a>
        </div>`));
    }
    serveArchiveLanding(req, res, id, params.code || '');
  };
  route('GET', '/q/:token', serveShortArchive);
  route('GET', '/q/:token/:code', serveShortArchive);

  /**
   * 档案扫码落地页的实际渲染（长路径 /api/a/:code 与短路径 /q/:token 共用）。
   * 令牌校验由调用方负责，进到这里说明已经校验通过。
   */
  function serveArchiveLanding(req, res, id, codeHint) {
    const a = q.get(`SELECT a.*, c.name AS category_name FROM archives a
                     LEFT JOIN categories c ON c.id=a.category_id WHERE a.id=?`, id);
    if (!a) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return void res.end(scanShell('未找到档案', `
        <div class="card">
          <h1>没有找到这份档案</h1>
          <div class="big">${esc(codeHint || '')}</div>
          <p class="muted">档案可能已经被删除或移出馆藏。</p>
        </div>`));
    }

    const label = qrContent.archiveLabel(a);
    const b = qrBaseInfo(req);
    // 详情页链接：SPA 的深层链接，登录后会直接打开这份档案的详情
    const detailUrl = `${qrContent.trimBase(b.base)}/#/archive/${a.id}`;
    const showTitle = settingOf('qr.scan_show_title', '1') !== '0';

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(scanShell(`档案 ${label}`, `
      <div class="card">
        <h1>档案号</h1>
        <div class="big" style="font-size:26px">${esc(label)}</div>
        ${showTitle && a.title ? `<div class="kv"><span class="k">题名</span><span class="v">${esc(a.title)}</span></div>` : ''}
        <div class="kv"><span class="k">门类</span><span class="v">${esc(a.category_name || a.type_code || '—')}</span></div>
        <div class="kv"><span class="k">年度</span><span class="v">${esc(String(a.year || '—'))}</span></div>
        <div class="kv"><span class="k">保管期限</span><span class="v">${esc(a.retention || '—')}</span></div>
        <div class="kv"><span class="k">状态</span><span class="v">${esc(a.status || '—')}${a.box_id ? '（已装盒）' : ''}</span></div>
      </div>
      <div class="card" style="margin-top:12px">
        <a style="display:block;text-align:center;text-decoration:none;padding:14px;background:#1b4d8f;color:#fff;border-radius:10px;font-size:17px"
           href="${esc(detailUrl)}">打开档案详情 →</a>
        <p class="muted" style="margin-top:10px">档案详情需要登录后才能查看。若尚未登录，点开会先跳到登录页，登录成功会自动回到这份档案。</p>
      </div>`));
  }

  /**
   * 指定档案盒的扫码网址（**短格式**）：<base>/b/<令牌>，约 33 个字符。
   *
   * 为什么用短格式：二维码内容越短，版本越低、模块数越少，打印在盒脊上单个模块越大。
   * 实测（纠错 H / 静区 6）：
   *   长格式 <base>/api/s/<盒号>?k=<12位>  58 字符 → v7，57 格
   *   短格式 <base>/b/<令牌>                33 字符 → v4，45 格
   * 同样的盒脊标签，每个模块大 24%。盒脊本来就不宽，这 24% 往往就是扫得出与扫不出的差别。
   *
   * 令牌里编码的是**盒 id**，所以需要传入盒记录（不能只给盒号）。
   * 长格式 /api/s/<盒号>?k=<12位> 继续保留并可用，已经打印出去的旧盒脊标签不受影响。
   */
  function boxScanUrl(box, req) {
    const b = qrBaseInfo(req);
    return qrContent.shortBoxUrl(b.base, box, qrSignKey());
  }

  /**
   * 档案盒二维码内容。
   * 默认写成网址：手机扫码能直接打开盒内清单，才算真正「扫得出来」。
   * 设置 qr.mode=code 时退回纯盒号（老式扫码枪 / 离线标签机用）。
   *
   * @param box 盒记录（需要 id 才能算短令牌），或直接传盒号字符串（退回长格式）
   */
  function boxQrText(box, req) {
    const boxCode = typeof box === 'string' ? box : (box && box.box_code) || '';
    if (settingOf('qr.mode', 'url') === 'code') return boxCode;
    if (box && typeof box === 'object' && box.id) return boxScanUrl(box, req);
    // 兜底：拿不到 id 就用长格式（已打印的旧标签走的就是这条）
    const b = qrBaseInfo(req);
    return qrContent.boxUrl(b.base, boxCode, qrSignKey());
  }

  /**
   * 手机扫码落地页（档案盒）。
   * 默认不要求登录：手机扫码时没有会话 Cookie，要求登录就等于「扫了也打不开」。
   * 只展示盒号/库位/件数/档号，不含题名，降低信息外泄风险。
   * 若单位要求更严，把设置 qr.scan_public 改为 0，即改为必须登录。
   *
   * 挂在三个路径上：
   *   /b/:token        —— **二维码里用的就是这个**（短，模块大，好扫）
   *   /api/s/:code     —— 按盒号，兼容已经打印出去的旧盒脊标签
   *   /api/scan/box/:code —— 最早期标签用的路径，继续保留
   */
  const scanBoxHandler = async (req, res, params) => {
    if (settingOf('qr.scan_public', '1') === '0') {
      const u = requireAuth(req, res);
      if (!u) return;
    }
    const code = String(params.code || '').trim();
    const box = q.get(`SELECT b.*, l.code AS loc_code, l.name AS loc_name FROM archive_boxes b
                       LEFT JOIN locations l ON l.id=b.location_id
                       WHERE b.box_code=? OR b.barcode=?`, code, code);
    serveBoxLanding(res, box, code);
  };
  route('GET', '/api/scan/box/:code', scanBoxHandler);
  route('GET', '/api/s/:code', scanBoxHandler);

  /**
   * 档案盒二维码的**短**落地页：/b/<令牌> 或 /b/<令牌>/<盒号>
   * 令牌里编码盒 id + HMAC 签名（防按 id 枚举）；后面那段盒号只用于显示。
   */
  const serveShortBox = async (req, res, params) => {
    if (settingOf('qr.scan_public', '1') === '0') {
      const u = requireAuth(req, res);
      if (!u) return;
    }
    const id = qrContent.parseShortBoxToken(params.token, qrSignKey());
    // 令牌不对：一律 403 且不透露任何信息（与档案落地页一致，防按 id 枚举）
    if (!id) {
      res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return void res.end(scanShell('请用系统生成的二维码访问', `
        <div class="card">
          <h1>这个链接无效</h1>
          <p class="muted">为了不让别人顺着编号把全库档案盒翻一遍，落地页只接受系统自己生成的二维码链接。</p>
          <p class="muted">请用档案系统打印的盒脊二维码扫码，或直接登录系统查看。</p>
        </div>`));
    }
    const box = q.get(`SELECT b.*, l.code AS loc_code, l.name AS loc_name FROM archive_boxes b
                       LEFT JOIN locations l ON l.id=b.location_id WHERE b.id=?`, id);
    serveBoxLanding(res, box, params.code || '');
  };
  route('GET', '/b/:token', serveShortBox);
  route('GET', '/b/:token/:code', serveShortBox);

  /**
   * 把本模块的查询能力注入共用解析器（实现见 lib/scan-parse）。
   * 盘点接口与扫码工作台都走这里，保证同一张标签在两处表现一致。
   */
  function scanCandidatesFor(text) {
    return scanParse.scanCandidates(text, {
      signKey: qrSignKey(),
      parseShortArchiveToken: qrContent.parseShortArchiveToken,
      parseShortBoxToken: qrContent.parseShortBoxToken,
      archiveById: (id) => q.get('SELECT archive_code, archive_number FROM archives WHERE id=?', id),
      boxById: (id) => q.get('SELECT box_code, barcode FROM archive_boxes WHERE id=?', id),
    });
  }

  /**
   * **扫码解析**：把扫码枪打进来的一段文本，解析成「这是哪份档案 / 哪个盒 / 哪个库位」。
   *
   * 为什么解析放服务端：扫码枪只是键盘设备，它把二维码里的文字原样"打"出来；
   * 而"这串字是什么"取决于服务端的东西 —— 短令牌的签名密钥、各表的编号规则、账号密级。
   * 前端只把原文透传过来、不做任何解析，免得两边各有一套规则、早晚对不上。
   */
  route('GET', '/api/scan/resolve', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const text = String(url.searchParams.get('text') || '');
    const parsed = scanCandidatesFor(text);
    if (!parsed.candidates.length) {
      return ok(res, { kind: 'unknown', raw: parsed.raw, candidates: [], hint: parsed.hint, reason: '扫码内容为空' });
    }

    const findByArchive = (code) => q.get(
      `SELECT a.id, a.archive_code, a.archive_number, a.title, a.year, a.type_code, a.retention,
              a.secret_level, a.status, a.location, a.box_id, a.archive_date,
              b.box_code, l.code AS loc_code, l.name AS loc_name
         FROM archives a
         LEFT JOIN archive_boxes b ON b.id = a.box_id
         LEFT JOIN locations l ON l.id = b.location_id
        WHERE a.archive_code=? OR a.archive_number=? LIMIT 1`, code, code);
    const findByBox = (code) => q.get(
      `SELECT b.*, l.code AS loc_code, l.name AS loc_name,
              (SELECT COUNT(*) FROM archives a WHERE a.box_id=b.id) AS archives_count
         FROM archive_boxes b LEFT JOIN locations l ON l.id=b.location_id
        WHERE b.box_code=? OR b.barcode=? LIMIT 1`, code, code);
    const findByLocation = (code) => q.get('SELECT * FROM locations WHERE code=? LIMIT 1', code);

    // 按类型提示优先试探：/q/ 开头的显然是档案、/b/ 开头的显然是盒。
    // 先试对的那一类既省查询，也避免编号恰好撞车时认错对象。
    const order = parsed.hint === 'box' ? ['box', 'archive', 'location'] : ['archive', 'box', 'location'];
    for (const t of order) {
      for (const code of parsed.candidates) {
        if (t === 'archive') {
          const row = findByArchive(code);
          if (row) {
            // 密级不够时**一律按"没找到"回应**：涉密档案的存在性本身就是需要保护的信息。
            // 真实原因只进审计日志，由安全审计员去发现。
            if (!policy.canSeeSecret(u, row.secret_level, enforceSecret())) {
              log(u, '扫码越权被拒', code, `档案密级=${row.secret_level}`, clientIp(req),
                { result: '拒绝', category: 'security', step: '扫码识别' });
              return ok(res, {
                kind: 'unknown', raw: parsed.raw, candidates: parsed.candidates, hint: parsed.hint,
                reason: '库中未找到该编号',
              });
            }
            return ok(res, {
              kind: 'archive', code: row.archive_code || code, raw: parsed.raw,
              candidates: parsed.candidates, hint: parsed.hint, archive: row,
            });
          }
        } else if (t === 'box') {
          const row = findByBox(code);
          if (row) {
            return ok(res, {
              kind: 'box', code: row.box_code || code, raw: parsed.raw,
              candidates: parsed.candidates, hint: parsed.hint, box: row,
            });
          }
        } else {
          const row = findByLocation(code);
          if (row) {
            return ok(res, {
              kind: 'location', code: row.code, raw: parsed.raw,
              candidates: parsed.candidates, hint: parsed.hint, location: row,
            });
          }
        }
      }
    }
    return ok(res, {
      kind: 'unknown', raw: parsed.raw, candidates: parsed.candidates, hint: parsed.hint,
      reason: '库中未找到该编号',
    });
  });

  /** 档案盒落地页的实际渲染（短路径与按盒号的路径共用） */
  function serveBoxLanding(res, box, codeHint) {
    res.writeHead(box ? 200 : 404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    if (!box) {
      return void res.end(scanShell('未找到档案盒', `
        <div class="card">
          <h1>没有找到这个档案盒</h1>
          <div class="big">${esc(codeHint || '')}</div>
          <p class="muted">系统里没有该盒号的记录，或这个链接的签名不对（请扫系统生成的二维码）。</p>
        </div>`));
    }
    const items = q.all(`SELECT archive_code, archive_number, year, retention, status FROM archives
                         WHERE box_id=? ORDER BY archive_number, archive_code`, box.id);
    const list = items.length
      ? `<ul class="list">${items.map((r) => `<li>${esc(r.archive_number || r.archive_code)}${
        r.status && r.status !== '在库' ? `<span class="tag">${esc(r.status)}</span>` : ''}</li>`).join('')}</ul>`
      : '<p class="muted">该盒目前没有装档案。</p>';
    res.end(scanShell(`档案盒 ${box.box_code}`, `
      <div class="card">
        <h1>档案盒信息</h1>
        <div class="big">${esc(box.box_code)}</div>
        <div class="kv"><span class="k">盒标题</span><span class="v">${esc(box.title || '—')}</span></div>
        <div class="kv"><span class="k">门类</span><span class="v">${esc(box.type_code || '—')}${box.year ? ' · ' + esc(box.year) + ' 年' : ''}</span></div>
        <div class="kv"><span class="k">存放库位</span><span class="v">${esc(box.loc_code || '未上架')}${box.loc_name ? ' ' + esc(box.loc_name) : ''}</span></div>
        <div class="kv"><span class="k">盒内件数</span><span class="v">${items.length} / ${Number(box.capacity) || 0}</span></div>
      </div>
      <div class="card" style="margin-top:12px">
        <h1>盒内档案（${items.length} 件）</h1>
        ${list}
      </div>`));
  }

  // ============================================================
  // 单件档案二维码（H 级纠错 / 静区 4 / 模块 10px，随系统启动自动生成）
  // ============================================================

  /** 二维码图片存放目录 */
  function qrDir() {
    return path.join(config.dataDir, 'qrcodes');
  }

  function archiveForQr(id) {
    return q.get('SELECT id, archive_number, archive_code, title, updated_at, created_at FROM archives WHERE id=?', id);
  }

  /** 读一个数值型设置项，带范围钳制与默认值 */
  function settingNum(key, dflt, lo, hi) {
    return settingNum2(settingOf(key, ''), dflt, lo, hi);
  }

  /** 把请求参数里的字符串解析成带范围钳制的整数 */
  function settingNum2(raw, dflt, lo, hi) {
    if (raw === null || raw === undefined || raw === '') return dflt;
    const n = Number(raw);
    if (!Number.isFinite(n)) return dflt;
    return Math.min(hi, Math.max(lo, Math.round(n)));
  }

  /**
   * 当前生效的二维码参数。
   * 默认：纠错 H、静区 6 个模块、每模块 15 像素；
   * 都可在「系统管理 → 档号规则」里改（settings 表的 qr.border / qr.box_size）。
   */
  function qrOpts() {
    return {
      ecLevel: archiveQrLib.QR_OPTS.ecLevel,
      margin: settingNum('qr.border', archiveQrLib.QR_OPTS.margin, 0, 16),
      scale: settingNum('qr.box_size', archiveQrLib.QR_OPTS.scale, 1, 40),
    };
  }

  /** 生成/读取某份档案的二维码图片。
   * 文件不存在就即时生成，保证「点一下一定有图」，不会出现空图。
   */
  function ensureArchiveQr(a, opts = {}) {
    const o = qrOpts();
    return archiveQrLib.generateOne(a, {
      dir: qrDir(),
      force: !!opts.force,
      margin: o.margin,
      scale: o.scale,
      ecLevel: o.ecLevel,
      // 二维码内容：默认是「公网网址」，扫码后落地页先显示档案号再给可点链接
      content: archiveQrContent(a),
      // 文件名走「全库计划」，与批量生成的结果完全一致（重名档案的后缀也一致）
      name: archiveQrLib.plannedBaseName(db, a),
    });
  }

  // -------- 二维码内容与公网地址 --------

  /** 落地页签名密钥；首次使用时生成并写进设置表，之后固定 */
  function qrSignKey() {
    let k = settingOf('qr.sign_key', '');
    if (!k) {
      k = qrContent.newSignKey();
      setSetting('qr.sign_key', k);
    }
    return k;
  }

  /** 二维码里使用的网址前缀（公网地址优先），以及它到底是公网还是内网 */
  function qrBaseInfo(req) {
    const configured = settingOf('qr.base_url', '').trim().replace(/\/+$/, '');
    if (configured) {
      const c = qrContent.classifyBase(configured);
      return { base: configured, source: 'setting', classify: c };
    }
    const port = (config && (config.actualPort || config.port)) || 8787;
    const hostHdr = String((req && req.headers && req.headers.host) || '');
    let base;
    let source;
    if (hostHdr && !isLoopbackHost(hostHdr)) {
      base = urlScheme() + '://' + hostHdr;
      source = 'request';
    } else {
      const lan = lanIPv4List();
      base = lan.length ? `${urlScheme()}://${lan[0].address}:${port}` : `${urlScheme()}://127.0.0.1:${port}`;
      source = lan.length ? 'lan-auto' : 'loopback';
    }
    return { base, source, classify: qrContent.classifyBase(base) };
  }

  /**
   * 档案二维码里写的文字。
   * 默认 url 模式：公网网址 —— 扫码打开落地页，页面上先大字显示档案号，再给可点链接。
   */
  function archiveQrContent(a) {
    const mode = settingOf('qr.archive_mode', 'url') || 'url';
    const b = qrBaseInfo(null);
    return qrContent.archiveQrText(a, { mode, base: b.base, signKey: qrSignKey() });
  }

  /**
   * 二维码尺寸信息。
   *
   * 为什么需要这个接口：二维码的「模块数」随内容长度变化（版本 1~10，模块数 21~57），
   * 所以固定像素尺寸显示是不对的 —— 长档号的码会小到扫不出。
   * 前端先问一下这里，就能按「每个模块至少 N 像素」算出合适的显示尺寸，
   * 并且按同一尺寸去请求图片，做到「显示尺寸 = 图片原生尺寸」，不被浏览器缩放糊边。
   */
  route('GET', '/api/qrcode/info', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const text = url.searchParams.get('text') || '';
    if (!text) return fail(res, 400, '缺少 text 参数');
    const o = qrOpts();
    const ecLevel = (url.searchParams.get('ec') || o.ecLevel).toUpperCase();
    try {
      const m = qrcode.qrMatrix(text, { ecLevel });
      ok(res, {
        content: text,
        version: m.version,
        modules: m.size,
        margin: o.margin,
        cells: m.size + o.margin * 2,     // 含静区后的总格数
        ec_level: ecLevel,
        box_size: o.scale,
        // 按当前默认参数生成时，图片的原生像素尺寸
        natural_px: (m.size + o.margin * 2) * o.scale,
      });
    } catch (e) { fail(res, 400, e.message); }
  });

  /** 单件二维码 PNG（可直接 <img src> 或下载）
   *  ?px=N    按目标像素输出，保证图片原生尺寸是「整数个模块边长」，显示时不需要缩放
   *  ?scale=N 直接指定模块边长
   *  ?download=1 带附件头
   */
  route('GET', '/api/archives/:id/qrcode.png', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = archiveForQr(Number(params.id));
    if (!a) return fail(res, 404, '档案不存在');

    // 内容必须与落盘的那份一致（默认是公网落地页网址，不是裸档号）
    const content = archiveQrContent(a);
    const o = qrOpts();
    const px = Number(url.searchParams.get('px')) || 0;
    const scaleParam = Number(url.searchParams.get('scale')) || 0;
    let buf, name, meta;
    try {
      if (px > 0 || scaleParam > 0) {
        // 按请求尺寸现算，不落盘（落盘的那份始终是标准参数）
        const margin = settingNum('qr.border', o.margin, 0, 16);
        const ecLevel = o.ecLevel;
        let scale = scaleParam > 0 ? scaleParam : 0;
        if (!scale) {
          const cells = qrcode.qrMatrix(content, { ecLevel }).size + margin * 2;
          scale = Math.max(1, Math.floor(px / cells));
        }
        meta = qrcode.qrPng(content, { ecLevel, margin, scale });
        buf = meta.buffer;
        name = archiveQrLib.qrBaseName(a) + '.png';
      } else {
        const r = ensureArchiveQr(a, { force: url.searchParams.get('rebuild') === '1' });
        if (r.error) return fail(res, 500, '生成二维码失败：' + r.error);
        buf = fs.readFileSync(r.file);
        name = r.name;
        meta = { size: r.size, scale: r.scale, pixels: r.pixels, margin: r.margin };
      }
    } catch (e) {
      return fail(res, 500, '生成二维码失败：' + e.message);
    }
    const download = url.searchParams.get('download') === '1';
      res.writeHead(200, {
        'Content-Type': 'image/png',
        'Content-Length': buf.length,
        'Cache-Control': 'no-cache',
        'X-QR-Modules': String(meta && meta.size ? meta.size : ''),
        'X-QR-Scale': String(meta && meta.scale ? meta.scale : ''),
        'X-QR-Pixels': String(meta && meta.pixels ? meta.pixels : ''),
        'Content-Disposition': (download ? 'attachment' : 'inline') + '; filename="' + encodeURIComponent(name) + '"',
      });
      res.end(buf);
  });

  /** 二维码生成情况统计 */
  route('GET', '/api/qrcodes/stats', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const dir = qrDir();
    let files = 0, bytes = 0;
    try {
      for (const f of fs.readdirSync(dir)) {
        if (!/\.png$/i.test(f)) continue;
        files += 1;
        try { bytes += fs.statSync(path.join(dir, f)).size; } catch (_) { /* 忽略 */ }
      }
    } catch (_) { /* 目录还不存在 */ }
    const total = q.scalar('SELECT COUNT(*) FROM archives') || 0;
    const py = pythonQrLib.detect();
    const o = qrOpts();
    ok(res, {
      archives: total,
      images: files,
      missing: Math.max(0, total - files),
      bytes,
      dir,
      ec_level: o.ecLevel,
      margin: o.margin,
      scale: o.scale,
      engine: settingOf('qr.engine', 'auto') || 'auto',
      python_available: !!py.available,
      python_exe: py.available ? py.exe : '',
      python_version: py.available ? py.version : '',
      python_reason: py.available ? '' : (py.reason || ''),
    });
  });

  /**
   * 批量重建二维码（管理员）。
   * 默认只补齐缺失的；force=true 全部重写；engine 可指定 python / builtin / auto。
   */
  route('POST', '/api/qrcodes/rebuild', async (req, res) => {
    const u = requireRole(req, res, 'admin');
    if (!u) return;
    const b = await readJson(req).catch(() => ({}));
    const force = !!(b && b.force === true);
    const engine = String((b && b.engine) || settingOf('qr.engine', 'auto') || 'auto').toLowerCase();
    const o = qrOpts();
    const st = archiveQrLib.generateAllWithEngine({
      db, dataDir: config.dataDir, force, engine,
      border: o.margin, boxSize: o.scale, ecLevel: o.ecLevel,
      // 二维码内容：按当前设置算（公网网址 / 档案号+网址 / 纯档案号）
      contentFor: (a) => archiveQrContent(a),
      baseUrl: qrBaseInfo(null).base,
      archiveMode: settingOf('qr.archive_mode', 'url') || 'url',
      signKey: qrSignKey(),
      onProgress: () => {},
    });
    if (!st.ok) {
      return fail(res, 500, st.reason || '生成失败');
    }
    // 地址变了（本机 IP 是 DHCP 的，随时会变）会自动整体重写，这里明确告诉用户，
    // 免得以为「什么都没发生」——已经打印出去的旧标签必须重新打印。
    const staleNote = st.staleDetected && st.staleDetected.stale
      ? `检测到网址或参数变化（内容变化 ${st.staleDetected.contentChanged} 张`
        + `${st.staleDetected.paramsChanged ? '，静区/模块边长也变了' : ''}），已自动重写全部图片；`
        + '已经打印贴在盒子上的旧标签不会自动更新，需要重新打印。'
      : '';
    log(u, '重建档案二维码', `${force ? '全部重写' : '补齐缺失'}／引擎 ${st.engine}`,
      `新生成 ${st.created} / 已存在 ${st.skipped} / 失败 ${st.failed} / 清理孤儿 ${st.orphansRemoved || 0}`
      + (staleNote ? `　${staleNote}` : ''), clientIp(req));
    ok(res, Object.assign({}, st, { note: staleNote }));
  });

  // ============================================================
  // 档案盒二维码批量生成与打包下载
  //   每个盒子一张**不同**的码（盒号不同 → 令牌不同），这里的价值是
  //   「一次性全部生成、打包成 ZIP 下载」，拿去印刷店直接印，不用一个盒一个盒点。
  // ============================================================

  /** 生成所有档案盒的二维码（增量；地址/参数变了会自动整体重写） */
  route('POST', '/api/boxes/qrcodes/rebuild', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req).catch(() => ({}));
    const force = !!(b && b.force === true);
    const o = qrOpts();
    const st = boxQrLib.generateAll({
      db, dataDir: config.dataDir, force,
      margin: o.margin, scale: o.scale, ecLevel: o.ecLevel,
      contentFor: (box) => boxQrText(box, null),
    });
    const staleNote = st.contentChanged
      ? `检测到网址或参数变化（内容变化 ${st.contentChanged} 张${st.paramsChanged ? '，静区/模块边长也变了' : ''}），已自动重写；`
        + '已经打印贴在盒子上的旧标签不会自动更新，需要重新打印。'
      : '';
    log(u, '重建档案盒二维码', force ? '全部重写' : '补齐缺失',
      `新生成 ${st.created} / 已存在 ${st.skipped} / 失败 ${st.failed} / 清理孤儿 ${st.orphansRemoved || 0}`,
      clientIp(req));
    ok(res, Object.assign({}, st, { note: staleNote }));
  });

  /** 档案盒二维码统计（盒数 / 图片数 / 缺失数） */
  route('GET', '/api/boxes/qrcodes/stats', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const o = qrOpts();
    ok(res, Object.assign(boxQrLib.stats({ db, dataDir: config.dataDir }), {
      ec_level: o.ecLevel, margin: o.margin, scale: o.scale,
      mode: settingOf('qr.mode', 'url'),
      base_url: qrBaseInfo(null).base,
    }));
  });

  /** 打包下载全部档案盒二维码（ZIP：每盒一张 PNG + 清单.csv） */
  route('GET', '/api/boxes/qrcodes/download', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const o = qrOpts();
    // 先补齐缺失的，保证下载到的和库里一致
    boxQrLib.generateAll({
      db, dataDir: config.dataDir, force: false,
      margin: o.margin, scale: o.scale, ecLevel: o.ecLevel,
      contentFor: (box) => boxQrText(box, null),
    });
    const dir = boxQrLib.boxQrDir(config.dataDir);
    const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => /\.(png|csv)$/i.test(f)) : [];
    if (!files.length) return fail(res, 400, '还没有任何档案盒，或二维码尚未生成');
    let buf;
    try {
      const zip = new ZipWriter();
      for (const f of files.sort()) zip.addFile(f, path.join(dir, f));
      buf = zip.toBuffer();
    } catch (e) {
      return fail(res, 500, '打包失败：' + e.message);
    }
    log(u, '下载档案盒二维码', `${files.length} 个文件`, '', clientIp(req));
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': contentDisposition(`档案盒二维码_${today()}.zip`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  /**
   * 单件档案二维码标签（打印用）。
   * 一页 A4 排多枚小标签，每枚含档号、题名与二维码，剪下贴到卷皮或档案盒上。
   * 图片以 base64 内嵌，打印页不依赖任何外部请求，断网也能打印。
   */
  route('GET', '/api/print/archive/:id', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const a = loadVisibleArchive(req, res, u, params.id);
    if (!a) return;
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const box = a.box_id ? q.get(`SELECT b.box_code, l.code AS loc_code FROM archive_boxes b
                                   LEFT JOIN locations l ON l.id=b.location_id WHERE b.id=?`, a.box_id) : null;
    const content = archiveQrLib.qrContent(a);       // 纸上显示给人看的档号
    const qrText = archiveQrContent(a);              // 真正写进二维码的内容（短落地页网址）
    const o = qrOpts();

    /**
     * 标签上的二维码尺寸必须**按模块数算**，不能写死。
     *
     * 物理尺寸目标：每个模块 0.8mm（手机扫纸面二维码的经验安全值；
     * 0.5mm 是理论下限，普通打印机墨点扩散之后基本扫不出）。
     * 上限 52mm：标签内宽 = 60mm - 左右各 3mm = 54mm。
     *
     * 图片按约 300dpi 生成，让「图片原生像素」≈「打印物理像素」，
     * 浏览器打印时不需要缩放 —— 一缩放模块边缘就被插值糊掉。
     */
    const TARGET_MODULE_MM = 0.8;
    const MAX_QR_MM = 52;
    let dataUri = '';
    let qrMm = 0;
    let qrCells = 0;
    let qrModuleMm = 0;
    let qrScale = 0;
    try {
      const m = qrcode.qrMatrix(qrText, { ecLevel: o.ecLevel });
      qrCells = m.size + o.margin * 2;
      qrMm = Math.min(MAX_QR_MM, Math.round(qrCells * TARGET_MODULE_MM * 10) / 10);
      qrModuleMm = qrMm / qrCells;
      qrScale = Math.max(4, Math.round((300 / 25.4) * qrModuleMm));
      const png = qrcode.qrPng(qrText, { ecLevel: o.ecLevel, margin: o.margin, scale: qrScale });
      dataUri = 'data:image/png;base64,' + png.buffer.toString('base64');
    } catch (_) {
      // 算不出来（内容异常长）就退回落盘那张，至少还能出纸
      try {
        const r = ensureArchiveQr(a);
        if (!r.error) dataUri = 'data:image/png;base64,' + fs.readFileSync(r.file).toString('base64');
      } catch (_) { /* 生成失败就只打印文字，不影响出纸 */ }
    }
    const count = Math.max(1, Math.min(24, Number(url.searchParams.get('count')) || 12));
    const qrImgStyle = qrMm ? ` style="width:${qrMm}mm;height:${qrMm}mm"` : '';
    const tooSmall = qrModuleMm > 0 && qrModuleMm < 0.7;
    const label = `
      <div class="qr-label">
        <div class="lbl-head">${esc(unit)}</div>
        <div class="lbl-code">${esc(content)}</div>
        <div class="lbl-title">${esc(a.title || '')}</div>
        ${dataUri ? `<img class="lbl-qr"${qrImgStyle} src="${dataUri}" alt="二维码">` : '<div class="muted">二维码生成失败</div>'}
        <div class="lbl-foot">${esc(String(a.year || ''))}${a.retention ? ' · ' + esc(a.retention) : ''}${box && box.loc_code ? ' · ' + esc(box.loc_code) : ''}</div>
      </div>`;
    const html = printShell('档案二维码标签', `
      <div class="print-head"><h1>档 案 二 维 码 标 签</h1><div class="meta">
        档号：${esc(content)}　题名：${esc(a.title || '')}<br>
        纠错等级 <b>${esc(o.ecLevel)}</b>（约 30% 容错）· 静区 <b>${o.margin}</b> 个模块 ·
        二维码 <b>${qrMm}mm</b> 见方（共 ${qrCells} 格，每模块 <b>${qrModuleMm.toFixed(2)}mm</b>）<br>
        沿虚线剪下贴到卷皮上；<b>二维码四周的白边不要剪掉</b>（那是静区，剪掉就扫不出）。
        ${tooSmall ? '<br><b>提示：每模块不足 0.7mm，普通打印机上可能扫不出。'
          + '可到「系统管理 → 档号规则」把「档案二维码内容」改成「只有档案号」——'
          + '码会立刻变小变稀疏，标签上每个模块就大了。</b>' : ''}</div></div>
      <div class="label-wrap">${Array.from({ length: count }, () => label).join('')}</div>
      <div class="rep-block" style="margin-top:18px">
        <div class="rep-title">归档章（DA/T 22—2015 §5.4.4 必备项）</div>
        ${archiveStamp.stampHtml(a, stampSettings())}
        <div class="stamp-note">加盖位置：归档文件首页上端居中。上表为电子样式，实体件仍须按单位规定加盖红色印章。</div>
      </div>`,
      !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  /**
   * 网络环境自检：告诉用户二维码里到底写了什么地址、手机该连哪个网。
   * 这是排查「二维码扫不出来」最快的一步。
   */
  route('GET', '/api/system/net', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const port = (config && (config.actualPort || config.port)) || 8787;
    const lan = lanIPv4List();
    const b = qrBaseInfo(req);
    const py = pythonQrLib.detect();
    ok(res, {
      version: (config && config.version) || '',
      bind_host: (config && config.host) || '127.0.0.1',
      lan_open: !!(config && config.host === '0.0.0.0'),
      port,
      base_url: b.base,
      base_source: b.source,               // setting / request / lan-auto / loopback
      base_kind: b.classify.kind,          // public / private / loopback / invalid
      base_reason: b.classify.reason,
      base_is_public: b.classify.ok && b.classify.kind === 'public',
      archive_mode: settingOf('qr.archive_mode', 'url') || 'url',
      qr_mode: settingOf('qr.mode', 'url'),
      qr_engine: settingOf('qr.engine', 'auto') || 'auto',
      qr_border: settingNum('qr.border', archiveQrLib.QR_OPTS.margin, 0, 16),
      qr_box_size: settingNum('qr.box_size', archiveQrLib.QR_OPTS.scale, 1, 40),
      qr_python_available: !!py.available,
      qr_python_exe: py.available ? py.exe : '',
      qr_python_version: py.available ? py.version : '',
      qr_python_reason: py.available ? '' : (py.reason || ''),
      scan_public: settingOf('qr.scan_public', '1') !== '0',
      candidates: lan.map((x) => ({ name: x.name, address: x.address, url: `${urlScheme()}://${x.address}:${port}` })),
    });
  });

  /**
   * 给 IT / 网管的「固定地址申请单」（可打印、可一键复制）。
   *
   * 为什么要有这一页：
   *   二维码印出去就改不了了。只要本机 IP 是 DHCP 自动获取的，哪天变了，
   *   已经贴在盒子上的二维码就会一起失效。要彻底避免，只能让 IT 做一件事：
   *   ① 在内网 DNS 里加一条域名记录（推荐，IP 变了只改 DNS，旧标签永久有效），或
   *   ② 按网卡 MAC 做 DHCP 保留 / 分配静态 IP。
   *   这两件都在本系统之外。这一页把 IT 需要的全部信息（计算机名、MAC、当前 IP、
   *   端口、需要放行的防火墙端口）自动列出来，省得用户手抄，也免得抄错。
   */
  route('GET', '/api/system/address-request', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const os = require('node:os');
    const port = (config && (config.actualPort || config.port)) || 8787;
    const b = qrBaseInfo(req);
    const hostname = os.hostname();

    // 网卡：给出所有「已启用且非回环」的 IPv4 + MAC
    const nics = [];
    const ifaces = os.networkInterfaces();
    for (const [name, list] of Object.entries(ifaces)) {
      for (const x of list || []) {
        if (x.family !== 'IPv4' || x.internal) continue;
        nics.push({ name, address: x.address, mac: (x.mac || '').toUpperCase() });
      }
    }
    // 当前二维码里用的那个地址对应的网卡值得单独标出来
    const cur = nics.find((n) => b.base.includes(n.address));

    const boxSt = boxQrLib.stats({ db, dataDir: config.dataDir });
    const text = [
      '申请一台内网服务器的网络配置',
      '============================================================',
      `计算机名    : ${hostname}`,
      `服务端口    : TCP ${port}`,
      cur ? `网卡 / MAC  : ${cur.name} / ${cur.mac}` : `网卡 / MAC  : ${nics.map((n) => n.mac).join(' , ') || '（未取到）'}`,
      `当前 IP     : ${nics.map((n) => n.address).join(' , ') || '（未取到）'}`,
      `当前二维码里用的地址 : ${b.base}`,
      '',
      '请求事项（满足任意一项即可）：',
      '  ① 在内网 DNS 中为本机增加一条 A 记录（例如 dangan.xxx.gov.cn），',
      '     并在本机 IP 变动时同步更新该记录；或',
      '  ② 为该网卡 MAC 做 DHCP 保留 / 分配静态 IP，使 IP 不再变化。',
      `  ③ 放行入站 TCP ${port}（供同一内网的其他电脑与手机访问）。`,
      '',
      '原因：',
      `  档案盒与卷皮上要印刷二维码（目前 ${boxSt.boxes} 个盒子，每盒一张不同的码），`,
      '  二维码印刷后无法更改，且必须在浏览器地址栏里长期可访问，',
      '  因此需要一个**长期不变的内网地址**。',
      '  若地址会变，已印出的标签将全部失效、需要重印。',
      '',
      `申请时间：${new Date().toLocaleString('zh-CN')}`,
    ].join('\n');

    const rows = nics.map((n) => `<tr><td>${esc(n.name)}</td><td class="mono">${esc(n.address)}</td>`
      + `<td class="mono">${esc(n.mac)}</td></tr>`).join('')
      || '<tr><td colspan="3" class="muted">没有取到网卡信息</td></tr>';

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(printShell('固定地址申请单', `
      <div class="print-head"><h1>固定内网地址 申请单</h1><div class="meta">
        由「档案管理系统」自动生成，交网络管理员即可。带 * 的是必须的信息。</div></div>

      <table class="print-table" style="margin-top:14px">
        <tbody>
          <tr><th style="width:150px">计算机名 *</th><td class="mono">${esc(hostname)}</td></tr>
          <tr><th>服务端口 *</th><td class="mono">TCP ${port}</td></tr>
          <tr><th>当前二维码里用的地址</th><td class="mono">${esc(b.base)}<span class="muted">
            （${esc(b.classify.reason)}）</span></td></tr>
          <tr><th>待印二维码数量</th><td>${boxSt.boxes} 个档案盒（每盒一张不同的码）</td></tr>
        </tbody>
      </table>

      <h3 style="margin:16px 0 6px">本机网卡</h3>
      <table class="print-table"><thead><tr><th>网卡</th><th>IPv4</th><th>MAC 地址 *</th></tr></thead>
        <tbody>${rows}</tbody></table>

      <h3 style="margin:16px 0 6px">请求事项（满足任意一项即可）</h3>
      <ol style="line-height:2;font-size:13px">
        <li><b>在内网 DNS 中为本机增加一条 A 记录</b>（例如 <span class="mono">dangan.xxx.gov.cn</span>），
            并在本机 IP 变动时同步更新。<b>推荐</b>：这样已经印出去的二维码永久有效。</li>
        <li>或：为该网卡 <b>MAC 做 DHCP 保留 / 分配静态 IP</b>，使 IP 不再变化。</li>
        <li>放行入站 <b>TCP ${port}</b>（供同一内网的其他电脑与手机访问）。</li>
      </ol>

      <h3 style="margin:16px 0 6px">原因</h3>
      <p style="font-size:13px;line-height:1.9">
        档案盒与卷皮上要<b>印刷二维码</b>，二维码印刷后无法更改，且必须在浏览器地址栏里长期可访问，
        因此需要一个<b>长期不变的内网地址</b>。若地址会变，已印出的标签将全部失效、需要重印。
      </p>

      <h3 style="margin:16px 0 6px">可直接复制的纯文本（Ctrl+C 后发给管理员）</h3>
      <pre id="req-text" style="white-space:pre-wrap;font-size:12.5px;line-height:1.7;border:1px solid #ccc;
        padding:10px;background:#fafafa;border-radius:6px">${esc(text)}</pre>
      <div style="margin-top:10px">
        <button onclick="navigator.clipboard.writeText(document.getElementById('req-text').textContent)
          .then(()=>{this.textContent='已复制 ✓'}).catch(()=>{this.textContent='复制失败，请手工选中'})"
          style="padding:8px 18px;font-size:14px">复制纯文本</button>
        <button onclick="window.print()" style="padding:8px 18px;font-size:14px;margin-left:8px">打印</button>
      </div>
      <p class="muted" style="margin-top:14px;font-size:12px">
        说明：本页只列出本机的网络信息，不包含任何档案内容。
      </p>`, false));
  });

  /**
   * 二维码自检页（免登录，手机也能直接打开）。
   *
   * 用途：把「码扫不出」和「网址打不开」这两种完全不同的故障分开。
   *   第 1 个码是固定文本，不依赖网络 —— 扫不出就是码/手机/显示的问题；
   *   第 1 个能扫、第 2 个扫出网址却打不开 —— 那是网络/网段/防火墙的问题。
   *
   * ★ 这里的二维码必须**内嵌成 data: 图片**，不能写 <img src="/api/qrcode.svg?...">。
   *   踩过的坑：这个页面是免登录的，而 /api/qrcode.svg 那条接口要求登录 ——
   *   于是手机上打开这一页时，两个二维码全是「图片加载失败」的破图，
   *   页面上根本没有码可扫。而这个页面本来是专门用来诊断「扫不出来」的，
   *   结果它自己就不显示码，等于把人往沟里带。内嵌之后这一页完全自给自足，
   *   少一次请求、也不再受登录状态影响。
   */
  route('GET', '/api/qrcode/selftest', async (req, res) => {
    const base = qrBaseUrl(req);
    const plain = 'ARCHIVE-QR-SELFTEST-12345';
    const url = `${base}/api/s/SELFTEST-BOX`;
    const o = qrOpts();
    // 内嵌 PNG：按「格数 × 整数倍率」算，显示尺寸 = 图片原生尺寸，浏览器不缩放（模块边缘才是硬的）。
    // 手机屏幕的物理像素倍率通常是 2~3，所以 6~7 个 CSS 像素的模块在屏幕上约 1.6~1.9mm，足够扫。
    const img = (t) => {
      try {
        const cells = qrcode.qrMatrix(t, { ecLevel: o.ecLevel }).size + o.margin * 2;
        let scale = Math.floor(330 / cells);
        if (scale < 6) scale = 6;
        if (scale > 24) scale = 24;
        const png = qrcode.qrPng(t, { ecLevel: o.ecLevel, margin: o.margin, scale });
        return `<img alt="二维码" src="data:image/png;base64,${png.buffer.toString('base64')}"`
          + ` width="${png.pixels}" height="${png.pixels}"`
          + ` style="image-rendering:pixelated;background:#fff;max-width:100%">`
          + `<div class="muted" style="font-size:12px;margin-top:4px">共 ${cells} 格 · 每模块 ${scale}px · 整图 ${png.pixels}px</div>`;
      } catch (e) {
        return `<div class="muted">二维码生成失败：${esc(e.message)}</div>`;
      }
    };
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(scanShell('二维码自检', `
      <div class="card">
        <h1>二维码自检</h1>
        <p class="muted">用微信「扫一扫」依次扫下面两个码，结果能直接告诉我们问题出在哪一环。</p>
        <p class="muted">这一页的二维码是<b>直接画在网页里</b>的（不依赖任何图片接口），所以只要能看到码，就能放心扫。</p>
      </div>
      <div class="card" style="margin-top:12px;text-align:center">
        <h1>第 1 个：固定文本码</h1>
        <div class="muted" style="margin-bottom:8px">不依赖网络。微信应读出：<span class="mono">${esc(plain)}</span></div>
        ${img(plain)}
        <div class="muted" style="margin-top:8px">扫不出 → 问题在手机、屏幕显示或打印质量，与系统无关。</div>
      </div>
      <div class="card" style="margin-top:12px;text-align:center">
        <h1>第 2 个：系统地址码</h1>
        <div class="muted" style="margin-bottom:8px">微信应读出：<span class="mono">${esc(url)}</span></div>
        ${img(url)}
        <div class="muted" style="margin-top:8px">能读出文字但打不开 → 问题在网络：手机要与本机同一局域网，且服务需用「局域网访问.bat」启动。</div>
      </div>
      <div class="card" style="margin-top:12px">
        <h1>判断对照</h1>
        <div class="kv"><span class="k">1 扫不出</span><span class="v">码/手机/显示问题</span></div>
        <div class="kv"><span class="k">1 能扫<br>2 扫不出</span><span class="v">系统生成的码有问题（请把这一页截图反馈）</span></div>
        <div class="kv"><span class="k">两个都能读出文字</span><span class="v">码没问题，剩下的只是网络能不能通</span></div>
        <div class="kv"><span class="k">根本看不到码</span><span class="v">这一页加载不全，重新刷新一次；若仍看不到请截图反馈</span></div>
      </div>
      <div class="card" style="margin-top:12px">
        <h1>连通性自检</h1>
        <p class="muted">在手机浏览器地址栏手动输入下面这个地址，能直接确认「手机到服务器的网络通不通」：</p>
        <div class="mono" style="word-break:break-all;margin:6px 0">${esc(base)}/api/ping</div>
        <p class="muted">看到一行 <b>OK 豆包信创档案管理系统在运行</b> 就说明网络通、服务在跑；一直转圈或一片空白就是网络不通。</p>
      </div>`));
  });

  /**
   * 通用二维码 PNG：/api/qrcode.png?text=...&scale=15&border=6&ec=H
   * 调试页用它把同一段内容按不同尺寸出图，方便找出「多大才扫得出」。
   */
  route('GET', '/api/qrcode.png', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const text = url.searchParams.get('text') || '';
    if (!text) return fail(res, 400, '缺少 text 参数');
    const o = qrOpts();
    const scale = settingNum2(url.searchParams.get('scale'), o.scale, 1, 40);
    const margin = settingNum2(url.searchParams.get('border'), o.margin, 0, 16);
    const ecLevel = (url.searchParams.get('ec') || o.ecLevel).toUpperCase();
    try {
      const png = qrcode.qrPng(text, { ecLevel, margin, scale });
      res.writeHead(200, {
        'Content-Type': 'image/png',
        'Content-Length': png.buffer.length,
        'Cache-Control': 'no-cache',
        'X-QR-Modules': String(png.size),
        'X-QR-Scale': String(png.scale),
        'X-QR-Margin': String(png.margin),
        'X-QR-Pixels': String(png.pixels),
      });
      res.end(png.buffer);
    } catch (e) { fail(res, 400, e.message); }
  });

  /**
   * 二维码调试页。
   *
   * 用途：把生成的二维码「原图直出」，并在浏览器里实测它的实际像素，
   * 一眼看出到底是码的问题、尺寸的问题、还是手机的问题。
   * 页面上每条检查都给出实测值和结论，不需要用户自己去猜。
   */
  route('GET', '/api/qrcode/debug', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;

    // 支持 ?archive=<id> 直接调某份档案的二维码，或 ?text= 自定义内容
    let content = url.searchParams.get('text') || '';
    let archiveNote = '';
    const archiveId = Number(url.searchParams.get('archive')) || 0;
    if (archiveId) {
      const a = archiveForQr(archiveId);
      if (!a) return fail(res, 404, '档案不存在');
      content = archiveQrContent(a);
      archiveNote = `档案：${esc(a.archive_number || a.archive_code || '')} ${esc(a.title || '')}`;
    }
    if (!content) content = '2026-WS-001';

    const o = qrOpts();
    let m;
    try { m = qrcode.qrMatrix(content, { ecLevel: o.ecLevel }); }
    catch (e) { return fail(res, 400, '内容过长，无法生成二维码：' + e.message); }

    const cells = m.size + o.margin * 2;
    const scales = [4, 6, 10, 15, 20];
    const ladder = scales.map((s) => {
      const px = cells * s;
      return `<div class="lv">
        <img src="/api/qrcode.png?text=${encodeURIComponent(content)}&scale=${s}&border=${o.margin}&ec=${o.ecLevel}"
             width="${px}" height="${px}" alt="scale ${s}">
        <div class="cap">每模块 <b>${s}</b> px · 整图 <b>${px}</b> px</div>
      </div>`;
    }).join('');

    const html = scanShell('二维码调试', `
      <div class="card">
        <h1>二维码调试</h1>
        <div class="kv"><span class="k">二维码内容</span><span class="v mono">${esc(content)}</span></div>
        ${archiveNote ? `<div class="kv"><span class="k">来源</span><span class="v">${archiveNote}</span></div>` : ''}
        <div class="kv"><span class="k">版本 / 模块</span><span class="v">v${m.version} · ${m.size} 个模块（含静区 ${cells} 格）</span></div>
        <div class="kv"><span class="k">纠错等级</span><span class="v">${o.ecLevel}（约 30% 容错）</span></div>
        <div class="kv"><span class="k">静区(留白)</span><span class="v">${o.margin} 个模块${o.margin >= 4 ? '（≥ 规范要求的 4，合格）' : '（<b>小于规范要求的 4，建议调到 6</b>）'}</span></div>
        <div class="kv"><span class="k">每模块像素</span><span class="v">${o.scale} px（系统当前设置）</span></div>
        <div class="kv"><span class="k">默认整图尺寸</span><span class="v">${cells * o.scale} × ${cells * o.scale} px</span></div>
      </div>

      <div class="card" style="margin-top:12px">
        <h1>① 浏览器实测（从服务器真实取回的图里量出来）</h1>
        <div id="measure">正在测量…</div>
      </div>

      <div class="card" style="margin-top:12px">
        <h1>② 原图直出（下面每张都是 1:1 原始尺寸，没有被任何样式缩放）</h1>
        <p class="muted">用手机依次扫下面几张。哪一张开始能扫出来，就说明你需要多大的码；
        全都扫不出，说明问题不在系统生成的码上。</p>
        <div class="ladder" style="overflow:auto">${ladder}</div>
      </div>

      <div class="card" style="margin-top:12px">
        <h1>③ 对照用的固定文本码（不依赖网络，也不依赖档案数据）</h1>
        <p class="muted">这一张的内容是固定字符串 <span class="mono">ARCHIVE-QR-SELFTEST-12345</span>。
        如果这张也扫不出，那就和档案系统完全无关了 —— 是手机、屏幕或光线的问题。</p>
        <div style="text-align:center">
          <img src="/api/qrcode.png?text=ARCHIVE-QR-SELFTEST-12345&scale=15&border=${o.margin}&ec=${o.ecLevel}"
               width="${(m.size + o.margin * 2) * 15}" height="${(m.size + o.margin * 2) * 15}" alt="固定文本码"
               style="max-width:100%;height:auto">
        </div>
      </div>

      <div class="card" style="margin-top:12px">
        <h1>④ 怎么把结果反馈给我</h1>
        <p class="muted">请把下面三件事告诉我，我就能定位：</p>
        <ol class="muted" style="padding-left:20px;line-height:1.9">
          <li>第 ② 组里，<b>从哪一档开始能扫出来</b>（比如"10px 以上才行"）</li>
          <li>扫出来显示的是<b>文字还是网址</b>；如果是网址，点开后是<b>空白、报错、还是能打开</b></li>
          <li>第 ① 组里量出来的数字（直接截图这一页即可）</li>
        </ol>
        <div class="flex" style="flex-wrap:wrap;gap:8px;margin-top:8px">
          <a class="btn" href="/api/qrcode.png?text=${encodeURIComponent(content)}&scale=${o.scale}&border=${o.margin}&ec=${o.ecLevel}" download="二维码原图.png">下载原图 PNG</a>
          <a class="btn" href="/api/qrcode.png?text=${encodeURIComponent(content)}&scale=25&border=${o.margin}&ec=${o.ecLevel}" download="二维码超大图.png">下载超大图（25px/模块）</a>
          <a class="btn" href="/api/qrcode/selftest">打开扫码自检页</a>
        </div>
      </div>

      <script>
      (function () {
        var wrap = document.getElementById('measure');
        var img = new Image();
        img.onload = function () {
          try {
            var c = document.createElement('canvas');
            c.width = img.naturalWidth; c.height = img.naturalHeight;
            var ctx = c.getContext('2d');
            ctx.drawImage(img, 0, 0);
            var d = ctx.getImageData(0, 0, c.width, c.height).data;
            var min = 255, max = 0, dark = 0, total = c.width * c.height;
            for (var i = 0; i < d.length; i += 4) {
              var v = Math.round(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]);
              if (v < min) min = v;
              if (v > max) max = v;
              if (v < 128) dark++;
            }
            // 静区实测：从左上角往右找第一个深色像素
            var quiet = 0, w = c.width;
            outer: for (var x = 0; x < w; x++) {
              for (var y = 0; y < Math.min(w, 40); y++) {
                var o = (y * w + x) * 4;
                if (d[o] < 128) { quiet = x; break outer; }
              }
            }
            var scale = ${o.scale};
            var marginPx = ${o.margin} * scale;
            var contrast = (max - min) + ':1';
            var rows = [
              ['图片实际尺寸', c.width + ' × ' + c.height + ' px'],
              ['最暗 / 最亮像素', min + ' / ' + max + '（0=纯黑，255=纯白）'],
              ['对比度', contrast + (min <= 8 && max >= 247 ? '　✅ 满对比，不存在"颜色太浅"' : '　⚠ 对比度不足，建议检查是否被加了滤镜或透明度')],
              ['深色像素占比', (dark / total * 100).toFixed(1) + '%'],
              ['静区实测', quiet + ' px' + (Math.abs(quiet - marginPx) <= 1 ? '　✅ 与设置一致（' + ${o.margin} + ' 模块 × ' + scale + ' px）' : '　⚠ 实测与设置不符')],
              ['每模块像素', scale + ' px' + (scale >= 4 ? '　✅ 屏幕扫描建议 ≥4' : '　⚠ 偏小，建议调大 box_size')]
            ];
            var html = '';
            for (var r = 0; r < rows.length; r++) {
              html += '<div class="kv"><span class="k">' + rows[r][0] + '</span><span class="v">' + rows[r][1] + '</span></div>';
            }
            wrap.innerHTML = html;
          } catch (e) {
            wrap.innerHTML = '<p class="muted">测量失败（可能是浏览器限制 canvas）：' + e.message + '</p>';
          }
        };
        img.onerror = function () { wrap.innerHTML = '<p class="muted">图片加载失败 —— 请确认已登录，或刷新页面重试。</p>'; };
        img.src = '/api/qrcode.png?text=${encodeURIComponent(content)}&scale=${o.scale}&border=${o.margin}&ec=${o.ecLevel}&t=' + Date.now();
      })();
      </script>
      <style>
        .ladder { display:flex; flex-wrap:wrap; gap:16px; align-items:flex-end; justify-content:center; }
        .ladder .lv { text-align:center; }
        .ladder .lv img { display:block; image-rendering:pixelated; background:#fff; border:1px solid #d7dde5; }
        .ladder .cap { font-size:12px; color:#6b7280; margin-top:6px; line-height:1.5; }
      </style>`);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(html);
  });

  route('GET', '/api/qrcode.svg', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const text = url.searchParams.get('text') || '';
    if (!text) return fail(res, 400, '缺少 text 参数');
    try {
      const o = qrOpts();
      const px = Number(url.searchParams.get('px')) || 0;
      const scale = Number(url.searchParams.get('scale')) || 0;
      // 允许单次请求覆盖静区（调试用），否则用系统设置里的值
      const borderRaw = url.searchParams.get('border');
      const margin = borderRaw === null || borderRaw === ''
        ? o.margin : Math.min(16, Math.max(0, Math.round(Number(borderRaw) || 0)));
      const opts = px > 0 ? { px, margin } : { scale: scale || 4, margin };
      const svg = qrcode.qrSvg(text, opts);
      res.writeHead(200, { 'Content-Type': 'image/svg+xml; charset=utf-8', 'Cache-Control': 'private, max-age=600' });
      res.end(svg);
    } catch (e) { fail(res, 400, e.message); }
  });

  /** 档案标签数据（含二维码内容） */
  route('GET', '/api/archives/:id/label', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    if (!loadVisibleArchive(req, res, u, id)) return;
    const a = q.get(`SELECT a.*, c.name AS category_name FROM archives a
                     LEFT JOIN categories c ON c.id=a.category_id WHERE a.id=?`, id);
    if (!a) return fail(res, 404, '档案不存在');
    const box = a.box_id ? q.get(`SELECT b.*, l.code AS loc_code FROM archive_boxes b
                                  LEFT JOIN locations l ON l.id=b.location_id WHERE b.id=?`, a.box_id) : null;
    ok(res, {
      archive_code: a.archive_code,
      archive_number: a.archive_number,
      title: a.title,
      category: a.category_name || '',
      year: a.year,
      retention: a.retention,
      retention_code: a.retention_code,
      box_code: box ? box.box_code : '',
      location: box ? (box.loc_code || '') : (a.location || ''),
      // 二维码内容：默认是公网网址（扫码后落地页先显示档案号，再给可点链接进详情）
      qr_text: archiveQrContent(a),
      // 里面一定包含系统能识别的编号，扫码枪扫到整串网址时也要能解析出来
      qr_code: a.archive_code || a.archive_number,
    });
  });

  /** 打印：案卷目录 / 卷内目录 / 盒脊标签 */
  route('GET', '/api/print/catalog', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const sp = url.searchParams;
    const f = buildFiltersOrFail(res, sp, u);
    if (!f) return;
    const rows = q.all(`SELECT a.*, c.name AS category_name FROM archives a
                        LEFT JOIN categories c ON c.id=a.category_id ${f.sql}
                        ORDER BY a.archive_number, a.archive_code LIMIT 2000`, ...f.params);
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const body = rows.map((r, i) => `<tr>
      <td>${i + 1}</td><td>${esc(r.archive_number || r.archive_code)}</td><td>${esc(r.title)}</td>
      <td>${esc(r.responsible || '')}</td><td>${esc(r.archive_date || '')}</td>
      <td>${esc(String(r.pages || ''))}</td><td>${esc(r.retention)}</td>
      <td>${esc(r.secret_level)}</td><td>${esc(r.location || '')}</td></tr>`).join('');
    const html = printShell('案卷目录', `
      <div class="print-head"><h1>案 卷 目 录</h1><div class="meta">
        全宗名称：${esc(unit)}　共 ${rows.length} 条　打印日期：${new Date().toLocaleDateString('zh-CN')}</div></div>
      <table class="print-table"><thead><tr>
        <th style="width:44px">序号</th><th style="width:150px">档号</th><th>题名</th>
        <th style="width:90px">责任者</th><th style="width:90px">归档日期</th><th style="width:50px">页数</th>
        <th style="width:70px">保管期限</th><th style="width:50px">密级</th><th style="width:90px">存放位置</th>
      </tr></thead><tbody>${body}</tbody></table>`, !!sp.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  route('GET', '/api/print/box/:boxId', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const boxId = Number(params.boxId);
    const box = q.get(`SELECT b.*, l.code AS loc_code, l.name AS loc_name FROM archive_boxes b
                       LEFT JOIN locations l ON l.id=b.location_id WHERE b.id=?`, boxId);
    if (!box) return fail(res, 404, '档案盒不存在');
    // 卷内目录同样按密级过滤：能打印整盒清单，就等于看到了盒内涉密档案的题名
    const boxScope = secretScope(u);
    const items = q.all(
      `SELECT a.* FROM archives a WHERE a.box_id=?${boxScope.sql} ORDER BY a.archive_number, a.archive_code`,
      boxId, ...boxScope.params,
    );
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const rows = items.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.archive_number || r.archive_code)}</td>
      <td>${esc(r.title)}</td><td>${esc(r.archive_date || '')}</td><td>${esc(String(r.pages || ''))}</td>
      <td>${esc(r.retention)}</td></tr>`).join('');
    const qr = safeQr(boxQrText(box, req));
    // 盒脊必备项（DA/T 22—2015 §6.4）：全宗号、年度、保管期限、起止件号、盒号
    const spineMeta = [
      `全宗号 ${q.scalar("SELECT value FROM settings WHERE key='archive.unit_code'") || '—'}`,
      `年度 ${box.year || '—'}`,
      `保管期限 ${box.retention || '—'}`,
      `盒脊 ${Number(box.spine_mm) || 30}mm`,
    ].join('　');
    const html = printShell('卷内目录 / 盒脊标签 / 备考表', `
      <div class="print-head"><h1>卷 内 文 件 目 录</h1><div class="meta">
        全宗名称：${esc(unit)}　盒号：${esc(box.box_code)}　存放位置：${esc(box.loc_code || '')}　共 ${items.length} 件<br>
        盒脊必备项（DA/T 22—2015 §6.4）：${esc(spineMeta)}　起止件号：${esc(items.length ? (items[0].archive_number || items[0].archive_code) : '—')} ~ ${esc(items.length ? (items[items.length - 1].archive_number || items[items.length - 1].archive_code) : '—')}</div></div>
      <table class="print-table"><thead><tr>
        <th style="width:44px">序号</th><th style="width:150px">档号</th><th>题名</th>
        <th style="width:90px">归档日期</th><th style="width:50px">页数</th><th style="width:70px">保管期限</th>
      </tr></thead><tbody>${rows}</tbody></table>
      <div class="page-break"></div>
      <div class="spine-wrap">
        ${[0, 1, 2].map(() => `<div class="spine">
          <div class="spine-title">${esc(unit)}</div>
          <div class="spine-box">${esc(box.box_code)}</div>
          <div class="spine-qr">${qr}</div>
          <div class="spine-loc">${esc(box.loc_code || '')}</div>
        </div>`).join('')}
      </div>
      <div class="page-break"></div>
      ${beikaobiaoInner(box)}`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  /**
   * 档案资料交接单（过程接收，v4.29.0）。
   *
   * 这张纸的作用是**凭据**：这一批资料谁交的、谁收的、交了多少件多少页、什么时候交的。
   * 归档定稿之后它就是这批资料的移交凭证，所以要能打印、要能签字。
   * 件数/页数按当前批次实时统计，不抄批次表里的缓存值 —— 打出来的必须和库里的现在一致。
   */
  route('GET', '/api/print/batch/:id', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const batch = q.get(`SELECT b.*, p.project_no, p.name AS project_name, p.kind AS project_kind
                         FROM intake_batches b LEFT JOIN projects p ON p.id=b.project_id
                         WHERE b.id=?`, Number(params.id));
    if (!batch) return fail(res, 404, '批次不存在');
    // 与其它打印件同一口径：超出密级的件不出现在清单上（清单里的题名本身就是涉密信息）
    const scope = secretScope(u);
    const items = q.all(`SELECT a.id, a.archive_code, a.archive_number, a.title, a.year, a.pages,
        a.archive_state,
        (SELECT COALESCE(SUM(f.pages),0) FROM files f WHERE f.archive_id=a.id AND f.kind='扫描件') AS scanned_pages
      FROM archives a WHERE a.batch_id=?${scope.sql}
      ORDER BY a.archive_number, a.id`, batch.id, ...scope.params);
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const totalPages = items.reduce((n, r) => n + (Number(String(r.pages || '').replace(/[^0-9]/g, '')) || 0), 0);
    const totalScanned = items.reduce((n, r) => n + (Number(r.scanned_pages) || 0), 0);
    const rows = items.map((r, i) => `<tr>
        <td style="width:38px">${i + 1}</td>
        <td style="width:170px">${esc(r.archive_number || r.archive_code)}</td>
        <td>${esc(r.title)}</td>
        <td style="width:56px">${esc(r.year || '')}</td>
        <td style="width:56px">${esc(String(r.pages || ''))}</td>
        <td style="width:64px">${Number(r.scanned_pages) || 0}</td>
        <td style="width:66px">${esc(r.archive_state || '过程')}</td>
      </tr>`).join('');
    const html = printShell(`资料交接单 ${batch.batch_no}`, `
      <div class="print-head"><h1>档 案 资 料 交 接 单</h1>
        <div class="meta">
          全宗名称：${esc(unit)}　批次号：${esc(batch.batch_no)}　接收日期：${esc(batch.received_at)}<br>
          项目：${esc(batch.project_no ? `${batch.project_no} ${batch.project_name}` : '（未挂项目）')}　
          阶段：${esc(batch.stage || '—')}　批次名称：${esc(batch.title || '')}
        </div></div>
      <table class="print-table">
        <thead><tr><th>序号</th><th>档号</th><th>题名</th><th>年度</th><th>页数</th><th>扫描页</th><th>状态</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="7" style="text-align:center">本批暂无档案</td></tr>'}</tbody>
        <tfoot><tr>
          <td colspan="4" style="text-align:right;font-weight:600">合计</td>
          <td>${totalPages}</td><td>${totalScanned}</td><td>${items.length} 件</td>
        </tr></tfoot>
      </table>
      <div class="meta" style="font-size:12px;margin-top:8px">
        移交部门：${esc(batch.source_unit || '—')}　交件人：${esc(batch.handover_by || '—')}　
        电话：${esc(batch.handover_phone || '—')}　接收人：${esc(batch.receive_by || '—')}
        ${batch.note ? `<br>备注：${esc(batch.note)}` : ''}
      </div>
      <div class="sign-row">
        <div>交件人（签字）：<span style="display:inline-block;min-width:150px;border-bottom:1px solid #333">&nbsp;</span></div>
        <div>接收人（签字）：<span style="display:inline-block;min-width:150px;border-bottom:1px solid #333">&nbsp;</span></div>
        <div>日期：<span style="display:inline-block;min-width:120px;border-bottom:1px solid #333">&nbsp;</span></div>
      </div>
      <div style="font-size:10.5px;color:#555;margin-top:14px">
        本单一式两份，移交方与接收方各执一份。打印时间：${esc(new Date().toLocaleString('zh-CN'))}　
        经办：${esc(u.display_name || u.username || '')}
      </div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  /**
   * 生成打印用二维码（盒脊/标签）。
   *
   * margin 取系统设置（默认 6）—— QR 规范最低要求 4。早期这里写死 margin:1，
   * 二维码四周几乎没有留白，印在盒脊上又紧挨着虚线框和文字，手机相机经常定位不到，
   * 表现就是「扫不出来」。宁可贵一点点白边，也不要扫不出。
   *
   * maxPx 是「标签能给出的像素宽度预算」：按它取**最大的整数模块边长**，
   * 这样 SVG 的原生尺寸就等于打印尺寸，浏览器不用缩放（一缩放模块边缘就被插值糊掉）；
   * 同时把预算用足 —— 舍去几个像素不用，换来的就是每个模块小一档。
   *
   * 盒脊这里给 212px：`.spine` 宽 216px、左右各留 2px 内边距。
   * 53 格（网址里带盒号）时 floor(212/53)=4 → 212px，每个模块 4px ≈ 1.06mm；
   * 49 格（没带编号，例如中文盒号）时同样是 4px；
   * 57 格（旧的按盒号长网址）时 floor(212/57)=3 → 171px ≈ 0.79mm，旧标签不受影响。
   */
  const SPINE_QR_BUDGET_PX = 212;
  function safeQr(text, maxPx) {
    const o = qrOpts();
    // ★ 纠错等级必须显式传 H。
    //   qrSvg 的默认值是 M（15% 容错），而 qrPng 的默认值是 H（30%）。
    //   不传的话，盒脊标签（最容易磨花、被手摸、贴歪的那种）反而用最低的容错 ——
    //   档案码一路是 H，盒码却是 M，这是个不该有的不一致。
    try { return qrcode.qrSvg(text, { px: maxPx || SPINE_QR_BUDGET_PX, margin: o.margin, ecLevel: o.ecLevel }); }
    catch (_) { return '<span class="muted">(内容过长)</span>'; }
  }

  // ============================================================
  // 批量导入
  // ============================================================
  route('GET', '/api/import/template', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    // v4.14.0：默认给**精简版**（9 列）。
    // 老版本只发一套 27 列的表，用户打开第一眼就是"要填 27 列吗"——
    // 而实际必填只有 3 列。全字段版仍然保留，给"从别的系统整库迁移、
    // 对方字段本来就齐"的场景用，参数 ?kind=full。
    const kind = /^(full|all|1|true)$/i.test(String(url.searchParams.get('kind') || '')) ? 'full' : 'simple';
    const csv = importer.buildTemplateCsv(kind);
    const notes = importer.buildTemplateNotes(kind).join('\r\n') + '\r\n';
    const buf = Buffer.from(csv + notes, 'utf8');
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': contentDisposition(
        kind === 'full' ? '档案批量导入模板-全字段.csv' : '档案批量导入模板-精简版.csv'),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  route('GET', '/api/import/batches', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const list = q.all('SELECT * FROM import_batches ORDER BY id DESC LIMIT 50');
    for (const r of list) {
      try { r.errors = JSON.parse(r.errors || '[]'); } catch (_) { r.errors = []; }
    }
    ok(res, { list });
  });

  route('POST', '/api/import/archives', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const form = await parseMultipart(req, {
      maxFileSize: 64 * 1024 * 1024, maxTotalSize: 64 * 1024 * 1024, maxFiles: 1,
    });
    const file = form.files[0];
    if (!file) return fail(res, 400, '没有收到文件，请选择 CSV 文件后重试');
    if (!/\.csv$/i.test(file.filename)) {
      return fail(res, 400, '目前只支持 CSV 文件。如果手头是 Excel 表格，请在 Excel 里「另存为 → CSV UTF-8（逗号分隔）」后再上传。');
    }
    let text;
    try {
      text = file.data.toString('utf8');
      if (text.includes('\ufffd')) throw new Error('编码异常');
    } catch (_) {
      return fail(res, 400, '文件不是 UTF-8 编码，请在 Excel 中另存为「CSV UTF-8」后重试');
    }
    const mode = form.fields.mode === '更新' ? '更新' : '新增';
    // 试跑（v4.21.0）：**先看会发生什么，再决定要不要写**。
    //
    // 为什么这个功能对本系统特别重要：档号是**不复用**的（v4.8.0 档号治理定的），
    // 所以一次导错的文件不只是"多了几条垃圾数据"——它会**永久烧掉一批正式档号**，
    // 而档号一旦被占用就不能再发给别的档案。相比"导完再一条条删"，
    // "导之前先看清楚"是唯一划算的做法。
    //
    // 实现上用事务回滚：整批操作**照常执行一遍**（这样校验、重号改写、
    // 号段推进全都是真实行为，不是另一套"模拟逻辑"），跑完立刻 ROLLBACK，
    // 于是数据、号段、批次记录一概不留。用同一套代码而不是写一份"模拟版"，
    // 是为了避免"试跑说没问题、真跑却失败"这种最坏的结果。
    const dryRun = form.fields.dryRun === '1';
    let result;
    try {
      // 试跑**不用**"外层包事务再回滚"：导入器内部就用 q.tx()（BEGIN IMMEDIATE），
      // 它不能嵌套 —— 第一版这么写直接报 "cannot start a transaction within a transaction"，
      // 是回归断言把它逮住的。现在改成把 dryRun 传给导入器，
      // 由它显式跳过写入、并把取号换成 previewNumber（只看不占）。
      result = importer.runImport({
        q,
        numbering,
        RETENTION_MAP,
        RETENTIONS, SECRET_LEVELS, CARRIERS, STATUSES,
        // 开放状态取值域来自 api.js（与 /api/types 下发、界面下拉框同一份），
        // 不在这里另写一份 —— 两份枚举迟早会漂移，然后导入写进一个界面不认的值
        OPEN_STATES,
      }, text, { mode, operator: u, dryRun });
    } catch (e) {
      return fail(res, e.statusCode || 400, e.message);
    }
    result.dryRun = dryRun;
    if (dryRun) {
      // 试跑也留痕：审计日志里要能看出"有人拿这份文件试过跑"，
      // 否则事后无法解释"为什么这条没导进去"。
      log(u, '批量导入试跑', file.filename,
        `试跑（未写入）：预计成功 ${result.succeeded} / 失败 ${result.failed}，档号未被占用`, clientIp(req));
      return ok(res, result);
    }
    q.run(`INSERT INTO import_batches(filename,mode,total,succeeded,failed,errors,operator_id,operator,created_at)
           VALUES(?,?,?,?,?,?,?,?,?)`,
      file.filename, mode, result.total, result.succeeded, result.failed,
      JSON.stringify(result.errors.slice(0, 50)), u.id, u.display_name || u.username, nowIso());
    log(u, '批量导入档案', file.filename, `成功 ${result.succeeded} / 失败 ${result.failed}`, clientIp(req));
    ok(res, result);
  });

  // ============================================================
  // 盘点
  // ============================================================
  route('GET', '/api/stock-checks', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    ok(res, { list: q.all('SELECT * FROM stock_checks ORDER BY id DESC LIMIT 50') });
  });

  route('POST', '/api/stock-checks', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    const scope = mustStr(b.scope, 60) || '全库';
    let where = " WHERE a.status NOT IN ('已销毁')";
    const args = [];
    if (b.location_id) { where += ' AND a.box_id IN (SELECT id FROM archive_boxes WHERE location_id=?)'; args.push(Number(b.location_id)); }
    if (b.type_code) { where += ' AND a.type_code=?'; args.push(b.type_code); }
    // 盘点范围同样受密级限制：盘点明细会逐条列出档号
    const sec = secretScope(u);
    if (sec.sql) { where += sec.sql; args.push(...sec.params); }
    const targets = q.all(`SELECT a.id, a.archive_code, a.location FROM archives a ${where} LIMIT 5000`, ...args);
    if (!targets.length) return fail(res, 400, '没有符合条件的档案可供盘点');
    const d = new Date();
    const checkNo = nextCheckNo(d);
    let id = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO stock_checks(check_no,title,scope,status,checked,missing,mislocated,
                        operator_id,operator,started_at) VALUES(?,?,?,'进行中',0,0,0,?,?,?)`,
        checkNo, mustStr(b.title, 100) || `盘点任务 ${checkNo}`, scope, u.id, u.display_name || u.username, nowIso());
      id = r.lastInsertRowid;
      for (const t of targets) {
        q.run(`INSERT INTO stock_check_items(check_id,archive_id,archive_code,expect_location,result,barcode)
               VALUES(?,?,?,?,'待盘点',?)`, id, t.id, t.archive_code, t.location || '', t.archive_code);
      }
    });
    log(u, '新建盘点任务', checkNo, `${targets.length} 件`, clientIp(req));
    ok(res, { id, check_no: checkNo, total: targets.length });
  });

  route('GET', '/api/stock-checks/:id', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const c = q.get('SELECT * FROM stock_checks WHERE id=?', Number(params.id));
    if (!c) return fail(res, 404, '盘点任务不存在');
    const sp = url.searchParams;
    const onlyProblem = sp.get('problem') === '1';
    // 明细也要按密级过滤：新建盘点时已按密级裁剪了范围，
    // 但**别人建的**历史盘点单里仍可能含自己看不到的档案，所以读取时再兜一道。
    // 用 INNER JOIN：看不到的档案干脆不出现（而不是只把编号打码，避免编号本身泄露）。
    const sec = secretScope(u);
    const items = q.all(
      `SELECT i.* FROM stock_check_items i
       JOIN archives a ON a.id = i.archive_id
       WHERE i.check_id = ? ${onlyProblem ? "AND i.result<>'在架'" : ''}${sec.sql}
       ORDER BY i.result, i.archive_code LIMIT 3000`, c.id, ...sec.params,
    );
    c.items = items;
    ok(res, c);
  });

  /** 扫码/录入盘点结果。支持扫「单件档案二维码」或「档案盒二维码」（后者一次核对整盒） */
  route('POST', '/api/stock-checks/:id/scan', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const c = q.get('SELECT * FROM stock_checks WHERE id=?', id);
    if (!c) return fail(res, 404, '盘点任务不存在');
    if (c.status !== '进行中') return fail(res, 400, '该盘点任务已完成');
    const b = await readJson(req);
    const rawCodes = Array.isArray(b.codes) ? b.codes.map((x) => mustStr(x, 200).trim()).filter(Boolean) : [];
    if (!rawCodes.length) return fail(res, 400, '请提供要核对的档案号、档号或档案盒号');
    const actualLocation = mustStr(b.location, 100);

    /**
     * 兼容处理扫码内容：
     * 正常情况二维码就是纯编号本身，但为了兼容用其他软件（或本系统早期版本）
     * 打印的、带有 "档号:xxx|档案号:yyy" 这类前缀的标签，这里把编号提取出来。
     */
    /**
     * 解析扫码枪输入 → 候选编号。
     * 实现见 lib/scan-parse（与「扫码工作台」共用同一套），
     * 这里只把本模块的查询能力注进去，不再各写一份解析。
     */
    function extractCodes(text) {
      return scanCandidatesFor(text).candidates;
    }

    /** 在本次盘点范围内查找匹配条目 */
    function findItem(cands) {
      for (const v of cands) {
        const byCode = q.get('SELECT * FROM stock_check_items WHERE check_id=? AND (archive_code=? OR barcode=?)', id, v, v);
        if (byCode) return byCode;
      }
      for (const v of cands) {
        const byNumber = q.get(`SELECT i.* FROM stock_check_items i JOIN archives a ON a.id=i.archive_id
                                WHERE i.check_id=? AND a.archive_number=?`, id, v);
        if (byNumber) return byNumber;
      }
      return null;
    }

    /** 库中是否存在该编号（用于区分"不在本次范围"与"库中无此档案"） */
    function existsInLibrary(cands) {
      for (const v of cands) {
        const r = q.get('SELECT id FROM archives WHERE archive_code=? OR archive_number=?', v, v);
        if (r) return r;
      }
      return null;
    }

    let hit = 0, notFound = 0, mislocated = 0, already = 0, boxExpanded = 0;
    const details = [];

    q.tx(() => {
      for (const raw of rawCodes) {
        const cands = extractCodes(raw);

        // 先按单件档案匹配
        let item = findItem(cands);
        let expandedFromBox = null;

        // 匹配不到时，尝试按「档案盒号」处理：一次核对盒内全部档案
        if (!item) {
          let box = null;
          for (const v of cands) {
            box = q.get('SELECT id, box_code FROM archive_boxes WHERE box_code=? OR barcode=?', v, v);
            if (box) break;
          }
          if (box) {
            const inBox = q.all(`SELECT i.* FROM stock_check_items i JOIN archives a ON a.id=i.archive_id
                                 WHERE i.check_id=? AND a.box_id=?`, id, box.id);
            if (inBox.length) {
              expandedFromBox = box;
              for (const bi of inBox) {
                const expect = bi.expect_location || '';
                if (bi.result === '在架') { already++; continue; }
                const result = actualLocation && expect && actualLocation !== expect ? '位置不符' : '在架';
                if (result === '在架') hit++; else mislocated++;
                q.run('UPDATE stock_check_items SET result=?, actual_location=?, checked_at=? WHERE id=?',
                  result, actualLocation || expect, nowIso(), bi.id);
                boxExpanded++;
              }
              details.push({ code: raw, result: `按盒核对 ${box.box_code}，共 ${inBox.length} 件` });
              continue;
            }
            // 盒存在但盒内档案不在本次盘点范围
            notFound++;
            details.push({ code: raw, result: '该盒内档案不在本次盘点范围' });
            continue;
          }
          // 既不是档案也不是档案盒
          notFound++;
          details.push({ code: raw, result: existsInLibrary(cands) ? '不在本次盘点范围' : '库中无此档案或档案盒' });
          continue;
        }

        if (item.result === '在架') { already++; details.push({ code: raw, result: '重复扫描' }); continue; }
        const expect = item.expect_location || '';
        const result = actualLocation && expect && actualLocation !== expect ? '位置不符' : '在架';
        if (result === '在架') hit++; else mislocated++;
        q.run('UPDATE stock_check_items SET result=?, actual_location=?, checked_at=? WHERE id=?',
          result, actualLocation || expect, nowIso(), item.id);
        if (actualLocation && result === '位置不符') {
          q.run('UPDATE archives SET location=?, updated_at=? WHERE id=?', actualLocation, nowIso(), item.archive_id);
        }
        details.push({ code: raw, result });
      }

      const stat = q.get(`SELECT
          SUM(CASE WHEN result='在架' THEN 1 ELSE 0 END) AS ok,
          SUM(CASE WHEN result='缺失' THEN 1 ELSE 0 END) AS missing,
          SUM(CASE WHEN result='位置不符' THEN 1 ELSE 0 END) AS mis FROM stock_check_items WHERE check_id=?`, id);
      q.run('UPDATE stock_checks SET checked=?, missing=?, mislocated=? WHERE id=?',
        Number(stat.ok) || 0, Number(stat.missing) || 0, Number(stat.mis) || 0, id);
    });
    ok(res, { hit, notFound, mislocated, already, boxExpanded, details: details.slice(0, 100) });
  });

  route('POST', '/api/stock-checks/:id/finish', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const c = q.get('SELECT * FROM stock_checks WHERE id=?', id);
    if (!c) return fail(res, 404, '盘点任务不存在');
    const b = await readJson(req);
    // 未扫描的条目按“缺失”处理（可勾选保留为待盘点）
    let markedMissing = 0;
    if (b.mark_unchecked_as_missing !== false) {
      markedMissing = q.run(`UPDATE stock_check_items SET result='缺失', checked_at=?
                             WHERE check_id=? AND result='待盘点'`, nowIso(), id).changes;
    }
    const stat = q.get(`SELECT
        SUM(CASE WHEN result='在架' THEN 1 ELSE 0 END) AS ok,
        SUM(CASE WHEN result='缺失' THEN 1 ELSE 0 END) AS missing,
        SUM(CASE WHEN result='位置不符' THEN 1 ELSE 0 END) AS mis,
        COUNT(*) AS total FROM stock_check_items WHERE check_id=?`, id);
    q.run(`UPDATE stock_checks SET status='已完成', finished_at=?, checked=?, missing=?, mislocated=?, note=? WHERE id=?`,
      nowIso(), Number(stat.ok) || 0, Number(stat.missing) || 0, Number(stat.mis) || 0,
      mustStr(b.note, 300), id);
    log(u, '完成盘点', c.check_no, `在架 ${Number(stat.ok) || 0} / 缺失 ${Number(stat.missing) || 0} / 位置不符 ${Number(stat.mis) || 0}`, clientIp(req));
    ok(res, { total: Number(stat.total) || 0, onShelf: Number(stat.ok) || 0, missing: Number(stat.missing) || 0, mislocated: Number(stat.mis) || 0, markedMissing });
  });

  route('GET', '/api/stock-checks/:id/print', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const c = q.get('SELECT * FROM stock_checks WHERE id=?', Number(params.id));
    if (!c) return fail(res, 404, '盘点任务不存在');
    const items = q.all('SELECT * FROM stock_check_items WHERE check_id=? ORDER BY result, archive_code LIMIT 3000', c.id);
    const rows = items.map((it, i) => `<tr><td>${i + 1}</td><td>${esc(it.archive_code)}</td>
      <td>${esc(it.expect_location || '')}</td><td>${esc(it.actual_location || '')}</td>
      <td>${esc(it.result)}</td><td>${esc(it.checked_at ? fmtDay(it.checked_at) : '')}</td></tr>`).join('');
    const html = printShell('盘点结果表', `
      <div class="print-head"><h1>档 案 盘 点 结 果 表</h1><div class="meta">
        盘点单号：${esc(c.check_no)}　范围：${esc(c.scope)}　状态：${esc(c.status)}<br>
        在架 ${c.checked} 件　缺失 ${c.missing} 件　位置不符 ${c.mislocated} 件　
        盘点人：${esc(c.operator)}　开始：${esc(fmtDay(c.started_at))}　完成：${esc(c.finished_at ? fmtDay(c.finished_at) : '')}</div></div>
      <table class="print-table"><thead><tr><th style="width:44px">序号</th><th style="width:150px">档案号</th>
        <th>应有位置</th><th>实际位置</th><th style="width:80px">结果</th><th style="width:90px">盘点时间</th>
      </tr></thead><tbody>${rows}</tbody></table>
      <div class="sign-row"><div>盘点人：____________</div><div>复核人：____________</div>
      <div>负责人：____________</div><div>日期：______年____月____日</div></div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  // ============================================================
  // 档案移交
  // ============================================================
  function nextTransferNo() {
    const y = String(new Date().getFullYear());
    const key = `transferseq:${y}`;
    const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0) + 1;
    q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(cur));
    return `YJ${y}-${String(cur).padStart(3, '0')}`;
  }

  /** 移交状态允许的下一步 */
  const TRANSFER_FLOW = {
    '待提交': ['已提交'],
    '已提交': ['已接收', '已退回'],
    '已接收': [],
    '已退回': ['已提交'],
  };

  route('GET', '/api/transfers', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const sp = url.searchParams;
    const where = [];
    const args = [];
    if (sp.get('status')) { where.push('t.status=?'); args.push(sp.get('status')); }
    if (sp.get('direction')) { where.push('t.direction=?'); args.push(sp.get('direction')); }
    const kw = (sp.get('kw') || '').trim();
    if (kw) {
      where.push('(t.transfer_no LIKE ? OR t.title LIKE ? OR t.target_unit LIKE ?)');
      args.push('%' + kw + '%', '%' + kw + '%', '%' + kw + '%');
    }
    const w = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const list = q.all(`SELECT t.*,
        (SELECT COUNT(*) FROM transfer_items i WHERE i.transfer_id=t.id) AS item_count
      FROM transfers t ${w} ORDER BY t.id DESC LIMIT 300`, ...args);
    const counts = {
      draft: Number(q.scalar("SELECT COUNT(*) FROM transfers WHERE status='待提交'") || 0),
      submitted: Number(q.scalar("SELECT COUNT(*) FROM transfers WHERE status='已提交'") || 0),
      accepted: Number(q.scalar("SELECT COUNT(*) FROM transfers WHERE status='已接收'") || 0),
      rejected: Number(q.scalar("SELECT COUNT(*) FROM transfers WHERE status='已退回'") || 0),
    };
    ok(res, { list, counts });
  });

  route('GET', '/api/transfers/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const t = q.get('SELECT * FROM transfers WHERE id=?', Number(params.id));
    if (!t) return fail(res, 404, '移交批次不存在');
    // 移交明细同样按密级兜一道（历史批次可能是别人建的）
    {
      const sec = secretScope(u);
      t.items = q.all(
        `SELECT i.* FROM transfer_items i JOIN archives a ON a.id = i.archive_id
         WHERE i.transfer_id = ?${sec.sql}
         ORDER BY i.archive_number, i.archive_code`, t.id, ...sec.params,
      );
      t.total_items = Number(q.scalar('SELECT COUNT(*) FROM transfer_items WHERE transfer_id=?', t.id) || 0);
    }
    ok(res, t);
  });

  /** 包内文件名清理：去掉路径分隔符与非法字符，避免目录穿越或解包失败 */
  function packageSafeName(s) {
    return String(s || '')
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
      .replace(/^\.+/, '_')
      .slice(0, 80) || 'unnamed';
  }

  /**
   * **移交进馆标准数据包**（本系统移交流程缺的那件最终交付物）。
   *
   * 移交流程（建批次 → 提交 → 接收）此前已经贯通，但接收方始终拿不到"那个包" ——
   * 只能登进本系统看。移交进馆要的是**可独立校验、脱离本系统也能读懂**的数据包。
   *
   * 包内结构：
   *   manifest.json        总账：批次信息 + 逐件清单 + 每个原文的 SHA-256 + 审计链结论
   *   目录清单.csv         人可读的移交目录（可直接打印）
   *   元数据/<档号>.xml     DA/T 46 元数据（与系统内单件导出走同一实现）
   *   原文/<档号>/…        电子原文（保持原文件名）
   *   交接文据.html        含双方签署栏，可打印
   *   说明.txt             包的用途、结构、以及接收方怎么校验
   *
   * 口径与列表一致：密级不够的档案**不进包**，并在 manifest 里**如实记录未纳入的件数** ——
   * 接收方若以为拿全了，问题会拖到对方清点时才暴露，那时更难查。
   */
  route('GET', '/api/transfers/:id/package', async (req, res, params) => {
    const u = requireCan(req, res, 'transfer:manage');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM transfers WHERE id=?', id);
    if (!t) return fail(res, 404, '移交批次不存在');
    if (t.status === '待提交') {
      return fail(res, 400, '该批次尚未提交。未提交的批次内容还会变，导出没有意义 —— 先提交再导出。');
    }
    const sec = secretScope(u);
    const items = q.all(
      `SELECT i.* FROM transfer_items i JOIN archives a ON a.id = i.archive_id
       WHERE i.transfer_id = ?${sec.sql}
       ORDER BY i.archive_number, i.archive_code`, id, ...sec.params);
    const totalItems = Number(q.scalar('SELECT COUNT(*) FROM transfer_items WHERE transfer_id=?', id) || 0);
    const hidden = Math.max(0, totalItems - items.length);
    if (!items.length) return fail(res, 400, '该批次里没有你能导出的档案（可能都超出你的密级上限）');

    const zip = new ZipWriter();
    const now = nowIso();
    const unitName = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    const manifestItems = [];
    let fileCount = 0;
    let fileBytes = 0;
    let missingFiles = 0;

    for (const it of items) {
      const a = q.get('SELECT * FROM archives WHERE id=?', it.archive_id);
      if (!a) continue;
      const code = it.archive_code || a.archive_code || String(it.archive_id);
      const base = packageSafeName(code);

      // 元数据：与「档案详情 → 导出元数据 XML」同一实现，保证两边一模一样
      const ctx = buildMetadataCtx(it.archive_id);
      const values = metadataValues(it.archive_id);
      const payload = Object.keys(values).length ? values : metadata.captureAll(ctx);
      const xml = metadata.toXml(ctx, payload, { exportedAt: now, by: u.username });
      zip.add(`元数据/${base}.xml`, Buffer.from(xml, 'utf8'));

      // 电子原文 + 逐件摘要（接收方可据此独立校验，不必相信本系统）
      const files = q.all('SELECT * FROM files WHERE archive_id=? ORDER BY id', it.archive_id);
      const fileEntries = [];
      for (const f of files) {
        const entry = {
          name: f.original_name || f.rel_path,
          size: Number(f.size) || 0,
          sha256: f.sha256 || '',
          missing: false,
        };
        try {
          const buf = fs.readFileSync(absPath(filesRoot, f.rel_path));
          entry.size = buf.length;
          if (!entry.sha256) entry.sha256 = sha256(buf);
          zip.add(`原文/${base}/${packageSafeName(f.original_name || f.rel_path)}`, buf);
          fileCount += 1;
          fileBytes += buf.length;
        } catch (_) {
          entry.missing = true;   // 实体缺失要如实写进总账，不能悄悄跳过
          missingFiles += 1;
        }
        fileEntries.push(entry);
      }

      manifestItems.push({
        archive_code: code,
        archive_number: it.archive_number || a.archive_number || '',
        title: it.title || a.title || '',
        type_code: it.type_code || a.type_code || '',
        year: it.year || a.year || '',
        retention: it.retention || a.retention || '',
        secret_level: a.secret_level || '',
        pages: it.pages || a.pages || '',
        item_no: a.item_no || '',
        carrier: a.carrier || '',
        metadata_file: `元数据/${base}.xml`,
        files: fileEntries,
      });
      if (a) { /* 保持结构清晰：下面是 CSV 与文据所需字段 */ }
    }

    // 目录清单（人可读、可直接打印）
    const csv = toCsv(
      ['序号', '档号', '档案号', '题名', '门类', '年度', '保管期限', '密级', '页数', '件号', '载体', '原文数'],
      manifestItems.map((x, i) => [i + 1, x.archive_code, x.archive_number, x.title, x.type_code, x.year,
        x.retention, x.secret_level, x.pages, x.item_no, x.carrier, x.files.length]),
    );
    zip.add('目录清单.csv', Buffer.from('\ufeff' + csv, 'utf8'));   // 带 BOM，Excel 打开不乱码

    const chain = verifyLogChain();
    const manifest = {
      package_version: 1,
      package_kind: '档案移交进馆标准数据包',
      generated_at: now,
      generated_by: u.username,
      generator: '档案管理系统 v' + ((config && config.version) || ''),
      unit: unitName,
      transfer: {
        transfer_no: t.transfer_no, title: t.title, direction: t.direction,
        target_unit: t.target_unit, source_unit: t.source_unit,
        contact: t.contact, phone: t.phone, basis: t.basis, carrier: t.carrier,
        status: t.status, applied_at: t.applied_at,
        submitted_at: t.submitted_at || '', accepted_at: t.accepted_at || '', acceptor: t.acceptor || '',
      },
      counts: {
        items_in_package: manifestItems.length,
        items_in_transfer: totalItems,
        items_excluded_by_clearance: hidden,
        originals: fileCount,
        original_bytes: fileBytes,
        originals_missing: missingFiles,
      },
      audit: { chain_ok: chain.ok, log_count: chain.count, note: '审计日志链校验结论（接收方可用备份包内的 logs.csv 复算）' },
      items: manifestItems,
    };
    zip.add('manifest.json', Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));

    // 交接文据（可打印，含双方签署栏）
    const sigHtml = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>交接文据 ${esc(t.transfer_no)}</title>
<style>body{font:14px/1.7 "Microsoft YaHei",sans-serif;margin:32px;color:#000}
h1{font-size:20px;text-align:center;margin:0 0 6px}.sub{text-align:center;color:#555;margin-bottom:18px}
table{border-collapse:collapse;width:100%;margin:10px 0}td,th{border:1px solid #333;padding:6px 8px;font-size:13px}
.k{width:110px;background:#f5f5f5}.sign td{height:64px}@media print{body{margin:12mm}}</style></head><body>
<h1>档案交接文据</h1><div class="sub">${esc(unitName)}　→　${esc(t.target_unit || '（接收单位）')}</div>
<table>
<tr><td class="k">移交批次号</td><td>${esc(t.transfer_no)}</td><td class="k">批次名称</td><td>${esc(t.title || '')}</td></tr>
<tr><td class="k">移交方向</td><td>${esc(t.direction)}</td><td class="k">载体</td><td>${esc(t.carrier || '')}</td></tr>
<tr><td class="k">移交件数</td><td>${manifestItems.length} 件${hidden ? `（另有 ${hidden} 件因密级未纳入本包）` : ''}</td>
    <td class="k">电子原文</td><td>${fileCount} 个${missingFiles ? `（${missingFiles} 个实体缺失，见 manifest）` : ''}</td></tr>
<tr><td class="k">移交依据</td><td colspan="3">${esc(t.basis || '')}</td></tr>
<tr><td class="k">联系人 / 电话</td><td colspan="3">${esc(t.contact || '')}　${esc(t.phone || '')}</td></tr>
<tr><td class="k">审计链校验</td><td colspan="3">${chain.ok ? '通过（' + chain.count + ' 条日志，SHA-256 链式哈希）' : '未通过，断点见系统内「操作日志 → 链校验」'}</td></tr>
</table>
<table class="sign">
<tr><th>移交单位（盖章）</th><th>接收单位（盖章）</th></tr>
<tr><td>经办人：　　　　　　　　　<br><br>日期：　　年　　月　　日</td>
    <td>经办人：　　　　　　　　　<br><br>日期：　　年　　月　　日</td></tr>
</table>
<p style="color:#555;font-size:12px">本页由「档案管理系统」生成于 ${esc(now)}。随包还有 manifest.json（含每个原文的 SHA-256）、目录清单.csv、
元数据 XML 与电子原文，接收方可独立校验。</p>
</body></html>`;
    zip.add('交接文据.html', Buffer.from(sigHtml, 'utf8'));

    zip.add('说明.txt', Buffer.from([
      '档案移交进馆标准数据包',
      '',
      `移交批次：${t.transfer_no}　${t.title || ''}`,
      `生成时间：${now}　生成人：${u.username}`,
      `移交单位：${unitName}　接收单位：${t.target_unit || '（未填）'}`,
      '',
      '一、包内结构',
      '  manifest.json      总账：批次信息、逐件清单、每个电子原文的 SHA-256、审计链校验结论',
      '  目录清单.csv       人可读的移交目录（带 BOM，Excel 直接打开不乱码）',
      '  元数据/<档号>.xml  DA/T 46 元数据（每件一份）',
      '  原文/<档号>/…      电子原文，文件名保持原样',
      '  交接文据.html      含双方签署栏，可直接打印',
      '',
      '二、怎么校验（接收方）',
      '  1. 打开 manifest.json，逐条核对 items[].archive_code 与目录清单.csv；',
      '  2. 对 原文/ 下每个文件计算 SHA-256，与 items[].files[].sha256 比对；',
      '  3. 若有 files[].missing = true，表示移交方系统里该附件实体缺失（本包已如实记录）。',
      '',
      '三、需要知道的边界',
      `  · 本包共 ${manifestItems.length} 件；该移交批次在移交方系统中共 ${totalItems} 件` +
        (hidden ? `，其中 ${hidden} 件因超出导出账号的密级上限**未纳入本包**，需由有权限的账号另行导出合并。` : '，已全部纳入。'),
      `  · 电子原文 ${fileCount} 个${missingFiles ? `，其中 ${missingFiles} 个实体缺失` : ''}。`,
      '  · 审计链结论来自移交方系统：' + (chain.ok ? '完整' : '不完整（请要求移交方先处理）') + '。',
      '  · 本包不包含数据库本身，也不含移交方系统的审计日志明细；如需日志请另行索取备份包内的 audit/logs.csv。',
      '',
    ].join('\r\n'), 'utf8'));

    const buf = zip.toBuffer();
    log(u, '导出移交数据包', t.transfer_no,
      `${manifestItems.length} 件 / ${fileCount} 个原文 / ${(buf.length / 1048576).toFixed(2)} MB`
        + (hidden ? `（${hidden} 件因密级未纳入）` : ''),
      clientIp(req), { category: 'transfer', step: '移交数据包' });
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': contentDisposition(`移交数据包_${t.transfer_no}.zip`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  /** 新建移交批次 */
  route('POST', '/api/transfers', async (req, res) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);
    let ids = Array.isArray(b.archive_ids) ? b.archive_ids.map(Number).filter(Boolean) : [];
    // 移交会把档案交出馆藏，属高风险动作：无论按条件挑选还是显式传 ids，
    // 都必须限制在自己能看到的范围内，否则等于绕开密级把涉密档案移交出去。
    const sec = secretScope(u);
    if (!ids.length) {
      // 未指定则按条件挑选（门类/年度/保管期限）
      const conds = ["a.status NOT IN ('已销毁')"];
      const args = [];
      if (b.type_code) { conds.push('a.type_code=?'); args.push(b.type_code); }
      if (b.year) { conds.push('a.year=?'); args.push(b.year); }
      if (b.retention) { conds.push('a.retention=?'); args.push(b.retention); }
      if (sec.sql) { conds.push(sec.sql.replace(/^ AND /, '')); args.push(...sec.params); }
      ids = q.all(`SELECT a.id FROM archives a WHERE ${conds.join(' AND ')} LIMIT 5000`, ...args).map((r) => r.id);
    } else {
      const holes = ids.map(() => '?').join(',');
      const allow = new Set(
        q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${sec.sql}`, ...ids, ...sec.params)
          .map((r) => Number(r.id)),
      );
      const before = ids.length;
      ids = ids.filter((id) => allow.has(id));
      if (ids.length !== before) {
        log(u, '移交跳过无权档案', `${before - ids.length} 条`, '超出账号密级上限', clientIp(req),
          { result: '拒绝', category: 'security', step: '密级鉴别' });
      }
      if (!ids.length) return fail(res, 403, '所选档案均超出你的密级权限范围');
    }
    if (!ids.length) return fail(res, 400, '没有选中任何档案，请先勾选档案或设置筛选条件');

    const items = [];
    for (const id of ids) {
      const a = q.get('SELECT * FROM archives WHERE id=?', id);
      if (!a) continue;
      // 同一档案不允许同时存在于两个未完成的移交批次
      const dup = q.get(`SELECT t.transfer_no FROM transfer_items i JOIN transfers t ON t.id=i.transfer_id
                         WHERE i.archive_id=? AND t.status IN ('待提交','已提交')`, id);
      if (dup) return fail(res, 400, `档案 ${a.archive_code} 已在移交批次 ${dup.transfer_no} 中，请先从原批次移除`);
      items.push(a);
    }
    if (!items.length) return fail(res, 400, '所选档案均不可移交');

    const no = nextTransferNo();
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';
    let batchId = 0;
    q.tx(() => {
      const r = q.run(`INSERT INTO transfers(transfer_no,title,direction,target_unit,source_unit,contact,phone,
                        basis,carrier,archive_count,total_pages,status,applicant_id,applicant,applied_at,remark,created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,'待提交',?,?,?,?,?)`,
        no, mustStr(b.title, 120) || `档案移交批次 ${no}`,
        ['移交进馆', '接收进馆'].includes(b.direction) ? b.direction : '移交进馆',
        mustStr(b.target_unit, 100), mustStr(b.source_unit, 100) || unit,
        mustStr(b.contact, 40), mustStr(b.phone, 30), mustStr(b.basis, 300),
        mustStr(b.carrier, 30) || '纸质+电子', items.length,
        items.reduce((s, a) => s + (Number(a.pages) || 0), 0),
        u.id, u.display_name || u.username, nowIso(), mustStr(b.remark, 300), nowIso());
      batchId = r.lastInsertRowid;
      for (const a of items) {
        q.run(`INSERT INTO transfer_items(transfer_id,archive_id,archive_code,archive_number,title,
                 type_code,year,retention,pages,location) VALUES(?,?,?,?,?,?,?,?,?,?)`,
          batchId, a.id, a.archive_code, a.archive_number || '', a.title, a.type_code,
          a.year, a.retention, String(a.pages || ''), a.location || '');
      }
    });
    log(u, '新建移交批次', no, `${items.length} 件`, clientIp(req));
    ok(res, { id: batchId, transfer_no: no, count: items.length });
  });

  /** 从批次移除档案（仅待提交/已退回可改） */
  route('POST', '/api/transfers/:id/remove', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM transfers WHERE id=?', id);
    if (!t) return fail(res, 404, '移交批次不存在');
    if (!['待提交', '已退回'].includes(t.status)) {
      return fail(res, 400, `批次状态为「${t.status}」，不能再修改清单`);
    }
    const b = await readJson(req);
    const itemIds = Array.isArray(b.item_ids) ? b.item_ids.map(Number).filter(Boolean) : [];
    if (!itemIds.length) return fail(res, 400, '请选择要移除的档案');
    let n = 0;
    q.tx(() => {
      for (const iid of itemIds) {
        n += q.run('DELETE FROM transfer_items WHERE id=? AND transfer_id=?', iid, id).changes;
      }
      const stat = q.get('SELECT COUNT(*) AS c, COALESCE(SUM(CAST(pages AS INTEGER)),0) AS p FROM transfer_items WHERE transfer_id=?', id);
      q.run('UPDATE transfers SET archive_count=?, total_pages=? WHERE id=?', Number(stat.c) || 0, Number(stat.p) || 0, id);
    });
    ok(res, { removed: n });
  });

  /** 提交移交 */
  route('POST', '/api/transfers/:id/submit', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM transfers WHERE id=?', id);
    if (!t) return fail(res, 404, '移交批次不存在');
    if (!(TRANSFER_FLOW[t.status] || []).includes('已提交')) {
      return fail(res, 400, `批次状态为「${t.status}」，不能提交`);
    }
    const cnt = Number(q.scalar('SELECT COUNT(*) FROM transfer_items WHERE transfer_id=?', id) || 0);
    if (!cnt) return fail(res, 400, '清单为空，无法提交');

    // 移交闸门：《电子档案管理办法》第二十一条要求"移交前进行四性检测，合格后方可移交"。
    // 提交即锁定清单、之后不能再改，所以这里是**唯一**能把这个标准要求变成硬约束的位置。
    if (String(numbering.getSetting(q, 'detection.enforce_transfer', '1')) === '1') {
      const items = q.all('SELECT archive_id, archive_code, title FROM transfer_items WHERE transfer_id=?', id);
      const bad = items.filter((it) => !hasPassingArchiveDetection(it.archive_id))
        .map((it) => it.archive_code || it.title);
      if (bad.length) {
        return fail(res, 400,
          `移交前四性检测未通过：${bad.slice(0, 5).join('、')}`
          + `${bad.length > 5 ? ` 等 ${bad.length} 件` : ''} 尚无合格的归档环节检测记录。`
          + '请先在「四性检测」中对其执行检测，合格后再提交。'
          + '（如本单位制度另有规定，可由管理员关闭「移交前强制检测」）',
          'DETECTION_REQUIRED');
      }
    }

    const b = await readJson(req);
    q.run(`UPDATE transfers SET status='已提交', submitted_at=?,
             target_unit=CASE WHEN ?<>'' THEN ? ELSE target_unit END,
             contact=CASE WHEN ?<>'' THEN ? ELSE contact END,
             phone=CASE WHEN ?<>'' THEN ? ELSE phone END,
             basis=CASE WHEN ?<>'' THEN ? ELSE basis END
           WHERE id=?`,
      nowIso(),
      mustStr(b.target_unit, 100), mustStr(b.target_unit, 100),
      mustStr(b.contact, 40), mustStr(b.contact, 40),
      mustStr(b.phone, 30), mustStr(b.phone, 30),
      mustStr(b.basis, 300), mustStr(b.basis, 300), id);
    log(u, '提交档案移交', t.transfer_no, `${cnt} 件`, clientIp(req));
    ok(res, { status: '已提交' });
  });

  /** 接收 / 退回 */
  route('POST', '/api/transfers/:id/accept', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM transfers WHERE id=?', id);
    if (!t) return fail(res, 404, '移交批次不存在');
    if (t.status !== '已提交') return fail(res, 400, `只有「已提交」的批次可以办理接收或退回，当前为「${t.status}」`);
    const b = await readJson(req);
    const accept = b.accept !== false;
    const acceptor = mustStr(b.acceptor, 60);
    const reason = mustStr(b.reason, 300);
    if (accept && !acceptor) return fail(res, 400, '办理接收必须填写接收人');
    if (!accept && !reason) return fail(res, 400, '退回必须填写退回原因');

    q.tx(() => {
      if (accept) {
        q.run(`UPDATE transfers SET status='已接收', accepted_at=?, acceptor=?, accept_note=? WHERE id=?`,
          nowIso(), acceptor, mustStr(b.note, 300), id);
        for (const it of q.all('SELECT archive_id FROM transfer_items WHERE transfer_id=?', id)) {
          q.run('UPDATE archives SET status_note=?, updated_at=? WHERE id=?',
            `已于 ${today()} 移交（${t.transfer_no}）`, nowIso(), it.archive_id);
        }
      } else {
        q.run("UPDATE transfers SET status='已退回', reject_reason=? WHERE id=?", reason, id);
      }
    });
    log(u, accept ? '接收档案移交' : '退回档案移交', t.transfer_no, accept ? `接收人 ${acceptor}` : reason, clientIp(req));
    ok(res, { status: accept ? '已接收' : '已退回' });
  });

  route('DELETE', '/api/transfers/:id', async (req, res, params) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM transfers WHERE id=?', id);
    if (!t) return fail(res, 404, '移交批次不存在');
    if (t.status === '已接收') return fail(res, 400, '已接收的移交批次属于业务凭据，不能删除');
    q.tx(() => {
      q.run('DELETE FROM transfer_items WHERE transfer_id=?', id);
      q.run('DELETE FROM transfers WHERE id=?', id);
    });
    log(u, '删除移交批次', t.transfer_no, '', clientIp(req));
    ok(res, true);
  });

  /** 打印移交清册（含交接双方签章栏） */
  route('GET', '/api/transfers/:id/print', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const t = q.get('SELECT * FROM transfers WHERE id=?', Number(params.id));
    if (!t) return fail(res, 404, '移交批次不存在');
    // 打印清册会逐条列出档号与题名，必须按密级过滤
    const sec = secretScope(u);
    const items = q.all(
      `SELECT i.* FROM transfer_items i JOIN archives a ON a.id = i.archive_id
       WHERE i.transfer_id = ?${sec.sql}
       ORDER BY i.archive_number, i.archive_code`, t.id, ...sec.params,
    );
    const rows = items.map((it, i) => `<tr>
      <td>${i + 1}</td><td>${esc(it.archive_number || it.archive_code)}</td>
      <td>${esc(it.title)}</td><td>${esc(it.type_code)}</td><td>${esc(it.year)}</td>
      <td>${esc(it.retention)}</td><td>${esc(it.pages || '')}</td><td>${esc(it.location || '')}</td></tr>`).join('');
    const html = printShell(`档案移交清册 ${esc(t.transfer_no)}`, `
      <div class="print-head"><h1>档 案 移 交 清 册</h1><div class="meta">
        移交单号：${esc(t.transfer_no)}　批次名称：${esc(t.title)}<br>
        移交单位：${esc(t.source_unit)}　接收单位：${esc(t.target_unit)}<br>
        移交依据：${esc(t.basis || '—')}　载体形式：${esc(t.carrier)}<br>
        共 ${items.length} 件　合计 ${t.total_pages} 页　联系人：${esc(t.contact)} ${esc(t.phone)}<br>
        提交日期：${esc(t.submitted_at ? fmtDay(t.submitted_at) : fmtDay(t.applied_at))}${t.accepted_at ? '　接收日期：' + esc(fmtDay(t.accepted_at)) : ''}
      </div></div>
      <table class="print-table"><thead><tr>
        <th style="width:42px">序号</th><th style="width:150px">档号</th><th>题名</th>
        <th style="width:52px">门类</th><th style="width:52px">年度</th><th style="width:70px">保管期限</th>
        <th style="width:46px">页数</th><th style="width:88px">存放位置</th>
      </tr></thead><tbody>${rows}
      <tr><td colspan="6" style="text-align:right"><b>合计</b></td><td><b>${t.total_pages}</b></td><td></td></tr>
      </tbody></table>
      <div class="sign-row">
        <div>移交单位（盖章）：____________</div>
        <div>接收单位（盖章）：____________</div>
        <div>移交经办人：____________</div>
        <div>接收人：${esc(t.acceptor || '____________')}</div>
      </div>
      <div class="sign-row" style="margin-top:14px">
        <div>移交日期：______年____月____日</div>
        <div>接收日期：______年____月____日</div>
      </div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  // ============================================================
  // 数据体检与批量维护
  // ============================================================
  route('GET', '/api/quality/scan', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const limit = Math.min(200, Math.max(10, Number(url.searchParams.get('limit')) || 50));
    const only = url.searchParams.get('only') || '';   // 只看某一类问题

    // 密级过滤：体检会列出档号与题名，不加密级过滤就等于给涉密档案开了个后门
    const sc = secretScope(u);
    const scSql = sc.sql;
    const scArgs = sc.params;

    // 体检结果的**严重度分级**（v4.23.0）。
    //
    // 为什么必须分级：原来是一张不分先后的清单，档案员看完不知道该先干哪个 ——
    // 而这几类的紧迫程度差着量级：档号重复是"两件档案同号"的硬错误，
    // 缺存放位置只是不便于找件。混在一起看，人只会挑最省事的做。
    //
    // 定级口径是**合规风险**，不是工作量：
    //   must   必须处理 —— 不处理就是错档、违规或已失真（档号唯一性、涉密期限…）
    //   should 建议处理 —— 影响利用与统计，或有法定时限压力
    //   info   提示     —— 规范性/便利性，做不做不影响档案本身是否正确
    const SEVERITY = {
      // —— 必须处理 ——
      number_duplicate: 'must',   // 两件档案同一个规范档号：直接违反档号唯一性
      number_missing: 'must',     // 没有规范档号：等于没编目
      number_malformed: 'must',   // 档号含空段：结构错乱，打印/移交都会出问题
      duplicate: 'must',          // 同年度同题名多条：通常是重复入库
      secret_no_term: 'must',     // 涉密未登记保密期限：违反保密管理要求
      secret_due: 'must',         // 保密期限届满未鉴定：该解密不解密
      // —— 建议处理 ——
      no_responsible: 'should',   // 著录必备项
      no_date: 'should',          // 影响到期计算
      due_unappraised: 'should',  // 有法定鉴定时限
      open_pending: 'should',     // 有法定开放时限
      text_unavailable: 'should', // 检索不到正文
      ocr_pending: 'should',      // 同上，可做 OCR 补救
      // —— 提示 ——
      no_category_code: 'info',
      no_file: 'info',
      no_location: 'info',
      mixed_box: 'info',
      number_gap: 'info',         // 断号本身**不违规**（按规范就是不得回填），只是提示
      pinyin_missing: 'info',
    };
    const SEV_ORDER = { must: 0, should: 1, info: 2 };
    const SEV_LABEL = { must: '必须处理', should: '建议处理', info: '提示' };

    const problems = [];
    const push = (type, label, count, list, hint) => {
      if (only && only !== type) return;
      const severity = SEVERITY[type] || 'should';
      problems.push({ type, label, count, hint, severity, severityLabel: SEV_LABEL[severity], samples: list });
    };
    const countOf = (sql) => Number(q.scalar(sql, ...scArgs) || 0);

    // ① 疑似重复：同年度 + 同题名
    const dupRows = q.all(`SELECT a.year, a.title, COUNT(*) AS c, GROUP_CONCAT(a.archive_code, ' / ') AS codes,
                                  MIN(a.id) AS first_id
                           FROM archives a WHERE a.title<>''${scSql}
                           GROUP BY a.year, a.title HAVING c > 1
                           ORDER BY c DESC, a.year DESC LIMIT ?`, ...scArgs, limit);
    const dupCount = countOf(`SELECT COUNT(*) FROM (
        SELECT 1 FROM archives a WHERE a.title<>''${scSql} GROUP BY a.year, a.title HAVING COUNT(*)>1)`);
    push('duplicate', '疑似重复档案（同年度同题名）', dupCount,
      dupRows.map((r) => ({ id: r.first_id, code: r.codes, title: `${r.year} ${r.title}（${r.c} 条）` })),
      '同一批档案被重复著录，建议核对后删除多余记录');

    // ② 缺责任者
    const noResp = q.all(`SELECT a.id, a.archive_code, a.title, a.year FROM archives a
                          WHERE (a.responsible IS NULL OR a.responsible='')${scSql}
                          ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('no_responsible', '缺责任者',
      countOf(`SELECT COUNT(*) FROM archives a WHERE (a.responsible IS NULL OR a.responsible='')${scSql}`),
      noResp.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '责任者是著录必备项，缺失会影响移交与统计');

    // ③ 缺归档日期
    const noDate = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a
                          WHERE (a.archive_date IS NULL OR a.archive_date='')${scSql}
                          ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('no_date', '缺归档日期',
      countOf(`SELECT COUNT(*) FROM archives a WHERE (a.archive_date IS NULL OR a.archive_date='')${scSql}`),
      noDate.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '归档日期缺失会导致保管期限到期计算不准确');

    // ④ 缺分类号 / 分类异常
    const noCatCode = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a
                             WHERE (a.category_code IS NULL OR a.category_code='')${scSql}
                             ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('no_category_code', '缺分类号',
      countOf(`SELECT COUNT(*) FROM archives a WHERE (a.category_code IS NULL OR a.category_code='')${scSql}`),
      noCatCode.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '可在「系统管理 → 档号规则」中设置默认目录号后重新保存档案以自动补全');

    // ⑤ 无电子附件
    const noFile = q.all(`SELECT a.id, a.archive_code, a.title, a.year FROM archives a
                          WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.archive_id=a.id)${scSql}
                          ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('no_file', '无电子附件',
      countOf(`SELECT COUNT(*) FROM archives a WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.archive_id=a.id)${scSql}`),
      noFile.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '尚未上传扫描件或电子文件，建议补齐以便检索与在线利用');

    // ⑥ 保管期限到期但未鉴定
    const thisYear = new Date().getFullYear();
    const dueUnappraised = q.all(`SELECT a.id, a.archive_code, a.title, a.retention, a.retention_due_year
                                  FROM archives a
                                  WHERE a.retention_years > 0 AND a.retention_due_year > 0 AND a.retention_due_year <= ?
                                    AND NOT EXISTS (SELECT 1 FROM appraisals p WHERE p.archive_id=a.id)${scSql}
                                  ORDER BY a.retention_due_year LIMIT ?`, thisYear, ...scArgs, limit);
    const dueCount = Number(q.scalar(`SELECT COUNT(*) FROM archives a
                       WHERE a.retention_years > 0 AND a.retention_due_year > 0 AND a.retention_due_year <= ?
                         AND NOT EXISTS (SELECT 1 FROM appraisals p WHERE p.archive_id=a.id)${scSql}`,
      thisYear, ...scArgs) || 0);
    push('due_unappraised', '已到期但未鉴定', dueCount,
      dueUnappraised.map((r) => ({ id: r.id, code: r.archive_code, title: `${r.title}（${r.retention}，${r.retention_due_year} 年到期）` })),
      '请到「到期与鉴定」中组织鉴定并记录结论');

    // ⑦ 存放位置缺失（已装盒的除外）
    const noLoc = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a
                         WHERE (a.location IS NULL OR a.location='') AND a.box_id IS NULL${scSql}
                         ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('no_location', '缺存放位置',
      countOf(`SELECT COUNT(*) FROM archives a WHERE (a.location IS NULL OR a.location='') AND a.box_id IS NULL${scSql}`),
      noLoc.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '建议在「实体管理」中建盒装盒，系统会自动带出库位');

    // ⑧ 扫描件无法检索（有附件但正文未提取）
    const unscannable = q.all(`SELECT a.id, a.archive_code, a.title, t.reason
                               FROM file_text t
                               JOIN archives a ON a.id=t.archive_id
                               WHERE t.status<>'成功'${scSql} ORDER BY t.file_id DESC LIMIT ?`, ...scArgs, limit);
    push('text_unavailable', '附件正文无法提取（扫描件或旧版格式）',
      countOf(`SELECT COUNT(*) FROM file_text t JOIN archives a ON a.id=t.archive_id WHERE t.status<>'成功'${scSql}`),
      unscannable.map((r) => ({ id: r.id, code: r.archive_code, title: `${r.title} — ${String(r.reason || '').slice(0, 40)}` })),
      '扫描件需 OCR 才能检索正文；旧版 .doc/.xls 可用 Office 另存为 .docx/.xlsx 后重新上传');

    // ⑨ 档案盒混装（DA/T 22—2015 §6.4）
    // 装盒接口已默认拒绝新的混装，这条用于把**历史遗留**的混装盒找出来。
    const mixedHaving = `HAVING COUNT(DISTINCT a.year)>1 OR COUNT(DISTINCT a.type_code)>1
                             OR COUNT(DISTINCT a.retention)>1 OR COUNT(DISTINCT a.category_code)>1`;
    const mixedBoxes = q.all(`SELECT b.id, b.box_code, b.year, b.retention,
                                     COUNT(a.id) AS c,
                                     COUNT(DISTINCT a.year) AS y,
                                     COUNT(DISTINCT a.type_code) AS t,
                                     COUNT(DISTINCT a.retention) AS r,
                                     COUNT(DISTINCT a.category_code) AS o
                              FROM archive_boxes b JOIN archives a ON a.box_id=b.id
                              WHERE 1=1${scSql}
                              GROUP BY b.id ${mixedHaving}
                              ORDER BY c DESC LIMIT ?`, ...scArgs, limit);
    const mixedCount = countOf(`SELECT COUNT(*) FROM (
        SELECT b.id FROM archive_boxes b JOIN archives a ON a.box_id=b.id
        WHERE 1=1${scSql} GROUP BY b.id ${mixedHaving})`);
    push('mixed_box', '档案盒混装（不同年度/保管期限/机构(问题)同盒）', mixedCount,
      mixedBoxes.map((r) => ({
        id: r.id, code: r.box_code,
        title: `${r.box_code}：${r.c} 件，涉及年度 ${r.y} 种 / 门类 ${r.t} 种 / 保管期限 ${r.r} 种 / 机构(问题) ${r.o} 种`,
      })),
      'DA/T 22—2015 §6.4 要求不同年度、机构(问题)、保管期限不得装入同一盒；请将不一致的档案移出另建盒。系统已默认拒绝新的混装，此处用于清查历史遗留');

    // ⑩ 档号体检（v4.8.0）
    // 档号是档案的唯一法定标识。与"① 疑似重复"（看的是题名）不同，这一组只看**号本身**。
    const noNum = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a
                         WHERE (a.archive_number IS NULL OR a.archive_number='')${scSql}
                         ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('number_missing', '缺规范档号',
      countOf(`SELECT COUNT(*) FROM archives a WHERE (a.archive_number IS NULL OR a.archive_number='')${scSql}`),
      noNum.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '规范档号是归档章、盒脊、移交数据包与元数据 M05 的取值来源；'
      + '可在「系统管理 → 档号规则」确认模板后重新保存该档案以补号');

    const dupNum = q.all(`SELECT a.archive_number, COUNT(*) AS c, MIN(a.id) AS first_id,
                                 GROUP_CONCAT(a.archive_code, ' / ') AS codes
                          FROM archives a WHERE a.archive_number<>''${scSql}
                          GROUP BY a.archive_number HAVING c > 1
                          ORDER BY c DESC LIMIT ?`, ...scArgs, limit);
    push('number_duplicate', '规范档号重复',
      countOf(`SELECT COUNT(*) FROM (SELECT 1 FROM archives a WHERE a.archive_number<>''${scSql}
                                     GROUP BY a.archive_number HAVING COUNT(*)>1)`),
      dupNum.map((r) => ({ id: r.first_id, code: r.codes, title: `${r.archive_number}（${r.c} 条共用）` })),
      '档号不得重复使用。新库已由唯一索引拦住，这里用于清查历史数据；'
      + '请核对后为重复的档案重新编号（保留最早的那条）');

    const malNum = q.all(`SELECT a.id, a.archive_number, a.title FROM archives a
                          WHERE a.archive_number<>'' AND (
                                a.archive_number LIKE '%--%'
                             OR a.archive_number LIKE '-%'
                             OR a.archive_number LIKE '%-')${scSql}
                          ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    push('number_malformed', '规范档号含空段（结构错乱）',
      countOf(`SELECT COUNT(*) FROM archives a WHERE a.archive_number<>'' AND (
                 a.archive_number LIKE '%--%' OR a.archive_number LIKE '-%' OR a.archive_number LIKE '%-')${scSql}`),
      malNum.map((r) => ({ id: r.id, code: r.archive_number, title: r.title })),
      '形如 Z001-HT·2037--CG-0001 的档号说明模板里某一段当时取不到值。'
      + 'v4.8.0 起系统会直接拒绝这种号；存量数据请补全对应信息后重新编号');

    // 断号：门类·年度内「最大序号」大于「实际条数」。
    // **刻意按"提醒"而非"缺陷"呈现** —— 按规范档号不得回填，销毁/移交造成的断号是正常的，
    // 需要的是确认每一次断号都有据可查（销毁清册 / 移交文据），而不是把号补上。
    const gapRows = q.all(`SELECT a.type_code, a.year, COUNT(*) AS c,
                                  MAX(CAST(substr(a.archive_code,-4) AS INTEGER)) AS m
                           FROM archives a
                           WHERE a.archive_code GLOB '*[0-9][0-9][0-9][0-9]'${scSql}
                           GROUP BY a.type_code, a.year HAVING m > c
                           ORDER BY (m - c) DESC LIMIT ?`, ...scArgs, limit);
    const gapTotal = Number(q.scalar(`SELECT COALESCE(SUM(m - c), 0) FROM (
        SELECT COUNT(*) AS c, MAX(CAST(substr(a.archive_code,-4) AS INTEGER)) AS m
          FROM archives a WHERE a.archive_code GLOB '*[0-9][0-9][0-9][0-9]'${scSql}
         GROUP BY a.type_code, a.year HAVING m > c)`, ...scArgs) || 0);
    push('number_gap', '档号断号（缺号，按规范不得回填）', gapTotal,
      gapRows.map((r) => ({
        id: 0, code: `${r.type_code}·${r.year}`,
        title: `${r.type_code} ${r.year} 年：现有 ${r.c} 条，用到序号 ${r.m}，缺 ${r.m - r.c} 个号`,
      })),
      '断号常见于档案被销毁、移交进馆或误删。档号一经编定不得重复使用，因此**不要回填**；'
      + '请确认每次断号都能在销毁清册或移交文据里找到对应记录');

    // ⑪ 涉密档案未登记保密期限（v4.10.0）
    // **刻意按"提醒"而不是"缺陷"呈现**：存量档案的密级是当年定的，保密期限当年可能就没写在系统里，
    // 系统凭空补一个"10年"等于伪造档案管理事实。要的是把它**列出来**，由定密责任人补录真实期限。
    const noSecretTerm = q.all(`SELECT a.id, a.archive_code, a.title, a.secret_level
                                FROM archives a
                                WHERE a.secret_level <> '公开' AND COALESCE(a.secret_term,'')='' AND a.status NOT IN ('已销毁')${scSql}
                                ORDER BY a.secret_level DESC, a.id LIMIT ?`, ...scArgs, limit);
    push('secret_no_term', '涉密档案未登记保密期限', countOf(
      `SELECT COUNT(*) FROM archives a WHERE a.secret_level <> '公开' AND COALESCE(a.secret_term,'')='' AND a.status NOT IN ('已销毁')${scSql}`,
    ), noSecretTerm.map((r) => ({
      id: r.id, code: r.archive_code, title: `${r.title}（${r.secret_level}）`,
    })), '没有保密期限就无法判断何时应当解密——请由定密责任人在「鉴定工作台 → 密级鉴定」中补录'
      + '保密期限与定密依据（《保守国家秘密法》第十九条：保密期限届满即自行解密）');

    // ⑫ 保密期限届满未做密级鉴定
    const dToday = nowIso().slice(0, 10);
    const secretDueRows = q.all(`SELECT a.id, a.archive_code, a.title, a.secret_level, a.secret_to
                                 FROM archives a
                                 WHERE a.secret_level <> '公开' AND COALESCE(a.secret_to,'') <> '' AND a.secret_to <= ?
                                   AND a.status NOT IN ('已销毁')${scSql}
                                 ORDER BY a.secret_to LIMIT ?`, dToday, ...scArgs, limit);
    push('secret_due', '保密期限届满未鉴定', Number(q.scalar(
      `SELECT COUNT(*) FROM archives a WHERE a.secret_level <> '公开' AND COALESCE(a.secret_to,'') <> '' AND a.secret_to <= ? AND a.status NOT IN ('已销毁')${scSql}`,
      dToday, ...scArgs,
    ) || 0), secretDueRows.map((r) => ({
      id: r.id, code: r.archive_code, title: `${r.title}（${r.secret_level}，${r.secret_to} 届满）`,
    })), '保密期限届满应当组织密级鉴定：解密、降低密级或延长保密期限（延长须在届满前重新确定）');

    // ⑬ 满 25 年未做开放鉴定
    const openYear = new Date().getFullYear();
    const openPendingRows = q.all(`SELECT a.id, a.archive_code, a.title, a.year, a.secret_level
                                   FROM archives a
                                   WHERE a.status NOT IN ('已销毁') AND a.year <> ''
                                     AND CAST(a.year AS INTEGER) > 0
                                     AND CAST(a.year AS INTEGER) + ${OPEN_PUBLIC_YEARS} <= ?
                                     AND a.open_state = '未鉴定'${scSql}
                                   ORDER BY a.year LIMIT ?`, openYear, ...scArgs, limit);
    push('open_pending', `满 ${OPEN_PUBLIC_YEARS} 年未做开放鉴定`, Number(q.scalar(
      `SELECT COUNT(*) FROM archives a WHERE a.status NOT IN ('已销毁') AND a.year <> ''
         AND CAST(a.year AS INTEGER) > 0 AND CAST(a.year AS INTEGER) + ${OPEN_PUBLIC_YEARS} <= ?
         AND a.open_state = '未鉴定'${scSql}`, openYear, ...scArgs,
    ) || 0), openPendingRows.map((r) => ({
      id: r.id, code: r.archive_code,
      title: `${r.title}（${r.year} 年形成，${Number(r.year) + OPEN_PUBLIC_YEARS} 年满 ${OPEN_PUBLIC_YEARS} 年）`,
    })), `《档案法》第二十七条：馆藏档案一般自形成之日起满 ${OPEN_PUBLIC_YEARS} 年向社会开放。`
      + '请到「鉴定工作台 → 开放鉴定」逐件作出开放 / 部分开放 / 控制使用的结论');

    // ⑭ 缺拼音检索键（v4.11.0）
    // 这不是"内容缺陷"而是**索引缺陷**：缺了它，用拼音搜不到这份档案。
    // 正常的库这里应该恒为 0 —— 不为 0 说明回填或写入路径漏了一处，
    // 属于"静默失效"类问题（能查到但没人知道查不到），所以必须列出来。
    const pyMissing = q.all(`SELECT a.id, a.archive_code, a.title FROM archives a
                              WHERE (COALESCE(a.py_full,'')='' OR COALESCE(a.py_initials,'')='')
                                AND a.title <> ''${scSql}
                              ORDER BY a.id DESC LIMIT ?`, ...scArgs, limit);
    const pyMissingCount = Number(q.scalar(
      `SELECT COUNT(*) FROM archives a WHERE (COALESCE(a.py_full,'')='' OR COALESCE(a.py_initials,'')='')
         AND a.title <> ''${scSql}`, ...scArgs,
    ) || 0);
    push('pinyin_missing', '缺拼音检索键（拼音搜不到）', pyMissingCount,
      pyMissing.map((r) => ({ id: r.id, code: r.archive_code, title: r.title })),
      '拼音检索键在著录/导入时自动生成，正常应为 0。若不为 0，重新保存一次该档案即可重建'
      + '（管理员也可在「系统管理 → 数据维护」中批量重建）');

    // ⑮ 有附件但正文搜不到（v4.11.0）—— OCR 的主要目标
    const ocrExts = [...ocrLib.IMAGE_EXT, '.pdf'];
    const ocrExtSql = '(' + ocrExts.map(() => 'lower(f.original_name) LIKE ?').join(' OR ') + ')';
    const ocrExtArgs = ocrExts.map((e) => '%' + e);
    const ocrPendingRows = q.all(`SELECT a.id, a.archive_code, a.title, f.original_name
                                  FROM files f JOIN archives a ON a.id=f.archive_id
                                  LEFT JOIN file_text t ON t.file_id=f.id
                                  WHERE (t.file_id IS NULL OR t.status<>'成功')
                                    AND a.status<>'已销毁' AND ${ocrExtSql}${scSql}
                                  ORDER BY f.id LIMIT ?`, ...ocrExtArgs, ...scArgs, limit);
    const ocrPendingCount = Number(q.scalar(
      `SELECT COUNT(*) FROM files f JOIN archives a ON a.id=f.archive_id
        LEFT JOIN file_text t ON t.file_id=f.id
        WHERE (t.file_id IS NULL OR t.status<>'成功') AND a.status<>'已销毁' AND ${ocrExtSql}${scSql}`,
      ...ocrExtArgs, ...scArgs,
    ) || 0);
    // 这里**刻意不探测 OCR 引擎**：探测要起一次 PowerShell（Windows 自带 OCR），
    // 每次体检都跑一遍会让这个接口慢到几秒。体检应当是只读、快、无副作用的。
    // 引擎到底有没有、是哪一档，由 /api/ocr/status 单独回答（界面异步加载那张卡片）。
    push('ocr_pending', '有附件但正文搜不到（可做 OCR）', ocrPendingCount,
      ocrPendingRows.map((r) => ({ id: r.id, code: r.archive_code, title: `${r.title} — ${r.original_name}` })),
      '这些附件的正文提取没有成功（多为扫描件或旧版 .doc/.xls）。'
      + '可到「数据体检 → 扫描件 OCR」看本机可用的识别引擎并批量识别，'
      + '识别结果会标注为 OCR 来源（可能有错字）');

    const totalProblems = problems.reduce((s, p) => s + p.count, 0);
    // 按严重度排序后再返回：**必须处理排最前**，同类内按条目数从多到少。
    // 只给列表加字段而不排序是不够的 —— 界面按数组顺序渲染，顺序就是优先级。
    problems.sort((a, b) =>
      (SEV_ORDER[a.severity] - SEV_ORDER[b.severity]) || (b.count - a.count));
    const summary = { must: 0, should: 0, info: 0 };
    for (const p of problems) summary[p.severity] += p.count;
    const summaryTypes = { must: 0, should: 0, info: 0 };
    for (const p of problems) if (p.count > 0) summaryTypes[p.severity] += 1;
    ok(res, {
      problems, totalProblems,
      severitySummary: summary,          // 每一级"涉及多少条档案"
      severityTypes: summaryTypes,       // 每一级"有几种问题"
      archives: countOf('SELECT COUNT(*) FROM archives a WHERE 1=1' + scSql),
      scannedAt: nowIso(),
    });
  });

  /** 批量修改档案字段 */
  route('POST', '/api/archives/bulk-update', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const b = await readJson(req);

    // 两种用法：显式传 ids，或传 filter 按检索条件批量处理
    let ids = Array.isArray(b.ids) ? b.ids.map(Number).filter(Boolean) : [];
    if (!ids.length && b.filter) {
      const sp = new URLSearchParams();
      for (const [k, v] of Object.entries(b.filter)) {
        if (v !== '' && v !== null && v !== undefined) sp.set(k, String(v));
      }
      const f = buildFiltersOrFail(res, sp, u);
      if (!f) return;
      ids = q.all(`SELECT a.id FROM archives a ${f.sql} LIMIT 5000`, ...f.params).map((r) => r.id);
    }
    if (!ids.length) return fail(res, 400, '请先选择要批量修改的档案');

    // 显式传 ids 时也必须逐条过密级校验：
    // 否则只要猜到 id，就能越权修改自己看不到的涉密档案（批量入口最容易漏的就是这里）。
    if (ids.length) {
      const scope = secretScope(u);
      const holes = ids.map(() => '?').join(',');
      const allow = new Set(
        q.all(`SELECT a.id FROM archives a WHERE a.id IN (${holes})${scope.sql}`, ...ids, ...scope.params)
          .map((r) => Number(r.id)),
      );
      const before = ids.length;
      ids = ids.filter((id) => allow.has(id));
      if (ids.length !== before) {
        log(u, '批量修改跳过无权档案', `${before - ids.length} 条`, '超出账号密级上限', clientIp(req));
      }
      if (!ids.length) return fail(res, 403, '所选档案均超出你的密级权限范围');
    }

    // 允许修改的字段白名单
    const allowed = ['type_code', 'category_id', 'retention', 'secret_level', 'carrier',
      'department', 'responsible', 'location', 'status', 'open_state', 'electronic_flag',
      'year', 'archive_date', 'catalog_no', 'unit_code', 'status_note'];
    // 密级可以批量改，但**只有定密责任人（安全保密员/管理员）能改**（v4.10.0）。
    // 批量入口是最容易"顺手全选改一下"的地方，所以这里是权限门而不是便利门：
    // 挡的是"谁"，不是"一次改几件" —— 定密责任人本来就该能对一批档案作出同一定密决定。
    // 另外，改为「公开」时必须把保密期限一并清空：留着期限会让密级鉴定清单永远挂着它。
    let secretChanged = false;
    let secretToPublic = false;
    if (b.changes && Object.prototype.hasOwnProperty.call(b.changes, 'secret_level')) {
      const want = String(b.changes.secret_level || '');
      if (!can(u, 'secret:classify')) {
        return fail(res, 403, '变更密级需系统安全保密员或管理员权限（定密责任人）');
      }
      if (!SECRET_LEVELS.includes(want)) {
        return fail(res, 400, `密级取值不合法，可选：${SECRET_LEVELS.join(' / ')}`);
      }
      secretChanged = true;
      secretToPublic = want === '公开';
    }
    const sets = [];
    const vals = [];
    for (const [k, v] of Object.entries(b.changes || {})) {
      if (!allowed.includes(k)) continue;
      const val = v === null || v === undefined ? '' : String(v);
      if (val === '') continue;
      sets.push(`${k}=?`);
      vals.push(val);
    }
    if (!sets.length) return fail(res, 400, '没有需要修改的字段');

    // 批量改为「公开」时把保密期限一并清空。空值会被上面的循环跳过（那是为了防止
    // 误把字段清空），所以这里显式补上 —— 留着期限会让密级鉴定清单永远挂着已公开的档案。
    if (secretToPublic) {
      for (const col of ['secret_term', 'secret_from', 'secret_to', 'secret_basis']) {
        sets.push(`${col}=''`);
      }
    }

    // 保管期限变化时同步重算代码与到期年度
    let retentionYears = null;
    if (sets.some((s) => s.startsWith('retention='))) {
      const retention = String((b.changes || {}).retention);
      if (!RETENTIONS.includes(retention)) return fail(res, 400, '保管期限取值不合法');
      const info = RETENTION_MAP[retention] || { code: '', years: 0 };
      sets.push('retention_code=?', 'retention_years=?');
      vals.push(info.code, String(info.years));
      retentionYears = info.years;
    }

    // 改了会影响拼音键的字段（题名/关键词/责任者）就必须重算拼音键，
    // 否则批量改完题名后，用新题名的拼音搜不到、用旧题名的拼音反而能搜到 —— 最难查的一类 bug。
    const pyAffected = ['title', 'keywords', 'responsible'].some(
      (k) => b.changes && Object.prototype.hasOwnProperty.call(b.changes, k),
    );

    let changed = 0;
    q.tx(() => {
      for (const id of ids) {
        const cur = q.get('SELECT * FROM archives WHERE id=?', id);
        if (!cur) continue;
        const localSets = sets.slice();
        const localVals = vals.slice();
        localSets.push('updated_at=?');
        localVals.push(nowIso());
        if (retentionYears !== null) {
          // 用本次设置的年数直接重算（不能回头再查库，此刻 UPDATE 还没执行）
          const y = Number(cur.year) || Number(String(cur.archive_date || '').slice(0, 4)) || new Date().getFullYear();
          localSets.push('retention_due_year=?');
          localVals.push(String(retentionYears > 0 ? y + retentionYears : 0));
        }
        if (pyAffected) {
          // 同理：此刻 UPDATE 还没执行，要拿"改完之后的值"来算，不能用库里的旧值
          const merged = Object.assign({}, cur, {
            title: String((b.changes || {}).title || cur.title),
            keywords: String((b.changes || {}).keywords || cur.keywords),
            responsible: String((b.changes || {}).responsible || cur.responsible),
          });
          const k = pinyinLib.archiveKeys(merged);
          localSets.push('py_full=?', 'py_initials=?');
          localVals.push(k.full, k.initials);
        }
        localVals.push(id);
        // 批量修改最容易"一改一大片"，所以每一件都留底（改错能逐件还原）
        snapshotArchive(cur, u, '批量修改', '批量修改前自动留底');
        const r = q.run(`UPDATE archives SET ${localSets.join(', ')} WHERE id=?`, ...localVals);
        changed += r.changes;
      }
    });
    log(u, '批量修改档案', String(changed), Object.keys(b.changes || {}).join(', '), clientIp(req));
    // 密级批量变更单独留一条安全类日志：审计里"批量修改档案"四个字看不出密级被动过，
    // 而密级变更恰恰是安全审计最关心的动作（谁、把多少件、改成了什么）
    if (secretChanged) {
      log(u, '批量变更密级', `${changed} 件`, `密级 → ${String(b.changes.secret_level)}`, clientIp(req),
        { step: '定密', category: 'security' });
    }
    ok(res, { changed, fields: Object.keys(b.changes || {}) });
  });

  // ============================================================
  // 统计增强
  // ============================================================
  route('GET', '/api/stats/report', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const year = String(url.searchParams.get('year') || '').trim();
    // 统计口径必须受密级约束：**数量本身就是涉密信息**
    const sc = secretScope(u);
    const yearClause = year ? ' AND a.year = ?' : '';
    const yearArgs = year ? [year] : [];
    const where = ` WHERE 1=1${yearClause}${sc.sql}`;
    const args = [...yearArgs, ...sc.params];

    const totals = q.get(`SELECT COUNT(*) AS total,
        COALESCE(SUM(CAST(pages AS INTEGER)),0) AS pages,
        COALESCE(SUM(CASE WHEN carrier LIKE '%电子%' THEN 1 ELSE 0 END),0) AS electronic
      FROM archives a ${where}`, ...args);

    const byType = q.all(`SELECT t.code, t.name, COUNT(a.id) AS count
      FROM archive_types t LEFT JOIN archives a ON a.type_code=t.code${yearClause}${sc.sql}
      GROUP BY t.code ORDER BY t.sort_no`, ...args);

    const byCategory = q.all(`SELECT c.name, COUNT(a.id) AS count FROM categories c
      LEFT JOIN archives a ON a.category_id=c.id${yearClause}${sc.sql}
      WHERE c.level=2 GROUP BY c.id ORDER BY count DESC`, ...args);

    const byDepartment = q.all(`SELECT CASE WHEN department='' OR department IS NULL THEN '未填写' ELSE department END AS name,
        COUNT(*) AS count FROM archives a ${where} GROUP BY name ORDER BY count DESC LIMIT 20`, ...args);

    const byRetention = q.all(`SELECT retention AS name, retention_code AS code, COUNT(*) AS count
      FROM archives a ${where} GROUP BY retention ORDER BY count DESC`, ...args);

    const bySecret = q.all(`SELECT secret_level AS name, COUNT(*) AS count
      FROM archives a ${where} GROUP BY secret_level ORDER BY count DESC`, ...args);

    const byYear = q.all(`SELECT year AS name, COUNT(*) AS count FROM archives a
      WHERE a.year<>''${sc.sql} GROUP BY year ORDER BY year DESC LIMIT 20`, ...sc.params);

    const byStatus = q.all(`SELECT status AS name, COUNT(*) AS count FROM archives a ${where}
      GROUP BY status ORDER BY count DESC`, ...args);

    // 业务量统计：借阅、鉴定、销毁、移交
    // 注意：年度筛选必须用参数绑定，不能把 year 拼进 SQL 字符串
    const yearArg = year || '';
    const loanStats = {
      total: Number(q.scalar('SELECT COUNT(*) FROM loans l WHERE (?=\'\' OR substr(l.apply_at,1,4)=?)', yearArg, yearArg) || 0),
      byMode: q.all('SELECT mode AS name, COUNT(*) AS count FROM loans l WHERE (?=\'\' OR substr(l.apply_at,1,4)=?) GROUP BY mode', yearArg, yearArg),
      byStatus: q.all('SELECT status AS name, COUNT(*) AS count FROM loans l WHERE (?=\'\' OR substr(l.apply_at,1,4)=?) GROUP BY status', yearArg, yearArg),
    };
    const appraisalStats = {
      total: Number(q.scalar('SELECT COUNT(*) FROM appraisals p WHERE (?=\'\' OR substr(p.appraised_at,1,4)=?)', yearArg, yearArg) || 0),
      byDecision: q.all('SELECT decision AS name, COUNT(*) AS count FROM appraisals p WHERE (?=\'\' OR substr(p.appraised_at,1,4)=?) GROUP BY decision', yearArg, yearArg),
    };
    const destroyStats = {
      batches: Number(q.scalar(`SELECT COUNT(*) FROM destructions WHERE status='已销毁'`) || 0),
      items: Number(q.scalar(`SELECT COUNT(*) FROM destruction_items WHERE action='已销毁'`) || 0),
    };
    const transferStats = {
      batches: Number(q.scalar('SELECT COUNT(*) FROM transfers') || 0),
      items: Number(q.scalar('SELECT COUNT(*) FROM transfer_items') || 0),
      accepted: Number(q.scalar("SELECT COUNT(*) FROM transfers WHERE status='已接收'") || 0),
    };

    // 电子附件与正文索引情况
    const fileStats = {
      total: Number(q.scalar('SELECT COUNT(*) FROM files') || 0),
      bytes: Number(q.scalar('SELECT COALESCE(SUM(size),0) FROM files') || 0),
      indexed: Number(q.scalar("SELECT COUNT(*) FROM file_text WHERE status='成功'") || 0),
      textChars: Number(q.scalar("SELECT COALESCE(SUM(char_count),0) FROM file_text WHERE status='成功'") || 0),
    };

    ok(res, {
      year: year || '全部年度',
      years: q.all(`SELECT DISTINCT year FROM archives a WHERE a.year<>''${sc.sql} ORDER BY year DESC`, ...sc.params).map((r) => r.year),
      totals, byType, byCategory, byDepartment, byRetention, bySecret, byYear, byStatus,
      loanStats, appraisalStats, destroyStats, transferStats, fileStats,
      unitName: q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位',
      generatedAt: nowIso(),
    });
  });

  /** 打印统计年报 */
  route('GET', '/api/stats/report/print', async (req, res, params, url) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const year = String(url.searchParams.get('year') || '').trim();
    const sc = secretScope(u);
    const where = ` WHERE 1=1${year ? ' AND a.year = ?' : ''}${sc.sql}`;
    const args = [...(year ? [year] : []), ...sc.params];
    const unit = q.scalar("SELECT value FROM settings WHERE key='archive.unit_name'") || '本单位';

    const total = q.get(`SELECT COUNT(*) AS c, COALESCE(SUM(CAST(pages AS INTEGER)),0) AS p FROM archives a ${where}`, ...args);
    const byType = q.all(`SELECT t.name, COUNT(a.id) AS c FROM archive_types t
      LEFT JOIN archives a ON a.type_code=t.code${year ? ' AND a.year=?' : ''}${sc.sql}
      GROUP BY t.code ORDER BY t.sort_no`, ...args);
    const byRetention = q.all(`SELECT retention AS n, COUNT(*) AS c FROM archives a ${where} GROUP BY retention`, ...args);
    const bySecret = q.all(`SELECT secret_level AS n, COUNT(*) AS c FROM archives a ${where} GROUP BY secret_level`, ...args);
    const byStatus = q.all(`SELECT status AS n, COUNT(*) AS c FROM archives a ${where} GROUP BY status`, ...args);
    const byDept = q.all(`SELECT CASE WHEN department='' OR department IS NULL THEN '未填写' ELSE department END AS n,
      COUNT(*) AS c FROM archives a ${where} GROUP BY n ORDER BY c DESC LIMIT 15`, ...args);
    const loans = q.get('SELECT COUNT(*) AS c FROM loans') || { c: 0 };
    const files = q.get('SELECT COUNT(*) AS c, COALESCE(SUM(size),0) AS b FROM files') || { c: 0, b: 0 };

    const tbl = (title, rows, k1, k2) => `
      <div class="rep-block">
        <div class="rep-title">${esc(title)}</div>
        <table class="print-table"><thead><tr><th>${esc(k1)}</th><th style="width:90px">数量</th></tr></thead>
        <tbody>${rows.map((r) => `<tr><td>${esc(r.n)}</td><td style="text-align:right">${r.c}</td></tr>`).join('')}
        <tr><td style="text-align:right"><b>合计</b></td><td style="text-align:right"><b>${rows.reduce((s, r) => s + Number(r.c), 0)}</b></td></tr>
        </tbody></table></div>`;

    const html = printShell('档案统计年报', `
      <style>
        .rep-block { margin-bottom: 14px; }
        .rep-title { font-weight:600; margin: 8px 0 4px; font-size:13px; }
        .rep-grid { display:flex; gap:16px; align-items:flex-start; }
        .rep-grid > div { flex:1; }
      </style>
      <div class="print-head"><h1>档 案 工 作 统 计 年 报</h1><div class="meta">
        单位名称：${esc(unit)}　统计年度：${esc(year || '全部年度')}　制表日期：${new Date().toLocaleDateString('zh-CN')}</div></div>
      <table class="print-table" style="margin-bottom:12px"><tbody>
        <tr><td style="width:150px">馆藏档案总数</td><td><b>${total.c}</b> 件</td>
            <td style="width:150px">档案总页数</td><td>${total.p} 页</td></tr>
        <tr><td>电子附件数</td><td>${files.c} 个</td>
            <td>附件占用空间</td><td>${(files.b / 1048576).toFixed(1)} MB</td></tr>
        <tr><td>累计借阅次数</td><td>${loans.c} 次</td>
            <td>门类数 / 分类数</td><td>${byType.length} / ${Number(q.scalar('SELECT COUNT(*) FROM categories') || 0)}</td></tr>
      </tbody></table>
      ${tbl('一、按门类统计', byType.map((r) => ({ n: r.name, c: r.c })), '档案门类', '数量')}
      ${tbl('二、按保管期限统计', byRetention, '保管期限', '数量')}
      ${tbl('三、按密级统计', bySecret, '密级', '数量')}
      ${tbl('四、按档案状态统计', byStatus, '状态', '数量')}
      ${tbl('五、按部门统计', byDept, '部门', '数量')}
      <div class="sign-row">
        <div>制表人：____________</div>
        <div>审核人：____________</div>
        <div>单位负责人：____________</div>
        <div>日期：______年____月____日</div>
      </div>`, !!url.searchParams.get('auto'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });

  /** 导出统计表 CSV */
  route('GET', '/api/stats/report.csv', async (req, res, params, url) => {
    const u = requireRole(req, res, 'clerk');
    if (!u) return;
    const year = String(url.searchParams.get('year') || '').trim();
    const sc = secretScope(u);
    const where = ` WHERE 1=1${year ? ' AND a.year = ?' : ''}${sc.sql}`;
    const args = [...(year ? [year] : []), ...sc.params];
    const lines = [];
    lines.push(['统计维度', '项目', '数量']);
    const push = (dim, rows, k) => rows.forEach((r) => lines.push([dim, r[k], r.count !== undefined ? r.count : r.c]));
    const byType = q.all(`SELECT t.name, COUNT(a.id) AS c FROM archive_types t
      LEFT JOIN archives a ON a.type_code=t.code${year ? ' AND a.year=?' : ''}${sc.sql}
      GROUP BY t.code ORDER BY t.sort_no`, ...args);
    push('按门类', byType, 'name');
    push('按保管期限', q.all(`SELECT retention AS name, COUNT(*) AS c FROM archives a ${where} GROUP BY retention`, ...args), 'name');
    push('按密级', q.all(`SELECT secret_level AS name, COUNT(*) AS c FROM archives a ${where} GROUP BY secret_level`, ...args), 'name');
    push('按状态', q.all(`SELECT status AS name, COUNT(*) AS c FROM archives a ${where} GROUP BY status`, ...args), 'name');
    push('按年度', q.all(`SELECT year AS name, COUNT(*) AS c FROM archives a
      WHERE a.year<>''${sc.sql} GROUP BY year ORDER BY year DESC`, ...sc.params), 'name');
    const csv = toCsv(lines[0], lines.slice(1));
    const buf = Buffer.from(csv, 'utf8');
    log(u, '导出统计表', year || '全部年度', '', clientIp(req));
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': contentDisposition(`档案统计表_${year || '全部年度'}_${today()}.csv`),
      'Content-Length': buf.length,
    });
    res.end(buf);
  });

  // ===== 分发 =====
  /**
   * CSRF 纵深防御：带凭证的写操作做 Origin/Referer 校验。
   *
   * 主要防线其实是 Cookie 的 SameSite=Lax（浏览器不会在跨站 POST 上带 Cookie）。
   * 这里再加一道：只要请求带了 Origin/Referer，就要求它与本站 Host 一致。
   *
   * 之所以"没带就放行"：curl、脚本、自测客户端本来就不带这些头，
   * 而 CSRF 是**浏览器**才会发动的攻击 —— 浏览器一定会带（非 GET 请求）。
   * 反向代理等特殊部署若被误拦，可用设置 security.csrf_origin_check=0 关闭。
   *
   * @returns {string} 问题描述；'' 表示通过
   */
  function csrfCheck(req) {
    const m = String(req.method || 'GET').toUpperCase();
    if (m === 'GET' || m === 'HEAD' || m === 'OPTIONS') return '';
    if (String(numbering.getSetting(q, 'security.csrf_origin_check', '1')) !== '1') return '';
    const cookies = parseCookies(req);
    const hasCredential = !!cookies.dsh_archive_token || !!req.headers['x-auth-token'];
    if (!hasCredential) return '';                       // 匿名写操作不涉及 CSRF
    const src = String(req.headers.origin || req.headers.referer || '');
    if (!src) return '';                                 // 非浏览器客户端
    const host = String(req.headers.host || '');
    if (!host) return '';
    let srcHost = '';
    try { srcHost = new URL(src).host; } catch (_) { return `来源地址无法解析（${src.slice(0, 60)}）`; }
    if (srcHost !== host) return `来源 ${srcHost} 与本站 ${host} 不一致`;
    return '';
  }

  async function handle(req, res, url) {
    const pathname = decodeURIComponent(url.pathname);
    // /api/ 下的所有接口，外加两个短落地页：
    //   /q/<令牌> 档案二维码    /b/<令牌> 档案盒二维码
    // 做得这么短是刻意的：二维码内容越短，模块数越少，打印到纸上每个模块越大、越好扫。
    // 未匹配到任何路由时返回 false，交回上层走静态文件/单页应用。
    if (!pathname.startsWith('/api/') && !pathname.startsWith('/q/') && !pathname.startsWith('/b/')) return false;

    // CSRF 纵深防御：放在入口处统一拦，避免"某个接口忘了校验"
    const csrfProblem = csrfCheck(req);
    if (csrfProblem) {
      try {
        const cu = currentUser(req);
        log(cu, '来源校验拒绝', `${req.method} ${pathname}`, csrfProblem, clientIp(req),
          { result: '拒绝', category: 'security', step: 'CSRF 校验' });
      } catch (_) { /* 审计失败不影响拒绝 */ }
      fail(res, 403, `请求来源校验未通过：${csrfProblem}`, 'CSRF_REJECTED');
      return true;
    }

    for (const r of routes) {
      if (!r.methods.includes(req.method)) continue;
      const m = r.rx.exec(pathname);
      if (!m) continue;
      // 授权只读（v4.33.0）：到期/换机器/签名不符时，写操作一律拒绝，读与导出照常。
      // 放在路由命中之后、真正执行之前 —— 这样 404 的接口还是 404，不会被误报成"授权问题"。
      if (isReadOnly() && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)
          && !READONLY_ALLOW.includes(pathname)) {
        fail(res, 403,
          '（授权只读）' + lic.message + '　如需恢复写入，请放置有效授权文件后重新读取。', 'LICENSE_READONLY');
        return true;
      }
      const params = {};
      r.names.forEach((n, i) => { params[n] = m[i + 1]; });
      try {
        await r.handler(req, res, params, url);
      } catch (e) {
        const status = e && e.statusCode ? e.statusCode : 500;
        if (status >= 500) console.error('[API 错误]', pathname, e);
        if (!res.headersSent) fail(res, status, (e && e.message) || '服务器内部错误');
        else res.end();
      }
      return true;
    }
    fail(res, 404, `接口不存在：${req.method} ${pathname}`, 'NOT_FOUND');
    return true;
  }

  // ============================================================
  //  待办中心与定时任务（v13）
  // ============================================================

  /**
   * 待检测清单。抽出来给**定时巡检**与人工页面共用：
   * user 传 null 表示系统口径（巡检是系统自身行为，不受任何账号密级限制），
   * 传用户则按该账号的密级过滤（人工页面必须过滤）。
   *
   * @returns {{list:object[], yearlyDays:number}}
   */
  function dueDetectionList(user, limit = 500) {
    const yearlyDays = Number(numbering.getSetting(q, 'detection.yearly_days', '365')) || 365;
    const sc = user ? secretScope(user) : { sql: '', params: [] };
    const cap = Math.min(1000, Math.max(10, Number(limit) || 500));
    const rows = q.all(`SELECT a.id, a.archive_code, a.title, a.year, a.retention,
        (SELECT MAX(d.created_at) FROM detections d
          WHERE d.archive_id=a.id AND d.environment='archive' AND d.qualified=1) AS last_ok
        FROM archives a WHERE 1=1${sc.sql}
        ORDER BY (last_ok IS NULL) DESC, last_ok LIMIT ?`, ...sc.params, cap);
    const now = Date.now();
    const list = [];
    for (const r of rows) {
      const t = r.last_ok ? Date.parse(r.last_ok) : 0;
      const days = t ? Math.floor((now - t) / 86400000) : null;
      const overdue = !t || days > yearlyDays;
      if (!overdue) continue;
      list.push({
        id: r.id, archive_code: r.archive_code, title: r.title, year: r.year, retention: r.retention,
        last_ok: r.last_ok || '', days, never: !t,
        reason: !t ? '从未通过归档环节四性检测' : `上次通过检测距今 ${days} 天，已超过 ${yearlyDays} 天`,
      });
    }
    return { list, yearlyDays, cap };
  }

  /**
   * 四性检测巡检（定时任务调用）。
   *
   * 为什么要限批量：到期待检可能上千件，一次全跑会把服务占死。
   * 每次只跑 budget 件，**没跑完的部分留给下一天**，同时把积压量做成待办提醒人。
   * 宁可慢一点，也不能让"定期巡检"变成"定期卡死服务"。
   *
   * @param {object} [opts] { budget }
   */
  function runDetectionSweep(opts = {}) {
    const budget = Math.max(1, Math.min(500, Number(opts.budget) || 100));
    const sysUser = { id: null, username: '系统' };
    const due = dueDetectionList(null, 1000).list;
    if (!due.length) return { detail: '没有到期待检的档案', scanned: 0, checked: 0, qualified: 0, unqualified: 0, failed: 0, remaining: 0 };
    const batch = due.slice(0, budget);
    let qualified = 0;
    let unqualified = 0;
    let failed = 0;
    for (const d of batch) {
      try {
        const r = runAndSaveDetection(sysUser, d.id, 'archive', '定时巡检');
        if (r.qualified) qualified++; else unqualified++;
      } catch (_) { failed++; }
    }
    const remaining = due.length - batch.length;
    const detail = `巡检 ${batch.length} 件：合格 ${qualified}、不合格 ${unqualified}`
      + (failed ? `、异常 ${failed}` : '') + (remaining ? `；尚有 ${remaining} 件待检` : '');
    log(sysUser, '四性检测巡检', '定时任务', detail, '',
      { category: 'detection', step: '定期巡检', result: failed ? '失败' : '成功' });
    return { detail, scanned: due.length, checked: batch.length, qualified, unqualified, failed, remaining };
  }

  // ---- 调度器引用（由 server.js 启动后注入）----
  // 不在这里 new 一个调度器：调度器要用到本模块的 runBackup/runStorageCheck 等函数，
  // 由 server.js 组装、再回注进来，依赖是单向的，避免 api 与 scheduler 互相 require。
  let schedulerRef = null;
  function attachScheduler(s) { schedulerRef = s; }

  /** 调度器状态 */
  route('GET', '/api/scheduler/status', async (req, res) => {
    const u = requireCan(req, res, 'scheduler:view');
    if (!u) return;
    const enabled = String(numbering.getSetting(q, 'scheduler.enabled', '1')) !== '0';
    const settings = {
      enabled,
      backup_hour: Number(numbering.getSetting(q, 'scheduler.backup_hour', '2')),
      catch_up_hours: Number(numbering.getSetting(q, 'scheduler.catch_up_hours', '24')),
      keep_copies: Number(numbering.getSetting(q, 'backup.keep_copies', '7')),
      sweep_days: Number(numbering.getSetting(q, 'detection.sweep_interval_days', '30')),
      storage_days: Number(numbering.getSetting(q, 'storage.check_interval_days', '30')),
    };
    if (!schedulerRef) {
      return ok(res, { attached: false, settings, tasks: [], note: '调度器未启动（服务可能以 --no-scheduler 启动）' });
    }
    ok(res, { attached: true, settings, tasks: schedulerRef.status() });
  });

  /** 手动触发一个任务（"立即运行"按钮） */
  route('POST', '/api/scheduler/run/:key', async (req, res, params) => {
    const u = requireCan(req, res, 'scheduler:run');
    if (!u) return;
    if (!schedulerRef) return fail(res, 400, '调度器未启动');
    if (!schedulerRef.has(params.key)) return fail(res, 404, `没有这个任务：${params.key}`);
    const r = await schedulerRef.runNow(params.key);
    log(u, '手动触发定时任务', params.key, r.detail || '', clientIp(req),
      { category: 'scheduler', step: '手动触发', result: r.ok ? '成功' : '失败' });
    ok(res, r);
  });

  /** 待办列表（含各状态计数，供导航红点用） */
  route('GET', '/api/todos', async (req, res, params, url) => {
    const u = requireCan(req, res, 'todo:read');
    if (!u) return;
    const rawStatus = String(url.searchParams.get('status') || 'open');
    const status = ['open', 'done', 'dismissed', 'all'].includes(rawStatus) ? rawStatus : 'open';
    const rawLevel = String(url.searchParams.get('level') || '');
    const level = ['info', 'warn', 'critical'].includes(rawLevel) ? rawLevel : '';
    const kind = String(url.searchParams.get('kind') || '').slice(0, 30);
    const limit = Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 200));

    const where = [];
    const args = [];
    if (status !== 'all') { where.push('status=?'); args.push(status); }
    if (level) { where.push('level=?'); args.push(level); }
    if (kind) { where.push('kind=?'); args.push(kind); }
    const list = q.all(
      `SELECT * FROM todos ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
       ORDER BY CASE level WHEN 'critical' THEN 0 WHEN 'warn' THEN 1 ELSE 2 END, id DESC LIMIT ?`,
      ...args, limit,
    );
    const countOf = (sql) => Number(q.scalar(sql) || 0);
    ok(res, {
      list,
      total: list.length,
      counts: {
        open: countOf("SELECT COUNT(*) FROM todos WHERE status='open'"),
        critical: countOf("SELECT COUNT(*) FROM todos WHERE status='open' AND level='critical'"),
        warn: countOf("SELECT COUNT(*) FROM todos WHERE status='open' AND level='warn'"),
        done: countOf("SELECT COUNT(*) FROM todos WHERE status='done'"),
        dismissed: countOf("SELECT COUNT(*) FROM todos WHERE status='dismissed'"),
      },
    });
  });

  /** 处理/忽略/重开一条待办 */
  async function setTodoStatus(req, res, params, nextStatus) {
    const u = requireCan(req, res, 'todo:handle');
    if (!u) return;
    const id = Number(params.id);
    const t = q.get('SELECT * FROM todos WHERE id=?', id);
    if (!t) return fail(res, 404, '待办不存在或已删除');
    if (nextStatus !== 'open' && t.status !== 'open') return fail(res, 400, '该待办已被处理过');
    if (nextStatus === 'open' && t.status === 'open') return fail(res, 400, '该待办本来就是待处理状态');
    let b = {};
    try { b = await readJson(req); } catch (_) { b = {}; }
    const note = String(b.note || '').slice(0, 300);
    q.run(`UPDATE todos SET status=?, handled_by=?, handled_at=?, handled_note=?, updated_at=? WHERE id=?`,
      nextStatus, u.id, nowIso(), note, nowIso(), id);
    const label = nextStatus === 'done' ? '处理待办' : (nextStatus === 'dismissed' ? '忽略待办' : '重开待办');
    log(u, label, t.title, note || t.detail || '', clientIp(req),
      { category: 'scheduler', step: '待办处置' });
    ok(res, { id, status: nextStatus });
  }

  route('POST', '/api/todos/:id/done', (req, res, params) => setTodoStatus(req, res, params, 'done'));
  route('POST', '/api/todos/:id/dismiss', (req, res, params) => setTodoStatus(req, res, params, 'dismissed'));
  route('POST', '/api/todos/:id/reopen', (req, res, params) => setTodoStatus(req, res, params, 'open'));

  // ============================================================
  //  常用检索（保存检索策略，v14）
  // ============================================================
  const SEARCH_NAME_MAX = 40;
  const SEARCH_QUERY_MAX = 4000;

  function parseQueryJson(s) {
    try {
      const o = JSON.parse(s || '{}');
      return (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
    } catch (_) { return {}; }
  }

  /**
   * 规范化保存进来的检索条件。
   *
   * 服务端**只做形状与体积约束，不解释内容** —— 检索条件的解释权归列表接口的 buildFilters 一处。
   * 若这里再实现一遍解析，两边口径迟早不一致（"保存时能查到的，调出来查不到"）。
   */
  function normalizeSearchQuery(raw) {
    if (raw === null || raw === undefined) return '{}';
    if (typeof raw !== 'object' || Array.isArray(raw)) {
      throw Object.assign(new Error('检索条件必须是一个对象（就是检索表单里那些字段）'), { statusCode: 400 });
    }
    const out = {};
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k !== 'string' || !k || k.length > 40) continue;
      if (v === null || v === undefined || typeof v === 'object') continue;   // 只收标量
      const s = String(v);
      if (!s) continue;
      // 超长**明确拒绝**，不静默截断 —— 悄悄把用户的检索词截短，
      // 会出现"保存时是这个条件、调出来查的是另一个条件"，而且没人知道。
      // `expr`（高级检索表达式）天生比普通条件长，配额单独给；上限取自 lib/query-expr，
      // 保证"列表接口能接受的表达式，一定存得下"。
      const cap = (k === 'expr') ? queryExpr.LIMITS.MAX_LEN : 200;
      if (s.length > cap) {
        throw Object.assign(new Error(`条件「${k}」太长（超过 ${cap} 字），请精简后再保存`), { statusCode: 400 });
      }
      // 表达式在**保存时**先编译一次：能存进去的一定是能查的。
      // 否则就会出现这个系统最怕的那类问题 ——「存的时候好好的，调出来报错」。
      if (k === 'expr') {
        try { queryExpr.validate(s); } catch (e) {
          const at = (Number(e.position) || 0) + 1;
          throw Object.assign(
            new Error(`检索表达式有错：${e.message}（第 ${at} 个字符处）`),
            { statusCode: 400 },
          );
        }
      }
      out[k] = s;
    }
    const json = JSON.stringify(out);
    if (json.length > SEARCH_QUERY_MAX) {
      throw Object.assign(new Error('检索条件太大，请精简后再保存'), { statusCode: 400 });
    }
    return json;
  }

  /** 自己的 + 共享的；最近用过的排前面 */
  route('GET', '/api/searches', async (req, res) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const list = q.all(
      `SELECT * FROM saved_searches WHERE owner_id=? OR shared=1
        ORDER BY (last_used_at='') ASC, last_used_at DESC, id DESC LIMIT 200`, u.id);
    ok(res, {
      list: list.map((r) => Object.assign({}, r, {
        query: parseQueryJson(r.query),
        mine: Number(r.owner_id) === Number(u.id),
      })),
      total: list.length,
    });
  });

  /** 保存（同名覆盖：连点两次不该存出一堆重名） */
  route('POST', '/api/searches', async (req, res) => {
    const u = requireCan(req, res, 'archive:read');
    if (!u) return;
    const b = await readJson(req);
    const name = mustStr(b.name, SEARCH_NAME_MAX).trim();
    if (!name) return fail(res, 400, '请给这个检索起个名字（例如「2026 年文书档案待鉴定」）');
    let query;
    try { query = normalizeSearchQuery(b.query); } catch (e) { return fail(res, e.statusCode || 400, e.message); }
    const shared = b.shared ? 1 : 0;
    const dup = q.get('SELECT id FROM saved_searches WHERE owner_id=? AND name=?', u.id, name);
    if (dup) {
      q.run('UPDATE saved_searches SET query=?, note=?, shared=?, updated_at=? WHERE id=?',
        query, mustStr(b.note, 200), shared, nowIso(), dup.id);
      log(u, '更新常用检索', name, '', clientIp(req), { category: 'output', step: '常用检索' });
      return ok(res, { id: dup.id, updated: true });
    }
    const r = q.run(
      `INSERT INTO saved_searches(name,query,note,shared,owner_id,owner,created_at,updated_at)
       VALUES(?,?,?,?,?,?,?,?)`,
      name, query, mustStr(b.note, 200), shared, u.id, u.username, nowIso(), nowIso(),
    );
    log(u, '保存常用检索', name, shared ? '共享' : '私有', clientIp(req), { category: 'output', step: '常用检索' });
    ok(res, { id: r.lastInsertRowid, updated: false });
  });

  /** 记一次使用：列表就能按"最近用过"排序，常用的自动浮到前面 */
  route('POST', '/api/searches/:id/use', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const row = q.get('SELECT * FROM saved_searches WHERE id=?', id);
    if (!row) return fail(res, 404, '该常用检索不存在');
    if (Number(row.owner_id) !== Number(u.id) && !row.shared) {
      return fail(res, 404, '该常用检索不存在');   // 别人的私有检索：按不存在回应，不泄露
    }
    q.run('UPDATE saved_searches SET used_count=used_count+1, last_used_at=? WHERE id=?', nowIso(), id);
    ok(res, { id, query: parseQueryJson(row.query) });
  });

  route('DELETE', '/api/searches/:id', async (req, res, params) => {
    const u = requireAuth(req, res);
    if (!u) return;
    const id = Number(params.id);
    const row = q.get('SELECT * FROM saved_searches WHERE id=?', id);
    if (!row) return fail(res, 404, '该常用检索不存在');
    if (Number(row.owner_id) !== Number(u.id) && !policy.can(u, 'system:manage')) {
      return fail(res, 403, '只能删除自己保存的检索');
    }
    q.run('DELETE FROM saved_searches WHERE id=?', id);
    log(u, '删除常用检索', row.name, '', clientIp(req), { category: 'output', step: '常用检索' });
    ok(res, true);
  });

  // ============================================================
  //  首次使用向导
  return {
    handle, refreshOverdue, processLoanDue, log, auditWeakPasswords, pruneLoginAttempts,
    // v13：供 server.js 组装定时任务使用（调度器要用同一份实现，不能另写一套）
    runBackup, runStorageCheck, runDetectionSweep, dueDetectionList, attachScheduler,
    // v4.13.0：启动时预热 OCR 引擎探测。探测走 spawnSync（会阻塞事件循环），
    // 必须在请求路径之外做 —— 否则第一个访问 OCR 状态的请求会把整个服务卡住几秒。
    warmOcrDetect: () => ocrDetect(true),
  };
}

module.exports = { createApi, RETENTIONS, SECRET_LEVELS, CARRIERS, STATUSES, ROLES, ROLE_NAMES };
