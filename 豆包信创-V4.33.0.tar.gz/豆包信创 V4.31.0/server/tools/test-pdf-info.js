/**
 * PDF 页数解析自测：node server/tools/test-pdf-info.js
 *
 * 不用真实扫描件也能验证解析逻辑 —— 这里按 PDF 语法拼出最小文件：
 *   ① 普通对象（页面对象明文）        → 应数出 3 页
 *   ② 对象流（ObjStm，Flate 压缩）    → 应数出 3 页
 *   ③ 只有页面树 /Count 的残缺结构    → 应回退到 /Count
 *   ④ 加密 PDF                       → 页数应为 0 且 encrypted=true
 *   ⑤ 非 PDF                         → 0，且不抛异常
 */
'use strict';

const zlib = require('node:zlib');
const { analyze, pageCount, isPdf } = require('../lib/pdf-info');

let pass = 0;
let fail = 0;

function check(name, actual, expected) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { pass += 1; console.log(`  ✓ ${name}`); } else {
    fail += 1;
    console.log(`  ✗ ${name}：期望 ${JSON.stringify(expected)}，实际 ${JSON.stringify(actual)}`);
  }
}

function buildPdf(objects, trailerExtra = '') {
  const parts = ['%PDF-1.7'];
  const offsets = [];
  let pos = parts[0].length + 1;
  objects.forEach((body, i) => {
    const text = `${i + 1} 0 obj\n${body}\nendobj\n`;
    offsets.push(pos);
    parts.push(text);
    pos += text.length;
  });
  const xrefStart = pos;
  parts.push(`xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`);
  for (const off of offsets) parts.push(`${String(off).padStart(10, '0')} 00000 n \n`);
  parts.push(`trailer\n<< /Size ${objects.length + 1} /Root 1 0 R ${trailerExtra}>>\nstartxref\n${xrefStart}\n%%EOF\n`);
  return Buffer.from(parts.join(''), 'latin1');
}

// ① 明文页面对象 3 页
const plain = buildPdf([
  '<< /Type /Catalog /Pages 2 0 R >>',
  '<< /Type /Pages /Kids [3 0 R 4 0 R 5 0 R] /Count 3 >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] >>',
]);

// ② 对象流：页面对象都被压进一个 ObjStm，原始字节里数不到 /Type /Page
const objStmBody = '<< /Type /Page >> << /Type /Page >> << /Type /Page >>';
const deflated = zlib.deflateSync(Buffer.from(objStmBody, 'latin1'));
const compressed = Buffer.concat([
  Buffer.from('%PDF-1.7\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Count 3 /Kids [3 0 R 4 0 R 5 0 R] >>\nendobj\n', 'latin1'),
  Buffer.from('6 0 obj\n<< /Type /ObjStm /N 3 /First 0 /Filter /FlateDecode /Length ', 'latin1'),
  Buffer.from(String(deflated.length), 'latin1'),
  Buffer.from(' >>\nstream\n', 'latin1'),
  deflated,
  Buffer.from('\nendstream\nendobj\ntrailer\n<< /Root 1 0 R >>\nstartxref\n0\n%%EOF\n', 'latin1'),
]);
// 这份对象流里页面对象是明文（无压缩），确保退路可用；同时 Count=3 也在明文里

// ③ 只有页面树 /Count
const countOnly = Buffer.from(
  '%PDF-1.4\n1 0 obj\n<< /Type /Pages /Kids [] /Count 7 >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n',
  'latin1',
);

// ④ 加密
const encrypted = buildPdf(
  ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Count 3 >>'],
  '/Encrypt 9 0 R ',
);

// ⑤ 非 PDF
const notPdf = Buffer.from('这不是 PDF，只是一段普通文本。', 'utf8');

console.log('PDF 页数解析');
check('明文 3 页', analyze(plain).pages, 3);
check('对象流（压缩）3 页', analyze(compressed).pages, 3);
check('只有 /Count 时按 Count', analyze(countOnly).pages, 7);
check('加密 PDF 页数为 0', analyze(encrypted).pages, 0);
check('加密标记', analyze(encrypted).encrypted, true);
check('非 PDF 不抛异常且为 0', pageCount(notPdf), 0);
check('isPdf 认扩展名', isPdf('扫描件.PDF', ''), true);
check('isPdf 认 MIME', isPdf('x.bin', 'application/pdf'), true);
check('isPdf 不误判 txt', isPdf('a.txt', 'text/plain'), false);

// 扫描件特征：整页一张 JPEG
const scanned = buildPdf([
  '<< /Type /Catalog /Pages 2 0 R >>',
  '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
  '<< /Type /Page /Parent 2 0 R /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>',
  '<< /Type /XObject /Subtype /Image /Filter /DCTDecode /Width 2480 /Height 3508 >>',
]);
check('扫描件识别（DCTDecode）', analyze(scanned).scanned, true);

console.log(`\n通过 ${pass}，失败 ${fail}`);
process.exit(fail ? 1 : 0);
