/**
 * 扫码枪解析与扫码工作台接口验证
 *
 * 分两段：
 *   A. 解析器纯函数（进程内直接跑，不用起服务）—— 覆盖各种标签形态；
 *   B. /api/scan/resolve 与「盘点扫码共用解析」的回归。
 *
 * 为什么 B 段要专门测盘点：这次把盘点接口里内联的解析逻辑抽成了 lib/scan-parse，
 * 两边共用。若不回归盘点，「重构没改坏行为」就只是嘴上说说。
 */
'use strict';

const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const scanParse = require('../lib/scan-parse');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'SC' + Math.random().toString(16).slice(2, 8).toUpperCase();
const ARCHIVE_CODE = 'Z001-WS-2026-BG-01-0001';
const BOX_CODE = '2026-WS-001';

async function main() {
  const admin = makeSession();

  // ---------------------------------------------------------------- A 解析器
  section('A. 解析器：各种标签形态都要认得出');
  const p = (text, opts) => scanParse.scanCandidates(text, opts || {});
  const has = (r, v) => r.candidates.includes(v);

  const shortArc = p(`https://x.example/q/abc123/${ARCHIVE_CODE}`);
  check('短档案网址 → 类型提示为档案', shortArc.hint === 'archive', String(shortArc.hint));
  check('短档案网址 → 候选里含档号', has(shortArc, ARCHIVE_CODE), JSON.stringify(shortArc.candidates.slice(0, 5)));

  const shortBox = p(`https://x.example/b/def456/${BOX_CODE}`);
  check('短盒网址 → 类型提示为盒', shortBox.hint === 'box', String(shortBox.hint));
  check('短盒网址 → 候选里含盒号', has(shortBox, BOX_CODE), JSON.stringify(shortBox.candidates.slice(0, 5)));

  const longArc = p(`http://192.168.3.28:8787/api/a/${ARCHIVE_CODE}?k=ABCDEFGHIJKL&i=12`);
  check('旧档案长网址 → 类型提示为档案', longArc.hint === 'archive', String(longArc.hint));
  check('旧档案长网址 → 候选里含档号', has(longArc, ARCHIVE_CODE));

  const longBox = p(`http://192.168.3.28:8787/api/s/${BOX_CODE}?k=ABCDEFGHIJKL`);
  check('旧盒脊长网址 → 类型提示为盒', longBox.hint === 'box', String(longBox.hint));
  check('旧盒脊长网址 → 候选里含盒号', has(longBox, BOX_CODE));

  const prefixed = p(`档案号：${ARCHIVE_CODE}`);
  check('带「档案号：」前缀的文本 → 提取出编号', has(prefixed, ARCHIVE_CODE), JSON.stringify(prefixed.candidates));

  const boxPrefixed = p(`盒号：${BOX_CODE}\r\n`);
  check('带「盒号：」前缀且带回车 → 提取出编号并归一化', has(boxPrefixed, BOX_CODE), JSON.stringify(boxPrefixed.candidates));
  check('归一化去掉了回车', boxPrefixed.raw === `盒号：${BOX_CODE}`, JSON.stringify(boxPrefixed.raw));

  const plain = p(`${ARCHIVE_CODE}\r\n`);
  check('纯编号（qr.mode=code 的标签）→ 候选就是它本身', has(plain, ARCHIVE_CODE), JSON.stringify(plain.candidates));
  check('纯编号没有类型提示（当时无从判断）', plain.hint === null, String(plain.hint));

  check('空文本 → 候选为空', p('   ').candidates.length === 0, JSON.stringify(p('   ').candidates));
  check('非法网址不抛错', (() => { try { p('http://%%%'); return true; } catch (_) { return false; } })());

  // 令牌反解：证明"改了档号之后，已经打印出去的旧标签照样能打开"
  const stub = p(`https://x/q/tok9999/OLD-CODE-1`, {
    signKey: 'k',
    parseShortArchiveToken: (t) => (t === 'tok9999' ? 77 : 0),
    archiveById: (id) => (id === 77 ? { archive_code: 'NEW-CODE-9', archive_number: 'N9' } : null),
  });
  check('短令牌能反解出档案并按 id 取到当前档号', has(stub, 'NEW-CODE-9'), JSON.stringify(stub.candidates));
  check('网址尾巴上的旧档号也保留为候选', has(stub, 'OLD-CODE-1'), JSON.stringify(stub.candidates));

  const boxStub = p(`https://x/b/btok1/B1`, {
    signKey: 'k',
    parseShortBoxToken: (t) => (t === 'btok1' ? 5 : 0),
    boxById: (id) => (id === 5 ? { box_code: 'BOX-5', barcode: 'BC-5' } : null),
  });
  check('盒短令牌同样能反解出盒号与条码', has(boxStub, 'BOX-5') && has(boxStub, 'BC-5'), JSON.stringify(boxStub.candidates));

  const encoded = p(`http://x/api/a/${encodeURIComponent('中文档号-001')}`);
  check('网址里的中文档号能解码还原', has(encoded, '中文档号-001'), JSON.stringify(encoded.candidates));

  // ---------------------------------------------------------------- B 接口
  section('B. /api/scan/resolve 接口');
  const anon = makeSession();
  check('未登录不允许解析（401）', (await anon.json('/api/scan/resolve?text=' + ARCHIVE_CODE)).status === 401);

  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));

  const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
  // 演示数据的密级是 公开/内部/秘密（没有"机密"）—— 用"高于阅读者（内部）"的档来测越权，
  // 而不是写死某个具体等级，否则夹具一变用例就假失败。
  const row = db.prepare("SELECT id, archive_code, secret_level FROM archives WHERE status NOT IN ('已销毁') AND secret_level='内部' LIMIT 1").get();
  const secretRow = db.prepare("SELECT id, archive_code, secret_level FROM archives WHERE secret_level NOT IN ('','公开','内部') LIMIT 1").get();

  const anyArchive = db.prepare("SELECT archive_code FROM archives WHERE archive_code<>'' LIMIT 1").get();
  const ac = (anyArchive && anyArchive.archive_code) || ARCHIVE_CODE;

  const r1 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent(ac));
  check('扫纯档号 → 认成档案', r1.status === 200 && r1.body.data.kind === 'archive', JSON.stringify(r1.body.data).slice(0, 160));
  check('返回档案详情（题名/状态/密级）', !!(r1.body.data.archive || {}).title !== undefined,
    JSON.stringify((r1.body.data.archive || {})).slice(0, 160));

  const r2 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent(`http://192.168.3.28:8787/api/a/${ac}?k=ZZZZZZZZZZZZ&i=1`));
  check('扫旧长网址 → 同样认成档案', r2.body.data.kind === 'archive', JSON.stringify(r2.body.data).slice(0, 120));
  check('认出来的是同一份档案', (r2.body.data.archive || {}).archive_code === (r1.body.data.archive || {}).archive_code,
    `${(r2.body.data.archive || {}).archive_code} vs ${(r1.body.data.archive || {}).archive_code}`);

  const r3 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent(`https://x/q/BOGUSTOKEN000/${ac}`));
  check('短网址即使令牌无法校验，也能靠尾巴上的档号认出（旧标签不失效）', r3.body.data.kind === 'archive',
    JSON.stringify(r3.body.data).slice(0, 140));

  const anyBox = db.prepare('SELECT box_code FROM archive_boxes LIMIT 1').get();
  if (anyBox && anyBox.box_code) {
    const r4 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent(anyBox.box_code));
    check('扫盒号 → 认成档案盒', r4.body.data.kind === 'box', JSON.stringify(r4.body.data).slice(0, 140));
    check('盒信息带盒内件数', typeof (r4.body.data.box || {}).archives_count === 'number',
      String((r4.body.data.box || {}).archives_count));
  } else {
    check('演示数据里应有档案盒', false, '没有盒');
    check('盒信息带盒内件数', false, '没有盒');
  }

  const anyLoc = db.prepare('SELECT code FROM locations LIMIT 1').get();
  if (anyLoc && anyLoc.code) {
    const r5 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent(anyLoc.code));
    check('扫库位编号 → 认成库位', r5.body.data.kind === 'location', JSON.stringify(r5.body.data).slice(0, 140));
  } else {
    check('演示数据里应有库位', false, '没有库位');
  }

  const r6 = await admin.json('/api/scan/resolve?text=' + encodeURIComponent('NO-SUCH-CODE-' + TAG));
  check('扫不存在的编号 → 明确返回未识别', r6.body.data.kind === 'unknown', JSON.stringify(r6.body.data).slice(0, 140));
  check('未识别时给出原因', typeof r6.body.data.reason === 'string' && r6.body.data.reason.length > 0, r6.body.data.reason);
  const r7 = await admin.json('/api/scan/resolve?text=');
  check('空内容 → 未识别且说明内容为空', r7.body.data.kind === 'unknown' && /为空/.test(r7.body.data.reason || ''),
    JSON.stringify(r7.body.data));

  section('C. 密级：扫到无权档案时不能泄露「它存在」');
  if (secretRow && secretRow.archive_code && row && row.archive_code) {
    const readerName = TAG.toLowerCase() + '_rd';
    const mk = await admin.json('/api/users', {
      method: 'POST',
      json: { username: readerName, display_name: '扫码测试阅读者', password: 'Test@12345', role: 'reader' },
    });
    const reader = makeSession();
    await reader.json('/api/login', { method: 'POST', json: { username: readerName, password: 'Test@12345' } });
    await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
    const rd = await reader.json('/api/scan/resolve?text=' + encodeURIComponent(secretRow.archive_code));
    check('普通用户扫机密档案 → 按「未识别」回应（不是 403，不泄露存在性）',
      rd.status === 200 && rd.body.data.kind === 'unknown', JSON.stringify(rd.body.data).slice(0, 140));
    const rd2 = await reader.json('/api/scan/resolve?text=' + encodeURIComponent(row.archive_code));
    check('普通用户扫密级允许的档案 → 正常返回（对照）', rd2.body.data.kind === 'archive',
      JSON.stringify(rd2.body.data).slice(0, 140));
    if (mk.body.ok) {
      await admin.json('/api/users/' + mk.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
  } else {
    check('演示数据里有机密档案', false, '没有机密档案');
    check('演示数据里有内部级档案', false, '没有内部级档案');
    check('对照用例', false, '夹具缺失');
  }

  section('D. 回归：盘点扫码与工作台共用同一套解析');
  const mkCheck = await admin.json('/api/stock-checks', { method: 'POST', json: { scope: '全库盘点-' + TAG } });
  check('能新建盘点单', mkCheck.status === 200 && mkCheck.body.ok, JSON.stringify(mkCheck.body).slice(0, 140));
  const checkId = mkCheck.body.ok ? mkCheck.body.data.id : 0;
  if (checkId) {
    const before = (await admin.json('/api/stock-checks/' + checkId)).body.data;
    const beforeChecked = before.checked || 0;
    // 用「网址形态」扫：这正是扫码枪扫二维码时打进来的样子
    const sc1 = await admin.json('/api/stock-checks/' + checkId + '/scan', {
      method: 'POST',
      json: { codes: [`http://192.168.3.28:8787/api/a/${ac}?k=ZZZZZZZZZZZZ&i=1`] },
    });
    check('盘点接口接受网址形态的扫码内容（重构后仍兼容）', sc1.status === 200 && sc1.body.ok,
      JSON.stringify(sc1.body).slice(0, 200));
    // 进度字段就在盘点单这一行上（checked/missing/mislocated），不是 counts 对象
    const after = (await admin.json('/api/stock-checks/' + checkId)).body.data;
    check('盘点进度确实前进了（说明解析出了编号）',
      (after.checked || 0) > beforeChecked,
      `${beforeChecked} → ${after.checked || 0}`);
    const sc2 = await admin.json('/api/stock-checks/' + checkId + '/scan', { method: 'POST', json: { codes: [ac] } });
    check('纯编号形态同样可用', sc2.status === 200 && sc2.body.ok, JSON.stringify(sc2.body).slice(0, 160));
    await admin.json('/api/stock-checks/' + checkId + '/finish', { method: 'POST', json: {} });
  } else {
    check('盘点单创建成功（后续用例依赖）', false, '未拿到 id');
    check('盘点进度确实前进了（说明解析出了编号）', false, '未拿到 id');
    check('纯编号形态同样可用', false, '未拿到 id');
  }
  db.close();

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
