/**
 * 鉴定扩展（v4.10.0）验证 —— 密级鉴定 / 价值鉴定 / 开放鉴定
 *
 * 为什么必须分开测三种鉴定：它们的**触发条件、可选结论、有权决定的人**都不同。
 *   ① 价值鉴定  触发：保管期限届满        结论：延长保管期限 / 继续保管 / 建议销毁
 *   ② 密级鉴定  触发：保密期限届满        结论：解密 / 降低密级 / 延长保密期限 / 维持原密级
 *   ③ 开放鉴定  触发：自形成之日起满 25 年  结论：开放 / 部分开放 / 控制使用（延期开放）
 * 把三者合成一个"鉴定"按钮的后果是：涉密档案该不该解密、满 25 年的该不该开放，
 * 都变成"顺手点一下"，而这两件事都是有法定责任人要签字的。
 *
 * 本套件盯的关键点：
 *   - 保密期限能由「期限 + 定密日期」换算成届满日期；长期/条件解密**不得**编造届满日期；
 *   - **不替历史数据编造保密期限**（没登记就是没登记，靠体检催办，不靠程序猜）；
 *   - 解密要过定密权限（secadmin/admin），且解密后期限字段一并清空；
 *   - 「降低密级」必须是**真的更低**，方向反了要拒绝；
 *   - 先解密、后开放：仍是涉密状态的档案作"开放"结论必须被拒；
 *   - 控制使用必须写理由，延期开放必须给延期日期（《档案法》第二十八条）；
 *   - 鉴定批次**一件不成立就整批不落地**（半批鉴定的清册与实际结论对不上）；
 *   - 批次文据可打印，且密级过滤在明细与统计上都要生效（看不到的条目连数量都要如实说明）。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'AX' + Math.random().toString(16).slice(2, 8).toUpperCase();
const THIS_YEAR = new Date().getFullYear();
const TODAY = new Date().toISOString().slice(0, 10);

async function main() {
  const admin = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const leaf = flat.find((c) => c.level === 2 && String(c.code).startsWith('WS-'));
  check('拿到文书档案二级分类', !!leaf, leaf && leaf.code);
  if (!leaf) process.exit(1);

  section('枚举下发（前后端同一份词汇表）');
  const types = await admin.json('/api/types');
  check('开放状态取值域已下发', Array.isArray(types.body.data.openStates) && types.body.data.openStates.includes('控制使用'),
    JSON.stringify(types.body.data.openStates));
  check('三鉴类别已下发', JSON.stringify(types.body.data.appraisalKinds) === JSON.stringify(['价值鉴定', '密级鉴定', '开放鉴定']),
    JSON.stringify(types.body.data.appraisalKinds));
  check('密级鉴定的结论含「解密」', (types.body.data.appraisalDecisions['密级鉴定'] || []).includes('解密'));
  check('开放鉴定的结论含「控制使用」', (types.body.data.appraisalDecisions['开放鉴定'] || []).includes('控制使用'));
  check('公开年限为 25 年', types.body.data.openPublicYears === 25, String(types.body.data.openPublicYears));
  const kinds = await admin.json('/api/appraisals/kinds');
  check('鉴定枚举接口可用', kinds.status === 200 && kinds.body.data.kinds.length === 3, String(kinds.status));

  const createdIds = [];
  async function mk(title, extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({ type_code: 'WS', category_id: leaf.id, title, year: '2020' }, extra),
    });
    if (r.body && r.body.ok && r.body.data && r.body.data.id) createdIds.push(r.body.data.id);
    return r;
  }

  // =========================================================================
  section('一、定密登记（保密期限 → 届满日期）');
  // =========================================================================
  const A1 = await mk(`${TAG} 密级鉴定样本甲`);
  check('建出样本档案', A1.body.ok, JSON.stringify(A1.body).slice(0, 140));
  const a1 = A1.body.data.id;
  const before = await admin.json('/api/archives/' + a1);
  check('★ 新建档案不得凭空带出保密期限（系统不替定密责任人猜）',
    !before.body.data.secret_term && !before.body.data.secret_to,
    JSON.stringify({ t: before.body.data.secret_term, to: before.body.data.secret_to }));

  const noBasis = await admin.json(`/api/archives/${a1}/secret`, {
    method: 'POST', json: { secret_level: '秘密', secret_term: '5年', secret_from: '2020-01-01' },
  });
  check('涉密但不写定密依据被拒（400）', noBasis.status === 400, String(noBasis.status));
  check('拒绝原因点名了定密依据', /依据/.test(noBasis.body.error || ''), noBasis.body.error);

  const noTerm = await admin.json(`/api/archives/${a1}/secret`, {
    method: 'POST', json: { secret_level: '秘密', secret_basis: '本单位保密事项范围第 3 条' },
  });
  check('涉密但不写保密期限被拒（400）', noTerm.status === 400, String(noTerm.status));
  check('拒绝原因点名了保密期限', /保密期限/.test(noTerm.body.error || ''), noTerm.body.error);

  const badLevel = await admin.json(`/api/archives/${a1}/secret`, {
    method: 'POST', json: { secret_level: '绝密', secret_term: '5年', secret_basis: 'x' },
  });
  check('非法密级被拒（400）', badLevel.status === 400, String(badLevel.status));

  const contradiction = await admin.json(`/api/archives/${a1}/secret`, {
    method: 'POST',
    json: { secret_level: '秘密', secret_term: '长期', secret_to: '2030-01-01', secret_basis: '本单位保密事项范围第 3 条' },
  });
  check('「长期」却又给具体届满日期属自相矛盾，被拒（400）', contradiction.status === 400, String(contradiction.status));

  const setOk = await admin.json(`/api/archives/${a1}/secret`, {
    method: 'POST',
    json: {
      secret_level: '秘密', secret_term: '5年', secret_from: '2020-01-01',
      secret_basis: '本单位保密事项范围第 3 条', declassify_condition: '公开后不会造成损害',
    },
  });
  check('定密登记成功', setOk.status === 200 && setOk.body.ok, JSON.stringify(setOk.body).slice(0, 160));
  check('★ 保密期限「5年」按定密日期换算成届满日期 2025-01-01',
    setOk.body.data.secret_to === '2025-01-01', String(setOk.body.data.secret_to));
  check('解密条件已保存', setOk.body.data.declassify_condition === '公开后不会造成损害');

  const longTerm = await mk(`${TAG} 长期保密样本`);
  const ltSet = await admin.json(`/api/archives/${longTerm.body.data.id}/secret`, {
    method: 'POST', json: { secret_level: '机密', secret_term: '长期', secret_from: '2020-01-01', secret_basis: 'x' },
  });
  check('★「长期」不编造届满日期', ltSet.body.data.secret_to === '', JSON.stringify(ltSet.body.data.secret_to));

  const pubClear = await mk(`${TAG} 公开样本`);
  const pcSet = await admin.json(`/api/archives/${pubClear.body.data.id}/secret`, {
    method: 'POST', json: { secret_level: '公开', secret_term: '10年', secret_from: '2020-01-01' },
  });
  check('★ 公开件不保留保密期限（否则鉴定清单永远挂着它）',
    pcSet.body.data.secret_level === '公开' && pcSet.body.data.secret_term === '', JSON.stringify(pcSet.body.data));

  // =========================================================================
  section('二、密级鉴定的触发清单');
  // =========================================================================
  const wbS = await admin.json('/api/appraisals/workbench?kind=' + encodeURIComponent('密级鉴定'));
  check('密级鉴定工作台可用', wbS.status === 200 && wbS.body.ok, String(wbS.status));
  const rowA1 = (wbS.body.data.list || []).find((r) => r.id === a1);
  check('★ 保密期限已届满的样本出现在清单里', !!rowA1, JSON.stringify((wbS.body.data.list || []).length));
  check('★ 届满状态标记为 overdue', rowA1 && rowA1.due_state === 'overdue', rowA1 && rowA1.due_state);
  const rowLt = (wbS.body.data.list || []).find((r) => r.id === longTerm.body.data.id);
  check('★「长期」被标为「未登记届满日期」而不是「期限内」', rowLt && rowLt.due_state === 'noreg', rowLt && rowLt.due_state);
  check('公开件不出现在密级鉴定清单',
    !(wbS.body.data.list || []).some((r) => r.id === pubClear.body.data.id));
  check('统计里区分 已届满 / 即将届满 / 未登记期限',
    wbS.body.data.counts['密级鉴定'].overdue >= 1 && wbS.body.data.counts['密级鉴定'].noreg >= 1
    && typeof wbS.body.data.counts['密级鉴定'].soon === 'number',
    JSON.stringify(wbS.body.data.counts['密级鉴定']));

  // =========================================================================
  section('三、密级鉴定：解密 / 降低密级 / 延长 / 维持');
  // =========================================================================
  const clerk = makeSession();
  const clerkName = TAG.toLowerCase() + '_clk';
  const mkClerk = await admin.json('/api/users', {
    method: 'POST', json: { username: clerkName, display_name: '鉴定权限测试档案员', password: 'Test@12345', role: 'clerk' },
  });
  check('创建档案员账号', mkClerk.status === 200 && mkClerk.body.ok, JSON.stringify(mkClerk.body).slice(0, 140));
  await clerk.json('/api/login', { method: 'POST', json: { username: clerkName, password: 'Test@12345' } });
  await clerk.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出

  const secadmin = makeSession();
  const secName = TAG.toLowerCase() + '_sec';
  const mkSec = await admin.json('/api/users', {
    method: 'POST', json: { username: secName, display_name: '定密责任人', password: 'Test@12345', role: 'secadmin' },
  });
  check('创建系统安全保密员账号', mkSec.status === 200 && mkSec.body.ok, JSON.stringify(mkSec.body).slice(0, 160));
  await secadmin.json('/api/login', { method: 'POST', json: { username: secName, password: 'Test@12345' } });
  await secadmin.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出

  const clerkSecret = await clerk.json(`/api/archives/${a1}/secret`, {
    method: 'POST', json: { secret_level: '秘密', secret_term: '5年', secret_basis: 'x' },
  });
  check('★ 档案员不能定密（403）', clerkSecret.status === 403, String(clerkSecret.status));

  const clerkAppraise = await clerk.json(`/api/archives/${a1}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '解密', basis_ref: '《保守国家秘密法》第十九条' },
  });
  check('★ 档案员不能做密级鉴定（403）', clerkAppraise.status === 403, String(clerkAppraise.status));

  const noRef = await secadmin.json(`/api/archives/${a1}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '解密' },
  });
  check('密级鉴定不写依据条款被拒（400）', noRef.status === 400, String(noRef.status));
  check('拒绝原因点名了依据条款', /依据条款/.test(noRef.body.error || ''), noRef.body.error);

  const decrypt = await secadmin.json(`/api/archives/${a1}/appraise`, {
    method: 'POST',
    json: {
      kind: '密级鉴定', conclusion: '解密', basis_ref: '《保守国家秘密法》第十九条',
      basis: '保密期限已届满，经审核不再属于国家秘密事项', declassify_condition: '公开后不会造成损害',
    },
  });
  check('★ 定密责任人（安全保密员）解密成功', decrypt.status === 200 && decrypt.body.ok, JSON.stringify(decrypt.body).slice(0, 180));
  const a1After = await admin.json('/api/archives/' + a1);
  check('解密后密级为公开', a1After.body.data.secret_level === '公开', a1After.body.data.secret_level);
  check('★ 解密后保密期限与届满日期一并清空',
    a1After.body.data.secret_term === '' && a1After.body.data.secret_to === '',
    JSON.stringify({ t: a1After.body.data.secret_term, to: a1After.body.data.secret_to }));
  check('解密条件写回了档案', /损害/.test(a1After.body.data.declassify_condition || ''), a1After.body.data.declassify_condition);

  const A2 = await mk(`${TAG} 降密样本`);
  const a2 = A2.body.data.id;
  await admin.json(`/api/archives/${a2}/secret`, {
    method: 'POST', json: { secret_level: '机密', secret_term: '20年', secret_from: '2020-01-01', secret_basis: 'x' },
  });
  const down = await admin.json(`/api/archives/${a2}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '降低密级', new_secret_level: '秘密', basis_ref: '《保守国家秘密法》第二十条' },
  });
  check('降低密级 机密 → 秘密 成功', down.status === 200, JSON.stringify(down.body).slice(0, 160));
  check('密级已写回为秘密', (await admin.json('/api/archives/' + a2)).body.data.secret_level === '秘密');

  const up = await admin.json(`/api/archives/${a2}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '降低密级', new_secret_level: '机密', basis_ref: '《保守国家秘密法》第二十条' },
  });
  check('★「降低密级」方向反了（秘密→机密）被拒（400）', up.status === 400, String(up.status) + ' ' + (up.body.error || ''));
  check('拒绝原因说明该级并不更低', /并不更低/.test(up.body.error || ''), up.body.error);

  const keep = await admin.json(`/api/archives/${a2}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '维持原密级', basis_ref: '《国家秘密定密管理暂行规定》第十九条' },
  });
  check('维持原密级成功且密级不变',
    keep.status === 200 && (await admin.json('/api/archives/' + a2)).body.data.secret_level === '秘密');

  const extNo = await secadmin.json(`/api/archives/${longTerm.body.data.id}/appraise`, {
    method: 'POST', json: { kind: '密级鉴定', conclusion: '延长保密期限', basis_ref: '《保守国家秘密法》第二十条' },
  });
  check('延长保密期限但既无期限也无日期 → 400（不能拖到自然解密）', extNo.status === 400, String(extNo.status));

  const ext = await secadmin.json(`/api/archives/${longTerm.body.data.id}/appraise`, {
    method: 'POST',
    json: { kind: '密级鉴定', conclusion: '延长保密期限', new_secret_term: '10年', basis_ref: '《保守国家秘密法》第二十条' },
  });
  check('延长保密期限成功', ext.status === 200, JSON.stringify(ext.body).slice(0, 160));
  const ltAfter = (await admin.json('/api/archives/' + longTerm.body.data.id)).body.data;
  check('★ 新的届满日期 = 鉴定日 + 10 年', String(ltAfter.secret_to).slice(0, 4) === String(Number(TODAY.slice(0, 4)) + 10),
    ltAfter.secret_to);

  // =========================================================================
  section('四、开放鉴定：满 25 年 + 先解密后开放');
  // =========================================================================
  const oldPub = await mk(`${TAG} 满25年公开件`, { year: '2000' });
  const oldSec = await mk(`${TAG} 满25年涉密件`, { year: '2000' });
  const young = await mk(`${TAG} 未满25年件`, { year: String(THIS_YEAR - 3) });
  check('建出 2000 年（满 25 年）与近年档案', oldPub.body.ok && oldSec.body.ok && young.body.ok);
  const op = oldPub.body.data.id;
  const os = oldSec.body.data.id;
  const yg = young.body.data.id;
  await admin.json(`/api/archives/${os}/secret`, {
    method: 'POST', json: { secret_level: '秘密', secret_term: '长期', secret_from: '2000-01-01', secret_basis: 'x' },
  });

  const wbO = await admin.json('/api/appraisals/workbench?kind=' + encodeURIComponent('开放鉴定'));
  check('开放鉴定工作台可用', wbO.status === 200 && wbO.body.ok, String(wbO.status));
  check('★ 满 25 年的档案进入清单', (wbO.body.data.list || []).some((r) => r.id === op));
  check('★ 未满 25 年的档案不在清单', !(wbO.body.data.list || []).some((r) => r.id === yg));
  const rowOp = (wbO.body.data.list || []).find((r) => r.id === op);
  check('清单里算出「形成满 25 年」的年度', rowOp && rowOp.open_due_year === 2025, rowOp && rowOp.open_due_year);
  check('统计区分 待鉴定 / 已开放 / 部分开放 / 控制使用 / 未满 25 年',
    typeof wbO.body.data.counts['开放鉴定'].pending === 'number'
    && typeof wbO.body.data.counts['开放鉴定'].notYet === 'number'
    && wbO.body.data.counts['开放鉴定'].publicYears === 25,
    JSON.stringify(wbO.body.data.counts['开放鉴定']));

  const clerkOpen = await clerk.json(`/api/archives/${op}/appraise`, {
    method: 'POST', json: { kind: '开放鉴定', conclusion: '开放', basis_ref: '《档案法》第二十七条' },
  });
  check('★ 档案员不能做开放鉴定（403，开放与否由馆领导批准）', clerkOpen.status === 403, String(clerkOpen.status));

  const openStillSecret = await secadmin.json(`/api/archives/${os}/appraise`, {
    method: 'POST', json: { kind: '开放鉴定', conclusion: '开放', basis_ref: '《档案法》第二十七条' },
  });
  check('★★ 仍是涉密状态的档案不能作出「开放」结论（必须先解密）',
    openStillSecret.status === 400, String(openStillSecret.status) + ' ' + (openStillSecret.body.error || ''));
  check('拒绝原因说明了要先完成密级鉴定', /密级鉴定/.test(openStillSecret.body.error || ''), openStillSecret.body.error);

  const ctrlNoReason = await secadmin.json(`/api/archives/${os}/appraise`, {
    method: 'POST', json: { kind: '开放鉴定', conclusion: '控制使用', basis_ref: '《档案法》第二十八条' },
  });
  check('控制使用不写理由被拒（400）', ctrlNoReason.status === 400, String(ctrlNoReason.status));

  const ctrlNoDate = await secadmin.json(`/api/archives/${os}/appraise`, {
    method: 'POST',
    json: { kind: '开放鉴定', conclusion: '控制使用', control_reason: '涉及个人隐私', basis_ref: '《档案法》第二十八条' },
  });
  check('★ 控制使用不给延期日期被拒（400，第二十八条要求明确延期期限）', ctrlNoDate.status === 400, String(ctrlNoDate.status));

  const ctrl = await secadmin.json(`/api/archives/${os}/appraise`, {
    method: 'POST',
    json: {
      kind: '开放鉴定', conclusion: '控制使用', control_reason: '涉及个人隐私，按控制使用范围规定第七条',
      open_delay_to: `${THIS_YEAR + 10}-12-31`, basis_ref: '《档案法》第二十八条',
    },
  });
  check('控制使用（延期开放）成功', ctrl.status === 200, JSON.stringify(ctrl.body).slice(0, 160));
  const osAfter = (await admin.json('/api/archives/' + os)).body.data;
  check('开放状态写回为控制使用', osAfter.open_state === '控制使用', osAfter.open_state);
  check('控制使用理由与延期日期都写回', /隐私/.test(osAfter.open_control_reason || '') && osAfter.open_delay_to === `${THIS_YEAR + 10}-12-31`,
    JSON.stringify({ r: osAfter.open_control_reason, d: osAfter.open_delay_to }));
  check('开放鉴定日期已记录', osAfter.open_review_at === TODAY, osAfter.open_review_at);

  const partial = await secadmin.json(`/api/archives/${op}/appraise`, {
    method: 'POST',
    json: {
      kind: '开放鉴定', conclusion: '部分开放', control_reason: '正文开放，附表涉及个人隐私',
      open_scope_note: '正文开放，附表与名单控制使用', basis_ref: '《档案法》第二十七条、第二十八条',
    },
  });
  check('部分开放成功', partial.status === 200 && (await admin.json('/api/archives/' + op)).body.data.open_state === '部分开放');

  // =========================================================================
  section('五、价值鉴定（原有能力在扩展后仍成立）');
  // =========================================================================
  const A3 = await mk(`${TAG} 到期样本`, { year: '2015', retention: '定期5年' });
  const a3 = A3.body.data.id;
  const a3Row0 = (await admin.json('/api/archives/' + a3)).body.data;
  check('★ 到期年度按归档年度起算（2015 + 5 = 2020，而不是"今年 + 5"）',
    Number(a3Row0.retention_due_year) === 2020, JSON.stringify(a3Row0.retention_due_year));

  const wbV = await admin.json('/api/appraisals/workbench?kind=' + encodeURIComponent('价值鉴定'));
  check('价值鉴定工作台可用且含到期样本',
    wbV.status === 200 && (wbV.body.data.list || []).some((r) => r.id === a3), String(wbV.status));
  check('价值鉴定统计含 已过期 / 今年到期 / 明年到期 / 永久',
    ['overdue', 'thisYear', 'nextYear', 'permanent'].every((k) => typeof wbV.body.data.counts['价值鉴定'][k] === 'number'),
    JSON.stringify(wbV.body.data.counts['价值鉴定']));

  const badDecision = await admin.json(`/api/archives/${a3}/appraise`, {
    method: 'POST', json: { kind: '价值鉴定', conclusion: '随便销毁' },
  });
  check('价值鉴定非法结论被拒（400）', badDecision.status === 400, String(badDecision.status));

  const ext2 = await admin.json(`/api/archives/${a3}/appraise`, {
    method: 'POST', json: { kind: '价值鉴定', conclusion: '延长保管期限', new_retention: '定期30年', basis: '仍有查考利用价值' },
  });
  check('延长保管期限成功', ext2.status === 200, JSON.stringify(ext2.body).slice(0, 160));
  const a3After = (await admin.json('/api/archives/' + a3)).body.data;
  check('保管期限与到期年度已重算',
    a3After.retention === '定期30年' && Number(a3After.retention_due_year) === 2045,
    JSON.stringify({ r: a3After.retention, y: a3After.retention_due_year }));

  // =========================================================================
  section('六、鉴定批次（意见书 + 清册）');
  // =========================================================================
  const dueIds = [];
  for (let i = 0; i < 3; i++) {
    const r = await mk(`${TAG} 批次样本${i + 1}`, { year: '2014', retention: '定期5年' });
    dueIds.push(r.body.data.id);
  }
  const batchesBefore = (await admin.json('/api/appraisal/batches')).body.data.total;

  const noIds = await admin.json('/api/appraisal/batches', {
    method: 'POST', json: { kind: '价值鉴定', archive_ids: [] },
  });
  check('不选档案被拒（400）', noIds.status === 400, String(noIds.status));

  const badBatch = await admin.json('/api/appraisal/batches', {
    method: 'POST', json: { kind: '价值鉴定', archive_ids: dueIds, conclusion: '全部烧掉' },
  });
  check('批次结论非法被拒（400）', badBatch.status === 400, String(badBatch.status));
  check('★ 失败的批次不留残骸（台账条数不变）',
    (await admin.json('/api/appraisal/batches')).body.data.total === batchesBefore);

  const batch = await admin.json('/api/appraisal/batches', {
    method: 'POST',
    json: {
      kind: '价值鉴定', archive_ids: dueIds, conclusion: '继续保管',
      title: `${TAG} 2020 年到期鉴定`, scope_note: '2014 年文书档案',
      basis: '仍有查考利用价值', basis_ref: '国家档案局令第 8 号附件',
      group_opinion: '经鉴定小组讨论，一致同意继续保管', members: '张三、李四、王五', member_count: 3,
      meeting_date: TODAY, organizer: '档案室', approver: '馆领导', approved_at: TODAY,
    },
  });
  check('组织鉴定成功', batch.status === 200 && batch.body.ok, JSON.stringify(batch.body).slice(0, 200));
  check('★ 批次号格式为 JD + 年月 + 序号', /^JD\d{6}-\d{3}$/.test(batch.body.data.batch_no || ''), batch.body.data.batch_no);
  check('★ 结论分布摘要正确（继续保管 3 件）', /继续保管 3 件/.test(batch.body.data.summary || ''), batch.body.data.summary);
  check('返回登记表打印地址', /appraisal\/batches\/\d+\/print/.test(batch.body.data.print_url || ''), batch.body.data.print_url);
  const bid = batch.body.data.batch_id;

  const ledger = await admin.json('/api/appraisal/batches');
  check('批次台账可查', ledger.status === 200 && (ledger.body.data.list || []).some((b) => b.id === bid));
  const bRow = (ledger.body.data.list || []).find((b) => b.id === bid);
  check('台账里带件数与结论分布', bRow && bRow.item_count === 3 && /继续保管/.test(bRow.summary || ''),
    JSON.stringify({ n: bRow && bRow.item_count, s: bRow && bRow.summary }));

  const detail = await admin.json('/api/appraisal/batches/' + bid);
  check('批次明细可查', detail.status === 200 && detail.body.data.items.length === 3, String(detail.status));
  check('★ 明细里带鉴定前快照（清册要写前后对照）',
    detail.body.data.items.every((p) => { try { return !!JSON.parse(p.before_state).retention; } catch (_) { return false; } }),
    JSON.stringify((detail.body.data.items[0] || {}).before_state));
  check('明细里记了鉴定人与批次号', detail.body.data.items.every((p) => p.appraiser_name && p.batch_id === bid));

  const printRes = await admin.req(`/api/appraisal/batches/${bid}/print`);
  const printHtml = await printRes.text();
  check('批次文据可打印', printRes.status === 200, String(printRes.status));
  check('★ 打印页含《档案鉴定意见书》', /档 案 鉴 定 意 见 书/.test(printHtml));
  check('★ 打印页含《档案鉴定清册》', /档 案 鉴 定 清 册/.test(printHtml));
  check('打印页写了鉴定依据与条款', /国家档案局令第 8 号/.test(printHtml));
  check('打印页列了逐件前后对照（原保管期限）', /原保管期限/.test(printHtml));
  check('打印页有鉴定小组与审核人签署栏', /鉴定小组负责人/.test(printHtml) && /审核人/.test(printHtml));

  // 一件不成立 → 整批不落地
  const withLoanTarget = await mk(`${TAG} 半批样本`, { year: '2014', retention: '定期5年' });
  const batchesBefore2 = (await admin.json('/api/appraisal/batches')).body.data.total;
  const halfFail = await admin.json('/api/appraisal/batches', {
    method: 'POST',
    json: {
      kind: '密级鉴定', archive_ids: [withLoanTarget.body.data.id],
      conclusion: '降低密级', new_secret_level: '内部', basis_ref: '《保守国家秘密法》第二十条',
    },
  });
  check('批内有一件不成立时整批失败（400）', halfFail.status === 400, String(halfFail.status));
  check('★ 整批不落地：台账条数没变', (await admin.json('/api/appraisal/batches')).body.data.total === batchesBefore2);
  check('★ 失败批次不留下孤立的鉴定记录',
    (await admin.json('/api/archives/' + withLoanTarget.body.data.id)).body.data.appraisals.length === 0);

  // =========================================================================
  section('七、密级过滤：清单、统计、批次明细都要过滤');
  // =========================================================================
  const secretBatchTarget = await mk(`${TAG} 批次用机密件`, { year: '2014', retention: '定期5年' });
  await admin.json(`/api/archives/${secretBatchTarget.body.data.id}/secret`, {
    method: 'POST', json: { secret_level: '机密', secret_term: '长期', secret_from: '2020-01-01', secret_basis: 'x' },
  });
  const mixed = await admin.json('/api/appraisal/batches', {
    method: 'POST',
    json: {
      kind: '价值鉴定', archive_ids: [secretBatchTarget.body.data.id], conclusion: '继续保管',
      basis: '混密级批次', basis_ref: '国家档案局令第 8 号',
    },
  });
  check('管理员可建含机密件的批次', mixed.status === 200, String(mixed.status));
  const mixedId = mixed.body.data.batch_id;

  const clkDetail = await clerk.json('/api/appraisal/batches/' + mixedId);
  check('★ 档案员看该批次明细时看不到机密件', clkDetail.body.data.items.length === 0, String(clkDetail.body.data.items.length));
  check('★ 但如实报出「有几件你看不到」，不假装批次只有 0 件',
    clkDetail.body.data.hidden === 1, JSON.stringify({ v: clkDetail.body.data.visible, h: clkDetail.body.data.hidden }));
  const clkPrint = await clerk.req(`/api/appraisal/batches/${mixedId}/print`);
  const clkHtml = await clkPrint.text();
  check('★ 打印页也不泄露涉密件的档号与题名',
    !clkHtml.includes(secretBatchTarget.body.data.archive_code), '打印页出现越密级档号');
  check('打印页如实说明有多少件超出密级权限未列入', /超出你的密级权限/.test(clkHtml));

  // =========================================================================
  section('八、密级改动的权限口子全部堵住');
  // =========================================================================
  const viaUpdate = await clerk.json('/api/archives/' + a3, {
    method: 'PUT', json: { title: `${TAG} 档案员改题名`, secret_level: '机密' },
  });
  check('★ 档案员通过修改档案改密级被拒（403）', viaUpdate.status === 403, String(viaUpdate.status));
  const viaUpdateOk = await clerk.json('/api/archives/' + a3, {
    method: 'PUT', json: { title: `${TAG} 档案员改题名（不动密级）` },
  });
  check('档案员不改密级时仍可正常修改档案', viaUpdateOk.status === 200, String(viaUpdateOk.status));

  const viaMeta = await clerk.json(`/api/archives/${a3}/metadata`, {
    method: 'PUT', json: { values: { M11: '机密' } },
  });
  const metaRej = (viaMeta.body.data && viaMeta.body.data.rejected) || [];
  check('★ 档案员通过元数据接口（M11 密级）改密级被拒',
    viaMeta.status === 200 && metaRej.some((r) => /密级/.test(r.reason || '')),
    JSON.stringify(metaRej).slice(0, 160));

  const viaBulk = await clerk.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [a3], changes: { secret_level: '机密' } },
  });
  check('★ 档案员通过批量修改改密级被拒（403）', viaBulk.status === 403, String(viaBulk.status));
  const viaBulkAdmin = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [a3], changes: { secret_level: '内部' } },
  });
  check('★ 管理员（定密责任人）可以批量改密级', viaBulkAdmin.status === 200 && viaBulkAdmin.body.data.changed === 1,
    JSON.stringify(viaBulkAdmin.body).slice(0, 160));
  check('批量改密级已生效', (await admin.json('/api/archives/' + a3)).body.data.secret_level === '内部');
  const bulkLogs = await admin.json('/api/logs?size=50');
  check('★ 批量变更密级单独进安全类审计日志',
    ((bulkLogs.body.data.list || [])).some((l) => /批量变更密级/.test(l.action || '')),
    ((bulkLogs.body.data.list || [])).slice(0, 5).map((l) => l.action).join(','));
  const viaBulkPub = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [a3], changes: { secret_level: '公开' } },
  });
  check('批量改为公开成功', viaBulkPub.status === 200, String(viaBulkPub.status));
  const a3Pub = (await admin.json('/api/archives/' + a3)).body.data;
  check('★ 批量改为公开时保密期限一并清空', a3Pub.secret_level === '公开' && a3Pub.secret_term === '',
    JSON.stringify({ l: a3Pub.secret_level, t: a3Pub.secret_term }));
  const bulkOther = await clerk.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [a3], changes: { department: TAG + '部门' } },
  });
  check('批量修改其他字段仍正常可用', bulkOther.status === 200 && bulkOther.body.data.changed === 1,
    JSON.stringify(bulkOther.body).slice(0, 120));

  // =========================================================================
  section('九、体检与审计');
  // =========================================================================
  const scan = await admin.json('/api/quality/scan');
  check('体检接口可用', scan.status === 200 && Array.isArray(scan.body.data.problems), String(scan.status));
  const types2 = (scan.body.data.problems || []).map((p) => p.type);
  check('体检含「涉密档案未登记保密期限」', types2.includes('secret_no_term'), types2.join(','));
  check('体检含「保密期限届满未鉴定」', types2.includes('secret_due'), types2.join(','));
  check('体检含「满 25 年未做开放鉴定」', types2.includes('open_pending'), types2.join(','));
  const noTermProblem = (scan.body.data.problems || []).find((p) => p.type === 'secret_no_term');
  check('未登记期限的提示说清了"由定密责任人补录"', /定密责任人/.test(noTermProblem.hint || ''), noTermProblem.hint);
  const openProblem = (scan.body.data.problems || []).find((p) => p.type === 'open_pending');
  check('开放鉴定提示引用了《档案法》第二十七条', /第二十七条/.test(openProblem.hint || ''), openProblem.hint);

  const logs = await admin.json('/api/logs?size=300');
  const acts = ((logs.body.data && logs.body.data.list) || []).map((l) => l.action);
  check('★ 定密登记进审计日志', acts.some((a) => /定密登记/.test(a)), acts.slice(0, 6).join(','));
  check('★ 档案鉴定进审计日志', acts.some((a) => /档案鉴定/.test(a)), acts.slice(0, 6).join(','));
  check('★ 组织鉴定进审计日志', acts.some((a) => /组织鉴定/.test(a)), acts.slice(0, 6).join(','));
  const chain = await admin.json('/api/logs/verify');
  check('审计链仍完整', chain.status === 200 && chain.body.data.ok === true, JSON.stringify(chain.body.data || {}).slice(0, 140));

  const dA1 = await admin.json('/api/archives/' + a1);
  check('★ 档案详情直接带出鉴定历史', Array.isArray(dA1.body.data.appraisals) && dA1.body.data.appraisals.length >= 1,
    JSON.stringify((dA1.body.data.appraisals || []).length));
  const histRow = (dA1.body.data.appraisals || [])[0] || {};
  check('鉴定历史带类别与依据条款', histRow.kind === '密级鉴定' && !!histRow.basis_ref,
    JSON.stringify({ k: histRow.kind, r: histRow.basis_ref }));

  // =========================================================================
  section('十、收尾');
  // =========================================================================
  for (const id of createdIds) await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  if (mkClerk.body.ok) await admin.json('/api/users/' + mkClerk.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  if (mkSec.body.ok) await admin.json('/api/users/' + mkSec.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const left = await admin.json('/api/archives?kw=' + encodeURIComponent(TAG) + '&size=100');
  check('清理：没有残留测试档案', (left.body.data.list || []).length === 0,
    String((left.body.data.list || []).length));

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
