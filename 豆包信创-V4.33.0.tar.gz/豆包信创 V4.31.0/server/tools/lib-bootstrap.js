/**
 * 回归测试专用：完成"首次强制改密"（千问版 v4.30.6）
 *
 * 为什么需要它：v4.30.6 起服务端对 must_change=1 的账号强制改密 ——
 * 除 /api/me、/api/me/password、/api/logout 外一律 403。这是**正确的安全行为**，
 * 但全部既有自测脚本都假定"出厂账号 admin/admin123、新建账号可直接调接口"。
 * 与其削弱门禁去迁就测试，不如让测试夹具自己把首改这一步走完。
 *
 * 用法（登录成功后立刻调）：
 *   const { completeFirstChange } = require('./lib-bootstrap');
 *   const pw = await completeFirstChange(adminSession, 'admin123');
 *   // 之后该会话的口令就是 pw（若本来就不需要改密，原样返回 'admin123'）
 *
 * 新建账号同理：建号 → 登录 → completeFirstChange → 用返回的口令继续。
 * 本模块只调真实接口，不碰库文件，不构成任何生产后门。
 */
'use strict';

/** 符合默认口令策略的强口令（长度≥8、含大小写/数字/符号、不在弱口令清单） */
const BOOTSTRAP_PW = 'Bootstrap@2026a';

/**
 * 若当前账号仍标记 must_change，则完成改密并返回新口令；否则返回原口令。
 * @param {{json:Function}} session 已登录的会话
 * @param {string} currentPw 当前口令
 * @returns {Promise<string>} 之后应使用的口令
 */
async function completeFirstChange(session, currentPw) {
  const me = await session.json('/api/me');
  const u = me.body && me.body.data && me.body.data.user;
  if (!u || Number(u.must_change) !== 1) return currentPw;
  const r = await session.json('/api/me/password', {
    method: 'POST',
    json: { oldPassword: currentPw, newPassword: BOOTSTRAP_PW },
  });
  if (!r.body || !r.body.ok) {
    throw new Error('测试夹具完成首次改密失败：' + JSON.stringify(r.body).slice(0, 200));
  }
  return BOOTSTRAP_PW;
}

module.exports = { completeFirstChange, BOOTSTRAP_PW };