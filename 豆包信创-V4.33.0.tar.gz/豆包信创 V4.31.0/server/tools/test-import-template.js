/**
 * 批量导入模板（v4.14.0）验证 —— 无需启动服务
 *
 * 这一套件盯的不是"能不能导入"（那是 selftest-v2 的活），而是
 * **模板本身有没有说谎**：
 *
 *   ① 表头和示例行列数一致 —— 老版本正是错在这里：示例行少写了两个空值，
 *      从「页数」往后的值整排前移，用户导入模板自带的示例会得到
 *      「页数=纸质、责任者=通知标题」这种脏数据，而且**一条错误都不报**；
 *   ② 模板里出现的每一列，导入引擎都认（列定义与 HEADER_MAP 不许漂移）；
 *   ③ 必填标记 `*` 只标在真正必填的列上，且带 `*` 的表头仍能识别；
 *   ④ 模板末尾的 `#` 填写说明**不算数据行、不产生错误** ——
 *      老版本把说明当数据行，"导入系统自带的模板"会报一串"题名不能为空"。
 *
 * 用法：node server/tools/test-import-template.js
 */
'use strict';

const path = require('node:path');
const importer = require(path.join(__dirname, '..', 'lib', 'importer.js'));

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

const simple = importer.buildTemplateCsv('simple');
const full = importer.buildTemplateCsv('full');
const simpleRows = importer.parseCsv(simple);
const fullRows = importer.parseCsv(full);

// ---------------------------------------------------------------- 1
section('1. 两套模板的列数');
check('默认模板是精简版（9 列）', simpleRows[0].length === 9, '实际 ' + simpleRows[0].length + ' 列');
check('全字段模板（33 列）', fullRows[0].length === 33, '实际 ' + fullRows[0].length + ' 列');
check('精简版是全字段版的子集',
  simpleRows[0].every((h) => fullRows[0].includes(h)),
  simpleRows[0].filter((h) => !fullRows[0].includes(h)).join(','));
check('列定义表没有重复表头',
  new Set(importer.TEMPLATE_COLUMNS.map((c) => c[0])).size === importer.TEMPLATE_COLUMNS.length);

// ---------------------------------------------------------------- 2
section('2. 必填标记');
const simpleRequired = simpleRows[0].filter((h) => /\*$/.test(h));
const fullRequired = fullRows[0].filter((h) => /\*$/.test(h));
check('精简版只标 3 个必填',
  simpleRequired.length === 3 && /门类代码\*/.test(simpleRequired[0]) && /题名\*/.test(simpleRequired[1]) && /分类\*/.test(simpleRequired[2]),
  simpleRequired.join(','));
check('两套模板的必填列一致', simpleRequired.join(',') === fullRequired.join(','), fullRequired.join(','));
check('必填标记与列定义 required 一一对应',
  importer.TEMPLATE_COLUMNS.filter((c) => c[2]).map((c) => c[0]).join(',') === '门类代码,题名,分类');

// ---------------------------------------------------------------- 3
section('3. 表头与示例行不许错位（老版本的真 bug）');
check('精简版每行列数一致', simpleRows.every((r) => r.length === simpleRows[0].length),
  simpleRows.map((r) => r.length).join(','));
check('全字段版每行列数一致', fullRows.every((r) => r.length === fullRows[0].length),
  fullRows.map((r) => r.length).join(','));
{
  // 按字段名取值，逐列核对示例值落位
  const cols = importer.TEMPLATE_COLUMNS.map((c) => c[0] + (c[2] ? '*' : ''));
  const iOf = (h) => fullRows[0].indexOf(h);
  const ex1 = fullRows[1];
  check('示例：页数=3（老版本这里是"纸质"）', ex1[iOf('页数')] === '3', JSON.stringify(ex1[iOf('页数')]));
  check('示例：份数=2（老版本这里是部门名）', ex1[iOf('份数')] === '2', JSON.stringify(ex1[iOf('份数')]));
  check('示例：载体形式=纸质（老版本这里是"综合科"）', ex1[iOf('载体形式')] === '纸质', JSON.stringify(ex1[iOf('载体形式')]));
  check('示例：责任者=本单位办公室（老版本这里是通知标题）', ex1[iOf('责任者')] === '本单位办公室', JSON.stringify(ex1[iOf('责任者')]));
  check('示例：所属部门=综合科', ex1[iOf('所属部门')] === '综合科', JSON.stringify(ex1[iOf('所属部门')]));
  check('示例：存放位置=A库-A1-2（老版本这里是"在库"）', ex1[iOf('存放位置')] === 'A库-A1-2', JSON.stringify(ex1[iOf('存放位置')]));
  check('示例：状态=在库（老版本这里是"未鉴定"）', ex1[iOf('状态')] === '在库', JSON.stringify(ex1[iOf('状态')]));
  check('示例：开放状态=未鉴定', ex1[iOf('开放状态')] === '未鉴定', JSON.stringify(ex1[iOf('开放状态')]));
  check('示例：密级=公开（不留无期限的密级，免得一导入就上体检清单）', ex1[iOf('密级')] === '公开', JSON.stringify(ex1[iOf('密级')]));
  check('示例：秘密那行带保密期限 10年', fullRows[2][iOf('保密期限')] === '10年', JSON.stringify(fullRows[2][iOf('保密期限')]));
  check('示例行数与列数无关的额外列全为空（未超范围赋值）',
    cols.length === ex1.length);
}

// ---------------------------------------------------------------- 4
section('4. 模板里的列，导入引擎必须都认');
{
  const known = new Set(Object.values(importer.HEADER_MAP));
  const orphan = importer.TEMPLATE_COLUMNS.filter((c) => !known.has(c[1])).map((c) => c[0] + '→' + c[1]);
  check('列定义的字段名都在 HEADER_MAP 中', orphan.length === 0, orphan.join(','));
  // 反向：HEADER_MAP 认得但没有进模板的字段（如英文别名）不该是"忘了加列"，
  // 这里只列出数量，供人工核对；真正要防的是上面那个方向。
  check('中文表头可直接被识别（无别名歧义）',
    importer.TEMPLATE_COLUMNS.every((c) => importer.HEADER_MAP[c[0]] === c[1]),
    importer.TEMPLATE_COLUMNS.filter((c) => importer.HEADER_MAP[c[0]] !== c[1]).map((c) => c[0]).join(','));
  check('说明里不出现"必填"字样之外的错误提示',
    importer.buildTemplateNotes('simple').join('\n').includes('必填列只有 3 列'));
}

// ---------------------------------------------------------------- 5
section('5. 表头识别：带 * / （必填） 也要认');
{
  const r1 = importer.mapHeaders(['门类代码*', '题名*', '分类*']);
  check('题名* → title', r1.map.get('title') === 1);
  check('门类代码* → type_code', r1.map.get('type_code') === 0);
  check('带 * 的表头不产生"未识别列"', r1.unknown.length === 0, r1.unknown.join(','));
  const r2 = importer.mapHeaders(['题名（必填）', '分类(必填)', '题名']);
  check('题名（必填） → title', r2.map.get('title') === 0);
  check('分类(必填) → category_path', r2.map.get('category_path') === 1);
  const r3 = importer.mapHeaders(['题名*', '责任者', '说明']);
  check('「说明」列被忽略且不报未识别', r3.unknown.length === 0, r3.unknown.join(','));
}

// ---------------------------------------------------------------- 6
section('6. 注释行与空行不算数据行（模板自带说明不许变成错误）');
{
  // 桩 q：本套件只关心"行怎么数"，不关心档号生成，所以让表为空即可
  const stubQ = {
    all: () => [],
    get: () => null,
    scalar: () => null,
    run: () => {},
    tx: (fn) => fn(),
  };
  const deps = {
    q: stubQ,
    numbering: {
      nextNumber: () => ({ archive_code: 'X-1', archive_number: 'N-1' }),
      previewNumber: () => ({ archive_number: 'N-1' }),
      getSetting: (q, k, d) => d,
    },
  };
  const header = simpleRows[0].join(',');

  const notesOnly = header + '\r\n' + importer.buildTemplateNotes('simple').map((l) => l).join('\r\n') + '\r\n';
  let r = importer.runImport(deps, notesOnly, {});
  check('只有表头+说明 → 数据行 0', r.total === 0, 'total=' + r.total);
  check('只有表头+说明 → 0 成功 0 失败', r.succeeded === 0 && r.failed === 0,
    JSON.stringify({ s: r.succeeded, f: r.failed }));

  // 模板原样导入：2 行示例会被算作数据行（门类桩库为空 → 必然失败，但绝不是"说明行失败"）
  r = importer.runImport(deps, importer.buildTemplateCsv('simple') + importer.buildTemplateNotes('simple').join('\r\n'), {});
  check('模板原样导入 → 数据行恰好 2（说明行不计数）', r.total === 2, 'total=' + r.total);
  check('报错行号不超过数据行范围（说明行没被当数据行）',
    r.errors.every((e) => e.line >= 2 && e.line <= 3),
    JSON.stringify(r.errors.map((e) => e.line)));

  const withBlank = header + '\r\n\r\n' + 'WS,甲,文书档案/行政管理\r\n' + '\r\n';
  r = importer.runImport(deps, withBlank, {});
  check('空行跳过（不报"题名不能为空"）', r.total === 1 && !r.errors.some((e) => /题名/.test(e.message)),
    'total=' + r.total + ' errors=' + JSON.stringify(r.errors));

  const midComment = header + '\r\n# 这是中间插的一行注释\r\nWS,乙,文书档案/行政管理\r\n';
  r = importer.runImport(deps, midComment, {});
  check('中间插的注释行也跳过', r.total === 1, 'total=' + r.total);
}

console.log('\n' + '='.repeat(60));
console.log(`批量导入模板检查：通过 ${pass} 项，失败 ${failed} 项`);
if (failed) fails.forEach((f) => console.log('  - ' + f));
console.log('='.repeat(60));
process.exit(failed ? 1 : 0);
