/**
 * 四性检测回归测试
 *
 * 用法：node server/tools/test-detection.js [http://127.0.0.1:8796] [数据目录]
 *
 * 覆盖（DA/T 70—2018 三环节×四性框架；DA/T 92—2022 §9.4；
 *       《电子档案管理办法》第十八/二十一/二十二/二十八条）：
 *   1. 检测项框架：三个管理环节 × 真实性/完整性/可用性/安全性
 *   2. 归档环节检测可执行、结论与逐项结果可追溯
 *   3. **真实不合格检出**：缺必备著录项、附件摘要不符（篡改实体文件）、非开放加密封装
 *   4. 上传附件自动触发归档检测
 *   5. 长期保存环节检测（含"距上次检测未超一年"）
 *   6. 移交闸门：未检测不得提交移交；补检测后可提交
 *   7. 覆盖率统计与超期清单
 *   8. 打印报告（含逐项结果与责任人确认栏）
 *   9. 权限与密级隔离
 *
 * 脚本结束时还原被篡改的文件、删除测试数据，可重复运行。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'archive.db');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function raw(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text() };
  }
  return { req, json, raw };
}

function multipart(files, fields = {}) {
  const boundary = '----det' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const TAG = 'DET' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [], transfers: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);
  const cats = (await admin.json('/api/categories')).body.data.flat;
  const cat = cats.find((c) => c.code === 'WS-XZ') || cats[0];

  async function makeArchive(extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({
        type_code: 'WS', category_id: cat.id, title: `${TAG} 检测样本`, secret_level: '公开',
        retention: '定期10年', year: '2026', archive_date: '2026-01-01',
      }, extra),
    });
    if (r.body.ok) created.archives.push(r.body.data.id);
    return r.body.ok ? r.body.data : null;
  }

  // ---------- 1. 框架 ----------
  section('检测项框架（三环节 × 四性）');
  const st = await admin.json('/api/detections/stats');
  const sd = st.body.data || {};
  check('统计接口返回检查项清单', Array.isArray(sd.checks) && sd.checks.length > 0, String((sd.checks || []).length));
  const envs = (sd.environments || []).map((e) => e.code).sort().join(',');
  check('覆盖三个管理环节（归档/移交接收/长期保存）', envs === 'archive,preservation,transfer', envs);
  const dims = [...new Set((sd.checks || []).map((c) => c.dimension))].sort();
  check('覆盖四性（真实性/完整性/可用性/安全性）', dims.length === 4, dims.join(','));
  check('每个检查项都标注了标准依据', (sd.checks || []).every((c) => !!c.basis),
    JSON.stringify((sd.checks || []).filter((c) => !c.basis).map((c) => c.code)));
  check('检查项声明了适用环节', (sd.checks || []).every((c) => Array.isArray(c.environments) && c.environments.length));
  check('检查项区分不合格（error）与提示（warn）',
    (sd.checks || []).some((c) => c.severity === 'error') && (sd.checks || []).some((c) => c.severity === 'warn'));

  // ---------- 2. 归档环节检测 ----------
  section('归档环节检测');
  const a1 = await makeArchive({ responsible: '办公室', title: `${TAG} 合规样本` });
  check('夹具档案创建成功', !!a1, JSON.stringify(a1).slice(0, 120));
  // 上传一个可提取正文的附件（顺便验证自动检测）
  const mp = multipart([{ filename: 'note.txt', data: `${TAG} 正文内容` }]);
  const up = await admin.json(`/api/archives/${a1.id}/files`, {
    method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body,
  });
  check('附件上传成功', up.body.ok, JSON.stringify(up.body).slice(0, 140));

  const det = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a1.id, environment: 'archive' },
  });
  check('执行归档环节检测成功', det.status === 200 && det.body.data.summary.archives === 1,
    JSON.stringify(det.body).slice(0, 160));
  const r0 = (det.body.data.results || [])[0] || {};
  check('返回检测单号', /^JC\d{8}-\d{3}$/.test(r0.detection_no || ''), String(r0.detection_no));
  check('返回合格结论', typeof r0.qualified === 'boolean' && /合格|不合格/.test(r0.conclusion || ''),
    String(r0.conclusion));
  check('返回逐项结果', Array.isArray(r0.result && r0.result.items) && r0.result.items.length > 0,
    String((r0.result && r0.result.items || []).length));
  check('归档环节覆盖四性',
    new Set((r0.result.items || []).map((i) => i.dimension)).size === 4,
    [...new Set((r0.result.items || []).map((i) => i.dimension))].join(','));

  const d1 = await admin.json(`/api/detections/${r0.id}`);
  check('检测记录可查询（含逐项明细）', d1.status === 200 && d1.body.data.detection.items.length > 0,
    JSON.stringify(d1.body).slice(0, 140));
  check('明细项带维度/严重程度/依据/说明',
    d1.body.data.detection.items.every((i) => i.dimension && i.severity && i.title && 'pass' in i && i.detail !== undefined),
    JSON.stringify(d1.body.data.detection.items[0] || {}));
  check('明细按四性顺序排列',
    (() => {
      const order = ['真实性', '完整性', '可用性', '安全性'];
      const seq = d1.body.data.detection.items.map((i) => order.indexOf(i.dimension));
      return seq.every((v, i) => i === 0 || v >= seq[i - 1]);
    })(), JSON.stringify(d1.body.data.detection.items.map((i) => i.dimension)));

  // ---------- 3. 不合格检出 ----------
  section('不合格检出 · 缺必备著录项');
  const a2 = await makeArchive({ title: `${TAG} 缺责任者`, responsible: '' });
  const det2 = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a2.id, environment: 'archive' },
  });
  const r2 = (det2.body.data.results || [])[0] || {};
  check('缺责任者 → 判为不合格', r2.qualified === false, String(r2.conclusion));
  const itemIntg = ((r2.result || {}).items || []).find((i) => i.code === 'INTG-01');
  check('精确定位到「著录必备项」检查项', itemIntg && itemIntg.pass === false, JSON.stringify(itemIntg));
  check('说明里点明了缺哪一项', /责任者/.test((itemIntg || {}).detail || ''), String((itemIntg || {}).detail));
  check('不合格项计入 errors 统计', Number((r2.result || {}).summary.errors) > 0,
    String((r2.result || {}).summary.errors));

  section('不合格检出 · 附件摘要不符（真实篡改实体文件）');
  const a3 = await makeArchive({ responsible: '办公室', title: `${TAG} 摘要校验` });
  const mp3 = multipart([{ filename: 'fixity.txt', data: `${TAG} 固件校验样本` }]);
  await admin.json(`/api/archives/${a3.id}/files`, {
    method: 'POST', headers: { 'Content-Type': mp3.contentType }, body: mp3.body,
  });
  // 取附件在磁盘上的路径
  const db = new DatabaseSync(DB_FILE);
  const fileRow = db.prepare('SELECT id, rel_path, original_name, size FROM files WHERE archive_id=?').get(a3.id);
  db.close();
  const abs = path.join(DATA_DIR, 'files', fileRow.rel_path);
  const origBuf = fs.readFileSync(abs);
  // 篡改：往文件末尾追加一个字节（大小与摘要都会变）
  fs.appendFileSync(abs, Buffer.from('X'));
  const det3 = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a3.id, environment: 'archive' },
  });
  const r3 = (det3.body.data.results || [])[0] || {};
  const items3 = ((r3.result || {}).items || []);
  const auth1 = items3.find((i) => i.code === 'AUTH-01');
  const intg3 = items3.find((i) => i.code === 'INTG-03');
  check('篡改附件后检测判为不合格', r3.qualified === false, String(r3.conclusion));
  check('摘要校验项报不合格', auth1 && auth1.pass === false, JSON.stringify(auth1));
  check('摘要说明里给出检测到的差异', /摘要不符|摘要/.test((auth1 || {}).detail || ''), String((auth1 || {}).detail));
  check('附件大小一致性检查项也报不合格', intg3 && intg3.pass === false, JSON.stringify(intg3));
  // 还原
  fs.writeFileSync(abs, origBuf);
  const det3b = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a3.id, environment: 'archive' },
  });
  const r3b = (det3b.body.data.results || [])[0] || {};
  const auth1b = ((r3b.result || {}).items || []).find((i) => i.code === 'AUTH-01');
  check('还原文件后摘要校验恢复通过', auth1b && auth1b.pass === true, JSON.stringify(auth1b));

  section('不合格检出 · 非开放加密封装');
  const a4 = await makeArchive({ responsible: '办公室', title: `${TAG} 压缩包附件` });
  const mp4 = multipart([{ filename: 'packed.zip', data: 'PK-not-a-real-zip', mime: 'application/zip' }]);
  await admin.json(`/api/archives/${a4.id}/files`, {
    method: 'POST', headers: { 'Content-Type': mp4.contentType }, body: mp4.body,
  });
  const det4 = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a4.id, environment: 'archive' },
  });
  const r4 = (det4.body.data.results || [])[0] || {};
  const sec2 = ((r4.result || {}).items || []).find((i) => i.code === 'SEC-02');
  check('压缩/加密封装被判不合格（DA/T 92 §8.1.3）', sec2 && sec2.pass === false, JSON.stringify(sec2));
  check('说明给出可操作的原因', /永久不可读|解包/.test((sec2 || {}).detail || ''), String((sec2 || {}).detail));

  // ---------- 4. 自动检测 ----------
  section('上传附件自动触发归档检测');
  check('上传接口返回自动检测结果', !!(up.body.data && up.body.data.detection),
    JSON.stringify(up.body.data && up.body.data.detection).slice(0, 160));
  if (up.body.data && up.body.data.detection && !up.body.data.detection.skipped) {
    check('自动检测已产出合格结论', /合格|不合格/.test(up.body.data.detection.conclusion || ''),
      String(up.body.data.detection.conclusion));
    const byArchive = await admin.json(`/api/detections?archive_id=${a1.id}&size=50`);
    const auto = (byArchive.body.data.list || []).find((x) => x.source === '归档上传');
    check('自动检测已落库且来源标为「归档上传」', !!auto, JSON.stringify((byArchive.body.data.list || []).map((x) => x.source)));
  }

  // ---------- 5. 长期保存环节 ----------
  section('长期保存环节检测');
  const det5 = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: a1.id, environment: 'preservation' },
  });
  const r5 = (det5.body.data.results || [])[0] || {};
  check('长期保存环节检测可执行', det5.status === 200, JSON.stringify(det5.body).slice(0, 140));
  const sec4 = ((r5.result || {}).items || []).find((i) => i.code === 'SEC-04');
  check('含「距上次检测未超一年」检查项', !!sec4, JSON.stringify(((r5.result || {}).items || []).map((i) => i.code)));
  check('该检查项给出距上次检测的天数说明', /天/.test((sec4 || {}).detail || ''), String((sec4 || {}).detail));
  const sec3 = ((r5.result || {}).items || []).find((i) => i.code === 'SEC-03');
  check('含存储介质空间检查项', !!sec3, JSON.stringify((sec3 || {}).detail));

  // ---------- 6. 移交闸门 ----------
  section('移交闸门（检测合格方可移交）');
  const aGate = await makeArchive({ responsible: '办公室', title: `${TAG} 闸门样本` });
  const t = await admin.json('/api/transfers', {
    method: 'POST', json: { archive_ids: [aGate.id], title: `${TAG} 闸门批次`, target_unit: '测试档案馆' },
  });
  if (t.body.ok) created.transfers.push(t.body.data.id);
  check('新建移交批次成功', t.body.ok, JSON.stringify(t.body).slice(0, 140));
  const blocked = await admin.json(`/api/transfers/${t.body.data.id}/submit`, { method: 'POST', json: {} });
  check('未检测 → 提交被拦（400）', blocked.status === 400, 'status=' + blocked.status);
  check('拦截码为 DETECTION_REQUIRED', blocked.body.code === 'DETECTION_REQUIRED', String(blocked.body.code));
  check('拦截文案引用了标准依据', /四性检测/.test(JSON.stringify(blocked.body)));
  await admin.json('/api/detections', { method: 'POST', json: { archive_id: aGate.id, environment: 'archive' } });
  const submitted = await admin.json(`/api/transfers/${t.body.data.id}/submit`, { method: 'POST', json: {} });
  check('补做检测后可以提交', submitted.body.ok && submitted.body.data.status === '已提交',
    JSON.stringify(submitted.body).slice(0, 160));

  const offGate = await admin.json('/api/settings', { method: 'PUT', json: { 'detection.enforce_transfer': '0' } });
  check('可由管理员关闭移交前强制检测', offGate.body.ok);
  await admin.json('/api/settings', { method: 'PUT', json: { 'detection.enforce_transfer': '1' } });

  // ---------- 7. 覆盖率与超期 ----------
  section('覆盖率与超期清单');
  const stats2 = await admin.json('/api/detections/stats');
  const s2 = stats2.body.data || {};
  check('统计返回总量/已检测/未检测', typeof s2.total === 'number' && typeof s2.detected === 'number',
    JSON.stringify({ total: s2.total, detected: s2.detected }));
  check('已检测数量大于 0', s2.detected > 0, String(s2.detected));
  check('返回覆盖率百分比', typeof s2.coverage === 'number', String(s2.coverage));
  check('返回按环节统计', Array.isArray(s2.byEnvironment), JSON.stringify(s2.byEnvironment));
  check('返回最近检测记录', Array.isArray(s2.recent), String((s2.recent || []).length));

  const due = await admin.json('/api/detections/due');
  check('超期清单可查询', due.status === 200 && Array.isArray(due.body.data.list), JSON.stringify(due.body).slice(0, 140));
  check('超期清单说明每条的原因', (due.body.data.list || []).every((x) => !!x.reason),
    JSON.stringify((due.body.data.list || [])[0] || {}));
  check('从未检测的档案会被列入', (due.body.data.list || []).some((x) => x.never === true),
    String((due.body.data.list || []).filter((x) => x.never).length));
  check('返回年度检测周期设置', typeof due.body.data.yearlyDays === 'number', String(due.body.data.yearlyDays));

  // ---------- 8. 打印报告 ----------
  section('检测报告打印');
  const pr = await admin.raw(`/api/detections/${r0.id}/print`);
  check('报告页可打开', pr.status === 200 && /四 性 检 测 报 告/.test(pr.text), 'status=' + pr.status);
  check('报告含检测单号与环节', pr.text.includes(r0.detection_no) && pr.text.includes('归档环节'));
  check('报告含逐项检测结果表', pr.text.includes('逐项检测结果'));
  check('报告含检查项编号与四性维度', /AUTH-01/.test(pr.text) && /真实性/.test(pr.text));
  check('报告含责任人确认栏（《电子档案管理办法》第十八条）', pr.text.includes('责任人确认'));
  check('报告注明标准依据', /DA\/T 70/.test(pr.text));

  // ---------- 9. 权限与密级 ----------
  section('权限与密级隔离');
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_aud`, display_name: TAG, password: 'Test@12345', role: 'auditor', clearance: '公开' },
  });
  if (mk.body.ok) created.users.push(mk.body.data.id);
  const aud = makeSession();
  await aud.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_aud`, password: 'Test@12345' } });
  await aud.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const audRun = await aud.json('/api/detections', { method: 'POST', json: { archive_id: a1.id, environment: 'archive' } });
  check('安全审计员不能执行检测（不参与业务）', audRun.status === 403, 'status=' + audRun.status);
  const audView = await aud.json('/api/detections');
  check('安全审计员可以查看检测记录', audView.status === 200, 'status=' + audView.status);

  const mkR = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_rd`, display_name: TAG, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  if (mkR.body.ok) created.users.push(mkR.body.data.id);
  const rd = makeSession();
  await rd.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_rd`, password: 'Test@12345' } });
  await rd.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const rdRun = await rd.json('/api/detections', { method: 'POST', json: { archive_id: a1.id, environment: 'archive' } });
  check('普通用户不能执行检测', rdRun.status === 403, 'status=' + rdRun.status);

  // 涉密档案的检测记录对低密级不可见
  const aSecret = await makeArchive({ responsible: '办公室', title: `${TAG} 涉密样本`, secret_level: '机密' });
  const detS = await admin.json('/api/detections', { method: 'POST', json: { archive_id: aSecret.id, environment: 'archive' } });
  const rS = (detS.body.data.results || [])[0] || {};
  const rdView = await rd.json(`/api/detections/${rS.id}`);
  check('低密级用户看不到涉密档案的检测记录（404）', rdView.status === 404, 'status=' + rdView.status);
  const listLow = await rd.json('/api/detections?size=100');
  check('检测列表里不含涉密档案的记录',
    !(listLow.body.data.list || []).some((x) => Number(x.archive_id) === Number(aSecret.id)),
    JSON.stringify((listLow.body.data.list || []).map((x) => x.archive_code).slice(0, 8)));

  // ---------- 清理 ----------
  section('清理');
  for (const id of created.transfers) await admin.json(`/api/transfers/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.archives) await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const finalDue = await admin.json('/api/detections/due');
  check('清理后接口仍可用', finalDue.status === 200);

  console.log(`\n四性检测回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n四性检测测试异常终止：', e); process.exit(1); });
