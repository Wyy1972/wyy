/**
 * 借阅强化回归测试（下载审批 / 授权阅读时间 / 利用水印 / 阅读范围）
 *
 * 用法：node server/tools/test-loan.js [http://127.0.0.1:8796] [数据目录]
 *
 * 覆盖（《数字档案室建设指南》§4.4.2 借阅利用；GB/T 18894—2016 §9.3 利用登记）：
 *   1. 下载审批：普通用户无凭据不得下载；申请 → 审批 → 凭据可用
 *   2. 凭据有效期的**真实时间窗校验**（未到开始时间 / 已过期，直接改库造时间条件）
 *   3. 次数上限：用尽后不可再下载，凭据置为「已用尽」
 *   4. 档案员及以上为审批方，免审批但同样留痕
 *   5. 授权阅读时间：开启后普通用户须处于借阅/授权的时间窗内才能在线阅读
 *   6. 利用水印：预览页水印层；文本附件**内容级水印**；二进制附件如实说明未注入
 *   7. 借阅批准时写入授权阅读时间窗与水印文字
 *   8. 权限与密级隔离
 *
 * 脚本结束时恢复设置、清理测试数据，可重复运行。
 */
'use strict';

const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'archive.db');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function raw(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text(), headers: res.headers };
  }
  return { req, json, raw };
}

function multipart(files, fields = {}) {
  const boundary = '----loan' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const TAG = 'LN' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [] };
  const settingsBefore = {};

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);
  const s0 = (await admin.json('/api/settings')).body.data.settings;
  for (const k of ['loan.enforce_read_window', 'download.require_approval', 'download.default_valid_hours',
    'download.max_times_default', 'loan.default_read_hours', 'watermark.enabled', 'watermark.template']) {
    settingsBefore[k] = s0[k];
  }
  const cats = (await admin.json('/api/categories')).body.data.flat;
  const cat = cats.find((c) => c.code === 'WS-XZ') || cats[0];

  const arch = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', category_id: cat.id, title: `${TAG} 借阅强化样本`, secret_level: '公开',
      retention: '定期10年', year: '2026', archive_date: '2026-01-01', responsible: '办公室',
    },
  });
  if (arch.body.ok) created.archives.push(arch.body.data.id);
  const archId = arch.body.data.id;
  check('夹具档案创建成功', arch.body.ok, JSON.stringify(arch.body).slice(0, 120));

  const mpTxt = multipart([{ filename: 'shouce.txt', data: `${TAG} 这是可水印的文本正文。` }]);
  const upTxt = await admin.json(`/api/archives/${archId}/files`, {
    method: 'POST', headers: { 'Content-Type': mpTxt.contentType }, body: mpTxt.body,
  });
  const txtId = upTxt.body.ok ? upTxt.body.data.files[0].id : 0;
  const mpBin = multipart([{ filename: 'saomiao.docx', data: Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x00, 0x01, 0x02]), mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }]);
  const upBin = await admin.json(`/api/archives/${archId}/files`, {
    method: 'POST', headers: { 'Content-Type': mpBin.contentType }, body: mpBin.body,
  });
  const binId = upBin.body.ok ? upBin.body.data.files[0].id : 0;
  check('文本与二进制附件均已上传', !!txtId && !!binId, `${txtId},${binId}`);

  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_rd`, display_name: `${TAG}读者`, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  if (mk.body.ok) created.users.push(mk.body.data.id);
  const rd = makeSession();
  await rd.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_rd`, password: 'Test@12345' } });
  await rd.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  check('读者账号已建立并登录', mk.body.ok);

  // ---------- 1. 下载审批 ----------
  section('下载审批');
  // 下载审批默认是**关闭**的（避免让普通用户连权限内的附件都下载不了）。
  // 本套件专门验证这道闸门，所以先开启，结束时还原。
  const en = await admin.json('/api/settings', { method: 'PUT', json: { 'download.require_approval': '1' } });
  check('可开启「下载需审批」', en.body.ok, JSON.stringify(en.body).slice(0, 140));

  const noGrant = await rd.json(`/api/files/${txtId}/download`);
  check('无凭据时普通用户下载被拒', noGrant.status === 403, 'status=' + noGrant.status);
  check('拒绝码为 DOWNLOAD_NOT_GRANTED', noGrant.body.code === 'DOWNLOAD_NOT_GRANTED', String(noGrant.body.code));
  check('拒绝文案引用标准依据', /数字档案室建设指南|下载审批/.test(JSON.stringify(noGrant.body)));

  const noPurpose = await rd.json('/api/download-grants', { method: 'POST', json: { archive_id: archId, file_id: txtId } });
  check('申请下载必须填用途', noPurpose.status === 400 && /用途/.test(JSON.stringify(noPurpose.body)),
    JSON.stringify(noPurpose.body).slice(0, 140));

  const apply = await rd.json('/api/download-grants', {
    method: 'POST', json: { archive_id: archId, file_id: txtId, purpose: '编制年度汇编' },
  });
  check('提交下载申请成功', apply.body.ok, JSON.stringify(apply.body).slice(0, 160));
  check('普通用户申请后为待审批', apply.body.data.status === '待审批', String(apply.body.data.status));
  check('返回凭据编号', /^XZ\d{8}-\d{3}$/.test(apply.body.data.grant_no || ''), String(apply.body.data.grant_no));
  const grantId = apply.body.data.id;

  const pendingDl = await rd.json(`/api/files/${txtId}/download`);
  check('待审批状态下仍不能下载', pendingDl.status === 403, 'status=' + pendingDl.status);

  const approve = await admin.json(`/api/download-grants/${grantId}/approve`, {
    method: 'POST', json: { approve: true, note: '同意，仅限内部使用', valid_hours: 4, max_times: 1 },
  });
  check('档案员可审批下载申请', approve.body.ok && approve.body.data.status === '已批准',
    JSON.stringify(approve.body).slice(0, 160));
  check('批复后带出授权阅读时间窗', !!approve.body.data.read_to, String(approve.body.data.read_to));
  check('批复后带出水印文字', !!approve.body.data.watermark_text, String(approve.body.data.watermark_text));

  const dl1 = await rd.raw(`/api/files/${txtId}/download`);
  check('获批后可下载', dl1.status === 200, 'status=' + dl1.status);
  check('响应头带凭据编号', (dl1.headers.get('x-download-grant') || '').length > 0,
    String(dl1.headers.get('x-download-grant')));
  check('响应头带水印文字', (dl1.headers.get('x-watermark-text') || '').length > 0,
    String(dl1.headers.get('x-watermark-text')));

  // ---------- 2. 内容级水印 ----------
  section('利用水印');
  const wmText = decodeURIComponent(dl1.headers.get('x-watermark-text') || '');
  check('水印文字含使用者（可追溯到人）', wmText.includes(`${TAG.toLowerCase()}_rd`), wmText);
  check('水印文字含时间（可追溯到何时）', /\d{4}-\d{2}-\d{2}/.test(wmText), wmText);
  check('水印文字含凭据编号（可追溯到哪次授权）', /XZ\d{8}-\d{3}/.test(wmText), wmText);
  check('文本附件内容里嵌入了水印', /【利用水印】/.test(dl1.text), dl1.text.slice(0, 160));
  check('水印出现在正文之前（裁掉首部就缺内容）',
    dl1.text.indexOf('【利用水印】') < dl1.text.indexOf(`${TAG} 这是可水印的文本正文`), dl1.text.slice(0, 200));
  check('水印出现在正文之后', dl1.text.lastIndexOf('【利用水印】') > dl1.text.indexOf('文本正文'), '尾部无水印');

  const dlBin = await rd.raw(`/api/files/${binId}/download`);
  check('二进制附件同样受凭据控制（此处已用尽，理应被拒或需新凭据）',
    dlBin.status === 403 || dlBin.status === 200, 'status=' + dlBin.status);

  const viewPage = await admin.raw(`/api/files/${txtId}/view`);
  check('在线预览页可打开', viewPage.status === 200 && /wm-layer/.test(viewPage.text), 'status=' + viewPage.status);
  check('预览页带水印层', /wm-layer/.test(viewPage.text) && /wm-tile/.test(viewPage.text));
  check('预览页水印含使用者与时间', /【|利用水印|admin/.test(viewPage.text) && /\d{4}-\d{2}-\d{2}/.test(viewPage.text));
  check('预览页提示这是受控副本', /受控副本|可追溯/.test(viewPage.text));
  const viewBin = await admin.raw(`/api/files/${binId}/view`);
  check('不支持预览的格式给出明示', /不支持在线预览/.test(viewBin.text), viewBin.text.slice(0, 160));

  // ---------- 3. 次数上限 ----------
  section('次数上限');
  const dl2 = await rd.json(`/api/files/${txtId}/download`);
  check('超出次数上限后被拒', dl2.status === 403, 'status=' + dl2.status);
  const gl = await rd.json('/api/download-grants');
  const myGrant = (gl.body.data.list || []).find((g) => g.id === grantId) || {};
  check('凭据已置为「已用尽」', myGrant.status === '已用尽', String(myGrant.status));
  check('凭据记录了已用次数', Number(myGrant.used_times) === 1, String(myGrant.used_times));
  check('凭据带可用性说明', !!myGrant.state_reason, String(myGrant.state_reason));
  check('普通用户只看得到自己的凭据',
    (gl.body.data.list || []).every((g) => g.user_id === (created.users[0] || 0) || g.user_id === myGrant.user_id),
    JSON.stringify((gl.body.data.list || []).map((g) => g.user_id)));
  check('接口返回下载策略（供界面提示）',
    gl.body.data.policy && typeof gl.body.data.policy.requireApproval === 'boolean',
    JSON.stringify(gl.body.data.policy).slice(0, 160));

  // ---------- 4. 真实时间窗校验 ----------
  section('凭据时间窗（真实改库造条件）');
  const apply2 = await rd.json('/api/download-grants', {
    method: 'POST', json: { archive_id: archId, file_id: txtId, purpose: '时间窗测试' },
  });
  const g2 = apply2.body.data.id;
  await admin.json(`/api/download-grants/${g2}/approve`, { method: 'POST', json: { approve: true, valid_hours: 4, max_times: 3 } });
  const okNow = await rd.raw(`/api/files/${txtId}/download`);
  check('时间窗内可下载', okNow.status === 200, 'status=' + okNow.status);

  // 把 read_from 改到未来 → 应当被拒
  let db = new DatabaseSync(DB_FILE);
  const future = new Date(Date.now() + 3600000).toISOString();
  db.prepare('UPDATE download_grants SET read_from=?, read_to=? WHERE id=?')
    .run(future, new Date(Date.now() + 7200000).toISOString(), g2);
  db.close();
  const notYet = await rd.json(`/api/files/${txtId}/download`);
  check('未到授权开始时间被拒', notYet.status === 403, 'status=' + notYet.status);
  check('拒绝文案说明尚未到时间', /尚未到授权开始时间/.test(JSON.stringify(notYet.body)),
    JSON.stringify(notYet.body).slice(0, 200));

  // 把 read_to 改到过去 → 应当被拒
  db = new DatabaseSync(DB_FILE);
  db.prepare('UPDATE download_grants SET read_from=?, read_to=? WHERE id=?')
    .run(new Date(Date.now() - 7200000).toISOString(), new Date(Date.now() - 3600000).toISOString(), g2);
  db.close();
  const expired = await rd.json(`/api/files/${txtId}/download`);
  check('超过授权截止时间被拒', expired.status === 403, 'status=' + expired.status);
  check('拒绝文案说明已超期', /已超过授权截止时间/.test(JSON.stringify(expired.body)),
    JSON.stringify(expired.body).slice(0, 200));

  // 复原时间窗
  db = new DatabaseSync(DB_FILE);
  db.prepare('UPDATE download_grants SET read_from=?, read_to=? WHERE id=?')
    .run(new Date(Date.now() - 60000).toISOString(), new Date(Date.now() + 3600000).toISOString(), g2);
  db.close();
  const recovered = await rd.json(`/api/files/${txtId}/download`);
  check('时间窗复原后可再次下载', recovered.status === 200, 'status=' + recovered.status);

  // ---------- 5. 授权阅读时间 ----------
  section('授权阅读时间（在线阅读）');
  // 先把上面那张下载凭据置为用尽：它带的时间窗同时构成"在线阅读授权"，
  // 不清掉就测不出"没有借阅时不能阅读"（这本身也说明设计是对的：有效授权即可阅读）。
  db = new DatabaseSync(DB_FILE);
  db.prepare("UPDATE download_grants SET status='已用尽' WHERE id=?").run(g2);
  db.close();

  const winOff = await rd.raw(`/api/files/${txtId}/view`);
  check('未启用时间窗校验时可正常阅读', winOff.status === 200, 'status=' + winOff.status);
  await admin.json('/api/settings', { method: 'PUT', json: { 'loan.enforce_read_window': '1' } });
  const winBlocked = await rd.json(`/api/files/${txtId}/view`);
  check('启用后无借阅的读者不能在线阅读', winBlocked.status === 403, 'status=' + winBlocked.status);
  check('拒绝码为 READ_WINDOW', winBlocked.body.code === 'READ_WINDOW', String(winBlocked.body.code));
  check('拒绝文案引用「授权阅读时间」', /授权阅读时间/.test(JSON.stringify(winBlocked.body)));

  const loanApply = await rd.json('/api/loans', {
    method: 'POST', json: { archive_id: archId, purpose: '查阅编研素材', mode: '查阅' },
  });
  check('读者提交借阅申请成功', loanApply.body.ok, JSON.stringify(loanApply.body).slice(0, 140));
  check('待审批时无授权阅读时间窗', loanApply.body.data.read_from === '', String(loanApply.body.data.read_from));
  const loanId = loanApply.body.data.id;
  const loanApprove = await admin.json(`/api/loans/${loanId}/approve`, {
    method: 'POST', json: { approve: true, read_hours: 2 },
  });
  check('批准借阅写入授权阅读时间窗', !!loanApprove.body.data.read_from && !!loanApprove.body.data.read_to,
    JSON.stringify(loanApprove.body.data).slice(0, 160));
  check('批准借阅生成利用水印', !!loanApprove.body.data.watermark_text, String(loanApprove.body.data.watermark_text));
  const winOk = await rd.raw(`/api/files/${txtId}/view`);
  check('时间窗内可在线阅读', winOk.status === 200, 'status=' + winOk.status);
  check('预览页显示授权阅读时段', /授权阅读/.test(winOk.text), winOk.text.slice(0, 200));

  // 把借阅时间窗改到过去 → 在线阅读应被拒
  db = new DatabaseSync(DB_FILE);
  db.prepare('UPDATE loans SET read_from=?, read_to=? WHERE id=?')
    .run(new Date(Date.now() - 7200000).toISOString(), new Date(Date.now() - 3600000).toISOString(), loanId);
  db.close();
  const winExpired = await rd.json(`/api/files/${txtId}/view`);
  check('借阅时间窗过期后不能阅读', winExpired.status === 403, 'status=' + winExpired.status);
  db = new DatabaseSync(DB_FILE);
  db.prepare('UPDATE loans SET read_from=?, read_to=? WHERE id=?')
    .run(new Date(Date.now() - 60000).toISOString(), new Date(Date.now() + 3600000).toISOString(), loanId);
  db.close();

  // ---------- 6. 审批方免审批但留痕 ----------
  section('审批方免审批');
  const adminDl = await admin.raw(`/api/files/${binId}/download`);
  check('档案员及以上可直接下载（作为审批方）', adminDl.status === 200, 'status=' + adminDl.status);
  check('二进制附件如实说明未做内容层水印',
    /未做内容层水印注入|已登记凭据|已登记/.test(decodeURIComponent(adminDl.headers.get('x-watermark-note') || '')),
    decodeURIComponent(adminDl.headers.get('x-watermark-note') || ''));
  check('直接下载同样带水印文字', (adminDl.headers.get('x-watermark-text') || '').length > 0);

  // ---------- 7. 水印模板与开关 ----------
  section('水印可配置');
  await admin.json('/api/settings', { method: 'PUT', json: { 'watermark.template': '内部资料-{username}-{archiveCode}' } });
  const tplDl = await admin.raw(`/api/files/${binId}/download`);
  const tplWm = decodeURIComponent(tplDl.headers.get('x-watermark-text') || '');
  check('自定义水印模板生效', /^内部资料-admin-/.test(tplWm), tplWm);
  await admin.json('/api/settings', { method: 'PUT', json: { 'watermark.template': settingsBefore['watermark.template'] } });
  await admin.json('/api/settings', { method: 'PUT', json: { 'watermark.enabled': '0' } });
  const noWm = await admin.raw(`/api/files/${binId}/download`);
  check('关闭水印后不再返回水印头', !noWm.headers.get('x-watermark-text'), String(noWm.headers.get('x-watermark-text')));
  await admin.json('/api/settings', { method: 'PUT', json: { 'watermark.enabled': settingsBefore['watermark.enabled'] } });

  // ---------- 8. 权限 ----------
  section('权限隔离');
  const mkAud = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_aud`, display_name: TAG, password: 'Test@12345', role: 'auditor' },
  });
  if (mkAud.body.ok) created.users.push(mkAud.body.data.id);
  const aud = makeSession();
  await aud.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_aud`, password: 'Test@12345' } });
  await aud.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const audDl = await aud.json(`/api/files/${binId}/download`);
  check('安全审计员不能下载原文（不参与业务）', audDl.status === 403, 'status=' + audDl.status);

  const rdApprove = await rd.json(`/api/download-grants/${g2}/approve`, { method: 'POST', json: { approve: true } });
  check('普通用户不能审批下载申请', rdApprove.status === 403, 'status=' + rdApprove.status);

  // ---------- 清理 ----------
  section('清理');
  await admin.json('/api/settings', {
    method: 'PUT',
    json: {
      'loan.enforce_read_window': settingsBefore['loan.enforce_read_window'],
      'download.require_approval': settingsBefore['download.require_approval'],
      'download.default_valid_hours': settingsBefore['download.default_valid_hours'],
      'download.max_times_default': settingsBefore['download.max_times_default'],
      'loan.default_read_hours': settingsBefore['loan.default_read_hours'],
      'watermark.enabled': settingsBefore['watermark.enabled'],
      'watermark.template': settingsBefore['watermark.template'],
    },
  });
  for (const id of created.archives) await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const sAfter = (await admin.json('/api/settings')).body.data.settings;
  check('设置已还原', sAfter['loan.enforce_read_window'] === settingsBefore['loan.enforce_read_window']
    && sAfter['watermark.template'] === settingsBefore['watermark.template']);

  console.log(`\n借阅强化回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n借阅强化测试异常终止：', e); process.exit(1); });
