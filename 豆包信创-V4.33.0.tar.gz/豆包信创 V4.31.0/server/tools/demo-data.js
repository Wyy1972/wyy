/**
 * 演示数据生成器：node server/server.js --demo
 * 生成覆盖五大门类的示例档案与少量示例附件，便于快速熟悉系统
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { makeApi } = require('../lib/q');
const storage = require('../lib/storage');
const { hashPassword } = require('../db');
const audit = require('../lib/audit');

const TITLES = {
  WS: [
    ['关于进一步加强档案管理工作的通知', 'WS-SJ', { fwzh: '办发〔2024〕18号', mjmc: '内部', zrz: '上级主管部门', cjz: '2024-03-12', fs: '2', ztc: '档案 管理 通知' }],
    ['关于印发年度重点工作任务分解方案的通知', 'WS-BW', { fwzh: '本单位发〔2024〕6号', mjmc: '公开', zrz: '本单位办公室', cjz: '2024-02-20', fs: '3', ztc: '重点工作 任务分解' }],
    ['关于开展安全生产大检查的实施方案', 'WS-YW', { fwzh: '本单位发〔2024〕21号', mjmc: '内部', zrz: '安全生产科', cjz: '2024-05-08', fs: '1', ztc: '安全生产 检查' }],
    ['关于表彰年度先进工作者的决定', 'WS-DQ', { fwzh: '党组发〔2024〕9号', mjmc: '公开', zrz: '党组', cjz: '2024-12-26', fs: '2', ztc: '表彰 先进' }],
    ['关于调整领导班子分工的通知', 'WS-DQ', { fwzh: '党组发〔2025〕2号', mjmc: '内部', zrz: '党组', cjz: '2025-01-15', fs: '1', ztc: '分工 调整' }],
    ['关于报送年度工作总结的报告', 'WS-BW', { fwzh: '本单位发〔2025〕4号', mjmc: '内部', zrz: '综合科', cjz: '2025-01-08', fs: '2', ztc: '工作总结' }],
    ['关于规范印章使用管理的通知', 'WS-XZ', { fwzh: '本单位发〔2023〕33号', mjmc: '内部', zrz: '办公室', cjz: '2023-11-02', fs: '1', ztc: '印章 管理' }],
  ],
  HT: [
    ['办公设备采购合同（联想电脑 60 台）', 'HT-CG', { hth: 'CG-2024-018', jf: '本单位', yf: '某某科技有限责任公司', je: '486000', qdrq: '2024-04-18', yxq: '2027-04-17', ldr: '张伟' }],
    ['物业管理服务合同', 'HT-FW', { hth: 'FW-2024-007', jf: '本单位', yf: '某某物业管理有限公司', je: '1200000', qdrq: '2024-01-05', yxq: '2026-12-31', ldr: '李娜' }],
    ['办公楼三至五层租赁合同', 'HT-ZL', { hth: 'ZL-2023-011', jf: '本单位', yf: '某某置业集团有限公司', je: '3600000', qdrq: '2023-09-01', yxq: '2028-08-31', ldr: '王强' }],
    ['信息系统运维服务合同', 'HT-FW', { hth: 'FW-2025-003', jf: '本单位', yf: '某某信息技术有限公司', je: '680000', qdrq: '2025-02-10', yxq: '2026-02-09', ldr: '陈晨' }],
    ['员工劳动合同（首批 25 人）', 'HT-LD', { hth: 'LD-2024-025', jf: '本单位', yf: '员工本人', je: '0', qdrq: '2024-07-01', yxq: '2027-06-30', ldr: '人事科' }],
    ['公务用车定点维修服务合同', 'HT-FW', { hth: 'FW-2023-022', jf: '本单位', yf: '某某汽车服务有限公司', je: '150000', qdrq: '2023-06-15', yxq: '2025-06-14', ldr: '刘洋' }],
  ],
  RS: [
    ['张明同志人事档案', 'RS-LL', { xm: '张明', gh: '2021007', bm: '综合办公室', zw: '科长', rzrq: '2021-03-01', mjmc: '秘密' }],
    ['李红同志人事档案', 'RS-LL', { xm: '李红', gh: '2019003', bm: '财务科', zw: '副科长', rzrq: '2019-07-15', mjmc: '秘密' }],
    ['王强同志人事档案', 'RS-LL', { xm: '王强', gh: '2015001', bm: '工程管理科', zw: '高级工程师', rzrq: '2015-09-01', mjmc: '秘密' }],
    ['赵敏同志专业技术职称评审材料', 'RS-ZC', { xm: '赵敏', gh: '2020012', bm: '技术科', zw: '工程师', rzrq: '2020-06-20', mjmc: '内部' }],
    ['年度考核优秀人员审批表', 'RS-KH', { xm: '多人', gh: '—', bm: '全单位', zw: '—', rzrq: '—', mjmc: '内部' }],
    ['新员工入职培训记录（第三期）', 'RS-PX', { xm: '多人', gh: '—', bm: '人事科', zw: '—', rzrq: '—', mjmc: '内部' }],
    ['退休人员审批材料（2024 年度）', 'RS-LZ', { xm: '多人', gh: '—', bm: '人事科', zw: '—', rzrq: '—', mjmc: '秘密' }],
  ],
  CW: [
    ['2024 年 12 月记账凭证', 'CW-PZ', { pzh: '记-2024-12', kjqj: '2024-12', hje: '1863452.60', zdr: '李红', shr: '周涛', jzrq: '2025-01-10' }],
    ['2024 年度总账', 'CW-ZB', { pzh: '总账-2024', kjqj: '2024', hje: '0', zdr: '李红', shr: '周涛', jzrq: '2025-02-28' }],
    ['2024 年度财务报告', 'CW-BG', { pzh: '财报-2024', kjqj: '2024', hje: '0', zdr: '李红', shr: '单位负责人', jzrq: '2025-03-20' }],
    ['2025 年度部门预算批复', 'CW-YS', { pzh: '预算-2025', kjqj: '2025', hje: '24500000', zdr: '财务科', shr: '上级主管部门', jzrq: '2025-01-25' }],
    ['2024 年度专项资金审计报告', 'CW-SJ', { pzh: '审计-2024-02', kjqj: '2024', hje: '0', zdr: '某某会计师事务所', shr: '财务科', jzrq: '2025-04-08' }],
    ['2024 年 11 月记账凭证', 'CW-PZ', { pzh: '记-2024-11', kjqj: '2024-11', hje: '1520983.15', zdr: '李红', shr: '周涛', jzrq: '2024-12-10' }],
  ],
  GC: [
    ['综合办公楼建设项目竣工图', 'GC-JG', { gcmc: '综合办公楼建设', tzh: 'JG-2023-001', gch: '建施-01~36', bcr: '王强', bcrq: '2023-12-15', sbr: '某某建筑设计院' }],
    ['综合办公楼结构设计图', 'GC-SJ', { gcmc: '综合办公楼建设', tzh: 'SJ-2022-014', gch: '结施-01~48', bcr: '王强', bcrq: '2022-08-20', sbr: '某某建筑设计院' }],
    ['院区给排水管网改造施工资料', 'GC-SG', { gcmc: '院区管网改造', tzh: 'SG-2024-006', gch: '水施-01~12', bcr: '赵敏', bcrq: '2024-06-30', sbr: '某某市政工程公司' }],
    ['配电房增容改造工程验收资料', 'GC-JG', { gcmc: '配电房增容改造', tzh: 'JG-2024-009', gch: '电施-01~18', bcr: '赵敏', bcrq: '2024-10-12', sbr: '某某电力安装公司' }],
    ['电梯设备安装及随机文件', 'GC-SB', { gcmc: '综合办公楼建设', tzh: 'SB-2023-003', gch: '—', bcr: '王强', bcrq: '2023-10-08', sbr: '某某电梯有限公司' }],
    ['消防设施改造工程立项批复', 'GC-LX', { gcmc: '消防设施改造', tzh: 'LX-2025-002', gch: '—', bcr: '综合科', bcrq: '2025-03-05', sbr: '上级主管部门' }],
  ],
};

const ABSTRACT = {
  WS: '本文就相关工作进行部署，明确责任分工、完成时限与工作要求，请各科室遵照执行。',
  HT: '合同经双方协商一致签订，明确标的、金额、履行期限、违约责任及争议解决方式，双方盖章生效。',
  RS: '本卷为该同志人事材料汇编，含履历、考核、任免、奖惩等材料，按规定权限管理，借阅需审批。',
  CW: '本卷为财务会计资料，按《会计档案管理办法》整理归档，保管期限按规定执行，不得擅自销毁。',
  GC: '本卷为工程项目技术资料，含图纸、变更、验收文件，是工程维护、改建、扩建的重要依据。',
};

const KEYWORDS = {
  WS: '公文 管理 通知 年度',
  HT: '合同 采购 服务 履行',
  RS: '人事 履历 考核 职称',
  CW: '会计 凭证 报表 审计',
  GC: '工程 图纸 施工 竣工验收',
};

function pick(arr, i) { return arr[i % arr.length]; }

function seedDemo(db, opts = {}) {
  const q = makeApi(db);
  const filesRoot = opts.filesRoot;
  const count = q.scalar('SELECT COUNT(*) FROM archives');
  if (count > 0) return 0;

  // 补几个普通账号，方便体验权限
  const users = [
    ['dangan', '档案员·小刘', 'clerk', '档案室'],
    ['zhangwei', '张伟', 'reader', '综合办公室'],
    ['lihong', '李红', 'reader', '财务科'],
  ];
  for (const [username, display, role, dept] of users) {
    if (q.scalar('SELECT id FROM users WHERE username=?', username)) continue;
    const { salt, hash } = hashPassword('123456');
    q.run(`INSERT INTO users(username,display_name,password_hash,password_salt,role,department,status,must_change,created_at)
           VALUES(?,?,?,?,?,?,'active',0,?)`, username, display, hash, salt, role, dept, new Date().toISOString());
  }

  const admin = q.get("SELECT id FROM users WHERE username='admin'");
  const cats = q.all('SELECT id, code FROM categories');
  const catByCode = new Map(cats.map((c) => [c.code, c.id]));
  const types = q.all('SELECT * FROM archive_types ORDER BY sort_no');
  const yearSet = [2023, 2024, 2025, 2026];
  let n = 0;

  for (const t of types) {
    const list = TITLES[t.code] || [];
    const fields = JSON.parse(t.fields);
    list.forEach((row, idx) => {
      const [title, catCode, extra] = row;
      const rawDate = extra.cjz || extra.qdrq || extra.jzrq || extra.bcrq || extra.rzrq || '';
      const parsedYear = parseInt(String(rawDate).slice(0, 4), 10);
      // 防御：日期缺失或非法时回退到有序的合理年度，绝不产生 NaN 档案号
      const y = Number.isFinite(parsedYear) && parsedYear > 1900 && parsedYear < 2200 ? parsedYear : pick(yearSet, idx);
      const archiveDate = /^\d{4}-\d{2}-\d{2}$/.test(String(rawDate)) ? String(rawDate) : `${y}-12-31`;
      // 档案号按年度流水生成
      const key = `seq:${t.code}:${y}`;
      const cur = Number(q.scalar('SELECT value FROM meta WHERE key=?', key) || 0) + 1;
      q.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, String(cur));
      const code = `${t.code}-${y}-${String(cur).padStart(4, '0')}`;
      if (q.scalar('SELECT id FROM archives WHERE archive_code=?', code)) return;

      const normalizedExtra = {};
      for (const f of fields) normalizedExtra[f.key] = extra[f.key] !== undefined ? String(extra[f.key]) : '';

      const status = '在库';   // 档案状态一律由借阅记录驱动，避免与借阅数据不一致
      const r = q.run(
        `INSERT INTO archives(archive_code,title,category_id,type_code,retention,secret_level,year,archive_date,
          volume_no,item_no,pages,copies,carrier,responsible,department,abstract,keywords,extra,location,status,status_note,created_by,created_at,updated_at)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        code, title, catByCode.get(catCode) || catByCode.get(t.code), t.code,
        t.retention, extra.mjmc || '公开', String(y), archiveDate,
        String(Math.ceil((idx + 1) / 3)), String(idx + 1), String(8 + idx * 3), Number(extra.fs || 1),
        t.code === 'GC' ? '纸质+电子' : '纸质',
        extra.zrz || extra.jf || extra.xm || extra.zdr || extra.bcr || '',
        extra.bm || q.scalar('SELECT department FROM users WHERE id=?', admin.id) || '',
        ABSTRACT[t.code] || '', KEYWORDS[t.code] || '', JSON.stringify(normalizedExtra),
        `档案室 ${String.fromCharCode(65 + (idx % 4))} 柜 ${(idx % 5) + 1} 层`,
        status, '', admin.id,
        `${archiveDate}T09:${String(10 + idx).padStart(2, '0')}:00.000Z`,
        `${archiveDate}T09:${String(10 + idx).padStart(2, '0')}:00.000Z`,
      );
      n += 1;

      // 给部分档案生成示例附件
      if (filesRoot && idx % 2 === 0) {
        const body = [
          `${title}`,
          '='.repeat(48),
          '',
          `档案号：${code}`,
          `门类：${t.name}　保管期限：${t.retention}　密级：${extra.mjmc || '公开'}`,
          `归档日期：${archiveDate}`,
          '',
          ABSTRACT[t.code],
          '',
          '（本文件为系统演示数据，用于体验检索、预览与下载功能）',
          `生成时间：${new Date().toLocaleString('zh-CN')}`,
        ].join('\r\n');
        const saved = storage.saveArchiveFile(filesRoot, {
          dir: storage.relDirFor({ archive: { archive_code: code, year: String(y) } }),
          base: storage.fileBaseName({ archive_code: code }),
        }, {
          filename: `${code}_${title.slice(0, 12)}.txt`,
          mime: 'text/plain; charset=utf-8',
          data: Buffer.from(body, 'utf8'),
        }, { seq: 1 });
        q.run(`INSERT INTO files(archive_id,original_name,stored_name,rel_path,mime,size,sha256,kind,sort_no,uploaded_by,created_at,storage_kind)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,'process')`,
          r.lastInsertRowid, saved.original_name, saved.stored_name, saved.rel_path, saved.mime,
          saved.size, saved.sha256, '正文', 1, admin.id, new Date().toISOString());
      }
    });
  }

  // 演示借阅记录
  const zhang = q.get("SELECT id FROM users WHERE username='zhangwei'");
  const li = q.get("SELECT id FROM users WHERE username='lihong'");
  const clerk = q.get("SELECT id FROM users WHERE username='dangan'");
  const someArchives = q.all('SELECT id, archive_code FROM archives ORDER BY id LIMIT 6');
  const today = new Date();
  const iso = (d) => d.toISOString().slice(0, 10);
  const shift = (days) => { const d = new Date(today); d.setDate(d.getDate() + days); return iso(d); };

  if (zhang && someArchives.length >= 3) {
    const rows = [
      [someArchives[0], zhang.id, '查阅', '办理年度审计需核对相关文件', '已归还', shift(-40), shift(-33), shift(-35)],
      [someArchives[1], zhang.id, '借出', '起草年度工作要点参考', '逾期', shift(-60), shift(-30), null],
      [someArchives[2], zhang.id, '复制', '留存备查', '待审批', shift(-1), shift(6), null],
    ];
    let seq = 1;
    for (const [a, uid, mode, purpose, status, applyAt, due, ret] of rows) {
      if (!a) continue;
      const loanNo = `JY${applyAt.replace(/-/g, '')}-${String(seq++).padStart(3, '0')}`;
      q.run(`INSERT INTO loans(loan_no,archive_id,user_id,purpose,mode,status,apply_at,approve_at,approve_by,due_date,return_at,return_by,return_note)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        loanNo, a.id, uid, purpose, mode, status, applyAt + 'T10:00:00.000Z',
        status === '待审批' ? null : applyAt + 'T11:00:00.000Z',
        status === '待审批' ? null : (clerk ? clerk.id : null), due,
        ret ? ret + 'T15:00:00.000Z' : null, ret ? (clerk ? clerk.id : null) : null,
        ret ? '完好归还' : '');
    }
  }
  // 让档案状态与借阅记录完全一致（借出 ↔ 在库 双向校正）
  q.run(`UPDATE archives SET status='借出' WHERE status='在库' AND id IN
         (SELECT archive_id FROM loans WHERE mode='借出' AND status IN ('已批准','逾期'))`);
  q.run(`UPDATE archives SET status='在库' WHERE status='借出' AND id NOT IN
         (SELECT archive_id FROM loans WHERE mode='借出' AND status IN ('已批准','逾期'))`);

  // 补全规范档号与保管期限代码：与数据库迁移使用同一套逻辑，保证演示数据与正式数据一致
  try {
    require('../db').backfillArchiveNumbers(db);
  } catch (e) {
    console.warn('[演示数据] 档号补全失败：' + e.message);
  }

  // ---- 库位、档案盒：没有这两类数据，「二维码」与「盘点」功能无法体验 ----
  seedLocationsAndBoxes(q, admin);

  // ---- 附件正文索引：演示附件是文本文件，直接提取入库，让「正文检索」开箱可用 ----
  seedFileText(q, filesRoot);

  // ---- 鉴定记录：到期提醒与鉴定流程的示例 ----
  seedAppraisals(q, admin);

  // 演示数据的初始化动作也要进同一条审计链。
  // 这里原先是一段自拼的 INSERT，绕过哈希链，会让 /api/logs/verify 报出假断点。
  audit.appendLog(db, {
    user_id: admin.id,
    username: 'admin',
    action: '初始化演示数据',
    target: '系统',
    detail: `生成 ${n} 条示例档案（含库位、档案盒、鉴定记录与正文索引）`,
    ip: '127.0.0.1',
    step: '演示数据播种',
  });

  return n;
}

/**
 * 生成库位与档案盒，并把部分档案装盒。
 * 装盒后档案的存放位置会自动继承盒所在库位，二维码、盘点、盒脊打印都能直接用。
 */
function seedLocationsAndBoxes(q, admin) {
  const now = new Date().toISOString();
  const locations = [
    ['A库-A1-1', 'A库 A1 排第 1 层', 'A库', 'A1', '1', 40],
    ['A库-A1-2', 'A库 A1 排第 2 层', 'A库', 'A1', '2', 40],
    ['B库-B1-1', 'B库 B1 排第 1 层', 'B库', 'B1', '1', 30],
    ['B库-B2-1', 'B库 B2 排第 1 层', 'B库', 'B2', '1', 30],
  ];
  const locIds = [];
  for (const [code, name, lib, shelf, layer, cap] of locations) {
    const r = q.run(`INSERT INTO locations(code,name,library,shelf,layer,capacity,remark,created_at)
                     VALUES(?,?,?,?,?,?,?,?)`, code, name, lib, shelf, layer, cap, '', now);
    locIds.push({ id: r.lastInsertRowid, code });
  }

  // 按门类与年度分盒，每个门类前若干件装一盒
  const types = q.all('SELECT code, name FROM archive_types ORDER BY sort_no');
  const boxDefs = [];
  const yearOf = new Date().getFullYear();
  types.forEach((t, i) => {
    boxDefs.push({
      box_code: `2026-${t.code}-001`,
      title: `2026 年${t.name}（一）`,
      type_code: t.code,
      year: String(yearOf),
      location: locIds[i % locIds.length],
    });
    if (i < 2) {
      boxDefs.push({
        box_code: `2025-${t.code}-002`,
        title: `2025 年${t.name}（二）`,
        type_code: t.code,
        year: '2025',
        location: locIds[(i + 2) % locIds.length],
      });
    }
  });

  let boxed = 0;
  boxDefs.forEach((b, idx) => {
    const cap = 60;
    const r = q.run(`INSERT INTO archive_boxes(box_code,title,type_code,year,location_id,capacity,barcode,remark,
                      created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
      b.box_code, b.title, b.type_code, b.year, b.location.id, cap, b.box_code, '',
      admin ? admin.id : null, now, now);
    const boxId = r.lastInsertRowid;
    // 每个盒里放 2~3 件，取该门类尚未装盒的档案
    const items = q.all(`SELECT id FROM archives WHERE type_code=? AND box_id IS NULL ORDER BY id LIMIT 3`, b.type_code);
    for (const it of items) {
      q.run('UPDATE archives SET box_id=?, location=?, updated_at=? WHERE id=?', boxId, b.location.code, now, it.id);
      boxed++;
    }
    if (idx === 0) {
      // 保证第一个盒至少有件（便于扫码与盘点体验）
      const more = q.all(`SELECT id FROM archives WHERE box_id IS NULL ORDER BY id LIMIT 2`);
      for (const it of more) {
        q.run('UPDATE archives SET box_id=?, location=?, updated_at=? WHERE id=?', boxId, b.location.code, now, it.id);
        boxed++;
      }
    }
  });
  console.log(`[演示数据] 已生成 ${locations.length} 个库位、${boxDefs.length} 个档案盒，装盒 ${boxed} 件`);
}

/** 为演示附件建立正文索引（附件是文本文件，可直接读取） */
function seedFileText(q, filesRoot) {
  if (!filesRoot) return;
  const { extractText } = require('../lib/text-extract');
  const fsx = require('node:fs');
  const pathx = require('node:path');
  const rows = q.all(`SELECT f.id, f.archive_id, f.original_name, f.rel_path FROM files f
                      WHERE f.id NOT IN (SELECT file_id FROM file_text)`);
  let ok = 0;
  const now = new Date().toISOString();
  for (const f of rows) {
    let buf;
    try { buf = fsx.readFileSync(pathx.join(filesRoot, f.rel_path)); } catch (_) { continue; }
    const r = extractText(buf, f.original_name);
    q.run(`INSERT INTO file_text(file_id,archive_id,content,char_count,status,kind,reason,extracted_at)
           VALUES(?,?,?,?,?,?,?,?)`,
      f.id, f.archive_id, r.text || '', (r.text || '').length,
      r.ok ? '成功' : '跳过', r.kind || '', r.reason || '', now);
    if (r.ok) ok++;
  }
  if (rows.length) console.log(`[演示数据] 已为 ${ok}/${rows.length} 个附件建立正文索引`);
}

/** 生成鉴定记录示例，让「到期与鉴定」页有内容 */
function seedAppraisals(q, admin) {
  const now = new Date().toISOString();
  // 取几件定期保管的档案，给出不同鉴定结论
  const periodic = q.all(`SELECT id, retention, year, title FROM archives
                          WHERE retention_years > 0 ORDER BY retention_due_year LIMIT 4`);
  const decisions = [
    ['延长保管期限', '定期30年', '仍有查考利用价值，同意延长保管期限', '鉴定小组一致同意延长'],
    ['继续保管', '', '未到处置时机，继续保管至期满', '一致同意继续保管'],
    ['建议销毁', '', '已超过保管期限，无继续保存价值', '一致同意提交销毁清册'],
    ['继续保管', '', '涉及未结事项，暂继续保管', '一致同意'],
  ];
  let n = 0;
  periodic.forEach((a, i) => {
    const [decision, newRet, basis, opinion] = decisions[i % decisions.length];
    // 建议销毁的走“已到期”语义，便于在销毁清册里演示
    q.run(`INSERT INTO appraisals(archive_id,decision,new_retention,basis,group_opinion,member_count,
            appraiser_id,appraiser,appraised_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,
      a.id, decision, newRet, basis, opinion, 3, admin ? admin.id : null,
      admin ? '系统管理员' : '档案员', now, now);
    if (decision === '延长保管期限') {
      const info = { code: 'D30', years: 30 };
      const y = Number(a.year) || new Date().getFullYear();
      q.run(`UPDATE archives SET retention=?, retention_code=?, retention_years=?, retention_due_year=?,
             status='在库', status_note=?, updated_at=? WHERE id=?`,
        newRet, info.code, info.years, y + info.years, `已鉴定：延长为${newRet}`, now, a.id);
    } else if (decision === '建议销毁') {
      q.run("UPDATE archives SET status='待销毁', status_note=?, updated_at=? WHERE id=?",
        '鉴定小组建议销毁，待审批', now, a.id);
    }
    n++;
  });
  if (n) console.log(`[演示数据] 已生成 ${n} 条鉴定记录（含延长、继续保管、建议销毁）`);
}

module.exports = { seedDemo, TITLES };
