/**
 * 跨平台就绪度检查（无需启动服务）
 *
 * 面向国产系统（麒麟 Kylin、统信 UOS、龙芯 LoongArch、飞腾/鲲鹏 ARM64）部署前的自查。
 * 这些问题在 Windows 上跑一万遍也发现不了，但一到 Linux 上就全暴露：
 *   · node:sqlite 的版本门槛（低于 22.13 直接起不来）
 *   · .sh 的行尾必须是 LF、不能带 BOM
 *   · 不能有任何平台特有的写死逻辑（Windows 字体、.bat、cmd）
 *   · 中文文件名、中文字体
 *
 * 用法：node server/tools/test-crossplatform.js
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..', '..');
const SRV = path.join(ROOT, 'server');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const read = (p) => fs.readFileSync(p, 'utf8');

// ---------------------------------------------------------------- 1
section('1. Node.js 版本门槛（node:sqlite 要求 ≥ 22.13）');
{
  const { checkNodeVersion, parseVersion, compareVersion } = require('../lib/node-version');

  check('能解析常见版本号', JSON.stringify(parseVersion('v22.16.0')) === '[22,16,0]'
    && JSON.stringify(parseVersion('24.20.0')) === '[24,20,0]', String(parseVersion('v22.16.0')));
  check('版本比较正确',
    compareVersion([22, 13, 0], [22, 12, 0]) === 1
    && compareVersion([22, 12, 0], [22, 13, 0]) === -1
    && compareVersion([22, 13, 0], [22, 13, 0]) === 0);

  // 能用的
  for (const v of ['24.20.0', '22.16.0', '22.13.0', 'v23.11.0']) {
    check(`接受 v${v}`, checkNodeVersion(v).ok);
  }
  // 不能用的（含国产系统常见自带版本）
  for (const v of ['18.20.8', '20.19.4', '21.7.3', '22.4.9', '22.12.0']) {
    const r = checkNodeVersion(v);
    check(`拒绝 v${v} 并给出提示`, !r.ok && r.message.length > 100, r.ok ? '竟然通过了' : '提示长度 ' + r.message.length);
  }
  // 提示里必须真的有可操作信息
  const low = checkNodeVersion('18.20.8').message;
  check('低版本提示含下载地址', /nodejs\.org/.test(low));
  check('低版本提示含龙芯适配地址（国产系统要用）', /loongnix\.cn|龙芯/.test(low));
  check('低版本提示含 ARM64 说明（飞腾/鲲鹏）', /arm64/i.test(low));
  const flag = checkNodeVersion('22.12.0').message;
  check('22.5~22.12 会提示可用 --experimental-sqlite 先跑', /--experimental-sqlite/.test(flag));
}

// ---------------------------------------------------------------- 2
section('2. 低版本 Node 上的友好报错（而不是 Cannot find module）');
{
  const db = read(path.join(SRV, 'db.js'));
  check('db.js 用 try/catch 包住 node:sqlite 的加载', /try\s*\{[\s\S]{0,80}require\('node:sqlite'\)/.test(db));
  check('加载失败时给出中文提示并退出', /process\.exit\(1\)/.test(db) && /checkNodeVersion/.test(db));

  const srv = read(path.join(SRV, 'server.js'));
  // 按「非注释行」的行号比较：注释里也会出现 require('./db') 字样，按字符串位置找会误判
  const codeLines = srv.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('//') && !l.startsWith('*'));
  const lineOf = (needle) => codeLines.findIndex((l) => l.includes(needle));
  const idxGuard = lineOf("require('./lib/node-version')");
  const idxDb = lineOf("require('./db')");
  check('server.js 在加载 db（即 node:sqlite）之前先做版本检查',
    idxGuard >= 0 && idxDb > idxGuard, `guard 在第 ${idxGuard + 1} 个有效行，db 在第 ${idxDb + 1} 个有效行`);
}

// ---------------------------------------------------------------- 3
section('3. Linux / 国产系统的启动脚本');
{
  const scripts = ['start.sh', 'start-lan.sh', 'backup.sh'];
  for (const name of scripts) {
    const p = path.join(ROOT, name);
    if (!fs.existsSync(p)) { check(`${name} 存在`, false); continue; }
    const buf = fs.readFileSync(p);
    const hasCR = buf.includes(13);
    const hasBom = buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf;
    check(`${name} 行尾为 LF（CRLF 会让 Linux 报 bad interpreter）`, !hasCR);
    check(`${name} 无 UTF-8 BOM`, !hasBom);
    check(`${name} 以 #!/bin/sh 开头`, buf.slice(0, 10).toString('utf8').startsWith('#!/bin/sh'));
    check(`${name} 会先切到脚本所在目录`, /cd "\$\(dirname "\$0"\)"/.test(buf.toString('utf8')));
  }

  const start = read(path.join(ROOT, 'start.sh'));
  check('start.sh 优先使用 runtime/node（若存在）', /runtime\/node/.test(start));
  check('start.sh 找不到 Node 时给出安装指引', /apt install nodejs/.test(start) && /linux-x64/.test(start));
  check('start.sh 给出龙芯（LoongArch）指引', /loongnix|龙芯/.test(start));

  const lan = read(path.join(ROOT, 'start-lan.sh'));
  check('start-lan.sh 绑定 0.0.0.0（否则手机连不上）', /--host 0\.0\.0\.0/.test(lan));
  check('start-lan.sh 会列出本机局域网地址', /hostname -I|ip -4 addr/.test(lan));
  check('start-lan.sh 提示放行防火墙', /firewall|防火墙/.test(lan));

  const bak = read(path.join(ROOT, 'backup.sh'));
  check('backup.sh 备份数据库、附件与二维码', /archive\.db/.test(bak) && /files/.test(bak) && /qrcodes/.test(bak));

  check('Linux 安装说明存在', fs.existsSync(path.join(ROOT, '安装说明-Linux.txt')));
}

// ---------------------------------------------------------------- 4
section('4. 零依赖 / 无原生模块（跨架构的前提）');
{
  const pkg = [];
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name === 'node_modules' || e.name === 'data' || e.name === 'release') continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name === 'package.json' || e.name.endsWith('.node')) pkg.push(path.relative(ROOT, p));
    }
  })(ROOT);
  check('没有 package.json、没有 .node 原生模块（换 CPU 架构不用重新编译）',
    pkg.length === 0, pkg.join(', '));

  const mods = new Set();
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) { if (e.name !== 'node_modules') walk(path.join(dir, e.name)); continue; }
      if (!e.name.endsWith('.js')) continue;
      const src = read(path.join(dir, e.name));
      for (const m of src.matchAll(/require\('node:([a-z_]+)'\)/g)) mods.add(m[1]);
    }
  })(path.join(SRV));
  // tls 是 v4.31.0「邮箱找回」用的（server/lib/mail.js），Node 内置且完全跨平台，不算可疑
  const bad = [...mods].filter((m) => !['http', 'https', 'tls', 'fs', 'path', 'os', 'crypto', 'zlib', 'sqlite',
    'child_process', 'vm', 'url', 'util', 'events', 'stream', 'buffer', 'assert', 'net'].includes(m));
  check('只用 Node 内置模块，且都是跨平台的', bad.length === 0, '可疑模块：' + bad.join(', '));
  const list = [...mods].sort().join(' ');
  console.log('    用到的内置模块：' + list);

  const db = read(path.join(SRV, 'db.js'));
  check('没有用 __dirname 拼 Windows 风格路径', !/\\\\server\\\\/.test(db));
}

// ---------------------------------------------------------------- 5
section('5. 平台相关代码都有分支（不能只写 Windows）');
{
  const srv = read(path.join(SRV, 'server.js'));
  check('打开浏览器有 Linux 分支（xdg-open）', /xdg-open/.test(srv));
  check('打开浏览器有 macOS 分支（open）', /'darwin'/.test(srv));

  const py = read(path.join(SRV, 'lib', 'python-qr.js'));
  check('Python 解释器候选区分 Windows / Linux', /win32/.test(py) && /python3/.test(py));
  check('查找 Python 时区分平台（Windows 有 py -3，Linux 用 python3）', /'py'/.test(py));
}

// ---------------------------------------------------------------- 6
section('6. 中文字体与中文文件名（国产系统上没有微软雅黑）');
{
  const css = read(path.join(ROOT, 'public', 'css', 'app.css'));
  check('前端字体栈含思源黑体（Source Han Sans SC）', /Source Han Sans SC/.test(css));
  check('前端字体栈含 Noto Sans CJK（麒麟/UOS 常见）', /Noto Sans CJK/.test(css));
  check('前端字体栈含文泉驿（许多国产系统默认装）', /WenQuanYi/.test(css));
  check('等宽字体也做了跨平台回退', /DejaVu Sans Mono/.test(css));

  const api = read(path.join(SRV, 'api.js'));
  check('打印视图字体栈含 Linux 中文字体', /Noto Sans CJK SC/.test(api) && /WenQuanYi/.test(api));

  const http = read(path.join(SRV, 'lib', 'http.js'));
  check('下载中文文件名用 RFC 5987 编码（跨浏览器/系统通用）', /filename\*=UTF-8''/.test(http));
}

// ---------------------------------------------------------------- 7
section('7. 前端脚本没有用到过新的语法（国产浏览器版本偏低）');
{
  const app = read(path.join(ROOT, 'public', 'js', 'app.js'));
  const tooNew = [
    ['可选链 ?.', /\?\.\s*[a-zA-Z[(]/, 'Chrome 80+'],
    ['空值合并 ??', /\?\?[^?]/, 'Chrome 80+'],
    ['replaceAll', /\.replaceAll\(/, 'Chrome 85+'],
    ['Object.fromEntries', /Object\.fromEntries/, 'Chrome 73+'],
    ['Array.prototype.flat', /\.flat\(/, 'Chrome 69+'],
    ['Array.prototype.at', /\.at\(-/, 'Chrome 92+'],
  ];
  for (const [name, re, need] of tooNew) {
    const m = app.match(re);
    check(`未使用 ${name}（需要 ${need}）`, !m, m ? '出现在：' + m[0] : '');
  }
  const idx = read(path.join(ROOT, 'public', 'index.html'));
  check('页面声明 UTF-8 编码', /<meta charset="utf-8">/i.test(idx));
  check('页面声明移动端视口（扫码落地页用）', /name="viewport"/.test(idx));
}

// ---------------------------------------------------------------- 8
section('8. 数据库与全文检索在目标平台可用');
{
  const sqlite = require('node:sqlite');
  const db = new sqlite.DatabaseSync(':memory:');
  let fts5 = false, trigram = false, why = '';
  try {
    db.exec("CREATE VIRTUAL TABLE t USING fts5(body, tokenize='trigram')");
    fts5 = trigram = true;
  } catch (e) { why = e.message; }
  check('当前 Node 内置 SQLite 支持 FTS5 + trigram 分词（中文全文检索依赖它）', fts5, why);
  let ver = '';
  try { ver = db.prepare('SELECT sqlite_version() AS v').get().v; } catch (_) { /* 忽略 */ }
  const nodeVer = db.prepare('SELECT 1 AS x') ? process.versions.node : '';
  console.log(`    当前环境：Node ${nodeVer}　内置 SQLite ${ver}`);
  db.close();
}

console.log('\n' + '='.repeat(60));
console.log(`跨平台就绪度检查：通过 ${pass} 项，失败 ${failed} 项`);
if (failed) fails.forEach((f) => console.log('  - ' + f));
console.log('='.repeat(60));
process.exit(failed ? 1 : 0);
