/**
 * 手机号找回口令 回归测试（v4.27.0）
 *
 * 用法：
 *   node server/tools/test-sms-login.js
 *       自己拉起一个临时服务（dev 短信通道 + 独立数据目录），跑完自动关掉。
 *   node server/tools/test-sms-login.js --url http://127.0.0.1:8911 --dev-log <文件>
 *       复用已在运行的服务。此时该服务必须以 dev 通道启动，且
 *       DSH_ARCHIVE_SMS_DEV_LOG 指向 <文件> —— 否则拿不到验证码，无法继续。
 *
 * 覆盖（对应《电子档案管理系统基本功能规定》第四十一条身份鉴别、
 * 档办发〔2017〕3号第三十八条口令管理、GB/T 39784—2021 第 8.2.3 身份鉴别）：
 *   1. 手机号格式校验、**一号一人**（重复登记被拒）
 *   2. 未登记号码：对外话术与已登记**完全一致**（不把登录页变成号码查询器）
 *   3. 三员账号不允许自助找回（短信不发出去）
 *   4. 发送冷却、当日上限
 *   5. 验证码最多尝试次数，超限即作废
 *   6. 验证码一次性：核销后重放无效
 *   7. 票据一次性：同一票据不能改两次口令
 *   8. 新口令仍走完整强度策略（弱口令 / 与原口令相同都拒绝）
 *   9. 重置成功后：旧口令失效、新口令可登录、旧会话被注销
 *
 * 两条容易踩的坑，脚本里刻意规避：
 *   · **绝不改动 admin 的口令**：本系统的口令策略禁止弱口令，把 admin 改回 admin123
 *     会被服务端 400 拒绝；而且后续套件都假定出厂口令 admin123。所以"被找回的账号"
 *     用一个临时建的账号，admin 只当操作者。
 *   · 收尾清理必须用**仍有效的会话**：重置口令会注销该账号的全部会话，
 *     若拿被重置账号自己的会话去收尾，后面每一步都会静默 401。
 *
 * 脚本结束时恢复被改动的设置、删除测试账号，可重复运行。
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const net = require('node:net');
const { spawn } = require('node:child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const argv = process.argv.slice(2);
function argOf(name) {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : '';
}

let BASE = argOf('--url');
let DEV_LOG = argOf('--dev-log') || process.env.DSH_ARCHIVE_SMS_DEV_LOG || '';
const TEST_DATA = path.join(APP_ROOT, '.regress-sms-data');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeSession(base) {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(base + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json, jar };
}

/** 从 dev 通道日志里取"发给该号码的最后一条验证码" */
function codeFromDevLog(phone) {
  let text = '';
  try { text = fs.readFileSync(DEV_LOG, 'utf8'); } catch (_) { return ''; }
  let code = '';
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const o = JSON.parse(line);
      if (String(o.phone) === String(phone)) code = String(o.code);
    } catch (_) { /* 跳过坏行 */ }
  }
  return code;
}

/** 等待 dev 通道把码写进日志（发送是异步返回的，落盘有极小延迟） */
async function waitCode(phone, ms = 3000) {
  const until = Date.now() + ms;
  for (;;) {
    const c = codeFromDevLog(phone);
    if (c) return c;
    if (Date.now() > until) return '';
    await sleep(100);
  }
}

async function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(0));
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(() => resolve(p));
    });
  });
}

async function waitPing(base, ms = 20000) {
  const until = Date.now() + ms;
  for (;;) {
    try {
      const r = await fetch(base + '/api/ping');
      const t = await r.text();
      if (t.includes('档案管理系统在运行')) return true;
    } catch (_) { /* 还没起来 */ }
    if (Date.now() > until) return false;
    await sleep(200);
  }
}

async function removeDirDeep(dir) {
  if (!fs.existsSync(dir)) return;
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 走兜底 */ }
  if (!fs.existsSync(dir)) return;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
    for (const it of items) {
      const p = path.join(d, it.name);
      if (it.isDirectory()) { walk(p); try { fs.rmdirSync(p); } catch (_) { /* ignore */ } }
      else { try { fs.unlinkSync(p); } catch (_) { /* ignore */ } }
    }
  };
  walk(dir);
  try { fs.rmdirSync(dir); } catch (_) { /* ignore */ }
}

const PHONE = '13800138000';      // 被测账号（victim）的号码
const PHONE3 = '13900139000';     // 三员账号的号码
const VICTIM_PWD = 'Archive@2026u';
const NEW_PWD = 'Archive@2026s';
const ADMIN_PWD_AFTER = 'Archive@2026a';   // admin 首改后的口令（仅存在于本套件的临时库里）
const TAG = Math.random().toString(16).slice(2, 7);

async function main() {
  let child = null;
  let devLog = DEV_LOG;

  if (!BASE) {
    // ---- 自建临时服务 ----
    await removeDirDeep(TEST_DATA);
    const port = await freePort();
    devLog = path.join(APP_ROOT, '.regress-sms-dev.log');
    // 关键：codeFromDevLog 读的是模块级的 DEV_LOG。自建服务这条路上原来只改了局部变量 devLog，
    // DEV_LOG 还停在 ''，于是"读验证码"永远返回空 —— 整套流程第二屏就断。
    DEV_LOG = devLog;
    try { fs.unlinkSync(devLog); } catch (_) { /* 第一次没有这个文件 */ }
    child = spawn(process.execPath, [
      path.join(APP_ROOT, 'server', 'server.js'),
      '--data', TEST_DATA, '--port', String(port), '--no-qr', '--no-scheduler', '--quiet',
    ], {
      cwd: APP_ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: Object.assign({}, process.env, {
        DSH_ARCHIVE_SMS_PROVIDER: 'dev',
        DSH_ARCHIVE_SMS_DEV: '1',
        DSH_ARCHIVE_SMS_SIGN: '档案管理系统',
        DSH_ARCHIVE_SMS_DEV_LOG: devLog,
      }),
    });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { out += d; });
    BASE = 'http://127.0.0.1:' + port;
    const okBoot = await waitPing(BASE);
    if (!okBoot) {
      console.error('服务没能启动，输出如下：\n' + out.slice(-2000));
      try { child.kill(); } catch (_) { /* ignore */ }
      process.exit(1);
    }
  }
  if (!devLog) {
    console.error('缺少 --dev-log：需要知道 dev 短信通道把验证码写到了哪个文件');
    process.exit(1);
  }

  // admin 只做"操作者"：建账号、配号码、看日志。它的口令全程不动。
  const admin = makeSession(BASE);
  const created = { users: [] };
  let settingsBefore = {};
  let victimId = 0;

  const keepKey = ['security.sms_resend_seconds', 'security.sms_daily_limit',
    'security.sms_max_attempts', 'security.sms_code_ttl_minutes', 'security.login_rate_per_minute'];

  async function restore() {
    try {
      const patch = {};
      for (const k of keepKey) if (settingsBefore[k] !== undefined) patch[k] = settingsBefore[k];
      if (Object.keys(patch).length) await admin.json('/api/settings', { method: 'PUT', json: patch });
      for (const id of created.users.slice()) {
        await admin.json('/api/users/' + id, { method: 'DELETE' });
      }
      created.users = [];
    } catch (e) {
      console.log('  （收尾时出现异常，不影响结论：' + e.message + '）');
    }
  }

  try {
    section('准备');
    const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
    check('管理员可登录', login.status === 200 && login.body.ok, 'HTTP ' + login.status + ' ' + (login.body.error || ''));
    if (!login.body.ok) throw new Error('前置失败：管理员登录不了，后续无从验证');
    // 本套件自建临时服务 + **独立数据目录**，库是 server.js 自己 seed 出来的：
    // v4.30.8 起出厂 admin 带 must_change=1，不先改密的话建号/改设置全被 403 拦住。
    // 这里改密只影响本套件这份临时库（跑完即删），不会波及同一次回归里别的套件；
    // 会话 token 在改密后依然有效，后面所有操作继续用 admin 这个会话。
    const adminChg = await admin.json('/api/me/password', {
      method: 'POST', json: { oldPassword: 'admin123', newPassword: ADMIN_PWD_AFTER },
    });
    check('出厂 admin 首改口令（走真人必经门禁）', adminChg.status === 200 && adminChg.body.ok,
      JSON.stringify(adminChg.body).slice(0, 140));

    const st = await admin.json('/api/settings');
    settingsBefore = (st.body.data && st.body.data.settings) || {};
    // 测试提速：冷却 1 秒、每日上限放宽；**故意不动 max_attempts**（要测 5 次上限）
    await admin.json('/api/settings', {
      method: 'PUT',
      json: { 'security.sms_resend_seconds': '1', 'security.sms_daily_limit': '50', 'security.login_rate_per_minute': '600' },
    });
    const st2 = await admin.json('/api/settings');
    check('短信相关设置项可被管理员修改',
      st2.body.data && st2.body.data.settings['security.sms_resend_seconds'] === '1',
      JSON.stringify(st2.body.data && st2.body.data.settings['security.sms_resend_seconds']));

    const info = await admin.json('/api/system/info');
    check('手机号找回已启用', !!(info.body.data && info.body.data.smsLogin && info.body.data.smsLogin.enabled));
    check('短信通道处于"已配置"', !!(info.body.data && info.body.data.smsLogin.configured),
      JSON.stringify(info.body.data && info.body.data.smsLogin));

    section('登记手机号');
    // 被测账号：单独建一个，避免动 admin
    let r = await admin.json('/api/users', {
      method: 'POST',
      json: { username: 'smsu' + TAG, password: VICTIM_PWD, role: 'admin', display_name: '找回测试账号' },
    });
    check('被测账号创建成功', r.status === 200 && r.body.ok, r.body.error);
    if (!r.body.ok) throw new Error('前置失败：被测账号建不出来');
    victimId = r.body.data.id;
    created.users.push(victimId);

    r = await admin.json('/api/users/' + victimId, { method: 'PUT', json: { phone: PHONE } });
    check('登记手机号成功', r.status === 200 && r.body.ok, r.body.error);
    r = await admin.json('/api/users/' + victimId, { method: 'PUT', json: { phone: '138-0013-8000' } });
    check('带短横线的号码被规范化后仍算同一个号（不被当成新号占用）', r.status === 200 && r.body.ok, r.body.error);
    r = await admin.json('/api/users/' + victimId, { method: 'PUT', json: { phone: '12345' } });
    check('非法手机号被拒', r.status === 400 && /11 位手机号/.test(r.body.error || ''), r.body.error);

    r = await admin.json('/api/users', {
      method: 'POST',
      json: { username: 'smsdup' + TAG, password: 'Archive@2026d', role: 'reader', phone: PHONE },
    });
    check('同一手机号不能登记到第二个账号', r.status === 400 && /已登记/.test(r.body.error || ''), r.body.error);
    if (r.body.ok) created.users.push(r.body.data.id);

    section('发送验证码');
    let s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: '13512345678' } });
    check('未登记号码：返回与已登记完全相同的应答（不泄露号码是否存在）',
      s.status === 200 && s.body.ok && s.body.data.sent === true, JSON.stringify(s.body));
    const ghost = await waitCode('13512345678', 400);
    check('未登记号码：确实没有短信发出', ghost === '', ghost);

    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: PHONE } });
    check('已登记号码：发送成功', s.status === 200 && s.body.ok && s.body.data.sent === true, JSON.stringify(s.body));
    const code1 = await waitCode(PHONE);
    check('dev 通道收到 6 位验证码', /^\d{6}$/.test(code1), code1);

    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: PHONE } });
    check('冷却期内重发被挡下并给出剩余秒数',
      s.status === 200 && s.body.data && s.body.data.sent === false && s.body.data.retryAfterSeconds > 0,
      JSON.stringify(s.body.data));

    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: '12345' } });
    check('非法手机号发送被拒', s.status === 400, s.body.error);

    section('三员账号不允许自助找回');
    const three = await admin.json('/api/users', {
      method: 'POST',
      json: { username: 'smssec' + TAG, password: 'Archive@2026q', role: 'secadmin', phone: PHONE3 },
    });
    check('安全保密员账号创建成功', three.status === 200 && three.body.ok, three.body.error);
    if (three.body.ok) created.users.push(three.body.data.id);
    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: PHONE3 } });
    check('三员号码：对外仍是同一句"已发送"', s.status === 200 && s.body.ok, JSON.stringify(s.body));
    const threeCode = await waitCode(PHONE3, 500);
    check('三员号码：短信没有真的发出（禁止自助找回）', threeCode === '', threeCode);

    section('验证码校验');
    let v = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: '000000' } });
    check('错误验证码被拒', v.status === 400 && /不正确或已过期/.test(v.body.error || ''), v.body.error);
    v = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: '123' } });
    check('非 6 位验证码被拒', v.status === 400 && /6 位数字/.test(v.body.error || ''), v.body.error);

    // 连错到上限：第 5 次错完之后，再试正确码也必须失败（码已作废）
    for (let i = 0; i < 4; i++) {
      await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: '111111' } });
    }
    v = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: code1 } });
    check('连续输错达上限后，正确码也不再放行（防穷举）',
      v.status === 400 && /次数过多|不正确或已过期/.test(v.body.error || ''), v.body.error);

    // 重新拿一条新码，走正常路径
    await sleep(1100);
    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: PHONE } });
    check('冷却结束后可以重新发送', s.body.data && s.body.data.sent === true, JSON.stringify(s.body.data));
    const code2 = await waitCode(PHONE);
    check('拿到新的验证码', /^\d{6}$/.test(code2) && code2 !== code1, code2);

    v = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: code2 } });
    check('正确验证码通过', v.status === 200 && v.body.ok && !!v.body.data.ticket, JSON.stringify(v.body).slice(0, 200));
    check('验证码通过时一并下发口令规则（供第三步显示）', !!(v.body.data && v.body.data.passwordPolicy));
    const ticket = (v.body.data && v.body.data.ticket) || '';

    v = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: code2 } });
    check('同一验证码不能二次使用（一次性）', v.status === 400, v.body.error);

    section('设置新口令');
    // 找一个**独立的会话**来调 reset：reset 成功会给调用方下发登录 Cookie，
    // 若借用 admin 的会话去调，admin 的 Cookie 会被换成被测账号的 ——
    // 后面所有"管理员操作"就都变成了"被测账号在操作"（收尾删自己时报 400）。
    const rc = makeSession(BASE);
    let rs = await rc.json('/api/login/sms/reset', { method: 'POST', json: { ticket, newPassword: '12345678' } });
    check('弱口令被拒（策略没有被"找回"这条路绕开）',
      rs.status === 400 && /弱口令|纯数字|长度/.test(rs.body.error || ''), rs.body.error);
    rs = await rc.json('/api/login/sms/reset', { method: 'POST', json: { ticket, newPassword: NEW_PWD } });
    check('强口令设置成功并直接建立会话', rs.status === 200 && rs.body.ok && !!rs.body.data.token, JSON.stringify(rs.body).slice(0, 200));
    const fresh = makeSession(BASE);
    // 把上面那次成功建立的会话搬到 fresh 上（同一浏览器视角）：直接用它拿到的 cookie 不行，
    // 这里改成重新登录一次，顺便验证新口令可用
    const newLogin = await fresh.json('/api/login', { method: 'POST', json: { username: 'smsu' + TAG, password: NEW_PWD } });
    check('新口令登录成功', newLogin.status === 200 && newLogin.body.ok, newLogin.body.error);
    check('找回后不再要求强制改密（已经设过了）',
      !!(newLogin.body.data && newLogin.body.data.user && Number(newLogin.body.data.user.must_change) === 0),
      JSON.stringify(newLogin.body.data && newLogin.body.data.user));
    const me = await fresh.json('/api/me');
    check('新会话可用（/api/me 200）', me.status === 200 && me.body.ok
      && me.body.data.user.username === 'smsu' + TAG);

    rs = await makeSession(BASE).json('/api/login/sms/reset', { method: 'POST', json: { ticket, newPassword: NEW_PWD + 'x' } });
    check('同一票据不能再用一次（票据一次性）', rs.status === 400 && /失效/.test(rs.body.error || ''), rs.body.error);

    rs = await makeSession(BASE).json('/api/login/sms/reset', { method: 'POST', json: { ticket: 'a'.repeat(48), newPassword: NEW_PWD } });
    check('伪造的票据被拒', rs.status === 400, rs.body.error);

    section('口令真的换了');
    const oldLogin = await makeSession(BASE).json('/api/login', {
      method: 'POST', json: { username: 'smsu' + TAG, password: VICTIM_PWD },
    });
    check('旧口令登录失败', oldLogin.status === 401, 'HTTP ' + oldLogin.status);
    // 重置前签发的会话必须被注销
    const victimOld = makeSession(BASE);
    const pre = await victimOld.json('/api/login', { method: 'POST', json: { username: 'smsu' + TAG, password: NEW_PWD } });
    check('（准备）重置前可以正常登录', pre.status === 200);
    // 再重置一次，验证"旧会话被踢掉"
    await sleep(1100);
    s = await admin.json('/api/login/sms/send', { method: 'POST', json: { phone: PHONE } });
    const code3 = await waitCode(PHONE);
    const v3 = await admin.json('/api/login/sms/verify', { method: 'POST', json: { phone: PHONE, code: code3 } });
    const ticket3 = (v3.body.data && v3.body.data.ticket) || '';
    const rs3 = await makeSession(BASE).json('/api/login/sms/reset', { method: 'POST', json: { ticket: ticket3, newPassword: 'Archive@2026t' } });
    check('可以再次走完整流程（重复使用不受限）', rs3.status === 200 && rs3.body.ok, rs3.body.error);
    const stale = await victimOld.json('/api/me');
    check('重置后该账号的旧会话已失效', stale.status === 401, 'HTTP ' + stale.status);

    section('审计留痕');
    const logs = await admin.json('/api/logs?size=200');
    const actions = ((logs.body.data && logs.body.data.list) || []).map((x) => String(x.action || ''));
    check('日志记录了"已发送验证码"', actions.some((a) => a.includes('已发送验证码')), actions.slice(0, 5).join(' / '));
    check('日志记录了"验证码重置口令"', actions.some((a) => a.includes('验证码重置口令')));
    check('日志记录了"验证码错误"', actions.some((a) => a.includes('验证码错误')));
    check('日志记录了"号码不可用"（未登记/三员）', actions.some((a) => a.includes('号码不可用')));
    const chain = await admin.json('/api/logs/verify');
    check('日志链仍然完整（找回流程没有破坏哈希链）', !!(chain.body.data && chain.body.data.ok === true));

    section('收尾');
    const del = await admin.json('/api/users/' + victimId, { method: 'DELETE' });
    check('被测账号可删除', del.status === 200 && del.body.ok, del.body.error);
    if (del.body.ok) created.users = created.users.filter((x) => x !== victimId);
  } catch (e) {
    failed++;
    fails.push('异常中断：' + e.message);
    console.log('  ✗ 异常中断：' + e.message);
  } finally {
    await restore();
    if (child) {
      try { child.kill(); } catch (_) { /* ignore */ }
      await sleep(300);
      await removeDirDeep(TEST_DATA);
      try { fs.unlinkSync(devLog); } catch (_) { /* ignore */ }
    }
  }

  console.log('\n通过 ' + pass + ' 项，失败 ' + failed + ' 项');
  if (failed) {
    console.log('失败项：');
    for (const f of fails) console.log('  · ' + f);
  }
  process.exit(failed ? 1 : 0);
}

main();
