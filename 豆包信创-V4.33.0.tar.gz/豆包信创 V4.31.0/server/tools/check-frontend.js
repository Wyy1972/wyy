/**
 * 前端静态检查：验证 index.html 中的 id 与 app.js 的选择器一致、资源可访问
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(path.join(ROOT, 'public', 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'public', 'css', 'app.css'), 'utf8');
const js = fs.readFileSync(path.join(ROOT, 'public', 'js', 'app.js'), 'utf8');
const serverSrc = fs.readFileSync(path.join(ROOT, 'server', 'server.js'), 'utf8');
const apiSrc = fs.readFileSync(path.join(ROOT, 'server', 'api.js'), 'utf8');

const htmlIds = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]));
// 运行时动态创建的元素同样算“存在”
for (const m of js.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)) htmlIds.add(m[1]);
for (const m of js.matchAll(/\.id\s*=\s*'([A-Za-z0-9_-]+)'/g)) htmlIds.add(m[1]);
for (const m of js.matchAll(/setAttribute\('id',\s*'([A-Za-z0-9_-]+)'\)/g)) htmlIds.add(m[1]);
// el('div', { id: 'x' }) 这种对象字面量写法也要认（v4.20.10）：
// 它是本项目自己的惯用法，不认就会把"动态创建的 id"误报成"HTML 里不存在"。
for (const m of js.matchAll(/\bid:\s*'([A-Za-z0-9_-]+)'/g)) htmlIds.add(m[1]);
const jsSelectors = new Set([...js.matchAll(/\$\$?\('#([A-Za-z0-9_-]+)/g)].map((m) => m[1]));

const missing = [...jsSelectors].filter((id) => !htmlIds.has(id));
const cssClasses = new Set([...css.matchAll(/\.([a-zA-Z][a-zA-Z0-9_-]*)/g)].map((m) => m[1]));
const jsClasses = new Set();
for (const m of js.matchAll(/class:\s*'([^']+)'/g)) {
  m[1].split(/\s+/).filter(Boolean).forEach((c) => jsClasses.add(c));
}
for (const m of js.matchAll(/class="([^"$]+)"/g)) {
  m[1].split(/\s+/).filter(Boolean).forEach((c) => jsClasses.add(c));
}
const undefinedClasses = [...jsClasses].filter((c) => !cssClasses.has(c) && !c.startsWith('tag ') && c !== 'hidden');

const referencedAssets = [...html.matchAll(/(?:href|src)="(\/[^"]+)"/g)].map((m) => m[1]);
const missingAssets = referencedAssets.filter((a) => {
  if (a.startsWith('/api/')) return false;
  // 去掉 ?v=<版本号> 之类的查询串再看文件在不在（v4.20.8 起资源带版本号）
  return !fs.existsSync(path.join(ROOT, 'public', a.split('?')[0].replace(/^\//, '')));
});

// 启动脚本与安装说明**也不许印口令**（v4.20.5）。
//
// 起因：登录页那句"出厂口令是某某"让使用者照着填、必然被拒（手机端连错 7 次）。
// 修完登录页后一查，发现同一个坑还散落在启动脚本和安装说明里 ——
// 它们同样会印一个"可能早就被改过"的值，而且安装说明还在教人填用户名，
// 可登录页从 v4.19.0 起就没有用户名框了。
//
// 判据刻意从紧：启动横幅（server/lib/banner.js）是**先验哈希再决定印不印**的，
// 那才是唯一该出口令的地方，脚本自己再印一份纯属重复且必然过期。
const LAUNCHER_FILES = ['start.sh', 'start-lan.sh', '双击启动-档案管理系统.bat',
  '启动档案管理系统.bat', '启动（含演示数据）.bat', '局域网访问.bat', '备份数据.bat',
  '安装说明.txt', '安装说明-Linux.txt'];
const launcherIssues = [];
for (const f of LAUNCHER_FILES) {
  const p = path.join(ROOT, f);
  if (!fs.existsSync(p)) { launcherIssues.push(`${f} 不见了`); continue; }
  const buf = fs.readFileSync(p);
  const text = buf.toString('utf8');
  if (/admin123|admin888|admin@123/.test(text)) {
    launcherIssues.push(`${f}: 印着出厂口令字面值`);
  }
  if (/默认账号|初始账号|default account/i.test(text)) {
    launcherIssues.push(`${f}: 又出现"默认账号"式硬编码提示`);
  }
  // .bat 必须纯 ASCII：cmd 在非 UTF-8 代码页下会把中文 echo 成乱码方块，
  // 而启动失败时这行提示正是最需要看清的东西。
  if (f.endsWith('.bat') && buf.some((b) => b > 127)) {
    launcherIssues.push(`${f}: 含非 ASCII 字节（.bat 必须纯 ASCII）`);
  }
}
console.log('启动脚本/安装说明不印口令       :', launcherIssues.length ? launcherIssues.join('；') : 'ok');

console.log('index.html 中的 id 数量        :', htmlIds.size);
console.log('app.js 引用的 #id 数量         :', jsSelectors.size);
console.log('app.js 引用但 HTML 不存在的 id :', missing.length ? missing.join(', ') : '（无）');
console.log('app.js 用到但 CSS 未定义的类   :', undefinedClasses.length ? undefinedClasses.join(', ') : '（无）');
console.log('HTML 引用的静态资源缺失        :', missingAssets.length ? missingAssets.join(', ') : '（无）');

// 用 V8 真实编译一次，确保语法完全合法（比手工数括号可靠）
let syntaxOk = true, syntaxErr = '';
try {
  new (require('node:vm').Script)(js, { filename: 'app.js' });
} catch (e) {
  syntaxOk = false;
  syntaxErr = e.message;
}
console.log('app.js 语法编译               :', syntaxOk ? 'ok' : '失败 -> ' + syntaxErr);
console.log('app.js 行数                    :', js.split('\n').length);

// 服务端每个 .js 也必须真实编译一遍（v4.20.9 补）。
//
// 起因是一次真实的翻车：用 PowerShell 的 `Set-Content -NoNewline` 批量替换版本号，
// 结果把 server.js **整个文件拼成了一行** —— 那样每一处 `//` 行注释都会吞掉后面全部代码。
// 当时手工 `node --check` 只查了 app.js 与 api.js，没查 server.js，
// 差点把这种文件同步进交付包。这里一次性覆盖 server/ 下所有 .js，
// 让"文件被写坏"在**静态检查**阶段就暴露，而不是等临时服务起不来。
const vmMod = require('node:vm');
const badSyntax = [];
(function walkServer(absDir, relDir) {
  for (const e of fs.readdirSync(absDir, { withFileTypes: true })) {
    if (e.name === '__pycache__' || e.name.startsWith('.')) continue;
    const rel = relDir ? relDir + '/' + e.name : e.name;
    const abs = path.join(absDir, e.name);
    if (e.isDirectory()) { walkServer(abs, rel); continue; }
    if (!e.name.endsWith('.js')) continue;
    try {
      new vmMod.Script(fs.readFileSync(abs, 'utf8'), { filename: rel });
    } catch (err) {
      badSyntax.push(rel + ' -> ' + err.message.split('\n')[0]);
    }
  }
})(path.join(ROOT, 'server'), '');
console.log('server/ 全部 .js 语法编译      :', badSyntax.length ? badSyntax.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 连续著录的"不带入"保证（v4.13.0）
//
// 为什么用静态检查盯住它：带着上一次的公共信息录新档案，是"录错档案"里最难发现的一类
// （门类/期限录错，连档号都是错的，界面上却一切正常）。所以这条保证值得一道护栏：
//   · renderCreate 必须按参数决定要不要沿用（wantCarry）
//   · 不沿用时必须把 carryOver 清掉
//   · 只允许"保存并录下一条"这一条路径带 carry:1，其余入口一律干净开始
// 将来若有人"顺手简化"成总是沿用，这里会立刻红。
const carryIssues = [];
if (!/function renderCreate\(params\)/.test(js)) carryIssues.push('renderCreate 未接收 params（无法区分入口）');
if (!/const wantCarry = !!\(params && params\.carry\)/.test(js)) carryIssues.push('renderCreate 里没有 wantCarry 判定');
if (!/if \(!wantCarry\) \{ carryOver = null; batchCount = 0; \}/.test(js)) carryIssues.push('不沿用时没有清空 carryOver');
{
  const withCarry = (js.match(/setView\('create', \{ carry: 1 \}\)/g) || []).length;
  const plain = (js.match(/setView\('create'\)/g) || []).length;
  if (withCarry !== 1) carryIssues.push(`带 carry:1 的入口应恰好 1 处（实际 ${withCarry} 处）`);
  if (plain < 1) carryIssues.push('没有"干净开始"的入口（setView(\'create\')）');
}
console.log('连续著录「不带入」保证          :', carryIssues.length ? carryIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 两套导入模板的入口（v4.14.0）
//
// 精简版是默认（9 列，必填 3 列）；全字段版是"从别的系统整库迁移"的活路。
// **两个入口都必须留着** —— 少任何一个都会有一类使用者无表可依：
// 只留全字段版则新用户第一眼就是 33 列（正是这次要修的问题），
// 只留精简版则迁移的人手里那 20 多列无处可对。所以用静态检查钉住这一对。
const tplIssues = [];
if (!/id="btn-tpl"/.test(js) || !/window\.location\.href = '\/api\/import\/template'/.test(js)) {
  tplIssues.push('缺少精简模板下载入口');
}
if (!/id="btn-tpl-full"/.test(js) || !/\/api\/import\/template\?kind=full/.test(js)) {
  tplIssues.push('缺少全字段模板下载入口');
}
if (!/多余的列可以整列删掉/.test(js)) tplIssues.push('界面上没有说明"多余的列可以删"');
console.log('导入模板两个入口               :', tplIssues.length ? tplIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 样式表的两类"说不出哪里不对"的错（v4.15.0）
//
// 这两类错都不会报错、不会白屏，只会让版面看起来"就是不太对"，所以最容易被留着：
//   ① **用了没定义的 CSS 变量**。`background: var(--x)` 在 --x 不存在时**整条声明作废**，
//      元素直接变成透明 —— 版面重做前 --c-bg-2 就是这样：二维码区块、分面胶囊、
//      连续著录提示条、仪表页数字块四处同时失去底色，但谁也说不清是哪里少了什么。
//   ② **同一个选择器被定义两次**。后写的静默覆盖前写的，而且往往只覆盖一部分属性：
//      重做前 .stat 被仪表页的规则覆盖成"居中的透明块"，工作台的统计卡片跟着一起变样。
//
// 判定重复时只数**顶层规则**：@media / @supports 里的重复是正常的（响应式就该这么写），
// 逗号组选择器（`input, select, textarea { }`）也算一个整体，不拆开数。
function topLevelSelectors(cssText) {
  const text = cssText.replace(/\/\*[\s\S]*?\*\//g, '');
  const out = [];
  let depth = 0;
  let start = 0;
  let sel = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '{') {
      const head = text.slice(start, i).trim();
      if (depth === 0) {
        if (/^@/.test(head)) {           // @media / @supports：整块跳过
          let d = 1;
          let j = i + 1;
          while (j < text.length && d > 0) { if (text[j] === '{') d++; else if (text[j] === '}') d--; j++; }
          i = j - 1;
          start = i + 1;
          continue;
        }
        sel = head;
      }
      depth++;
      continue;
    }
    if (ch === '}') {
      depth--;
      if (depth === 0 && sel !== null) { out.push(sel); sel = null; }
      start = i + 1;
    }
  }
  return out;
}

const cssIssues = [];
{
  const bare = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const definedVars = new Set([...css.matchAll(/^\s*(--[a-z0-9-]+)\s*:/gim)].map((m) => m[1]));
  // 变量可能在 CSS、JS 内联样式或 index.html 里被用到，三处都要算
  const usedVars = new Map();
  for (const [src, where] of [[bare, 'app.css'], [js, 'app.js'], [html, 'index.html']]) {
    for (const m of src.matchAll(/var\(\s*(--[a-z0-9-]+)/g)) {
      if (!usedVars.has(m[1])) usedVars.set(m[1], new Set());
      usedVars.get(m[1]).add(where);
    }
  }
  const undef = [...usedVars].filter(([v]) => !definedVars.has(v));
  if (undef.length) cssIssues.push('未定义的变量：' + undef.map(([v, w]) => `${v}（${[...w].join('/')}）`).join('、'));

  const counts = new Map();
  for (const s of topLevelSelectors(css)) counts.set(s, (counts.get(s) || 0) + 1);
  const dups = [...counts].filter(([, c]) => c > 1);
  if (dups.length) cssIssues.push('重复定义的选择器：' + dups.map(([s, c]) => `${s} ×${c}`).join('、'));

  // 花括号必须配平：少一个会把后面所有规则吞进一个坏块里，页面直接走样
  const open = (bare.match(/\{/g) || []).length;
  const close = (bare.match(/\}/g) || []).length;
  if (open !== close) cssIssues.push(`花括号不配平（${open} 开 / ${close} 闭）`);

  console.log(`样式表：${topLevelSelectors(css).length} 条顶层规则、${definedVars.size} 个变量、`
    + `变量未定义/选择器重复：${cssIssues.length ? '有问题' : '无'}`);
}
console.log('样式表变量与重复选择器          :', cssIssues.length ? cssIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 手机端抽屉导航（v4.15.0）
//
// 此前 ≤720px 时侧栏是 display:none —— **手机上根本没有导航**，登录后只能停在工作台。
// 现在靠三样东西成立：☰ 按钮切 body.nav-open、遮罩负责收回、每个菜单项都归属一个分组。
// 少任何一样，"手机上能不能换页"就会悄悄退回不可用，所以这里逐项钉住。
const drawerIssues = [];
for (const id of ['btn-nav', 'nav-scrim']) {
  if (!new RegExp(`id="${id}"`).test(html)) drawerIssues.push(`index.html 里缺少 #${id}`);
}
if (!/function setNavDrawer\(open\)/.test(js)) drawerIssues.push('app.js 里没有 setNavDrawer');
if (!/classList\.toggle\('nav-open'/.test(js)) drawerIssues.push('抽屉状态没有落到 body.nav-open');
if (!/id="btn-nav"[\s\S]{0,400}?onclick = \(\) => setNavDrawer/.test(js) && !/navBtn\.onclick = \(\) => setNavDrawer/.test(js)) {
  drawerIssues.push('☰ 按钮没有绑定开合');
}
if (!/body\.nav-open \.sidebar \{ transform: none/.test(css)) drawerIssues.push('CSS 里没有"抽屉滑出"规则');
if (!/\.topbar-nav-btn \{ display: inline-flex/.test(css)) drawerIssues.push('CSS 里没有"小屏显示汉堡按钮"规则');
{
  const items = [...html.matchAll(/class="nav-item"[^>]*data-view="([^"]+)"[^>]*data-sec="([^"]+)"/g)].map((m) => [m[1], m[2]]);
  const secs = new Set([...html.matchAll(/class="nav-sec"[^>]*data-sec="([^"]+)"/g)].map((m) => m[1]));
  const views = [...html.matchAll(/class="nav-item"/g)].length;
  if (items.length !== views) drawerIssues.push(`有 ${views - items.length} 个菜单项没写 data-sec`);
  const orphan = items.filter(([, s]) => !secs.has(s));
  if (orphan.length) drawerIssues.push('菜单项的分组没有对应标题：' + orphan.map(([v, s]) => `${v}→${s}`).join('、'));
  for (const s of secs) {
    if (!items.some(([, x]) => x === s)) drawerIssues.push(`分组标题 ${s} 下面一个菜单项都没有`);
  }
  if (!/整组菜单都被权限滤掉/.test(js)) drawerIssues.push('没有处理"整组被权限隐藏时的空标题"');
}
console.log('手机端抽屉导航                 :', drawerIssues.length ? drawerIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 启动画面必须"撤得掉"（v4.16.0）
//
// 启动画面唯一不可原谅的错就是撤不掉 —— 那会把使用者永远挡在登录页外面，
// 而且是他自己无法处理的（刷新也一样）。所以这里钉三件事：
//   ① 元素存在；② **两条**路径都撤（已登录走 showApp、未登录走登录分支）；
//   ③ 还有一个与网络无关的兜底超时 —— 万一第一次请求卡住，也必须能进去。
const bootIssues = [];
if (!/id="boot-splash"/.test(html)) bootIssues.push('index.html 缺少 #boot-splash');
if (!/function hideBootSplash\(\)/.test(js)) bootIssues.push('app.js 里没有 hideBootSplash');
{
  const calls = (js.match(/hideBootSplash\(\);/g) || []).length;
  if (calls < 2) bootIssues.push(`撤除调用应至少 2 处（已登录 / 未登录），实际 ${calls} 处`);
  if (!/setTimeout\(hideBootSplash, \d+\)/.test(js)) bootIssues.push('没有与网络无关的兜底超时');
}
if (!/\.boot-splash \{/.test(css)) bootIssues.push('CSS 里没有 .boot-splash');
if (!/\.boot-splash\.done/.test(css)) bootIssues.push('CSS 里没有撤除后的 .done 状态');
console.log('启动画面可撤除                 :', bootIssues.length ? bootIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 说明文档必须能在浏览器里打开（v4.16.1）
//
// 本机 `assoc .md` 没有关联，双击 .md 会报「文件资源不可用」。使用者会本能地
// 去双击那个 .md 文件，所以光在分发包里放 .html/.txt 不够 —— 必须让文档
// **在系统里用网页直接打开**（/docs/ 路由 + 「系统信息」页的按钮），跟文件关联彻底解耦。
// 少任何一端，使用者又会退回"双击 .md → 报错"的老路。
const docIssues = [];
if (!/\/docs\/使用说明\.html/.test(js) || !/\/docs\/升级说明\.html/.test(js)) {
  docIssues.push('app.js 里缺少使用说明 / 升级说明的网页入口');
}
// v4.20.6：文档还要能给 Word 与记事本两种形式 —— 使用者明确要求过，
// 而且它们是唯一不依赖文件关联的"拿走"路径。
for (const ext of ['docx', 'txt']) {
  if (!new RegExp(`/docs/升级说明\\.${ext}`).test(js)) {
    docIssues.push(`app.js 里缺少升级说明的 .${ext} 下载入口`);
  }
}
if (!/\(html\|txt\|docx\)/.test(serverSrc)) {
  docIssues.push('server.js 的 /docs/ 路由没有同时提供 html/txt/docx');
}
// 静态资产必须带 ?v=<版本号>，且必须与 server.js 的 VERSION 一致（v4.20.8）。
//
// 起因值得留一笔：手机浏览器把 /js/app.js 缓存住了，服务端已经换成新版，
// 手机上跑的却还是旧代码 —— 于是"已经修好的下载"在手机上依然是老行为，
// 使用者看到的现象和修复前一模一样，怎么看都像"没修"。
// 版本号变了 URL 才变，缓存才会失效；守卫钉住"两处版本号必须一起改"。
//
// ⚠ 这段必须放在 docIssues 声明**之后**：它要往 docIssues 里 push，
//   放到前面会踩 const 的暂时性死区 —— 版本号一致时不触发所以"看着没问题"，
//   一旦真不一致整个脚本直接抛 ReferenceError，守卫反而比没有更糟（v4.20.8 自查发现）。
const assetVers = [...html.matchAll(/(?:href|src)="\/(?:js|css)\/[^"?]+\?v=([^"&]+)"/g)].map((m) => m[1]);
const serverVersion = (/const VERSION = '([^']+)'/.exec(serverSrc) || [])[1];
if (assetVers.length < 2) {
  docIssues.push('index.html 的 js/css 资源没有带 ?v=<版本号>（手机会一直用缓存的旧代码）');
} else if (assetVers.some((v) => v !== serverVersion)) {
  docIssues.push(`index.html 的资源版本号(${assetVers.join(' / ')})与 server.js 的 VERSION(${serverVersion}) 不一致`);
}

// 内置浏览器（微信/QQ/钉钉…）不能下载文件，必须**认出来并给出路**（v4.20.10）。
// 这条守卫钉住"别把这套识别悄悄删掉"：删了之后手机在微信里点下载，
// 又会退回到"点了没反应、也不知道为什么"的状态。
if (!/MicroMessenger/.test(js) || !/function inAppBrowser/.test(js) || !/function webViewNotice/.test(js)) {
  docIssues.push('app.js 缺少"应用内置浏览器"识别与提示（微信里将无法下载且不给解释）');
}
if (!/webview-notice/.test(css)) {
  docIssues.push('app.css 缺少 .webview-notice 样式');
}
// 附件行的按钮顺序就是优先级（v4.24.0）：最高频的「预览」必须排在最前，
// 编辑类动作（上移/下移/替换/识别/删除）排到最后。
// 这条守卫防的是"以后往前面插按钮"——把预览又挤回按钮堆中间。
{
  const row = /<div class="file-item"[\s\S]*?<\/div>`/.exec(js);
  const tpl = row ? row[0] : '';
  const iPreview = tpl.indexOf('data-fact="preview"');
  const iUp = tpl.indexOf('data-fact="up"');
  const iDel = tpl.indexOf('data-fact="del"');
  if (iPreview < 0 || iUp < 0 || iDel < 0) {
    docIssues.push('附件行模板结构变了（守卫找不到预览/上移/删除），请核对后更新守卫');
  } else if (!(iPreview < iUp && iUp < iDel)) {
    docIssues.push('附件行按钮顺序被改了：「预览」应排在最前、编辑类动作排在最后');
  }
  if (!/wvNow \? '复制链接' : '下载'/.test(js)) {
    docIssues.push('内置浏览器里「下载」按钮没有改成「复制链接」（微信里点下载只会白点一下）');
  }
  if (!/copyText\(link\)/.test(js)) {
    docIssues.push('内置浏览器的下载分支没有直接复制链接（应一点即复制，不要再弹一层对话框）');
  }
  // 登录页必须提前提醒"内置浏览器不能下载"（v4.25.0）：
  // 等到登录之后才说，使用者已经白折腾一轮了。
  if (!/id="login-webview-hint"/.test(html)) {
    docIssues.push('登录页缺少内置浏览器提醒的容器（id="login-webview-hint"）');
  }
  if (!/login-webview-hint/.test(js)) {
    docIssues.push('app.js 没有按内置浏览器填充登录页提醒');
  }
}
if (!/\/docs\//.test(serverSrc) || !/使用说明|升级说明/.test(serverSrc)) {
  docIssues.push('server.js 里没有 /docs/ 文档路由');
}
console.log('说明文档网页入口               :', docIssues.length ? docIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// v4.26.x 的四项能力各自的"命根子"（v4.26.2 ~ v4.26.8 事后补的守卫）
//
// ⚠ 这四条**是补的**：v4.26.2~v4.26.8 当初只做了功能、只跑了全量回归，
//   没有为它们写任何断言 —— 于是删掉之后回归**照样全绿**。
//   "回归全绿"只能证明"已断言的部分没坏"，不能证明"新功能还在"。
//   每条守卫都做过反向验证（注入坏值 → 必须变红）。
const v426Issues = [];
{
  // ① 悬停"瞄一眼"（v4.26.2）：延迟出现 + 位置钳制。
  // 为什么钉这两点：不加延迟则鼠标划过一排附件会连弹好几次；
  // 不钳制位置则最后一行文件的浮层会被窗口底边截掉一半（等于看不见）。
  if (!/id: 'hover-peek'/.test(js)) {
    v426Issues.push('app.js 没有悬停小浮层（#hover-peek，v4.26.2 的"瞄一眼"不见了）');
  } else if (!/hov = setTimeout\(/.test(js) || !/innerWidth - W/.test(js)) {
    v426Issues.push('悬停浮层缺少延迟出现与位置钳制（会连弹 / 会被窗口底边截掉）');
  }
  // ② 登录页版本号（v4.26.3）必须是**服务端下发**的。
  // 这里防的是"又写死一个号"：写死必过期，登录页印的版本就成了假信息 ——
  // 使用者报问题时会照着它说，反而把人带偏（v4.20.5 印作废口令就是同一类错）。
  if (!/id="login-version"/.test(html) || !/login-version/.test(js)) {
    v426Issues.push('登录页没有版本号容器或 app.js 没去填（v4.26.3：报问题前先能看见版本）');
  } else if (!/fetch\('\/api\/ping'/.test(js)) {
    v426Issues.push('登录页版本号不是从 /api/ping 取的（写死的版本号一定会过期）');
  }
  // ③ "先看再传"的正文提取（v4.26.4）**只许提取、不许落盘**。
  // 界面上写着"预览不会在服务器上留下任何东西"，那是给使用者的承诺；
  // 如果这个接口偷偷写了库，承诺就成了假话。
  if (!/POST', '\/api\/preview-extract'/.test(apiSrc) || !/preview-extract/.test(js)) {
    v426Issues.push('缺少"先看再传"的正文提取接口 /api/preview-extract（v4.26.4：Excel/Word 传之前看不了）');
  } else {
    const blk = apiSrc.split("'/api/preview-extract'")[1] || '';
    const body = blk.slice(0, 1400);
    if (!/textExtract\.extractText/.test(body)) v426Issues.push('preview-extract 没有复用正文提取器');
    if (/\b(INSERT|UPDATE|DELETE)\b/i.test(body)) {
      v426Issues.push('preview-extract 里出现了写库语句（它承诺"只提取、不落盘"）');
    }
  }
  // ④ "用本机程序打开"（v4.26.5）是个能执行文件的能力，三条约束一条都不能少：
  //    只许本机访问、扩展名走白名单、留有审计痕迹。
  const ob = apiSrc.split("'/api/files/:id/open-local'")[1] || '';
  const openBlk = ob.slice(0, 2200);
  if (!/POST', '\/api\/files\/:id\/open-local'/.test(apiSrc)) {
    v426Issues.push('缺少"用本机程序打开"接口（v4.26.5）');
  } else {
    // ⚠ 这里钉"整条约束还在"，不钉某一行的完整写法：
    //   曾经写成 `/\bisLocal\b/`，结果把 `const isLocal = …` 也算作通过 ——
    //   注入坏值（把 `if (!isLocal)` 改成 `if (false)`）时它依然是绿的。
    //   守卫要跟着**约束**走，不能跟着**标识符**走。
    if (!/const isLocal\s*=/.test(openBlk) || !/127\.0\.0\.1/.test(openBlk)) {
      v426Issues.push('open-local 没有限制"只许本机访问"（等于局域网里谁都能在服务器上弹程序）');
    }
    if (!/OPEN_LOCAL_EXT/.test(openBlk) || !/OPEN_LOCAL_DENY/.test(openBlk)) {
      v426Issues.push('open-local 没有扩展名白名单/黑名单校验（等于开了"传上来就能执行"的口子）');
    }
    if (!/log\(u,/.test(openBlk)) v426Issues.push('open-local 没有写审计日志（事后查不出谁打开过什么）');
  }
  // ⑤ 扫码诊断（v4.26.8）**只观察、不判定**。
  // 这一条是整段历史里最该钉死的：有一版凭推断改了这里（忽略 ev.repeat、提前
  // preventDefault），把正常扫码改坏了，两轮往返才退回来。
  // 所以：ev.repeat 只许出现在诊断里，绝不许出现在任何判定的条件里。
  if (!/__dshScanDiag/.test(js) || !/scanDiag/.test(js)) {
    v426Issues.push('app.js 没有扫码诊断（v4.26.8：扫码出问题时无从判断是哪一环）');
  } else {
    // ev.repeat **只许用于统计**，不许拿来拦按键：`if (ev.repeat) return` 正是
    // v4.26.6 那一版干的事（凭推断"过滤自动重复"），结果把正常扫码一起滤掉了。
    // 注意别把诊断自己那句 `if (ev.repeat) scanDiag.sawRepeat = true;` 误判成拦截 ——
    // 判定标准是"条件成立后到底做了什么"：凡是**拦断/改写**按键流的，一律不放行。
    const repGate = /if\s*\(\s*ev\.repeat\s*\)\s*(?:return|continue|break\b|ev\.preventDefault|ev\.stopPropagation|\{[^}]*(?:return|preventDefault|stopPropagation))/;
    const repOr = /ev\.repeat\s*(?:\?|&&|\|\|)/;
    if (repGate.test(js) || repOr.test(js)) {
      v426Issues.push('扫码判定里又出现了基于 ev.repeat 的拦截（v4.26.6 就是这么把正常扫码改坏的）');
    }
    // 兜底：诊断只需要读几次 ev.repeat，出现太多次就说明有人在拿它做判定
    const repCount = (js.match(/ev\.repeat/g) || []).length;
    if (repCount > 2) {
      v426Issues.push(`app.js 里 ev.repeat 出现了 ${repCount} 次（诊断只需 1~2 次，多半又被拿去判定了）`);
    }
    if (!/workbench.*scanner|扫码诊断/.test(js) || !/renderScanLog/.test(js)) {
      v426Issues.push('扫码诊断没有在工作台里显示（只记不显等于没做）');
    }
  }
}
console.log('v4.26.x 四项能力守卫           :', v426Issues.length ? v426Issues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 单位名在"服务端横幅"与"前端品牌位"两处必须一致（v4.16.2）
//
// 单位名（广州市南沙区排水和污水处理事务中心）写在 server.js（控制台横幅）和
// index.html（启动画面 / 侧栏 / 登录页）两个文件里 —— index.html 是静态页，
// 服务端没有模板注入，所以这两处必须手动保持一致。一旦只改了一边，
// 就会出现"黑窗口一个名、网页一个名"的尴尬，所以钉一个守卫。
const orgIssues = [];
const orgName = '广州市南沙区排水和污水处理事务中心';
if (!html.includes(orgName)) orgIssues.push('index.html 里没有单位名');
if (!serverSrc.includes(orgName)) orgIssues.push('server.js 里没有单位名（ORG_NAME）');
console.log('单位名两处一致                 :', orgIssues.length ? orgIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 角色定义只许有一处（v4.16.3）
//
// api.js 里曾藏着一份只有 3 个旧角色的 ROLES/ROLE_NAMES 副本，而 lib/policy.js
// 才是权威的 6 个角色（含三员 sysadmin/secadmin/auditor）。两份表并存造成：
// 用户列表里三员角色名空白、审计日志写「undefined｜密级上限=机密」、
// 合规体检写「三员尚未配齐：、 暂无账号」—— 全部实测复现过。
// 角色与角色名**只能来自 policy**，本文件与前端兜底表都只是引用者。
const roleIssues = [];
if (!/const ROLES = policy\.ROLES;/.test(apiSrc) || !/const ROLE_NAMES = policy\.ROLE_NAMES;/.test(apiSrc)) {
  roleIssues.push('api.js 没有复用 policy.ROLES / policy.ROLE_NAMES（不许在本文件另写一份角色表）');
}
{
  const front = /roleNames:\s*\{([^}]*)\}/.exec(js);
  const names = front ? front[1] : '';
  const missing = ['admin', 'sysadmin', 'secadmin', 'auditor', 'clerk', 'reader'].filter((r) => !new RegExp(`\\b${r}\\s*:`).test(names));
  if (missing.length) roleIssues.push('app.js 的角色名兜底表缺：' + missing.join('、'));
}
// 菜单权限必须由服务端下发（v4.17.0）：前端不许再写死"哪个角色看不到哪些菜单"。
// 曾经那张写死的清单只处理了普通用户，导致安全审计员能看到档案著录、导入导出等
// 全部菜单，点进去才发现没权限 —— 界面与实际权限对不上的典型症状。
if (!/state\.views/.test(js)) roleIssues.push('app.js 没有使用服务端下发的 state.views 控制菜单');
if (/hideForReader/.test(js)) roleIssues.push('app.js 里又出现了写死的菜单权限清单（应由服务端下发）');
console.log('角色定义单一来源               :', roleIssues.length ? roleIssues.join('；') : 'ok');

// ---------------------------------------------------------------------------
// 登录页的「身份」下拉必须与服务端一致（v4.18.0）
//
// 登录页只暴露两种身份（档案管理员 / 其他人员）。选项直接写在 index.html 里
// （不等接口返回再填，接口慢或失败时登录页仍然能用），所以两边必须对齐：
// 服务端加了身份而登录页没有 → 那种账号根本登不进来；
// 登录页写了服务端不认识的身份 → 提交就被 400 拒掉。这道守卫盯的就是这两头。
const idIssues = [];
{
  const m = /const LOGIN_IDENTITIES = \[([\s\S]*?)\n\];/.exec(apiSrc);
  const pairs = m ? [...m[1].matchAll(/key:\s*'([^']+)',\s*label:\s*'([^']+)'/g)].map((x) => [x[1], x[2]]) : [];
  if (!pairs.length) idIssues.push('api.js 里没有 LOGIN_IDENTITIES');
  const sel = /<select name="identity" id="login-identity"[\s\S]*?<\/select>/.exec(html);
  if (!sel) idIssues.push('index.html 登录页没有身份下拉');
  else {
    for (const [k, label] of pairs) {
      if (!new RegExp(`<option value="${k}"[^>]*>${label}</option>`).test(sel[0])) {
        idIssues.push(`登录页缺少身份选项「${label}」`);
      }
    }
    const n = (sel[0].match(/<option /g) || []).length;
    if (n !== pairs.length) idIssues.push(`登录页有 ${n} 个身份选项，服务端有 ${pairs.length} 个`);
  }
  // 登录页只要「身份 + 口令」两个框（v4.19.0）。用户明确要求去掉用户名 ——
  // 加回来会让"一人一账号"和"身份口令"两种理解混在一起，钉一道防止回退。
  if (/id="login-username"/.test(html)) {
    idIssues.push('登录页又出现了用户名输入框（v4.19.0 起只要「身份 + 口令」两个框）');
  }
  if (!/id="login-password"/.test(html)) idIssues.push('登录页缺少密码输入框');
  // 登录页不许印任何口令（v4.20.5）。原来它印着一句"出厂口令是某某"，
  // 而真实部署的口令早就改过 —— 使用者照填必被拒，还只得到一句"用户名或密码错误"，
  // 怎么也想不到是提示本身在骗他（手机端连续多次失败的根因就是这个）。
  // 口令该由服务端**验过哈希**再决定要不要印（启动横幅就是这么做的），页面没有这个条件。
  // 顺带：HTML 注释也会随页面发到浏览器，所以注释里同样不许出现。
  const comments = (html.match(/<!--[\s\S]*?-->/g) || []).join('\n');
  const body = html.replace(/<!--[\s\S]*?-->/g, '');
  const LEAK = /admin123|admin888|admin@123/i;
  const PRINTED = /(出厂|默认)(口令|密码)[^\n<]{0,12}[：:＝=]\s*[^\s<）)、。]{4,}/;
  const leaks = [];
  if (LEAK.test(body)) leaks.push('页面正文里有出厂口令字面值');
  if (PRINTED.test(body)) leaks.push('页面正文里印着具体口令');
  if (LEAK.test(comments)) leaks.push('HTML 注释里有出厂口令字面值');
  if (PRINTED.test(comments)) leaks.push('HTML 注释里印着具体口令');
  if (leaks.length) {
    idIssues.push(`登录页出现口令痕迹（v4.20.5 起一律不印）：${leaks.join('、')}`);
  }
  if (!/档案管理员分配的口令/.test(body)) {
    idIssues.push('登录页提示没写"用档案管理员分配的口令"（v4.20.5 的措辞，别改回印具体值）');
  }
}
console.log('登录身份与服务端一致           :', idIssues.length ? idIssues.join('；') : 'ok');

const fail = missing.length || undefinedClasses.length || missingAssets.length || !syntaxOk
  || badSyntax.length
  || carryIssues.length || tplIssues.length || cssIssues.length || drawerIssues.length
  || bootIssues.length || docIssues.length || orgIssues.length || roleIssues.length || idIssues.length
  || launcherIssues.length || v426Issues.length;
console.log('\n前端静态检查结果：' + (fail ? '发现问题' : '全部通过'));
process.exit(fail ? 1 : 0);
