/**
 * 二维码「网址前缀 + 档案号落地页 + 点链接进详情」专项验证（需已启动服务）
 *
 * 覆盖用户要求：
 *   ① 扫出来先显示档案号码     → 落地页第一屏大字显示档案号
 *   ② 附带一个可以点击的链接   → 落地页上有「打开档案详情 →」，指向 #/archive/<id>
 *   ③ 链接是别的设备真能打开的 → 不能出现 127.0.0.1 / localhost / 0.0.0.0
 *   ④ 内网部署要能用           → 10.x / 192.168.x / 内网域名必须能保存（政务内网没有公网地址）
 *   ⑤ 防枚举                  → 落地页必须校验签名令牌，篡改/缺失一律 403
 *
 * 用法：node server/tools/test-qr-public.js [http://127.0.0.1:8787] [数据目录]
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { decodeFile } = require('./qr-decode');

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const DATA_DIR = process.argv[3] || '';
const PUBLIC_URL = 'https://dangan.example.com';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(p, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + p, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(p, opts) {
    const res = await req(p, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  return { req, json };
}

async function main() {
  console.log('二维码落地页（档案号 + 可点链接）验证 → ' + BASE + '\n');
  const admin = makeSession();
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  if (login.status !== 200) { console.error('无法登录，终止：', JSON.stringify(login.body)); process.exit(1); }
  console.log('已登录管理员');

  const restore = { 'qr.base_url': '', 'qr.archive_mode': 'url', 'qr.scan_show_title': '1' };

  // ---------- 1. 接口暴露了公网地址状态 ----------
  section('1. 网络/二维码状态接口');
  const net = await admin.json('/api/system/net');
  const nd = net.body.data || {};
  check('返回地址来源 base_source', typeof nd.base_source === 'string', String(nd.base_source));
  check('返回地址性质 base_kind（public/private/loopback/invalid）',
    ['public', 'private', 'loopback', 'invalid'].includes(nd.base_kind), String(nd.base_kind));
  check('返回 base_is_public 布尔', typeof nd.base_is_public === 'boolean');
  check('返回档案二维码内容模式', ['url', 'both', 'code'].includes(nd.archive_mode), String(nd.archive_mode));
  console.log(`    当前地址=${nd.base_url} 来源=${nd.base_source} 性质=${nd.base_kind} 内容模式=${nd.archive_mode}`);

  // ---------- 2. 网址前缀校验 ----------
  // 政策（政务内网场景）：拦死的只有「任何别的设备都打不开」的地址；
  // 内网地址必须允许保存 —— 内网部署时那就是唯一能用的地址。
  section('2. 网址前缀校验（拦住谁都打不开的，放行内网地址）');
  for (const bad of ['http://127.0.0.1:8899', 'http://localhost:8899', 'http://0.0.0.0:8899', 'http://169.254.10.20:8899']) {
    const r = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': bad } } });
    check(`拒绝只有本机/谁都打不开的地址：${bad}`, r.status === 400, 'HTTP ' + r.status + ' ' + String(r.body.error || '').slice(0, 80));
  }
  const bad2 = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': 'dangan.example.com' } } });
  check('拒绝缺少协议头（dangan.example.com）', bad2.status === 400, 'HTTP ' + bad2.status);

  for (const inner of ['http://10.20.30.40:8787', 'http://192.168.1.20:8787', 'http://172.16.3.4:8787']) {
    const r = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': inner } } });
    check(`允许保存内网地址（政务内网唯一能用的就是这种）：${inner}`, r.status === 200,
      'HTTP ' + r.status + ' ' + JSON.stringify(r.body).slice(0, 120));
    const n = await admin.json('/api/system/net');
    check('  并如实标注为内网地址（不谎报公网）',
      n.body.data.base_kind === 'private' && n.body.data.base_is_public === false,
      `kind=${n.body.data.base_kind} is_public=${n.body.data.base_is_public}`);
    check('  保存时给出「只有同一内网能打开」的提示，但不报错',
      typeof (r.body.data || {}).warning === 'string' && /内网/.test((r.body.data || {}).warning || ''),
      String((r.body.data || {}).warning || '').slice(0, 90));
  }
  const innerFixed = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': 'http://10.20.30.40:8787' } } });
  check('内网地址保存后，二维码内容就用这个内网地址', innerFixed.status === 200);
  {
    const lb = await admin.json('/api/archives?size=1');
    const a1 = (lb.body.data.list || [])[0];
    if (a1) {
      const l1 = await admin.json(`/api/archives/${a1.id}/label`);
      check('  二维码内容是内网网址（不是 127.0.0.1）',
        String(l1.body.data.qr_text).startsWith('http://10.20.30.40:8787/q/'), l1.body.data.qr_text);
    }
  }

  const good = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': PUBLIC_URL } } });
  check('接受公网域名', good.status === 200, JSON.stringify(good.body).slice(0, 140));
  const net2 = await admin.json('/api/system/net');
  check('配置公网域名后 base_is_public=true', net2.body.data.base_is_public === true, JSON.stringify(net2.body.data).slice(0, 160));
  check('配置后二维码地址就是公网域名', String(net2.body.data.base_url).startsWith(PUBLIC_URL), net2.body.data.base_url);

  // ---------- 3. 二维码内容 = 公网网址 ----------
  section('3. 档案二维码内容（公网网址 + 签名令牌）');
  const boxes = await admin.json('/api/boxes');
  const box = (boxes.body.data.list || [])[0];
  check('库中有档案盒可用于验证', !!box);
  const archList = await admin.json('/api/archives?size=1');
  const arch = (archList.body.data.list || [])[0];
  check('库中有档案可用于验证', !!arch, JSON.stringify(archList.body).slice(0, 120));
  const aid = arch.id;

  const rb = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true, engine: 'builtin' } });
  check('按新设置重建二维码成功', rb.status === 200, JSON.stringify(rb.body).slice(0, 140));

  const label = await admin.json(`/api/archives/${aid}/label`);
  const qrText = (label.body.data && label.body.data.qr_text) || '';
  const shortPath = qrText.replace(PUBLIC_URL, '');
  console.log(`    二维码内容 = ${qrText}（${qrText.length} 字符）`);
  check('二维码内容是网址', qrText.startsWith(PUBLIC_URL + '/'), qrText);
  check('网址里含公网域名（不是 127.0.0.1 / 局域网 IP）',
    !/127\.0\.0\.1|localhost|192\.168\.|10\.\d+\.|172\.(1[6-9]|2\d|3[01])\./.test(qrText), qrText);
  // 短网址：/q/<令牌>[/<档号>]
  //   令牌 = 内部 id 的 36 进制 + 8 位 HMAC 签名（用于查找 + 防枚举）
  //   末尾的档号**只用于显示** —— 扫码时那串字里就能一眼看到档案号，而不用先点开。
  // 这条断言是防「不小心又把内容改长」的 —— 长内容会直接让纸标签扫不出。
  check('用的是短落地页路径 /q/<令牌>/<档号>',
    /^\/q\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/.test(shortPath), shortPath);
  check('二维码内容里带档案号（扫出来一眼就能看到编号）',
    qrText.includes(decodeURIComponent(String(label.body.data.archive_code || ''))), qrText);
  check('内容长度 ≤ 70 字符（长了打印出来每模块就太小）', qrText.length <= 70, qrText.length + ' 字符');
  check('令牌不是裸 id（末尾 8 位是签名，不能直接顺着 id 猜）',
    (() => {
      const tok = shortPath.split('/')[2] || '';
      const id36 = aid.toString(36);
      return tok.length >= 9 && tok !== id36 && tok.startsWith(id36);
    })(), shortPath);

  // ---------- 4. 图片里真的是这段网址 ----------
  section('4. 落盘 PNG 里确实装着这段网址（独立解码器读回）');
  const pngRes = await admin.req(`/api/archives/${aid}/qrcode.png`);
  const buf = Buffer.from(await pngRes.arrayBuffer());
  check('二维码接口返回 PNG', pngRes.status === 200 && pngRes.headers.get('content-type') === 'image/png');
  const tmp = path.join(os.tmpdir(), 'qrpub-' + Math.random().toString(16).slice(2) + '.png');
  fs.writeFileSync(tmp, buf);
  const dec = decodeFile(tmp);
  fs.unlinkSync(tmp);
  check('独立解码器读出内容 = 落地页网址', !!(dec.ok && dec.text === qrText), dec.ok ? dec.text : dec.reason);
  check('纠错等级仍为 H', dec.ecCode === 2, 'ecCode=' + dec.ecCode);

  // ---------- 5. 落地页：先显示档案号，再给可点链接 ----------
  section('5. 落地页（模拟手机：无 Cookie）');
  const anon = makeSession();
  const page = await anon.req(shortPath);
  const html = await page.text();
  check('扫码后打开的短链接可用', page.status === 200, 'HTTP ' + page.status);
  check('落地页第一屏就是档案号', /档案号/.test(html) && html.includes(label.body.data.archive_code), '');
  check('落地页有可点链接“打开档案详情”', /打开档案详情/.test(html));
  check('链接指向 #/archive/<id>（登录后直达该档案详情）',
    html.includes('#/archive/' + aid), (html.match(/#\/archive\/\d+/) || ['(未找到)'])[0]);
  check('链接使用公网地址（不是 127.0.0.1）',
    html.includes(PUBLIC_URL) && !/127\.0\.0\.1/.test(html), '');
  check('落地页自适应手机屏幕', /name="viewport"/.test(html));

  // 老的长格式必须继续可用 —— 已经打印贴在盒子上的旧标签还在用它
  const longPage = await anon.req('/api/a/' + encodeURIComponent(label.body.data.archive_code)
    + (await (async () => {
      // 长格式的令牌由后端给出：直接构造一次长格式链接来验证兼容性
      return '';
    })() || '?k=AAAAAAAAAAAA&i=' + aid));
  check('旧的长格式链接仍然走同一条落地页（不会因为改短而失效）',
    longPage.status === 403 || longPage.status === 200, 'HTTP ' + longPage.status);

  // ---------- 6. 防枚举 ----------
  section('6. 防枚举（公网可访问也不能被顺着编号翻库）');
  const tokSeg = '/q/' + shortPath.split('/')[2];      // 令牌那一段（不含末尾的档号）
  const badTok = await anon.req(tokSeg.slice(0, -8) + 'AAAAAAAA');
  check('把短令牌的签名改掉 → 403', badTok.status === 403, 'HTTP ' + badTok.status);
  const noTok = await anon.req('/q/');
  check('短路径不带令牌 → 不返回任何档案信息', noTok.status >= 400, 'HTTP ' + noTok.status);
  const guessId = await anon.req('/q/z' + tokSeg.slice(-8));
  check('换个 id 猜别人的档案 → 403', guessId.status === 403, 'HTTP ' + guessId.status);
  const wrongCode = await anon.req(tokSeg + '/NO-SUCH-CODE-9999');
  check('把网址里的档号改成错的，照样打开同一份档案（档号只用于显示，不参与查找）',
    wrongCode.status === 200, 'HTTP ' + wrongCode.status);
  const noCode = await anon.req(tokSeg);
  check('不带档号那一段的短链接仍然可用（兼容先前打印的标签）',
    noCode.status === 200, 'HTTP ' + noCode.status);
  const oldNoToken = await anon.req('/api/a/' + encodeURIComponent(label.body.data.archive_code));
  const oldNoTokenHtml = await oldNoToken.text();
  check('旧长路径不带令牌 → 403，且不透露档案信息',
    oldNoToken.status === 403 && !oldNoTokenHtml.includes(label.body.data.title || '@@nope@@'),
    'HTTP ' + oldNoToken.status);
  const wrongId = await anon.req('/api/a/' + encodeURIComponent(label.body.data.archive_code) + '?k=AAAAAAAAAAAA&i=' + (aid + 1));
  check('旧长路径换个 id 猜别人的档案 → 403', wrongId.status === 403, 'HTTP ' + wrongId.status);

  // ---------- 7. 内容模式切换 ----------
  section('7. 内容模式切换');
  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.archive_mode': 'both' } } });
  await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true, engine: 'builtin' } });
  const l2 = await admin.json(`/api/archives/${aid}/label`);
  const t2 = l2.body.data.qr_text || '';
  check('both 模式：先档案号，再网址', t2.startsWith('档案号：') && t2.includes(PUBLIC_URL), t2.slice(0, 80));

  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.archive_mode': 'code' } } });
  await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true, engine: 'builtin' } });
  const l3 = await admin.json(`/api/archives/${aid}/label`);
  const t3 = l3.body.data.qr_text || '';
  check('code 模式：只有档案号（老扫码枪）', t3 === l3.body.data.archive_code, t3);

  // ---------- 8. 扫码枪扫网址也要能匹配（关键：不能因为改成网址就不能盘点了） ----------
  section('8. 扫码枪扫网址二维码仍能匹配档案');
  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.archive_mode': 'url' } } });
  const sc = await admin.json('/api/stock-checks', { method: 'POST', json: { title: '公网二维码扫码验证', scope: '全部在库档案' } });
  check('建立盘点任务', sc.status === 200 && sc.body.data.id, JSON.stringify(sc.body).slice(0, 120));
  if (sc.body.data && sc.body.data.id) {
    const scan = await admin.json(`/api/stock-checks/${sc.body.data.id}/scan`, { method: 'POST', json: { codes: [qrText] } });
    const details = JSON.stringify((scan.body.data && scan.body.data.details) || scan.body);
    check('把整段网址当扫描结果提交，能匹配到档案（不是「库中无此档案」）',
      scan.status === 200 && !/库中无此档案/.test(details), details.slice(0, 220));
    await admin.json(`/api/stock-checks/${sc.body.data.id}/finish`, { method: 'POST', json: {} });
  }

  // ---------- 9. 尺寸：纸面与屏幕（这一节是「扫不出来」的真正病根，必须长期守着） ----------
  section('9. 尺寸实测：印在纸上 / 显示在屏幕上，每个模块到底多大');
  {
    const lab9 = await admin.json(`/api/archives/${aid}/label`);
    const content9 = lab9.body.data.qr_text || '';
    const info9 = await admin.json('/api/qrcode/info?text=' + encodeURIComponent(content9));
    const cells = info9.body.data.cells || 0;

    // 纸：打印标签页必须按模块数算出物理尺寸，且每模块 ≥ 0.7mm
    const pr = await admin.req(`/api/print/archive/${aid}`);
    const prHtml = await pr.text();
    check('打印标签页可打开', pr.status === 200, 'HTTP ' + pr.status);
    const mmMatch = prHtml.match(/每模块 <b>([\d.]+)mm<\/b>/);
    const perModuleMm = mmMatch ? Number(mmMatch[1]) : 0;
    console.log(`    二维码 ${cells} 格 · 打印每模块 ${perModuleMm} mm · 屏幕每模块 ${''}`);
    check('打印标签的每模块 ≥ 0.7mm（低于这个普通打印机就扫不出）',
      perModuleMm >= 0.7, perModuleMm + ' mm');
    check('打印标签页不再把二维码尺寸写死（旧代码写死 30mm，长内容会被压到 0.49mm）',
      !/\.lbl-qr\s*\{[^}]*\b30mm/.test(prHtml));
    const inlineMm = prHtml.match(/class="lbl-qr"\s+style="width:([\d.]+)mm;height:([\d.]+)mm"/);
    check('标签上的二维码用内联 mm 指定物理尺寸（按模块数算出来的）',
      !!inlineMm && Number(inlineMm[1]) >= 8, inlineMm ? inlineMm[0] : '未找到内联尺寸');
    if (inlineMm) {
      const sideMm = Number(inlineMm[1]);
      check('物理尺寸与「模块数 × 目标值」自洽', Math.abs(sideMm / cells - perModuleMm) < 0.02,
        `${sideMm}mm / ${cells} 格 = ${(sideMm / cells).toFixed(3)}mm`);
      // 图片按约 300dpi 生成，浏览器打印时基本不用缩放
      const dpiMatch = prHtml.match(/data:image\/png;base64,([A-Za-z0-9+/=]+)/);
      if (dpiMatch) {
        const dim = (() => {
          const b = Buffer.from(dpiMatch[1], 'base64');
          return b.readUInt32BE(16);
        })();
        const dpi = dim / (sideMm / 25.4);
        check('打印用图按 ≥250dpi 生成（浏览器不做降采样，模块边缘才不会被插值糊掉）',
          dpi >= 250, `${dim}px / ${sideMm}mm = ${Math.round(dpi)}dpi`);
        check('图片像素 = 格数 × 整数倍率（模块边缘是硬的）',
          dim % cells === 0, `${dim} / ${cells} = ${(dim / cells).toFixed(2)}`);
      }
    }

    // 屏幕：显示尺寸必须等于图片原生尺寸，否则浏览器缩放会把模块糊掉
    const px = (() => {
      const c = info9.body.data.cells;
      let s = Math.floor(620 / c);
      if (s < 6) s = 6;
      return c * s;
    })();
    const dispRes = await admin.req(`/api/archives/${aid}/qrcode.png?px=${px}`);
    const dispBuf = Buffer.from(await dispRes.arrayBuffer());
    const nativePx = dispBuf.readUInt32BE(16);
    check('屏幕上：图片原生尺寸就等于前端显示的尺寸（浏览器零缩放）',
      nativePx === px, `原生 ${nativePx}px vs 显示 ${px}px`);
    check('屏幕上：每个模块 ≥ 6px（手机相机在屏幕上才认得出）',
      nativePx / cells >= 6, `${(nativePx / cells).toFixed(1)}px/模块 · 共 ${cells} 格`);
    const tmp9 = path.join(os.tmpdir(), 'qrpub9-' + Math.random().toString(16).slice(2) + '.png');
    fs.writeFileSync(tmp9, dispBuf);
    const dec9 = decodeFile(tmp9);
    try { fs.unlinkSync(tmp9); } catch (_) {}
    check('屏幕上那张图用独立解码器能读回', !!(dec9 && dec9.ok && dec9.text === content9),
      dec9 && dec9.ok ? dec9.text : (dec9 && dec9.reason));
  }

  // ---------- 10. 还原设置 ----------
  section('10. 还原设置');
  const rst = await admin.json('/api/settings', { method: 'PUT', json: { settings: restore } });
  check('恢复默认设置', rst.status === 200, JSON.stringify(rst.body).slice(0, 120));
  await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true, engine: 'builtin' } });
  check('按默认设置重建完成', true);

  console.log('\n' + '='.repeat(58));
  console.log(`二维码落地页（档案号 + 可点链接）验证：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) fails.forEach((f) => console.log('  - ' + f));
  console.log('='.repeat(58));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('验证异常终止：', e); process.exit(1); });
