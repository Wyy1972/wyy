#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
档案二维码批量生成（Python · qrcode 库）
================================================================

为库里每一份档案生成一张二维码 PNG，按档号自动命名，供打印后贴在卷皮/档案盒上。

【二维码参数】（默认值与系统内置引擎一致，可用命令行覆盖）
    纠错率   ERROR_CORRECT_H  ≈ 30% 容错，标签磨花一角也能读
    留白     border = 6       静区模块数（QR 规范最低要求 4，多留一圈更保险）
    码点大小 box_size = 15    每个模块 15 像素
    格式     PNG

【命名规则】（与系统内置引擎完全一致，切换引擎不会产生重复文件）
    规范档号 archive_number  →  短档案号 archive_code  →  题名 title  →  「档案<id>」
    文件名里的 \\ / : * ? " < > | 与控制字符会替换成下划线，末尾的点与空格去掉，最长 80 字

【二维码内容】
    短档案号 archive_code 优先，其次规范档号 —— 必须是「系统能直接识别的编号」，
    这样扫码枪扫出来可以直接在盘点/检索里匹配到档案。不要把题名放进去。

【输出】
    <数据目录>/qrcodes/<名字>.png      每份档案一张
    <数据目录>/qrcodes/清单.csv        UTF-8 BOM，Excel 双击不乱码

【关于模式优化】
    qrcode 库会自动为内容选择最优编码模式：像 Z001-WS-2025-0001 这种纯大写字母+数字
    会走「字母数字模式」（2 字符/11 位），比字节模式省很多，因此版本更低、码更小、
    打印出来单个模块更大、更好扫。含中文或小写字母时会自动退回字节模式。

【被系统调用】
    档案管理系统启动时会自动调用本脚本（见 server/lib/python-qr.js），
    所以正常情况下你不需要手动运行它。

【手动运行】
    python generate_qrcodes.py --data "D:\\档案管理系统\\data"
    python generate_qrcodes.py --data "D:\\档案管理系统\\data" --force
    python generate_qrcodes.py --data "D:\\档案管理系统\\data" --report out.json
"""

import argparse
import base64
import csv
import hashlib
import hmac
import json
import os
import re
import sqlite3
import sys
from urllib.parse import quote

# ---------------- 二维码参数 ----------------
# 默认值与系统内置引擎保持一致；档案管理系统调用时会用 --border / --box-size
# 把「系统设置」里的值传进来（qr.border / qr.box_size），保证两个引擎参数不会跑偏。
EC_LEVEL_NAME = "H"          # ERROR_CORRECT_H
BORDER = 6                   # 留白（静区）模块数，QR 规范最低要求 4
BOX_SIZE = 15                # 每个模块的像素边长

ILLEGAL_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
ENGINE_NAME = "python-qrcode"


def safe_name(raw):
    """把任意文本变成安全的文件名（不含扩展名）。"""
    name = ILLEGAL_RE.sub("_", str(raw or ""))
    name = re.sub(r"\s+", " ", name).strip()
    name = name.rstrip(". ")
    if len(name) > 80:
        name = name[:80].rstrip(". ")
    return name


def sign_token(key, scope, value):
    """与 Node 侧 lib/qr-content.js 的 sign() 完全一致：HMAC-SHA256 → base64 → 去掉 +/= → 取前 12 位"""
    digest = hmac.new(str(key or "").encode("utf-8"),
                      ("%s:%s" % (scope, value)).encode("utf-8"),
                      hashlib.sha256).digest()
    b64 = base64.b64encode(digest).decode("ascii")
    for ch in "+/=":
        b64 = b64.replace(ch, "")
    return b64[:12]


def id_to_base36(value):
    """与 Node 侧 idToBase36() 一致（Number.prototype.toString(36)）"""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return "0"
    if n <= 0:
        return "0"
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    out = ""
    while n:
        out = digits[n % 36] + out
        n //= 36
    return out


def short_archive_url(base, row, sign_key):
    """
    档案二维码的**短**落地页网址，必须与 Node 侧 qr-content.js 的 shortArchiveUrl() 一致。

    为什么要短：二维码里每多一个字符，模块数就可能上一个版本，打印到纸上每个模块就变小。
    实测（纠错 H / 静区 6）：长格式 65 字符 → 61 格，贴在 30mm 标签上只有 0.49mm/模块，
    实测扫不出；这条短格式 33 字符 → 45 格，同样标签有 0.67mm/模块。
    """
    id36 = id_to_base36(row["id"])
    sig = sign_token(sign_key, "q", id36)[:8]
    return "%s/q/%s%s" % (str(base).rstrip("/"), id36, sig)


def archive_label(row):
    """显示用/匹配用的编号：短档案号优先"""
    keys = row.keys()
    for key in ("archive_code", "archive_number"):
        if key in keys and (row[key] or "").strip():
            return row[key].strip()
    return "档案%s" % row["id"]


def archive_qr_text(row, base, mode, sign_key):
    """
    档案二维码里写的文字，必须与 Node 侧 lib/qr-content.js 的 archiveQrText() 一致。

    mode:
      url  短落地页网址（默认）—— 扫码打开落地页，第一行大字显示档案号，再给可点链接
      both 档案号 + 换行 + 网址
      code 只有档案号（老式扫码枪 / 离线标签机）
    """
    label = archive_label(row)
    mode = (mode or "url").lower()
    if mode == "code" or not base:
        return label
    url = short_archive_url(base, row, sign_key)
    if mode == "both":
        return "档案号：%s\n%s" % (label, url)
    return url


def qr_content(row, base="", mode="url", sign_key=""):
    """二维码内容（默认公网网址，见 archive_qr_text 的说明）"""
    keys = row.keys()
    if base and (mode or "url").lower() != "code":
        return archive_qr_text(row, base, mode, sign_key)
    # 没配公网地址时退回纯编号：内容必须是「系统能直接识别的编号」
    for key in ("archive_code", "archive_number"):
        if key in keys and (row[key] or "").strip():
            return row[key].strip()
    return "档案%s" % row["id"]


def qr_basename(row):
    """文件名：规范档号 → 短档案号 → 题名 → 档案<id>。"""
    keys = row.keys()
    for key in ("archive_number", "archive_code", "title"):
        if key in keys:
            val = (row[key] or "").strip()
            if val:
                name = safe_name(val)
                if name:
                    return name
    return "档案%s" % row["id"]


def load_rows(db_path):
    if not os.path.exists(db_path):
        raise SystemExit("找不到数据库文件：%s\n请用 --data 指定正确的数据目录。" % db_path)
    # 只读方式打开，绝不改动数据
    uri = "file:%s?mode=ro" % db_path.replace("\\", "/").replace("?", "%3f").replace("#", "%23")
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    try:
        return conn.execute(
            "SELECT id, archive_number, archive_code, title, updated_at, created_at "
            "FROM archives ORDER BY id"
        ).fetchall()
    finally:
        conn.close()


def import_qrcode():
    """导入 qrcode 库；失败时给出可操作的提示，而不是抛一堆栈。"""
    try:
        import qrcode
        from qrcode.constants import (
            ERROR_CORRECT_H, ERROR_CORRECT_L, ERROR_CORRECT_M, ERROR_CORRECT_Q,
        )
    except ImportError as exc:
        raise SystemExit(
            "没有找到 qrcode 库（%s）。\n"
            "请先安装：\n"
            "    pip install \"qrcode[pil]\" pillow\n"
            "内网无法访问外网时，请在有网的机器上执行：\n"
            "    pip download \"qrcode[pil]\" pillow -d whl\n"
            "再把 whl 目录拷过来执行：\n"
            "    pip install --no-index --find-links=whl \"qrcode[pil]\" pillow\n" % exc
        )
    return qrcode, {
        "L": ERROR_CORRECT_L, "M": ERROR_CORRECT_M,
        "Q": ERROR_CORRECT_Q, "H": ERROR_CORRECT_H,
    }


def newer_than(row, path):
    """图片是否比档案还新（是则说明不用重生成）。"""
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return False
    src = ""
    keys = row.keys()
    for key in ("updated_at", "created_at"):
        if key in keys and row[key]:
            src = row[key]
            break
    if not src:
        return True
    # 数据库里存的是 ISO 字符串（2025-01-01T12:00:00.000Z / 2025-01-01 12:00:00）
    text = str(src).replace("Z", "").replace("T", " ")[:19]
    try:
        import datetime
        dt = datetime.datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        try:
            import datetime
            dt = datetime.datetime.strptime(text, "%Y-%m-%d %H:%M")
        except ValueError:
            return True
    return mtime >= dt.timestamp()


def read_recorded_contents(out_dir):
    """读上一次的 清单.csv，得到「文件名 -> 当时写进二维码的内容」。

    用途：本机 IP 是 DHCP 动态分配的，随时会变；地址一变，旧图片里写的还是
    老地址，二维码看着好好的、扫出来却打不开。所以必须比对内容，不一致就重写。
    读不到就返回空表（退化成「按文件时间跳过」的老行为，不会误写）。
    """
    recorded = {}
    path = os.path.join(out_dir, "清单.csv")
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.reader(fh)
            next(reader, None)          # 表头
            for cells in reader:
                if len(cells) >= 4:
                    recorded[cells[2]] = cells[3]
    except (OSError, csv.Error):
        return {}
    return recorded


def main():
    parser = argparse.ArgumentParser(
        description="为档案管理系统里的每份档案生成二维码 PNG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--data", default="data", help="数据目录（内含 archive.db），默认 ./data")
    parser.add_argument("--force", action="store_true", help="全部重新生成，覆盖已有图片")
    parser.add_argument("--limit", type=int, default=0, help="只处理前 N 份（调试用）")
    parser.add_argument("--quiet", action="store_true", help="不打印每一条进度")
    parser.add_argument("--report", default="", help="把结果写成 JSON（供档案管理系统读取）")
    parser.add_argument("--border", type=int, default=BORDER,
                        help="静区（留白）模块数，规范最低要求 4，默认 %d" % BORDER)
    parser.add_argument("--box-size", type=int, default=BOX_SIZE,
                        help="每个模块的像素边长，默认 %d" % BOX_SIZE)
    parser.add_argument("--base-url", default="",
                        help="二维码里写的网址前缀（公网地址，如 https://dangan.example.com）")
    parser.add_argument("--archive-mode", default="url", choices=["url", "both", "code"],
                        help="档案二维码内容：url=公网网址(默认) / both=档案号+网址 / code=只有档案号")
    parser.add_argument("--sign-key", default="",
                        help="落地页签名密钥（与档案管理系统里的 qr.sign_key 一致）")
    args = parser.parse_args()

    # 参数做范围钳制，避免误传导致生成不可扫的码
    border = max(0, min(16, int(args.border)))
    box_size = max(1, min(40, int(args.box_size)))
    base_url = (args.base_url or "").rstrip("/")
    archive_mode = (args.archive_mode or "url").lower()
    sign_key = args.sign_key or ""

    qrcode, levels = import_qrcode()
    ec_level = levels[EC_LEVEL_NAME]

    data_dir = os.path.abspath(args.data)
    db_path = os.path.join(data_dir, "archive.db")
    out_dir = os.path.join(data_dir, "qrcodes")
    os.makedirs(out_dir, exist_ok=True)

    rows = load_rows(db_path)
    if args.limit:
        rows = rows[: args.limit]

    if not args.quiet:
        print("数据目录：%s" % data_dir)
        print("输出目录：%s" % out_dir)
        print("参数：ERROR_CORRECT_%s / border=%d / box_size=%d" % (EC_LEVEL_NAME, border, box_size))
        print("共 %d 份档案，开始生成……\n" % len(rows))

    taken = {f.lower() for f in os.listdir(out_dir)}
    created = skipped = failed = 0
    content_changed = 0
    errors = []
    index_rows = []
    # 上一次每张图里写的内容：地址变了必须重写这张图（否则二维码会指向老地址）
    recorded = read_recorded_contents(out_dir)

    for row in rows:
        content = qr_content(row, base_url, archive_mode, sign_key)
        base = qr_basename(row)

        # 重名时加序号（不同档案可能同名，尤其是用题名命名时）
        filename = base + ".png"
        n = 2
        while filename.lower() in taken and not os.path.exists(os.path.join(out_dir, filename)):
            filename = "%s(%d).png" % (base, n)
            n += 1
        path = os.path.join(out_dir, filename)

        # 内容变了（本机 IP 变了 / 网址前缀改了 / 内容模式改了）→ 无条件重写
        stale = filename in recorded and recorded[filename] != content
        if stale:
            content_changed += 1

        # 增量：已有、内容一致、且不比档案新的图片直接跳过，重复运行很快
        if os.path.exists(path) and not args.force and not stale and newer_than(row, path):
            skipped += 1
            index_rows.append((row["archive_number"] or row["archive_code"] or "",
                               row["title"] or "", filename, content))
            continue

        try:
            qr = qrcode.QRCode(
                version=None,            # 自动选最小版本
                error_correction=ec_level,   # ERROR_CORRECT_H
                box_size=box_size,       # 每个模块的像素边长（默认 15）
                border=border,           # 静区模块数（默认 6）
            )
            qr.add_data(content)
            qr.make(fit=True)
            qr.make_image().save(path)
            taken.add(filename.lower())
            created += 1
            if not args.quiet:
                print("  [%d] %s -> %s" % (created + skipped, content, filename))
        except Exception as exc:          # noqa: BLE001 —— 单张失败不能影响其余
            failed += 1
            if len(errors) < 20:
                errors.append("%s：%s" % (base, exc))

        index_rows.append((row["archive_number"] or row["archive_code"] or "",
                           row["title"] or "", filename, content))

    # 清单（UTF-8 BOM，Excel 双击不乱码）
    csv_path = os.path.join(out_dir, "清单.csv")
    try:
        with open(csv_path, "w", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh)
            writer.writerow(["档案号", "题名", "二维码图片文件名", "二维码内容"])
            writer.writerows(index_rows)
    except OSError as exc:
        errors.append("写清单失败：%s" % exc)

    stat = {
        "ok": True,
        "engine": ENGINE_NAME,
        "total": len(rows),
        "created": created,
        "skipped": skipped,
        "failed": failed,
        "errors": errors,
        "dir": out_dir,
        "ec_level": EC_LEVEL_NAME,
        "border": border,
        "box_size": box_size,
        "content_changed": content_changed,
    }

    if args.report:
        try:
            with open(args.report, "w", encoding="utf-8") as fh:
                json.dump(stat, fh, ensure_ascii=False)
        except OSError as exc:
            print("写报告文件失败：%s" % exc, file=sys.stderr)

    if not args.quiet:
        print("\n" + "=" * 56)
        print("生成完成：新生成 %d，已存在 %d，失败 %d" % (created, skipped, failed))
        print("图片目录：%s" % out_dir)
        print("清单位置：%s" % csv_path)
        if errors:
            print("\n失败明细（最多 20 条）：")
            for msg in errors:
                print("  ! " + msg)
        print("=" * 56)

    return 0


if __name__ == "__main__":
    sys.exit(main())
