/**
 * 扫描件存储自测：node server/tools/test-scan-storage.js [--url http://127.0.0.1:8913] [--data .\tmp-scan-test]
 *
 * 验证 v4.28.0 的"按档号落盘"是否真的成立（不只看接口返回，要看磁盘）：
 *   ① 导入多页 PDF → 服务端数出页数，返回页数核对结果
 *   ② 磁盘路径 = data/files/<档号各段>/<档号>.pdf
 *   ③ 同一件再导一个 → 自动命名 -02.pdf，不覆盖第一个
 *   ④ 档号目录里的文件名与档号一致（数字档案室建设指南 §4.3.2）
 *
 * 前置：起一个临时实例（别用真实库）
 *   node server/server.js --data .\tmp-scan-test --port 8913 --no-qr
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

function arg(name, dft) {
  const i = process.argv.indexOf('--' + name);
  if (i >= 0) {
    const v = process.argv[i + 1];
    return v && !v.startsWith('--') ? v : true;
  }
  // 兼容 run-all.js：它不写 --url/--data，而是按位置传
  //   argv[2] = 服务地址，argv[3] = 测试数据目录
  // 原来只认 --url，被 run-all 调起时就退回默认的 8913 —— 而 run-all 用的是随机临时端口，
  // 于是整套断言一条都跑不到（不是"通过"，是"零断言"）。
  if (name === 'url' && process.argv[2] && /^http/i.test(process.argv[2])) return process.argv[2];
  if (name === 'data' && process.argv[3] && !process.argv[3].startsWith('--')) return process.argv[3];
  return dft;
}

const BASE = String(arg('url', 'http://127.0.0.1:8913')).replace(/\/+$/, '');
const DATA = path.resolve(String(arg('data', path.join(__dirname, '..', '..', 'tmp-scan-test'))));
const ADMIN_PASSWORD = String(arg('password', 'admin123'));
let cookie = '';
let pass = 0;
let fail = 0;

function check(name, ok, detail) {
  if (ok) { pass += 1; console.log(`  ✓ ${name}`); } else {
    fail += 1;
    console.log(`  ✗ ${name}${detail ? '：' + detail : ''}`);
  }
}

function req(method, p, { body, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(BASE + p);
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const h = { ...headers };
    if (payload) { h['Content-Type'] = 'application/json'; h['Content-Length'] = payload.length; }
    if (cookie) h.Cookie = cookie;
    const r = http.request({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, method, headers: h }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const sc = res.headers['set-cookie'];
        if (sc) cookie = sc.map((x) => x.split(';')[0]).join('; ');
        const text = Buffer.concat(chunks).toString('utf8');
        let json = null;
        try { json = JSON.parse(text); } catch (_) { json = null; }
        resolve({ status: res.statusCode, json, text });
      });
    });
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

function upload(archiveId, { kind, filename, data, fields = {} }) {
  return new Promise((resolve, reject) => {
    const boundary = '----dsharchive' + Date.now().toString(16);
    const parts = [];
    for (const [k, v] of Object.entries({ kind, ...fields })) {
      parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
    }
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="files"; filename="${filename}"\r\n`
      + 'Content-Type: application/pdf\r\n\r\n'));
    parts.push(data);
    parts.push(Buffer.from(`\r\n--${boundary}--\r\n`));
    const body = Buffer.concat(parts);
    const u = new URL(BASE + `/api/archives/${archiveId}/files`);
    const r = http.request({
      hostname: u.hostname, port: u.port, path: u.pathname, method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length,
        ...(cookie ? { Cookie: cookie } : {}),
      },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { json = null; }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.write(body);
    r.end();
  });
}

/** 生成一个 n 页的最小 PDF（页对象明文，便于人工核对） */
function makePdf(n) {
  const kids = [];
  const objs = [];
  objs.push('<< /Type /Catalog /Pages 2 0 R >>');
  objs.push(''); // 占位，稍后填页面树
  for (let i = 0; i < n; i += 1) {
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents ${n + 3 + i} 0 R >>`);
  }
  for (let i = 0; i < n; i += 1) {
    kids.push(`${3 + i} 0 R`);
    objs.push(`<< /Length 0 >>\nstream\n\nendstream`);
  }
  objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${n} >>`;
  let out = '%PDF-1.7\n';
  const offs = [];
  objs.forEach((o, i) => {
    offs.push(out.length);
    out += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (const o of offs) out += `${String(o).padStart(10, '0')} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}

(async () => {
  console.log('扫描件存储自测');
  const ping = await req('GET', '/api/ping');
  check('服务可达', ping.status === 200, `HTTP ${ping.status}`);

  const login = await req('POST', '/api/login', { body: { username: 'admin', password: ADMIN_PASSWORD } });
  check('管理员登录', login.status === 200 && login.json && login.json.ok,
    (login.json && login.json.error) || `HTTP ${login.status}`);

  const types = await req('GET', '/api/types');
  const cats = await req('GET', '/api/categories');
  const flat = ((cats.json && cats.json.data && cats.json.data.flat) || []);
  const cat = flat.find((c) => String(c.code || '').startsWith('WS-')) || flat[0];
  check('取到分类', !!cat, JSON.stringify(cats.json).slice(0, 120));
  if (!cat) process.exit(1);

  const created = await req('POST', '/api/archives', {
    body: { title: '扫描件存储自测件', category_id: cat.id, type_code: 'WS', year: '2026', pages: '3' },
  });
  const a = created.json && created.json.data;
  check('新建档案', created.status === 200 && !!a, (created.json && created.json.error) || `HTTP ${created.status}`);
  if (!a) process.exit(1);
  console.log(`    档案号 ${a.archive_code}　档号 ${a.archive_number}`);

  const pdf3 = makePdf(3);
  const up1 = await upload(a.id, {
    kind: '扫描件', filename: '扫描0001.pdf', data: pdf3,
    fields: { dpi: '300', color_mode: '彩色', device: '自测扫描仪' },
  });
  const d1 = up1.json && up1.json.data;
  check('导入成功', up1.status === 200 && !!d1, (up1.json && up1.json.error) || `HTTP ${up1.status}`);
  check('解析出 3 页', d1 && d1.files && d1.files[0] && d1.files[0].pages === 3,
    JSON.stringify(d1 && d1.files && d1.files[0]));
  check('页数核对一致', d1 && d1.scanCheck && d1.scanCheck.level === 'ok',
    JSON.stringify(d1 && d1.scanCheck));

  // v4.29.0 起：没有挂项目/批次的件落在「过程/未分项目/<年度>/未分批次」
  const expectRel = `过程/未分项目/${a.year || new Date().getFullYear()}/未分批次`;
  const first = d1 && d1.files && d1.files[0];
  check('落盘目录 = 过程区（未挂项目）', !!first && first.rel_path.startsWith(expectRel + '/'),
    `${first && first.rel_path} 期望前缀 ${expectRel}/`);
  check('文件名 = 档号.pdf', !!first && first.rel_path === `${expectRel}/${a.archive_number}.pdf`,
    first && first.rel_path);

  const abs = path.join(DATA, 'files', first ? first.rel_path : '');
  const exists = fs.existsSync(abs);
  check('磁盘上确实有这个文件', exists, abs);
  if (exists) {
    const head = fs.readFileSync(abs, { encoding: 'latin1', flag: 'r' }).slice(0, 5);
    check('文件内容是 PDF', head === '%PDF-', JSON.stringify(head));
  }

  const up2 = await upload(a.id, {
    kind: '扫描件', filename: '扫描0002.pdf', data: makePdf(2), fields: { dpi: '300' },
  });
  const d2 = up2.json && up2.json.data;
  const second = d2 && d2.files && d2.files[0];
  check('第二份自动命名 -02', !!second && second.rel_path === `${expectRel}/${a.archive_number}-02.pdf`,
    second && second.rel_path);
  check('页数累计核对（3+2 对实体 3 页 → 提示不一致）',
    d2 && d2.scanCheck && d2.scanCheck.level === 'warn' && d2.scanCheck.scanned === 5,
    JSON.stringify(d2 && d2.scanCheck));

  const detail = await req('GET', `/api/archives/${a.id}`);
  const files = (detail.json && detail.json.data && detail.json.data.files) || [];
  const meta = files.find((f) => f.id === (first && first.id)) || {};
  check('详情接口带出页数与扫描参数', meta.pages === 3 && meta.dpi === 300 && meta.color_mode === '彩色',
    JSON.stringify({ pages: meta.pages, dpi: meta.dpi, color: meta.color_mode }));

  console.log(`\n通过 ${pass}，失败 ${fail}`);
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error('自测异常：' + (e && e.message));
  process.exit(1);
});
