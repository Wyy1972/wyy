/**
 * 二维码验证
 *  - 往返验证：编码 → 从位矩阵反向解码 → 比对原文（检验数据编码、分块交错、掩码、布点）
 *  - 与第三方实现比对：v1~v4 逐模块、v5~v10 哈希（跳出「自己编自己解」的循环验证）
 *  - 全版本 PNG 往返：v1~v10 都要能被独立解码器读回
 *  - 结构规范：定位图案、定时图案、格式信息、尺寸
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const qr = require('../lib/qrcode');
const { decodeFile } = require('./qr-decode');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

/** 从位矩阵解码（独立于编码路径实现，用于往返验证） */
function qrDecode(matrix, size, version) {
  // 按标准位序读取格式信息 —— 使用与编码端同一张落点表。
  // 这里绝不能再自定义一套读取方式：两边各写一套时，位序写反也测不出来。
  let bits = 0;
  for (const p of qr.formatPositions(size)) {
    if (matrix[p.y][p.x]) bits |= (1 << p.bit);
  }
  const fmt = (bits ^ 0x5412) >>> 0;
  const ecBits = (fmt >>> 13) & 0x3;
  const mask = (fmt >>> 10) & 0x7;
  // 格式信息里的纠错等级编码是标准值（M=00, L=01, H=10, Q=11），
  // 注意这**不是** RS 分块表的索引顺序（那里 M=1）。
  // 曾经把两者混为一谈，导致写出去的格式信息说自己是 L，真实扫码器直接判定无效。
  if (ecBits !== qr.QR_FORMAT_EC.M) throw new Error('纠错等级不是 M：' + ecBits);

  const reserved = Array.from({ length: size }, () => new Array(size).fill(false));
  const reserve = (x, y) => { if (x >= 0 && y >= 0 && x < size && y < size) reserved[y][x] = true; };
  const reserveFinder = (cx, cy) => {
    for (let dy = -1; dy <= 7; dy++) for (let dx = -1; dx <= 7; dx++) reserve(cx + dx, cy + dy);
  };
  reserveFinder(0, 0);
  reserveFinder(size - 7, 0);
  reserveFinder(0, size - 7);
  for (let i = 8; i < size - 8; i++) { reserve(i, 6); reserve(6, i); }
  for (const ax of (qr.QR_ALIGN[version] || [])) {
    for (const ay of (qr.QR_ALIGN[version] || [])) {
      if ((ax <= 8 && ay <= 8) || (ax <= 8 && ay >= size - 9) || (ax >= size - 9 && ay <= 8)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) reserve(ax + dx, ay + dy);
    }
  }
  for (let i = 0; i <= 8; i++) { reserve(i, 8); reserve(8, i); }
  for (let i = 0; i < 8; i++) { reserve(size - 1 - i, 8); reserve(8, size - 1 - i); }
  if (version >= 7) {
    for (let i = 0; i < 18; i++) {
      const a = Math.floor(i / 3), b = i % 3;
      reserve(size - 11 + b, a);
      reserve(a, size - 11 + b);
    }
  }

  const stream = [];
  let upward = true;
  for (let x = size - 1; x > 0; x -= 2) {
    if (x === 6) x = 5;
    for (let k = 0; k < size; k++) {
      const y = upward ? size - 1 - k : k;
      for (const dx of [0, -1]) {
        const xx = x + dx;
        if (reserved[y][xx]) continue;
        let v = matrix[y][xx];
        if (qr.maskFn(mask, xx, y)) v ^= 1;
        stream.push(v);
      }
    }
    upward = !upward;
  }
  const bytes = [];
  for (let i = 0; i + 8 <= stream.length; i += 8) {
    let b = 0;
    for (let j = 0; j < 8; j++) b = (b << 1) | stream[i + j];
    bytes.push(b);
  }

  const [ecLen, b1, d1, b2, d2] = qr.QR_M_TABLE[version];
  const blocks = [];
  for (let i = 0; i < b1; i++) blocks.push({ len: d1, data: [], ec: [] });
  for (let i = 0; i < b2; i++) blocks.push({ len: d2, data: [], ec: [] });
  const maxData = Math.max(...blocks.map((b) => b.len));
  let idx = 0;
  for (let i = 0; i < maxData; i++) {
    for (const b of blocks) if (i < b.len) b.data.push(bytes[idx++]);
  }
  // 交错区之后是各块的纠错码字
  for (let i = 0; i < ecLen; i++) {
    for (const b of blocks) b.ec.push(bytes[idx++]);
  }

  // ---- 校验 Reed-Solomon 纠错码 ----
  // 真扫码器必然会做这一步：如果数据布点顺序或码字交错有错，这里的校验会立刻失败。
  // 这是比“往返比对”更硬的验证，能抓住“双方错得一致”那类问题。
  const gfExp = new Uint8Array(512);
  const gfLog = new Uint8Array(256);
  (() => {
    let x = 1;
    for (let i = 0; i < 255; i++) { gfExp[i] = x; gfLog[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
    for (let i = 255; i < 512; i++) gfExp[i] = gfExp[i - 255];
  })();
  const gfMul = (a, b) => (a === 0 || b === 0 ? 0 : gfExp[gfLog[a] + gfLog[b]]);
  let rsOk = true;
  for (const b of blocks) {
    // 生成多项式
    let gen = [1];
    for (let i = 0; i < ecLen; i++) {
      const next = new Array(gen.length + 1).fill(0);
      for (let j = 0; j < gen.length; j++) {
        next[j] ^= gen[j];
        next[j + 1] ^= gfMul(gen[j], gfExp[i]);
      }
      gen = next;
    }
    // 余数应为全 0
    const res = new Array(ecLen).fill(0);
    for (const byte of b.data.concat(b.ec)) {
      const factor = byte ^ res[0];
      res.shift();
      res.push(0);
      if (factor !== 0) for (let i = 0; i < ecLen; i++) res[i] ^= gfMul(gen[i + 1], factor);
    }
    if (res.some((v) => v !== 0)) rsOk = false;
  }
  const flat = blocks.flatMap((b) => b.data);

  const bitStream = [];
  for (const b of flat) for (let i = 7; i >= 0; i--) bitStream.push((b >>> i) & 1);
  let p = 0;
  const take = (n) => { let v = 0; for (let i = 0; i < n; i++) v = (v << 1) | (bitStream[p++] || 0); return v; };
  const mode = take(4);
  if (mode !== 4) throw new Error('数据模式不是字节模式：' + mode);
  const len = take(version <= 9 ? 8 : 16);
  const out = [];
  for (let i = 0; i < len; i++) out.push(take(8));
  return { text: Buffer.from(out).toString('utf8'), mask, version, ecLen, rsOk };
}

console.log('【1. 往返验证（编码→解码→比对原文）】');
const payloads = [
  'HELLO',
  'Z001-WS-DQ-01-2025-0001',
  'http://127.0.0.1:8787',
  'HT-2024-0001',
  'A'.repeat(60),
  'B'.repeat(120),
  '档案盒-A库-A1-3-第001盒',
];
for (const text of payloads) {
  let decoded = null, err = null, info = '?', rs = null;
  try {
    const m = qr.qrMatrix(text);
    info = `v${m.version}/掩码${m.mask}`;
    const d = qrDecode(m.modules, m.size, m.version);
    decoded = d.text;
    rs = d.rsOk;
  } catch (e) { err = e; }
  check(`往返一致（${text.length} 字符，${info}）`, decoded === text,
    err ? '异常: ' + err.message : `解出「${decoded}」`);
  check(`纠错码校验通过（${info}）`, rs === true,
    'Reed-Solomon 校验失败 —— 说明数据布点或码字交错有误，真扫码器会读不出');
}

console.log('\n【1b. 与第三方实现的黄金矩阵逐模块比对（最关键的一项）】');
{
  // 为什么必须有这一节：
  //   「自己编码、自己解码」的往返测试**证明不了二维码合规** ——
  //   编码器和解码器错得一模一样时，往返照样通过。
  //   本项目在格式信息上栽过两次（纠错等级编码写成分块表索引、15 位落点位序整体写反），
  //   两次都是自测全绿、微信一个都扫不出，用户看到的就是「二维码扫不出来」。
  //
  //   下面的黄金矩阵由第三方公认实现 qrcode-generator v1.4.4
  //   （MIT，Copyright (c) 2009 Kazuhiko Arase）生成，与本项目代码无任何共享，
  //   因此能真正跳出循环验证。
  //
  //   比对方式：先按标准位序从黄金矩阵里读回它当时选用的掩码，
  //   再强制本项目用同一掩码生成，逐模块比对 —— 必须完全一致。
  //   掩码本身是自由选择（8 个都合规），所以不比对「自动选出的掩码是否相同」，
  //   否则会把两套都合法的惩罚函数差异误报成错误。
  const GOLDEN = [
  // 21x21  2026-WS-001
  { text: "2026-WS-001", size: 21, mask: 7, rows: [
    '111111100110101111111',
    '100000100110101000001',
    '101110100001001011101',
    '101110100011001011101',
    '101110100110101011101',
    '100000101111101000001',
    '111111101010101111111',
    '000000000101100000000',
    '100101101110010100000',
    '001011001010001111001',
    '010000101110101000111',
    '110100000001011010010',
    '001101110010110011001',
    '000000001011000011011',
    '111111100010000111000',
    '100000101111110011001',
    '101110100111000101010',
    '101110101000011001011',
    '101110100110101110001',
    '100000100010000011000',
    '111111101111111101010',
  ] },
  // 21x21  WS-2026-0001
  { text: "WS-2026-0001", size: 21, mask: 2, rows: [
    '111111100101101111111',
    '100000100000001000001',
    '101110101010101011101',
    '101110101011101011101',
    '101110101011101011101',
    '100000101110101000001',
    '111111101010101111111',
    '000000001101100000000',
    '101111100000101111100',
    '100111000100111110110',
    '010101100011010101010',
    '010011000100000110111',
    '011010101111011000010',
    '000000001100100011010',
    '111111100000100101110',
    '100000101111100110100',
    '101110101000111101011',
    '101110101001000010100',
    '101110101110100100000',
    '100000100100100100100',
    '111111101010111101010',
  ] },
  // 25x25  中文（同时验证 UTF-8 字节模式）
  { text: "档案盒-A库-A1-3", size: 25, mask: 5, rows: [
    '1111111000010010101111111',
    '1000001011001010101000001',
    '1011101011000011001011101',
    '1011101011010110001011101',
    '1011101000000010001011101',
    '1000001000110100101000001',
    '1111111010101010101111111',
    '0000000011100010000000000',
    '1000001011011001011001110',
    '0101010100110110000010100',
    '1101101000100111110010100',
    '0110110000100100111001111',
    '0000001110011100101011011',
    '1010010100000001001011000',
    '1001001101111001101111100',
    '1011000001010001111000000',
    '1011011111010001111111111',
    '0000000010101111100010000',
    '1111111000110001101010100',
    '1000001001001100100010110',
    '1011101000101010111111001',
    '1011101001100010010110011',
    '1011101000111001100011001',
    '1000001000110011111111101',
    '1111111010000111001011001',
  ] },
  // 33x33  实际使用的扫码网址
  { text: "http://172.29.106.169:8787/api/scan/box/2026-WS-001", size: 33, mask: 3, rows: [
    '111111101110000010010001101111111',
    '100000101000101001000011101000001',
    '101110100111011010110000001011101',
    '101110101101100100110111101011101',
    '101110100111110010100110001011101',
    '100000100001010111000100001000001',
    '111111101010101010101010101111111',
    '000000001011100111010000100000000',
    '101101110111000101001110101001011',
    '001100010000010011010111111101101',
    '110110110011010010101111000111011',
    '100000010011100011001001010101001',
    '101001111100001110000110000011000',
    '110100000100101000001010000101010',
    '000011101100001000011010010101000',
    '010010000110101100100111110011100',
    '100000100111011000000101101011100',
    '111101011001111100100001001011011',
    '000111110010101110101000111010110',
    '110101001001110111101010110110010',
    '000001110110101110011111110001110',
    '101101010100110110010101111001001',
    '000111111110101100101001011011111',
    '011111010101001100110010001010001',
    '100111101010100001101000111110000',
    '000000001010110100111111100011010',
    '111111101100000001110001101010000',
    '100000101001110011111110100010111',
    '101110100010100011110101111110110',
    '101110101111101011000000110001101',
    '101110101010010110100010111101000',
    '100000100011100001001000101010001',
    '111111101011001001010110011000100',
  ] },
  ];

  let allOk = true;
  const detail = [];
  for (const g of GOLDEN) {
    const rows = g.rows.map((r) => r.split('').map(Number));
    // 1) 用本项目的位序表从黄金矩阵读回格式信息（这一步本身就是对位序表的校验）
    const info = qr.readFormatInfo(rows, g.size);
    // 2) 强制用同一掩码生成，逐模块比对
    const m = qr.qrMatrix(g.text, { ecLevel: 'M', forceMask: info.mask });
    let diff = 0, first = null;
    for (let y = 0; y < g.size; y++) {
      for (let x = 0; x < g.size; x++) {
        if (m.modules[y][x] !== rows[y][x]) { diff++; if (!first) first = '(' + x + ',' + y + ')'; }
      }
    }
    const ok = info.ecLevel === 'M' && info.mask === g.mask && m.size === g.size && diff === 0;
    if (!ok) allOk = false;
    detail.push(g.text.slice(0, 18) + ': 读出' + info.ecLevel + '/掩码' + info.mask + ' 应掩码' + g.mask + ' 差异' + diff + (first ? '@' + first : ''));
  }
  check('与第三方实现逐模块完全一致（' + GOLDEN.length + ' 个用例）', allOk, detail.join(' | '));
}

console.log('\n【1b-2. 纠错等级 H 的黄金矩阵比对（档案单件二维码用的就是 H）】');
{
  // H 级是「每份档案一张二维码」功能使用的等级（约 30% 容错），
  // 与 M 级用的是不同的分块表，必须单独跟第三方核对一遍，
  // 否则很容易出现「M 级对、H 级错」而没人发现的情况。
  const GOLDEN_H = [
  // 25x25 纠错等级 H  2026-WS-001
  { text: "2026-WS-001", size: 25, mask: 3, rows: [
    '1111111001011110101111111',
    '1000001001010011101000001',
    '1011101001101100001011101',
    '1011101001100011001011101',
    '1011101011011001001011101',
    '1000001001010111001000001',
    '1111111010101010101111111',
    '0000000010101011100000000',
    '0011001110110010111010000',
    '1010100010010101110001010',
    '0001111000010011110010110',
    '1100100110101010000100100',
    '0111001010110100001110101',
    '0010010010000000101011001',
    '0100111101010001100000000',
    '1000010000000110111111000',
    '0011101010100111111110110',
    '0000000010111101100011011',
    '1111111011001111101010001',
    '1000001001101100100011001',
    '1011101001110100111111101',
    '1011101010101100001010001',
    '1011101010000100010011110',
    '1000001000101100111011100',
    '1111111000101010100000011',
  ] },
  // 29x29 纠错等级 H  Z001-WS-XZ-01-0001-0001
  { text: "Z001-WS-XZ-01-0001-0001", size: 29, mask: 6, rows: [
    '11111110000010001011101111111',
    '10000010001110000001001000001',
    '10111010110100110001001011101',
    '10111010100001001110101011101',
    '10111010000111001001101011101',
    '10000010011100001000001000001',
    '11111110101010101010101111111',
    '00000000001101001110100000000',
    '00011011011000010000100001100',
    '10101001010010011111100011010',
    '10100110110011101010100011110',
    '11100100110100010010010110000',
    '11011110110100100101001010010',
    '00011001101111011001010111101',
    '10111010001110110011000111011',
    '11110000111110011110111100111',
    '11011110100110100001010001010',
    '11011101011100111011010110011',
    '11010111110110110111111111101',
    '11001000000111111001111011111',
    '11001011110011001111111110101',
    '00000000101101000111100010110',
    '11111110110001100000101010110',
    '10000010011110011001100010001',
    '10111010110101100101111110011',
    '10111010101011110110100001110',
    '10111010010000011100110011011',
    '10000010000000011001001110101',
    '11111110001011111010110111000',
  ] },
  // 29x29 纠错等级 H  中文内容（同时验证 UTF-8 字节模式）
  { text: "档案盒-A库-A1-3", size: 29, mask: 5, rows: [
    '11111110101010111101101111111',
    '10000010010111110010101000001',
    '10111010111100011100001011101',
    '10111010010011101100101011101',
    '10111010110110111110101011101',
    '10000010001011011100101000001',
    '11111110101010101010101111111',
    '00000000111100111110100000000',
    '00000110011011101001001010101',
    '11011000010101011110010010100',
    '00110110010010110101011111111',
    '10110100111011100111100100001',
    '11010010010100010010100111001',
    '01110001110100110011001000010',
    '01111110001011101010010111011',
    '01011100110110100101110010000',
    '01110011000110111000110000111',
    '10001100010110001110000011101',
    '11100110011110000001001010100',
    '10111101010101000110011011011',
    '10010011000001110010111110010',
    '00000000101000010101100010110',
    '11111110011101101100101011111',
    '10000010111010001010100011110',
    '10111010011100100110111111001',
    '10111010001010001001101000010',
    '10111010011000000000100001010',
    '10000010001001100100110000101',
    '11111110000001111101111111100',
  ] },
  ];

  let allOk = true;
  const detail = [];
  for (const g of GOLDEN_H) {
    const rows = g.rows.map((r) => r.split('').map(Number));
    const info = qr.readFormatInfo(rows, g.size);
    const m = qr.qrMatrix(g.text, { ecLevel: 'H', forceMask: info.mask });
    let diff = 0;
    for (let y = 0; y < g.size; y++) {
      for (let x = 0; x < g.size; x++) if (m.modules[y][x] !== rows[y][x]) diff++;
    }
    const ok = info.ecLevel === 'H' && info.mask === g.mask && m.size === g.size && diff === 0;
    if (!ok) allOk = false;
    detail.push(g.text.slice(0, 16) + ': 读出' + info.ecLevel + '/掩码' + info.mask + ' 差异' + diff);
  }
  check('H 级与第三方实现逐模块完全一致（' + GOLDEN_H.length + ' 个用例）', allOk, detail.join(' | '));

  // 四个等级都要能生成，且格式信息里的纠错码符合标准（M=00 L=01 H=10 Q=11）
  let allLevels = true;
  const lvDetail = [];
  for (const lv of ['L', 'M', 'Q', 'H']) {
    try {
      const m = qr.qrMatrix('LEVEL-' + lv, { ecLevel: lv });
      const info = qr.readFormatInfo(m.modules, m.size);
      const good = info.ecLevel === lv && info.mask === m.mask && info.ecCode === qr.QR_FORMAT_EC[lv];
      if (!good) allLevels = false;
      lvDetail.push(`${lv}:v${m.version}/格式码${info.ecCode}`);
    } catch (e) { allLevels = false; lvDetail.push(lv + ':异常 ' + e.message); }
  }
  check('L/M/Q/H 四个等级都能生成且格式码正确', allLevels, lvDetail.join(' '));
}

console.log('\n【1b-3. PNG 输出与解码往返】');
{
  // 「每份档案一张二维码图片」落盘的就是 PNG，必须验证：
  //   ① 是合法 PNG（签名、尺寸、灰度）
  //   ② 尺寸恰好等于 (模块数 + 静区 8) × 模块边长
  //   ③ 独立解码器能从 PNG 里读回原文
  const os = require('node:os');
  const fsx = require('node:fs');
  const pathx = require('node:path');
  const { decodeFile } = require('./qr-decode');
  const cases = ['2026-WS-001', 'Z001-WS-XZ-01-0001-0001', '档案盒-A库-A1-3'];
  let allOk = true;
  const detail = [];
  for (const text of cases) {
    try {
      const png = qr.qrPng(text, { ecLevel: 'H', scale: 10, margin: 4 });
      const b = png.buffer;
      const sig = b.slice(0, 8).toString('hex') === '89504e470d0a1a0a';
      const w = b.readUInt32BE(16), h = b.readUInt32BE(20);
      const colorType = b[25];
      const expectDim = (png.size + 8) * 10;
      const tmp = pathx.join(os.tmpdir(), 'qrpng-' + Math.random().toString(16).slice(2) + '.png');
      fsx.writeFileSync(tmp, b);
      const dec = decodeFile(tmp);
      fsx.unlinkSync(tmp);
      const good = sig && w === expectDim && h === expectDim && colorType === 0
        && dec.ok && dec.text === text && dec.viaFormat === true;
      if (!good) allOk = false;
      detail.push(`${text.slice(0, 10)}:${w}px/${b.length}B/${dec.ok ? 'ok' : dec.reason}`);
    } catch (e) { allOk = false; detail.push(text + ':异常 ' + e.message); }
  }
  check('PNG 合法、尺寸符合参数、且能被独立解码器读回', allOk, detail.join(' | '));

  // 参数必须真的是「静区 4 / 模块 10」：改参数尺寸要跟着变
  const a = qr.qrPng('SIZE-CHECK', { ecLevel: 'H', scale: 10, margin: 4 });
  const b2 = qr.qrPng('SIZE-CHECK', { ecLevel: 'H', scale: 5, margin: 4 });
  const c2 = qr.qrPng('SIZE-CHECK', { ecLevel: 'H', scale: 10, margin: 0 });
  check('模块边长参数生效（scale 10 → 5 尺寸减半）',
    a.pixels === b2.pixels * 2, `${a.pixels} vs ${b2.pixels}`);
  check('静区参数生效（margin 4 → 0 尺寸减少 80px）',
    a.pixels - c2.pixels === 80, `${a.pixels} vs ${c2.pixels}`);
}

console.log('\n【1b-4. 高版本（v5~v10）与第三方实现逐位比对】');
{
  // 为什么单独有这一节：
  //   上面 1b/1b-2 的黄金矩阵只有 v1~v4。而编码器能生成到 v10，
  //   也就是**高版本一度完全没有被独立验证过** —— 直到有一次拿高版本内容去跑，
  //   才发现测试解码器的分块表根本没写到 v5 以上（已经补上）。
  //   这里用第三方实现 Python 的 qrcode 库生成的矩阵哈希做长期看守。
  //
  //   对照方法：强制 Python 也用「字节模式」（本项目只做字节模式），
  //   此时两者的数据编码完全一致，在相同版本、相同掩码下矩阵必须逐位相同。
  //   哈希是 SHA-256(每行拼成字符串再以 \n 连接)，与 Python 侧算出的完全一致。
  const GOLDEN_HASH = [
    // 内容                                                     版本  模块  掩码  SHA-256
    ['X'.repeat(40), 5, 37, 3, '1262f0acd9b70ad230eaf8324687617df499d9b471a8c475ef0a56eba2ba761e'],
    ['Y'.repeat(60), 7, 45, 1, 'c07160163cf6f2ed0a5cbb66e8f714e292c8379a6e780e6f6df541c49ca47fa9'],
    ['Z'.repeat(80), 8, 49, 5, '521e26e61c6dc624b896bbd587119ca28ea97c13dc04e482bc36fc3e26435714'],
    ['W'.repeat(115), 10, 57, 1, '35680aefbfdc6be1736c2822f7b3e495cede13b950bc62ac96d149bbaabd3ed4'],
    ['https://example.com/some/rather/long/path?with=query&and=more&params=here', 8, 49, 6,
      '5ca7a6191699f0656e26f294472d3fa82289b6581d2f8b2cac705b87e8d6a3e2'],
  ];
  let allOk = true;
  const detail = [];
  for (const [text, version, size, mask, want] of GOLDEN_HASH) {
    const m = qr.qrMatrix(text, { ecLevel: 'H', forceMask: mask });
    const rows = m.modules.map((r) => r.join(''));
    const got = crypto.createHash('sha256').update(rows.join('\n')).digest('hex');
    const ok = m.version === version && m.size === size && got === want;
    if (!ok) allOk = false;
    detail.push(`v${version}/${size}模块: ${ok ? '一致' : `不一致（本项目 v${m.version}/${m.size} ${got.slice(0, 12)}…）`}`);
  }
  check(`高版本 v5~v10 与第三方实现逐位一致（${GOLDEN_HASH.length} 个用例）`, allOk, detail.join(' | '));
}

console.log('\n【1b-5. 全版本 PNG 往返（v1~v10 都要能被独立解码器读回）】');
{
  // 编码器能产出 v1~v10。这里把每个版本都实际生成一遍 PNG，
  // 再交给独立解码器（它自己抄了一份标准分块表、并且强制走格式信息路径），
  // 确保「任何版本都能被读回」，而不是只有小版本好用。
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'qrver-'));
  const cases = ['A', '2026-WS-001', 'Z001-WS-XZ-01-0001-0001', '档案盒-A库-A1-3',
    'http://172.29.106.169:8787/api/s/2026-WS-001', 'X'.repeat(40), 'Y'.repeat(60),
    'Z'.repeat(80), 'Q'.repeat(100), 'W'.repeat(115)];
  const seen = new Set();
  let allOk = true;
  const detail = [];
  for (let i = 0; i < cases.length; i++) {
    const text = cases[i];
    let png, file, dec;
    try {
      png = qr.qrPng(text, { ecLevel: 'H', scale: 10, margin: 4 });
      file = path.join(tmpDir, 'v' + png.version + '-' + i + '.png');
      fs.writeFileSync(file, png.buffer);
      dec = decodeFile(file);
    } catch (e) { allOk = false; detail.push(`异常 ${e.message}`); continue; }
    const ok = dec.ok && dec.text === text && dec.viaFormat === true && dec.ecCode === 2;
    if (!ok) allOk = false;
    seen.add(png.version);
    detail.push(`v${png.version}:${ok ? 'ok' : (dec.reason || '不一致')}`);
  }
  fs.rmSync(tmpDir, { recursive: true, force: true });
  check('v1~v10 各版本都能被独立解码器正确读回', allOk, detail.join(' '));
  check('覆盖到多个版本（不只是最小版本）', seen.size >= 5, '覆盖版本数 ' + seen.size + '：' + [...seen].sort((a, b) => a - b).join(','));
}

console.log('\n【1c. 格式信息自校验】');
{
  // 从自己生成的矩阵里读回格式信息，必须与编码时写入的一致
  let ok = true;
  const detail = [];
  for (const text of ['HELLO', 'Z001-WS-DQ-01-2025-0001', 'A'.repeat(60)]) {
    const m = qr.qrMatrix(text);
    const info = qr.readFormatInfo(m.modules, m.size);
    const bits = qr.formatBits('M', m.mask) >>> 0;
    const good = info.ecLevel === 'M' && info.mask === m.mask && info.bits === bits;
    if (!good) ok = false;
    detail.push('v' + m.version + ': 应掩码' + m.mask + ' 读出' + info.mask + ' 等级' + info.ecLevel);
  }
  check('格式信息能按标准位序读回（含纠错等级 M=00）', ok, detail.join(' | '));
  // 两份副本必须一致（真扫码器任取一份都要能读）
  const m2 = qr.qrMatrix('Z001-WS-DQ-01-2025-0001');
  const pos = qr.formatPositions(m2.size);
  const copyA = pos.filter((p) => !(p.x === 8 && p.y > 8) && !(p.y === 8 && p.x > 8));
  const copyB = pos.filter((p) => !copyA.includes(p));
  let same = copyA.length === 15 && copyB.length === 15;
  for (const a of copyA) {
    const b = copyB.find((q) => q.bit === a.bit);
    if (b && m2.modules[a.y][a.x] !== m2.modules[b.y][b.x]) same = false;
  }
  check('格式信息两份副本内容一致且各 15 位', same, 'A=' + copyA.length + ' B=' + copyB.length);
}

console.log('\n【2. 结构规范性】');
{
  const m = qr.qrMatrix('Z001-WS-DQ-01-2025-0001');
  check('尺寸 = 4×版本+17', m.size === 4 * m.version + 17, `size=${m.size} version=${m.version}`);
  const finderOk = (cx, cy) => {
    const at = (dx, dy) => m.modules[cy + dy][cx + dx];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (!at(dx, dy)) return false;
    if (at(2, 0) || at(-2, 0) || at(0, 2) || at(0, -2)) return false;
    for (let d = -3; d <= 3; d++) {
      if (!at(d, -3) || !at(d, 3) || !at(-3, d) || !at(3, d)) return false;
    }
    return true;
  };
  check('左上定位图案结构正确（黑框+白环+黑心）', finderOk(3, 3));
  check('右上定位图案结构正确', finderOk(m.size - 4, 3));
  check('左下定位图案结构正确', finderOk(3, m.size - 4));
  check('定位图案外侧分隔带为白', m.modules[7][0] === 0 && m.modules[0][7] === 0 && m.modules[7][7] === 0);
  check('固定暗模块存在', m.modules[m.size - 8][8] === 1);
  check('定时图案（第 6 行/列）黑白交替', (() => {
    for (let i = 8; i < m.size - 8; i++) {
      if (m.modules[6][i] !== (i % 2 === 0 ? 1 : 0)) return false;
    }
    return true;
  })());
  check('掩码号合法（0~7）', m.mask >= 0 && m.mask <= 7, String(m.mask));
  const svg = qr.qrSvg('Z001-WS-DQ-01-2025-0001');
  check('SVG 输出正常', svg.includes('<svg') && svg.includes('<rect'));
  check('data URI 可生成', qr.svgDataUri(svg).startsWith('data:image/svg+xml;base64,'));
}

console.log('\n【3. 容量与边界】');
{
  let overflow = false;
  try { qr.qrMatrix('X'.repeat(400)); } catch (_) { overflow = true; }
  check('超长内容给出明确错误而非静默截断', overflow);
  check('短内容使用最小版本 v1', qr.pickVersion(10) === 1);
  check('长内容自动升级版本', qr.pickVersion(150) > 1);
  const cn = qr.qrMatrix('档案管理系统');
  check('中文内容往返一致（UTF-8 字节模式）',
    qrDecode(cn.modules, cn.size, cn.version).text === '档案管理系统');
  check('空内容不抛异常', (() => { try { qr.qrMatrix(''); return true; } catch (_) { return false; } })());
}

console.log('\n' + '='.repeat(54));
console.log(`二维码验证：通过 ${pass} 项，失败 ${failed} 项`);
if (failed) fails.forEach((f) => console.log('  - ' + f));
console.log('='.repeat(54));
process.exit(failed ? 1 : 0);
