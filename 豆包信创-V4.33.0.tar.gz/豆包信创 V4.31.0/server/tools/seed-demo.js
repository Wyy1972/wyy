/**
 * 演示数据播种工具（零依赖）
 *
 * 用途：往**指定的数据目录**里生成演示数据（32 条档案 + 档案盒 + 借阅记录 + 示例附件）。
 *      与 `node server/server.js --demo` 用的是同一个 seedDemo()，行为完全一致、幂等。
 *
 * 为什么单独做成一个工具：
 *   1. 回归测试需要在**启动服务之前**把夹具种进测试库（二维码套件依赖「至少一个档案盒」）；
 *      服务启动后再从另一个进程写同一个 SQLite 会引入并发写风险，没必要。
 *   2. 让使用者可以把演示数据种进任意目录（例如临时试跑），而不必去动 data/。
 *
 * 用法：
 *   node server/tools/seed-demo.js <数据目录>
 *   node server/tools/seed-demo.js .regress-data
 *
 * 退出码：0 = 成功（含「已存在，跳过」）；1 = 失败。
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { openDatabase } = require('../db');
const { seedDemo } = require('./demo-data');

const dataDir = process.argv[2];
if (!dataDir) {
  console.error('用法：node server/tools/seed-demo.js <数据目录>');
  process.exit(1);
}

const absDataDir = path.resolve(dataDir);
const dbFile = path.join(absDataDir, 'archive.db');

if (!fs.existsSync(dbFile)) {
  console.error(`[错误] 数据目录里没有 archive.db：${dbFile}`);
  console.error('       请先用 server/tools/init-empty-db.js 建库，或确认目录是否正确。');
  process.exit(1);
}

const db = openDatabase(dbFile);
let n = 0;
try {
  n = seedDemo(db, { filesRoot: path.join(absDataDir, 'files') });
} catch (e) {
  console.error('[错误] 播种演示数据失败：' + e.message);
  db.close();
  process.exit(1);
}

const stats = {
  archives: db.prepare('SELECT COUNT(*) AS c FROM archives').get().c,
  boxes: db.prepare('SELECT COUNT(*) AS c FROM archive_boxes').get().c,
  loans: db.prepare('SELECT COUNT(*) AS c FROM loans').get().c,
  users: db.prepare('SELECT COUNT(*) AS c FROM users').get().c,
};
db.close();

if (n) console.log(`  演示数据已生成：新增 ${n} 条（档案 ${stats.archives} / 档案盒 ${stats.boxes} / 借阅 ${stats.loans} / 账号 ${stats.users}）`);
else console.log(`  演示数据已存在，跳过生成（档案 ${stats.archives} / 档案盒 ${stats.boxes}）`);
