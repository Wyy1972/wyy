/**
 * 交叉验证：本项目生成的二维码 → 渲染为图片 → 用独立解码器解回。
 *
 * 为什么需要这个：
 *   「自己编码、自己解码」的往返测试**不能证明二维码合规** ——
 *   编码与解码两边错得一致时，往返照样通过（这个坑已经踩过两次：
 *   格式信息位序、第二份副本位序）。
 *   因此这里用**独立实现**的解码器（qrcode 库输出的图片能解出，说明它按标准实现）
 *   来回读我们生成的图，作为真正的合规性检验。
 *
 * 用法：node server/tools/test-qr-cross.js
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const qr = require('../lib/qrcode');
const { decodeFile } = require('./qr-decode');
const { matrixToBmp } = require('./qr-render');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

console.log('=== 交叉验证：本项目生成 → 独立解码器解回 ===\n');

const payloads = [
  '2026-WS-001',                          // 档案盒号（实际用途）
  'WS-2026-0001',                         // 档案号
  'Z001-WS-XZ-01-0001-0001',              // 规范档号
  'http://192.168.1.20:8787/',            // 局域网地址
  '2025-HT-002',                          // 含字母数字
  '档案盒-A库-A1-3',                       // 中文内容
];

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'qr-cross-'));
let allOk = true;
for (const text of payloads) {
  let result = null, err = null, info = '';
  try {
    const m = qr.qrMatrix(text);
    info = `v${m.version}/掩码${m.mask}`;
    const bmp = matrixToBmp(m.modules, m.size, 8, 4);
    const file = path.join(tmpDir, 't' + Math.abs(text.length * 7919 + m.version) + '.bmp');
    fs.writeFileSync(file, bmp);
    result = decodeFile(file);
    fs.unlinkSync(file);
  } catch (e) { err = e; }
  const ok = result && result.ok && result.text === text && result.viaFormat === true;
  if (!ok) allOk = false;
  check(`独立解码器能读出（${text.slice(0, 24)}…，${info}）`, ok,
    err ? '异常: ' + err.message
      : (result && result.ok
        ? (result.text !== text
          ? `读出「${result.text}」（不一致）`
          : '读出来了，但走的是枚举猜测而不是格式信息 —— 说明格式信息不合规，真扫码器会读不出')
        : (result ? result.reason : '无结果')));
}

fs.rmSync(tmpDir, { recursive: true, force: true });

console.log('\n' + '='.repeat(56));
console.log(`交叉验证：通过 ${pass} 项，失败 ${failed} 项`);
if (failed) {
  console.log('\n这说明生成的二维码不符合标准，真扫码器会读不出。');
  fails.forEach((f) => console.log('  - ' + f));
}
console.log('='.repeat(56));
process.exit(failed ? 1 : 0);
