/**
 * 一键回归测试入口（零依赖）
 *
 * 用法：
 *   node server/tools/run-all.js                     自动拉起服务（临时端口 + 干净测试库）后跑全部套件
 *   node server/tools/run-all.js --url http://127.0.0.1:8787   复用已在运行的服务
 *   node server/tools/run-all.js --offline            只跑不需要服务的套件
 *   node server/tools/run-all.js --only qr            只跑名字/脚本名含 qr 的套件
 *   node server/tools/run-all.js --keep               跑完不自动关掉自己拉起的服务
 *   node server/tools/run-all.js --keep-data          复用上次的测试库（默认每次重建）
 *   node server/tools/run-all.js --no-demo            不播种演示数据（纯空库跑）
 *   node server/tools/run-all.js --data <目录>         指定测试数据目录
 *   node server/tools/run-all.js --verbose            失败时打印完整输出（默认也打印失败片段）
 *
 * 退出码：全部通过 = 0；任一失败 = 1。
 *
 * 设计说明：
 *   - 各套件脚本自带 `process.exit(failed ? 1 : 0)` 与「通过 N 项，失败 M 项」摘要，
 *     本脚本以退出码为准，摘要用于展示，二者不一致时给出警告（防止脚本漏写 exit）。
 *   - 服务由本脚本自己拉起时，端口用临时端口，绝不占用 8787，避免影响正在使用的系统。
 *   - **测试库是独立的（.regress-data），每次运行重建，绝不读写 data/ 下的使用者数据。**
 *     原因：自测脚本假定出厂账号 admin/admin123，而真实部署里密码早已被改掉；
 *     直接拿使用者数据库跑回归会全线登录失败，既不可重复也危险。
 */
'use strict';

const { spawn, spawnSync } = require('node:child_process');
const http = require('node:http');
const net = require('node:net');
const path = require('node:path');
const fs = require('node:fs');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const TOOLS = path.join(APP_ROOT, 'server', 'tools');
/** 回归测试专用数据目录：与使用者数据 data/ 完全隔离，默认每次重建 */
const REGRESS_DATA = path.join(APP_ROOT, '.regress-data');
/**
 * 临时服务的 PID 文件。
 *
 * 放在 APP_ROOT 而**不是**测试数据目录里：测试数据目录每轮开头都会被清空，
 * 放进去等于"先把线索删掉、再去找线索"。
 */
const PID_FILE = path.join(APP_ROOT, '.regress-server.pid');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * 递归删除目录，**删完必须核对**。
 *
 * 为什么不用 fs.rmSync(dir, { recursive: true, force: true })：
 * 本机实测它对含中文的路径会**返回成功却一个文件都不删**（force 把 ENOENT 吞掉了；
 * 同一路径下 unlinkSync / rmdirSync 全部正常）。这是"测试库删不掉"的真正根因 ——
 * 它随后让 init-empty-db 打开旧库，报出一句与真因毫无关系的
 * 「生成的数据库包含 N 条档案，分发包必须是空库」，为此查了很久。
 * 所以这里不依赖那个会静默失效的调用：先试 rmSync，再核对，不行就自己走
 * scandir + unlink + rmdir（这几个 API 实测都正常）。
 *
 * @returns {boolean} 是否确实删干净了
 */
function removeDirDeep(dir) {
  if (!fs.existsSync(dir)) return true;
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 走下面的兜底 */ }
  if (!fs.existsSync(dir)) return true;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
    for (const it of items) {
      const p = path.join(d, it.name);
      if (it.isDirectory()) { walk(p); try { fs.rmdirSync(p); } catch (_) { /* 下一轮再试 */ } }
      else { try { fs.unlinkSync(p); } catch (_) { /* 下一轮再试 */ } }
    }
  };
  walk(dir);
  try { fs.rmdirSync(dir); } catch (_) { /* 可能还有残留 */ }
  return !fs.existsSync(dir);
}

/**
 * 报告一次子进程失败，**必须带上"为什么失败"**。
 *
 * 为什么单独抽出来：原来这里是
 *     console.error(((init.stdout || '') + (init.stderr || '')).trim());
 * 只打印子进程的输出。可**子进程根本没起来**时（例如被沙箱拦下，spawnSync 直接
 * 返回 error=EPERM、stdout/stderr 都是空串），这行打印出来是**空的** ——
 * 终端上只剩一句"测试库初始化失败："，后面什么都没有，完全无法诊断。
 * 本机实测就撞到过：DSH 的 workspace-write 沙箱不允许 Node 用管道 stdio 起子进程，
 * 真实原因是 `EPERM`，却被显示成"空错误"，白查了一轮。
 *
 * 所以这里把三个来源都摊开：spawn 自身的 error / 退出码与信号 / 子进程输出，
 * 并对"进程压根没起来"给出可行出路。
 */
function reportChildFailure(what, r) {
  const lines = [];
  if (r.error) {
    lines.push(`  · 进程没有启动起来：${r.error.code || ''} ${r.error.message || r.error}`.trim());
    if (String(r.error.code) === 'EPERM') {
      lines.push('  · EPERM 出现在 Windows 沙箱下：沙箱不允许 Node 用管道 stdio 起子进程。');
      lines.push('    出路（任选）：① 以更宽的权限运行本脚本；② 用 --url 复用已在运行的服务；');
      lines.push('    ③ 只跑不需要服务的套件：--offline。');
    }
  }
  if (!r.error) {
    if (r.signal) lines.push(`  · 被信号终止：${r.signal}`);
    else lines.push(`  · 退出码：${r.status}`);
  }
  const out = ((r.stdout || '') + (r.stderr || '')).trim();
  if (out) lines.push(out.split('\n').map((l) => '  ' + l).join('\n'));
  else if (!r.error) lines.push('  · 子进程没有任何输出（这本身就是线索：多半在能打印之前就退出了）');
  console.error(C.r + what + C.x);
  console.error(lines.join('\n'));
}

/**
 * 清理上一轮残留的临时服务。
 *
 * 为什么需要：`child.kill()` 之后进程句柄的释放有延迟（Windows 上尤其明显），
 * 若上一轮是异常结束（Ctrl+C、崩溃、被强杀），临时服务会活下来占着测试库。
 * 此时新一轮删除测试目录必然失败，随后 init-empty-db 打开的是**旧库**，
 * 报出来却是「生成的数据库包含 N 条档案，分发包必须是空库」——
 * 一句与真实原因毫无关系的错。（本项目为此查了很久）
 */
function killStaleServer() {
  let pid = 0;
  try {
    if (!fs.existsSync(PID_FILE)) return;
    pid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim());
    fs.unlinkSync(PID_FILE);   // 用 unlinkSync 而不是 rmSync：后者在本机实测会静默失效
  } catch (_) { return; }
  if (!pid) return;
  try { process.kill(pid, 0); } catch (_) { return; }   // 进程已不在，无需处理
  try {
    process.kill(pid);
    console.log(`${C.d}已清理上一轮残留的临时服务（PID ${pid}）${C.x}`);
  } catch (_) { /* 已退出或权限不足，交给后面的删除重试兜底 */ }
}

/** 停止临时服务，并**等它真的退出**（不等就会留下尚未释放的句柄） */
async function stopChild(proc) {
  if (!proc) return;
  try {
    if (proc.exitCode === null) {
      const exited = new Promise((r) => proc.once('exit', r));
      proc.kill();
      await Promise.race([exited, sleep(3000)]);
      if (proc.exitCode === null) {
        try { proc.kill('SIGKILL'); } catch (_) { /* ignore */ }
        await Promise.race([exited, sleep(1500)]);
      }
      console.log(`${C.d}临时服务已停止（PID ${proc.pid}，exitCode=${proc.exitCode}）${C.x}`);
    }
  } catch (_) { /* ignore */ }
  // PID 文件要删干净，否则下一轮会拿着一个陈旧 PID 去"清理"
  for (let i = 0; i < 5; i++) {
    try { fs.unlinkSync(PID_FILE); } catch (_) { /* 下一轮再试 */ }
    if (!fs.existsSync(PID_FILE)) return;
    await sleep(200);
  }
  console.log(`${C.y}警告${C.x} PID 文件未能删除：${PID_FILE}（下一轮会据此清理一个已不存在的进程，无副作用）`);
}

/** 套件定义：offline = 不需要服务 */
const SUITES = [
  { name: '跨平台就绪度', script: 'test-crossplatform.js', offline: true },
  { name: '迁移与档号规则', script: 'test-migration.js', offline: true },
  { name: '二维码验证', script: 'test-qrcode.js', offline: true },
  { name: '二维码交叉验证', script: 'test-qr-cross.js', offline: true },
  { name: '前端静态一致性', script: 'check-frontend.js', offline: true },
  { name: '批量导入模板', script: 'test-import-template.js', offline: true },
  { name: '附件正文提取实测', script: 'verify-extract.js', offline: true },
  // v4.28.0 扫描件按档号存储：PDF 页数解析是纯函数，不需要服务就能验
  { name: 'PDF 页数解析', script: 'test-pdf-info.js', offline: true },
  { name: '定时任务与待办', script: 'test-scheduler.js', offline: true },
  // 以下需要服务；顺序有依赖：先跑功能回归造出档案/盒，再跑扫码链路
  { name: 'v1 功能回归', script: 'selftest.js', offline: false },
  { name: 'v2 功能回归', script: 'selftest-v2.js', offline: false },
  { name: 'v3 功能回归', script: 'selftest-v3.js', offline: false },
  { name: '二维码扫码链路', script: 'test-qr-net.js', offline: false },
  { name: '二维码落地页', script: 'test-qr-public.js', offline: false },
  { name: '档案二维码', script: 'test-archive-qr.js', offline: false, needsData: true },
  { name: '前端冒烟测试', script: 'smoke-frontend.js', offline: false },
  { name: '安全与合规', script: 'test-security.js', offline: false },
  { name: '档案实体合规', script: 'test-compliance.js', offline: false },
  { name: '档号治理', script: 'test-numbering.js', offline: false, needsData: true },
  { name: '补充归档', script: 'test-supplement.js', offline: false, needsData: true },
  { name: '鉴定扩展', script: 'test-appraisal-ext.js', offline: false, needsData: true },
  { name: '检索智能化', script: 'test-search-smart.js', offline: false, needsData: true },
  { name: '全文搜索补全', script: 'test-fulltext.js', offline: false, needsData: true },
  { name: '审计防篡改', script: 'test-audit.js', offline: false, needsData: true },
  { name: '四性检测', script: 'test-detection.js', offline: false, needsData: true },
  { name: '元数据方案', script: 'test-metadata.js', offline: false },
  { name: '归档章与备考表', script: 'test-stamp.js', offline: false },
  { name: '借阅强化', script: 'test-loan.js', offline: false, needsData: true },
  { name: '备份与存储监控', script: 'test-backup.js', offline: false, needsData: true },
  { name: '待办中心接口', script: 'test-todos.js', offline: false, needsData: true },
  // 「首次使用向导」连同它的接口（/api/setup/*）在 v4.20.1 已整体删除：
  // 登录页定死两种身份之后，向导那套"建账号 / 选角色"成了废动作。
  // 它留下的唯一价值（全宗号还是出厂占位值 Z001 的提醒）改由工作台承担，
  // 数据来自 /api/stats/overview 的 unitIsFactory，与档号规则的校验共用同一个常量。
  { name: '扫码枪解析与工作台', script: 'test-scan.js', offline: false, needsData: true },
  { name: '扫描件按档号存储', script: 'test-scan-storage.js', offline: false, needsData: true },
  { name: '过程接收（项目/批次）', script: 'test-intake.js', offline: false, needsData: true },
  { name: '四处界面能力', script: 'test-ui.js', offline: false, needsData: true },
  { name: '删除留痕·回收站', script: 'test-trash.js', offline: false, needsData: true },
  { name: '移交进馆数据包', script: 'test-transfer-package.js', offline: false, needsData: true },
  { name: '常用检索', script: 'test-searches.js', offline: false },
  { name: '高级检索表达式', script: 'test-query-expr.js', offline: false, needsData: true },
  { name: '登录与口令防护', script: 'test-login.js', offline: false },
  // v4.27.0 手机号找回口令：自己拉起一个 dev 短信通道的临时服务，
  // 所以不需要外部服务（offline: true 表示"离线也能跑"），也不会碰 data/ 里的真实数据
  { name: '手机号找回口令', script: 'test-sms-login.js', offline: true },
  // 恢复演练 + 整库恢复：也要自己拉起/停掉服务（整库恢复本来就必须停服），
  // 所以同样是 offline，并且用独立数据目录，不碰同一次回归里别的套件的库
  { name: '恢复演练与整库恢复', script: 'test-restore.js', offline: true },
  // 制度五项（V4.32.0）：自己拉起独立服务与独立库，验证保管期限表/状态机/四性证据/件级授权/驾驶舱
  { name: '制度五项', script: 'test-v432.js', offline: true },
  // 授权与审计外存（V4.33.0）：自己拉起独立服务（随机端口）+ 独立库 + 独立外存目录，
  // 覆盖 未授权/有效/篡改/换机/过期 五种状态与读取降级，以及锚点落盘、外存追加、游标对齐
  { name: '授权与审计外存', script: 'test-v433.js', offline: true },
];

// ---------------------------------------------------------------- 参数

function parseArgs(argv) {
  const out = { url: '', data: '', offline: false, only: '', keep: false, keepData: false, noDemo: false, verbose: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--url') out.url = String(argv[++i] || '').replace(/\/+$/, '');
    else if (a === '--data') out.data = String(argv[++i] || '');
    else if (a === '--offline') out.offline = true;
    else if (a === '--only') out.only = String(argv[++i] || '');
    else if (a === '--keep') out.keep = true;
    else if (a === '--keep-data') out.keepData = true;
    else if (a === '--no-demo') out.noDemo = true;
    else if (a === '--verbose') out.verbose = true;
    else if (a === '-h' || a === '--help') out.help = true;
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));

if (args.help) {
  console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0].replace(/^\/\*\*?/, '').trim());
  process.exit(0);
}

// ---------------------------------------------------------------- 工具

const C = process.stdout.isTTY
  ? { g: '\x1b[32m', r: '\x1b[31m', y: '\x1b[33m', d: '\x1b[90m', b: '\x1b[1m', x: '\x1b[0m' }
  : { g: '', r: '', y: '', d: '', b: '', x: '' };

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const p = srv.address().port;
      srv.close(() => resolve(p));
    });
  });
}

function httpGet(url, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ ok: true, status: res.statusCode, body }));
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.setTimeout(timeoutMs, () => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
  });
}

async function waitForServer(base, ms = 40000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const r = await httpGet(base + '/api/ping');
    if (r.ok && r.status === 200) return true;
    await new Promise((r2) => setTimeout(r2, 300));
  }
  return false;
}

/** 从套件输出里抓「通过 N 项，失败 M 项」 */
function parseSummary(text) {
  let pass = 0, failed = 0, found = false;
  const re = /通过\s*(\d+)\s*项[，,]\s*失败\s*(\d+)\s*项/g;
  let m;
  while ((m = re.exec(text))) { pass = Number(m[1]); failed = Number(m[2]); found = true; }
  return { pass, failed, found };
}

// ---------------------------------------------------------------- 主流程

async function main() {
  const t0 = Date.now();
  let child = null;
  let base = args.url;

  let suites = SUITES.filter((s) => (args.offline ? s.offline : true));
  if (args.only) {
    const k = args.only.toLowerCase();
    suites = suites.filter((s) => s.name.toLowerCase().includes(k) || s.script.toLowerCase().includes(k));
  }
  if (!suites.length) {
    console.error(C.r + '没有匹配的套件（--only 关键字是否写错？）' + C.x);
    process.exit(1);
  }

  const needServer = suites.some((s) => !s.offline);

  // 测试数据目录：绝不碰使用者的 data/
  let dataDirForSuites = args.data ? path.resolve(args.data) : '';

  if (needServer && !base) {
    const testData = dataDirForSuites || REGRESS_DATA;
    const dbFile = path.join(testData, 'archive.db');
    if (!args.keepData || !fs.existsSync(dbFile)) {
      // 先清掉上一轮可能残留的临时服务，再删测试目录
      killStaleServer();
      // 清空测试目录必须**带重试**：上一轮的临时服务刚被 kill 时，
      // Windows 上文件句柄的回收有延迟，一次 rmSync 很可能撞上还没释放的句柄。
      // 踩过的坑：这里若直接失败退出，报出来的是「生成的数据库包含 N 条档案，
      // 分发包必须是空库」——一句与真实原因毫无关系的错，能查很久。
      let cleared = false;
      for (let attempt = 0; attempt < 8; attempt++) {
        cleared = removeDirDeep(testData);
        if (cleared) break;
        await new Promise((r) => setTimeout(r, 400));
      }
      if (!cleared) {
        console.error(C.r + '测试数据目录清理失败：' + C.x + dbFile + ' 仍然存在');
        console.error('  多半是上一轮回归残留的临时服务还占着它。');
        console.error('  处理：结束那个 node 进程（命令行含 --data ' + testData + '），或手动删除该目录后重试。');
        process.exit(1);
      }
      fs.mkdirSync(testData, { recursive: true });
      const init = spawnSync(
        process.execPath,
        ['--no-warnings', path.join('server', 'tools', 'init-empty-db.js'), dbFile],
        { cwd: APP_ROOT, encoding: 'utf8', windowsHide: true }
      );
      if (init.error || init.status !== 0) {
        reportChildFailure('测试库初始化失败：', init);
        process.exit(1);
      }
      console.log(`${C.d}测试库已重建：${testData}${C.x}`);

      // 播种演示数据：二维码扫码链路 / 落地页两个套件依赖「至少一个档案盒 + 至少一份档案」，
      // 而 v1~v3 自测结束会清理自己造的数据，所以夹具必须在起服务之前种好。
      if (!args.noDemo) {
        const seed = spawnSync(
          process.execPath,
          ['--no-warnings', path.join('server', 'tools', 'seed-demo.js'), testData],
          { cwd: APP_ROOT, encoding: 'utf8', windowsHide: true }
        );
        if (seed.error || seed.status !== 0) {
          reportChildFailure('演示数据播种失败：', seed);
          process.exit(1);
        }
        console.log(`${C.d}${((seed.stdout || '').trim())}${C.x}`);
      }
    } else {
      console.log(`${C.d}测试库复用（--keep-data）：${testData}${C.x}`);
    }
    dataDirForSuites = testData;

    const port = await freePort();
    base = `http://127.0.0.1:${port}`;
    console.log(`${C.d}拉起临时服务：${base}（不影响 8787 上正在运行的系统）${C.x}`);
    child = spawn(
      process.execPath,
      ['--no-warnings', path.join('server', 'server.js'), '--port', String(port), '--data', testData],
      { cwd: APP_ROOT, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true }
    );
    // 记下临时服务的 PID：本轮若异常结束（Ctrl+C、崩溃、被强杀），
    // 下一轮启动时就能据此把它清掉，不会留下占着测试库的僵尸服务。
    try { fs.writeFileSync(PID_FILE, String(child.pid), 'utf8'); } catch (_) { /* 写不进不阻断 */ }
    let bootLog = '';
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (c) => { bootLog += c; });
    child.stderr.on('data', (c) => { bootLog += c; });
    child.on('exit', (code) => {
      if (code !== 0 && code !== null && !stopping) {
        console.error(C.r + `临时服务意外退出，exit=${code}` + C.x);
        console.error(bootLog.split('\n').filter(Boolean).slice(-20).join('\n'));
      }
    });
    const up = await waitForServer(base);
    if (!up) {
      console.error(C.r + '临时服务启动失败，输出如下：' + C.x);
      console.error(bootLog.split('\n').filter(Boolean).slice(-30).join('\n'));
      if (child) child.kill();
      process.exit(1);
    }
    console.log(`${C.d}服务就绪${C.x}`);
  }

  if (base && !dataDirForSuites && suites.some((s) => s.needsData)) {
    console.log(`${C.y}注意${C.x} 复用外部服务时未指定 --data：「档案二维码」套件将按程序默认的 data/ 目录核对落盘文件，若与被测服务的数据目录不一致可能误报。`);
  }

  console.log('');
  const results = [];
  for (const s of suites) {
    const scriptPath = path.join(TOOLS, s.script);
    if (!fs.existsSync(scriptPath)) {
      results.push({ ...s, code: 127, pass: 0, failed: 0, ms: 0, note: '脚本不存在' });
      console.log(`${C.y}跳过${C.x}  ${s.name.padEnd(18, ' ')} ${C.d}${s.script} 不存在${C.x}`);
      continue;
    }
    const argv = ['--no-warnings', scriptPath];
    if (!s.offline) argv.push(base);
    if (s.needsData) argv.push(dataDirForSuites || path.join(APP_ROOT, 'data'));

    const t = Date.now();
    const r = spawnSync(process.execPath, argv, {
      cwd: APP_ROOT,
      encoding: 'utf8',
      timeout: 10 * 60 * 1000,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    const ms = Date.now() - t;
    const out = (r.stdout || '') + (r.stderr || '');
    // 退出码优先级：spawn 自身失败（error）> 被信号杀 > 超时 > 正常退出码。
    // 原来这里是 `r.status === null ? 124 : r.status` —— spawn 失败时 status 也是 null，
    // 于是 EPERM 这类"进程根本没起来"会被显示成"超时(124)"，指错了方向。
    const code = r.error ? 126 : (r.status === null ? (r.signal ? 125 : 124) : r.status);
    const sum = parseSummary(out);

    results.push({ ...s, code, pass: sum.pass, failed: sum.failed, ms, out, spawnError: r.error || null });

    const okMark = code === 0 ? `${C.g}通过${C.x}` : `${C.r}失败${C.x}`;
    const counts = sum.found ? `${C.d}(通过 ${sum.pass} / 失败 ${sum.failed})${C.x}` : '';
    console.log(`${okMark}  ${s.name.padEnd(18, ' ')} ${String((ms / 1000).toFixed(1)).padStart(6)}s ${counts}`);
    if (code !== 0) {
      // 进程没起来就没什么可分析的：先把"没起来"这件事本身说清楚（否则会显示成空输出）
      if (r.error) {
        reportChildFailure(`套件「${s.name}」的进程没有启动起来：`, r);
        results[results.length - 1].note = 'spawn ' + (r.error.code || 'error');
      } else {
        const lines = out.split('\n').map((l) => l.trim()).filter(Boolean);
        const failLines = lines.filter((l) => /失败明细|^\s*-\s|✗|❌|Error|错误|失败/.test(l)).slice(0, 25);
        console.log((args.verbose ? lines : failLines).map((l) => `      ${C.d}${l}${C.x}`).join('\n'));
      }
    }
  }

  const failedSuites = results.filter((r) => r.code !== 0);
  const totalPass = results.reduce((n, r) => n + r.pass, 0);
  const totalFail = results.reduce((n, r) => n + r.failed, 0);
  const secs = ((Date.now() - t0) / 1000).toFixed(1);

  console.log('');
  console.log(C.b + '─'.repeat(64) + C.x);
  if (failedSuites.length) {
    console.log(`${C.r}${C.b}回归失败：${failedSuites.length} 个套件未通过${C.x}`);
    for (const f of failedSuites) console.log(`  ${C.r}✗${C.x} ${f.name}  (exit=${f.code}${f.note ? ', ' + f.note : ''})`);
  } else {
    console.log(`${C.g}${C.b}回归全部通过${C.x}`);
  }
  console.log(`检查项合计：通过 ${totalPass} 项，失败 ${totalFail} 项；套件 ${results.length} 个；耗时 ${secs}s`);
  console.log(C.b + '─'.repeat(64) + C.x);

  // 退出码与摘要不一致时告警（脚本漏写 exit 的情况）
  for (const r of results) {
    if (r.code === 0 && r.failed > 0) console.log(`${C.y}警告${C.x} ${r.name}：退出码为 0 但摘要显示失败 ${r.failed} 项`);
    if (r.code !== 0 && r.failed === 0 && r.pass > 0) console.log(`${C.y}警告${C.x} ${r.name}：摘要显示全部通过但退出码为 ${r.code}`);
  }

  if (child && !args.keep) {
    stopping = true;
    // 等它**真的退出**：不等的话，下一轮会因句柄尚未释放而删不掉测试库
    await stopChild(child);
  } else if (child && args.keep) {
    console.log(`${C.d}临时服务保留在 ${base}（--keep），PID ${child.pid}${C.x}`);
  }

  process.exit(failedSuites.length ? 1 : 0);
}

let stopping = false;

main().catch((e) => {
  console.error('回归入口异常终止：', e);
  process.exit(1);
});
