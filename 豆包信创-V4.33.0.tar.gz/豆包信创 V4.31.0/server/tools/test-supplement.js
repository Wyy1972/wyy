/**
 * 补充归档（v4.9.0）验证 —— 关联件 / 补充归档登记 / 附件插入排序 / 正文替换留痕
 *
 * 业务背景（决定了这套件测什么）：
 *   DA/T 22—2015 以「件」为整理单位。新发现的资料要归入已有档案时，
 *   **标准做法是另立一件并建立关联**，而不是往已编好的件里插页 ——
 *   插页会让该件的页数、归档章、元数据 M05/M07、已打印的移交清册全部对不上。
 *   但"另立一件"之后，两份材料在业务上是同一事由，**必须能互相找得到**，
 *   而且这次补入要能追溯（谁、何时、为什么、补的是哪一件）。
 *
 * 所以本套件盯五件事：
 *   ① 关联是**双向**的（两个方向都看得到），且不能自关联、不能重复登记；
 *   ② 补充归档**进审计链**，并能出可打印的登记表；
 *   ③ 关联的对方档案**超出密级时必须整条省略**（连数量都不给）；
 *   ④ 附件顺序可调整（上移/下移/插到第 N 位），且顺序真实落库；
 *   ⑤ 替换正文**保留旧版留痕**（旧哈希/大小/原因/经办人），而不是等于"删掉重传"。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json, raw: req };
}

function multipart(files, fields = {}) {
  const boundary = '----supp' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const TAG = 'SP' + Math.random().toString(16).slice(2, 8).toUpperCase();
const YR = '2042';

async function main() {
  const admin = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const leaf = flat.find((c) => c.level === 2 && String(c.code).startsWith('WS-'));
  check('拿到文书档案二级分类', !!leaf, leaf && leaf.code);
  if (!leaf) process.exit(1);

  const createdIds = [];
  async function mk(title, extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({ type_code: 'WS', category_id: leaf.id, title, year: YR }, extra),
    });
    if (r.body && r.body.ok) createdIds.push(r.body.data.id);
    return r;
  }

  const A = await mk('补充归档·原档案' + TAG);
  const B = await mk('补充归档·新件甲' + TAG);
  const C = await mk('补充归档·新件乙' + TAG);
  const A2 = await mk('补充归档·原档案二' + TAG);
  check('建出原档案与新增件', A.body.ok && B.body.ok && C.body.ok && A2.body.ok,
    [A, B, C, A2].map((x) => x.status).join('/'));
  const aid = A.body.data.id; const bid = B.body.data.id; const cid = C.body.data.id; const a2id = A2.body.data.id;
  const bNum = B.body.data.archive_number;

  // =========================================================================
  section('一、关联件：双向一致、不能自关联、不能重复');
  // =========================================================================
  const lk = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [bid], kind: '参见', note: '同一事由' } });
  check('建立关联成功', lk.status === 200 && lk.body.ok && lk.body.data.created.length === 1,
    JSON.stringify(lk.body).slice(0, 160));
  const linkId = lk.body.ok && lk.body.data.created[0] ? lk.body.data.created[0].id : 0;

  const la = await admin.json(`/api/archives/${aid}/links`);
  check('原档案侧能看到关联', la.body.ok && la.body.data.list.length === 1, JSON.stringify(la.body.data).slice(0, 160));
  check('原档案侧方向为 out', la.body.data.list[0].direction === 'out', la.body.data.list[0].direction);
  check('关联里带对方档号与题名',
    la.body.data.list[0].archive.archive_number === bNum && la.body.data.list[0].archive.title.includes('新件甲'),
    JSON.stringify(la.body.data.list[0].archive));

  const lb = await admin.json(`/api/archives/${bid}/links`);
  check('★ 新件侧也能看到（关联是双向的）', lb.body.ok && lb.body.data.list.length === 1,
    JSON.stringify(lb.body.data).slice(0, 160));
  check('★ 新件侧方向为 in', lb.body.data.list[0].direction === 'in', lb.body.data.list[0].direction);

  const dup = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [bid], kind: '参见' } });
  check('重复建同类关联被跳过（不报错但也不重复存）',
    dup.status === 200 && dup.body.data.created.length === 0 && dup.body.data.skipped.length === 1,
    JSON.stringify(dup.body.data).slice(0, 160));
  check('跳过的原因说清了是重复', /已有同类关联/.test(dup.body.data.skipped[0].reason),
    dup.body.data.skipped[0].reason);

  const self = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [aid], kind: '参见' } });
  check('不能与自身关联', self.body.data.created.length === 0 && /自身/.test(self.body.data.skipped[0].reason),
    JSON.stringify(self.body.data.skipped));

  const ghost = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [99999999], kind: '参见' } });
  check('关联不存在的档案被拒绝（按不可见处理）',
    ghost.body.data.created.length === 0 && /不可见|不存在/.test(ghost.body.data.skipped[0].reason),
    JSON.stringify(ghost.body.data.skipped));

  const badKind = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [cid], kind: '随便什么' } });
  check('非法的关联种类被拒（400）', badKind.status === 400, String(badKind.status));
  check('拒绝时列出可选种类', /参见/.test(badKind.body.error || ''), badKind.body.error);
  const noIds = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [] } });
  check('不选档案被拒（400）', noIds.status === 400, String(noIds.status));

  const detailA = await admin.json('/api/archives/' + aid);
  check('档案详情里直接带出关联件', Array.isArray(detailA.body.data.links) && detailA.body.data.links.length === 1,
    JSON.stringify(detailA.body.data.links || []).slice(0, 140));

  const delLk = await admin.json('/api/links/' + linkId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('解除关联成功', delLk.status === 200 && delLk.body.ok, String(delLk.status));
  check('★ 解除后原档案侧不再显示', (await admin.json(`/api/archives/${aid}/links`)).body.data.list.length === 0);
  check('★ 解除后新件侧也不再显示（一条记录管两个方向）',
    (await admin.json(`/api/archives/${bid}/links`)).body.data.list.length === 0);
  check('解除不存在的关联返回 404', (await admin.json('/api/links/99999999', { method: 'DELETE', json: { reason: '测试夹具清理' } })).status === 404);

  // =========================================================================
  section('二、补充归档登记');
  // =========================================================================
  const noReason = await admin.json(`/api/archives/${aid}/supplement`, { method: 'POST', json: { new_ids: [bid] } });
  check('不填原因被拒（400）', noReason.status === 400, String(noReason.status));
  check('拒绝原因说明了要填什么', /原因/.test(noReason.body.error || ''), noReason.body.error);

  const sup = await admin.json(`/api/archives/${aid}/supplement`, {
    method: 'POST', json: { new_ids: [bid, cid], reason: '原件附件后补', note: '移交时补入' },
  });
  check('补充归档登记成功', sup.status === 200 && sup.body.ok && sup.body.data.created.length === 2,
    JSON.stringify(sup.body).slice(0, 170));
  check('返回了登记表打印地址', /supplement\/print/.test(sup.body.data.print_url || ''), sup.body.data.print_url);

  const supLinks = await admin.json(`/api/archives/${aid}/links`);
  const supKind = (supLinks.body.data.list || []).filter((l) => l.kind === '补充归档');
  check('登记后产生 2 条「补充归档」关联', supKind.length === 2, String(supKind.length));
  check('补充归档的备注里存下了原因', /原件附件后补/.test(supKind[0].note || ''), supKind[0].note);

  const supAgain = await admin.json(`/api/archives/${aid}/supplement`, {
    method: 'POST', json: { new_ids: [bid], reason: '再来一次' },
  });
  check('重复登记被拒（400）', supAgain.status === 400, String(supAgain.status));
  check('拒绝原因说清是重复', /已经登记过/.test(supAgain.body.error || ''), supAgain.body.error);

  const supSelf = await admin.json(`/api/archives/${aid}/supplement`, {
    method: 'POST', json: { new_ids: [aid], reason: '自补' },
  });
  check('不能把档案补充归档到它自己', supSelf.status === 400, String(supSelf.status));

  // 审计链：补充归档是业务动作，必须留痕
  const logs = await admin.json('/api/logs?size=200');
  check('审计日志可读', logs.status === 200 && Array.isArray(logs.body.data.list), String(logs.status));
  const supLog = (logs.body.data.list || []).find((l) => /补充归档登记/.test(l.action || ''));
  check('★ 补充归档登记进了审计日志', !!supLog, (logs.body.data.list || []).slice(0, 3).map((l) => l.action).join(','));
  check('日志里记了原档案号与原因',
    !!supLog && String(supLog.target || '').length > 0 && /原件附件后补/.test(supLog.detail || ''),
    supLog && `${supLog.target} ${supLog.detail}`);
  const chain = await admin.json('/api/logs/verify');
  check('审计链仍然完整（写入未破坏哈希链）', chain.status === 200 && chain.body.data.ok === true,
    JSON.stringify(chain.body.data || {}).slice(0, 140));

  const supPrint = await admin.raw(`/api/archives/${aid}/supplement/print`);
  const supHtml = await supPrint.text();
  check('补充归档登记表可打印', supPrint.status === 200 && /补 充 归 档 登 记 表/.test(supHtml), String(supPrint.status));
  check('登记表里列了补入件的档号', supHtml.includes(bNum), bNum);
  check('登记表里写了依据（DA/T 22—2015）', /DA\/T 22—2015/.test(supHtml));
  check('登记表有签署栏', /整理人/.test(supHtml) && /检查人/.test(supHtml));

  // 备考表：纸质实体上唯一能留下补充归档痕迹的地方
  const box = await admin.json('/api/boxes', {
    method: 'POST', json: { box_code: TAG + '-BOX', title: TAG + ' 补充归档测试盒', type_code: 'WS', capacity: 50 },
  });
  check('建盒成功', box.status === 200 && box.body.ok, JSON.stringify(box.body).slice(0, 140));
  const boxId = box.body.ok ? box.body.data.id : 0;
  if (boxId) {
    const asg = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [a2id] } });
    check('装盒成功', asg.status === 200 && asg.body.ok, JSON.stringify(asg.body).slice(0, 140));
    const sup2 = await admin.json(`/api/archives/${a2id}/supplement`, {
      method: 'POST', json: { new_ids: [cid], reason: '配套材料后补', add_to_box_note: true },
    });
    check('补充归档并写入备考表成功', sup2.status === 200 && sup2.body.data.box_note_updated === true,
      JSON.stringify(sup2.body).slice(0, 170));
    check('返回了写入的盒号', sup2.body.data.box_code === TAG + '-BOX', sup2.body.data.box_code);
    const bk = await admin.json(`/api/boxes/${boxId}/beikaobiao`);
    check('★ 备考表「盒内文件情况说明」里出现了补充归档记录',
      /补充归档/.test((bk.body.data && bk.body.data.inventory_note) || ''),
      (bk.body.data && bk.body.data.inventory_note) || '(空)');
    check('备考表记录里带了补入件的档号',
      ((bk.body.data && bk.body.data.inventory_note) || '').includes(
        (await admin.json('/api/archives/' + cid)).body.data.archive_number),
      (bk.body.data && bk.body.data.inventory_note) || '');
  }

  // =========================================================================
  section('三、密级：关联的对方看不到时整条省略');
  // =========================================================================
  const D = await mk('补充归档·涉密件' + TAG, { secret_level: '机密' });
  check('建出机密档案', D.body.ok && D.body.data.id > 0, JSON.stringify(D.body).slice(0, 140));
  const did = D.body.data.id;

  const rdName = TAG.toLowerCase() + '_rd';
  const mkUser = await admin.json('/api/users', {
    method: 'POST', json: { username: rdName, display_name: '补充归档权限测试', password: 'Test@12345', role: 'reader' },
  });
  check('创建低权限账号成功', mkUser.status === 200 && mkUser.body.ok, JSON.stringify(mkUser.body).slice(0, 150));
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: rdName, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出

  const linkSecret = await admin.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [did], kind: '参见' } });
  check('管理员建了一条指向机密档案的关联', linkSecret.body.ok && linkSecret.body.data.created.length === 1,
    JSON.stringify(linkSecret.body).slice(0, 150));
  const adminLinks = await admin.json(`/api/archives/${aid}/links`);
  check('管理员能看到这条关联', adminLinks.body.data.list.length >= 1, String(adminLinks.body.data.list.length));

  const rdLinks = await reader.json(`/api/archives/${aid}/links`);
  check('低权限账号能读到公开档案', rdLinks.status === 200, String(rdLinks.status));
  const leaked = (rdLinks.body.data.list || []).filter((l) => l.archive.id === did);
  check('★ 越密级的关联整条不出现（不泄露存在性）', leaked.length === 0,
    JSON.stringify(leaked.map((l) => l.archive.archive_number)));
  const rdDetail = await reader.json('/api/archives/' + aid);
  check('★ 详情里的关联列表同样过滤干净',
    (rdDetail.body.data.links || []).every((l) => l.archive.id !== did),
    JSON.stringify((rdDetail.body.data.links || []).map((l) => l.archive.id)));
  check('低权限账号不能建关联（403）',
    (await reader.json(`/api/archives/${aid}/links`, { method: 'POST', json: { to_ids: [bid], kind: '参见' } })).status === 403);
  check('低权限账号不能补充归档（403）',
    (await reader.json(`/api/archives/${aid}/supplement`, { method: 'POST', json: { new_ids: [bid], reason: 'x' } })).status === 403);
  check('低权限账号不能调整附件顺序（403）',
    (await reader.json('/api/files/1/move', { method: 'POST', json: { dir: 'up' } })).status === 403);

  // =========================================================================
  section('四、附件插入与排序');
  // =========================================================================
  // 注意：multipart() 每次调用都会生成新 boundary，必须**只构造一次**再同时用作头与体
  const mp3 = multipart([{ filename: '件3.txt', data: `${TAG} 第三件正文` }]);
  const up3 = await admin.req(`/api/archives/${aid}/files`, {
    method: 'POST', headers: { 'Content-Type': mp3.contentType }, body: mp3.body,
  });
  const up3Json = await up3.json();
  check('上传附件成功', up3.status === 200 && up3Json.ok, JSON.stringify(up3Json).slice(0, 150));

  const mp12 = multipart([
    { filename: '件1.txt', data: `${TAG} 第一件正文` },
    { filename: '件2.txt', data: `${TAG} 第二件正文` },
  ]);
  const upMore = await admin.req(`/api/archives/${aid}/files`, {
    method: 'POST', headers: { 'Content-Type': mp12.contentType }, body: mp12.body,
  });
  check('再上传两个附件', upMore.status === 200, String(upMore.status));

  async function fileOrder() {
    const d = await admin.json('/api/archives/' + aid);
    return (d.body.data.files || []).map((f) => f.original_name);
  }
  const order0 = await fileOrder();
  check('附件按上传顺序排列（共 3 个）', order0.length === 3, JSON.stringify(order0));
  check('初始顺序正确', order0[0] === '件3.txt' && order0[1] === '件1.txt' && order0[2] === '件2.txt',
    JSON.stringify(order0));

  const idsResp = await admin.json('/api/archives/' + aid);
  const fids = (idsResp.body.data.files || []).map((f) => f.id);
  const mv = await admin.json(`/api/files/${fids[0]}/move`, { method: 'POST', json: { to: 3 } });
  check('把第 1 个挪到第 3 位', mv.status === 200 && mv.body.data.moved === true && mv.body.data.position === 3,
    JSON.stringify(mv.body.data).slice(0, 140));
  const order1 = await fileOrder();
  check('★ 顺序真实落库（件3 到了最后）', order1[2] === '件3.txt', JSON.stringify(order1));

  const mvUp = await admin.json(`/api/files/${fids[0]}/move`, { method: 'POST', json: { dir: 'up' } });
  check('上移一位生效', mvUp.body.data.moved === true && mvUp.body.data.position === 2, JSON.stringify(mvUp.body.data).slice(0, 120));
  const order2 = await fileOrder();
  check('上移后顺序正确', order2[1] === '件3.txt', JSON.stringify(order2));

  const mvTop = await admin.json(`/api/files/${fids[0]}/move`, { method: 'POST', json: { dir: 'down' } });
  check('下移一位生效', mvTop.body.data.moved === true, JSON.stringify(mvTop.body.data).slice(0, 120));

  // 插到第 1 位：新上传的文件应直接排在最前
  const mpPos = multipart([{ filename: '插入件.txt', data: `${TAG} 插入正文` }], { position: '1' });
  const upPos = await admin.req(`/api/archives/${aid}/files`, {
    method: 'POST', headers: { 'Content-Type': mpPos.contentType }, body: mpPos.body,
  });
  check('带位置上传成功', upPos.status === 200, String(upPos.status));
  const order3 = await fileOrder();
  check('★ 指定 position=1 的新附件排在最前（不是追加到末尾）',
    order3[0] === '插入件.txt', JSON.stringify(order3));

  const lastResp = await admin.json('/api/archives/' + aid);
  const lastFid = (lastResp.body.data.files || []).slice(-1)[0].id;
  const atEnd = await admin.json(`/api/files/${lastFid}/move`, { method: 'POST', json: { dir: 'down' } });
  check('已在末尾时下移是静默无效（不算错误）', atEnd.status === 200 && atEnd.body.data.moved === false,
    JSON.stringify(atEnd.body.data).slice(0, 120));
  check('移动不存在的文件返回 404', (await admin.json('/api/files/99999999/move', { method: 'POST', json: { dir: 'up' } })).status === 404);

  // =========================================================================
  section('五、正文替换留痕');
  // =========================================================================
  const before = (await admin.json('/api/archives/' + aid)).body.data.files.find((f) => f.id === fids[0]);
  const mpRep = multipart([{ filename: '重新扫描.txt', data: `${TAG} 这是重新扫描后的正文，内容更长一些。` }], { reason: '原扫描缺页，重新扫描' });
  const rep = await admin.req(`/api/files/${fids[0]}/replace`, {
    method: 'POST', headers: { 'Content-Type': mpRep.contentType }, body: mpRep.body,
  });
  const repJson = await rep.json();
  check('替换正文成功', rep.status === 200 && repJson.ok, JSON.stringify(repJson).slice(0, 170));
  check('替换后哈希变了', repJson.ok && repJson.data.sha256 && repJson.data.sha256 !== before.sha256,
    `${before.sha256} → ${repJson.ok ? repJson.data.sha256 : ''}`);

  const reps = await admin.json(`/api/archives/${aid}/replacements`);
  check('替换留痕可查', reps.status === 200 && reps.body.data.total === 1, JSON.stringify(reps.body.data).slice(0, 150));
  const r0 = (reps.body.data.list || [])[0] || {};
  check('★ 留痕里保存了旧版 SHA-256', r0.old_sha256 === before.sha256, `${r0.old_sha256} vs ${before.sha256}`);
  check('留痕里保存了旧版大小', Number(r0.old_size) === Number(before.size), `${r0.old_size} vs ${before.size}`);
  check('留痕里保存了替换原因', /缺页/.test(r0.reason || ''), r0.reason);
  check('留痕里记了经办人', !!r0.replaced_by, String(r0.replaced_by));
  check('留痕里记了替换时间', /^\d{4}-\d{2}-\d{2}/.test(String(r0.replaced_at || '')), r0.replaced_at);

  const afterRep = (await admin.json('/api/archives/' + aid)).body.data.files.find((f) => f.id === fids[0]);
  check('替换后文件名已更新', afterRep.original_name === '重新扫描.txt', afterRep.original_name);
  check('替换后正文可检索（重新提取了正文）',
    (await admin.json('/api/search/text?kw=' + encodeURIComponent('重新扫描后的正文'))).body.data.list.length >= 1,
    '正文索引未命中');

  const mpGhost = multipart([{ filename: 'x.txt', data: 'x' }]);
  const repGhost = await admin.req('/api/files/99999999/replace', {
    method: 'POST', headers: { 'Content-Type': mpGhost.contentType }, body: mpGhost.body,
  });
  check('替换不存在的文件返回 404', repGhost.status === 404, String(repGhost.status));
  const mpRd = multipart([{ filename: 'x.txt', data: 'x' }]);
  const rdRep = await reader.req(`/api/files/${fids[0]}/replace`, {
    method: 'POST', headers: { 'Content-Type': mpRd.contentType }, body: mpRd.body,
  });
  check('低权限账号不能替换正文（403）', rdRep.status === 403, String(rdRep.status));

  // =========================================================================
  section('六、收尾');
  // =========================================================================
  if (boxId) await admin.json('/api/boxes/' + boxId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of createdIds) await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  if (mkUser.body.ok) await admin.json('/api/users/' + mkUser.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const left = await admin.json('/api/archives?kw=' + encodeURIComponent(TAG) + '&size=50');
  check('清理：没有残留测试档案', left.body.ok && (left.body.data.list || []).length === 0,
    String(left.body.ok ? (left.body.data.list || []).length : left.status));

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
