/**
 * 第 3 版新增功能自测：附件正文检索、档案移交、数据体检与批量修改、统计增强
 * 用法：node server/tools/selftest-v3.js [http://127.0.0.1:8796]
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 200) }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  return { req, json };
}

function multipart(fields, files) {
  const boundary = '----v3test' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields || {})) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files || []) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

/** 用纯算法构造一个最小可用的 docx（ZIP + document.xml），用于验证真实提取链路 */
function buildDocx(text) {
  const files = [
    { name: '[Content_Types].xml', data: Buffer.from('<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/></Types>', 'utf8') },
    { name: 'word/document.xml', data: Buffer.from(`<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>${text}</w:t></w:r></w:p></w:body></w:document>`, 'utf8') },
  ];
  const chunks = [];
  const central = [];
  let offset = 0;
  const crcTable = (() => {
    const t = new Int32Array(256);
    for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[i] = c; }
    return t;
  })();
  const crc32 = (buf) => {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };
  for (const f of files) {
    const nameBuf = Buffer.from(f.name, 'utf8');
    const comp = zlib.deflateRawSync(f.data);
    const crc = crc32(f.data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(8, 8);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(comp.length, 18);
    local.writeUInt32LE(f.data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    chunks.push(local, nameBuf, comp);
    central.push({ nameBuf, crc, comp: comp.length, raw: f.data.length, offset });
    offset += local.length + nameBuf.length + comp.length;
  }
  const cdStart = offset;
  let cdSize = 0;
  for (const c of central) {
    const h = Buffer.alloc(46);
    h.writeUInt32LE(0x02014b50, 0);
    h.writeUInt16LE(20, 4); h.writeUInt16LE(20, 6);
    h.writeUInt16LE(0x0800, 8); h.writeUInt16LE(8, 10);
    h.writeUInt32LE(c.crc, 16);
    h.writeUInt32LE(c.comp, 20); h.writeUInt32LE(c.raw, 24);
    h.writeUInt16LE(c.nameBuf.length, 28);
    h.writeUInt32LE(c.offset, 42);
    chunks.push(h, c.nameBuf);
    cdSize += h.length + c.nameBuf.length;
  }
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(central.length, 8);
  end.writeUInt16LE(central.length, 10);
  end.writeUInt32LE(cdSize, 12);
  end.writeUInt32LE(cdStart, 16);
  chunks.push(end);
  return Buffer.concat(chunks);
}

const created = { archives: [], transfers: [], users: [] };

async function main() {
  console.log('第 3 版新功能自测 → ' + BASE + '\n');
  const admin = makeSession();
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  if (login.status !== 200) { console.error('登录失败：', JSON.stringify(login.body)); process.exit(1); }
  console.log('已登录管理员');

  // 清理上一轮残留
  {
    let n = 0;
    for (const kw of ['V3测试', '正文检索测试']) {
      const found = await admin.json('/api/archives?kw=' + encodeURIComponent(kw) + '&size=100');
      for (const row of (found.body.data.list || [])) {
        if ((await admin.json('/api/archives/' + row.id, { method: 'DELETE', json: { reason: '测试夹具清理' } })).status === 200) n++;
      }
    }
    const ts = await admin.json('/api/transfers?size=100');
    for (const t of (ts.body.data.list || [])) {
      if (/V3/.test(t.title || '')) await admin.json('/api/transfers/' + t.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
    const users = await admin.json('/api/users');
    for (const u of (users.body.data.list || [])) {
      if (u.username === 'v3reader') await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
    if (n) console.log(`已清理残留档案 ${n} 条`);
  }

  const cats = (await admin.json('/api/categories')).body.data;
  const cat = cats.flat.find((c) => c.code === 'WS-XZ') || cats.flat[0];

  // ============================================================ 1. 正文检索
  section('1. 附件正文检索（PDF/Office 文本提取）');
  const mk = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', title: 'V3测试档案-正文检索', category_id: cat.id,
      year: '2032', archive_date: '2032-03-01', retention: '永久', responsible: '测试', department: '测试科',
    },
  });
  check('建立测试档案', mk.status === 200, JSON.stringify(mk.body).slice(0, 120));
  const aId = mk.body.data.id;
  created.archives.push(aId);

  const TXT_WORD = '南沙区内涝防治专项检查报告';
  const txtContent = `${TXT_WORD}\n本报告说明了排水管网的改造计划与资金安排，涉及应急响应机制。\n`;
  const docxText = 'V3测试公文标题 关于加强汛期值班管理的通知 各科室要严格落实值班制度';
  const docx = buildDocx(docxText);

  const mp = multipart({ kind: '正文' }, [
    { filename: 'V3测试报告.txt', mime: 'text/plain', data: txtContent },
    { filename: 'V3测试公文.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', data: docx },
    { filename: 'V3扫描件模拟.pdf', mime: 'application/pdf', data: Buffer.from('%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n', 'utf8') },
  ]);
  const up = await admin.req(`/api/archives/${aId}/files`, { method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body });
  const upJson = await up.json();
  check('上传附件成功（含 txt / docx / 模拟扫描件）', up.status === 200 && upJson.ok && upJson.data.files.length === 3,
    JSON.stringify(upJson).slice(0, 200));

  const tRes = (upJson.data.textResults || []);
  const txtRes = tRes.find((r) => /\.txt$/.test(r.name));
  const docxRes = tRes.find((r) => /\.docx$/.test(r.name));
  const pdfRes = tRes.find((r) => /\.pdf$/.test(r.name));
  check('上传时自动提取 txt 正文', txtRes && txtRes.ok && txtRes.chars > 20, JSON.stringify(txtRes));
  check('上传时自动提取 docx 正文（含中文）', docxRes && docxRes.ok && docxRes.chars > 10, JSON.stringify(docxRes));
  check('无文字层 PDF 被标记为不可提取并给出原因', pdfRes && !pdfRes.ok && /没有文字层|OCR/.test(pdfRes.reason || ''),
    JSON.stringify(pdfRes));

  const hitTxt = await admin.json('/api/search/text?kw=' + encodeURIComponent('内涝防治'));
  check('按正文关键词检索命中', hitTxt.status === 200 && hitTxt.body.data.total >= 1,
    'total=' + (hitTxt.body.data.total));
  const first = (hitTxt.body.data.list || [])[0];
  check('命中结果带档案信息与文件名', first && first.archive_code && first.original_name, JSON.stringify(first || {}).slice(0, 160));
  check('命中结果带上下文片段', first && /内涝防治/.test(first.snippet || ''), first ? first.snippet : '');
  check('命中片段含前后文（非仅关键词）', first && (first.snippet || '').length > 10, first ? String(first.snippet).length + ' 字' : '');

  const hitDocx = await admin.json('/api/search/text?kw=' + encodeURIComponent('汛期值班管理'));
  check('docx 正文可被检索（验证提取链路真实可用）', hitDocx.body.data.total >= 1,
    'total=' + hitDocx.body.data.total);

  const hitNone = await admin.json('/api/search/text?kw=' + encodeURIComponent('这个词绝对不存在zzz'));
  check('无匹配关键词返回空', hitNone.body.data.total === 0);
  const noKw = await admin.json('/api/search/text');
  check('空关键词被拒绝', noKw.status === 400, 'HTTP ' + noKw.status);

  const stats = await admin.json('/api/search/text/stats');
  check('正文索引统计可用', stats.status === 200 && stats.body.data.indexed >= 2,
    JSON.stringify(stats.body.data).slice(0, 160));

  const filesList = (await admin.json('/api/archives/' + aId)).body.data.files;
  const txtFile = filesList.find((f) => /\.txt$/.test(f.original_name));
  const docxFile = filesList.find((f) => /\.docx$/.test(f.original_name));
  const pdfFile = filesList.find((f) => /\.pdf$/.test(f.original_name));
  const ft = await admin.json(`/api/files/${txtFile.id}/text`);
  check('可查看单个附件的提取结果', ft.status === 200 && ft.body.data.status === '成功' && ft.body.data.char_count > 0,
    JSON.stringify(ft.body.data).slice(0, 140));
  const fp = await admin.json(`/api/files/${pdfFile.id}/text`);
  check('扫描件标注为提取失败并带原因', fp.body.data.status !== '成功' && !!fp.body.data.reason,
    JSON.stringify(fp.body.data).slice(0, 140));
  const fprev = await admin.json(`/api/files/${txtFile.id}/text?preview=1`);
  check('正文可预览（截断）', fprev.body.data.content.length > 0);

  // 扫描件被正确跳过
  const reindex = await admin.json('/api/search/text/reindex', { method: 'POST', json: { limit: 50 } });
  check('补建正文索引接口可用', reindex.status === 200 && typeof reindex.body.data.processed === 'number',
    JSON.stringify(reindex.body.data).slice(0, 160));

  // ============================================================ 2. 档案移交
  section('2. 档案移交');
  const transfer1 = await admin.json('/api/transfers', {
    method: 'POST',
    json: {
      archive_ids: [aId], title: 'V3测试移交批次', direction: '移交进馆',
      target_unit: '广州市南沙区档案馆', contact: '张档案', phone: '020-12345678',
      basis: '《档案法》关于定期向档案馆移交档案的规定',
    },
  });
  check('新建移交批次', transfer1.status === 200 && /^YJ\d{4}-\d{3}$/.test(transfer1.body.data.transfer_no || ''),
    JSON.stringify(transfer1.body).slice(0, 160));
  const tId = transfer1.body.data.id;
  created.transfers.push(tId);

  const dupTransfer = await admin.json('/api/transfers', {
    method: 'POST', json: { archive_ids: [aId], title: 'V3重复移交测试' },
  });
  check('同一档案不能重复进入未完成批次', dupTransfer.status === 400, JSON.stringify(dupTransfer.body).slice(0, 140));

  const tDetail = await admin.json('/api/transfers/' + tId);
  check('移交清单含档案明细', tDetail.body.data.items.length === 1
    && tDetail.body.data.items[0].archive_code === mk.body.data.archive_code,
    JSON.stringify(tDetail.body.data.items[0] || {}).slice(0, 160));
  check('批次自动统计件数与页数', Number(tDetail.body.data.archive_count) === 1,
    'count=' + tDetail.body.data.archive_count);
  check('批次初始状态为待提交', tDetail.body.data.status === '待提交', tDetail.body.data.status);

  const acceptTooEarly = await admin.json(`/api/transfers/${tId}/accept`, {
    method: 'POST', json: { accept: true, acceptor: '李接收' },
  });
  check('未提交的批次不能直接接收', acceptTooEarly.status === 400, JSON.stringify(acceptTooEarly.body).slice(0, 120));

  // 移交前必须先有合格的归档环节四性检测记录（v8 引入的硬约束，
  // 依据《电子档案管理办法》第二十一条"移交前检测合格方可移交"）。
  // 注意：本套件里的样本档案在"正文检索"环节上传过附件，已触发过自动检测，
  // 所以这里不会出现"被拦"的情况 —— 闸门本身的拦截行为由 test-detection.js 专门验证。
  const detect = await admin.json('/api/detections', {
    method: 'POST', json: { archive_id: aId, environment: 'archive', source: '移交前' },
  });
  check('移交前补做归档环节四性检测', detect.status === 200 && detect.body.data.summary.archives === 1,
    JSON.stringify(detect.body).slice(0, 160));

  const submit = await admin.json(`/api/transfers/${tId}/submit`, { method: 'POST', json: {} });
  check('提交移交', submit.status === 200 && submit.body.data.status === '已提交');

  const printT = await admin.req(`/api/transfers/${tId}/print`);
  const printTHtml = await printT.text();
  check('移交清册可打印（含双方签章栏）',
    printT.status === 200 && printTHtml.includes('档 案 移 交 清 册')
    && printTHtml.includes('移交单位（盖章）') && printTHtml.includes('接收人'), 'HTTP ' + printT.status);

  const rejectNoReason = await admin.json(`/api/transfers/${tId}/accept`, { method: 'POST', json: { accept: false } });
  check('退回必须填写原因', rejectNoReason.status === 400, JSON.stringify(rejectNoReason.body).slice(0, 120));

  const acceptNoName = await admin.json(`/api/transfers/${tId}/accept`, { method: 'POST', json: { accept: true } });
  check('接收必须填写接收人', acceptNoName.status === 400, JSON.stringify(acceptNoName.body).slice(0, 120));

  const accept = await admin.json(`/api/transfers/${tId}/accept`, {
    method: 'POST', json: { accept: true, acceptor: '李接收', note: '数量相符，接收' },
  });
  check('办理接收', accept.status === 200 && accept.body.data.status === '已接收');

  const afterAccept = await admin.json('/api/transfers/' + tId);
  check('接收后记录接收人与时间', afterAccept.body.data.acceptor === '李接收' && !!afterAccept.body.data.accepted_at);
  const archAfter = await admin.json('/api/archives/' + aId);
  check('档案上留下移交痕迹', /移交/.test(archAfter.body.data.status_note || ''), archAfter.body.data.status_note);

  const delAccepted = await admin.json('/api/transfers/' + tId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('已接收批次作为凭据不可删除', delAccepted.status === 400, JSON.stringify(delAccepted.body).slice(0, 120));

  // 退回流程
  const t2 = await admin.json('/api/transfers', {
    method: 'POST', json: { archive_ids: [aId], title: 'V3测试退回流程', target_unit: '测试档案馆' },
  });
  check('新建第二个批次（验证退回流程）', t2.status === 200, JSON.stringify(t2.body).slice(0, 140));
  const t2Id = t2.body.data.id;
  created.transfers.push(t2Id);
  await admin.json(`/api/transfers/${t2Id}/submit`, { method: 'POST', json: {} });
  const reject = await admin.json(`/api/transfers/${t2Id}/accept`, {
    method: 'POST', json: { accept: false, reason: '清单中有 1 件档案页数填写不完整' },
  });
  check('退回移交并记录原因', reject.status === 200 && reject.body.data.status === '已退回');
  const t2Detail = await admin.json('/api/transfers/' + t2Id);
  check('退回原因已保存', /页数填写不完整/.test(t2Detail.body.data.reject_reason || ''),
    t2Detail.body.data.reject_reason);
  const resubmit = await admin.json(`/api/transfers/${t2Id}/submit`, { method: 'POST', json: {} });
  check('退回后可重新提交', resubmit.status === 200 && resubmit.body.data.status === '已提交');
  const removeItem = await admin.json(`/api/transfers/${t2Id}/remove`, {
    method: 'POST', json: { item_ids: [t2Detail.body.data.items[0].id] },
  });
  check('已提交的批次不允许改清单', removeItem.status === 400, JSON.stringify(removeItem.body).slice(0, 120));
  const cleanT2 = await admin.json('/api/transfers/' + t2Id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('未接收批次可删除', cleanT2.status === 200);

  // ============================================================ 3. 数据体检
  section('3. 数据体检');
  const scan = await admin.json('/api/quality/scan');
  check('体检接口可用', scan.status === 200 && Array.isArray(scan.body.data.problems),
    JSON.stringify(scan.body.data).slice(0, 120));
  const ptypes = (scan.body.data.problems || []).map((p) => p.type);
  for (const t of ['duplicate', 'no_responsible', 'no_date', 'no_category_code', 'no_file',
    'due_unappraised', 'no_location', 'text_unavailable']) {
    check('体检包含检查项：' + t, ptypes.includes(t), ptypes.join(','));
  }
  const noFileItem = (scan.body.data.problems || []).find((p) => p.type === 'no_file');
  check('无附件检查项带样例与说明', noFileItem && Array.isArray(noFileItem.samples) && !!noFileItem.hint,
    JSON.stringify(noFileItem || {}).slice(0, 160));

  // ============================================================ 4. 批量修改
  section('4. 批量修改');
  const bulk1 = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [aId], changes: { department: 'V3批量修改后部门', secret_level: '内部' } },
  });
  check('批量修改字段', bulk1.status === 200 && bulk1.body.data.changed === 1, JSON.stringify(bulk1.body).slice(0, 140));
  const afterBulk = await admin.json('/api/archives/' + aId);
  check('修改已生效', afterBulk.body.data.department === 'V3批量修改后部门'
    && afterBulk.body.data.secret_level === '内部', afterBulk.body.data.department);

  const bulkEmpty = await admin.json('/api/archives/bulk-update', { method: 'POST', json: { ids: [aId], changes: {} } });
  check('空的修改内容被拒绝', bulkEmpty.status === 400, JSON.stringify(bulkEmpty.body).slice(0, 120));
  const bulkBad = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [aId], changes: { title: '试图批量改题名' } },
  });
  check('不允许的字段被忽略（题名不在白名单）', bulkBad.status === 400 || bulkBad.body.data.fields.indexOf('title') < 0,
    JSON.stringify(bulkBad.body).slice(0, 140));
  const bulkNoIds = await admin.json('/api/archives/bulk-update', { method: 'POST', json: { changes: { department: 'X' } } });
  check('未选档案时拒绝', bulkNoIds.status === 400, JSON.stringify(bulkNoIds.body).slice(0, 120));

  // 按筛选条件批量修改
  const bulkByFilter = await admin.json('/api/archives/bulk-update', {
    method: 'POST',
    json: { filter: { kw: 'V3测试档案' }, changes: { responsible: 'V3批量责任者' } },
  });
  check('可按检索条件批量修改', bulkByFilter.status === 200 && bulkByFilter.body.data.changed >= 1,
    JSON.stringify(bulkByFilter.body).slice(0, 140));

  // 保管期限变化应重算到期年度
  const bulkRet = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [aId], changes: { retention: '定期30年' } },
  });
  check('批量改保管期限', bulkRet.status === 200);
  const retAfter = await admin.json('/api/archives/' + aId);
  check('改期限后代码与到期年度同步更新',
    retAfter.body.data.retention_code === 'D30' && Number(retAfter.body.data.retention_due_year) === 2062,
    `code=${retAfter.body.data.retention_code} due=${retAfter.body.data.retention_due_year}`);

  // ============================================================ 5. 统计增强
  section('5. 统计增强');
  const rep = await admin.json('/api/stats/report');
  check('统计报表接口可用', rep.status === 200 && rep.body.data.totals, JSON.stringify(rep.body.data).slice(0, 140));
  const d = rep.body.data;
  // 门类数不写死：出厂 7 个，用户还能自建门类，按实际门类表比对才有意义
  const typesV3 = await admin.json('/api/types');
  const typeCountV3 = ((typesV3.body.data && typesV3.body.data.list) || []).length;
  check('含按门类统计（覆盖全部门类）', (d.byType || []).length >= Math.min(5, typeCountV3),
    `统计 ${(d.byType || []).length} 个 / 门类表 ${typeCountV3} 个`);
  check('含按保管期限/密级/状态统计',
    Array.isArray(d.byRetention) && Array.isArray(d.bySecret) && Array.isArray(d.byStatus));
  check('含按部门统计', Array.isArray(d.byDepartment));
  check('含业务量统计（借阅/鉴定/销毁/移交）',
    d.loanStats && d.appraisalStats && d.destroyStats && d.transferStats,
    JSON.stringify({ l: !!d.loanStats, a: !!d.appraisalStats, ds: !!d.destroyStats, t: !!d.transferStats }));
  check('含附件与正文索引统计', d.fileStats && typeof d.fileStats.indexed === 'number',
    JSON.stringify(d.fileStats || {}));
  check('含可选年度列表', Array.isArray(d.years) && d.years.length > 0, (d.years || []).join(','));

  const repY = await admin.json('/api/stats/report?year=2032');
  check('按年度筛选统计', repY.status === 200 && repY.body.data.year === '2032',
    JSON.stringify(repY.body.data.totals || {}).slice(0, 120));

  const repPrint = await admin.req('/api/stats/report/print?year=2032');
  const repPrintHtml = await repPrint.text();
  check('统计年报可打印', repPrint.status === 200 && repPrintHtml.includes('档 案 工 作 统 计 年 报')
    && repPrintHtml.includes('制表人'), 'HTTP ' + repPrint.status);

  const repCsv = await admin.req('/api/stats/report.csv');
  const csvBuf = Buffer.from(await repCsv.arrayBuffer());
  const csvText = csvBuf.toString('utf8');
  check('统计表可导出 CSV', repCsv.status === 200 && csvText.includes('统计维度') && csvText.includes('按门类'),
    'HTTP ' + repCsv.status);
  check('CSV 带 UTF-8 BOM', csvBuf[0] === 0xef && csvBuf[1] === 0xbb && csvBuf[2] === 0xbf);

  // ============================================================ 6. 权限
  section('6. 新功能权限控制');
  await admin.json('/api/users', {
    method: 'POST', json: { username: 'v3reader', display_name: 'V3只读', password: 'reader123456', role: 'reader' },
  });
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: 'v3reader', password: 'reader123456' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'reader123456', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const perms = [
    ['普通用户不能移交', await reader.json('/api/transfers', { method: 'POST', json: { archive_ids: [aId] } })],
    ['普通用户不能看待移交列表', await reader.json('/api/transfers')],
    ['普通用户不能数据体检', await reader.json('/api/quality/scan')],
    ['普通用户不能批量修改', await reader.json('/api/archives/bulk-update', { method: 'POST', json: { ids: [aId], changes: { department: 'X' } } })],
    ['普通用户不能补建正文索引', await reader.json('/api/search/text/reindex', { method: 'POST' })],
  ];
  for (const [name, r] of perms) check(name + '（403）', r.status === 403, 'HTTP ' + r.status);
  check('普通用户可正文检索', (await reader.json('/api/search/text?kw=' + encodeURIComponent('内涝'))).status === 200);
  check('普通用户可看统计报表', (await reader.json('/api/stats/report')).status === 200);

  // ============================================================ 7. 清理
  section('7. 清理自测数据');
  for (const t of created.transfers) await admin.json('/api/transfers/' + t.id, { method: 'DELETE', json: { reason: '测试夹具清理' } }).catch(() => {});
  const tl = await admin.json('/api/transfers');
  for (const t of (tl.body.data.list || [])) {
    if (/V3/.test(t.title || '')) await admin.json('/api/transfers/' + t.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  let cleaned = 0;
  for (const id of created.archives) {
    const r = await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.status === 200 || r.status === 404) cleaned++;
  }
  check('清理测试档案', cleaned === created.archives.length, `${cleaned}/${created.archives.length}`);
  const remain = await admin.json('/api/archives?kw=' + encodeURIComponent('V3测试'));
  check('测试档案已清理干净', remain.body.data.total === 0, 'total=' + remain.body.data.total);
  const users = (await admin.json('/api/users')).body.data.list;
  for (const u of users) if (u.username === 'v3reader') await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });

  console.log('\n' + '='.repeat(56));
  console.log(`第 3 版自测结果：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  console.log('='.repeat(56));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n自测异常终止：', e); process.exit(1); });
