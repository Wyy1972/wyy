/**
 * PDF 结构诊断：判断“提取为 0”到底是没有文字层，还是我们的解析器有问题
 * 用法：node server/tools/diag-pdf.js <pdf 文件>
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

function diag(file) {
  const buf = fs.readFileSync(file);
  const latin = buf.toString('latin1');
  console.log('===== ' + path.basename(file) + ' =====');
  console.log('  文件大小 : ' + Math.round(buf.length / 1024) + ' KB');
  console.log('  PDF 版本 : ' + (latin.slice(0, 8).match(/^%PDF-[\d.]+/) || ['(未识别)'])[0]);

  // 1) 统计 stream 与过滤器类型
  const streamCount = (latin.match(/stream\r?\n/g) || []).length;
  const endstream = (latin.match(/endstream/g) || []).length;
  const filters = {};
  for (const m of latin.matchAll(/\/Filter\s*(\[[^\]]*\]|\/\w+)/g)) {
    const key = m[1].replace(/\s+/g, '');
    filters[key] = (filters[key] || 0) + 1;
  }
  console.log('  stream 数: ' + streamCount + ' / endstream 数: ' + endstream);
  console.log('  过滤器   : ' + (Object.keys(filters).length ? JSON.stringify(filters) : '(无)'));
  console.log('  FlateDecode 出现次数: ' + (latin.match(/FlateDecode/g) || []).length);

  // 2) 是否有字体 / ToUnicode / 图片对象
  console.log('  字体对象 /Font      : ' + (latin.match(/\/Font/g) || []).length);
  console.log('  ToUnicode CMap      : ' + (latin.match(/\/ToUnicode/g) || []).length);
  console.log('  图片 XObject /Image : ' + (latin.match(/\/Subtype\s*\/Image/g) || []).length);
  console.log('  文本操作符 BT 次数  : ' + (latin.match(/\bBT\b/g) || []).length);

  // 3) 逐个尝试解压 stream，统计成功数与内容特征
  let okInflate = 0, failInflate = 0, textStreams = 0, imageStreams = 0;
  let sampleContent = '';
  const re = /stream\r?\n/g;
  let m;
  let idx = 0;
  while ((m = re.exec(latin))) {
    const start = m.index + m[0].length;
    const end = latin.indexOf('endstream', start);
    if (end < 0) break;
    let raw = buf.slice(start, end);
    while (raw.length && (raw[raw.length - 1] === 0x0a || raw[raw.length - 1] === 0x0d)) raw = raw.slice(0, -1);
    // 查看该 stream 前的字典
    const dict = latin.slice(Math.max(0, m.index - 400), m.index);
    const isImage = /\/Subtype\s*\/Image/.test(dict);
    const isFlate = /FlateDecode/.test(dict);
    let data = null;
    if (isFlate) {
      try { data = zlib.inflateSync(raw); okInflate++; } catch (_) { try { data = zlib.inflateRawSync(raw); okInflate++; } catch (_2) { failInflate++; } }
    } else {
      data = raw;
      okInflate++;
    }
    idx++;
    if (isImage) imageStreams++;
    if (data && /\bBT\b|\bTj\b|\bTJ\b/.test(data.slice(0, 4000).toString('latin1'))) {
      textStreams++;
      if (!sampleContent) sampleContent = data.slice(0, 600).toString('latin1');
    }
    if (idx > 400) break;
  }
  console.log('  解压成功/失败: ' + okInflate + ' / ' + failInflate);
  console.log('  含文本操作符的流: ' + textStreams);
  console.log('  图片流          : ' + imageStreams);

  if (sampleContent) {
    console.log('  --- 文本流样本（前 300 字符）---');
    console.log('  ' + sampleContent.replace(/\n/g, ' ').slice(0, 300));
  }

  // 4) 结论
  console.log('  ===> 判定：' + (
    textStreams > 0
      ? `可提取（有 ${textStreams} 个文本流）——如果提取为空说明解析器有 bug`
      : (imageStreams > 0
        ? '无文本流，仅有图片流 → 确认为扫描件/图片型 PDF，需 OCR'
        : '既无文本流也无图片流 → 结构异常，需进一步分析')
  ));
  console.log('');
}

const args = process.argv.slice(2);
if (!args.length) {
  // 自动找桌面上的 PDF
  const d = path.join(process.env.USERPROFILE || '', 'Desktop');
  const list = fs.readdirSync(d).filter((f) => f.toLowerCase().endsWith('.pdf')).slice(0, 4);
  for (const f of list) diag(path.join(d, f));
} else {
  for (const f of args) diag(f);
}
