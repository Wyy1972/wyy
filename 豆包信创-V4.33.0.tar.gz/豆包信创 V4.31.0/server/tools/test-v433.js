﻿/**
 * 授权与审计外存 回归测试（豆包信创 V4.33.0）
 *
 * 用法：node server/tools/test-v433.js
 *
 * 覆盖：
 *   1. 没放授权文件 → state=none、不降级（照常可写）
 *   2. 放本机授权文件 → state=ok、单位/到期/机器码正确
 *   3. 签名被改 → 只读：写接口 403 LICENSE_READONLY，读接口照常，登录/改密不把人卡死
 *   4. 授权绑的是别的机器 → mismatch + 只读
 *   5. 授权过期 → expired + 只读；换回有效文件并 reload → 恢复可写
 *   6. 审计锚点：能算出链尾与条数、落盘成文件；配外存后新增日志被追加成 JSONL，
 *      第二次生成不重复追加；外存游标与本地链尾对齐
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const net = require('node:net');
const { spawn } = require('node:child_process');
const lic = require('../lib/license');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const TEST_DATA = path.join(APP_ROOT, '.regress-v433-data');
const MIRROR = path.join(APP_ROOT, '.regress-v433-mirror');
const ADMIN_PWD = 'Archive@2026l';
const ADMIN_PWD2 = 'Archive@2026l2';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeSession(base) {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(base + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json, jar };
}

async function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(0));
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); });
  });
}

async function waitPing(base, ms = 25000) {
  const until = Date.now() + ms;
  for (;;) {
    try {
      const r = await fetch(base + '/api/ping');
      const t = await r.text();
      if (t.includes('在运行')) return true;
    } catch (_) { /* 还没起来 */ }
    if (Date.now() > until) return false;
    await sleep(200);
  }
}

function removeDirDeep(dir) {
  if (!fs.existsSync(dir)) return;
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 兜底 */ }
}

const writeLicense = (obj) => fs.writeFileSync(path.join(TEST_DATA, 'license.json'), JSON.stringify(obj, null, 2), 'utf8');

async function main() {
  removeDirDeep(TEST_DATA);
  removeDirDeep(MIRROR);
  fs.mkdirSync(TEST_DATA, { recursive: true });
  const mp = lic.machineCode();
  const port = await freePort();
  const BASE = 'http://127.0.0.1:' + port;
  const srv = spawn(process.execPath, [
    path.join(APP_ROOT, 'server', 'server.js'),
    '--data', TEST_DATA, '--port', String(port), '--no-qr', '--no-scheduler', '--quiet',
  ], { cwd: APP_ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  srv.stdout.on('data', (d) => { out += d; });
  srv.stderr.on('data', (d) => { out += d; });

  const admin = makeSession(BASE);
  try {
    if (!await waitPing(BASE)) throw new Error('服务没能启动：\n' + out.slice(-1500));

    section('准备');
    const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
    check('管理员可登录', login.status === 200 && login.body.ok, 'HTTP ' + login.status);
    if (!login.body.ok) throw new Error('前置失败：管理员登录不了');
    await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: 'admin123', newPassword: ADMIN_PWD } });
    const cats = await admin.json('/api/categories');
    const flat = ((cats.body.data || {}).flat) || [];
    const cat = flat.find((c) => String(c.code || '') === 'WS-XZ') || flat[flat.length - 1];
    const newArchive = async (title) => admin.json('/api/archives', {
      method: 'POST', json: { title, category_id: cat && cat.id, type_code: 'WS', year: '2026', pages: '1' },
    });

    section('未放置授权文件');
    const none = await admin.json('/api/license');
    check('状态=未放置（none）', none.status === 200 && (none.body.data || {}).state === 'none',
      JSON.stringify(none.body.data || {}).slice(0, 140));
    check('未放置时不降级（readOnly=false）', (none.body.data || {}).readOnly === false);
    check('已登录能看到本机机器码', ((none.body.data || {}).machine || {}).code === mp.code,
      ((none.body.data || {}).machine || {}).code);
    const w0 = await newArchive('授权回归件');
    check('未授权状态下仍可写（仅提示，不锁功能）', w0.status === 200 && w0.body.ok, 'HTTP ' + w0.status);

    section('放置本机授权');
    writeLicense(lic.issueLicense({ unit: '回归测试单位', months: 12, fpCore: mp.fpCore, fpFull: mp.fpFull }));
    const okd = await admin.json('/api/license/reload', { method: 'POST', json: {} });
    check('重新读取后状态=ok', (okd.body.data || {}).state === 'ok', JSON.stringify(okd.body.data || {}).slice(0, 160));
    check('授权单位回显正确', (okd.body.data || {}).unit === '回归测试单位');
    check('到期日与剩余天数为正', Number((okd.body.data || {}).remainDays) > 0 && !!(okd.body.data || {}).expires_at);
    const w1 = await newArchive('有效授权下建件');
    check('有效授权可写', w1.status === 200 && w1.body.ok, 'HTTP ' + w1.status);

    section('签名被篡改');
    const tampered = lic.issueLicense({ unit: '回归测试单位', months: 12, fpCore: mp.fpCore, fpFull: mp.fpFull });
    tampered.unit = '别的单位';
    writeLicense(tampered);
    const bad = await admin.json('/api/license/reload', { method: 'POST', json: {} });
    const bd = bad.body.data || {};
    check('篡改后状态=invalid', bd.state === 'invalid', JSON.stringify(bd).slice(0, 120));
    check('篡改后进入只读', bd.readOnly === true);
    const wr = await newArchive('只读下不该建成');
    check('只读下写接口被拒（403 LICENSE_READONLY）',
      wr.status === 403 && String(wr.body.code || '') === 'LICENSE_READONLY',
      'HTTP ' + wr.status + ' ' + JSON.stringify(wr.body).slice(0, 140));
    const rd = await admin.json('/api/archives?limit=1');
    check('只读下读接口照常', rd.status === 200 && rd.body.ok, 'HTTP ' + rd.status);
    const pw = await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: ADMIN_PWD, newPassword: ADMIN_PWD2 } });
    check('只读下仍允许改口令（不把人卡死）', pw.status === 200, 'HTTP ' + pw.status);

    section('换了机器的授权');
    writeLicense(lic.issueLicense({ unit: '回归测试单位', months: 12, fpCore: 'f'.repeat(64), fpFull: 'e'.repeat(64) }));
    const mm = await admin.json('/api/license/reload', { method: 'POST', json: {} });
    check('机器码不符= mismatch', (mm.body.data || {}).state === 'mismatch', JSON.stringify(mm.body.data || {}).slice(0, 140));
    check('机器码不符也只看读，不锁数据', (mm.body.data || {}).readOnly === true);

    section('授权到期');
    writeLicense(lic.issueLicense({
      unit: '回归测试单位', months: 12, fpCore: mp.fpCore, fpFull: mp.fpFull, issuedAt: '2024-01-01',
    }));
    const ex = await admin.json('/api/license/reload', { method: 'POST', json: {} });
    check('过期= expired', (ex.body.data || {}).state === 'expired', JSON.stringify(ex.body.data || {}).slice(0, 140));
    check('过期只剩读、剩余天数≤0', (ex.body.data || {}).readOnly === true && Number((ex.body.data || {}).remainDays) <= 0);
    writeLicense(lic.issueLicense({ unit: '回归测试单位', months: 12, fpCore: mp.fpCore, fpFull: mp.fpFull }));
    const back = await admin.json('/api/license/reload', { method: 'POST', json: {} });
    const w2 = await newArchive('恢复可写验证件');
    check('换回有效授权后恢复可写',
      (back.body.data || {}).state === 'ok' && w2.status === 200,
      `state=${(back.body.data || {}).state} http=${w2.status}`);

    section('审计外存');
    const a0 = await admin.json('/api/audit/anchor?limit=20');
    const a0d = a0.body.data || {};
    check('锚点接口可用', a0.status === 200 && a0.body.ok, 'HTTP ' + a0.status + ' ' + JSON.stringify(a0.body).slice(0, 140));
    check('能算出链尾与日志总数', (a0d.tail || {}).total >= 1 && Number((a0d.tail || {}).lastId) >= 1,
      JSON.stringify(a0d.tail || {}).slice(0, 120));
    check('链校验完整', (a0d.tail || {}).chainOk === true, String((a0d.tail || {}).reason || ''));
    check('启动时已自动留了一个锚点', ((a0d.local || {}).count) >= 1, 'count=' + ((a0d.local || {}).count));
    check('未配外存时 mirror.configured=false', (a0d.mirror || {}).configured === false);

    const run1 = await admin.json('/api/audit/anchor/run', { method: 'POST', json: {} });
    const r1 = run1.body.data || {};
    check('手动生成锚点成功', run1.status === 200 && run1.body.ok, JSON.stringify(r1).slice(0, 140));
    check('锚点文件已落盘', !!r1.localPath && fs.existsSync(r1.localPath), String(r1.localPath || ''));

    const setDir = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'audit.mirror_dir': MIRROR } } });
    check('外存目录可保存', setDir.status === 200, JSON.stringify(setDir.body).slice(0, 140));
    const run2 = await admin.json('/api/audit/anchor/run', { method: 'POST', json: {} });
    const r2 = run2.body.data || {};
    check('首次外存写入成功', run2.status === 200 && (r2.errors || []).length === 0,
      JSON.stringify(r2.errors || []).slice(0, 160));
    check('外存追加了历史日志', Number((r2.mirror || {}).appended) >= 1, 'appended=' + (r2.mirror || {}).appended);
    const mirrorFiles = fs.existsSync(MIRROR) ? fs.readdirSync(MIRROR).filter((f) => /^audit-\d{4}-\d{2}\.jsonl$/.test(f)) : [];
    check('外存目录里有月度 JSONL 副本', mirrorFiles.length >= 1, mirrorFiles.join(','));
    const stateFile = path.join(MIRROR, '.mirror-state.json');
    check('外存游标文件已生成', fs.existsSync(stateFile), stateFile);
    if (fs.existsSync(stateFile)) {
      const mstate = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
      check('外存游标与本地链尾对齐', Number(mstate.last_id) === Number((r2.anchor || {}).last_id),
        `cursor=${mstate.last_id} anchor=${(r2.anchor || {}).last_id}`);
    }
    check('锚点在外存也留了一份', fs.existsSync(path.join(MIRROR, 'anchors')));
    const run3 = await admin.json('/api/audit/anchor/run', { method: 'POST', json: {} });
    const r3 = run3.body.data || {};
    check('上一次锚点动作自己那条日志这次补进外存', Number((r3.mirror || {}).appended) === 1,
      'appended=' + (r3.mirror || {}).appended);
    const run4 = await admin.json('/api/audit/anchor/run', { method: 'POST', json: {} });
    const r4 = run4.body.data || {};
    check('再跑一次仍只追加新产生的 1 条（不重复拷历史）', Number((r4.mirror || {}).appended) === 1,
      'appended=' + (r4.mirror || {}).appended);
    // 外存副本总行数必须正好等于日志总数，多一条就是重复拷贝、少一条就是漏拷
    const jf = (r4.mirror || {}).file || '';
    const jlines = jf && fs.existsSync(jf) ? fs.readFileSync(jf, 'utf8').split('\n').filter(Boolean).length : -1;
    check('外存副本行数与日志总数一致（不重不漏）', jlines === Number((r4.anchor || {}).logs_total),
      `lines=${jlines} total=${(r4.anchor || {}).logs_total}`);
    const a2 = await admin.json('/api/audit/anchor?limit=20');
    check('外存状态可查且已同步', ((a2.body.data || {}).mirror || {}).configured === true
      && Number(((a2.body.data || {}).mirror || {}).lastId) >= 1);
    check('锚点清单至少有 3 条（启动 + 两次手动）', ((((a2.body.data || {}).local || {}).list) || []).length >= 3,
      'n=' + ((((a2.body.data || {}).local || {}).list) || []).length);
    const alogs = await admin.json('/api/logs?size=20&action=' + encodeURIComponent('生成审计锚点'));
    const alogList = (((alogs.body.data || {}).list) || []);
    const alogHit = alogList.some((l) => String(l.action || '').includes('生成审计锚点'));
    check('锚点动作写了审计', alogHit, 'n=' + alogList.length);
  } catch (e) {
    failed += 1;
    fails.push('异常中断：' + (e && e.message));
    console.log('\n  ✗ 套件异常中断：' + (e && e.stack ? e.stack : e));
  } finally {
    try { srv.kill(); } catch (_) {}
    await sleep(400);
    removeDirDeep(TEST_DATA);
    removeDirDeep(MIRROR);
  }

  console.log(`\n${failed === 0 ? '全部通过' : '存在失败'}：通过 ${pass} 项，失败 ${failed} 项`);
  if (fails.length) { console.log('失败清单：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((e) => { console.error(e && e.stack ? e.stack : e); process.exit(1); });
