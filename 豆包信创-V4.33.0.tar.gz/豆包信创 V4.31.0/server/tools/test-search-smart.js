/**
 * 检索智能化（v4.11.0）验证 —— 拼音检索 / 检索结果分面 / 扫描件 OCR
 *
 * 这一版的主题是"**搜得到**"，三个子能力各自的失败方式完全不同，所以要分开测：
 *
 *   ① 拼音检索：失败方式是"**静默搜不到**"——没有报错，只是查不出结果，
 *      使用者会以为库里没这份档案。所以本套件盯的是"同一个词用三种写法都要命中"，
 *      以及**改了题名之后拼音键有没有跟着变**（不变就是最恶心的那种 bug：
 *      用新题名搜不到、用旧题名反而能搜到）。
 *
 *   ② 检索分面：失败方式是"**计数在骗人**"。标准分面语义是
 *      "算某一维度时不要应用该维度自己的筛选条件"，做错了界面不会报错，
 *      只会让使用者看着一堆 0 发懵。另外计数本身就是涉密信息，必须过密级。
 *
 *   ③ OCR：失败方式是"**假装能用**"。本机没装引擎却返回成功、或者把 OCR 文本
 *      伪装成原生文字层，都是这一版最该避免的事。所以本套件用**注入假引擎**的方式
 *      把真实识别链路跑通（而不是只测"没装引擎"这一条路），同时验证：
 *      没引擎时如实说明、有引擎时不覆盖原生文字层、结果标为 ocr 来源。
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

function multipart(files, fields = {}) {
  const boundary = '----ss' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

/** 1×1 透明 PNG（真图，保证上传链路走在真实格式上） */
const PNG_1X1 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8AAAwAB/AGtE0kAAAAASUVORK5CYII=',
  'base64',
);

const TAG = 'SS' + Math.random().toString(16).slice(2, 8).toUpperCase();
const YR = '2044';
const OCR_MARK = 'OCRFAKE' + TAG;

/**
 * 造一个**假的 tesseract**：一个 .cmd 包装脚本 + 一个 Node 实现。
 *
 * 为什么要用 .cmd 而不是直接一个 exe：Windows 上用户把别的 OCR 引擎包成 tesseract 契约时，
 * 最自然的写法就是 .cmd —— 而这恰好是 Node 不能直接 spawn 的（会抛 EINVAL），
 * 必须经 cmd.exe。用 .cmd 做测试件，等于把这条真实路径也一起验证了。
 */
function makeFakeEngine() {
  const dir = path.join(os.tmpdir(), 'dsh-fake-ocr-' + TAG);
  fs.mkdirSync(dir, { recursive: true });
  const js = path.join(dir, 'fake-ocr.js');
  const cmd = path.join(dir, 'fake-tesseract.cmd');
  fs.writeFileSync(js, `
const fs = require('node:fs');
const a = process.argv.slice(2);
if (a[0] === '--version') { process.stdout.write('tesseract 5.9.9-fake\\n'); process.exit(0); }
if (a[0] === '--list-langs') {
  process.stdout.write('List of available languages in "C:\\\\fake\\\\tessdata" (2):\\nchi_sim\\neng\\n');
  process.exit(0);
}
const base = a[1];
if (!base) { process.stderr.write('missing output base\\n'); process.exit(2); }
fs.writeFileSync(base + '.txt',
  '内涝防治应急预案 档案管理 ' + ${JSON.stringify(OCR_MARK)} + '\\n第二页：值班制度与责任分工\\n', 'utf8');
process.exit(0);
`, 'utf8');
  // .cmd 内容必须是纯 ASCII：中文在批处理里会随代码页变形
  fs.writeFileSync(cmd, '@echo off\r\nnode "%~dp0fake-ocr.js" %*\r\n', 'ascii');
  return { dir, cmd };
}

async function main() {
  const admin = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const leaf = flat.find((c) => c.level === 2 && String(c.code).startsWith('WS-'));
  check('拿到文书档案二级分类', !!leaf, leaf && leaf.code);
  if (!leaf) process.exit(1);

  const createdIds = [];
  async function mk(title, extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({ type_code: 'WS', category_id: leaf.id, title, year: YR, secret_level: '公开' }, extra),
    });
    if (r.body && r.body.ok && r.body.data && r.body.data.id) createdIds.push(r.body.data.id);
    return r;
  }
  /** 按关键词检索，返回命中的 id 集合 */
  async function kwIds(kw, extra = '') {
    const r = await admin.json('/api/archives?kw=' + encodeURIComponent(kw) + '&size=200' + extra);
    return { ids: ((r.body.data || {}).list || []).map((x) => x.id), total: (r.body.data || {}).total, status: r.status, body: r.body };
  }

  // =========================================================================
  section('一、拼音检索：汉字 / 全拼 / 首字母三种写法都要命中');
  // =========================================================================
  const A = await mk(`${TAG}文书管理工作总结`, { keywords: '归档案卷 年度总结', responsible: '张三' });
  check('建出拼音检索样本', A.body.ok, JSON.stringify(A.body).slice(0, 140));
  const a = A.body.data.id;

  const han = await kwIds('文书管理');
  check('汉字检索命中', han.ids.includes(a), JSON.stringify(han.ids.length));
  const full = await kwIds('wenshuguanli');
  check('★ 全拼 wenshuguanli 命中', full.ids.includes(a), `total=${full.total}`);
  const ini = await kwIds('wsgl');
  check('★ 首字母 wsgl 命中', ini.ids.includes(a), `total=${ini.total}`);
  const kwPy = await kwIds('guidanganjuan');
  check('★ 关键词字段的拼音也能命中', kwPy.ids.includes(a), `total=${kwPy.total}`);
  const respPy = await kwIds('zhangsan');
  check('★ 责任者的拼音也能命中', respPy.ids.includes(a), `total=${respPy.total}`);
  const miss = await kwIds('zzzznotexistword');
  check('不相关的拼音搜不到', miss.total === 0, `total=${miss.total}`);
  const oneChar = await kwIds('w');
  check('单字母不做拼音匹配（否则等于把半个库捞出来）', oneChar.status === 200, String(oneChar.status));
  const tagHit = await kwIds(TAG);
  check('ASCII 标记原样保留、照常命中', tagHit.ids.includes(a), `total=${tagHit.total}`);

  // 表达式里的裸词必须与表单「关键词」同口径（共用 kwClause）
  const expr = await admin.json('/api/archives?expr=' + encodeURIComponent(`wsgl AND 年度:${YR}`) + '&size=200');
  check('★ 高级检索表达式里的裸词也支持拼音',
    ((expr.body.data || {}).list || []).some((x) => x.id === a), String(expr.status));

  // 改题名 → 拼音键必须跟着变，否则会出现"新题名搜不到、旧题名反而搜得到"
  await admin.json('/api/archives/' + a, {
    method: 'PUT', json: { title: `${TAG}防汛应急预案`, keywords: '防汛 应急', responsible: '李四' },
  });
  const newPy = await kwIds('fangxun');
  check('★ 改题名后新题名的拼音能命中', newPy.ids.includes(a), `total=${newPy.total}`);
  const oldPy = await kwIds('wenshuguanli');
  check('★ 改题名后旧题名的拼音不再命中（拼音键真的重算了）', !oldPy.ids.includes(a), `total=${oldPy.total}`);

  // 批量修改会影响拼音键的字段 → 拼音键同样要重算
  // （批量入口的字段白名单里没有 title —— 批量改题名没有业务意义；责任者是可以批量改的）
  const bulk = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [a], changes: { responsible: '王五' } },
  });
  check('批量修改责任者成功', bulk.status === 200 && bulk.body.data.changed === 1, JSON.stringify(bulk.body).slice(0, 120));
  const bulkPy = await kwIds('wangwu');
  check('★ 批量改责任者后拼音键也重算了', bulkPy.ids.includes(a), `total=${bulkPy.total}`);
  const oldRespPy = await kwIds('lisi');
  check('★ 旧的拼音键不再命中', !oldRespPy.ids.includes(a), `total=${oldRespPy.total}`);

  // 体检里"缺拼音检索键"应为 0（同时证明 32 条演示存量档案也回填过了）
  const scan0 = await admin.json('/api/quality/scan?limit=5');
  const pyProblem = (((scan0.body.data || {}).problems) || []).find((p) => p.type === 'pinyin_missing');
  check('★ 体检项「缺拼音检索键」存在', !!pyProblem);
  check('★ 缺拼音检索键为 0（存量档案已回填）', pyProblem && pyProblem.count === 0, pyProblem && String(pyProblem.count));

  // =========================================================================
  section('二、检索结果分面');
  // =========================================================================
  const baseList = await admin.json('/api/archives?size=1');
  const baseTotal = Number(baseList.body.data.total);
  const f0 = await admin.json('/api/archives/facets');
  check('分面接口可用', f0.status === 200 && f0.body.ok, String(f0.status));
  check('★ 分面 total 与列表 total 一致', Number(f0.body.data.total) === baseTotal,
    `${f0.body.data.total} vs ${baseTotal}`);
  const keys = (f0.body.data.facets || []).map((x) => x.key);
  check('分面维度齐全（门类/年度/保管期限/密级/状态/分类/部门/附件）',
    ['type', 'year', 'retention', 'secret', 'status', 'category', 'department', 'hasFile'].every((k) => keys.includes(k)),
    keys.join(','));
  check('分面含「正文可检索性」维度', keys.includes('textIndex'), keys.join(','));

  const sumOf = (key) => {
    const f = (f0.body.data.facets || []).find((x) => x.key === key);
    return (f.values || []).reduce((s, v) => s + v.count, 0) + (f.blank || 0);
  };
  check('门类分面计数之和 = total', sumOf('type') === baseTotal, `${sumOf('type')} vs ${baseTotal}`);
  check('保管期限分面计数之和 = total', sumOf('retention') === baseTotal, `${sumOf('retention')} vs ${baseTotal}`);
  check('附件分面（有/无）之和 = total', sumOf('hasFile') === baseTotal, `${sumOf('hasFile')} vs ${baseTotal}`);

  const wsFacet0 = ((f0.body.data.facets || []).find((x) => x.key === 'type').values || [])
    .find((v) => v.value === 'WS');
  check('门类分面里有文书档案(WS)', !!wsFacet0 && wsFacet0.count > 0, JSON.stringify(wsFacet0));

  // 分面语义：加了门类筛选之后，门类分面自己**不能**被这个筛选缩掉
  const f1 = await admin.json('/api/archives/facets?type=WS');
  const typeFacet1 = (f1.body.data.facets || []).find((x) => x.key === 'type');
  check('★ 选定门类=WS 后，门类分面仍列出全部门类（标准分面语义）',
    (typeFacet1.values || []).filter((v) => v.value !== 'WS' && v.count > 0).length >= 1,
    JSON.stringify((typeFacet1.values || []).map((v) => `${v.value}:${v.count}`)));
  const otherFacet1 = (f1.body.data.facets || []).find((x) => x.key === 'year');
  check('★ 其他维度照常被门类筛选收窄', (otherFacet1.total || 0) === Number(f1.body.data.total),
    `${otherFacet1.total} vs ${f1.body.data.total}`);
  check('分面回传当前生效的筛选（active）', f1.body.data.active && f1.body.data.active.type === 'WS',
    JSON.stringify(f1.body.data.active));

  const f2 = await admin.json('/api/archives/facets?kw=' + encodeURIComponent('消防'));
  check('带关键词时分面生效', f2.status === 200 && Number(f2.body.data.total) >= 1, String(f2.body.data.total));

  // 计数也是涉密信息：低密级账号不能从分面计数里推断出机密件有多少
  const rdName = TAG.toLowerCase() + '_rd';
  const mkRd = await admin.json('/api/users', {
    method: 'POST', json: { username: rdName, display_name: '分面密级测试', password: 'Test@12345', role: 'reader' },
  });
  check('创建普通用户账号', mkRd.status === 200 && mkRd.body.ok, JSON.stringify(mkRd.body).slice(0, 140));
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: rdName, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const fRd = await reader.json('/api/archives/facets');
  const secretRd = ((fRd.body.data.facets || []).find((x) => x.key === 'secret').values || []);
  check('★ 普通用户的分面里不出现超出其密级的密级档位',
    !secretRd.some((v) => ['秘密', '机密'].includes(v.value)),
    JSON.stringify(secretRd.map((v) => v.value)));
  check('★ 普通用户分面 total 小于管理员 total（数量本身受密级约束）',
    Number(fRd.body.data.total) < baseTotal, `${fRd.body.data.total} vs ${baseTotal}`);

  // =========================================================================
  section('三、OCR：没有引擎时如实说明');
  // =========================================================================
  const status0 = await admin.json('/api/ocr/status');
  check('OCR 状态接口可用', status0.status === 200 && status0.body.ok, String(status0.status));
  check('返回引擎探测结果与计数',
    status0.body.data.detect && status0.body.data.counts
    && typeof status0.body.data.counts.candidates === 'number',
    JSON.stringify(status0.body.data.counts));

  // =========================================================================
  section('四、OCR：注入假引擎，把真实识别链路跑通');
  // =========================================================================
  const fake = makeFakeEngine();
  // v4.12.0 起 ocr.engine=auto 会**优先用 Windows 自带识别**（零安装），
  // 所以要显式指定用 tesseract，假引擎才会被真正调用 —— 这段测的正是"外部引擎适配层"。
  const setEngine = await admin.json('/api/settings', {
    method: 'PUT', json: { 'ocr.engine_path': fake.cmd, 'ocr.engine': 'tesseract' },
  });
  check('设置 OCR 引擎路径成功', setEngine.status === 200 && setEngine.body.ok,
    JSON.stringify(setEngine.body).slice(0, 200));
  check('保存后立刻回报引擎状态（不让用户以为没生效）',
    /OCR 引擎(已就绪|仍不可用)/.test(setEngine.body.data.warning || ''), setEngine.body.data.warning);
  check('★ 假引擎被探测到并报告为 tesseract', /tesseract/.test(setEngine.body.data.warning || ''), setEngine.body.data.warning);

  const status1 = await admin.json('/api/ocr/status');
  check('★ 状态里 available=true 且引擎为 tesseract',
    status1.body.data.detect.available === true && status1.body.data.detect.engine === 'tesseract',
    JSON.stringify(status1.body.data.detect).slice(0, 160));
  check('报告了语言包（chi_sim 在列）',
    (status1.body.data.detect.tesseract.langs || []).includes('chi_sim'),
    JSON.stringify((status1.body.data.detect.tesseract.langs || [])));

  const B = await mk(`${TAG}扫描件样本`);
  const b = B.body.data.id;
  const mpPng = multipart([{ filename: '扫描件.png', data: PNG_1X1, mime: 'image/png' }]);
  const upPng = await admin.req(`/api/archives/${b}/files`, {
    method: 'POST', headers: { 'Content-Type': mpPng.contentType }, body: mpPng.body,
  });
  const upPngJson = await upPng.json();
  check('上传扫描件（PNG）成功', upPng.status === 200 && upPngJson.ok, JSON.stringify(upPngJson).slice(0, 140));
  const pngFid = upPngJson.data && upPngJson.data.files && upPngJson.data.files[0] ? upPngJson.data.files[0].id : 0;
  check('拿到附件 id', pngFid > 0, String(pngFid));

  const txt0 = await admin.json(`/api/files/${pngFid}/text`);
  check('图片附件原生的正文提取是非成功状态（正是 OCR 要解决的情形）',
    txt0.body.data.status !== '成功', JSON.stringify(txt0.body.data).slice(0, 140));

  const status2 = await admin.json('/api/ocr/status');
  check('★ 待 OCR 计数包含这个扫描件', Number(status2.body.data.counts.candidates) >= 1,
    String(status2.body.data.counts.candidates));

  const ocrOne = await admin.json(`/api/files/${pngFid}/ocr`, { method: 'POST', body: {} });
  check('★ 单件 OCR 成功', ocrOne.status === 200 && ocrOne.body.data.ok, JSON.stringify(ocrOne.body).slice(0, 180));
  check('报告识别字数与引擎', ocrOne.body.data.chars > 0 && /tesseract/.test(ocrOne.body.data.engine || ''),
    JSON.stringify({ c: ocrOne.body.data.chars, e: ocrOne.body.data.engine }));

  const txt1 = await admin.json(`/api/files/${pngFid}/text`);
  check('★ 正文以 ocr 来源落库（不伪装成原生文本）', txt1.body.data.via === 'ocr', String(txt1.body.data.via));
  check('★ 记录了识别引擎', /tesseract/.test(txt1.body.data.engine || ''), String(txt1.body.data.engine));
  check('识别出的中文正文已入库', /内涝防治/.test(txt1.body.data.content || ''),
    String(txt1.body.data.content || '').slice(0, 60));

  const searchOcr = await admin.json('/api/search/text?kw=' + encodeURIComponent('内涝防治'));
  check('★ OCR 出来的正文可以被正文检索命中',
    ((searchOcr.body.data || {}).list || []).some((x) => x.file_id === pngFid), `total=${searchOcr.body.data.total}`);
  const hitRow = ((searchOcr.body.data || {}).list || []).find((x) => x.file_id === pngFid) || {};
  check('检索结果里标出正文来源为 OCR', hitRow.via === 'ocr' && /tesseract/.test(hitRow.engine || ''),
    JSON.stringify({ v: hitRow.via, e: hitRow.engine }));
  const searchNative = await admin.json('/api/search/text?kw=' + encodeURIComponent('内涝防治') + '&via=native');
  check('★ 按「仅原生文字层」筛时不含这条 OCR 结果',
    !((searchNative.body.data || {}).list || []).some((x) => x.file_id === pngFid),
    String(searchNative.body.data.total));
  const searchOcrOnly = await admin.json('/api/search/text?kw=' + encodeURIComponent('内涝防治') + '&via=ocr');
  check('按「仅 OCR」筛时只含 OCR 结果',
    ((searchOcrOnly.body.data || {}).list || []).every((x) => x.via === 'ocr'),
    String(searchOcrOnly.body.data.total));

  const scan1 = await admin.json('/api/quality/scan?limit=5');
  const ocrProblem = (((scan1.body.data || {}).problems) || []).find((p) => p.type === 'ocr_pending');
  check('体检项「有附件但正文搜不到」存在', !!ocrProblem);
  // v4.13.0 起体检**不再探测 OCR 引擎**（探测要起 PowerShell，会阻塞事件循环几秒，
  // 体检必须保持只读、快、无副作用），所以提示里不再点名引擎，而是指向看引擎的入口。
  check('★ 体检提示指向"哪里看引擎"，而不是自己去做探测',
    /数据体检/.test((ocrProblem && ocrProblem.hint) || '') && !/tesseract/i.test((ocrProblem && ocrProblem.hint) || ''),
    String((ocrProblem && ocrProblem.hint) || '').slice(0, 100));
  // 反向验证：体检接口不该因为 OCR 探测而变慢（探测阻塞事件循环时这里会超时）
  {
    const t0 = Date.now();
    await admin.json('/api/quality/scan?limit=5');
    const ms = Date.now() - t0;
    check('★ 体检接口保持快速（不因 OCR 探测被拖住）', ms < 3000, ms + 'ms');
  }

  // ---- 不覆盖原生文字层 ----
  const C = await mk(`${TAG}原生文本样本`);
  const c = C.body.data.id;
  const mpTxt = multipart([{ filename: '正文.txt', data: 'NATIVECHECK ' + TAG + ' 这是文档自带的文字层', mime: 'text/plain' }]);
  const upTxt = await admin.req(`/api/archives/${c}/files`, {
    method: 'POST', headers: { 'Content-Type': mpTxt.contentType }, body: mpTxt.body,
  });
  const upTxtJson = await upTxt.json();
  check('上传纯文本附件成功', upTxt.status === 200, String(upTxt.status));
  const txtFid = upTxtJson.data.files[0].id;
  const txtBefore = await admin.json(`/api/files/${txtFid}/text`);
  check('原生文字层提取成功', txtBefore.body.data.status === '成功' && txtBefore.body.data.via === 'native',
    JSON.stringify({ s: txtBefore.body.data.status, v: txtBefore.body.data.via }));

  const ocrNative = await admin.json(`/api/files/${txtFid}/ocr`, { method: 'POST', body: {} });
  check('★ 对已有原生文字层的附件做 OCR 会被跳过（不覆盖更准确的文本）',
    ocrNative.status === 200 && ocrNative.body.data.skipped === true,
    JSON.stringify(ocrNative.body).slice(0, 160));
  check('跳过原因说清了是原生文字层', /原生文字层/.test(ocrNative.body.data.reason || ''),
    ocrNative.body.data.reason);
  const txtAfter = await admin.json(`/api/files/${txtFid}/text`);
  check('★ 原生正文原封不动', txtAfter.body.data.via === 'native' && /NATIVECHECK/.test(txtAfter.body.data.content || ''),
    String(txtAfter.body.data.content || '').slice(0, 40));

  // ---- 格式不支持要说清 ----
  const mpZip = multipart([{ filename: '归档包.zip', data: Buffer.from('PK\u0003\u0004fakezip', 'binary'), mime: 'application/zip' }]);
  const upZip = await admin.req(`/api/archives/${c}/files`, {
    method: 'POST', headers: { 'Content-Type': mpZip.contentType }, body: mpZip.body,
  });
  const upZipJson = await upZip.json();
  const zipFid = upZipJson.data.files[0].id;
  const ocrZip = await admin.json(`/api/files/${zipFid}/ocr`, { method: 'POST', body: {} });
  check('★ 非图片/PDF 的附件做 OCR 明确拒绝（400）', ocrZip.status === 400, String(ocrZip.status));
  check('拒绝原因说清只处理图片与 PDF', /图片|PDF|图像/.test(ocrZip.body.error || ''), ocrZip.body.error);

  // ---- 批量 OCR ----
  const D = await mk(`${TAG}批量扫描样本`);
  const mpPng2 = multipart([{ filename: '批量扫描.png', data: PNG_1X1, mime: 'image/png' }]);
  await admin.req(`/api/archives/${D.body.data.id}/files`, {
    method: 'POST', headers: { 'Content-Type': mpPng2.contentType }, body: mpPng2.body,
  });
  const batch = await admin.json('/api/ocr/batch', { method: 'POST', json: { limit: 5 } });
  check('批量 OCR 可用', batch.status === 200 && batch.body.ok, JSON.stringify(batch.body).slice(0, 160));
  check('★ 批量结果逐条给出（成功/失败/跳过分得清）',
    Array.isArray(batch.body.data.results) && typeof batch.body.data.skipped === 'number',
    JSON.stringify({ n: (batch.body.data.results || []).length, s: batch.body.data.skipped }));
  check('批量为限量接口（默认 10 上限 50）', batch.body.data.processed <= 50, String(batch.body.data.processed));
  const bigLimit = await admin.json('/api/ocr/batch', { method: 'POST', json: { limit: 9999 } });
  check('批量请求超过上限时被夹到 50 以内', bigLimit.status === 200 && bigLimit.body.data.processed <= 50,
    String(bigLimit.body.data.processed));

  // ---- 权限 ----
  const rdOcr = await reader.json(`/api/files/${pngFid}/ocr`, { method: 'POST', body: {} });
  check('★ 普通用户不能做 OCR（403）', rdOcr.status === 403, String(rdOcr.status));
  const rdBatch = await reader.json('/api/ocr/batch', { method: 'POST', body: {} });
  check('普通用户不能用批量 OCR（403）', rdBatch.status === 403, String(rdBatch.status));
  const rdStatus = await reader.json('/api/ocr/status');
  check('普通用户看 OCR 状态也被拒（403）', rdStatus.status === 403, String(rdStatus.status));
  const rdDetect = await reader.json('/api/ocr/detect', { method: 'POST', body: {} });
  check('普通用户不能重新探测引擎（403）', rdDetect.status === 403, String(rdDetect.status));

  // ---- 审计 ----
  const logs = await admin.json('/api/logs?size=300');
  const acts = (((logs.body.data || {}).list) || []).map((l) => l.action);
  check('★ OCR 识别进了审计日志', acts.some((x) => /OCR 识别正文/.test(x)), acts.slice(0, 6).join(','));
  check('批量 OCR 也进审计日志', acts.some((x) => /批量 OCR/.test(x)), acts.slice(0, 6).join(','));

  // =========================================================================
  section('五、收尾：还原引擎设置，并验证"没有引擎时如实说明"');
  // =========================================================================
  const clearEngine = await admin.json('/api/settings', { method: 'PUT', json: { 'ocr.engine_path': '', 'ocr.engine': 'auto' } });
  check('清空引擎路径成功', clearEngine.status === 200, JSON.stringify(clearEngine.body).slice(0, 160));
  const status3 = await admin.json('/api/ocr/status?force=1');
  const det3 = status3.body.data.detect;
  // v4.12.0 起 auto 会优先用 **Windows 自带识别**（零安装）。所以"清空自定义引擎路径"之后
  // 本机仍然可能是有引擎的 —— 那恰恰是好事。这里按实际情况断言：
  //   有 Windows 引擎 → 必须**回落**到它；没有 → 必须如实说不可用并给安装指引。
  if (det3.windows) {
    check('★ 清空自定义引擎后自动回落到 Windows 自带识别（零安装）',
      det3.available === true && det3.engine === 'windows', JSON.stringify(det3).slice(0, 140));
    check('★ 回落时也如实说明用的是哪一档引擎',
      (det3.notes || []).some((n) => /Windows/.test(n)), JSON.stringify(det3.notes));
  } else {
    check('★ 本机没有引擎时如实报告不可用', det3.available === false, JSON.stringify(det3).slice(0, 140));
    check('★ 不可用时给出可执行的下一步（安装指引）',
      /Tesseract|OCR 引擎|engine_path/.test(det3.reason || ''), String(det3.reason || '').slice(0, 120));
    check('不可用时 canPdf 为 false（不假装能处理 PDF）', det3.canPdf === false, String(det3.canPdf));
  }

  const badPath = await admin.json('/api/settings', { method: 'PUT', json: { 'ocr.engine_path': 'C:\\nonexistent\\tesseract.exe' } });
  check('引擎路径不存在时拒绝保存（不让用户以为配好了）', badPath.status === 400, String(badPath.status));
  const badMode = await admin.json('/api/settings', { method: 'PUT', json: { 'ocr.mode': 'maybe' } });
  check('ocr.mode 非法取值被拒', badMode.status === 400, String(badMode.status));
  const offMode = await admin.json('/api/settings', { method: 'PUT', json: { 'ocr.mode': 'none' } });
  check('可以把 OCR 明确关闭（mode=none）', offMode.status === 200, String(offMode.status));
  const statusOff = await admin.json('/api/ocr/status?force=1');
  check('★ 关闭后不调用任何外部程序，直接说明已关闭',
    statusOff.body.data.detect.available === false && /关闭/.test(statusOff.body.data.detect.reason || ''),
    String(statusOff.body.data.detect.reason || '').slice(0, 100));
  await admin.json('/api/settings', { method: 'PUT', json: { 'ocr.mode': 'auto' } });

  for (const id of createdIds) await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  if (mkRd.body.ok) await admin.json('/api/users/' + mkRd.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  try { fs.rmSync(fake.dir, { recursive: true, force: true }); } catch (_) { /* 忽略 */ }
  const left = await admin.json('/api/archives?kw=' + encodeURIComponent(TAG) + '&size=100');
  check('清理：没有残留测试档案', ((left.body.data || {}).list || []).length === 0,
    String(((left.body.data || {}).list || []).length));

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
