'use strict';
const fs = require('node:fs');
const path = require('node:path');
const te = require('../lib/text-extract');

const dirs = ['Desktop', 'Documents', 'Downloads'].map((d) => path.join(process.env.USERPROFILE || '', d));
const targets = [];
for (const dir of dirs) {
  let list = [];
  try { list = fs.readdirSync(dir); } catch (_) { continue; }
  for (const f of list) {
    if (!/\.(pdf|docx|xlsx|pptx|doc|xls|txt|csv)$/i.test(f)) continue;
    const full = path.join(dir, f);
    let size = 0;
    try { size = fs.statSync(full).size; } catch (_) { continue; }
    if (size < 3 * 1024 || size > 10 * 1024 * 1024) continue;
    targets.push(full);
  }
}

const stat = new Map();
let scannedLike = 0;
const examples = { ok: [], scanned: [], legacy: [], fail: [] };

for (const full of targets) {
  const name = path.basename(full);
  const ext = (name.match(/\.[a-z0-9]+$/i) || [''])[0].toLowerCase();
  const s = stat.get(ext) || { total: 0, ok: 0, chars: 0, ms: 0 };
  s.total++;
  let r;
  const t0 = Date.now();
  try { r = te.extractText(fs.readFileSync(full), name); } catch (e) { r = { ok: false, reason: '异常: ' + e.message }; }
  s.ms += Date.now() - t0;
  if (r.ok) {
    s.ok++; s.chars += r.text.length;
    if (examples.ok.length < 3) examples.ok.push(name + ' → ' + r.text.replace(/\s+/g, ' ').slice(0, 40));
  } else if (/没有文字层/.test(r.reason || '')) {
    scannedLike++;
    if (examples.scanned.length < 3) examples.scanned.push(name);
  } else if (/旧版二进制/.test(r.reason || '')) {
    if (examples.legacy.length < 3) examples.legacy.push(name);
  } else if (examples.fail.length < 3) examples.fail.push(name + ' → ' + r.reason);
  stat.set(ext, s);
}

console.log('=== 附件正文提取：真实样本统计 ===');
console.log('样本目录：桌面 / 文档 / 下载   合计 ' + targets.length + ' 个文件\n');
console.log('扩展名   总数   成功   成功率   平均字符   平均耗时');
let totalAll = 0, okAll = 0;
for (const [ext, s] of [...stat].sort((a, b) => b[1].total - a[1].total)) {
  totalAll += s.total; okAll += s.ok;
  console.log(
    ext.padEnd(8) + String(s.total).padStart(4) + String(s.ok).padStart(7) +
    ('  ' + (s.total ? (s.ok / s.total * 100).toFixed(0) : 0) + '%').padStart(9) +
    String(s.ok ? Math.round(s.chars / s.ok) : 0).padStart(11) +
    String(Math.round(s.ms / s.total) + 'ms').padStart(11),
  );
}
console.log('\n总体：成功 ' + okAll + '/' + totalAll + '（' + (totalAll ? (okAll / totalAll * 100).toFixed(0) : 0) + '%）');
console.log('其中判定为「扫描件/无文字层」：' + scannedLike + ' 个（需 OCR，非解析器缺陷）');
console.log('\n成功样例：'); examples.ok.forEach((e) => console.log('  ' + e));
console.log('\n扫描件样例：'); examples.scanned.forEach((e) => console.log('  ' + e));
console.log('\n旧版 Office 样例：'); examples.legacy.forEach((e) => console.log('  ' + e));
console.log('\n其他未提取：'); examples.fail.forEach((e) => console.log('  ' + e));
