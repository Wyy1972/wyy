/**
 * 迁移与档号规则验证
 * 1) 全新库能否建成 v2 结构
 * 2) 迁移是否幂等（重复打开不报错、不重复回填）
 * 3) 档号规则引擎生成的档号是否符合预期
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { openDatabase, RETENTION_MAP } = require('../db');
const { makeApi } = require('../lib/q');
const numbering = require('../lib/numbering');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'asnum-'));
const dbPath = path.join(dir, 'test.db');
let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

console.log('【1. 全新库结构】');
let db = openDatabase(dbPath);
let q = makeApi(db);
const cols = new Set(db.prepare('PRAGMA table_info(archives)').all().map((r) => r.name));
for (const c of ['archive_number', 'unit_code', 'category_code', 'catalog_no', 'retention_code',
  'retention_years', 'retention_due_year', 'open_state', 'box_id', 'electronic_flag', 'created_via']) {
  check('archives 含列 ' + c, cols.has(c));
}
const tables = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name));
for (const t of ['locations', 'archive_boxes', 'appraisals', 'destructions', 'destruction_items',
  'stock_checks', 'stock_check_items', 'import_batches', 'settings',
  'file_text', 'file_text_fts', 'transfers', 'transfer_items',
  'saved_searches', 'number_sequences']) {
  check('存在表 ' + t, tables.has(t));
}
const ver = Number(q.scalar("SELECT value FROM meta WHERE key='schema_version'"));
check('schema_version 已升到 15', ver >= 15, String(ver));
check('默认设置项已写入', q.scalar("SELECT COUNT(*) FROM settings") >= 7);

console.log('\n【1c. 档号号段表（v15：号码只增不回退）】');
{
  const nsCols = new Set(db.prepare('PRAGMA table_info(number_sequences)').all().map((r) => r.name));
  for (const c of ['type_code', 'year', 'kind', 'last_seq', 'updated_at']) {
    check('number_sequences 含列 ' + c, nsCols.has(c));
  }
  // 回填的正确性在【2】里等有存量档号之后再验（空库无号可回填）
}

console.log('\n【1b. 附件正文全文索引联动】');
{
  const cat = q.get('SELECT id FROM categories LIMIT 1');
  const ts = new Date().toISOString();
  const a = q.run(`INSERT INTO archives(archive_code,title,category_id,type_code,retention,year,archive_date,
                    status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    'ZZ-2026-0001', '正文索引联动测试', cat.id, 'WS', '永久', '2026', '2026-01-01', '在库', ts, ts);
  const f = q.run(`INSERT INTO files(archive_id,original_name,stored_name,rel_path,mime,size,sha256,kind,sort_no,created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?)`,
    a.lastInsertRowid, '测试.txt', 'abc.txt', 'WS/2026/ab/abc.txt', 'text/plain', 10, 'abc', '正文', 1, ts);
  q.run(`INSERT INTO file_text(file_id,archive_id,content,char_count,status,kind,reason,extracted_at)
         VALUES(?,?,?,?,'成功','文本文件','',?)`,
    f.lastInsertRowid, a.lastInsertRowid, '这是一段用于验证全文检索的测试正文内容', 20, ts);
  const hit = q.all("SELECT rowid FROM file_text_fts WHERE file_text_fts MATCH ?", '"全文检索"');
  check('附件正文写入后可被全文检索命中', hit.length === 1, '命中 ' + hit.length + ' 条');
  q.run('DELETE FROM file_text WHERE file_id=?', f.lastInsertRowid);
  const after = q.all("SELECT rowid FROM file_text_fts WHERE file_text_fts MATCH ?", '"全文检索"');
  check('删除正文后索引同步清理', after.length === 0, '残留 ' + after.length + ' 条');
  q.run('DELETE FROM files WHERE id=?', f.lastInsertRowid);
  q.run('DELETE FROM archives WHERE id=?', a.lastInsertRowid);
}

console.log('\n【2. 插入档案后自动补全档号字段】');
const wsCat = q.get("SELECT id FROM categories WHERE code='WS-DQ'") || q.get("SELECT id FROM categories LIMIT 1");
const ins = q.run(
  `INSERT INTO archives(archive_code,title,category_id,type_code,retention,secret_level,year,archive_date,
    responsible,department,abstract,keywords,extra,status,created_at,updated_at)
   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  'WS-2025-9001', '迁移测试档案', wsCat.id, 'WS', '定期10年', '公开', '2025', '2025-06-01',
  '测试', '测试科', '摘要', '测试', '{}', '在库', new Date().toISOString(), new Date().toISOString(),
);
const newId = ins.lastInsertRowid;
// 触发回填（重新打开数据库即执行迁移逻辑）
db.close();
db = openDatabase(dbPath);
q = makeApi(db);
const filled = q.get('SELECT * FROM archives WHERE id=?', newId);
check('存量档案已回填 unit_code', filled.unit_code !== '', String(filled.unit_code));
check('存量档案已回填 category_code', filled.category_code === 'WS-DQ', String(filled.category_code));
check('存量档案已回填 retention_code=D10', filled.retention_code === 'D10', String(filled.retention_code));
check('定期10年 到期年度=2035', Number(filled.retention_due_year) === 2035, String(filled.retention_due_year));
check('已生成规范档号', /^Z001-WS-DQ-01-2025-9001$/.test(filled.archive_number), String(filled.archive_number));

// v15 号段回填：这条存量档号是 WS-2025-9001，重新打开库触发迁移后，
// 号段表里 WS·2025 必须记到 9001 —— 否则升级后新建的第一条档案会从 0001 开始，直接重号。
const nsRow = q.get("SELECT last_seq, updated_at FROM number_sequences WHERE type_code='WS' AND year='2025' AND kind='archive'");
check('号段已按存量档号回填（WS·2025 → 9001）', Number(nsRow && nsRow.last_seq) === 9001,
  nsRow ? String(nsRow.last_seq) : '(无记录)');
check('号段记录带有更新时间', !!nsRow && !!String(nsRow.updated_at || ''), nsRow && nsRow.updated_at);

console.log('\n【3. 幂等性（重复打开）】');
const before = q.get('SELECT archive_number, retention_due_year FROM archives WHERE id=?', newId);
db.close();
db = openDatabase(dbPath);
q = makeApi(db);
const after = q.get('SELECT archive_number, retention_due_year FROM archives WHERE id=?', newId);
check('重复迁移不改变已有档号', before.archive_number === after.archive_number,
  `${before.archive_number} vs ${after.archive_number}`);
check('重复迁移无重复行', Number(q.scalar('SELECT COUNT(*) FROM archives')) === 1);
check('重复迁移不残留临时数据', Number(q.scalar('SELECT COUNT(*) FROM archives')) === 1);

console.log('\n【4. 档号规则引擎】');
check('模板校验：合法模板', numbering.validateTemplate('{unit}-{category}-{year}-{seq4}').ok);
check('模板校验：拒绝无流水模板', !numbering.validateTemplate('{unit}-{category}').ok);
check('模板校验：拒绝 unknown 占位符', !numbering.validateTemplate('{unit}-{foo}').ok);
check('模板校验：拒绝 year+volume 冲突', !numbering.validateTemplate('{unit}-{year}-{volume}').ok);

// v4.8.0 起：出厂默认模板 = DA/T 22—2015 §5.4 标准结构，
// 即 全宗号-档案门类代码·年度-保管期限-机构(问题)代码-件号
const p1 = numbering.previewNumber(q, { typeCode: 'WS', year: '2026', categoryId: wsCat.id, retentionCode: 'D30' });
check('出厂默认模板即 DA/T 22—2015 标准结构',
  /^Z001-WS·2026-D30-DQ-\d{4}$/.test(p1.archive_number), p1.archive_number);
check('同时给出兼容短档案号', /^WS-2026-\d{4}$/.test(p1.archive_code), p1.archive_code);

// 模板段填不满时**拒绝出号**：不再产出 Z001-WS·2026--DQ-0001 这种空段档号
let gapErr = null;
try { numbering.previewNumber(q, { typeCode: 'WS', year: '2026', categoryId: wsCat.id }); }
catch (e) { gapErr = e; }
check('保管期限取不到值时拒绝出号（不再留空段）', !!gapErr && gapErr.statusCode === 400,
  gapErr ? gapErr.message : '竟然出号了');
check('拒绝原因点名了缺的是保管期限', !!gapErr && /保管期限/.test(gapErr.message),
  gapErr && gapErr.message);
check('unfilledSegments 能列出填不满的段',
  numbering.unfilledSegments('{unit}-{typeYear}-{retention}-{org}-{item}',
    { unit: 'Z001', typeYear: 'WS·2026', retention: '', org: 'DQ', item: 1 })
    .some((g) => g.token === 'retention' && g.label === '保管期限代码'));

// 切换到标准档号模板
q.run("UPDATE settings SET value=? WHERE key='archive.code_template'", '{unit}-{category}-{catalog}-{volume}-{item}');
const p2 = numbering.previewNumber(q, { typeCode: 'WS', year: '2026', categoryId: wsCat.id });
check('标准档号模板生效', /^Z001-WS-DQ-01-\d{4}-\d{4}$/.test(p2.archive_number), p2.archive_number);
const p3 = numbering.previewNumber(q, { typeCode: 'WS', year: '2026', categoryId: wsCat.id });
check('预览不占用序号（两次预览一致）', p2.archive_number === p3.archive_number,
  `${p2.archive_number} vs ${p3.archive_number}`);

// 门类级模板优先于全局
q.run("UPDATE archive_types SET code_template=? WHERE code='HT'", '{unit}-HT-{year}-{seq3}');
const p4 = numbering.previewNumber(q, { typeCode: 'HT', year: '2026', categoryId: wsCat.id });
check('门类级模板优先', /^Z001-HT-2026-\d{3}$/.test(p4.archive_number), p4.archive_number);

console.log('\n【4b. 档号结构（DA/T 22—2015 / DA/T 13—2022）】');
check('模板校验：拒绝 typeYear 与 year 同时出现（年度会重复）',
  !numbering.validateTemplate('{unit}-{typeYear}-{year}-{item}').ok);
check('模板校验：拒绝 typeYear 与 volume 同时出现',
  !numbering.validateTemplate('{unit}-{typeYear}-{volume}').ok);

// DA/T 22—2015 §5.4 结构：全宗号-档案门类代码·年度-保管期限-机构(问题)代码-件号
q.run("UPDATE archive_types SET code_template='' WHERE code='HT'");
q.run("UPDATE settings SET value=? WHERE key='archive.code_template'", numbering.PRESET_DAT22);
const d1 = numbering.previewNumber(q, {
  typeCode: 'WS', year: '2026', categoryId: wsCat.id, retentionCode: 'D30', categoryCode: 'WS-XZ',
});
check('DA/T 22—2015 标准档号结构正确',
  /^Z001-WS·2026-D30-XZ-\d{4}$/.test(d1.archive_number), d1.archive_number);
check('档号内含保管期限代码（旧模板结构上做不到）',
  d1.archive_number.includes('-D30-'), d1.archive_number);
check('机构(问题)代码取自分类号「门类-机构」的后半段',
  d1.archive_number.includes('-XZ-'), d1.archive_number);
check('门类代码与年度之间用间隔号 ·',
  d1.archive_number.includes('WS·2026'), d1.archive_number);

// 空段一律拒绝（v4.8.0 起的刻意行为）：早期这里允许"先出号、后补期限"，
// 代价是产出 Z001-WS·2026--DQ-0001 这种结构错乱的档号且毫无提示。
// 现在改成当场拒绝并说清缺哪一项 —— 正式著录时保管期限总会回退到门类默认值，
// 所以这条严格规则不会挡住正常流程，只挡模板/数据本身有问题的情形。
let gap2 = null;
try {
  numbering.previewNumber(q, { typeCode: 'WS', year: '2026', categoryId: wsCat.id, categoryCode: 'WS-DQ' });
} catch (e) { gap2 = e; }
check('未传保管期限代码时拒绝出号（不再留空段）', !!gap2 && gap2.statusCode === 400,
  gap2 ? gap2.message : '竟然出号了');
check('报错说清了缺的是保管期限', !!gap2 && /保管期限/.test(gap2.message), gap2 && gap2.message);

const d3 = numbering.previewNumber(q, {
  typeCode: 'WS', year: '2026', categoryId: wsCat.id, retentionCode: 'D30',
});
check('未显式传分类号时，自动从分类表查出并推出机构(问题)代码',
  d3.archive_number.includes('-DQ-'), d3.archive_number);

const vStd = numbering.validateTemplate(numbering.PRESET_DAT22);
check('标准模板被判为符合现行结构', vStd.ok && vStd.compliant === true, JSON.stringify(vStd));
const vOld = numbering.validateTemplate(numbering.PRESET_LEGACY);
check('旧模板仍可用（不阻断既有单位）', vOld.ok === true);
check('旧模板给出标准符合性提示', vOld.compliant === false && (vOld.warnings || []).length > 0,
  JSON.stringify(vOld.warnings || []));
check('提示里点明了缺失「保管期限」', /保管期限/.test((vOld.warnings || []).join('')));
check('提示里给出了标准模板', (vOld.warnings || []).join('').includes(numbering.PRESET_DAT22));

console.log('\n【5. 保管期限映射】');
check('永久 → Y/0 年', RETENTION_MAP['永久'].code === 'Y' && RETENTION_MAP['永久'].years === 0);
check('定期30年 → D30/30 年', RETENTION_MAP['定期30年'].code === 'D30' && RETENTION_MAP['定期30年'].years === 30);
check('定期5年 → D5/5 年', RETENTION_MAP['定期5年'].code === 'D5');

console.log('\n【6. 号段只增不回退】');
// 放在最后：这一段会删掉档案，前面的用例还依赖它。
// 这里验的正是 v4.8.0 修的核心缺陷 —— 删掉序号最大的那一条后，
// 号段必须**保持在 9001**，否则下一条新档案会复用 9001 这个档号。
{
  const delIds = q.all("SELECT id FROM archives WHERE type_code='WS' AND year='2025'");
  check('先确认还有可删的档案', delIds.length > 0, String(delIds.length));
  for (const r of delIds) q.run('DELETE FROM archives WHERE id=?', r.id);
  db.close(); db = openDatabase(dbPath); q = makeApi(db);   // 重新打开（跑迁移）
  const afterDel = q.get("SELECT last_seq FROM number_sequences WHERE type_code='WS' AND year='2025' AND kind='archive'");
  check('★ 删除档案后号段不回退（仍为 9001）', Number(afterDel && afterDel.last_seq) === 9001,
    afterDel ? String(afterDel.last_seq) : '(无记录)');
}

db.close();
fs.rmSync(dir, { recursive: true, force: true });

console.log('\n' + '='.repeat(52));
console.log(`迁移与档号规则验证：通过 ${pass} 项，失败 ${failed} 项`);
if (failed) fails.forEach((f) => console.log('  - ' + f));
console.log('='.repeat(52));
process.exit(failed ? 1 : 0);
