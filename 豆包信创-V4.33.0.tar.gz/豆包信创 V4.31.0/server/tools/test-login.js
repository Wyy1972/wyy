/**
 * 登录防护与口令策略回归测试
 *
 * 用法：node server/tools/test-login.js [http://127.0.0.1:8796]
 *
 * 覆盖（对应 GB/T 18894—2016 §5.2.4 身份鉴别、档办发〔2017〕3号第三十八条口令管理、
 * 等保 2.0 登录失败处理要求）：
 *   1. 口令强度策略：长度 / 弱口令清单 / 与用户名的关系 / 单一字符类型
 *   2. 连续失败锁定，且锁定期间即使口令正确也拒绝
 *   3. 登录成功清零失败计数
 *   4. 管理员/安全保密员可解锁；重置口令会同时解锁
 *   5. 登录失败对外不区分原因（账号不存在 vs 口令错误）
 *   6. 按来源 IP 限流（429）
 *   7. CSRF 纵深防御：伪造 Origin 的带凭证写请求被拒；同源与无 Origin 放行
 *   8. 弱口令审计能查出正在使用弱口令的账号
 *   9. /api/me 与 安全体检暴露口令策略与登录防护状态
 *
 * 脚本结束时恢复被改动的设置、删除测试账号，可重复运行。
 */
'use strict';

const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  return { req, json };
}

const TAG = 'LOG' + Math.random().toString(16).slice(2, 8).toUpperCase();
const GOOD_PWD = 'Archive@2026x';

async function main() {
  const admin = makeSession();
  const created = { users: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);

  const settingsBefore = (await admin.json('/api/settings')).body.data.settings;
  const keep = (k) => settingsBefore[k];
  const restore = async () => {
    await admin.json('/api/settings', {
      method: 'PUT',
      json: {
        'security.login_max_fail': keep('security.login_max_fail'),
        'security.login_lock_minutes': keep('security.login_lock_minutes'),
        'security.login_rate_per_minute': keep('security.login_rate_per_minute'),
        'security.password_min_length': keep('security.password_min_length'),
        'security.password_require_complexity': keep('security.password_require_complexity'),
      },
    });
  };
  // 先把限流放宽，避免本套件自身的失败尝试被前面套件累积的失败计数误伤
  await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '600' } });

  async function makeUser(username, password, role = 'reader') {
    const r = await admin.json('/api/users', {
      method: 'POST',
      json: { username, display_name: username, password, role },
    });
    if (r.body.ok) created.users.push(r.body.data.id);
    return r;
  }

  /**
   * 用**独立会话**尝试登录。
   * 绝不能用 admin 的会话去登录别的账号：登录成功会把 admin 的 Cookie 覆盖成那个账号的，
   * 之后所有管理员接口都会 403（本项目踩过一次）。
   */
  async function tryLogin(username, password) {
    const s = makeSession();
    const r = await s.json('/api/login', { method: 'POST', json: { username, password } });
    return { session: s, status: r.status, body: r.body };
  }

  // ---------- 1. 口令强度策略 ----------
  section('口令强度策略');
  const shortPwd = await makeUser(`${TAG.toLowerCase()}_p1`, 'Ab@1');
  check('拒绝过短口令', shortPwd.status === 400 && /长度/.test(JSON.stringify(shortPwd.body)),
    JSON.stringify(shortPwd.body).slice(0, 140));
  const weakPwd = await makeUser(`${TAG.toLowerCase()}_p2`, 'admin123');
  check('拒绝常见弱口令（admin123）', weakPwd.status === 400 && /弱口令/.test(JSON.stringify(weakPwd.body)),
    JSON.stringify(weakPwd.body).slice(0, 140));
  const userPwd = await makeUser(`${TAG.toLowerCase()}_p3`, `${TAG.toLowerCase()}_p3`);
  check('拒绝与用户名相同的口令', userPwd.status === 400 && /用户名/.test(JSON.stringify(userPwd.body)),
    JSON.stringify(userPwd.body).slice(0, 140));
  const digitsPwd = await makeUser(`${TAG.toLowerCase()}_p4`, '987654321');
  check('拒绝短的纯数字口令', digitsPwd.status === 400 && /纯数字/.test(JSON.stringify(digitsPwd.body)),
    JSON.stringify(digitsPwd.body).slice(0, 140));
  const good = await makeUser(`${TAG.toLowerCase()}_ok`, GOOD_PWD);
  check('合规口令可以创建账号', good.body.ok, JSON.stringify(good.body).slice(0, 140));

  // ---------- 2. 登录失败不区分原因 ----------
  section('登录失败不对外区分原因');
  const noSuch = await tryLogin(`${TAG}_nobody`, 'Whatever@123');
  const wrongPwd = await tryLogin(`${TAG.toLowerCase()}_ok`, 'Wrong@123456');
  check('不存在的用户名返回 401', noSuch.status === 401, 'status=' + noSuch.status);
  check('口令错误返回 401', wrongPwd.status === 401, 'status=' + wrongPwd.status);
  check('两者对外是同一句话（避免账号枚举）',
    String(noSuch.body.error || '').replace(/；.*$/, '') === String(wrongPwd.body.error || '').replace(/；.*$/, ''),
    `${noSuch.body.error} | ${wrongPwd.body.error}`);

  // ---------- 3. 连续失败锁定 ----------
  section('连续失败锁定');
  const lockUser = `${TAG.toLowerCase()}_lock`;
  await makeUser(lockUser, GOOD_PWD);
  await admin.json('/api/settings', {
    method: 'PUT',
    json: { 'security.login_max_fail': '3', 'security.login_lock_minutes': '2', 'security.login_rate_per_minute': '600' },
  });

  const failsStatus = [];
  for (let i = 0; i < 3; i++) {
    const r = await tryLogin(lockUser, 'Wrong@123456');
    failsStatus.push(r.status);
  }
  check('前几次失败返回 401（尚未锁定）', failsStatus.slice(0, 2).every((s) => s === 401), failsStatus.join(','));
  check('达到阈值那一次起账号被锁定', failsStatus[2] === 401, failsStatus.join(','));

  const correctButLocked = await tryLogin(lockUser, GOOD_PWD);
  check('锁定期间即使口令正确也拒绝', correctButLocked.status === 423, 'status=' + correctButLocked.status);
  check('锁定提示给出剩余分钟数', /分钟/.test(JSON.stringify(correctButLocked.body)),
    JSON.stringify(correctButLocked.body).slice(0, 160));

  // ---------- 4. 解锁 ----------
  section('账号解锁');
  const usersList = await admin.json('/api/users');
  const lockRow = (usersList.body.data.list || []).find((x) => x.username === lockUser) || {};
  check('用户列表显示锁定状态', lockRow.locked === true, JSON.stringify(lockRow).slice(0, 160));
  check('用户列表显示失败次数', Number(lockRow.failed_count) >= 3, String(lockRow.failed_count));

  const unlock = await admin.json(`/api/users/${lockRow.id}/unlock`, { method: 'POST' });
  check('管理员可解锁账号', unlock.body.ok, JSON.stringify(unlock.body).slice(0, 140));
  const afterUnlock = await tryLogin(lockUser, GOOD_PWD);
  check('解锁后可以正常登录', afterUnlock.body.ok, JSON.stringify(afterUnlock.body).slice(0, 140));

  // ---------- 5. 成功登录清零失败计数 ----------
  section('成功登录清零失败计数');
  const lockUser2 = `${TAG.toLowerCase()}_clear`;
  await makeUser(lockUser2, GOOD_PWD);
  for (let i = 0; i < 2; i++) {
    await tryLogin(lockUser2, 'Wrong@123456');
  }
  const beforeClear = (await admin.json('/api/users')).body.data.list.find((x) => x.username === lockUser2) || {};
  check('失败 2 次后计数为 2', Number(beforeClear.failed_count) === 2, String(beforeClear.failed_count));
  await tryLogin(lockUser2, GOOD_PWD);
  const afterClear = (await admin.json('/api/users')).body.data.list.find((x) => x.username === lockUser2) || {};
  check('成功登录后失败计数清零', Number(afterClear.failed_count) === 0, String(afterClear.failed_count));

  // ---------- 6. 重置口令同时解锁 ----------
  section('重置口令同时解锁');
  const lockUser3 = `${TAG.toLowerCase()}_reset`;
  const u3 = await makeUser(lockUser3, GOOD_PWD);
  for (let i = 0; i < 3; i++) {
    await tryLogin(lockUser3, 'Wrong@123456');
  }
  const lockedRow = (await admin.json('/api/users')).body.data.list.find((x) => x.username === lockUser3) || {};
  check('该账号已锁定', lockedRow.locked === true);
  const reset = await admin.json(`/api/users/${u3.body.data.id}/reset-password`, {
    method: 'POST', json: { password: 'Reset@2026ok' },
  });
  check('重置口令成功', reset.body.ok, JSON.stringify(reset.body).slice(0, 140));
  const relogin = await tryLogin(lockUser3, 'Reset@2026ok');
  check('重置后解除锁定并可登录', relogin.body.ok, JSON.stringify(relogin.body).slice(0, 140));
  const resetWeak = await admin.json(`/api/users/${u3.body.data.id}/reset-password`, {
    method: 'POST', json: { password: '123456' },
  });
  check('重置为弱口令被拒绝', resetWeak.status === 400, 'status=' + resetWeak.status);

  // ---------- 7. 改密策略 ----------
  section('修改口令策略');
  const okSession = makeSession();
  await okSession.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_ok`, password: GOOD_PWD } });
  const samePwd = await okSession.json('/api/me/password', {
    method: 'POST', json: { oldPassword: GOOD_PWD, newPassword: GOOD_PWD },
  });
  check('新口令不能与原口令相同', samePwd.status === 400, 'status=' + samePwd.status);
  const weakNew = await okSession.json('/api/me/password', {
    method: 'POST', json: { oldPassword: GOOD_PWD, newPassword: 'admin123' },
  });
  check('改成弱口令被拒绝', weakNew.status === 400, 'status=' + weakNew.status);
  const goodNew = await okSession.json('/api/me/password', {
    method: 'POST', json: { oldPassword: GOOD_PWD, newPassword: 'Archive@2026y' },
  });
  check('合规新口令修改成功', goodNew.body.ok, JSON.stringify(goodNew.body).slice(0, 140));
  const afterChange = await tryLogin(`${TAG.toLowerCase()}_ok`, 'Archive@2026y');
  check('可用新口令登录', afterChange.body.ok);

  // ---------- 8. 口令策略随设置变化 ----------
  section('口令策略可配置');
  await admin.json('/api/settings', { method: 'PUT', json: { 'security.password_min_length': '14' } });
  const tooShortNow = await makeUser(`${TAG.toLowerCase()}_len14`, 'Ab@12345678');
  check('最小长度提高到 14 后，12 位口令被拒', tooShortNow.status === 400,
    JSON.stringify(tooShortNow.body).slice(0, 140));
  await admin.json('/api/settings', { method: 'PUT', json: { 'security.password_require_complexity': '1' } });
  const noComplex = await makeUser(`${TAG.toLowerCase()}_cx`, 'abcdefghijklmn');
  check('开启复杂度要求后，纯字母长口令被拒', noComplex.status === 400,
    JSON.stringify(noComplex.body).slice(0, 140));
  await admin.json('/api/settings', {
    method: 'PUT', json: { 'security.password_min_length': '8', 'security.password_require_complexity': '0' },
  });

  // ---------- 9. 限流 ----------
  section('按 IP 限流');
  await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '2', 'security.login_max_fail': '0' } });
  let got429 = false;
  let tried = 0;
  for (let i = 0; i < 6 && !got429; i++) {
    tried++;
    const r = await tryLogin(`${TAG}_spray${i}`, 'Wrong@123456');
    if (r.status === 429) got429 = true;
  }
  check('短时间内大量失败会被限流（429）', got429, `尝试 ${tried} 次仍未限流`);
  await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '600' } });
  const afterRate = await tryLogin('admin', 'admin123');
  check('放宽限流后恢复正常登录', afterRate.body.ok, JSON.stringify(afterRate.body).slice(0, 140));

  // ---------- 10. CSRF Origin 校验 ----------
  section('CSRF 纵深防御');
  const evil = await admin.req('/api/categories', {
    method: 'POST',
    headers: { Origin: 'http://evil.example.com', 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'x', code: 'X' }),
  });
  check('伪造 Origin 的带凭证写请求被拒（403）', evil.status === 403, 'status=' + evil.status);
  const sameOrigin = await admin.req('/api/archives/bulk-status', {
    method: 'POST',
    headers: { Origin: BASE, 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids: [], status: '在库' }),
  });
  check('同源 Origin 放行（非 403）', sameOrigin.status !== 403, 'status=' + sameOrigin.status);
  const noOrigin = await admin.req('/api/archives/bulk-status', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids: [], status: '在库' }),
  });
  check('无 Origin 的非浏览器客户端放行（自测/脚本不受影响）', noOrigin.status !== 403, 'status=' + noOrigin.status);
  const readOk = await admin.req('/api/me', { headers: { Origin: 'http://evil.example.com' } });
  check('GET 请求不受来源校验影响', readOk.status === 200, 'status=' + readOk.status);

  // ---------- 11. 弱口令审计 ----------
  section('弱口令审计');
  const audit = await admin.json('/api/security/audit-passwords', { method: 'POST' });
  check('可触发口令审计', audit.status === 200 && typeof audit.body.data.checked === 'number',
    JSON.stringify(audit.body.data || {}).slice(0, 160));
  check('审计返回弱口令清单', Array.isArray(audit.body.data.weak), JSON.stringify(audit.body.data.weak || []).slice(0, 160));
  // 出厂管理员口令就是常见的 admin123 —— 审计应当把它揪出来
  check('能查出正在使用弱口令的账号（含出厂默认口令）',
    (audit.body.data.weak || []).some((x) => x.username === 'admin'),
    JSON.stringify(audit.body.data.weak || []).slice(0, 200));

  // ---------- 12. 接口暴露策略 ----------
  section('策略与状态可查');
  const me = await admin.json('/api/me');
  check('/api/me 返回口令策略', !!(me.body.data.passwordPolicy && me.body.data.passwordPolicy.minLength),
    JSON.stringify(me.body.data.passwordPolicy || {}).slice(0, 160));
  check('口令策略给出可读规则', Array.isArray(me.body.data.passwordPolicy.rules)
    && me.body.data.passwordPolicy.rules.length > 0, JSON.stringify(me.body.data.passwordPolicy.rules || []));
  const st = await admin.json('/api/security/status');
  const lp = (st.body.data || {}).loginProtection || {};
  check('安全体检返回登录防护配置', typeof lp.maxFail === 'number' && typeof lp.ratePerMinute === 'number',
    JSON.stringify(lp).slice(0, 200));
  check('安全体检返回最近 24 小时失败次数', typeof lp.recentFailures24h === 'number', String(lp.recentFailures24h));
  check('安全体检返回锁定账号清单', Array.isArray(lp.lockedUsers), JSON.stringify(lp.lockedUsers || []).slice(0, 160));
  check('安全体检返回弱口令审计结果', !!lp.weakPasswords, JSON.stringify(lp.weakPasswords || {}).slice(0, 160));

  // ---------- 清理 ----------
  section('清理');
  await restore();
  let cleaned = 0;
  for (const id of created.users) {
    const r = await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) cleaned++;
  }
  check(`测试账号已清理（${cleaned}/${created.users.length}）`, cleaned === created.users.length);
  // 把 admin 自己的失败计数清掉，避免影响后续运行
  const admins = (await admin.json('/api/users')).body.data.list.filter((x) => x.username === 'admin');
  for (const a of admins) await admin.json(`/api/users/${a.id}/unlock`, { method: 'POST' });
  const settingsAfter = (await admin.json('/api/settings')).body.data.settings;
  check('登录防护设置已还原',
    settingsAfter['security.login_max_fail'] === keep('security.login_max_fail')
    && settingsAfter['security.login_rate_per_minute'] === keep('security.login_rate_per_minute'),
    JSON.stringify([settingsAfter['security.login_max_fail'], settingsAfter['security.login_rate_per_minute']]));

  // ---------- 登录身份门禁（v4.18.0）----------
  //
  // 使用者要的是"进门这一步就选定身份"：登录页下拉只有 档案管理员 / 其他人员 两种。
  // 身份与账号角色不一致时当场拒绝，而不是进去以后才发现菜单不对。
  // 注意它**不是安全边界** —— 真正拦住人的始终是口令；它管的是一致性与可解释性。
  section('登录身份门禁');
  {
    const tryId = async (body) => {
      const r = await fetch(BASE + '/api/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      const t = await r.text();
      let d = {}; try { d = JSON.parse(t); } catch (_) { /* ignore */ }
      return { status: r.status, ok: !!(d && d.ok), error: (d && d.error) || '' };
    };
    const lg = await tryId({ username: 'admin', password: 'admin123', identity: 'manager' });
    check('档案管理员身份可登录', lg.ok, `status=${lg.status} ${lg.error}`);
    const wrongId = await tryId({ username: 'admin', password: 'admin123', identity: 'staff' });
    check('★ 身份选错当场拒绝，且说清是身份不符', !wrongId.ok && /身份/.test(wrongId.error),
      `status=${wrongId.status} ${wrongId.error}`);
    const badId = await tryId({ username: 'admin', password: 'admin123', identity: 'hacker' });
    check('非法身份值返回 400', badId.status === 400, `status=${badId.status}`);
    const noId = await tryId({ username: 'admin', password: 'admin123' });
    check('不带身份仍可登录（兼容脚本与旧调用）', noId.ok, `status=${noId.status}`);
    const wrongPwd = await tryId({ username: 'admin', password: 'definitely-wrong', identity: 'manager' });
    check('口令错时不泄露账号角色（仍是"用户名或密码错误"一句话）',
      !wrongPwd.ok && /用户名或密码错误/.test(wrongPwd.error), `${wrongPwd.status} ${wrongPwd.error}`);

    // v4.19.0：登录页只要「身份 + 口令」两个框 ——
    // 服务端在**该身份的账号里按口令逐个比对**，命中哪个账号就是哪个。
    // 这样界面简化的同时，账号仍然一人一个，审计日志记的是本人账号而不是笼统的身份。
    const byId = await tryId({ identity: 'manager', password: 'admin123' });
    check('★ 只给「身份 + 口令」即可登录（登录页只有两个框）', byId.ok, `status=${byId.status} ${byId.error}`);
    const crossId = await tryId({ identity: 'staff', password: 'admin123' });
    check('其他人员身份 + 管理员口令被拒（该身份下无匹配账号）', !crossId.ok, `status=${crossId.status}`);
    const noIdent = await tryId({ password: 'admin123' });
    check('只给口令、不给身份返回 400', noIdent.status === 400, `status=${noIdent.status}`);
  }

  console.log(`\n登录与口令防护回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n登录防护测试异常终止：', e); process.exit(1); });
