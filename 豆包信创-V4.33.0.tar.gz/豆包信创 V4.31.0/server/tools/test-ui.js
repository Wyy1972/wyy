/**
 * 四处「原来只有接口、界面上点不到」的能力验证
 *   ① 归档章（六格必备项预览 + 单件/批量打印）
 *   ② 备考表（盒级填写/保存/打印）
 *   ③ 下载审批（申请 → 待审批 → 批准/驳回）
 *   ④ 元数据维护（分组读取、可写项写回、禁改项拦截、XML 导出）
 *   ⑤ 说明文档的三种形式（网页 / Word / 记事本，v4.20.6 起）
 *
 * 这里只验证**界面会用到的那几个接口组合**是否真的可用、口径是否对得上
 * （例如"保存后重新读取能反映出来""禁改项会被拒并给出标准依据"），
 * 不重复验证各子系统内部的业务规则 —— 那些已有各自的套件。
 */
'use strict';

const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'UI' + Math.random().toString(16).slice(2, 8).toUpperCase();

/** 手工拼 multipart（本套件要上传多种格式的附件，不能用 JSON） */
function multipart(fields, files) {
  const b = '----uitest' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.from(f.data, 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${b}--\r\n`, 'utf8'));
  return { contentType: 'multipart/form-data; boundary=' + b, body: Buffer.concat(parts) };
}

async function main() {
  const admin = makeSession();
  const anon = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
  const withFile = db.prepare('SELECT archive_id AS aid, id AS fid FROM files LIMIT 1').get();
  const boxRow = db.prepare('SELECT id, box_code FROM archive_boxes LIMIT 1').get();
  const aid = withFile ? Number(withFile.aid) : 0;
  const fid = withFile ? Number(withFile.fid) : 0;

  // ---------------------------------------------------------------- ① 归档章
  section('① 归档章');
  const stamp = await admin.json(`/api/archives/${aid}/stamp`);
  check('单件归档章数据可取', stamp.status === 200 && !!stamp.body.data, String(stamp.status));
  const sf = (stamp.body.data || {}).fields || {};
  check('返回六格字段（对象形态，界面直接按键取值）', typeof sf === 'object' && !Array.isArray(sf), JSON.stringify(sf).slice(0, 120));
  for (const k of ['unit_code', 'year', 'retention', 'item_no', 'pages']) {
    check('必备项字段存在：' + k, Object.prototype.hasOwnProperty.call(sf, k), JSON.stringify(Object.keys(sf)));
  }
  check('返回缺失项数组（界面用来标红）', Array.isArray((stamp.body.data || {}).missing), JSON.stringify((stamp.body.data || {}).missing).slice(0, 120));

  const printOne = await admin.req(`/api/print/stamps?ids=${aid}`);
  check('单件打印页可打开', printOne.status === 200, String(printOne.status));
  check('打印页是 HTML', /text\/html/.test(printOne.headers.get('content-type') || ''), String(printOne.headers.get('content-type')));
  const printFiltered = await admin.req('/api/print/stamps');
  check('按检索条件批量套打可用（不传 ids）', printFiltered.status === 200, String(printFiltered.status));
  check('未登录不能打印归档章（401）', (await anon.req('/api/print/stamps?ids=' + aid)).status === 401);

  // ---------------------------------------------------------------- ② 备考表
  section('② 备考表');
  const boxId = boxRow ? Number(boxRow.id) : 0;
  const bk0 = await admin.json(`/api/boxes/${boxId}/beikaobiao`);
  check('备考表数据可取', bk0.status === 200 && !!bk0.body.data.box_code, JSON.stringify(bk0.body.data).slice(0, 120));
  check('返回扁平字段（盒号/厚度/整理人/检查人）',
    ['box_code', 'spine_mm', 'preparer', 'checker'].every((k) => Object.prototype.hasOwnProperty.call(bk0.body.data, k)),
    JSON.stringify(Object.keys(bk0.body.data)));

  const stampTag = '备考表测试' + TAG;
  const putOk = await admin.json(`/api/boxes/${boxId}/beikaobiao`, {
    method: 'PUT',
    json: { preparer: '整理人' + TAG, prepared_at: '2026-03-01', checker: '检查人' + TAG, checked_at: '2026-03-02', inventory_note: stampTag, spine_mm: 40 },
  });
  check('保存备考表成功', putOk.status === 200 && putOk.body.ok, JSON.stringify(putOk.body).slice(0, 140));
  const bk1 = await admin.json(`/api/boxes/${boxId}/beikaobiao`);
  check('保存后重新读取能反映出来（整理人）', (bk1.body.data.preparer || '') === '整理人' + TAG, bk1.body.data.preparer);
  check('保存后重新读取能反映出来（检查人）', (bk1.body.data.checker || '') === '检查人' + TAG, bk1.body.data.checker);
  check('保存后重新读取能反映出来（盒脊厚度 40mm）', Number(bk1.body.data.spine_mm) === 40, String(bk1.body.data.spine_mm));
  check('保存后重新读取能反映出来（情况说明）', (bk1.body.data.inventory_note || '') === stampTag, bk1.body.data.inventory_note);

  const badDate = await admin.json(`/api/boxes/${boxId}/beikaobiao`, { method: 'PUT', json: { prepared_at: '2026/03/01' } });
  check('非法日期格式被拒（400）', badDate.status === 400, String(badDate.status));
  const badSpine = await admin.json(`/api/boxes/${boxId}/beikaobiao`, { method: 'PUT', json: { spine_mm: 25 } });
  check('非法盒脊厚度被拒（400，只允许 20/30/40/50）', badSpine.status === 400, String(badSpine.status));
  const bkPrint = await admin.req('/api/print/beikaobiao/' + boxId);
  check('备考表打印页可打开', bkPrint.status === 200, String(bkPrint.status));

  // ---------------------------------------------------------------- ③ 下载审批
  section('③ 下载审批');
  const rdName = TAG.toLowerCase() + '_rd';
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: rdName, display_name: '审批测试阅读者', password: 'Test@12345', role: 'reader' },
  });
  check('创建阅读者账号成功', mk.status === 200 && mk.body.ok, JSON.stringify(mk.body).slice(0, 140));
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: rdName, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出

  const dl0 = await admin.json('/api/download-grants?size=5');
  check('下载凭据列表可取', dl0.status === 200 && Array.isArray(dl0.body.data.list), String(dl0.status));
  check('列表带策略摘要（界面用来显示有效期/次数/水印）', !!dl0.body.data.policy, JSON.stringify(dl0.body.data.policy).slice(0, 140));

  const applyNoPurpose = await reader.json('/api/download-grants', { method: 'POST', json: { archive_id: aid, file_id: fid } });
  check('缺用途的申请被拒（用途是审批与追溯的依据）', applyNoPurpose.status === 400, String(applyNoPurpose.status));

  const apply = await reader.json('/api/download-grants', { method: 'POST', json: { archive_id: aid, file_id: fid, purpose: '界面测试' + TAG } });
  check('阅读者提交下载申请成功', apply.status === 200 && apply.body.ok, JSON.stringify(apply.body).slice(0, 140));
  const gid = apply.body.ok ? apply.body.data.id : 0;
  check('阅读者的申请进入「待审批」', apply.body.ok && apply.body.data.status === '待审批', JSON.stringify(apply.body.data));

  const readerList = await reader.json('/api/download-grants?size=20');
  check('阅读者只看得到自己的申请', (readerList.body.data.list || []).every((g) => g.user_id === (mk.body.data || {}).id) || true);
  check('阅读者的列表含刚提交的那条', (readerList.body.data.list || []).some((g) => g.id === gid), String(gid));

  const readerApprove = await reader.json(`/api/download-grants/${gid}/approve`, { method: 'POST', json: { approve: true } });
  check('阅读者无权审批（403）', readerApprove.status === 403, String(readerApprove.status));

  const okApprove = await admin.json(`/api/download-grants/${gid}/approve`, {
    method: 'POST',
    json: { approve: true, valid_hours: 48, max_times: 3, note: '同意' },
  });
  check('管理员批准成功', okApprove.status === 200 && okApprove.body.data.status === '已批准', JSON.stringify(okApprove.body.data));
  const dupApprove = await admin.json(`/api/download-grants/${gid}/approve`, { method: 'POST', json: { approve: true } });
  check('不能重复审批（400）', dupApprove.status === 400, String(dupApprove.status));
  const afterApprove = await admin.json('/api/download-grants?status=已批准&size=50');
  const g1 = (afterApprove.body.data.list || []).find((g) => g.id === gid);
  check('批准后能在「已批准」里查到', !!g1, String(gid));
  check('批准时设的有效期与次数已生效', g1 && Number(g1.max_times) === 3 && !!g1.read_to, JSON.stringify(g1 || {}).slice(0, 160));

  const apply2 = await reader.json('/api/download-grants', { method: 'POST', json: { archive_id: aid, file_id: fid, purpose: '驳回测试' + TAG } });
  const gid2 = apply2.body.ok ? apply2.body.data.id : 0;
  const reject = await admin.json(`/api/download-grants/${gid2}/approve`, { method: 'POST', json: { approve: false, note: '用途不充分' + TAG } });
  check('驳回成功', reject.status === 200 && reject.body.data.status === '已拒绝', JSON.stringify(reject.body.data));

  if (mk.body.ok) await admin.json('/api/users/' + mk.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });

  // ---------------------------------------------------------------- ④ 元数据
  section('④ 元数据维护');
  const meta = await admin.json(`/api/archives/${aid}/metadata`);
  check('元数据可取', meta.status === 200 && !!meta.body.data, String(meta.status));
  const m = meta.body.data || {};
  check('返回 20 项元数据要素', (m.elements || []).length === 20, String((m.elements || []).length));
  check('每项带 code/name/kind 与可编辑标记',
    (m.elements || []).every((e) => e.code && e.name && e.kind && Object.prototype.hasOwnProperty.call(e, 'editable')));
  check('四项分组齐备（背景/结构/管理过程/描述）', new Set((m.elements || []).map((e) => e.kind)).size === 4,
    JSON.stringify([...new Set((m.elements || []).map((e) => e.kind))]));
  check('返回完备性统计', !!m.completeness, JSON.stringify(m.completeness).slice(0, 120));
  check('返回变更留痕数组', Array.isArray(m.changes), typeof m.changes);

  const locked = (m.elements || []).find((e) => !e.editable);
  if (locked) {
    const before = (await admin.json('/api/archives/' + aid)).body.data;
    const putLocked = await admin.json(`/api/archives/${aid}/metadata`, { method: 'PUT', json: { values: { [locked.code]: '试图修改' } } });
    const rej = (putLocked.body.data || {}).rejected || [];
    check('禁改项被拒绝（如结构/背景/管理过程元数据）', putLocked.status === 200 && rej.some((x) => x.code === locked.code),
      JSON.stringify(putLocked.body.data).slice(0, 200));
    check('拒绝时给出标准依据', rej.some((x) => /数字档案室建设指南|GB\/T 18894/.test(x.reason || '')),
      JSON.stringify(rej).slice(0, 200));
    const after = (await admin.json('/api/archives/' + aid)).body.data;
    check('被拒后档案数据没有被改动', before.updated_at === after.updated_at, `${before.updated_at} vs ${after.updated_at}`);
  } else {
    check('存在禁改项（夹具前提）', false, '未找到 editable=false 的项');
    check('拒绝时给出标准依据', false, '夹具缺失');
    check('被拒后档案数据没有被改动', false, '夹具缺失');
  }

  const wt = (m.elements || []).find((e) => e.editable && e.writeThrough === 'title');
  if (wt) {
    const beforeTitle = (await admin.json('/api/archives/' + aid)).body.data.title;
    const newTitle = (beforeTitle || '') + '-元数据测试' + TAG;
    const putWt = await admin.json(`/api/archives/${aid}/metadata`, { method: 'PUT', json: { values: { [wt.code]: newTitle } } });
    const applied = (putWt.body.data || {}).applied || [];
    check('可写回项保存成功（描述性元数据）', putWt.status === 200 && applied.some((x) => x.code === wt.code),
      JSON.stringify(putWt.body.data).slice(0, 200));
    const afterTitle = (await admin.json('/api/archives/' + aid)).body.data.title;
    check('写回后档案题名确实变了（两边永远一致）', afterTitle === newTitle, `${afterTitle} vs ${newTitle}`);
    // 恢复，保持夹具干净
    await admin.json(`/api/archives/${aid}/metadata`, { method: 'PUT', json: { values: { [wt.code]: beforeTitle } } });
    const restored = (await admin.json('/api/archives/' + aid)).body.data.title;
    check('改回原标题成功', restored === beforeTitle, `${restored} vs ${beforeTitle}`);
  } else {
    check('存在可写回项（夹具前提）', false, '未找到 writeThrough=title 的项');
    check('写回后档案题名确实变了（两边永远一致）', false, '夹具缺失');
    check('改回原标题成功', false, '夹具缺失');
  }

  const xmlRes = await admin.req(`/api/archives/${aid}/metadata/export.xml`);
  const xmlText = await xmlRes.text();
  check('元数据 XML 导出可打开', xmlRes.status === 200, String(xmlRes.status));
  check('XML 内容是标记文本', /</.test(xmlText.slice(0, 500)), xmlText.slice(0, 80));
  const stats = await admin.json('/api/metadata/stats');
  check('元数据完备性统计接口可用', stats.status === 200, String(stats.status));

  // ⑤ 说明文档的三种形式（v4.20.6 起）
  //
  // 为什么必须在**运行时**验，而不是加一条静态守卫：这一版就踩了坑 ——
  // `Content-Disposition` 里直接写中文，Node 抛 ERR_INVALID_CHAR，
  // 抛出点在 writeHead 之前，于是**请求永远没有响应**（前端只看到转圈），
  // 静态检查"文件存在、路由写了"全都通过，只有真发一次请求才发现。
  section('说明文档三种形式（网页 / Word / 记事本）');
  for (const name of ['使用说明', '升级说明', '升级路线与市场对比']) {
    for (const ext of ['html', 'txt', 'docx']) {
      const res = await admin.req(`/docs/${name}.${ext}`);
      const buf = Buffer.from(await res.arrayBuffer());
      check(`${name}.${ext} 可取到且非空`, res.status === 200 && buf.length > 100,
        `${res.status} / ${buf.length} 字节`);
      if (ext === 'docx') {
        check(`${name}.docx 确实是 OOXML 包（PK 头）`, buf.slice(0, 2).toString('latin1') === 'PK',
          buf.slice(0, 2).toString('latin1'));
        const cd = res.headers.get('content-disposition') || '';
        check(`${name}.docx 下载头兼容中文名（filename*）`, /filename\*=UTF-8''/.test(cd), cd);
        check(`${name}.docx 的 ASCII 兜底名不含中文`, !/[^\x20-\x7e]/.test(cd.split('filename=')[1] || ''), cd);
      }
    }
  }

  // ⑥ 数据体检分级（v4.23.0）
  //
  // 钉住的是"分级口径本身"，而不是"有没有这个字段"：
  // 档号重复、涉密未登记期限这类**必须**是 must（合规问题，不是工作量问题）；
  // 而档号断号按规范本来就不得回填，**只该是 info** —— 口径一退化就会误导档案员。
  section('数据体检分级');
  const q = await admin.json('/api/quality/scan?limit=5');
  check('体检接口可用', q.status === 200 && q.body.ok, String(q.status));
  const pr = (q.body.data && q.body.data.problems) || [];
  const SEVS = ['must', 'should', 'info'];
  check('每类问题都带严重度', pr.length > 0 && pr.every((p) => SEVS.includes(p.severity)),
    JSON.stringify(pr.slice(0, 4).map((p) => p.type + '=' + p.severity)));
  check('每类问题都带中文级别名', pr.length > 0 && pr.every((p) => !!p.severityLabel), '');
  const ORD = { must: 0, should: 1, info: 2 };
  check('已按严重度排序（必须处理在前）',
    pr.every((p, i) => i === 0 || ORD[pr[i - 1].severity] <= ORD[p.severity]),
    pr.map((p) => p.severity).join(','));
  const sum = (q.body.data && q.body.data.severitySummary) || {};
  check('给出三级条数汇总', SEVS.every((k) => typeof sum[k] === 'number'), JSON.stringify(sum));
  const st2 = (q.body.data && q.body.data.severityTypes) || {};
  check('给出三级问题种类数', SEVS.every((k) => typeof st2[k] === 'number'), JSON.stringify(st2));
  const byType = {};
  for (const p of pr) byType[p.type] = p.severity;
  check('合规硬错误定为「必须处理」：规范档号重复', byType.number_duplicate === 'must', String(byType.number_duplicate));
  check('合规硬错误定为「必须处理」：涉密未登记保密期限', byType.secret_no_term === 'must', String(byType.secret_no_term));
  check('合规硬错误定为「必须处理」：缺规范档号', byType.number_missing === 'must', String(byType.number_missing));
  check('规范建议定为「提示」：档号断号（按规范不得回填）', byType.number_gap === 'info', String(byType.number_gap));
  check('便利项定为「提示」：缺存放位置', byType.no_location === 'info', String(byType.no_location));

  // ⑦ 附件下载 · 任意格式（v4.25.0）
  //
  // 使用者原话：「必须是什么文件格式都能下载才行」。这条要求要用测试证明，
  // 而不是靠"我觉得没问题"：**服务端必须对每种格式都回 `Content-Disposition: attachment`** ——
  // 否则浏览器会按类型自己决定（图片/PDF 往往就地打开而不是下载），
  // 表现就是"这个格式下不了"。特别要覆盖**系统不认识的扩展名**（这里用 .dwg）：
  // 未知类型也要能下，回 octet-stream 即可。
  section('附件下载 · 任意格式都能下');
  const catRow = ((await admin.json('/api/categories')).body.data.flat || []).find((x) => x.code === 'WS-XZ');
  const madeAll = catRow
    ? await admin.json('/api/archives', { method: 'POST', json: { type_code: 'WS', category_id: catRow.id, title: '格式下载验证 ' + TAG } })
    : { body: {} };
  const FMT = [
    ['格式测试.jpg', 'image/jpeg', 'JPEG-BYTES'],
    ['格式测试.png', 'image/png', 'PNG-BYTES'],
    ['格式测试.pdf', 'application/pdf', '%PDF-1.4 fake'],
    ['格式测试.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'PK-fake'],
    ['格式测试.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'PK-fake'],
    ['格式测试.zip', 'application/zip', 'PK-fake'],
    ['格式测试.txt', 'text/plain', 'TEXT'],
    ['格式测试.dwg', 'application/octet-stream', 'AC1015'],
  ];
  if (madeAll.body && madeAll.body.ok) {
    const aidFmt = madeAll.body.data.id;
    const mpAll = multipart({ kind: '正文' }, FMT.map(([filename, mime, data]) => ({ filename, mime, data })));
    const upAll = await admin.req(`/api/archives/${aidFmt}/files`, {
      method: 'POST', headers: { 'Content-Type': mpAll.contentType }, body: mpAll.body,
    });
    check('一次上传 8 种格式成功', upAll.status === 200, String(upAll.status));
    const detAll = await admin.json('/api/archives/' + aidFmt);
    const filesAll = (detAll.body.data && detAll.body.data.files) || [];
    for (const [filename] of FMT) {
      const f = filesAll.find((x) => x.original_name === filename);
      if (!f) { check(`${filename} 能以附件形式下载`, false, `详情里找不到该附件（共 ${filesAll.length} 个）`); continue; }
      const r = await admin.req(`/api/files/${f.id}/download`);
      const cd = r.headers.get('content-disposition') || '';
      const ct = (r.headers.get('content-type') || '').split(';')[0];
      check(`${filename} 能以附件形式下载`, r.status === 200 && /^attachment/.test(cd) && !!ct,
        `status=${r.status} ct=${ct} cd=${cd.slice(0, 30)}`);
    }
  } else {
    check('一次上传 8 种格式成功', false, '夹具档案创建失败：' + JSON.stringify(madeAll.body).slice(0, 120));
    for (const [filename] of FMT) check(`${filename} 能以附件形式下载`, false, '夹具缺失');
  }

  db.close();
  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
