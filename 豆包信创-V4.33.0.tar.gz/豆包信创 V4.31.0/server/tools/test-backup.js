/**
 * 备份合规与存储状况监控回归测试
 *
 * 用法：node server/tools/test-backup.js [http://127.0.0.1:8796] [数据目录]
 *
 * 覆盖（《电子档案管理办法》第二十六条/第二十七条；档办发〔2017〕3号第二十二/二十四条；
 *       DA/T 92—2022 §9.2）：
 *   1. 介质登记（类型/位置/状态）
 *   2. 制作备份并**登记**（在线/离线/异地，落到磁盘、登记摘要与日志链结论）
 *   3. 备份合规体检：套数、介质种类、离线、异地、检测超期
 *   4. 备份校验：**真实篡改备份文件**后能被查出
 *   5. 保管状况检测：空间、数据库完整性、审计链、附件抽样可读性、介质状态、非授权访问
 *   6. 存储状况告警（含"空间偏紧"与"检测超期"两级）
 *   7. 权限：仅系统管理员/管理员可做备份与介质管理
 *
 * 脚本结束时清理测试数据（含写出的备份文件），可重复运行。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  return { req, json };
}

const TAG = 'BK' + Math.random().toString(16).slice(2, 8).toUpperCase();
const written = [];   // 本次测试写出的备份文件，结束时删掉

async function main() {
  const admin = makeSession();
  const created = { users: [], media: [], backups: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);
  const s0 = (await admin.json('/api/settings')).body.data.settings;
  const keep = (k) => s0[k];

  // ---------- 1. 介质登记 ----------
  section('备份介质登记');
  const m1 = await admin.json('/api/backup/media', {
    method: 'POST',
    json: { medium_no: `${TAG}-DISK1`, type: '移动硬盘', location: '在线', label: '机房移动硬盘', capacity_bytes: 2 * 1024 ** 3 },
  });
  check('登记在线移动硬盘', m1.body.ok, JSON.stringify(m1.body).slice(0, 140));
  if (m1.body.ok) created.media.push(m1.body.data.id);

  const m2 = await admin.json('/api/backup/media', {
    method: 'POST',
    json: { medium_no: `${TAG}-DVD1`, type: '光盘', location: '同城离线', label: '档案室光盘柜' },
  });
  check('登记离线光盘介质', m2.body.ok);
  if (m2.body.ok) created.media.push(m2.body.data.id);

  const m3 = await admin.json('/api/backup/media', {
    method: 'POST',
    json: { medium_no: `${TAG}-OFF1`, type: '磁盘', location: '异地', label: '异地机房' },
  });
  check('登记异地介质', m3.body.ok);
  if (m3.body.ok) created.media.push(m3.body.data.id);

  check('介质编号重复被拒绝',
    (await admin.json('/api/backup/media', { method: 'POST', json: { medium_no: `${TAG}-DISK1`, type: '磁盘' } })).status === 400);

  const mediaList = await admin.json('/api/backup/media');
  check('介质台账可查询', mediaList.status === 200 && (mediaList.body.data.list || []).length >= 3,
    String((mediaList.body.data.list || []).length));
  check('返回可选的介质类型与存放位置',
    Array.isArray(mediaList.body.data.types) && mediaList.body.data.types.includes('光盘')
    && mediaList.body.data.locations.includes('异地'),
    JSON.stringify([mediaList.body.data.types, mediaList.body.data.locations]));
  check('每种介质统计了备份份数',
    (mediaList.body.data.list || []).every((m) => typeof m.backup_count === 'number'));

  const badMedia = await admin.json('/api/backup/media', {
    method: 'POST', json: { medium_no: `${TAG}-BAD`, type: '磁盘', location: '在线', condition: '不可用' },
  });
  if (badMedia.body.ok) created.media.push(badMedia.body.data.id);
  check('可登记状态为不可用的介质', badMedia.body.ok);
  // 注意：这个"不可用介质"会在体检中产生告警，所以先做体检之后的正向断言，
  // 再让它参与负向断言（否则"合规"永远判不出来）。

  // ---------- 2. 制作备份并登记 ----------
  section('制作备份并登记');
  const destDir = path.join(DATA_DIR, `.test-backups-${TAG}`);
  const run1 = await admin.json('/api/backup/run', {
    method: 'POST', json: { target_type: '在线', medium_id: created.media[0], dest_dir: destDir, note: '日常在线备份' },
  });
  check('制作在线备份成功', run1.body.ok, JSON.stringify(run1.body).slice(0, 180));
  if (run1.body.ok) {
    created.backups.push(run1.body.data.id);
    written.push(run1.body.data.dest_path);
  }
  check('返回备份单号', /^BZ\d{8}-\d{3}$/.test(run1.body.data.backup_no || ''), String(run1.body.data.backup_no));
  check('备份文件已落盘', fs.existsSync(run1.body.data.dest_path), String(run1.body.data.dest_path));
  check('记录了文件摘要', /^[0-9a-f]{64}$/.test(run1.body.data.sha256 || ''), String(run1.body.data.sha256).slice(0, 16));
  check('记录了日志链校验结论', run1.body.data.chain_ok === true, String(run1.body.data.chain_ok));
  check('备份包大小合理（> 1KB）', run1.body.data.size_bytes > 1024, String(run1.body.data.size_bytes));

  const run2 = await admin.json('/api/backup/run', {
    method: 'POST', json: { target_type: '离线', medium_id: created.media[1], dest_dir: destDir, note: '离线光盘备份' },
  });
  if (run2.body.ok) { created.backups.push(run2.body.data.id); written.push(run2.body.data.dest_path); }
  check('制作离线备份成功', run2.body.ok, JSON.stringify(run2.body).slice(0, 160));

  const run3 = await admin.json('/api/backup/run', {
    method: 'POST', json: { target_type: '异地', medium_id: created.media[2], dest_dir: destDir, note: '异地备份' },
  });
  if (run3.body.ok) { created.backups.push(run3.body.data.id); written.push(run3.body.data.dest_path); }
  check('制作异地备份成功', run3.body.ok, JSON.stringify(run3.body).slice(0, 160));

  check('状态不可用的介质不能用于备份',
    (await admin.json('/api/backup/run', {
      method: 'POST', json: { target_type: '在线', medium_id: created.media[3], dest_dir: destDir },
    })).status === 400);

  const bkList = await admin.json('/api/backups');
  check('备份登记列表可查询', bkList.status === 200 && (bkList.body.data.list || []).length >= 3,
    String((bkList.body.data.list || []).length));
  check('登记项含目标类型与介质',
    (bkList.body.data.list || []).some((b) => b.target_type === '异地' && b.medium_no),
    JSON.stringify((bkList.body.data.list || []).map((b) => [b.target_type, b.medium_no]).slice(0, 4)));

  // ---------- 3. 合规体检 ----------
  section('备份合规体检（三套两介质）');
  // 先让条件齐备再做正向断言：把那个"不可用介质"暂置良好，并先完成一次保管状况检测
  // （否则体检必然因"从未检测"和"介质异常"判为不合规 —— 那是对的，只是顺序不该这样）。
  await admin.json(`/api/backup/media/${created.media[3]}`, { method: 'PUT', json: { condition: '良好' } });
  const preCheck = await admin.json('/api/storage/check', { method: 'POST', json: { sample: 5 } });
  check('预先完成一次保管状况检测', preCheck.status === 200, JSON.stringify(preCheck.body).slice(0, 140));

  const st = await admin.json('/api/backup/status');
  const sd = st.body.data || {};
  check('体检接口可用', st.status === 200 && !!sd.counts, JSON.stringify(sd).slice(0, 160));
  check('返回标准要求（至少三套、至少两种介质）',
    sd.requirement && sd.requirement.requiredCopies === 3 && sd.requirement.requiredMediaTypes === 2,
    JSON.stringify(sd.requirement || {}).slice(0, 160));
  check('体检引用标准依据',
    /电子档案管理办法/.test((sd.requirement || {}).basis || ''), String((sd.requirement || {}).basis));
  check('统计了在线/离线/异地套数',
    typeof sd.counts.online === 'number' && typeof sd.counts.offline === 'number' && typeof sd.counts.offsite === 'number',
    JSON.stringify(sd.counts));
  check('识别出至少两种介质在用', (sd.counts.mediaTypes || []).length >= 2,
    JSON.stringify(sd.counts.mediaTypes));
  check('三套齐备后判定为合规', sd.compliant === true, JSON.stringify(sd.warnings));
  check('列出仍在使用的备份', Array.isArray(sd.usableBackups) && sd.usableBackups.length >= 3,
    String((sd.usableBackups || []).length));

  // 再把介质置回不可用，供后面的负向断言使用
  await admin.json(`/api/backup/media/${created.media[3]}`, { method: 'PUT', json: { condition: '不可用' } });

  // 删掉离线与异地那两份 → 应当报出"套数不足/无离线"
  for (const p of written.slice(1)) { try { fs.unlinkSync(p); } catch (_) { /* ignore */ } }
  const st2 = await admin.json('/api/backup/status');
  check('文件缺失的备份不计入可用套数', st2.body.data.counts.usable <= 1, String(st2.body.data.counts.usable));
  check('套数不足时给出告警', st2.body.data.warnings.some((w) => /至少 3 套|完整备份只有/.test(w)),
    JSON.stringify(st2.body.data.warnings));
  check('无离线备份时给出告警', st2.body.data.warnings.some((w) => /离线/.test(w)),
    JSON.stringify(st2.body.data.warnings));
  check('判定为不合规', st2.body.data.compliant === false);

  // ---------- 4. 备份校验（真实篡改文件） ----------
  section('备份校验（真实篡改）');
  const bkId = run1.body.data.id;
  const targetPath = run1.body.data.dest_path;
  const v0 = await admin.json(`/api/backups/${bkId}/verify`, { method: 'POST' });
  check('未篡改时校验合格', v0.body.data.ok === true, JSON.stringify(v0.body.data).slice(0, 200));
  check('校验结论文本以「合格」开头', /^合格/.test(v0.body.data.result || ''), String(v0.body.data.result));
  check('校验后回写了校验结果', !!v0.body.data.result, String(v0.body.data.result));

  fs.appendFileSync(targetPath, Buffer.from('X'));
  const v1 = await admin.json(`/api/backups/${bkId}/verify`, { method: 'POST' });
  check('篡改备份文件后校验不合格', v1.body.data.ok === false, JSON.stringify(v1.body.data).slice(0, 200));
  check('结论文本以「不合格」开头', /^不合格/.test(v1.body.data.result || ''), String(v1.body.data.result));
  check('指出文件大小不符', (v1.body.data.problems || []).some((p) => /大小与登记不符/.test(p)),
    JSON.stringify(v1.body.data.problems));
  check('指出摘要不符', (v1.body.data.problems || []).some((p) => /摘要与登记不符/.test(p)),
    JSON.stringify(v1.body.data.problems));

  // 还原
  fs.unlinkSync(targetPath);
  fs.writeFileSync(targetPath, Buffer.alloc(Number(run1.body.data.size_bytes), 0));
  const v2 = await admin.json(`/api/backups/${bkId}/verify`, { method: 'POST' });
  check('把文件换回同样大小但内容不同的文件 → 仍能查出摘要不符',
    v2.body.data.ok === false && (v2.body.data.problems || []).some((p) => /摘要/.test(p)),
    JSON.stringify(v2.body.data.problems));

  fs.unlinkSync(targetPath);
  const v3 = await admin.json(`/api/backups/${bkId}/verify`, { method: 'POST' });
  check('文件被删除后校验不合格', v3.body.data.ok === false
    && (v3.body.data.problems || []).some((p) => /不存在/.test(p)), JSON.stringify(v3.body.data.problems));

  // ---------- 5. 保管状况检测 ----------
  section('保管状况检测');
  const sc = await admin.json('/api/storage/check', { method: 'POST', json: { sample: 10 } });
  const sck = sc.body.data || {};
  check('检测可执行', sc.status === 200 && !!sck.check_no, JSON.stringify(sck).slice(0, 160));
  check('检测单号格式正确', /^BJ\d{8}-\d{3}$/.test(sck.check_no || ''), String(sck.check_no));
  check('① 检查了介质空间', typeof sck.free_bytes === 'number' && typeof sck.total_bytes === 'number',
    JSON.stringify([sck.free_bytes, sck.total_bytes]));
  check('② 数据库完整性检查通过（PRAGMA integrity_check）', sck.db_integrity === true, String(sck.db_integrity));
  check('③ 审计日志链完整', sck.chain_ok === true, String(sck.chain_ok));
  check('④ 做了附件可读性抽样（fixity）', typeof sck.fixity_checked === 'number', String(sck.fixity_checked));
  check('抽样未发现失败', sck.fixity_failed === 0, JSON.stringify(sck.bad_files || []));
  check('⑤ 检查了介质状态', typeof sck.media_total === 'number' && typeof sck.media_bad === 'number',
    JSON.stringify([sck.media_total, sck.media_bad]));
  check('⑥ 监控了非授权访问尝试', typeof sck.denied_recent === 'number', String(sck.denied_recent));
  check('发现介质不可用告警', (sck.warnings || []).some((w) => w.type === 'media'),
    JSON.stringify((sck.warnings || []).map((w) => w.label)));
  check('给出结论文本', typeof sck.conclusion === 'string' && sck.conclusion.length > 0, sck.conclusion);

  // fixity 抽样必须**轮转**：原先按 id DESC 取最新 N 件，等于永远只校验最新附件，
  // 而长期保存真正要防的是老档案的比特腐坏 —— 那些档案可能十年都排不到一次校验。
  section('fixity 抽样轮转（覆盖全量，而不是只查最新附件）');
  {
    const { DatabaseSync } = require('node:sqlite');
    const dr = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
    const num = (sql) => {
      const r = dr.prepare(sql).get();
      return Number((r && (r.c !== undefined ? r.c : Object.values(r)[0])) || 0);
    };
    const setCursor = (v) => dr.prepare(
      "INSERT INTO meta(key,value) VALUES('storage.fixity_cursor',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    ).run(String(v));
    const getCursor = () => Number((dr.prepare("SELECT value FROM meta WHERE key='storage.fixity_cursor'").get() || {}).value || 0);
    const totalFiles = num('SELECT COUNT(*) AS c FROM files');
    const maxId = num('SELECT MAX(id) AS c FROM files');
    check('演示数据里有多个附件可供轮转', totalFiles >= 3, 'files=' + totalFiles);

    setCursor(0);
    const r1 = await admin.json('/api/storage/check', { method: 'POST', json: { sample: 1 } });
    const c1 = getCursor();
    check('第一轮把游标推过首个附件', c1 > 0, 'cursor=' + c1);
    const r2 = await admin.json('/api/storage/check', { method: 'POST', json: { sample: 1 } });
    const c2 = getCursor();
    check('第二轮游标继续前进（轮到别的附件）', c2 > c1, `c1=${c1} c2=${c2}`);
    check('每轮确实校验了 1 件',
      Number((r1.body.data || {}).fixity_checked) === 1 && Number((r2.body.data || {}).fixity_checked) === 1,
      JSON.stringify([(r1.body.data || {}).fixity_checked, (r2.body.data || {}).fixity_checked]));

    setCursor(maxId);
    const r3 = await admin.json('/api/storage/check', { method: 'POST', json: { sample: 2 } });
    check('走到末尾后绕回开头（游标归零）', getCursor() === 0, 'cursor=' + getCursor());
    check('绕回时仍真的校验了附件（不是空转）', Number((r3.body.data || {}).fixity_checked) >= 1,
      String((r3.body.data || {}).fixity_checked));
    check('返回体带全量附件数（界面可显示覆盖率）', Number((r3.body.data || {}).fixity_total) === totalFiles,
      JSON.stringify([(r3.body.data || {}).fixity_total, totalFiles]));

    // 本块为了验证轮转做了 3 次检测，会写出 3 条新的检测记录。
    // 后面的「检测超期」用例是按**最近一次检测时间**造超期的，这些新记录会把它冲掉，
    // 所以要**用完即清**，保持夹具干净（这是本块唯一对外部状态的副作用）。
    const dclean = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
    for (const r of [r1, r2, r3]) {
      const no = (r.body.data || {}).check_no || '';
      if (no) dclean.prepare('DELETE FROM storage_checks WHERE check_no=?').run(no);
    }
    dclean.close();
    dr.close();
  }

  const ss = await admin.json('/api/storage/status');
  check('存储状况概览可查询', ss.status === 200 && typeof ss.body.data.free_ratio === 'number',
    JSON.stringify(ss.body.data).slice(0, 160));
  check('返回告警列表', Array.isArray(ss.body.data.alarms), JSON.stringify((ss.body.data.alarms || []).map((a) => a.label)));
  check('返回检测历史', Array.isArray(ss.body.data.history) && ss.body.data.history.length >= 1,
    String((ss.body.data.history || []).length));
  check('记录了最近一次检测距今天数', typeof ss.body.data.last_check_days === 'number',
    String(ss.body.data.last_check_days));

  // 检测超期告警：把周期改为 1 天，等 1 秒即可不满足（用直接改库造"超期"更可控）
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
  db.prepare("UPDATE storage_checks SET created_at=? WHERE check_no=?").run('2020-01-01T00:00:00.000Z', sck.check_no);
  db.close();
  const ss2 = await admin.json('/api/storage/status');
  check('检测超期时给出告警', (ss2.body.data.alarms || []).some((a) => /超期/.test(a.label)),
    JSON.stringify((ss2.body.data.alarms || []).map((a) => a.label)));
  check('超期告警为 warn 级', (ss2.body.data.alarms || []).some((a) => /超期/.test(a.label) && a.level === 'warn'));

  // 体检也应报出检测超期
  const st3 = await admin.json('/api/backup/status');
  check('备份体检同样报出检测超期', (st3.body.data.warnings || []).some((w) => /检测/.test(w)),
    JSON.stringify(st3.body.data.warnings));

  // ---------- 6. 权限 ----------
  section('权限隔离');
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_clk`, display_name: TAG, password: 'Test@12345', role: 'clerk' },
  });
  if (mk.body.ok) created.users.push(mk.body.data.id);
  const clk = makeSession();
  await clk.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_clk`, password: 'Test@12345' } });
  await clk.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  check('档案员不能制作备份', (await clk.json('/api/backup/run', { method: 'POST', json: {} })).status === 403);
  check('档案员不能查看备份体检', (await clk.json('/api/backup/status')).status === 403);
  check('档案员不能登记介质',
    (await clk.json('/api/backup/media', { method: 'POST', json: { medium_no: 'X', type: '磁盘' } })).status === 403);
  check('档案员不能执行保管状况检测', (await clk.json('/api/storage/check', { method: 'POST', json: {} })).status === 403);
  check('档案员不能下载全库备份', (await clk.json('/api/backup/download')).status === 403);

  // ---------- 清理 ----------
  section('清理');
  for (const p of written) { try { fs.unlinkSync(p); } catch (_) { /* ignore */ } }
  try { fs.rmSync(destDir, { recursive: true, force: true }); } catch (_) { /* ignore */ }
  check('测试备份文件已清理', written.every((p) => !fs.existsSync(p)));
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('清理完成', true);

  console.log(`\n备份合规与存储监控回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n备份测试异常终止：', e); process.exit(1); });
