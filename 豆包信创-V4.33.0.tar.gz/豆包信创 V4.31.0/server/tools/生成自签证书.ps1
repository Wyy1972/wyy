# 生成自签 HTTPS 证书（Windows / PowerShell）
#
# 用途：内网部署时让「口令与令牌不明文过网」这条能落地 —— 等保测评里
#      "鉴别信息传输未加密"是必查项，而内网单位往往拿不到公网 CA 证书。
#      自签证书浏览器会提示"不受信任"，但传输确实是加密的，内网可接受；
#      正式对外提供服务请换成正规 CA 证书（把 server.pfx / server.crt 换掉即可）。
#
# 用法（在任意目录执行）：
#   powershell -ExecutionPolicy Bypass -File "server\tools\生成自签证书.ps1"
#   指定数据目录：
#   ... -File "server\tools\生成自签证书.ps1" -OutDir "D:\档案数据\tls"
#
# 产物（默认写到 <软件目录>\data\tls\）：
#   server.pfx        证书+私钥（服务端自动识别，无需再装 openssl）
#   server.pfx.pass   PFX 口令（服务端自动读取）
#
# 说明：
#   - 证书有效期 5 年，含 localhost、本机名与全部本机 IPv4，手机/局域网访问不会名字不匹配
#   - 只导出到当前用户的证书存储，随后立即从存储中删除，不污染系统证书列表
#   - 服务端启动时若看到 data\tls\server.pfx 会自动启用 HTTPS，启动横幅里会写明

param(
  [string]$OutDir = "",
  [string[]]$DnsName = @(),
  [string]$Pass = ""
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if (-not $OutDir) { $OutDir = Join-Path $root 'data\tls' }
$OutDir = [System.IO.Path]::GetFullPath($OutDir)
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

if (-not $Pass) {
  $bytes = New-Object byte[] 24
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $Pass = ([Convert]::ToBase64String($bytes) -replace '[^A-Za-z0-9]', '').Substring(0, 20)
}

$names = New-Object System.Collections.Generic.List[string]
$names.Add('localhost')
$names.Add($env:COMPUTERNAME)
if ($env:USERDNSDOMAIN) { $names.Add("$($env:COMPUTERNAME).$($env:USERDNSDOMAIN)") }
foreach ($n in $DnsName) { if ($n -and -not $names.Contains($n)) { $names.Add($n) } }
try {
  Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
    Where-Object { $_.IPAddress -notlike '127.*' } |
    ForEach-Object { if (-not $names.Contains($_.IPAddress)) { $names.Add($_.IPAddress) } }
} catch { }

Write-Host "证书名称：$($names -join ', ')"
Write-Host "输出目录：$OutDir"

$cert = New-SelfSignedCertificate `
  -DnsName $names.ToArray() `
  -CertStoreLocation 'Cert:\CurrentUser\My' `
  -NotAfter (Get-Date).AddYears(5) `
  -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm sha256 `
  -KeyExportPolicy Exportable `
  -Subject "CN=豆包信创档案管理系统"

$pfxPath = Join-Path $OutDir 'server.pfx'
$passPath = Join-Path $OutDir 'server.pfx.pass'
$sec = ConvertTo-SecureString -String $Pass -Force -AsPlainText
Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $sec | Out-Null
Set-Content -LiteralPath $passPath -Value $Pass -Encoding ascii -NoNewline

# 从个人证书存储里清掉，避免以后误选
try { Remove-Item -LiteralPath ("Cert:\CurrentUser\My\" + $cert.Thumbprint) -Force } catch { }

Write-Host ''
Write-Host '已生成：'
Write-Host "  $pfxPath"
Write-Host "  $passPath"
Write-Host ''
Write-Host '下一步：重启服务即可。启动横幅出现「传输加密：已启用 HTTPS」即生效。'
Write-Host '浏览器首次访问会提示"证书不受信任"，选择"继续访问"即可（内网自签的正常现象）。'
