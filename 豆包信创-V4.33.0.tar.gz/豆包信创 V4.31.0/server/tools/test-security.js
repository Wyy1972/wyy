/**
 * 安全与合规回归测试：密级访问控制、权限隔离、三员分立
 *
 * 用法：node server/tools/test-security.js [http://127.0.0.1:8796]
 *
 * 覆盖范围（对应 v4 安全版本新增能力）：
 *   1. 密级访问控制：列表 / 详情 / 附件下载 / 导出 / 正文检索 / 打印 / 借阅 / 批量修改
 *   2. 越权响应不泄露存在性（返回 404 而非 403）
 *   3. 权限修复：普通用户不能修改、删除档案
 *   4. 三员分立：角色职责隔离（系统管理员建号、安全保密员定密、审计员只审计）
 *   5. 密级上限可调整（含 secadmin 专属权限）
 *   6. 合规状态接口
 *
 * 依据：《电子档案管理系统基本功能规定》（档办发〔2017〕3号）第四十一条；
 *       GB/T 18894—2016 §5.2.4/§5.4；DA/T 92—2022 §9.1.3。
 *
 * 脚本结束时自动清理自己创建的账号与档案，可重复运行。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

// ---------------------------------------------------------------- HTTP 会话

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function text(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text() };
  }
  return { req, json, text };
}

function multipart(files, fields = {}) {
  const boundary = '----sectest' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

/** 从分类树里取出第一个分类 id */
function firstId(node, out = []) {
  if (!node || typeof node !== 'object') return out;
  if (Array.isArray(node)) { for (const n of node) firstId(n, out); return out; }
  if (typeof node.id === 'number') out.push(node.id);
  for (const v of Object.values(node)) if (v && typeof v === 'object') firstId(v, out);
  return out;
}

// ---------------------------------------------------------------- 主流程

const TAG = 'SEC' + Math.random().toString(16).slice(2, 8).toUpperCase();
const PW = 'Test@12345';
const PW2 = 'Archive@2026x';   // 首改后的口令（见 sessionFor）

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [], boxes: [], checks: [] };

  // ---------- 准备 ----------
  section('准备：登录与夹具');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, JSON.stringify(login.body).slice(0, 120));
  if (!login.body.ok) { console.error('无法继续：管理员登录失败'); process.exit(1); }

  const cats = await admin.json('/api/categories');
  const catId = firstId(cats.body.data)[0];
  check('取到一个可用分类 id', typeof catId === 'number', String(catId));

  /** 建一份档案 */
  async function makeArchive(secret, title) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: {
        type_code: 'WS', category_id: catId, title: `${TAG} ${title}`, secret_level: secret,
        retention: '定期10年', year: '2026', archive_date: '2026-01-01',
      },
    });
    if (r.body.ok) created.archives.push(r.body.data.id);
    return r;
  }

  const aPublic = await makeArchive('公开', '公开件');
  const aInner = await makeArchive('内部', '内部件');
  const aSecret = await makeArchive('秘密', '秘密件');
  check('创建公开档案', aPublic.body.ok, JSON.stringify(aPublic.body).slice(0, 120));
  check('创建内部档案', aInner.body.ok, JSON.stringify(aInner.body).slice(0, 120));
  check('创建秘密档案', aSecret.body.ok, JSON.stringify(aSecret.body).slice(0, 120));

  const idPublic = aPublic.body.ok ? aPublic.body.data.id : 0;
  const idInner = aInner.body.ok ? aInner.body.data.id : 0;
  const idSecret = aSecret.body.ok ? aSecret.body.data.id : 0;
  const codeSecret = aSecret.body.ok ? aSecret.body.data.archive_code : '';

  /** 建账号 */
  async function makeUser(username, role, clearance) {
    const payload = { username, display_name: username, password: PW, role };
    if (clearance) payload.clearance = clearance;
    const r = await admin.json('/api/users', { method: 'POST', json: payload });
    if (r.body.ok) created.users.push(r.body.data.id);
    return r;
  }

  const uLow = await makeUser(`${TAG.toLowerCase()}_low`, 'reader', '内部');
  const uHigh = await makeUser(`${TAG.toLowerCase()}_high`, 'reader', '机密');
  const uAuditor = await makeUser(`${TAG.toLowerCase()}_auditor`, 'auditor', '公开');
  const uSys = await makeUser(`${TAG.toLowerCase()}_sys`, 'sysadmin', '机密');
  const uSec = await makeUser(`${TAG.toLowerCase()}_sec`, 'secadmin', '机密');
  const uClerkPub = await makeUser(`${TAG.toLowerCase()}_clerk`, 'clerk', '公开');
  check('创建测试账号（reader/auditor/sysadmin/secadmin/clerk）',
    [uLow, uHigh, uAuditor, uSys, uSec, uClerkPub].every((r) => r.body.ok),
    [uLow, uHigh, uAuditor, uSys, uSec, uClerkPub].map((r) => r.status).join(','));

  /** 登录一个会话 */
  async function sessionFor(username) {
    const s = makeSession();
    let r = await s.json('/api/login', { method: 'POST', json: { username, password: PW } });
    if (r.body.ok) {
      // v4.30.8 起新账号强制首改（must_change=1），业务接口一律 403。
      // 补这一步走真人的路径；本套件同一账号会被反复登录，所以已经改过的口令要再试一次。
      await s.json('/api/me/password', { method: 'POST', json: { oldPassword: PW, newPassword: PW2 } });
      return s;
    }
    const s2 = makeSession();
    r = await s2.json('/api/login', { method: 'POST', json: { username, password: PW2 } });
    return r.body.ok ? s2 : null;
  }
  const sLow = await sessionFor(`${TAG.toLowerCase()}_low`);
  const sHigh = await sessionFor(`${TAG.toLowerCase()}_high`);
  const sAuditor = await sessionFor(`${TAG.toLowerCase()}_auditor`);
  const sSys = await sessionFor(`${TAG.toLowerCase()}_sys`);
  const sSec = await sessionFor(`${TAG.toLowerCase()}_sec`);
  const sClerkPub = await sessionFor(`${TAG.toLowerCase()}_clerk`);
  check('新账号可登录（reader 等 6 个会话）',
    !!(sLow && sHigh && sAuditor && sSys && sSec && sClerkPub),
    [!!sLow, !!sHigh, !!sAuditor, !!sSys, !!sSec, !!sClerkPub].join(','));

  if (!sLow || !sHigh || !sClerkPub) { console.error('关键会话缺失，无法继续'); process.exit(1); }

  // 附件夹具：秘密件与内部件各挂一个带唯一标记的正文
  // 注意：multipart() 每次调用都会生成新的 boundary，必须**只构造一次**再同时用作
  // Content-Type 与 body，否则两者边界不一致，服务端会解析不出任何文件。
  const MARK = 'MARK' + TAG;
  const mpSecret = multipart([{ filename: 'secret-note.txt', data: `秘密正文内容 ${MARK}A` }]);
  const mpInner = multipart([{ filename: 'inner-note.txt', data: `内部正文内容 ${MARK}B` }]);
  const upSecret = await admin.json(`/api/archives/${idSecret}/files`, {
    method: 'POST',
    headers: { 'Content-Type': mpSecret.contentType },
    body: mpSecret.body,
  });
  const upInner = await admin.json(`/api/archives/${idInner}/files`, {
    method: 'POST',
    headers: { 'Content-Type': mpInner.contentType },
    body: mpInner.body,
  });
  check('秘密件附件上传成功（并建正文索引）', upSecret.body.ok, JSON.stringify(upSecret.body).slice(0, 120));
  check('内部件附件上传成功（并建正文索引）', upInner.body.ok, JSON.stringify(upInner.body).slice(0, 120));

  // ---------- 1. 密级：列表 ----------
  section('密级 · 列表过滤');
  const listAdmin = await admin.json(`/api/archives?kw=${TAG}&size=50`);
  const listLow = await sLow.json(`/api/archives?kw=${TAG}&size=50`);
  const listHigh = await sHigh.json(`/api/archives?kw=${TAG}&size=50`);
  const codes = (r) => (r.body.data.list || []).map((x) => x.archive_code);
  check('管理员（机密）能看到 3 份', codes(listAdmin).length === 3, '实际 ' + codes(listAdmin).length);
  check('普通用户（内部）看不到秘密件', !codes(listLow).includes(codeSecret), codes(listLow).join(','));
  check('普通用户（内部）能看到公开件与内部件', codes(listLow).length === 2, '实际 ' + codes(listLow).length);
  check('普通用户（机密）能看到全部 3 份', codes(listHigh).length === 3, '实际 ' + codes(listHigh).length);

  // ---------- 2. 密级：详情 ----------
  section('密级 · 详情访问');
  const dSecretLow = await sLow.json(`/api/archives/${idSecret}`);
  const dInnerLow = await sLow.json(`/api/archives/${idInner}`);
  const dSecretHigh = await sHigh.json(`/api/archives/${idSecret}`);
  check('内部级用户读秘密件详情 → 404', dSecretLow.status === 404, 'status=' + dSecretLow.status);
  check('内部级用户读内部件详情 → 200', dInnerLow.status === 200, 'status=' + dInnerLow.status);
  check('机密级用户读秘密件详情 → 200', dSecretHigh.status === 200, 'status=' + dSecretHigh.status);
  check('越权响应不泄露存在性（404 而不是 403，且不含密级信息）',
    dSecretLow.status === 404 && !/密级|秘密|权限/.test(JSON.stringify(dSecretLow.body)),
    JSON.stringify(dSecretLow.body).slice(0, 120));

  // ---------- 3. 密级：附件 ----------
  section('密级 · 附件下载/预览');
  const fileIdSecret = upSecret.body.ok && upSecret.body.data.files && upSecret.body.data.files[0]
    ? upSecret.body.data.files[0].id : 0;
  const fileIdInner = upInner.body.ok && upInner.body.data.files && upInner.body.data.files[0]
    ? upInner.body.data.files[0].id : 0;
  if (fileIdSecret && fileIdInner) {
    const dlSecretLow = await sLow.text(`/api/files/${fileIdSecret}/download`);
    const dlInnerLow = await sLow.text(`/api/files/${fileIdInner}/download`);
    const dlSecretHigh = await sHigh.text(`/api/files/${fileIdSecret}/download`);
    check('内部级用户下载秘密件附件 → 404', dlSecretLow.status === 404, 'status=' + dlSecretLow.status);
    check('内部级用户下载内部件附件 → 200', dlInnerLow.status === 200, 'status=' + dlInnerLow.status);
    check('机密级用户下载秘密件附件 → 200', dlSecretHigh.status === 200, 'status=' + dlSecretHigh.status);
    const dlSecretLowBody = dlSecretLow.text || '';
    check('越权下载不返回文件内容', !dlSecretLowBody.includes(MARK), dlSecretLowBody.slice(0, 100));
  } else {
    check('附件夹具就位（秘密件/内部件）', false, '上传未返回文件 id');
  }

  // ---------- 3b. 下载票据（v4.20.7）----------
  //
  // 票据的用途是让手机上的系统下载器能在**不带 cookie** 的情况下取到附件
  // （安卓把下载交给另一个进程，cookie 会丢；而 blob 下载很多手机浏览器又不支持）。
  // 所以这里必须同时证明两件事：
  //   ① 票据确实能免 cookie 取件 —— 否则等于没修；
  //   ② 票据**不放松任何权限**，尤其不能绕过密级 —— 否则这就是自己开的后门。
  section('下载票据 · 免 cookie 且不越权');
  if (fileIdSecret && fileIdInner) {
    const anon = makeSession();
    const tkAnon = await anon.req(`/api/files/${fileIdSecret}/download-ticket`);
    check('取票据需要登录（未登录 401）', tkAnon.status === 401, 'status=' + tkAnon.status);

    const tk = await sHigh.json(`/api/files/${fileIdSecret}/download-ticket`);
    check('有权限的账号能取到票据', tk.status === 200 && tk.body.ok, JSON.stringify(tk.body).slice(0, 140));
    const turl = (tk.body && tk.body.data && tk.body.data.url) || '';
    check('票据地址带签名与有效期', /[?&]t=/.test(turl) && /[?&]e=\d+/.test(turl), turl);

    // 关键一条：**一个 cookie 都不带**去取，这正是手机系统下载器的处境
    const noCookie = await fetch(BASE + turl);
    const noCookieText = await noCookie.text();
    check('免 cookie 用票据取件 → 200', noCookie.status === 200, 'status=' + noCookie.status);
    check('免 cookie 取到的就是原文件内容', noCookieText.includes(MARK), noCookieText.slice(0, 80));

    const tampered = turl.replace(/([?&]t=)([^&]+)/, '$1AAAAAAAAAAAA');
    check('篡改签名 → 401', (await fetch(BASE + tampered)).status === 401);
    const swapped = turl.replace(/\/files\/\d+\//, `/files/${fileIdInner}/`);
    check('票据挪用给别的附件 → 401', (await fetch(BASE + swapped)).status === 401);
    check('无票据匿名下载 → 401',
      (await fetch(BASE + `/api/files/${fileIdInner}/download`)).status === 401);

    // 最重要的一条：低密级账号即使拿到了**合法票据**，也依然下不到秘密件。
    // 这说明票据只替代"认出你是谁"，权限、密级、利用控制全都照跑一遍。
    const tkLow = await sLow.json(`/api/files/${fileIdSecret}/download-ticket`);
    const lowUrl = (tkLow.body && tkLow.body.data && tkLow.body.data.url) || '';
    check('低密级账号也能取到票据（它确实有 file:download）', !!lowUrl, JSON.stringify(tkLow.body).slice(0, 140));
    if (lowUrl) {
      const lowDl = await fetch(BASE + lowUrl);
      const lowText = await lowDl.text();
      check('低密级账号凭票据下载秘密件 → 仍 404', lowDl.status === 404, 'status=' + lowDl.status);
      check('低密级账号凭票据也拿不到文件内容', !lowText.includes(MARK), lowText.slice(0, 100));
    } else {
      check('低密级账号凭票据下载秘密件 → 仍 404', false, '未取到票据');
      check('低密级账号凭票据也拿不到文件内容', false, '未取到票据');
    }
  } else {
    for (const n of ['取票据需要登录（未登录 401）', '有权限的账号能取到票据',
      '免 cookie 用票据取件 → 200', '篡改签名 → 401', '票据挪用给别的附件 → 401',
      '无票据匿名下载 → 401', '低密级账号凭票据下载秘密件 → 仍 404']) {
      check(n, false, '附件夹具缺失');
    }
  }

  // ---------- 4. 密级：导出与打印 ----------
  section('密级 · 导出与打印');
  const csvLow = await sLow.text(`/api/export/archives.csv?kw=${TAG}`);
  check('内部级用户导出 CSV 不含秘密件档号', !csvLow.text.includes(codeSecret), csvLow.text.slice(0, 160));
  check('内部级用户导出 CSV 含内部件档号', csvLow.text.includes(aInner.body.ok ? aInner.body.data.archive_code : '\u0000'));

  const prSecretLow = await sLow.text(`/api/print/archive/${idSecret}`);
  const prInnerLow = await sLow.text(`/api/print/archive/${idInner}`);
  check('内部级用户打印秘密件标签 → 404', prSecretLow.status === 404, 'status=' + prSecretLow.status);
  check('内部级用户打印内部件标签 → 200', prInnerLow.status === 200, 'status=' + prInnerLow.status);

  const lbSecretLow = await sLow.json(`/api/archives/${idSecret}/label`);
  check('内部级用户取秘密件二维码标签 → 404', lbSecretLow.status === 404, 'status=' + lbSecretLow.status);
  check('标签接口 404 时不返回二维码内容', !JSON.stringify(lbSecretLow.body).includes('qr_text'));

  const catLow = await sLow.text(`/api/print/catalog?kw=${TAG}`);
  check('内部级用户打印案卷目录不含秘密件档号', !catLow.text.includes(codeSecret));

  // ---------- 5. 密级：正文检索 ----------
  section('密级 · 附件正文检索');
  const searchLow = await sLow.json(`/api/search/text?kw=${MARK}A`);
  const searchHigh = await sHigh.json(`/api/search/text?kw=${MARK}A`);
  const searchInner = await sLow.json(`/api/search/text?kw=${MARK}B`);
  check('内部级用户搜不到秘密件正文', (searchLow.body.data && searchLow.body.data.list ? searchLow.body.data.list : []).length === 0,
    JSON.stringify(searchLow.body).slice(0, 120));
  check('机密级用户能搜到秘密件正文', (searchHigh.body.data && searchHigh.body.data.list ? searchHigh.body.data.list : []).length >= 1,
    JSON.stringify(searchHigh.body).slice(0, 120));
  check('内部级用户能搜到内部件正文', (searchInner.body.data && searchInner.body.data.list ? searchInner.body.data.list : []).length >= 1,
    JSON.stringify(searchInner.body).slice(0, 120));

  // ---------- 6. 密级：借阅 ----------
  section('密级 · 借阅申请');
  const loanSecret = await sLow.json('/api/loans', { method: 'POST', json: { archive_id: idSecret, purpose: '越权尝试', mode: '查阅' } });
  const loanInner = await sLow.json('/api/loans', { method: 'POST', json: { archive_id: idInner, purpose: '合规申请', mode: '查阅' } });
  check('内部级用户对秘密件申请借阅 → 404', loanSecret.status === 404, 'status=' + loanSecret.status);
  check('内部级用户对内部件申请借阅 → 成功', loanInner.body.ok, JSON.stringify(loanInner.body).slice(0, 120));

  // ---------- 7. 密级：批量修改越权 ----------
  section('密级 · 批量修改');
  const bulkBad = await sClerkPub.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [idSecret], changes: { department: TAG + '越权' } },
  });
  check('公开级档案员按 id 批量改秘密件 → 403', bulkBad.status === 403, 'status=' + bulkBad.status);
  const bulkOk = await sClerkPub.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [idPublic], changes: { department: TAG + '合规' } },
  });
  check('公开级档案员按 id 批量改公开件 → 成功', bulkOk.body.ok, JSON.stringify(bulkOk.body).slice(0, 120));

  // ---------- 8. 权限修复 ----------
  section('权限隔离 · 其他人员只查阅');
  // v4.20.0：使用者把权限模型定成"档案管理员能操作一切，其他人员只能查阅"。
  // 所以普通用户**连著录都不行** —— 这一条从原来的"业务允许"改成了"必须拒绝"。
  const own = await sLow.json('/api/archives', {
    method: 'POST',
    json: { type_code: 'WS', category_id: catId, title: `${TAG} 普通用户自建件`, secret_level: '公开', retention: '定期10年', year: '2026', archive_date: '2026-01-01' },
  });
  check('★ 普通用户不能著录档案（只查阅，不新建）', own.status === 403, 'status=' + own.status);

  // 修改/删除的靶子改用管理员建的件（普通用户再也建不出件来了）
  const victim = await admin.json('/api/archives', {
    method: 'POST',
    json: { type_code: 'WS', category_id: catId, title: `${TAG} 权限隔离靶件`, secret_level: '公开', retention: '定期10年', year: '2026', archive_date: '2026-01-01' },
  });
  const ownId = victim.body.ok ? victim.body.data.id : 0;
  if (ownId) created.archives.push(ownId);
  const updOwn = ownId ? await sLow.json(`/api/archives/${ownId}`, {
    method: 'PUT',
    json: { title: `${TAG} 被改过的题名`, category_id: catId, secret_level: '公开', retention: '定期10年', year: '2026', archive_date: '2026-01-01' },
  }) : { status: 0 };
  check('普通用户不能修改档案', updOwn.status === 403, 'status=' + updOwn.status);

  const delOwn = ownId ? await sLow.json(`/api/archives/${ownId}`, { method: 'DELETE', json: { reason: '测试夹具清理' } }) : { status: 0 };
  check('普通用户不能删除档案', delOwn.status === 403, 'status=' + delOwn.status);

  // 附件上传也是"改档案"：v4.20.0 起普通用户连给自己建的件传附件都不行
  if (ownId) {
    const mpUp = multipart([{ filename: '低权限上传.txt', data: Buffer.from('x', 'utf8'), mime: 'text/plain' }]);
    const upOwn = await sLow.req(`/api/archives/${ownId}/files`, {
      method: 'POST', headers: { 'Content-Type': mpUp.contentType }, body: mpUp.body,
    });
    check('普通用户不能上传附件', upOwn.status === 403, 'status=' + upOwn.status);
  }

  const updByAdmin = ownId ? await admin.json(`/api/archives/${ownId}`, {
    method: 'PUT',
    json: { title: `${TAG} 管理员改过的题名`, category_id: catId, secret_level: '公开', retention: '定期10年', year: '2026', archive_date: '2026-01-01' },
  }) : { body: {} };
  check('档案管理员仍可正常修改', updByAdmin.body && updByAdmin.body.ok, JSON.stringify(updByAdmin.body).slice(0, 120));

  // ---------- 9. 三员分立 ----------
  section('三员分立 · 职责隔离');
  if (sAuditor) {
    const audLogs = await sAuditor.json('/api/logs');
    check('安全审计员可以看审计日志', audLogs.status === 200, 'status=' + audLogs.status);
    const audCreate = await sAuditor.json('/api/archives', {
      method: 'POST', json: { type_code: 'WS', category_id: catId, title: `${TAG} 审计员建件`, retention: '定期10年' },
    });
    check('安全审计员不能著录档案（不参与业务）', audCreate.status === 403, 'status=' + audCreate.status);
    const audLoan = await sAuditor.json('/api/loans', { method: 'POST', json: { archive_id: idInner, mode: '查阅' } });
    check('安全审计员不能申请借阅', audLoan.status === 403, 'status=' + audLoan.status);
  } else { check('安全审计员会话可用', false); }

  // ---- 审计员必须"只审计"：逐个业务动作核对权限矩阵（v4.17.0）----
  //
  // 为什么单独钉这一组：审计员的档位是 3，而业务动作普遍写成 `lv >= 2`，
  // 于是 appraisal:run（鉴定）/ box:manage（装盒）/ transfer:manage（移交）/
  // archive:update 这些**曾经全部对审计员放行** —— 他审计的就是自己做过的事，
  // 分立就失去意义。这一组离线断言不依赖任何接口，直接锁死矩阵本身。
  {
    const P = require('../lib/policy');
    const aud = { id: 99, role: 'auditor' };
    const businessActions = [
      'archive:create', 'archive:read', 'archive:update', 'archive:delete', 'archive:destroy',
      'file:upload', 'file:delete', 'file:download',
      'loan:apply', 'loan:approve', 'loan:return',
      'appraisal:run', 'appraisal:approve', 'secret:classify',
      'box:manage', 'transfer:manage',
      'detection:run', 'todo:handle', 'meta:manage', 'backup',
      'user:manage', 'system:manage', 'security:manage', 'scheduler:view', 'scheduler:run',
    ];
    const leaked = businessActions.filter((a) => P.can(aud, a));
    check('★ 审计员对所有业务/管理动作一律无权（只审计）', leaked.length === 0, '仍放行：' + leaked.join('、'));
    // detection:view 是**查看**检测记录，属于审计证据，必须对审计员开放（四性检测套件也在盯这条）
    check('审计员仍可看审计日志、安全状态与检测记录',
      P.can(aud, 'log:view') === true && P.can(aud, 'audit:view') === true
      && P.can(aud, 'todo:read') === true && P.can(aud, 'detection:view') === true);
    // 另外两个三员各自的"专属动作"也必须泾渭分明
    check('安全保密员能定密、不能建号',
      P.can({ id: 98, role: 'secadmin' }, 'secret:classify') === true
      && P.can({ id: 98, role: 'secadmin' }, 'user:manage') === false);
    check('系统管理员能建号、不能定密',
      P.can({ id: 97, role: 'sysadmin' }, 'user:manage') === true
      && P.can({ id: 97, role: 'sysadmin' }, 'secret:classify') === false);

    // 普通用户（界面上叫「其他人员」）必须彻底只读（v4.20.0）：
    // 使用者定的是"其他人登录就只有查阅的权限，不能修改、删除等功能"。
    // 原来 archive:create 与 file:upload 写的是 lv>=1，普通用户也能著录、也能传附件 —— 已收紧。
    const reader = { id: 96, role: 'reader' };
    const writeActions = [
      'archive:create', 'archive:update', 'archive:delete', 'archive:destroy',
      'file:upload', 'file:delete', 'appraisal:run', 'appraisal:approve',
      'box:manage', 'transfer:manage', 'detection:run', 'todo:handle', 'meta:manage',
      'user:manage', 'system:manage', 'security:manage', 'backup', 'scheduler:run',
    ];
    const canWrite = writeActions.filter((a) => P.can(reader, a));
    check('★ 普通用户（其他人员）对所有写操作一律无权（只查阅）', canWrite.length === 0,
      '仍放行：' + canWrite.join('、'));
    check('普通用户仍可检索、看正文、申请借阅',
      P.can(reader, 'archive:read') === true && P.can(reader, 'file:download') === true
      && P.can(reader, 'loan:apply') === true);
  }

  if (sSys) {
    const sysUsers = await sSys.json('/api/users');
    check('系统管理员可以管理账号', sysUsers.status === 200, 'status=' + sysUsers.status);
    const sysSetClearance = await sSys.json(`/api/users/${created.users[0]}`, {
      method: 'PUT', json: { role: 'reader', clearance: '公开' },
    });
    check('系统管理员不能自行调整密级上限（定密与运维分离）', sysSetClearance.status === 403, 'status=' + sysSetClearance.status);
  } else { check('系统管理员会话可用', false); }

  if (sSec) {
    const secUsers = await sSec.json('/api/users');
    check('安全保密员不能建号/管号（建号与定密分离）', secUsers.status === 403, 'status=' + secUsers.status);
    const secSetClearance = await sSec.json(`/api/users/${created.users[0]}`, {
      method: 'PUT', json: { clearance: '公开' },
    });
    check('安全保密员可以调整密级上限', secSetClearance.body && secSetClearance.body.ok, JSON.stringify(secSetClearance.body).slice(0, 120));
  } else { check('安全保密员会话可用', false); }

  // ---------- 10. 合规状态 ----------
  section('安全合规状态');
  const stAdmin = await admin.json('/api/security/status');
  check('管理员可查看安全合规状态', stAdmin.status === 200, 'status=' + stAdmin.status);
  const stData = stAdmin.body.data || {};
  check('状态里返回密级管控开关', stData.enforceSecret === true, String(stData.enforceSecret));
  check('状态里返回三员角色清单', Array.isArray(stData.threeRoles) && stData.threeRoles.length === 3, JSON.stringify(stData.threeRoles));
  check('三员由不同账号担任时 distinctAccounts 正确', stData.distinctAccounts >= 3, 'distinct=' + stData.distinctAccounts);
  check('状态里给出待办告警列表', Array.isArray(stData.warnings), JSON.stringify(stData.warnings));

  const stLow = await sLow.json('/api/security/status');
  check('普通用户不能查看安全合规状态', stLow.status === 403, 'status=' + stLow.status);

  // ---- 角色名不许再出现"空白 / undefined"（v4.16.3）----
  //
  // 起因：api.js 里曾藏着一份只有 3 个旧角色的 ROLE_NAMES 副本，而 lib/policy.js 才是
  // 权威的 6 个角色。后果有三个，全部实测复现过：
  //   · 用户列表里三员账号的角色名变成空白（前端兜底成英文代号 secadmin）；
  //   · 审计日志写成「undefined｜密级上限=机密」——审计日志里出现 undefined 是要出事的；
  //   · 合规体检写成「三员尚未配齐：、 暂无账号」（名字为空，因为 [undefined,undefined].join('、') 是空串）。
  // 这三条断言就是钉住"角色名只有一份来源"。
  {
    const loginRoleNames = (await admin.json('/api/me')).body.data.roleNames || {};
    const expectRoles = ['admin', 'sysadmin', 'secadmin', 'auditor', 'clerk', 'reader'];
    const missing = expectRoles.filter((r) => !loginRoleNames[r]);
    check('登录/me 下发的角色名覆盖 6 个角色（含三员）', missing.length === 0,
      '缺：' + missing.join('、') + '；实际 ' + JSON.stringify(loginRoleNames));

    const threeWarn = (stData.warnings || []).find((w) => /三员/.test(w)) || '';
    check('三员告警里出现的是角色中文名，不是空名',
      !threeWarn || (/系统管理员|系统安全保密员|系统安全审计员/.test(threeWarn) && !/：\s*、/.test(threeWarn)),
      threeWarn);
    check('安全合规告警里不出现 undefined',
      !(stData.warnings || []).some((w) => /undefined/.test(String(w))),
      JSON.stringify(stData.warnings));

    const ulist = (await admin.json('/api/users')).body.data || {};
    const badRole = (ulist.list || []).filter((x) => !(ulist.roleNames || {})[x.role]).map((x) => x.role);
    check('用户列表里每个账号的角色都能给出中文名', badRole.length === 0, '缺名角色：' + [...new Set(badRole)].join('、'));

    const logs = (await admin.json('/api/logs?size=60')).body.data || {};
    const badLog = (logs.list || []).filter((l) => /undefined/.test(String(l.detail || '')));
    check('审计日志里不出现 undefined', badLog.length === 0,
      badLog.slice(0, 2).map((l) => l.action + '：' + l.detail).join(' / '));
  }

  if (sAuditor) {
    const stAud = await sAuditor.json('/api/security/status');
    check('安全审计员可查看安全合规状态', stAud.status === 200, 'status=' + stAud.status);
  }

  // ---------- 11. 密级上限调整生效 ----------
  section('密级上限 · 调整生效');
  const lowerHigh = await admin.json(`/api/users/${uHigh.body.ok ? uHigh.body.data.id : 0}`, {
    method: 'PUT', json: { clearance: '公开' },
  });
  check('管理员把某账号密级上限降为公开', lowerHigh.body && lowerHigh.body.ok, JSON.stringify(lowerHigh.body).slice(0, 120));
  const sHighAfter = await sessionFor(`${TAG.toLowerCase()}_high`);
  if (sHighAfter) {
    const listAfter = await sHighAfter.json(`/api/archives?kw=${TAG}&size=50`);
    const rowsAfter = (listAfter.body.data && listAfter.body.data.list) || [];
    const codeInner2 = aInner.body.ok ? aInner.body.data.archive_code : '';
    // 注意：夹具里有两份公开件（本次新建的公开件 + 普通用户自建件都按 TAG 命中），
    // 所以不能断言「只剩 1 份」，要断言「内部件与秘密件都看不到了、且结果全为公开级」。
    check('密级上限下调后，看不到内部件与秘密件',
      !codes(listAfter).includes(codeSecret) && !codes(listAfter).includes(codeInner2),
      codes(listAfter).join(','));
    check('密级上限下调后，返回结果全部为公开级（且非空）',
      rowsAfter.length > 0 && rowsAfter.every((r) => r.secret_level === '公开'),
      rowsAfter.map((r) => r.secret_level).join(',') || '（空）');
  } else { check('降级后仍可登录', false); }

  // ---------- 12. 其余数据出口的密级过滤 ----------
  section('其余数据出口 · 统计口径');
  const ovAdmin = await admin.json('/api/stats/overview');
  const ovLow = await sLow.json('/api/stats/overview');
  const names = (rows) => (rows || []).map((r) => r.name);
  check('低密级用户的总量小于管理员（涉密件未计入）',
    ovLow.body.data.total < ovAdmin.body.data.total,
    `${ovLow.body.data.total} vs ${ovAdmin.body.data.total}`);
  check('管理员按密级统计里含「秘密」',
    names(ovAdmin.body.data.bySecret).includes('秘密'), JSON.stringify(names(ovAdmin.body.data.bySecret)));
  check('低密级用户按密级统计里不含「秘密」',
    !names(ovLow.body.data.bySecret).includes('秘密'), JSON.stringify(names(ovLow.body.data.bySecret)));
  check('低密级用户按密级统计里不含「机密」',
    !names(ovLow.body.data.bySecret).includes('机密'), JSON.stringify(names(ovLow.body.data.bySecret)));
  check('低密级用户看不到涉密档案的"最近入库"',
    !(ovLow.body.data.recent || []).some((r) => r.archive_code === codeSecret),
    JSON.stringify((ovLow.body.data.recent || []).map((r) => r.archive_code)));
  check('低密级用户的门类统计合计不超过其可见总量',
    (ovLow.body.data.byType || []).reduce((s, r) => s + Number(r.count), 0) <= ovLow.body.data.total,
    JSON.stringify(ovLow.body.data.byType));

  const rpAdmin = await admin.json('/api/stats/report');
  const rpLow = await sLow.json('/api/stats/report');
  check('统计报表总量同样按密级过滤',
    rpLow.body.data.totals.total < rpAdmin.body.data.totals.total,
    `${rpLow.body.data.totals.total} vs ${rpAdmin.body.data.totals.total}`);
  check('统计报表按密级统计里不含「秘密」',
    !names(rpLow.body.data.bySecret).includes('秘密'), JSON.stringify(names(rpLow.body.data.bySecret)));

  const statCsvLow = await sLow.text('/api/stats/report.csv');
  check('统计表 CSV 不含「秘密」（数量本身就是涉密信息）', !statCsvLow.text.includes('秘密'),
    statCsvLow.text.split('\n').filter((l) => /秘密|机密/.test(l)).join('|').slice(0, 160));
  const statPrintLow = await sLow.text('/api/stats/report/print');
  check('打印版统计年报不含「秘密」', !statPrintLow.text.includes('秘密'));

  section('其余数据出口 · 到期与实体');
  const dueAdmin = await admin.json('/api/retention/due?from=2030&to=2040');
  const dueClerk = await sClerkPub.json('/api/retention/due?from=2030&to=2040');
  const dueCodes = (r) => ((r.body.data && r.body.data.list) || []).map((x) => x.archive_code);
  check('管理员到期清单含秘密件', dueCodes(dueAdmin).includes(codeSecret), dueCodes(dueAdmin).join(',').slice(0, 120));
  check('低密级档案员的到期清单不含秘密件', !dueCodes(dueClerk).includes(codeSecret), dueCodes(dueClerk).join(',').slice(0, 120));
  const sumLow = await sClerkPub.json('/api/retention/summary');
  check('到期汇总接口可用且按密级统计', sumLow.status === 200 && Array.isArray(sumLow.body.data.byRetention),
    JSON.stringify(sumLow.body.data || {}).slice(0, 160));

  // 造一个装了秘密件的盒，验证「盒内件数」也不泄露
  const boxR = await admin.json('/api/boxes', {
    method: 'POST', json: { box_code: `${TAG}-BOXMIX`, title: `${TAG} 密级盒计数测试`, type_code: 'WS', capacity: 50 },
  });
  const boxId = boxR.body.ok ? boxR.body.data.id : 0;
  if (boxId) {
    created.boxes.push(boxId);
    await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idSecret] } });
  }
  check('测试档案盒创建成功', !!boxId);
  const bxAdmin = await admin.json(`/api/boxes?kw=${TAG}-BOXMIX`);
  const bxLow = await sLow.json(`/api/boxes?kw=${TAG}-BOXMIX`);
  const cnt = (r) => (((r.body.data || {}).list || [])[0] || {}).archive_count;
  check('管理员看到盒内 1 件', Number(cnt(bxAdmin)) === 1, String(cnt(bxAdmin)));
  check('低密级用户看到盒内 0 件（件数本身也是涉密信息）', Number(cnt(bxLow)) === 0, String(cnt(bxLow)));

  section('其余数据出口 · 写操作越权');
  const bulkStatus = await sClerkPub.json('/api/archives/bulk-status', {
    method: 'POST', json: { ids: [idSecret], status: '待整理' },
  });
  check('按 id 批量改状态改不到涉密件', bulkStatus.status === 403, 'status=' + bulkStatus.status);

  const trBad = await sClerkPub.json('/api/transfers', {
    method: 'POST', json: { archive_ids: [idSecret], target_unit: TAG, title: `${TAG} 越权移交` },
  });
  check('不能把涉密件列入移交批次', trBad.status === 403, 'status=' + trBad.status);

  const dsBad = await sClerkPub.json('/api/destructions', {
    method: 'POST', json: { archive_ids: [idSecret], reason: TAG },
  });
  check('不能把涉密件列入销毁清册', dsBad.status === 403, 'status=' + dsBad.status);

  const scR = await sClerkPub.json('/api/stock-checks', {
    method: 'POST', json: { scope: '全库', type_code: 'WS', title: `${TAG} 密级盘点` },
  });
  if (scR.body.ok) created.checks.push(scR.body.data.id);
  check('盘点任务可创建（范围内按密级裁剪）', scR.body.ok, JSON.stringify(scR.body).slice(0, 160));
  if (scR.body.ok) {
    const detail = await sClerkPub.json(`/api/stock-checks/${scR.body.data.id}`);
    const itemCodes = ((detail.body.data && detail.body.data.items) || []).map((x) => x.archive_code);
    check('盘点明细里不含自己看不到的涉密件', !itemCodes.includes(codeSecret),
      itemCodes.join(',').slice(0, 160));
  }

  // ---------- 清理 ----------
  section('清理测试数据');
  let cleaned = 0;
  for (const id of created.archives) {
    const r = await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) cleaned++;
  }
  check(`测试档案已清理（${cleaned}/${created.archives.length}）`, cleaned === created.archives.length);
  let uCleaned = 0;
  const uFailed = [];
  for (const id of created.users) {
    const r = await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) uCleaned++;
    else uFailed.push(`id=${id} status=${r.status} ${JSON.stringify(r.body).slice(0, 100)}`);
  }
  check(`测试账号已清理（${uCleaned}/${created.users.length}）`, uCleaned === created.users.length,
    uFailed.join(' | '));

  // 档案盒与盘点任务：先删盒内档案引用，再删盒；盘点任务一并清掉
  for (const id of created.boxes) {
    await admin.json(`/api/boxes/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  const checkIds = created.checks.slice();
  let cCleaned = 0;
  for (const id of checkIds) {
    const r = await admin.json(`/api/stock-checks/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) cCleaned++;
    else if (r.status === 404) cCleaned++;   // 没有删除接口时不算失败
  }
  check(`盘点任务已清理（${cCleaned}/${checkIds.length}）`, cCleaned === checkIds.length);

  // ---------- 汇总 ----------
  console.log(`\n安全与合规回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) {
    console.log('\n失败明细：');
    fails.forEach((f) => console.log('  - ' + f));
  }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n安全测试异常终止：', e); process.exit(1); });
