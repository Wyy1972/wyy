/**
 * 端到端自测：覆盖登录、检索、著录、附件上传下载、借阅审批、权限、导出备份
 * 用法：node server/tools/selftest.js [http://127.0.0.1:8787]
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let pass = 0, failed = 0;
const failures = [];

function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; failures.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

function section(title) { console.log('\n【' + title + '】'); }

/** 带 cookie 的会话 */
function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(opts.json);
    }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    const setCookie = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const c of setCookie) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 200) }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  async function login(username, password) {
    const r = await json('/api/login', { method: 'POST', json: { username, password } });
    // v4.30.8 起 /api/users 建出来的账号一律 must_change=1，除 查自己/改密/登出 外全 403。
    // 套件原来"建号→登录→直接调业务接口"，等于绕过真人必经的首改；这里把这一步补上，
    // 改不回原口令也无所谓——本套件每个账号只用一次。admin 不在此列（出厂已标首改）。
    if (r.body && r.body.ok && String(username) !== 'admin') {
      await json('/api/me/password', { method: 'POST', json: { oldPassword: password, newPassword: 'Archive@2026x' } });
    }
    return r;
  }
  return { req, json, login, jar };
}

/** 构造 multipart 请求体 */
function multipart(fields, files) {
  const boundary = '----selftest' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields || {})) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files || []) {
    parts.push(Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\n` +
      `Content-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

/** 极简 ZIP 读取：列出条目名并校验 CRC-less 结构 */
function listZipEntries(buf) {
  const names = [];
  let i = 0;
  while (i < buf.length - 4) {
    if (buf.readUInt32LE(i) === 0x04034b50) {
      const nameLen = buf.readUInt16LE(i + 26);
      const extraLen = buf.readUInt16LE(i + 28);
      const size = buf.readUInt32LE(i + 18);
      const name = buf.slice(i + 30, i + 30 + nameLen).toString('utf8');
      names.push(name);
      i += 30 + nameLen + extraLen + size;
    } else i++;
  }
  return names;
}

async function main() {
  console.log('端到端自测目标：' + BASE);
  const admin = makeSession();

  section('1. 登录与鉴权');
  const badLogin = await admin.login('admin', 'wrong-password');
  check('错误密码被拒绝', badLogin.status === 401, 'HTTP ' + badLogin.status);
  const anonRes = await makeSession().json('/api/archives');
  check('未登录访问接口返回 401', anonRes.status === 401, 'HTTP ' + anonRes.status);
  const login = await admin.login('admin', 'admin123');
  check('管理员登录成功', login.status === 200 && login.body.ok === true, JSON.stringify(login.body).slice(0, 120));
  const me = await admin.json('/api/me');
  check('会话保持（/api/me）', me.status === 200 && me.body.data.user.username === 'admin');

  // 清理历史自测残留，保证脚本可重复运行
  const leftovers = await admin.json('/api/archives?kw=' + encodeURIComponent('自测专用') + '&size=50');
  for (const row of (leftovers.body.data.list || [])) {
    await admin.json('/api/archives/' + row.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  const leftoverUsers = await admin.json('/api/users');
  for (const u of (leftoverUsers.body.data.list || [])) {
    if (/^selftest_/.test(u.username)) await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }

  section('2. 基础元数据');
  const cats = await admin.json('/api/categories');
  const tree = cats.body.data.list;
  const types = await admin.json('/api/types');
  const typeList = types.body.data.list;
  // 不再写死"5 大门类"：v4.30.5 起出厂就补了「养护档案」「安全生产检查」两个门类，
  // 用户还能自己加门类，写死数字只会让自测在正常库上误报。
  check('分类树门类数与门类表一致（≥5）', tree.length >= 5 && tree.length === typeList.length,
    `分类树 ${tree.length} 个 / 门类表 ${typeList.length} 个`);
  // 二级分类至少 2 个（「安全生产检查」就是 2 个），单分类的门类说明建库没跑全
  check('分类含下级（每个顶类至少 2 个二级）', tree.every((t) => t.children.length >= 2),
    '有的分类没有下级');
  const wsCat = tree.find((t) => t.code === 'WS');
  const childCat = wsCat.children[0];
  check('门类返回 ≥5 类', typeList.length >= 5, '实际 ' + typeList.length);
  check('门类带自定义著录项', typeList.every((t) => t.fields.length > 0));

  // ---- 建立自测所需的基础数据 ----
  // 本套自测必须同时在“空库”（分发包出厂状态）和“有演示数据的库”上通过，
  // 因此所需的档案与账号一律由脚本自行创建，结束时再清理。
  const fixtures = [];
  for (const t of types.body.data.list) {
    const parent = tree.find((x) => x.code === t.code) || tree[0];
    const cat = parent.children[0];
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: {
        type_code: t.code, title: `自测基础数据-${t.name}`, category_id: cat.id,
        year: '2026', archive_date: '2026-01-01', retention: '永久', secret_level: '公开',
        responsible: '自测', department: '测试科',
        abstract: '自动化测试建立的基础数据，用于验证检索与统计功能。', keywords: '自测 基础数据',
      },
    });
    if (r.status === 200) fixtures.push(r.body.data.id);
  }
  check('已建立自测基础数据（每门类各 1 条）', fixtures.length === typeList.length,
    `建立 ${fixtures.length} 条 / 门类 ${typeList.length} 个`);

  section('3. 检索与统计');
  const list = await admin.json('/api/archives?page=1&size=5');
  check('档案列表分页正常', list.status === 200 && list.body.data.list.length === Math.min(5, list.body.data.total),
    `返回 ${list.body.data.list.length} 条 / 共 ${list.body.data.total} 条`);
  check('分页返回总数字段', Number.isInteger(list.body.data.total) && list.body.data.total > 0,
    'total=' + list.body.data.total);
  const total0 = list.body.data.total;
  const byType = await admin.json('/api/archives?type=HT&size=50');
  check('按门类筛选', byType.body.data.list.length > 0 && byType.body.data.list.every((r) => r.type_code === 'HT'),
    'total=' + byType.body.data.total);
  const byCat = await admin.json(`/api/archives?category=${wsCat.id}&size=50`);
  check('按分类筛选（含下级）', byCat.body.data.total >= 1, 'total=' + byCat.body.data.total);
  // 用自测基础数据的题名做全文检索断言，避免依赖演示数据
  const fixtureKw = '自测基础数据';
  const kw = await admin.json('/api/archives?kw=' + encodeURIComponent(fixtureKw));
  check('中文关键词检索有结果', kw.body.data.total >= 5, 'total=' + kw.body.data.total);
  const kwFts = await admin.json('/api/archives?kw=' + encodeURIComponent('基础数据'));
  check('摘要/题名全文命中', kwFts.body.data.total >= 5, 'total=' + kwFts.body.data.total);
  const kwNone = await admin.json('/api/archives?kw=' + encodeURIComponent('这个词肯定不存在xyz'));
  check('无匹配关键词返回空', kwNone.body.data.total === 0);
  const kv = await admin.json('/api/archives?kw=' + encodeURIComponent('合同') + '&retention=' + encodeURIComponent('30年'));
  check('多条件组合筛选', kv.status === 200);
  const overview = await admin.json('/api/stats/overview');
  // 门类数是数据驱动的（v4.30.5 起出厂 7 个，用户还能自己加），所以按 /api/types 的实际条数校验，
  // 不再钉死"5 个"——那是旧出厂数据的口径。
  const typeListForStats = await admin.json('/api/types');
  const typeCount = ((typeListForStats.body.data && typeListForStats.body.data.list) || []).length;
  check('统计接口返回完整维度', overview.status === 200 && overview.body.data.byType.length === typeCount
    && Array.isArray(overview.body.data.monthly) && !!overview.body.data.loanStats,
    `byType=${(overview.body.data.byType || []).length} types=${typeCount}`);
  check('统计数据与列表一致', overview.body.data.total === total0, `${overview.body.data.total} vs ${total0}`);

  section('4. 档案著录');
  // 出厂默认模板是 DA/T 22—2015 标准结构，含「机构(问题)代码」段 —— 它取自分类号，
  // 所以预览必须指定分类；不指定时系统会明确拒绝，而不是产出一个空段的档号（v4.8.0 起）。
  const nextCode = await admin.json(`/api/archives/next-code?type=WS&year=2026&category=${childCat.id}`);
  check('自动生成档案号', /^WS-2026-\d{4}$/.test(nextCode.body.data.code), nextCode.body.data.code);
  check('同时给出符合 DA/T 22—2015 的规范档号',
    /^Z001-WS·2026-[A-Z]\d*-DQ-\d{4}$/.test(nextCode.body.data.archive_number || ''),
    nextCode.body.data.archive_number);
  const created = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'HT', title: '自测专用合同（可删除）', category_id: childCat.id,
      year: '2026', archive_date: '2026-01-05', retention: '定期10年', secret_level: '内部',
      responsible: '自测', department: '测试科', abstract: '这是一条自动化测试写入的合同档案。',
      keywords: '自测 自动化', extra: { hth: 'TEST-2026-001', je: '12345.67', yf: '某某测试公司' },
    },
  });
  check('新建档案成功', created.status === 200 && created.body.data.id > 0, JSON.stringify(created.body).slice(0, 160));
  const newId = created.body.data.id;
  const newCode = created.body.data.archive_code;
  check('自动分配档案号', /^HT-2026-\d{4}$/.test(newCode), newCode);
  const dup = await admin.json('/api/archives', {
    method: 'POST', json: { type_code: 'HT', title: '重复档案号测试', category_id: childCat.id, archive_code: newCode },
  });
  check('重复档案号被拒绝', dup.status === 409, 'HTTP ' + dup.status);
  const badTitle = await admin.json('/api/archives', {
    method: 'POST', json: { type_code: 'HT', category_id: childCat.id, title: '' },
  });
  check('空题名被拒绝', badTitle.status === 400, 'HTTP ' + badTitle.status);
  const detail = await admin.json('/api/archives/' + newId);
  check('详情读回自定义著录项', detail.body.data.extra.hth === 'TEST-2026-001' && detail.body.data.extra.je === '12345.67',
    JSON.stringify(detail.body.data.extra));
  check('详情关联分类名称', !!detail.body.data.category_name);
  const upd = await admin.json('/api/archives/' + newId, {
    method: 'PUT', json: { title: '自测专用合同（已修改）', category_id: childCat.id, extra: { hth: 'TEST-2026-001-X' } },
  });
  check('修改档案成功', upd.status === 200 && upd.body.ok);
  const after = await admin.json('/api/archives/' + newId);
  check('修改已生效且保留未提交字段', after.body.data.title.includes('已修改') && after.body.data.retention === '定期10年',
    after.body.data.title + ' / ' + after.body.data.retention);
  const codeCheck = await admin.json('/api/archives/check-code', { method: 'POST', json: { archive_code: newCode } });
  check('档案号查重接口', codeCheck.body.data.available === false && codeCheck.body.data.conflict.id === newId);

  section('5. 附件上传 / 下载 / 预览');
  const fileContent = '档案系统附件测试内容\r\n第二行：中文内容检验 UTF-8 与下载一致性。\r\n';
  const mp = multipart({ kind: '正文' }, [
    { filename: '测试附件.txt', mime: 'text/plain', data: fileContent },
    { filename: '第二个附件.csv', mime: 'text/csv', data: 'a,b,c\r\n1,2,3\r\n' },
  ]);
  const up = await admin.req(`/api/archives/${newId}/files`, {
    method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body,
  });
  const upJson = await up.json();
  check('批量上传附件成功', up.status === 200 && upJson.ok && upJson.data.files.length === 2, JSON.stringify(upJson).slice(0, 160));
  const fileId = upJson.data && upJson.data.files ? upJson.data.files[0].id : 0;
  check('中文文件名保留', upJson.data.files[0].name === '测试附件.txt', upJson.data.files[0].name);

  const dl = await admin.req(`/api/files/${fileId}/download`);
  const dlText = await dl.text();
  check('下载内容与上传一致', dlText === fileContent, 'len=' + dlText.length);
  check('下载返回附件头', /attachment/.test(dl.headers.get('content-disposition') || '')
    && /filename\*=UTF-8''/.test(dl.headers.get('content-disposition') || ''));
  const preview = await admin.req(`/api/files/${fileId}/preview`);
  check('预览接口按 inline 返回', preview.status === 200 && /inline/.test(preview.headers.get('content-disposition') || ''));
  await preview.text();
  const head = await admin.req(`/api/files/${fileId}/download`, { method: 'HEAD' });
  check('HEAD 请求支持（预览探测用）', head.status === 200 && Number(head.headers.get('content-length')) > 0);
  const ranged = await admin.req(`/api/files/${fileId}/download`, { headers: { Range: 'bytes=0-5' } });
  const rangedBuf = Buffer.from(await ranged.arrayBuffer());
  check('断点续传 / Range 支持（返回精确字节范围）',
    ranged.status === 206 && rangedBuf.length === 6
    && ranged.headers.get('content-range') === `bytes 0-5/${Buffer.byteLength(fileContent)}`,
    `HTTP ${ranged.status} len=${rangedBuf.length} range=${ranged.headers.get('content-range')}`);
  const dedup = multipart({}, [{ filename: '同名内容副本.txt', mime: 'text/plain', data: fileContent }]);
  const up2 = await admin.req(`/api/archives/${newId}/files`, {
    method: 'POST', headers: { 'Content-Type': dedup.contentType }, body: dedup.body,
  });
  const up2Json = await up2.json();
  check('重复内容可再上传（请求成功）', up2.status === 200 && up2Json.ok);
  const listFiles = await admin.json('/api/archives/' + newId);
  const paths = listFiles.body.data.files.map((f) => f.rel_path || f.stored_name);
  const storedNames = listFiles.body.data.files.map((f) => f.stored_name);
  // v4.28.0 起附件按档号落盘（<档号>-02.txt、-03.txt…），同内容不再共享同一个物理实体，
  // 所以这里要钉的不是"存储名相同"，而是"每件各占一个独立文件，互不覆盖"。
  check('同内容附件各自独立落盘、存储名互不覆盖',
    storedNames.length >= 2 && new Set(storedNames).size === storedNames.length,
    storedNames.join(','));
  const delFile = await admin.json('/api/files/' + up2Json.data.files[0].id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('删除附件成功', delFile.status === 200);
  const stillThere = await admin.req(`/api/files/${fileId}/download`);
  check('删掉其中一个不影响另一个附件', stillThere.status === 200, 'HTTP ' + stillThere.status);
  await stillThere.text();

  section('6. 借阅流程（含权限）');
  const reader = makeSession();
  // 普通用户账号由脚本自行创建，保证在空库环境下也能验证权限控制
  const readerName = 'selftest_reader';
  const mkReader = await admin.json('/api/users', {
    method: 'POST',
    json: { username: readerName, display_name: '自测普通用户', password: 'reader123456', role: 'reader', department: '测试科' },
  });
  check('创建普通用户账号', mkReader.status === 200, JSON.stringify(mkReader.body).slice(0, 120));
  await reader.login(readerName, 'reader123456');
  const rMe = await reader.json('/api/me');
  check('普通用户登录成功', rMe.status === 200 && rMe.body.data.user.role === 'reader', JSON.stringify(rMe.body).slice(0, 120));
  const rApply = await reader.json('/api/loans', {
    method: 'POST', json: { archive_id: newId, mode: '借出', purpose: '自测借阅用途', due_date: '2026-12-31' },
  });
  check('普通用户申请进入待审批', rApply.status === 200 && rApply.body.data.status === '待审批', JSON.stringify(rApply.body).slice(0, 140));
  const loanId = rApply.body.data.id;
  const rApprove = await reader.json(`/api/loans/${loanId}/approve`, { method: 'POST', json: { approve: true, due_date: '2026-12-31' } });
  check('普通用户无审批权限（403）', rApprove.status === 403, 'HTTP ' + rApprove.status);
  const rUsers = await reader.json('/api/users');
  check('普通用户无法查看用户列表（403）', rUsers.status === 403, 'HTTP ' + rUsers.status);
  const rLogs = await reader.json('/api/logs');
  check('普通用户无法查看日志（403）', rLogs.status === 403, 'HTTP ' + rLogs.status);
  const rBackup = await reader.json('/api/backup/download');
  check('普通用户无法导出备份（403）', rBackup.status === 403, 'HTTP ' + rBackup.status);
  const rStats = await reader.json('/api/stats/overview');
  check('普通用户可查看统计', rStats.status === 200);
  const dupApply = await reader.json('/api/loans', { method: 'POST', json: { archive_id: newId, mode: '借出', purpose: '重复申请' } });
  check('重复借阅申请被拦截', dupApply.status === 400, 'HTTP ' + dupApply.status);

  const pending = await admin.json('/api/loans?status=' + encodeURIComponent('待审批'));
  check('管理员可见待审批列表', pending.body.data.counts.pending >= 1, 'pending=' + pending.body.data.counts.pending);
  const approve = await admin.json(`/api/loans/${loanId}/approve`, { method: 'POST', json: { approve: true, due_date: '2026-12-31', note: '同意' } });
  check('管理员批准借阅', approve.status === 200);
  const st1 = await admin.json('/api/archives/' + newId);
  check('批准后档案状态变为借出', st1.body.data.status === '借出', st1.body.data.status);
  const ret = await admin.json(`/api/loans/${loanId}/return`, { method: 'POST', json: { note: '完好' } });
  check('办理归还成功', ret.status === 200);
  const st2 = await admin.json('/api/archives/' + newId);
  check('归还后档案状态回到在库', st2.body.data.status === '在库', st2.body.data.status);
  const delBusy = await admin.json('/api/loans/' + loanId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('已归还记录作为留痕不可删除', delBusy.status === 400, 'HTTP ' + delBusy.status);

  section('7. 用户管理与密码');
  const uName = 'selftest_' + Date.now().toString().slice(-6);
  const mkUser = await admin.json('/api/users', {
    method: 'POST', json: { username: uName, display_name: '自测用户', password: 'test123456', role: 'clerk', department: '测试科' },
  });
  check('新增用户成功', mkUser.status === 200, JSON.stringify(mkUser.body).slice(0, 120));
  const newUserId = mkUser.body.data.id;
  const dupUser = await admin.json('/api/users', {
    method: 'POST', json: { username: uName, display_name: '重复', password: 'test123456' },
  });
  check('重复用户名被拒绝', dupUser.status === 400);
  const shortPwd = await admin.json('/api/users', {
    method: 'POST', json: { username: 'shortpwd_' + Date.now().toString().slice(-5), password: '123' },
  });
  check('弱密码被拒绝', shortPwd.status === 400);
  const newUserSession = makeSession();
  const nuLogin = await newUserSession.login(uName, 'test123456');
  check('新用户可登录', nuLogin.status === 200 && nuLogin.body.data.user.role === 'clerk');
  const clerkApprove = await newUserSession.json('/api/loans/999999/approve', { method: 'POST', json: { approve: true } });
  check('档案员具备审批权限（非 403）', clerkApprove.status !== 403, 'HTTP ' + clerkApprove.status);
  const clerkBackup = await newUserSession.json('/api/backup/download');
  check('档案员无备份权限（403）', clerkBackup.status === 403, 'HTTP ' + clerkBackup.status);
  const resetPwd = await admin.json(`/api/users/${newUserId}/reset-password`, { method: 'POST', json: { password: 'newpass123' } });
  check('重置密码成功', resetPwd.status === 200);
  const afterReset = await newUserSession.json('/api/me');
  check('重置后原会话失效', afterReset.status === 401, 'HTTP ' + afterReset.status);
  const relogin = await makeSession().login(uName, 'newpass123');
  check('可用新密码登录', relogin.status === 200);
  const selfDel = await admin.json('/api/users/' + me.body.data.user.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('不能删除自己', selfDel.status === 400);
  const changePwd = await admin.json('/api/me/password', {
    method: 'POST', json: { oldPassword: 'admin123', newPassword: 'admin123' },
  });
  check('修改密码接口可用（原密码错误应拒绝）', changePwd.status === 400 || changePwd.status === 200);
  const wrongOld = await admin.json('/api/me/password', {
    method: 'POST', json: { oldPassword: 'definitely-wrong', newPassword: 'abcdef123' },
  });
  check('原密码错误被拒绝', wrongOld.status === 400, 'HTTP ' + wrongOld.status);

  section('8. 导出与备份');
  const csv = await admin.req('/api/export/archives.csv');
  const csvBuf = Buffer.from(await csv.arrayBuffer());
  const csvText = csvBuf.toString('utf8');
  check('CSV 导出成功', csv.status === 200 && csvText.includes('档案号') && csvText.includes('题名'));
  check('CSV 含 UTF-8 BOM（Excel 中文不乱码）',
    csvBuf[0] === 0xef && csvBuf[1] === 0xbb && csvBuf[2] === 0xbf,
    [...csvBuf.slice(0, 3)].map((b) => b.toString(16)).join(' '));
  const csvArchiveTotal = await admin.json('/api/archives?size=1');
  check('CSV 行数与档案数匹配', csvText.trim().split(/\r\n/).length === csvArchiveTotal.body.data.total + 1,
    `CSV ${csvText.trim().split(/\r\n/).length - 1} 行 vs 档案 ${csvArchiveTotal.body.data.total} 条`);

  const bkArchiveTotal = (await admin.json('/api/archives?size=1')).body.data.total;
  const bk = await admin.req('/api/backup/download');
  const bkBuf = Buffer.from(await bk.arrayBuffer());
  const entries = listZipEntries(bkBuf);
  check('备份 ZIP 下载成功', bk.status === 200 && bkBuf.length > 1000, 'bytes=' + bkBuf.length);
  check('备份包含数据库快照', entries.includes('db/archive.db'), entries.slice(0, 8).join(','));
  check('备份包含 manifest', entries.includes('manifest.json'));
  check('备份包含附件目录', entries.some((e) => e.startsWith('files/')), entries.filter((e) => e.startsWith('files/')).slice(0, 3).join(','));

  // 校验恢复出来的数据库能否打开
  const tmpZipDir = fs.mkdtempSync(path.join(os.tmpdir(), 'as-zip-'));
  const dbEntryOffset = (() => {
    let i = 0;
    while (i < bkBuf.length - 4) {
      if (bkBuf.readUInt32LE(i) === 0x04034b50) {
        const nameLen = bkBuf.readUInt16LE(i + 26);
        const extraLen = bkBuf.readUInt16LE(i + 28);
        const size = bkBuf.readUInt32LE(i + 18);
        const name = bkBuf.slice(i + 30, i + 30 + nameLen).toString('utf8');
        if (name === 'db/archive.db') return { start: i + 30 + nameLen + extraLen, size };
        i += 30 + nameLen + extraLen + size;
      } else i++;
    }
    return null;
  })();
  if (dbEntryOffset) {
    const outDb = path.join(tmpZipDir, 'restore.db');
    fs.writeFileSync(outDb, bkBuf.slice(dbEntryOffset.start, dbEntryOffset.start + dbEntryOffset.size));
    const { DatabaseSync } = require('node:sqlite');
    const rdb = new DatabaseSync(outDb);
    const n = rdb.prepare('SELECT COUNT(*) AS c FROM archives').get().c;
    check('备份数据库可正常打开且数据完整', Number(n) === bkArchiveTotal,
      `恢复库档案数 ${n} vs 备份时 ${bkArchiveTotal}`);
    const restoredFts = rdb.prepare('SELECT COUNT(*) AS c FROM archives_fts').get().c;
    const restoredFiles = rdb.prepare('SELECT COUNT(*) AS c FROM files').get().c;
    check('备份库中全文索引同步完整', Number(restoredFts) === Number(n), `索引 ${restoredFts} / 档案 ${n}`);
    check('备份库中附件记录完整', Number(restoredFiles) > 0, 'files=' + restoredFiles);
    rdb.close();
  } else {
    check('备份数据库可正常打开且数据完整', false, '未在 ZIP 中找到 db/archive.db');
    check('备份库中全文索引同步完整', false, '未找到数据库');
    check('备份库中附件记录完整', false, '未找到数据库');
  }
  fs.rmSync(tmpZipDir, { recursive: true, force: true });

  section('9. 日志与系统信息');
  const logs = await admin.json('/api/logs?size=50');
  check('日志接口可用', logs.status === 200 && logs.body.data.total > 0, 'total=' + logs.body.data.total);
  const actions = logs.body.data.list.map((l) => l.action);
  check('登录/新建/上传/借阅等操作已留痕',
    ['登录', '新建档案', '上传附件', '批准借阅', '办理归还'].every((a) => actions.includes(a)),
    [...new Set(actions)].join('/'));
  const sysinfo = await admin.json('/api/system/info');
  check('系统信息接口可用', sysinfo.status === 200 && sysinfo.body.data.version && sysinfo.body.data.dataDir);

  section('10. 边界与健壮性');
  const missing = await admin.json('/api/archives/99999999');
  check('不存在的档案返回 404', missing.status === 404);
  const badApi = await admin.json('/api/not-exist');
  check('未知接口返回 404 JSON', badApi.status === 404 && badApi.body.ok === false);
  const evil = await admin.req('/../server/server.js');
  const evilText = await evil.text();
  check('路径穿越尝试不会拿到程序源码',
    evil.status === 404 && !evilText.includes('require.main === module'),
    'HTTP ' + evil.status + ' len=' + evilText.length);
  const evilEnc = await admin.req('/%2e%2e%2f%2e%2e%2fserver%2fserver.js');
  const evilEncText = await evilEnc.text();
  check('编码后的穿越尝试同样被拦截',
    evilEnc.status === 404 && !evilEncText.includes('require.main === module'),
    'HTTP ' + evilEnc.status);
  const evilFile = await admin.req('/api/files/../../../../etc/passwd/download');
  const evilFileText = await evilFile.text();
  check('附件接口穿越尝试被拦截', evilFile.status === 404 && !evilFileText.includes('root:'),
    'HTTP ' + evilFile.status);
  const spa = await admin.req('/', { headers: { Accept: 'text/html' } });
  const spaText = await spa.text();
  check('浏览器导航正常返回单页应用', spa.status === 200 && spaText.includes('档案管理系统'));
  const badJson = await admin.req('/api/archives', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad json' });
  check('非法 JSON 返回 400', badJson.status === 400, 'HTTP ' + badJson.status);
  await badJson.text();
  const badCat = await admin.json('/api/archives', { method: 'POST', json: { type_code: 'HT', title: '分类不存在测试', category_id: 999999 } });
  check('不存在的分类被拒绝', badCat.status === 400, 'HTTP ' + badCat.status);
  const badType = await admin.json('/api/archives', { method: 'POST', json: { type_code: 'ZZZ', title: '门类不存在测试', category_id: childCat.id } });
  check('不存在的门类被拒绝', badType.status === 400, 'HTTP ' + badType.status);
  const emptyUp = multipart({}, []);
  const upEmpty = await admin.req(`/api/archives/${newId}/files`, {
    method: 'POST', headers: { 'Content-Type': emptyUp.contentType }, body: emptyUp.body,
  });
  check('空上传被拒绝', upEmpty.status === 400, 'HTTP ' + upEmpty.status);
  await upEmpty.text();

  section('11. 索引一致性');
  const kwNew = await admin.json('/api/archives?kw=' + encodeURIComponent('自测专用'));
  check('新建档案立即可被检索到', kwNew.body.data.total >= 1, 'total=' + kwNew.body.data.total);

  section('12. 清理自测数据');
  const cleanDel = await admin.json('/api/archives/' + newId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('删除自测档案成功', cleanDel.status === 200);
  const afterDel = await admin.json('/api/archives?kw=' + encodeURIComponent('自测专用'));
  check('删除后全文索引同步清理', afterDel.body.data.total === 0, 'total=' + afterDel.body.data.total);

  let fxRemoved = 0;
  for (const id of fixtures) {
    const r = await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.status === 200) fxRemoved++;
  }
  check('清理自测基础数据', fxRemoved === fixtures.length, `${fxRemoved}/${fixtures.length}`);

  const cleanUser = await admin.json('/api/users/' + newUserId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('删除自测用户成功', cleanUser.status === 200);
  for (const u of ['selftest_reader', 'selftest_owner']) {
    const found = await admin.json('/api/users');
    const target = (found.body.data.list || []).find((x) => x.username === u);
    if (target) await admin.json('/api/users/' + target.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  const finalTotal = await admin.json('/api/archives?size=1');
  // 比 ID 集合而不是总数：基线里可能本来就含演示数据，总数断言会误判
  const fxList = await admin.json('/api/archives?size=200');
  const remainingFixtureIds = (fxList.body.data.list || [])
    .map((r) => r.id).filter((id) => fixtures.includes(id));
  check('自测数据已完全清理干净', remainingFixtureIds.length === 0,
    `残留 ${remainingFixtureIds.length} 条；当前馆藏 ${finalTotal.body.data.total} 条`);

  console.log('\n' + '='.repeat(56));
  console.log(`自测结果：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) {
    console.log('\n失败明细：');
    failures.forEach((f) => console.log('  - ' + f));
  }
  console.log('='.repeat(56));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('\n自测脚本异常终止：', e);
  process.exit(1);
});
