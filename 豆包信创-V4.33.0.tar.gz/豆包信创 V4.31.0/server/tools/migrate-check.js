/**
 * 升级迁移预演（dry-run，零依赖）
 *
 * 作用：在**真实数据的副本**上完整跑一遍数据库迁移，报告迁移前后的变化，
 *      用来在正式升级前确认「迁移幂等、不破坏数据、新增字段就位」。
 *
 * 用法：
 *   node server/tools/migrate-check.js <数据目录>           预演并自动清理
 *   node server/tools/migrate-check.js <数据目录> --keep     保留临时副本以便人工检查
 *   node server/tools/migrate-check.js --self               用内置临时库自测一遍（无需真实数据）
 *
 * 安全性（重要）：
 *   本工具**绝不直接打开源库**。它会先把 archive.db（含 -wal/-shm）复制到系统临时目录，
 *   再打开副本。因此对生产数据是纯只读的 —— 预演本身不会改动一个字节。
 *
 * 退出码：0 = 预演成功；1 = 失败。
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { openDatabase, SCHEMA_VERSION } = require('../db');
const audit = require('../lib/audit');

const args = process.argv.slice(2);
const keep = args.includes('--keep');
const selfTest = args.includes('--self');
const srcArg = args.find((a) => !a.startsWith('--'));

/** 复制 SQLite 库及其 WAL 附属文件 */
function copyDb(srcDir, dstDir) {
  fs.mkdirSync(dstDir, { recursive: true });
  const names = ['archive.db', 'archive.db-wal', 'archive.db-shm'];
  let n = 0;
  for (const name of names) {
    const from = path.join(srcDir, name);
    if (fs.existsSync(from)) {
      fs.copyFileSync(from, path.join(dstDir, name));
      n++;
    }
  }
  if (!fs.existsSync(path.join(dstDir, 'archive.db'))) {
    throw new Error(`源数据目录里没有 archive.db：${srcDir}`);
  }
  return n;
}

/**
 * 读取一份库的关键指标。
 *
 * **必须对「表和列可能还不存在」容错**：本工具要在迁移**前**读一次快照，
 * 而那时 users.clearance、甚至整张表都可能还不存在。
 * 早期版本直接写死 `SELECT ...,clearance FROM users`，结果在迁移前的库上抛
 * "no such column: clearance"，被兜底捕获后报出「迁移前 0 条」的误导性结论。
 */
function snapshot(db) {
  const tableExists = (t) => !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(t);
  const columns = (t) => {
    try { return db.prepare(`PRAGMA table_info(${t})`).all().map((r) => r.name); } catch (_) { return []; }
  };
  const count = (t) => (tableExists(t) ? db.prepare(`SELECT COUNT(*) AS c FROM ${t}`).get().c : 0);

  const schema = tableExists('meta')
    ? ((db.prepare("SELECT value FROM meta WHERE key='schema_version'").get() || {}).value || null)
    : null;

  const uCols = columns('users');
  const sel = ['id', 'username', 'role', 'status'].filter((c) => uCols.includes(c));
  if (uCols.includes('clearance')) sel.push('clearance');
  const userList = tableExists('users') && sel.includes('username')
    ? db.prepare(`SELECT ${sel.join(',')} FROM users ORDER BY id`).all()
    : [];

  const settings = {};
  if (tableExists('settings')) {
    for (const k of ['security.enforce_secret', 'security.three_roles', 'security.login_max_fail',
      'security.login_min_length', 'security.password_min_length', 'security.log_retain_days']) {
      const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k);
      if (r) settings[k] = r.value;
    }
  }

  // 审计日志链：迁移会为存量日志建立哈希链，这里顺便验证链是否完整。
  // 迁移前该列还不存在（logChain=null，不打印）。
  let logChain = null;
  if (tableExists('logs') && columns('logs').includes('hash')) {
    try {
      const rows = db.prepare('SELECT * FROM logs ORDER BY id').all();
      const vr = audit.verifyChain(rows);
      logChain = { total: rows.length, ok: vr.ok, brokenAt: vr.brokenAt || null, reason: vr.reason || '' };
    } catch (e) {
      logChain = { total: 0, ok: false, brokenAt: null, reason: e.message };
    }
  }

  return {
    schema,
    users: count('users'),
    userList,
    archives: count('archives'),
    boxes: count('archive_boxes'),
    files: count('files'),
    loans: count('loans'),
    logs: count('logs'),
    hasClearance: uCols.includes('clearance'),
    hasArchiveNumber: columns('archives').includes('archive_number'),
    settings,
    logChain,
  };
}

function fmt(v) { return v === null || v === undefined ? '—' : String(v); }

function report(label, s) {
  console.log(`\n【${label}】`);
  console.log(`  schema 版本        : ${fmt(s.schema)}   （程序当前 ${SCHEMA_VERSION}）`);
  console.log(`  账号 / 档案 / 盒    : ${s.users} / ${s.archives} / ${s.boxes}`);
  console.log(`  附件 / 借阅 / 日志   : ${s.files} / ${s.loans} / ${s.logs}`);
  console.log(`  users.clearance    : ${s.hasClearance ? '已存在 ✓' : '缺失 ✗'}`);
  console.log(`  archives.archive_number : ${s.hasArchiveNumber ? '已存在 ✓' : '缺失 ✗'}`);
  console.log('  安全设置            : '
    + (Object.keys(s.settings).length ? Object.entries(s.settings).map(([k, v]) => `${k}=${v}`).join('  ') : '（未写入）'));
  if (s.logChain) {
    console.log(`  审计日志链          : ${s.logChain.ok ? '完整 ✓' : '断开 ✗'}（共 ${s.logChain.total} 条，SHA-256 链式哈希）`);
    if (!s.logChain.ok) {
      console.log(`      断点 id=${s.logChain.brokenAt}：${s.logChain.reason}`);
    }
  }
  console.log('  账号密级上限        :');
  for (const u of s.userList) {
    console.log(`      ${String(u.username).padEnd(16)} 角色=${String(u.role).padEnd(10)} 状态=${String(u.status).padEnd(8)} 密级上限=${u.clearance ? u.clearance : '（空，按角色默认）'}`);
  }
}

function main() {
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'migrate-check-'));
  const workDir = path.join(tmpRoot, 'data');
  let srcDir = srcArg;

  try {
    if (selfTest || !srcDir) {
      if (!selfTest) {
        console.error('用法：node server/tools/migrate-check.js <数据目录> [--keep]');
        console.error('      node server/tools/migrate-check.js --self');
        process.exit(1);
      }
      console.log('自测模式：用内置空白库验证迁移链路');
      fs.mkdirSync(workDir, { recursive: true });
      const db0 = openDatabase(path.join(workDir, 'archive.db'));
      db0.close();
      const first = snapshotDirect(path.join(workDir, 'archive.db'));
      report('迁移后（第一次打开）', first);
      const second = snapshotDirect(path.join(workDir, 'archive.db'));
      report('再次打开（验证幂等）', second);
      const ok = first.hasClearance && second.hasClearance
        && String(first.schema) === String(SCHEMA_VERSION)
        && String(second.schema) === String(SCHEMA_VERSION)
        && first.archives === second.archives && first.users === second.users;
      console.log(`\n结论：${ok ? '迁移可用且幂等 ✓' : '存在问题 ✗'}`);
      process.exit(ok ? 0 : 1);
    }

    srcDir = path.resolve(srcDir);
    console.log(`源数据目录（只读，不会被改动）：${srcDir}`);
    const copied = copyDb(srcDir, workDir);
    console.log(`已复制 ${copied} 个文件到临时副本：${workDir}`);

    // 迁移前的状态：直接读副本但先不迁移 —— 用一个只读连接读表结构
    const before = snapshotDirect(path.join(workDir, 'archive.db'), { noMigrate: true });
    report('迁移前（副本原始状态）', before);

    // 触发迁移
    const db = openDatabase(path.join(workDir, 'archive.db'));
    db.close();
    const after = snapshotDirect(path.join(workDir, 'archive.db'));
    report('迁移后', after);

    // 再打开一次，确认幂等
    const db2 = openDatabase(path.join(workDir, 'archive.db'));
    db2.close();
    const again = snapshotDirect(path.join(workDir, 'archive.db'));

    const problems = [];
    if (!after.hasClearance) problems.push('users.clearance 未创建');
    if (String(after.schema) !== String(SCHEMA_VERSION)) problems.push(`schema 版本未升到 ${SCHEMA_VERSION}`);
    if (before.users !== after.users) problems.push(`账号数变化：${before.users} → ${after.users}`);
    if (before.archives !== after.archives) problems.push(`档案数变化：${before.archives} → ${after.archives}`);
    if (again.archives !== after.archives || again.logs !== after.logs) problems.push('重复打开会继续改动数据（迁移不幂等）');
    if (after.logChain && !after.logChain.ok) {
      problems.push(`审计日志链在 id=${after.logChain.brokenAt} 处断开：${after.logChain.reason}`);
    }

    console.log('');
    if (problems.length) {
      console.log('结论：迁移存在问题 ✗');
      for (const p of problems) console.log('  - ' + p);
    } else {
      console.log('结论：迁移成功且幂等 ✓');
      console.log(`  账号 ${after.users} 个、档案 ${after.archives} 条，数量与迁移前一致，未丢失数据。`);
      console.log('  密级上限为空表示「按角色默认」：管理员=机密，档案员=秘密，普通用户=内部，安全审计员=公开。');
    }
    process.exit(problems.length ? 1 : 0);
  } finally {
    if (!keep) {
      try { fs.rmSync(tmpRoot, { recursive: true, force: true }); } catch (_) { /* 忽略 */ }
    } else {
      console.log(`\n临时副本已保留（--keep）：${workDir}`);
    }
  }
}

/**
 * 直接快照。
 *
 * noMigrate=true 时用**原生 sqlite 连接**读，而不是 openDatabase()——
 * 迁移逻辑在 openDatabase() 里，原生连接不会触发它，因此读到的是迁移前的真实状态。
 * 注意不要传 { readOnly: true }：该选项在部分 Node 版本上不被接受会抛错，
 * 一旦被兜底捕获就会报出「迁移前 0 条」这种误导性结果（本项目踩过一次）。
 * 只做 SELECT 不会改动数据；而且本工具操作的是副本，源库始终只读。
 */
function snapshotDirect(dbFile, opts = {}) {
  if (opts.noMigrate) {
    const { DatabaseSync } = require('node:sqlite');
    let db = null;
    try {
      db = new DatabaseSync(dbFile);
      return snapshot(db);
    } catch (e) {
      return {
        error: e.message,
        schema: '（读取失败：' + e.message + '）',
        users: 0, userList: [], archives: 0, boxes: 0, files: 0, loans: 0, logs: 0,
        hasClearance: false, hasArchiveNumber: false, settings: {},
      };
    } finally {
      if (db) db.close();
    }
  }
  const db = openDatabase(dbFile);
  try { return snapshot(db); } finally { db.close(); }
}

main();
