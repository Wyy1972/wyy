/**
 * 档号治理（v4.8.0）验证 —— DA/T 22—2015 §5.4 / DA/T 13—2022
 *
 * 这一版修的是**实测出来的缺陷**，所以本套件也以"实测"为主，而不是读代码断言：
 *
 *   ① **号码只增不回退**：删掉序号最大的那一件后，下一条新档案**不得**复用它的档号。
 *      改之前会复用（实测：建 0001/0002/0003 → 删 0003 → 新建又拿到 0003），
 *      而"档号一经编定不得重复使用"是档案管理的硬原则。
 *   ② **默认模板即现行标准结构**：出厂默认 = DA/T 22—2015 §5.4
 *      「全宗号-档案门类代码·年度-保管期限-机构(问题)代码-件号」。
 *   ③ **空段一律拒绝**：模板某段取不到值时拒绝出号并说清缺哪一项，
 *      不再产出 Z001-HT·2037--CG-0001 这类结构错乱的档号。
 *   ④ **件号在件级整理下真的递增**：早期 {item} 恒为 0001（普通著录不填 item_no），
 *      换成标准模板后连录两条就会撞号。
 *   ⑤ 预览**不占号**；数据体检里能看见档号体检四类问题。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const enc = encodeURIComponent;

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'NB' + Math.random().toString(16).slice(2, 8).toUpperCase();
const YR = '2041';                      // 干净年度，避开演示数据
const STD_TPL = '{unit}-{typeYear}-{retention}-{org}-{item}';   // DA/T 22—2015 §5.4

async function main() {
  const admin = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  // ---- 测试隔离 ----
  // 全局档号模板是**跨套件共享的系统状态**：前面的 selftest-v2 会把它改成旧结构用于自己的用例，
  // 而且不恢复。本套件测的是"出厂默认 = 标准结构"，所以这里自己先把模板设成标准结构，
  // 结束时再还原 —— 不依赖别的套件留下什么，也不给别人留坑。
  const settings0 = await admin.json('/api/settings');
  const savedTpl = settings0.body.ok ? String(settings0.body.data['archive.code_template'] || '') : '';
  await admin.json('/api/settings', {
    method: 'PUT', json: { settings: { 'archive.code_template': STD_TPL, 'archive.unit_code': 'Z001' } },
  });

  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  // 件号/机构(问题)代码要靠分类号的「门类-机构」形式，所以取二级分类
  const leaf = flat.find((c) => c.level === 2 && String(c.code).startsWith('WS-'));
  check('拿到文书档案的二级分类（用于测机构代码段）', !!leaf, leaf && leaf.code);
  if (!leaf) process.exit(1);
  const orgCode = String(leaf.code).split('-')[1];

  // =========================================================================
  section('一、出厂默认模板 = DA/T 22—2015 §5.4 标准结构');
  // =========================================================================
  // 注意：出厂默认来自**代码**（numbering.js），不一定在 settings 表里存了一行 ——
  // 所以判断"当前生效的模板"要问引擎本身（next-code 会把实际用的模板回带）。
  const pv1 = await admin.json(`/api/archives/next-code?type=WS&year=${YR}&category=${leaf.id}`);
  const pv2 = await admin.json(`/api/archives/next-code?type=WS&year=${YR}&category=${leaf.id}`);
  check('预览接口可用', pv1.status === 200 && !!pv1.body.data.archive_number, JSON.stringify(pv1.body).slice(0, 140));
  const tpl = pv1.body.ok ? String(pv1.body.data.template || '') : '';
  check('当前生效的档号模板不是旧的出厂默认',
    !!tpl && tpl !== '{unit}-{category}-{year}-{seq4}', tpl || '(空)');
  check('模板含现行结构五要素（门类·年度 / 保管期限 / 机构代码 / 件号）',
    /\{typeYear\}/.test(tpl) && /\{retention\}/.test(tpl) && /\{org\}/.test(tpl) && /\{item\}/.test(tpl), tpl);

  const tplCheck = await admin.json('/api/settings/check-template', {
    method: 'POST',
    json: { template: tpl, type_code: 'WS', category_id: leaf.id, year: YR, retention: '定期30年' },
  });
  check('模板被判定为符合现行结构（compliant）',
    tplCheck.status === 200 && tplCheck.body.data.valid === true && tplCheck.body.data.compliant === true,
    JSON.stringify(tplCheck.body.data || {}).slice(0, 160));
  check('模板预览能算出完整档号（无空段）',
    /^Z001-WS·\d{4}-D30-[A-Z0-9]+-\d{4}$/.test(tplCheck.body.data.preview || ''),
    tplCheck.body.data.preview);
  check('模板预览未报"有段填不满"',
    Array.isArray(tplCheck.body.data.unfilled) && tplCheck.body.data.unfilled.length === 0,
    JSON.stringify(tplCheck.body.data.unfilled));

  // =========================================================================
  section('二、预览不占号');
  // =========================================================================
  check('连续两次预览给出同一个号（预览不占号）',
    pv1.body.data.archive_number === pv2.body.data.archive_number,
    `${pv1.body.data.archive_number} vs ${pv2.body.data.archive_number}`);
  check('预览号符合标准结构', /^Z001-WS·2041-[A-Z]\d*-[A-Z0-9]+-\d{4}$/.test(pv1.body.data.archive_number),
    pv1.body.data.archive_number);
  check('未传保管期限时回退到门类默认值（与著录同口径）',
    pv1.status === 200 && !!pv1.body.data.archive_number, String(pv1.status));

  // =========================================================================
  section('三、件号在件级整理下真的递增');
  // =========================================================================
  const created = [];
  async function mk(title) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: { type_code: 'WS', category_id: leaf.id, title, year: YR },
    });
    if (r.body && r.body.ok) created.push(r.body.data.id);
    return r;
  }
  const a1 = await mk('档号测试甲' + TAG);
  const a2 = await mk('档号测试乙' + TAG);
  const a3 = await mk('档号测试丙' + TAG);
  check('连建三件都成功', a1.body.ok && a2.body.ok && a3.body.ok,
    [a1, a2, a3].map((x) => x.status).join('/'));
  const n1 = a1.body.data.archive_number; const n2 = a2.body.data.archive_number; const n3 = a3.body.data.archive_number;
  check('三条规范档号互不相同', new Set([n1, n2, n3]).size === 3, [n1, n2, n3].join(' / '));
  check('件号段真的在递增（不是恒为 0001）',
    n1.endsWith('0001') && n2.endsWith('0002') && n3.endsWith('0003'), [n1, n2, n3].join(' / '));
  check('机构(问题)代码段取自分类号',
    n1.includes(`-${orgCode}-`), `${n1}（期望含 -${orgCode}-）`);
  check('门类代码与年度之间用间隔号 ·', n1.includes('WS·' + YR), n1);

  // =========================================================================
  section('四、号码只增不回退（本版修的核心缺陷）');
  // =========================================================================
  const del = await admin.json('/api/archives/' + a3.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('删掉序号最大的那一件', del.status === 200 && del.body.ok, String(del.status));

  const a4 = await mk('档号测试丁' + TAG);
  check('删档后新建成功', a4.body.ok, JSON.stringify(a4.body).slice(0, 160));
  const n4 = a4.body.data.archive_number;
  check('★ 删除后号码**不复用**（新件拿到 0004 而不是 0003）',
    n4.endsWith('0004'), `丁=${n4}，丙曾用=${n3}`);
  check('★ 规范档号整体也不复用', n4 !== n3, `${n4} vs ${n3}`);

  // 把该门类·年度清空后再建一件：号段仍不得回落
  for (const id of [a1.body.data.id, a2.body.data.id, a4.body.data.id]) {
    await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  const a5 = await mk('档号测试戊' + TAG);
  check('清空该门类·年度后新建仍成功', a5.body.ok, JSON.stringify(a5.body).slice(0, 160));
  check('★ 全部删除后号段仍不回退（戊拿到 0005）',
    String(a5.body.data.archive_number).endsWith('0005'), a5.body.data.archive_number);

  // =========================================================================
  section('五、空段档号一律拒绝');
  // =========================================================================
  // 制造一个"机构(问题)代码取不到值"的真实场景：分类号写成「WS-」（尾随短横），
  // 按 orgFromCategory 的规则，取"第一个短横之后"得到的就是空字符串。
  // 这正是现实中录错分类号的样子 —— 早期它只会默默生成 Z001-WS·2041-Y--0001。
  const newCat = await admin.json('/api/categories', {
    method: 'POST', json: { parent_id: leaf.parent_id, name: '空段测试' + TAG, code: 'WS-' },
  });
  const noCodeCatId = newCat.body && newCat.body.ok ? newCat.body.data.id : 0;
  check('可以建出"分类号尾部是短横"的分类（用于复现空段场景）', !!noCodeCatId,
    JSON.stringify(newCat.body).slice(0, 160));

  let gap = null;
  if (noCodeCatId) {
    gap = await admin.json('/api/archives', {
      method: 'POST',
      json: { type_code: 'WS', category_id: noCodeCatId, title: '空段档号测试' + TAG, year: YR },
    });
    check('★ 该分类下著录被拒绝（不再产出空段档号）', gap.status === 400, String(gap.status));
    check('★ 拒绝原因点名了缺的是机构(问题)代码',
      gap.body && /机构/.test(gap.body.error || ''), gap.body && gap.body.error);
    check('拒绝时没有写入任何档案', !(gap.body && gap.body.data), JSON.stringify(gap.body && gap.body.data));
  }

  // =========================================================================
  section('六、标准模板下各种档案都能正常出号');
  // =========================================================================
  const otherCat = flat.find((c) => c.level === 2 && String(c.code).startsWith('HT-'));
  if (otherCat) {
    const ht = await admin.json('/api/archives', {
      method: 'POST',
      json: { type_code: 'HT', category_id: otherCat.id, title: '档号测试合同' + TAG, year: YR, retention: '定期30年' },
    });
    check('另一门类（合同）也能出标准档号', ht.body.ok, JSON.stringify(ht.body).slice(0, 160));
    if (ht.body.ok) {
      created.push(ht.body.data.id);
      check('合同档案档号含 D30 段',
        String(ht.body.data.archive_number).includes('-D30-'), ht.body.data.archive_number);
    }
  }

  // =========================================================================
  section('七、数据体检里的「档号体检」');
  // =========================================================================
  const scan = await admin.json('/api/quality/scan?limit=10');
  check('体检接口可用', scan.status === 200 && Array.isArray(scan.body.data.problems), String(scan.status));
  const types = (scan.body.data.problems || []).map((p) => p.type);
  for (const t of ['number_missing', 'number_duplicate', 'number_malformed', 'number_gap']) {
    check(`体检含规则 ${t}`, types.includes(t), types.join(','));
  }
  const gapRule = (scan.body.data.problems || []).find((p) => p.type === 'number_gap');
  check('断号规则给了"不得回填"的说明',
    !!gapRule && /不得回填|不要回填/.test(gapRule.hint || ''), gapRule && gapRule.hint);
  const gapOnly = await admin.json('/api/quality/scan?only=number_gap&limit=5');
  check('only 过滤能只取档号断号',
    gapOnly.status === 200 && (gapOnly.body.data.problems || []).every((p) => p.type === 'number_gap'),
    JSON.stringify((gapOnly.body.data.problems || []).map((p) => p.type)));

  // =========================================================================
  section('八、收尾');
  // =========================================================================
  for (const id of created.concat(a5.body.ok ? [a5.body.data.id] : [])) {
    await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  if (noCodeCatId) await admin.json('/api/categories/' + noCodeCatId, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  // 还原本套件开始时看到的模板，不给后续套件留坑
  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'archive.code_template': savedTpl } } });
  const back = await admin.json('/api/settings');
  check('清理：全局档号模板已还原',
    back.body.ok && String(back.body.data['archive.code_template'] || '') === savedTpl,
    String(back.body.ok ? back.body.data['archive.code_template'] : ''));
  const left = await admin.json('/api/archives?kw=' + enc(TAG) + '&size=50');
  check('清理：没有残留测试档案',
    left.body.ok && (left.body.data.list || []).length === 0,
    String(left.body.ok ? (left.body.data.list || []).length : left.status));

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
