/**
 * 删除留痕 · 回收站（v4.22.0）
 *
 * 为什么这件事在本系统里格外要紧：档号**不复用**（v4.8.0 档号治理），
 * 而在此之前删除是**不可逆**的 —— 手一抖，档案行和物理附件一起没了。
 *
 * 本套件要钉住的是"可逆"这件事的每一环，尤其是三条最容易做错的：
 *   ① 删除后**物理附件必须还在**（否则回收站只是一堆空壳）；
 *   ② 恢复后**档号必须与删除前完全一致**（档号不复用，恢复的必须是同一个号）；
 *   ③ 恢复时若原 id 已被新档案占用，必须**改写附件归属**而不是串到别人身上。
 *
 * 用法：node server/tools/test-trash.js [http://127.0.0.1:8796] [数据目录]
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

function multipart(fields, files) {
  const b = '----trash' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.from(f.data, 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${b}--\r\n`, 'utf8'));
  return { contentType: 'multipart/form-data; boundary=' + b, body: Buffer.concat(parts) };
}

/**
 * 按 sha256 找到附件的物理文件。
 *
 * v4.28.0 起附件不再"文件名=sha256"，而是按档号落盘（归档/…/<档号>.pdf），
 * 所以先读库里的 files.rel_path —— 那是唯一真相；只有老库（老布局）才回退去按 sha 扫目录。
 * 说明：档案详情接口不暴露内部路径（合理），但测试就在本机，直连测试库读得到。
 */
function findBySha(root, sha) {
  if (!sha) return '';
  try {
    const { DatabaseSync } = require('node:sqlite');
    const d = new DatabaseSync(path.join(DATA_DIR, 'archive.db'), { readOnly: true });
    const row = d.prepare('SELECT rel_path FROM files WHERE sha256=?').get(sha);
    d.close();
    if (row && row.rel_path) {
      const p = path.join(root, String(row.rel_path).replace(/\//g, path.sep));
      if (fs.existsSync(p)) return p;
    }
  } catch (_) { /* 读不到库就走老办法 */ }
  if (!fs.existsSync(root)) return '';
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { continue; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) stack.push(p);
      else if (e.name.startsWith(sha)) return p;
    }
  }
  return '';
}

const TAG = 'TRASH' + Math.random().toString(16).slice(2, 8).toUpperCase();
const MARK = 'TRASHMARK-' + TAG;

async function main() {
  const admin = makeSession();
  const staff = makeSession();   // 「其他人员」= reader，只查阅

  const login = await admin.json('/api/login', { method: 'POST', json: { identity: 'manager', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, JSON.stringify(login.body).slice(0, 140));
  // 演示数据里 reader 账号口令统一 123456（与 run-all 的演示数据一致）
  const staffLogin = await staff.json('/api/login', { method: 'POST', json: { identity: 'staff', password: '123456' } });
  check('「其他人员」登录成功（用于权限对照）', staffLogin.status === 200 && staffLogin.body.ok,
    JSON.stringify(staffLogin.body).slice(0, 140));

  // ---------- 造一条带附件的档案 ----------
  section('夹具 · 带附件的档案');
  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const cat = flat.find((c) => c.code === 'WS-XZ') || flat.find((c) => c.id && c.code) || flat[0] || {};
  check('取到档案分类（夹具前提）', !!cat.id, JSON.stringify(cats.body).slice(0, 200));
  const made = await admin.json('/api/archives', {
    method: 'POST', json: { type_code: 'WS', category_id: cat.id, title: '回收站验证件' + TAG },
  });
  check('新建档案成功', made.status === 200 && made.body.ok, JSON.stringify(made.body).slice(0, 200));
  if (!made.body || !made.body.ok) { finish('夹具失败，后续断言无法进行'); return; }
  const aid = made.body.data.id;
  const code0 = made.body.data.archive_code;

  const mp = multipart({ kind: '正文' }, [{ filename: '回收站附件.txt', data: MARK }]);
  const up = await admin.req(`/api/archives/${aid}/files`, { method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body });
  const upText = await up.text();
  check('上传附件成功', up.status === 200, `status=${up.status} body=${upText.slice(0, 220)}`);

  const before = await admin.json('/api/archives/' + aid);
  const file0 = (before.body.data && before.body.data.files ? before.body.data.files[0] : null) || {};
  check('档案详情里能看到这个附件', !!file0.id,
    'files=' + JSON.stringify((before.body.data && before.body.data.files) || []).slice(0, 160));
  const sha0 = file0.sha256 || '';
  const abs0 = findBySha(path.join(DATA_DIR, 'files'), sha0);
  check('附件物理文件已落盘（夹具前提）', !!sha0 && !!abs0, 'sha=' + String(sha0).slice(0, 12) + ' file=' + abs0);

  // ---------- 删除 → 进回收站 ----------
  section('删除 · 移入回收站');
  const del = await admin.json('/api/archives/' + aid, { method: 'DELETE', json: { reason: '分类录错，重新著录' } });
  check('删除返回"已入回收站"', del.status === 200 && del.body.ok && del.body.data.trashed === true,
    JSON.stringify(del.body.data || del.body).slice(0, 180));
  check('删除原因已留痕（未标记为未填写）', del.body.data && del.body.data.reasonMissing === false,
    'reasonMissing=' + (del.body.data && del.body.data.reasonMissing));
  check('**物理附件仍然保留**（回收站不能是空壳）', fs.existsSync(abs0), abs0);
  check('档案已不在 archives 里', (await admin.json('/api/archives/' + aid)).status === 404);

  const tr = await admin.json('/api/trash');
  const row = ((tr.body.data && tr.body.data.list) || []).find((x) => x.archive_code === code0);
  check('回收站列表里能找到这条', !!row, JSON.stringify(tr.body).slice(0, 200));
  if (row) {
    check('原因如实保留', row.reason === '分类录错，重新著录', String(row.reason));
    check('带删除人', !!row.deleted_by_name, String(row.deleted_by_name || ''));
    check('给出剩余保留天数', typeof row.days_left === 'number', 'days_left=' + row.days_left);
  } else {
    check('原因如实保留', false, '无条目'); check('带删除人', false, '无条目'); check('给出剩余保留天数', false, '无条目');
  }

  // ---------- 恢复 ----------
  section('恢复 · 档号必须一模一样');
  const rs = row ? await admin.json(`/api/trash/${row.id}/restore`, { method: 'POST' }) : { status: 0, body: {} };
  check('恢复成功', rs.status === 200 && rs.body.ok, JSON.stringify(rs.body).slice(0, 200));
  const backId = rs.body.data ? rs.body.data.id : 0;
  const back = await admin.json('/api/archives/' + backId);
  check('档案回到原位', back.status === 200, 'status=' + back.status);
  if (back.status === 200) {
    const a = back.body.data;
    check('**档号与删除前完全一致**（档号不复用）', a.archive_code === code0, `${code0} → ${a.archive_code}`);
    const f = (a.files || [])[0] || {};
    check('附件记录一并恢复', !!f.id, JSON.stringify(f).slice(0, 140));
    check('恢复后 sha256 与删除前一致（文件没被换过）', f.sha256 === sha0, `${String(sha0).slice(0, 12)} → ${String(f.sha256).slice(0, 12)}`);
    check('附件物理文件仍在', !!findBySha(path.join(DATA_DIR, 'files'), sha0), abs0);
    // 「有没有串档」直接查库判定：接口不一定回 archive_id，
    // 拿一个"字段为空就算过"的断言等于没测 —— 那种假绿比红更危险。
    let dbRow = null;
    try {
      const { DatabaseSync } = require('node:sqlite');
      const d = new DatabaseSync(path.join(DATA_DIR, 'archive.db'), { readOnly: true });
      dbRow = d.prepare('SELECT archive_id, rel_path FROM files WHERE sha256=?').get(sha0);
      d.close();
    } catch (e) { dbRow = { error: e.message }; }
    check('**附件在库里指向恢复后的档案（没有串档）**',
      !!dbRow && Number(dbRow.archive_id) === Number(a.id),
      `db.archive_id=${dbRow && dbRow.archive_id} archive.id=${a.id}`);
  } else {
    for (const n of ['**档号与删除前完全一致**（档号不复用）', '附件记录一并恢复', '附件物理文件仍在且大小一致', '**附件指向恢复后的档案（没有串档）**']) check(n, false, '恢复失败');
  }
  const tr2 = await admin.json('/api/trash');
  check('恢复后回收站条目消失', ((tr2.body.data && tr2.body.data.list) || []).every((x) => x.archive_code !== code0));

  // ---------- 权限 ----------
  // 注意：主流程已经恢复过一遍，回收站此刻可能是空的，所以要**另造一条**来测权限，
  // 不能拿"空列表"当通过（上一版就是这么漏过去的）。
  section('权限 · 其他人员一律不行');
  const made2 = await admin.json('/api/archives', {
    method: 'POST', json: { type_code: 'WS', category_id: cat.id, title: '回收站权限靶件' + TAG },
  });
  const aid2 = made2.body && made2.body.ok ? made2.body.data.id : 0;
  const del2a = aid2 ? await admin.json('/api/archives/' + aid2, { method: 'DELETE', json: { reason: '权限靶件' } }) : { status: 0, body: {} };
  const row2 = ((await admin.json('/api/trash')).body.data.list || []).find((x) => x.id === del2a.body.data.trashId);
  check('权限靶件已入回收站（夹具前提）', !!row2, JSON.stringify(del2a.body.data || {}).slice(0, 140));

  const staffDel = await staff.json('/api/archives/' + backId, { method: 'DELETE', json: { reason: '试试' } });
  check('其他人员不能删除档案', staffDel.status === 403, 'status=' + staffDel.status);
  check('其他人员看不到回收站', (await staff.json('/api/trash')).status === 403);
  if (row2) {
    const st = await staff.json(`/api/trash/${row2.id}/restore`, { method: 'POST' });
    check('其他人员不能恢复', st.status === 403, 'status=' + st.status);
    const sp = await staff.json(`/api/trash/${row2.id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    check('其他人员不能彻底清除', sp.status === 403, 'status=' + sp.status);
    // 收尾：把靶件彻底清掉，确认它还在（没被上面那几次越权请求动过）
    const stillThere = ((await admin.json('/api/trash')).body.data.list || []).some((x) => x.id === row2.id);
    check('越权尝试没有真的动到这条记录', stillThere);
    await admin.json(`/api/trash/${row2.id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  } else {
    check('其他人员不能恢复', false, '靶件未入回收站');
    check('其他人员不能彻底清除', false, '靶件未入回收站');
    check('越权尝试没有真的动到这条记录', false, '靶件未入回收站');
  }

  // ---------- 无原因删除（过渡期行为） ----------
  section('删除原因必填 · 服务端硬拒');
  // v4.22.1 起服务端**硬拒**无原因删除（界面一直是必填，现在接口也绕不过去）。
  // 这一条同时验证"拒绝之后档案没有被半途移走" —— 拒绝必须是干净的。
  const delNoReason = await admin.json('/api/archives/' + backId, { method: 'DELETE' });
  check('无原因删除被拒（400）', delNoReason.status === 400,
    'status=' + delNoReason.status + ' ' + JSON.stringify(delNoReason.body).slice(0, 140));
  check('被拒之后档案还在（没有半途移走）', (await admin.json('/api/archives/' + backId)).status === 200);
  const delWithReason = await admin.json('/api/archives/' + backId, { method: 'DELETE', json: { reason: '重复录入' } });
  check('带上原因才允许删除', delWithReason.status === 200 && delWithReason.body.data.trashed === true,
    JSON.stringify(delWithReason.body.data || delWithReason.body).slice(0, 160));
  const warnRow = ((await admin.json('/api/trash')).body.data.list || []).find((x) => x.archive_code === code0);
  check('原因如实留痕', !!warnRow && warnRow.reason === '重复录入', String(warnRow && warnRow.reason));

  // ---------- 彻底清除 ----------
  section('彻底清除 · 物理文件此时才删');
  const purge = warnRow ? await admin.json(`/api/trash/${warnRow.id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } }) : { status: 0, body: {} };
  check('彻底清除成功', purge.status === 200 && purge.body.ok, JSON.stringify(purge.body).slice(0, 160));
  check('物理附件此时才被删除', !fs.existsSync(abs0), abs0);
  check('回收站条目消失', ((await admin.json('/api/trash')).body.data.list || []).every((x) => x.archive_code !== code0));
  const logs = await admin.json('/api/logs?kw=' + encodeURIComponent(code0));
  const logText = JSON.stringify(logs.body).slice(0, 4000);
  check('审计日志里留下过删除留痕（档号可查）', logText.includes(code0), logText.slice(0, 200));

  finish();
}

function finish(note) {
  console.log('\n────────────────────────────────────────');
  if (note) console.log(note);
  if (fails.length) { console.log('失败明细：'); for (const f of fails) console.log('  - ' + f); }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e)); process.exit(1); });
