/**
 * 合规回归测试：档案实体（装盒）一致性
 *
 * 用法：node server/tools/test-compliance.js [http://127.0.0.1:8796]
 *
 * 覆盖：
 *   1. 装盒一致性校验 —— 不同年度 / 保管期限 / 机构(问题) / 门类 不得同盒（DA/T 22—2015 §6.4）
 *   2. 兼容性预检接口与装盒接口判定一致
 *   3. 盒容量约束
 *   4. 空盒装盒后自动补齐盒属性（年度/保管期限/机构），使盒脊打印有依据
 *   5. 改盒属性不得与盒内档案冲突
 *   6. 校验开关（box.enforce_mix）可关闭，关闭后允许混装
 *   7. 数据体检能清查历史遗留的混装盒
 *   8. 装盒受密级约束（看不到的档案不能装盒）
 *
 * 脚本结束时恢复设置、清理自己创建的档案与盒，可重复运行。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  return { req, json };
}

/** 收集分类节点（取两个不同 code 的，用于构造「机构(问题)」差异） */
function collectCats(node, out = []) {
  if (!node || typeof node !== 'object') return out;
  if (Array.isArray(node)) { for (const n of node) collectCats(n, out); return out; }
  if (typeof node.id === 'number' && node.code) out.push({ id: node.id, code: String(node.code), name: String(node.name || '') });
  for (const v of Object.values(node)) if (v && typeof v === 'object') collectCats(v, out);
  return out;
}

const TAG = 'BOX' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { archives: [], boxes: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);

  const cats = await admin.json('/api/categories');
  const all = collectCats(cats.body.data);
  // 优先取二级分类（代码形如 WS-XZ）：它的后半段就是「机构(问题)代码」，
  // 与档号结构里的那一节对应；只取到顶级分类代码（WS）时校验意义不大。
  const sub = all.filter((c) => c.code.includes('-'));
  const c1 = sub[0] || all[0];
  const c2 = sub.find((c) => c.code !== (c1 && c1.code)) || all.find((c) => c.code !== (c1 && c1.code));
  check('取到两个不同分类（模拟不同机构/问题）', !!(c1 && c2), JSON.stringify([c1 && c1.code, c2 && c2.code]));

  async function makeArchive(opts) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: {
        type_code: 'WS', category_id: opts.catId, title: `${TAG} ${opts.label}`,
        secret_level: opts.secret || '公开', retention: opts.retention || '定期10年',
        year: opts.year || '2026', archive_date: `${opts.year || '2026'}-01-01`,
      },
    });
    if (r.body.ok) created.archives.push(r.body.data.id);
    return r.body.ok ? r.body.data.id : 0;
  }

  const idBase = await makeArchive({ catId: c1.id, label: '基准件 2026 定期10年' });
  const idSame = await makeArchive({ catId: c1.id, label: '兼容件 2026 定期10年' });
  const idYear = await makeArchive({ catId: c1.id, label: '年度不符 2025', year: '2025' });
  const idRet = await makeArchive({ catId: c1.id, label: '期限不符 定期30年', retention: '定期30年' });
  const idOrg = await makeArchive({ catId: c2.id, label: '机构不符' });
  check('夹具档案创建完成（5 件）', [idBase, idSame, idYear, idRet, idOrg].every(Boolean),
    [idBase, idSame, idYear, idRet, idOrg].join(','));

  async function makeBox(opts) {
    const r = await admin.json('/api/boxes', {
      method: 'POST',
      json: Object.assign({
        box_code: `${TAG}-${opts.suffix}`, title: `${TAG} ${opts.suffix}`,
        type_code: 'WS', capacity: 10,
      }, opts.fields || {}),
    });
    if (r.body.ok) created.boxes.push(r.body.data.id);
    return r.body.ok ? r.body.data.id : 0;
  }

  const boxId = await makeBox({
    suffix: 'A',
    fields: { year: '2026', retention: '定期10年', org_code: c1.code },
  });
  check('基准档案盒创建成功', !!boxId);

  // ---------- 1. 装盒一致性 ----------
  section('装盒一致性校验（DA/T 22—2015 §6.4）');
  const asgBase = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idBase] } });
  check('装入同年度/同期限/同机构的档案 → 成功', asgBase.body.ok && asgBase.body.data.assigned === 1,
    JSON.stringify(asgBase.body).slice(0, 160));

  const asgYear = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idYear] } });
  check('装入不同年度的档案 → 被拒绝', asgYear.status === 400, 'status=' + asgYear.status);
  check('拒绝原因指明是「年度」不一致', /年度/.test(JSON.stringify(asgYear.body)), JSON.stringify(asgYear.body).slice(0, 200));
  check('拒绝码为 BOX_MIX（便于前端与外部系统识别）',
    asgYear.body && asgYear.body.code === 'BOX_MIX', String(asgYear.body && asgYear.body.code));
  check('错误文案引用了标准依据', /DA\/T 22/.test(JSON.stringify(asgYear.body)));

  const asgRet = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idRet] } });
  check('装入不同保管期限的档案 → 被拒绝', asgRet.status === 400, 'status=' + asgRet.status);
  check('拒绝原因指明是「保管期限」不一致', /保管期限/.test(JSON.stringify(asgRet.body)));

  const asgOrg = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idOrg] } });
  check('装入不同机构(问题)的档案 → 被拒绝', asgOrg.status === 400, 'status=' + asgOrg.status);
  check('拒绝原因指明是「机构(问题)」不一致', /机构/.test(JSON.stringify(asgOrg.body)));

  const asgSame = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idSame] } });
  check('装入完全一致的档案 → 成功', asgSame.body.ok && asgSame.body.data.assigned === 1);

  // ---------- 2. 兼容性预检 ----------
  section('装盒兼容性预检');
  const preOk = await admin.json(`/api/boxes/${boxId}/compat?archive_ids=${idSame}`);
  check('预检：兼容档案 compatible=true', preOk.body.data && preOk.body.data.compatible === true,
    JSON.stringify(preOk.body).slice(0, 200));
  const preBad = await admin.json(`/api/boxes/${boxId}/compat?archive_ids=${idSame},${idYear}`);
  check('预检：含不兼容档案 compatible=false', preBad.body.data && preBad.body.data.compatible === false,
    JSON.stringify(preBad.body.data || {}).slice(0, 200));
  check('预检：逐条给出不兼容原因',
    Array.isArray(preBad.body.data.bad) && preBad.body.data.bad.length === 1
    && /年度/.test(preBad.body.data.bad[0].reason),
    JSON.stringify(preBad.body.data && preBad.body.data.bad).slice(0, 200));
  check('预检：返回基准属性供界面提示',
    preBad.body.data.canon && preBad.body.data.canon.year === '2026',
    JSON.stringify(preBad.body.data && preBad.body.data.canon));

  // ---------- 3. 容量 ----------
  section('盒容量约束');
  // 容量测试用**专用档案**：一份档案只能在一个盒里。若复用 boxId 里的档案，
  // 第二次装盒等于把它从原盒移走，后面针对 boxId 的断言就会莫名失败（本项目踩过一次）。
  const idCapA = await makeArchive({ catId: c1.id, label: '容量测试 A' });
  const idCapB = await makeArchive({ catId: c1.id, label: '容量测试 B' });
  const boxCap = await makeBox({ suffix: 'CAP', fields: { capacity: 1, year: '2026', retention: '定期10年', org_code: c1.code } });
  const cap1 = await admin.json(`/api/boxes/${boxCap}/assign`, { method: 'POST', json: { archive_ids: [idCapA] } });
  check('容量 1 的盒装入第 1 件 → 成功', cap1.body.ok, JSON.stringify(cap1.body).slice(0, 160));
  const cap2 = await admin.json(`/api/boxes/${boxCap}/assign`, { method: 'POST', json: { archive_ids: [idCapB] } });
  check('容量 1 的盒再装第 2 件 → 被拒绝', cap2.status === 400, 'status=' + cap2.status);
  check('拒绝原因说明超出容量', /容量/.test(JSON.stringify(cap2.body)), JSON.stringify(cap2.body).slice(0, 160));

  // ---------- 4. 空盒属性补齐 ----------
  section('空盒装盒后自动补齐盒属性');
  const boxAdopt = await makeBox({ suffix: 'ADOPT', fields: { capacity: 10 } });   // 不声明年度/期限/机构
  await admin.json(`/api/boxes/${boxAdopt}/assign`, { method: 'POST', json: { archive_ids: [idOrg] } });
  const boxesAfter = await admin.json(`/api/boxes?kw=${TAG}-ADOPT`);
  const adoptRow = (boxesAfter.body.data.list || [])[0] || {};
  check('盒的年度被自动补齐', adoptRow.year === '2026', String(adoptRow.year));
  check('盒的保管期限被自动补齐', adoptRow.retention === '定期10年', String(adoptRow.retention));
  check('盒的机构(问题)被自动补齐', adoptRow.org_code === c2.code, `${adoptRow.org_code} vs ${c2.code}`);

  // ---------- 5. 改盒属性冲突 ----------
  section('修改盒属性不得与盒内档案冲突');
  const putBad = await admin.json(`/api/boxes/${boxId}`, {
    method: 'PUT',
    json: { box_code: `${TAG}-A`, title: `${TAG} A`, type_code: 'WS', year: '2025', retention: '定期10年', org_code: c1.code, capacity: 10 },
  });
  check('把有内容的盒改成不一致的年度 → 被拒绝', putBad.status === 400, 'status=' + putBad.status);
  check('拒绝原因说明与盒内档案冲突', /盒内已有/.test(JSON.stringify(putBad.body)), JSON.stringify(putBad.body).slice(0, 160));
  const putCap = await admin.json(`/api/boxes/${boxId}`, {
    method: 'PUT',
    json: { box_code: `${TAG}-A`, title: `${TAG} A`, type_code: 'WS', year: '2026', retention: '定期10年', org_code: c1.code, capacity: 1 },
  });
  check('把盒容量改到小于盒内件数 → 被拒绝', putCap.status === 400, 'status=' + putCap.status);
  const putOk = await admin.json(`/api/boxes/${boxId}`, {
    method: 'PUT',
    json: { box_code: `${TAG}-A`, title: `${TAG} A 改名`, type_code: 'WS', year: '2026', retention: '定期10年', org_code: c1.code, capacity: 10 },
  });
  check('保持一致的修改 → 成功', putOk.body.ok, JSON.stringify(putOk.body).slice(0, 120));

  // ---------- 6. 开关可关闭 ----------
  section('校验开关可关闭（可逆）');
  const off = await admin.json('/api/settings', { method: 'PUT', json: { 'box.enforce_mix': '0' } });
  check('关闭装盒一致性校验', off.body.ok && off.body.data.changed.includes('box.enforce_mix'),
    JSON.stringify(off.body).slice(0, 160));
  const mixedAssign = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [idYear] } });
  check('关闭后允许混装（历史整理方式确有例外）', mixedAssign.body.ok, JSON.stringify(mixedAssign.body).slice(0, 160));

  const invalidSetting = await admin.json('/api/settings', { method: 'PUT', json: { 'box.enforce_mix': 'yes' } });
  check('开关只接受 0/1，传 yes 被拒绝', invalidSetting.status === 400, 'status=' + invalidSetting.status);

  const backOn = await admin.json('/api/settings', { method: 'PUT', json: { 'box.enforce_mix': '1' } });
  check('重新开启装盒一致性校验', backOn.body.ok);

  // ---------- 7. 数据体检清查历史混装 ----------
  section('数据体检 · 历史混装清查');
  const scan = await admin.json('/api/quality/scan');
  const mixed = (scan.body.data.problems || []).find((p) => p.type === 'mixed_box');
  check('体检结果包含「档案盒混装」检查项', !!mixed, JSON.stringify((scan.body.data.problems || []).map((p) => p.type)));
  check('能查出刚才制造的混装盒', mixed && mixed.count >= 1, String(mixed && mixed.count));
  check('混装样本给出盒号与差异维度',
    mixed && mixed.samples.some((s) => String(s.title).includes('种')),
    JSON.stringify(mixed && mixed.samples).slice(0, 200));

  // ---------- 8. 装盒受密级约束 ----------
  section('装盒受密级约束');
  const secretId = await makeArchive({ catId: c1.id, label: '涉密件', secret: '机密' });
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_r`, display_name: TAG, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  const readerId = mk.body.ok ? mk.body.data.id : 0;
  const reader = makeSession();
  const rl = await reader.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_r`, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  check('低密级账号登录成功', rl.body.ok);
  const readerAssign = await reader.json(`/api/boxes/${boxAdopt}/assign`, { method: 'POST', json: { archive_ids: [secretId] } });
  check('低密级账号不能把涉密档案装盒', readerAssign.status === 403 || readerAssign.status === 404,
    'status=' + readerAssign.status);

  // ---------- 9. 档号结构（DA/T 22—2015 / DA/T 13—2022）----------
  section('档号结构（DA/T 22—2015 / DA/T 13—2022）');
  const tplStd = '{unit}-{typeYear}-{retention}-{org}-{item}';
  const tplLegacy = '{unit}-{category}-{catalog}-{volume}-{item}';

  const tplInfo = await admin.json('/api/settings/check-template', {
    method: 'POST',
    json: { template: tplStd, type_code: 'WS', category_id: c1.id, year: '2026', retention: '定期30年' },
  });
  const ti = tplInfo.body.data || {};
  check('校验接口接受 DA/T 22—2015 标准模板', ti.valid === true, JSON.stringify(ti).slice(0, 160));
  check('预览结果含保管期限代码与门类·年度',
    /-D30-/.test(ti.preview || '') && /·2026/.test(ti.preview || ''), String(ti.preview));
  check('标准模板被判为 compliant', ti.compliant === true);
  check('接口返回标准结构与预设模板',
    typeof ti.structure === 'string' && !!(ti.presets && ti.presets.dat22), JSON.stringify(ti.presets));

  const tplBad = await admin.json('/api/settings/check-template', {
    method: 'POST', json: { template: '{unit}-{typeYear}-{year}-{item}', type_code: 'WS', category_id: c1.id },
  });
  check('同时写 typeYear 与 year 被判为非法（年度会重复）', tplBad.body.data.valid === false,
    JSON.stringify(tplBad.body.data || {}).slice(0, 160));

  const legacyInfo = await admin.json('/api/settings/check-template', {
    method: 'POST', json: { template: tplLegacy, type_code: 'WS', category_id: c1.id, year: '2026' },
  });
  const li = legacyInfo.body.data || {};
  check('旧案卷级模板仍可通过校验（不阻断既有单位）', li.valid === true);
  check('旧模板被判为不符合现行结构', li.compliant === false);
  check('旧模板给出标准符合性提示', Array.isArray(li.warnings) && li.warnings.length > 0,
    JSON.stringify(li.warnings || []));
  check('提示里点明缺少「保管期限」并给出标准模板',
    /保管期限/.test((li.warnings || []).join('')) && (li.warnings || []).join('').includes(tplStd));

  // 端到端：切到标准模板后新建档案，档号必须符合该结构
  const settingsBefore = (await admin.json('/api/settings')).body.data.settings;
  const curTpl = settingsBefore['archive.code_template'];
  const setTpl = await admin.json('/api/settings', { method: 'PUT', json: { 'archive.code_template': tplStd } });
  check('切换到标准档号模板', setTpl.body.ok, JSON.stringify(setTpl.body).slice(0, 160));

  const stdArch = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', category_id: c1.id, title: `${TAG} 标准档号件`, secret_level: '公开',
      retention: '定期30年', year: '2026', archive_date: '2026-01-01',
    },
  });
  if (stdArch.body.ok) created.archives.push(stdArch.body.data.id);
  const stdNumber = stdArch.body.ok ? stdArch.body.data.archive_number : '';
  // 机构(问题)代码的推导规则：分类号去掉「门类-」前缀
  const expectOrg = c1.code.includes('-') ? c1.code.slice(c1.code.indexOf('-') + 1) : c1.code;
  const stdRe = new RegExp(`^Z001-WS·2026-D30-${expectOrg}-\\d{4}$`);
  check('新建档案的档号符合 DA/T 22—2015 结构', stdRe.test(stdNumber), stdNumber);
  check('档号内确实带上了保管期限代码 D30', stdNumber.includes('-D30-'), stdNumber);

  await admin.json('/api/settings', { method: 'PUT', json: { 'archive.code_template': curTpl } });
  const restoredTpl = (await admin.json('/api/settings')).body.data.settings['archive.code_template'];
  check('档号模板已还原', restoredTpl === curTpl, `${restoredTpl} vs ${curTpl}`);

  // ---------- 清理 ----------
  section('清理');
  if (readerId) await admin.json(`/api/users/${readerId}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  let aCleaned = 0;
  for (const id of created.archives) {
    const r = await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) aCleaned++;
  }
  check(`测试档案已清理（${aCleaned}/${created.archives.length}）`, aCleaned === created.archives.length);
  let bCleaned = 0;
  for (const id of created.boxes) {
    await admin.json(`/api/boxes/${id}/remove`, { method: 'POST', json: { archive_ids: created.archives } });
    const r = await admin.json(`/api/boxes/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.body && r.body.ok) bCleaned++;
  }
  check(`测试档案盒已清理（${bCleaned}/${created.boxes.length}）`, bCleaned === created.boxes.length);
  const restored = await admin.json('/api/settings', { method: 'PUT', json: { 'box.enforce_mix': '1' } });
  check('设置已恢复为默认（校验开启）', restored.body.ok);

  console.log(`\n档案实体合规回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n合规测试异常终止：', e); process.exit(1); });
