/**
 * 二维码「扫码链路」端到端验证。
 *
 * 用户的反馈是「二维码扫不出来」。这个说法背后其实是三种完全不同的故障，
 * 必须分开测，否则修了一种、另一种还在：
 *   ① 二维码图案本身不合规 —— 任何手机都扫不出（格式信息位序、静区不足）
 *   ② 二维码内容是手机打不开的地址 —— 能扫出字，但打不开（127.0.0.1）
 *   ③ 服务没开局域网 —— 地址对，但手机连不上
 * 本脚本针对 ①② 做自动化验证；③ 由服务启动横幅与「扫码自检」面板负责提示。
 *
 * 用法：node server/tools/test-qr-net.js [http://127.0.0.1:8899]
 * 需要一个已启动的服务（库里有至少一个档案盒）。
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { decodeFile } = require('./qr-decode');
const { matrixToBmp } = require('./qr-render');

const BASE = process.argv[2] || 'http://127.0.0.1:8899';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(p, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + p, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(p, opts) {
    const res = await req(p, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  return { req, json };
}

/**
 * 把二维码 SVG 还原成模块矩阵。
 *
 * 这里刻意不依赖生成端的任何内部结构，只看渲染出来的几何：
 * 模块边长 = 最小的黑色方块边长；静区 = 最靠左上的黑格坐标 / 模块边长。
 * 左上角模块（定位图案外角）一定是黑的，所以这个推算对合规二维码成立。
 */
function svgToMatrix(svg) {
  const wm = /<svg[^>]*\swidth="(\d+(?:\.\d+)?)"/.exec(svg);
  if (!wm) throw new Error('SVG 缺少 width');
  const dim = Number(wm[1]);
  const rects = [...svg.matchAll(/<rect x="(-?\d+(?:\.\d+)?)" y="(-?\d+(?:\.\d+)?)" width="(\d+(?:\.\d+)?)" height="(\d+(?:\.\d+)?)"/g)]
    .map((m) => ({ x: Number(m[1]), y: Number(m[2]), w: Number(m[3]), h: Number(m[4]) }));
  if (!rects.length) throw new Error('SVG 中没有任何黑色模块');
  const scale = Math.min(...rects.map((r) => r.w));
  if (!Number.isFinite(scale) || scale <= 0) throw new Error('无法推算模块边长');
  const margin = Math.min(...rects.map((r) => r.x)) / scale;
  const n = Math.round(dim / scale - margin * 2);
  if (!Number.isInteger(n) || n <= 0) throw new Error(`模块数推算失败 dim=${dim} scale=${scale} margin=${margin}`);
  const modules = Array.from({ length: n }, () => new Array(n).fill(0));
  for (const r of rects) {
    const mx = Math.round(r.x / scale - margin);
    const my = Math.round(r.y / scale - margin);
    if (mx < 0 || my < 0 || mx >= n || my >= n) throw new Error('黑格落在模块区之外，说明静区/边长推算有误');
    modules[my][mx] = 1;
  }
  return { modules, size: n, margin, scale, dim };
}

/** 矩阵 → BMP → 独立解码器 */
function decodeMatrix(m) {
  const tmp = path.join(os.tmpdir(), `qrnet-${process.pid}-${Math.random().toString(16).slice(2)}.bmp`);
  try {
    fs.writeFileSync(tmp, matrixToBmp(m.modules, m.size, 8, 4));
    return decodeFile(tmp);
  } finally {
    try { fs.unlinkSync(tmp); } catch (_) { /* ignore */ }
  }
}

function firstSvg(html) {
  const m = /<svg[\s\S]*?<\/svg>/.exec(html);
  return m ? m[0] : null;
}

async function main() {
  console.log('二维码与手机扫码链路验证 → ' + BASE + '\n');
  const admin = makeSession();
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  if (login.status !== 200) {
    console.error('无法登录，终止：', JSON.stringify(login.body));
    process.exit(1);
  }
  console.log('已登录管理员');

  // ---------- 1. 网络自检接口 ----------
  section('1. 网络自检接口');
  // 先清掉可能残留的手工网址前缀，拿到「自动探测」的基准值，
  // 否则上一次验证中断留下的 qr.base_url 会让这里的基准变成手工值。
  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': '' } } });
  const net = await admin.json('/api/system/net');
  const nd = (net.body && net.body.data) || {};
  check('/api/system/net 可用', net.status === 200 && !!net.body.data, 'HTTP ' + net.status);
  check('返回监听端口', Number.isInteger(nd.port) && nd.port > 0, String(nd.port));
  check('返回绑定地址', typeof nd.bind_host === 'string' && nd.bind_host.length > 0, String(nd.bind_host));
  check('返回是否开启局域网访问（布尔）', typeof nd.lan_open === 'boolean', String(nd.lan_open));
  check('返回二维码网址前缀 base_url', /^https?:\/\/[^\s]+$/.test(nd.base_url || ''), String(nd.base_url));
  check('候选地址是数组', Array.isArray(nd.candidates), typeof nd.candidates);
  check('候选地址项含 url 字段',
    !nd.candidates.length || nd.candidates.every((c) => /^https?:\/\//.test(c.url || '')),
    JSON.stringify(nd.candidates).slice(0, 160));
  check('有局域网网卡时 base_url 不得是回环地址（手机打不开）',
    nd.candidates.length === 0 || !/127\.0\.0\.1|localhost/.test(nd.base_url), String(nd.base_url));
  console.log(`    端口=${nd.port} 绑定=${nd.bind_host} 局域网开启=${nd.lan_open} 候选=${(nd.candidates || []).length}`);

  // ---------- 2. 取一个档案盒 ----------
  section('2. 准备验证用档案盒');
  const boxes = await admin.json('/api/boxes');
  const list = (boxes.body.data && boxes.body.data.list) || [];
  check('库中有档案盒可用于验证', list.length > 0, '数量=' + list.length);
  if (!list.length) {
    console.log('\n没有档案盒，无法继续。请先启动带演示数据的服务。');
    process.exit(1);
  }
  const box = list[0];
  const boxCode = box.box_code;
  // 盒二维码内容 = **短落地页网址** <base>/b/<令牌>/<盒号>
  //   令牌 = 盒 id 的 36 进制 + 8 位 HMAC 签名（用于查找 + 防枚举）
  //   末尾的盒号**只用于显示** —— 扫码时那串字里就能一眼看到编号，但它不参与查找，
  //   所以改盒号不会让已打印的旧标签失效。
  // 后端把它算好放在 /api/boxes 每行的 qr_text 里，前端不再自己拼网址。
  // 长格式 <base>/api/s/<盒号>?k=<12位> 继续兼容（更早打印出去的旧盒脊标签）。
  const boxQrText = box.qr_text || '';
  const SHORT_BOX_RE = /^https?:\/\/.+\/b\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/;
  const isBoxUrl = (t) => typeof t === 'string'
    && (SHORT_BOX_RE.test(t) || t.startsWith(`${nd.base_url}/api/s/`));
  const boxUrlSample = boxQrText;
  console.log(`    盒号=${boxCode} 二维码内容=${boxQrText}（${boxQrText.length} 字符）`);

  // ---------- 2b. 三条落地页路径都要能打开 ----------
  section('2b. 扫码落地页的三条路径');
  {
    const anon2 = makeSession();
    const shortPath = boxQrText.replace(/^https?:\/\/[^/]+/, '');
    // 令牌是中间那一段，编号是最后一段
    const tokenSeg = '/b/' + shortPath.split('/')[2];
    for (const [label, p] of [
      ['短路径 /b/（二维码里用的）', shortPath],
      ['不带编号的短路径 /b/<令牌>（兼容先前打印的标签）', tokenSeg],
      ['按盒号 /api/s/', '/api/s/' + encodeURIComponent(boxCode)],
      ['最早期 /api/scan/box/（兼容旧标签）', '/api/scan/box/' + encodeURIComponent(boxCode)],
    ]) {
      const r = await anon2.req(p);
      const t = await r.text();
      check(`${label} 可打开且显示盒号`,
        r.status === 200 && t.includes(boxCode.slice(0, 6)), 'HTTP ' + r.status);
    }
    // ★ 用户要的效果：扫出来的那串字里就能看到盒号
    check('二维码内容里带盒号（扫出来一眼就能看到编号）',
      boxQrText.includes(boxCode), boxQrText);
    // 短令牌的签名被改掉 → 403（不能因为改短就丢了防枚举）
    const tamper = await anon2.req(tokenSeg.slice(0, -8) + 'AAAAAAAA');
    check('把短令牌的签名改掉 → 403，不透露盒内信息',
      tamper.status === 403, 'HTTP ' + tamper.status);
    const guess = await anon2.req('/b/z' + tokenSeg.slice(-8));
    check('换个 id 猜别人的盒子 → 403（防按 id 枚举）', guess.status === 403, 'HTTP ' + guess.status);
    // 编号那一段被改掉，查找不受影响（查找只看令牌）—— 这正是「改盒号不吃掉旧标签」的保证
    const wrongCode = await anon2.req(tokenSeg + '/WRONG-BOX-999');
    check('把网址里的编号改成错的，照样打开同一个盒子（编号只用于显示，不参与查找）',
      wrongCode.status === 200, 'HTTP ' + wrongCode.status);
  }

  // ---------- 2c. 二维码自检页（免登录，用于区分「码扫不出」和「网址打不开」） ----------
  section('2c. 二维码自检页');
  {
    const anon3 = makeSession();
    const r = await anon3.req('/api/qrcode/selftest');
    const t = await r.text();
    check('自检页免登录可打开', r.status === 200, 'HTTP ' + r.status);
    check('自检页含固定文本码（不依赖网络，用于判断码本身是否可读）',
      t.includes('ARCHIVE-QR-SELFTEST-12345'), '');
    check('自检页给出判断对照说明', /判断对照|码\/手机\/显示问题/.test(t), '');

    // ★ 这一条是血泪教训：自检页是免登录的，但它原先用
    //   <img src="/api/qrcode.svg?..."> 引图片，而那个接口要求登录 ——
    //   于是手机上打开这一页，两个二维码全是「图片加载失败」的破图，页面上根本没有码可扫。
    //   一个专门用来诊断「扫不出来」的页面，自己就不显示码，等于把人往沟里带。
    //   所以：以「手机身份」逐张抓这个页面上的图，必须每一张都真的能拿到。
    const srcs = [...t.matchAll(/<img[^>]*\ssrc="([^"]+)"/g)].map((m) => m[1]);
    check('自检页确实画了二维码（至少 2 张图）', srcs.length >= 2, '图片数=' + srcs.length);
    let badImg = [];
    for (const src of srcs) {
      if (src.startsWith('data:')) continue;                 // 内嵌图片，天然没问题
      if (!src.startsWith('/')) continue;
      const ir = await anon3.req(src.replace(/&amp;/g, '&'));  // 不带任何 Cookie
      if (ir.status !== 200) badImg.push(`${src.slice(0, 60)} → HTTP ${ir.status}`);
      await ir.arrayBuffer().catch(() => {});
    }
    check('自检页上的每一张图，在没有登录的情况下都能加载出来（否则手机上就是破图）',
      badImg.length === 0, badImg.join('；'));
    const dataImgs = srcs.filter((s) => s.startsWith('data:image/')).length;
    check('自检页的二维码是内嵌图片（不依赖第二个接口，也不受登录状态影响）',
      dataImgs >= 2, `内嵌 ${dataImgs} 张 / 共 ${srcs.length} 张`);
    check('自检页告诉用户怎么用 /api/ping 测连通性',
      t.includes('/api/ping'), '');
  }

  // ---------- 3. 弹窗二维码（页面里点「二维码」看到的那个） ----------
  section('3. 页面弹窗二维码');
  const svgRes = await admin.req('/api/qrcode.svg?text=' + encodeURIComponent(boxQrText) + '&px=340');
  const svg = await svgRes.text();
  check('二维码接口返回 SVG', svgRes.status === 200 && svg.startsWith('<svg'), 'HTTP ' + svgRes.status);
  const m1 = svgToMatrix(svg);
  check('静区 ≥ 4 个模块（QR 规范的硬性最低要求）', m1.margin >= 4, 'margin=' + m1.margin);
  const d1 = decodeMatrix(m1);
  check('独立解码器能读出弹窗二维码',
    !!(d1 && d1.ok && d1.text === boxQrText),
    d1 ? (d1.ok ? `读出「${d1.text}」` : d1.reason) : '无结果');
  check('格式信息按标准可读（真扫码器同样依赖它，读不出就判定「这不是二维码」）',
    !!(d1 && d1.viaFormat === true),
    d1 ? ('viaFormat=' + d1.viaFormat + (d1.formatCopy ? ' ' + d1.formatCopy : '')) : '无结果');

  // px 模式：原生尺寸不得超出目标像素，且必须是整数模块边长（否则浏览器缩放会糊边）
  {
    const dim = Number(/<svg[^>]*\swidth="(\d+)"/.exec(svg)[1]);
    const scaleAttr = Number(/data-scale="(\d+)"/.exec(svg)[1]);
    const modAttr = Number(/data-modules="(\d+)"/.exec(svg)[1]);
    check('px 模式：原生尺寸不超过目标像素（浏览器无需缩放）',
      dim <= 340 && dim > 200, `dim=${dim} 目标=340`);
    check('px 模式：模块边长是整数且与尺寸自洽',
      Number.isInteger(scaleAttr) && scaleAttr >= 1 && (modAttr + m1.margin * 2) * scaleAttr === dim,
      `模块=${modAttr} 静区=${m1.margin} 边长=${scaleAttr} 尺寸=${dim}`);
    check('px 模式：单个模块在屏幕上至少 6px（手机相机才认得出）',
      scaleAttr >= 6, '边长=' + scaleAttr + 'px');
  }

  // ---------- 4. 打印标签二维码（盒脊）——「纸面上到底多大」是唯一可信的口径 ----------
  section('4. 打印标签二维码（盒脊）');
  const pr = await admin.req(`/api/print/box/${box.id}`);
  const html = await pr.text();
  check('打印页可打开', pr.status === 200 && html.includes('spine-qr'), 'HTTP ' + pr.status);
  const spineSvg = firstSvg(html);
  check('盒脊上带二维码 SVG', !!spineSvg);
  if (spineSvg) {
    const m2 = svgToMatrix(spineSvg);
    check('打印二维码静区 ≥ 4 个模块（此前是 1，印出来手机对不上焦）',
      m2.margin >= 4, 'margin=' + m2.margin);
    const d2 = decodeMatrix(m2);
    check('独立解码器能读出打印二维码',
      !!(d2 && d2.ok && isBoxUrl(d2.text)),
      d2 ? (d2.ok ? `读出「${d2.text}」` : d2.reason) : '无结果');
    // ★ 盒脊的纠错等级必须是 H。
    //   坑：qrSvg 的默认纠错等级是 M（15%），而 qrPng 的默认是 H（30%）。
    //   生成盒脊时如果不显式传 H，就会出现「最容易磨花的盒脊标签容错反而最低」。
    check('盒脊二维码纠错等级是 H（与档案二维码一致，磨花一角也能读）',
      !!(d2 && d2.ok && d2.ecCode === 2), d2 ? 'ecCode=' + d2.ecCode + '（2=H, 0=M）' : '无结果');
  }
  check('打印页的二维码单个模块足够大（≥0.7mm，否则普通打印机扫不出）',
    (() => {
      if (!spineSvg) return false;
      const sc = Number(/data-scale="(\d+)"/.exec(spineSvg)[1]);
      const mm = sc / 96 * 25.4;                  // 浏览器按 96dpi 折算物理尺寸
      return Number.isFinite(mm) && mm >= 0.7;
    })(),
    spineSvg ? `模块边长 ${/data-scale="(\d+)"/.exec(spineSvg)[1]}px ≈ ${(/data-scale="(\d+)"/.exec(spineSvg)[1] / 96 * 25.4).toFixed(2)}mm` : '无二维码');
  check('盒脊二维码没有被 CSS 压缩（可用宽度要放得下原生尺寸）',
    (() => {
      if (!spineSvg) return false;
      const dim = svgToMatrix(spineSvg).dim;
      const spineW = Number((/\.spine \{ width:(\d+)px/.exec(html) || [])[1]);
      return Number.isFinite(spineW) && dim <= spineW - 4;   // 左右各 2px 内边距
    })(),
    spineSvg ? `二维码 ${svgToMatrix(spineSvg).dim}px / 盒脊 ${(/\.spine \{ width:(\d+)px/.exec(html) || [])[1]}px` : '无二维码');
  check('盒脊二维码内容 ≤ 70 字符（长了每个模块就变小）',
    boxQrText.length <= 70, boxQrText.length + ' 字符');
  check('打印页不再用 CSS 缩放二维码（否则模块边缘被插值糊掉）',
    !/\.spine-qr svg\s*\{[^}]*width:\s*\d+px/.test(html),
    ((/\.spine-qr svg\s*\{[^}]*\}/.exec(html) || [''])[0]).replace(/\s+/g, ' '));

  // ---------- 5. 手机扫码落地页（关键：没有 Cookie） ----------
  section('5. 手机扫码落地页（模拟手机：无 Cookie、无会话）');
  const anon = makeSession();
  const pageRes = await anon.req('/api/scan/box/' + encodeURIComponent(boxCode));
  const pageHtml = await pageRes.text();
  check('未登录也能打开扫码落地页（手机没有登录 Cookie）', pageRes.status === 200, 'HTTP ' + pageRes.status);
  check('落地页显示盒号', pageHtml.includes(boxCode.slice(0, 6)));
  check('落地页显示存放库位', /存放库位/.test(pageHtml));
  check('落地页显示盒内件数', /盒内件数/.test(pageHtml));
  check('落地页显示盒内清单', /盒内档案/.test(pageHtml));
  check('落地页不含题名（降低信息外泄）', !/题名/.test(pageHtml));
  check('落地页自适应手机屏幕', /name="viewport"/.test(pageHtml));

  const nf = await anon.req('/api/scan/box/' + encodeURIComponent('NO-SUCH-BOX-9999'));
  const nfHtml = await nf.text();
  check('不存在的盒号返回 404 且提示友好',
    nf.status === 404 && /没有找到这个档案盒/.test(nfHtml), 'HTTP ' + nf.status);

  // ---------- 6. 扫码枪扫同一个码仍要能匹配（网址容错） ----------
  section('6. 扫码枪扫「网址二维码」的容错');
  const sc = await admin.json('/api/stock-checks', {
    method: 'POST', json: { title: '二维码网络自检盘点', scope: '全部在库档案' },
  });
  check('建立盘点任务', sc.status === 200 && sc.body.data && sc.body.data.id,
    JSON.stringify(sc.body).slice(0, 140));
  const scId = sc.body.data && sc.body.data.id;
  if (scId) {
    const scan = await admin.json(`/api/stock-checks/${scId}/scan`, {
      method: 'POST', json: { codes: [boxUrlSample] },
    });
    const details = JSON.stringify((scan.body.data && scan.body.data.details) || scan.body);
    check('扫码枪提交网址内容时能识别出盒号（不得报「库中无此档案」）',
      scan.status === 200 && !/库中无此档案/.test(details), details.slice(0, 260));
    check('按盒核对有明确提示', /按盒核对|已核对/.test(details), details.slice(0, 260));
    await admin.json(`/api/stock-checks/${scId}/finish`, { method: 'POST', json: {} });
  }

  // ---------- 7. 二维码内容模式切换 ----------
  section('7. 二维码内容模式切换');
  const setCode = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.mode': 'code' } } });
  check('可以保存 qr.mode=code', setCode.status === 200, JSON.stringify(setCode.body).slice(0, 140));
  const pr2 = await admin.req(`/api/print/box/${box.id}`);
  const html2 = await pr2.text();
  const svg2 = firstSvg(html2);
  if (svg2) {
    const d3 = decodeMatrix(svgToMatrix(svg2));
    check('qr.mode=code 时二维码退回纯盒号（老扫码枪/离线标签机）',
      !!(d3 && d3.ok && d3.text === boxCode),
      d3 ? (d3.ok ? `读出「${d3.text}」` : d3.reason) : '无结果');
  }
  const setUrl = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.mode': 'url' } } });
  check('可以还原 qr.mode=url', setUrl.status === 200);
  const pr3 = await admin.req(`/api/print/box/${box.id}`);
  const svg3 = firstSvg(await pr3.text());
  if (svg3) {
    const d4 = decodeMatrix(svgToMatrix(svg3));
    check('还原后二维码内容又变回网址', !!(d4 && d4.ok && isBoxUrl(d4.text)),
      d4 ? (d4.ok ? `读出「${d4.text}」` : d4.reason) : '无结果');
  }

  // ---------- 8. 网址前缀（政务内网场景：内网地址必须能用） ----------
  section('8. 网址前缀：拦住谁都打不开的，放行内网地址');
  for (const bad of ['http://127.0.0.1:8899', 'http://localhost:8899', 'http://0.0.0.0:8899',
    'http://169.254.1.1:8899', 'dangan.example.com']) {
    const r = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': bad } } });
    check(`拒绝手机打不开的网址前缀：${bad}`, r.status === 400,
      'HTTP ' + r.status + ' ' + JSON.stringify(r.body).slice(0, 120));
  }
  // 内网地址是政务内网部署时唯一能用的地址，必须允许保存
  const innerBase = 'http://10.20.30.40:8787';
  const setInner = await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': innerBase } } });
  check('允许保存内网地址（政务内网没有公网地址，拦住就等于功能不可用）',
    setInner.status === 200, 'HTTP ' + setInner.status + ' ' + JSON.stringify(setInner.body).slice(0, 140));
  check('保存内网地址时给出「只有同一内网能打开」的提示',
    typeof (setInner.body.data || {}).warning === 'string' && /内网/.test((setInner.body.data || {}).warning || ''),
    String((setInner.body.data || {}).warning || '').slice(0, 100));
  const pr4 = await admin.req(`/api/print/box/${box.id}`);
  const svg4 = firstSvg(await pr4.text());
  const expectManual = `${innerBase}/b/`;
  if (svg4) {
    const d5 = decodeMatrix(svgToMatrix(svg4));
    check('二维码改用该内网地址（带签名令牌）',
      !!(d5 && d5.ok && d5.text.startsWith(expectManual) && SHORT_BOX_RE.test(d5.text)),
      d5 ? (d5.ok ? `读出「${d5.text}」` : d5.reason) : '无结果');
  }
  // 档案二维码同样要用这个地址：扫出来先显示档案号，再给可点链接
  const ar = await admin.json('/api/archives?page=1&page_size=1');
  const a0 = ((ar.body.data && ar.body.data.list) || [])[0];
  if (a0) {
    const png = await admin.req(`/api/archives/${a0.id}/qrcode.png?px=900`);
    const buf = Buffer.from(await png.arrayBuffer());
    const tmp = path.join(os.tmpdir(), 'qr-net-archive-' + a0.id + '.png');
    fs.writeFileSync(tmp, buf);
    const d6 = decodeFile(tmp);
    const aCode = a0.archive_code || a0.archive_number || '';
    check('档案二维码里写的是能访问到的地址（不是 127.0.0.1）',
      !!(d6 && d6.ok && d6.text.startsWith(innerBase + '/q/')),
      d6 ? (d6.ok ? `读出「${d6.text}」` : d6.reason) : '无结果');
    check('档案二维码带签名令牌（防止有人顺着档号枚举全库）',
      !!(d6 && d6.ok && /^https?:\/\/.+\/q\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/.test(d6.text)),
      d6 && d6.ok ? d6.text : '无结果');
    check('档案二维码内容里带档号（扫出来一眼就能看到编号）',
      !!(d6 && d6.ok && d6.text.includes(aCode)), aCode);
    check('二维码内容长度在可控范围内（≤70 字符；太长了打印到纸上每模块就太小）',
      !!(d6 && d6.ok && d6.text.length <= 70), d6 && d6.ok ? d6.text.length + ' 字符' : '无结果');
    // 落地页：先显示档案号，再给可点链接（链接指向系统内档案详情）
    if (d6 && d6.ok) {
      const u2 = new URL(d6.text);
      const lp = await admin.req(u2.pathname + u2.search);
      const html = await lp.text();
      check('扫码落地页可打开', lp.status === 200, 'HTTP ' + lp.status);
      check('落地页把档案号显示在最上面（大字）',
        html.includes(aCode), aCode);
      check('落地页给出可点开的档案详情链接',
        html.includes(`#/archive/${a0.id}`), '');
      // 令牌是中间那一段（/q/<令牌>[/<档号>]），改签名要改令牌而不是末尾的档号
      const aTokenSeg = '/q/' + u2.pathname.split('/')[2];
      const tamper = await admin.req(aTokenSeg.slice(0, -8) + 'AAAAAAAA');
      check('把短令牌的签名改掉后落地页不透露任何档案信息（403）',
        tamper.status === 403, 'HTTP ' + tamper.status);
      // 编号那一段改错不影响查找（只用于显示）
      const wrongCode = await admin.req(aTokenSeg + '/NO-SUCH-CODE-9999');
      check('把网址里的档号改成错的，照样打开同一份档案（档号只用于显示）',
        wrongCode.status === 200, 'HTTP ' + wrongCode.status);
      try { fs.unlinkSync(tmp); } catch (_) {}
    }
  } else {
    console.log('    （库中没有档案，跳过档案二维码检查）');
  }
  await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': '' } } });
  const net2 = await admin.json('/api/system/net');
  check('清空 qr.base_url 后恢复自动探测',
    net2.status === 200 && net2.body.data.base_url === nd.base_url,
    `${net2.body.data && net2.body.data.base_url} vs ${nd.base_url}`);

  // ---------- 9. 档案盒二维码：批量生成 + 打包下载 + 给 IT 的申请单 ----------
  section('9. 档案盒二维码批量生成 / 打包下载 / 固定地址申请单');
  {
    // 9a. 批量生成
    const rb = await admin.json('/api/boxes/qrcodes/rebuild', { method: 'POST', json: { force: true } });
    check('批量生成所有盒二维码成功', rb.status === 200 && typeof rb.body.data.created === 'number',
      JSON.stringify(rb.body).slice(0, 160));
    const st1 = await admin.json('/api/boxes/qrcodes/stats');
    const s1 = st1.body.data || {};
    console.log(`    盒 ${s1.boxes} 个 / 图片 ${s1.images} 张 / 缺 ${s1.missing} / 目录 ${s1.dir}`);
    check('统计接口返回盒数与图片数', st1.status === 200 && typeof s1.boxes === 'number' && typeof s1.images === 'number');
    check('生成后图片数 = 盒数，无缺失', Number(s1.images) === Number(s1.boxes) && Number(s1.missing) === 0,
      `盒 ${s1.boxes} / 图 ${s1.images} / 缺 ${s1.missing}`);
    check('每个盒一张**不同**的二维码（盒号不同 → 内容不同）',
      true, `已生成 ${s1.images} 张，逐张内容见下方清单校验`);

    // 9b. 幂等 + 清单正确
    const rb2 = await admin.json('/api/boxes/qrcodes/rebuild', { method: 'POST', json: {} });
    check('再生成一次不会重复产图（幂等）',
      rb2.status === 200 && Number(rb2.body.data.created) === 0 && Number(rb2.body.data.skipped) === s1.boxes,
      `created=${rb2.body.data && rb2.body.data.created} skipped=${rb2.body.data && rb2.body.data.skipped}`);
    const qdir = s1.dir;
    const files = fs.readdirSync(qdir);
    check('目录里有 清单.csv', files.includes('清单.csv'), files.slice(0, 6).join(','));
    const csv = fs.readFileSync(path.join(qdir, '清单.csv'), 'utf8').replace(/^\ufeff/, '');
    const lines = csv.split(/\r?\n/).filter(Boolean);
    check('清单表头是 4 列（盒号/盒标题/文件名/二维码内容）',
      lines[0] === '盒号,盒标题,二维码图片文件名,二维码内容', lines[0]);
    const cells = (lines[1] || '').split('","').map((x) => x.replace(/^"|"$/g, ''));
    check('清单第 4 列是短落地页网址 /b/<令牌>/<盒号>',
      cells.length >= 4 && SHORT_BOX_RE.test(cells[3]), cells[3] || lines[1]);
    // 逐张内容必须互不相同（这正是用户要的「每个盒子不同的二维码」）
    const contents = lines.slice(1).map((l) => (l.split('","')[3] || '').replace(/"$/, ''));
    check('清单里每张二维码的内容都不同（每盒一码）',
      new Set(contents).size === contents.length, `共 ${contents.length} 条，去重后 ${new Set(contents).size} 条`);

    // 9c. 打包下载
    const dl = await admin.req('/api/boxes/qrcodes/download');
    const zbuf = Buffer.from(await dl.arrayBuffer());
    check('打包下载返回 ZIP',
      dl.status === 200 && zbuf.slice(0, 2).toString('ascii') === 'PK',
      'HTTP ' + dl.status + ' ' + zbuf.length + ' 字节');
    check('文件名带中文且用 RFC 5987 编码（跨浏览器不乱码）',
      /filename\*=UTF-8''/.test(dl.headers.get('content-disposition') || ''),
      dl.headers.get('content-disposition'));
    // ZIP 里至少要包含和盒数一样多的 PNG + 一份清单
    const ztext = zbuf.toString('latin1');
    const pngCount = (ztext.match(/\.png/g) || []).length;
    check('ZIP 里每盒一张 PNG', pngCount >= s1.boxes, `ZIP 内 .png 出现 ${pngCount} 次 / 盒 ${s1.boxes} 个`);
    check('ZIP 里含清单.csv（印刷时能逐个核对）', ztext.includes('.csv'), '');

    // 9d. 权限：只读用户不能重建/下载
    const rname = 'qrbox' + Date.now().toString().slice(-5);
    const ru = await admin.json('/api/users', {
      method: 'POST',
      json: { username: rname, password: 'Test12345', display_name: '盒码只读测试', role: 'reader' },
    });
    if (ru.status === 200) {
      const reader = makeSession();
      await reader.json('/api/login', { method: 'POST', json: { username: rname, password: 'Test12345' } });
      await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
      const r1 = await reader.json('/api/boxes/qrcodes/rebuild', { method: 'POST', json: {} });
      check('只读用户不能批量生成盒二维码（403）', r1.status === 403, 'HTTP ' + r1.status);
      const r2 = await reader.req('/api/boxes/qrcodes/download');
      check('只读用户不能打包下载（403）', r2.status === 403, 'HTTP ' + r2.status);
      await r2.arrayBuffer().catch(() => {});
      const r3 = await reader.json('/api/boxes/qrcodes/stats');
      check('只读用户可以看盒二维码统计', r3.status === 200, 'HTTP ' + r3.status);
      await admin.json('/api/users/' + ru.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }

    // 9e. 固定地址申请单
    const ar = await admin.req('/api/system/address-request');
    const arHtml = await ar.text();
    check('固定地址申请单页可打开', ar.status === 200, 'HTTP ' + ar.status);
    check('申请单列出计算机名与端口',
      arHtml.includes('计算机名') && arHtml.includes(String(nd.port)), `port=${nd.port}`);
    check('申请单列出网卡 MAC（IT 做 DHCP 保留要用）',
      /MAC/i.test(arHtml) && /[0-9A-F]{2}[:-][0-9A-F]{2}[:-][0-9A-F]{2}/i.test(arHtml),
      (arHtml.match(/[0-9A-F]{2}[:-][0-9A-F]{2}[:-][0-9A-F]{2}[:-][0-9A-F]{2}[:-][0-9A-F]{2}[:-][0-9A-F]{2}/i) || ['(未找到 MAC)'])[0]);
    check('申请单写明「DNS 记录」和「DHCP 保留」两条路，并说明为什么需要固定地址',
      /A 记录/.test(arHtml) && /DHCP 保留/.test(arHtml) && /长期不变的内网地址/.test(arHtml), '');
    check('申请单提供可复制的纯文本块', /id="req-text"/.test(arHtml), '');
    const arAnon = makeSession();
    const arAnonRes = await arAnon.req('/api/system/address-request');
    check('未登录不能看申请单（含网卡信息）', arAnonRes.status === 401, 'HTTP ' + arAnonRes.status);
    await arAnonRes.arrayBuffer().catch(() => {});
  }

  console.log('\n' + '='.repeat(56));
  console.log(`二维码扫码链路验证：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) fails.forEach((f) => console.log('  - ' + f));
  console.log('='.repeat(56));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('验证异常终止：', e); process.exit(1); });
