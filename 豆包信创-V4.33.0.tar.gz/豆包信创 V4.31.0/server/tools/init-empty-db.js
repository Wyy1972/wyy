/**
 * 生成“空白但已配置好”的数据库，供分发包使用。
 * 内容：完整表结构 + 5 大档案门类 + 25 个二级分类 + admin 账号
 * 不含：任何档案记录、附件、借阅记录
 *
 * 用法：node server/tools/init-empty-db.js <输出路径>
 */
'use strict';

const path = require('node:path');
const { openDatabase } = require('../db');

const out = process.argv[2];
if (!out) {
  console.error('用法：node server/tools/init-empty-db.js <数据库输出路径>');
  process.exit(1);
}

const db = openDatabase(path.resolve(out));

// 演示/空白库的 admin 不强制改密：否则分发包一登录就被 "PASSWORD_CHANGE_REQUIRED" 拦在门外，
// 看起来像"系统坏了"。正式部署改密由安全策略另行驱动（首登强改仍在服务端强制）。
db.prepare("UPDATE users SET must_change=0 WHERE username='admin'").run();

const stats = {
  categories: db.prepare('SELECT COUNT(*) AS c FROM categories').get().c,
  types: db.prepare('SELECT COUNT(*) AS c FROM archive_types').get().c,
  users: db.prepare('SELECT COUNT(*) AS c FROM users').get().c,
  archives: db.prepare('SELECT COUNT(*) AS c FROM archives').get().c,
};

// 空白库不应该含有任何业务数据，这里做一次自检，防止把演示数据误打包下发
if (Number(stats.archives) !== 0) {
  console.error(`[错误] 生成的数据库包含 ${stats.archives} 条档案，分发包必须是空库`);
  process.exit(1);
}
// 门类数不写死：v4.30 起基础门类由 5 个扩到 7 个，写死 5 会让新库自检永远失败
if (Number(stats.categories) < 25 || Number(stats.types) < 5 || Number(stats.users) < 1) {
  console.error('[错误] 基础配置不完整：', JSON.stringify(stats));
  process.exit(1);
}

db.close();
console.log(`  空数据库已生成：分类 ${stats.categories} 个 / 门类 ${stats.types} 个 / 账号 ${stats.users} 个 / 档案 ${stats.archives} 条`);
