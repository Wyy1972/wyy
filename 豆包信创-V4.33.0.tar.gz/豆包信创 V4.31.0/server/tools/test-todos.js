/**
 * 待办中心与调度器接口验证（v13·HTTP 层）
 *
 * 覆盖：/api/todos 系列、/api/scheduler/status、/api/scheduler/run/:key，
 * 以及**权限边界**（普通用户能看待办但不能处置、非管理员不能碰调度器）。
 *
 * 待办夹具直接写库（needsData 把数据目录传进来）而不是靠定时任务"顺手产生"——
 * 后者依赖演示数据里恰好有到期项，哪天夹具变了测试就会莫名其妙地"没测到"。
 */
'use strict';

const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'TD' + Math.random().toString(16).slice(2, 8).toUpperCase();
const dbPath = path.join(DATA_DIR, 'archive.db');
const dedupeKey = 'test.todo.' + TAG;
let todoId = 0;
let clkUser = 0;
let clkName = '';

function openDb() { return new DatabaseSync(dbPath); }

async function main() {
  const admin = makeSession();
  const reader = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);

  // 夹具：直接写一条待办
  const db = openDb();
  const now = new Date().toISOString();
  const ins = db.prepare(`INSERT INTO todos(dedupe_key,kind,level,title,detail,ref_type,ref_id,due_at,status,created_at,updated_at)
                          VALUES(?,?,?,?,?,?,?,?,'open',?,?)`)
    .run(dedupeKey, 'backup', 'critical', '【测试】待办夹具 ' + TAG, '接口测试用，结束时会删除', '', null, '', now, now);
  todoId = Number(ins.lastInsertRowid);
  check('已写入待办夹具', todoId > 0, 'id=' + todoId);

  section('待办列表');
  const list = await admin.json('/api/todos?status=open&limit=500');
  check('GET /api/todos 返回 200', list.status === 200, String(list.status));
  const found = (list.body.data.list || []).find((t) => t.id === todoId);
  check('列表包含刚写入的待办', !!found);
  check('列表带 counts 计数', !!list.body.data.counts);
  check('counts.open 至少为 1', (list.body.data.counts.open || 0) >= 1, String(list.body.data.counts.open));
  check('counts.critical 至少为 1', (list.body.data.counts.critical || 0) >= 1, String(list.body.data.counts.critical));
  check('紧急项排在最前（critical 优先）', (list.body.data.list[0] || {}).level === 'critical', (list.body.data.list[0] || {}).level);

  const byLevel = await admin.json('/api/todos?status=open&level=critical&limit=500');
  check('按级别过滤生效', (byLevel.body.data.list || []).every((t) => t.level === 'critical'));
  const byKind = await admin.json('/api/todos?status=open&kind=backup&limit=500');
  check('按类型过滤生效', (byKind.body.data.list || []).every((t) => t.kind === 'backup'));
  const doneList = await admin.json('/api/todos?status=done&limit=500');
  check('已处理列表不含未处理的夹具', !(doneList.body.data.list || []).some((t) => t.id === todoId));
  const allList = await admin.json('/api/todos?status=all&limit=500');
  check('status=all 返回全部', (allList.body.data.list || []).some((t) => t.id === todoId));

  section('状态流转');
  const done = await admin.json(`/api/todos/${todoId}/done`, { method: 'POST', json: { note: '测试处理' } });
  check('标记已处理成功', done.status === 200 && done.body.ok, String(done.status));
  let row = openDb().prepare('SELECT * FROM todos WHERE id=?').get(todoId);
  check('库中状态为 done', row.status === 'done', row.status);
  check('记录了处理人与时间', !!row.handled_by && !!row.handled_at, `by=${row.handled_by} at=${row.handled_at}`);
  check('记录了处理意见', row.handled_note === '测试处理', row.handled_note);

  const doneAgain = await admin.json(`/api/todos/${todoId}/done`, { method: 'POST', json: {} });
  check('重复处理被拒（400）', doneAgain.status === 400, String(doneAgain.status));
  const dismissDone = await admin.json(`/api/todos/${todoId}/dismiss`, { method: 'POST', json: {} });
  check('已处理的不能再忽略（400）', dismissDone.status === 400, String(dismissDone.status));

  const reopen = await admin.json(`/api/todos/${todoId}/reopen`, { method: 'POST', json: {} });
  check('可以重开', reopen.status === 200 && reopen.body.ok, String(reopen.status));
  row = openDb().prepare('SELECT * FROM todos WHERE id=?').get(todoId);
  check('重开后状态为 open', row.status === 'open', row.status);
  const reopenAgain = await admin.json(`/api/todos/${todoId}/reopen`, { method: 'POST', json: {} });
  check('重复重开被拒（400）', reopenAgain.status === 400, String(reopenAgain.status));

  const missing = await admin.json('/api/todos/99999999/done', { method: 'POST', json: {} });
  check('处理不存在的待办返回 404', missing.status === 404, String(missing.status));

  section('调度器接口');
  const st = await admin.json('/api/scheduler/status');
  check('GET /api/scheduler/status 返回 200', st.status === 200, String(st.status));
  check('调度器已挂载', st.body.data.attached === true, JSON.stringify(st.body.data.attached));
  check('注册了 5 个内置任务', (st.body.data.tasks || []).length === 5, String((st.body.data.tasks || []).length));
  const keys = (st.body.data.tasks || []).map((t) => t.key);
  for (const k of ['backup.auto', 'detection.sweep', 'storage.check', 'remind.due', 'housekeep.login_attempts']) {
    check('任务表中含 ' + k, keys.includes(k));
  }
  check('状态里带下一步说明', !!(st.body.data.tasks || [])[0].reason, JSON.stringify((st.body.data.tasks || [])[0] || {}));
  check('状态里带设置摘要', !!st.body.data.settings, JSON.stringify(st.body.data.settings));

  const runOne = await admin.json('/api/scheduler/run/housekeep.login_attempts', { method: 'POST', json: {} });
  check('手动触发任务成功', runOne.status === 200 && runOne.body.data.ok === true, JSON.stringify(runOne.body.data));
  check('手动触发返回执行详情', typeof runOne.body.data.detail === 'string', JSON.stringify(runOne.body.data));

  const runMissing = await admin.json('/api/scheduler/run/no.such.task', { method: 'POST', json: {} });
  check('触发不存在的任务返回 404', runMissing.status === 404, String(runMissing.status));

  section('权限边界');
  // 建一个普通用户（reader）：能看待办（todo:read），但不能处置（todo:handle），也不能看调度器
  clkName = TAG.toLowerCase() + '_rd';
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: clkName, display_name: '测试阅读者', password: 'Test@12345', role: 'reader', department: '测试' },
  });
  check('创建普通用户成功', mk.status === 200 && mk.body.ok, JSON.stringify(mk.body).slice(0, 200));
  clkUser = (mk.body.data && (mk.body.data.id || (mk.body.data.user && mk.body.data.user.id))) || 0;

  const rl = await reader.json('/api/login', { method: 'POST', json: { username: clkName, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  check('普通用户登录成功', rl.status === 200 && rl.body.ok, String(rl.status));

  const rlist = await reader.json('/api/todos?status=open&limit=10');
  check('普通用户可以看待办列表', rlist.status === 200, String(rlist.status));
  const rdone = await reader.json(`/api/todos/${todoId}/done`, { method: 'POST', json: {} });
  check('普通用户不能处置待办（403）', rdone.status === 403, String(rdone.status));
  const rsched = await reader.json('/api/scheduler/status');
  check('普通用户不能看调度器（403）', rsched.status === 403, String(rsched.status));
  const rrun = await reader.json('/api/scheduler/run/remind.due', { method: 'POST', json: {} });
  check('普通用户不能触发任务（403）', rrun.status === 403, String(rrun.status));

  section('清理');
  const db2 = openDb();
  db2.prepare('DELETE FROM todos WHERE dedupe_key=?').run(dedupeKey);
  check('测试待办已清理', !db2.prepare('SELECT id FROM todos WHERE dedupe_key=?').get(dedupeKey));
  if (clkUser) {
    const del = await admin.json('/api/users/' + clkUser, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    check('测试用户已删除或降级', del.status === 200, String(del.status));
  }
  db2.close();
  db.close();

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  try { const d = openDb(); d.prepare('DELETE FROM todos WHERE dedupe_key=?').run(dedupeKey); d.close(); } catch (_) { /* ignore */ }
  process.exit(1);
});
