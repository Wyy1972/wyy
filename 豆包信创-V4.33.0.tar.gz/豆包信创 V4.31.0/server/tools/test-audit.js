/**
 * 审计跟踪回归测试：哈希链防篡改、行为要素、分类、保留期、导出与备份纳入
 *
 * 用法：node server/tools/test-audit.js [http://127.0.0.1:8796] [数据目录]
 *
 * 覆盖（对应 DA/T 92—2022 §9.5 与档办发〔2017〕3号第四十二/四十三条）：
 *   1. 日志具备「行为描述 / 行为步骤 / 行为对象 / 行为日期 / 行为人员」五要素
 *   2. 哈希链完整可校验（/api/logs/verify）
 *   3. **真实篡改检测**：直接改数据库里的历史日志 → 链必须报出断点；恢复后重新变完整
 *   4. **真实删除检测**：删掉中间一条 → 链必须在下一处报断点；补回后重新变完整
 *   5. 非授权访问（越权）被记录为安全事件，带「拒绝」结果
 *   6. 登录失败被记录，带「失败」结果
 *   7. 日志分类与结果筛选
 *   8. 审计日志导出（含哈希字段）
 *   9. 权限：只有安全审计员/管理员可校验与导出，档案员不可
 *  10. 保留期策略（不低于最长保管期限）
 *  11. 备份把审计日志纳入范围并给出链校验结论
 *
 * 脚本结束时把被篡改的数据**原样还原**，可重复运行。
 */
'use strict';

const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'archive.db');

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function raw(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text() };
  }
  return { req, json, raw };
}

const TAG = 'AUD' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { users: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);

  // ---------- 1. 五要素 ----------
  section('审计要素完整性');
  const list = await admin.json('/api/logs?size=50');
  const rows = (list.body.data && list.body.data.list) || [];
  check('日志可查询且非空', rows.length > 0, String(rows.length));
  const hasFields = rows.every((r) => 'at' in r && 'username' in r && 'action' in r && 'target' in r
    && 'step' in r && 'result' in r && 'category' in r && 'prev_hash' in r && 'hash' in r);
  check('每条日志都带行为五要素与链字段', hasFields,
    JSON.stringify(Object.keys(rows[0] || {})).slice(0, 200));
  check('行为日期（at）已记录', rows.every((r) => !!r.at));
  check('行为人员（username）已记录', rows.every((r) => typeof r.username === 'string'));
  check('接口返回日志分类清单', Array.isArray(list.body.data.categories) && list.body.data.categories.length > 0,
    JSON.stringify(list.body.data.categories || []).slice(0, 160));

  // ---------- 2. 链完整性 ----------
  section('哈希链完整性');
  const v0 = await admin.json('/api/logs/verify');
  check('校验接口返回成功', v0.status === 200 && v0.body.ok, JSON.stringify(v0.body).slice(0, 200));
  check('链校验通过', v0.body.data.ok === true, JSON.stringify(v0.body.data).slice(0, 240));
  check('返回校验条数', v0.body.data.checked > 0, String(v0.body.data.checked));
  check('说明使用 SHA-256 链式哈希', /SHA-256/.test(v0.body.data.algorithm || ''), String(v0.body.data.algorithm));
  check('返回链尾哈希', /^[0-9a-f]{64}$/.test(v0.body.data.tail || ''), String(v0.body.data.tail).slice(0, 20));

  // ---------- 3 & 4. 篡改 / 删除检测 ----------
  section('篡改检测（真实改动数据库）');
  const db = new DatabaseSync(DB_FILE);
  const allIds = db.prepare('SELECT id FROM logs ORDER BY id').all().map((r) => r.id);
  check('测试库中有足够日志可供篡改测试', allIds.length >= 6, String(allIds.length));

  // 取中间的一条（不要首尾：首条验创世链接、尾条之后没有记录来暴露断点）
  const tamperId = allIds[Math.floor(allIds.length / 2)];
  const orig = db.prepare('SELECT * FROM logs WHERE id=?').get(tamperId);
  const tamperPrev = orig.prev_hash;
  const tamperHash = orig.hash;

  db.prepare("UPDATE logs SET detail=? WHERE id=?").run('被篡改的内容 ' + TAG, tamperId);
  const v1 = await admin.json('/api/logs/verify');
  db.close();

  check('内容被改后：链校验报失败', v1.body.data.ok === false, JSON.stringify(v1.body.data).slice(0, 200));
  check('精确定位到被改的那条记录', v1.body.data.broken && v1.body.data.broken.id === tamperId,
    JSON.stringify(v1.body.data.broken));
  check('断点原因说明是「内容被修改」', /修改/.test((v1.body.data.broken || {}).reason || ''),
    String((v1.body.data.broken || {}).reason));
  check('校验失败本身也留痕（结果=失败）', /失败/.test(JSON.stringify((await admin.json('/api/logs?size=5')).body.data.list[0] || {})));

  // 还原
  const db2 = new DatabaseSync(DB_FILE);
  db2.prepare('UPDATE logs SET detail=?, prev_hash=?, hash=? WHERE id=?')
    .run(orig.detail, tamperPrev, tamperHash, tamperId);
  db2.close();
  const v2 = await admin.json('/api/logs/verify');
  check('还原后链重新变完整', v2.body.data.ok === true, JSON.stringify(v2.body.data).slice(0, 200));

  section('删除检测（真实删除一条记录）');
  const delIdx = Math.floor(allIds.length / 2) + 1;
  const delId = allIds[delIdx];
  const nextId = allIds[delIdx + 1];
  const db3 = new DatabaseSync(DB_FILE);
  const delRow = db3.prepare('SELECT * FROM logs WHERE id=?').get(delId);
  db3.prepare('DELETE FROM logs WHERE id=?').run(delId);
  db3.close();

  const v3 = await admin.json('/api/logs/verify');
  check('记录被删后：链校验报失败', v3.body.data.ok === false, JSON.stringify(v3.body.data).slice(0, 200));
  check('断点落在被删记录的下一条（哈希不衔接）',
    v3.body.data.broken && v3.body.data.broken.id === nextId,
    `期望 ${nextId}，实际 ${JSON.stringify(v3.body.data.broken)}`);
  check('断点原因说明是「被删除或插入」', /删除|插入/.test((v3.body.data.broken || {}).reason || ''),
    String((v3.body.data.broken || {}).reason));

  // 补回原记录
  const db4 = new DatabaseSync(DB_FILE);
  db4.prepare(`INSERT INTO logs(id,at,user_id,username,action,target,detail,ip,step,result,category,prev_hash,hash)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(delRow.id, delRow.at, delRow.user_id, delRow.username, delRow.action, delRow.target,
      delRow.detail, delRow.ip, delRow.step, delRow.result, delRow.category, delRow.prev_hash, delRow.hash);
  db4.close();
  const v4 = await admin.json('/api/logs/verify');
  check('补回记录后链重新变完整', v4.body.data.ok === true, JSON.stringify(v4.body.data).slice(0, 200));

  // ---------- 5 & 6. 安全事件留痕 ----------
  section('安全事件留痕');
  // 造一次真实的越权：低密级账号读机密档案
  const mkArch = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', title: `${TAG} 机密件`, secret_level: '机密', retention: '定期10年',
      year: '2026', archive_date: '2026-01-01',
      category_id: (await admin.json('/api/categories')).body.data.flat.find((c) => c.code === 'WS-XZ').id,
    },
  });
  const secretId = mkArch.body.ok ? mkArch.body.data.id : 0;
  const mkUser = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_low`, display_name: TAG, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  if (mkUser.body.ok) created.users.push(mkUser.body.data.id);
  const low = makeSession();
  await low.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_low`, password: 'Test@12345' } });
  await low.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  await low.json(`/api/archives/${secretId}`);          // 越权读取
  await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: '错误的密码' } });  // 登录失败

  const secLogs = await admin.json('/api/logs?category=security&size=20');
  const secList = (secLogs.body.data && secLogs.body.data.list) || [];
  check('越权访问被记为安全事件（可按分类筛出）', secList.length > 0,
    JSON.stringify(secList.slice(0, 2)).slice(0, 200));
  check('安全事件带「拒绝」结果',
    secList.some((r) => r.result === '拒绝' && /越权/.test(r.action)),
    JSON.stringify(secList.map((r) => [r.action, r.result])).slice(0, 200));
  check('安全事件记录了行为步骤', secList.some((r) => !!r.step), JSON.stringify(secList.map((r) => r.step)));
  check('安全事件记录了行为人员', secList.some((r) => r.username === `${TAG.toLowerCase()}_low`));

  const failLogs = await admin.json('/api/logs?result=失败&size=20');
  const failList = (failLogs.body.data && failLogs.body.data.list) || [];
  check('登录失败被记录且结果为「失败」',
    failList.some((r) => /登录失败/.test(r.action)), JSON.stringify(failList.map((r) => r.action)).slice(0, 160));
  check('登录失败归入「登录与会话」分类',
    failList.some((r) => r.category === 'auth'), JSON.stringify(failList.map((r) => r.category)).slice(0, 160));

  // ---------- 7. 导出 ----------
  section('审计日志导出');
  const csv = await admin.raw('/api/logs/export.csv');
  check('导出返回 CSV', csv.status === 200 && /序号|行为日期/.test(csv.text.slice(0, 200)),
    csv.text.slice(0, 120));
  check('导出含行为步骤与结果列', /行为步骤/.test(csv.text) && /结果/.test(csv.text));
  check('导出含哈希字段（可离线复核链）', /前一条哈希/.test(csv.text) && /本条哈希/.test(csv.text));
  check('导出内容里有真实哈希值', /[0-9a-f]{64}/.test(csv.text));

  // ---------- 8. 权限 ----------
  section('权限隔离');
  const clerkMk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_clk`, display_name: TAG, password: 'Test@12345', role: 'clerk' },
  });
  if (clerkMk.body.ok) created.users.push(clerkMk.body.data.id);
  const clerk = makeSession();
  await clerk.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_clk`, password: 'Test@12345' } });
  await clerk.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const clerkVerify = await clerk.json('/api/logs/verify');
  check('档案员不能校验日志链（属审计职责）', clerkVerify.status === 403, 'status=' + clerkVerify.status);
  const clerkExport = await clerk.raw('/api/logs/export.csv');
  check('档案员不能导出审计日志', clerkExport.status === 403, 'status=' + clerkExport.status);
  const clerkList = await clerk.json('/api/logs');
  check('档案员仍可查看操作日志', clerkList.status === 200, 'status=' + clerkList.status);

  // ---------- 9. 保留期 ----------
  section('保留期策略');
  const st = await admin.json('/api/security/status');
  const auditInfo = (st.body.data || {}).audit || {};
  check('安全体检返回审计链状态', auditInfo.chainIntact === true, JSON.stringify(auditInfo).slice(0, 240));
  check('安全体检返回保留期策略', !!(auditInfo.retention && typeof auditInfo.retention.configuredDays === 'number'),
    JSON.stringify(auditInfo.retention));
  check('保留期策略给出最长保管期限依据',
    typeof auditInfo.retention.maxRetentionYears === 'number', JSON.stringify(auditInfo.retention));
  check('安全体检给出日志导出与校验入口',
    !!auditInfo.exportUrl && !!auditInfo.verifyUrl, JSON.stringify([auditInfo.exportUrl, auditInfo.verifyUrl]));

  // ---------- 10. 备份纳入 ----------
  section('备份纳入审计日志');
  const bak = await admin.req('/api/backup/download');
  check('备份接口返回 ZIP', bak.status === 200 && (bak.headers.get('content-type') || '').includes('zip'),
    `status=${bak.status} type=${bak.headers.get('content-type')}`);
  const buf = Buffer.from(await bak.arrayBuffer());
  check('备份包含审计日志（ZIP 内出现 logs.csv 名字）',
    buf.includes(Buffer.from('audit/logs.csv', 'utf8')), `size=${buf.length}`);
  // 注意用 action 筛选而不是 kw：kw 只搜行为对象/细节/人员，
  // 而「备份导出」是**行为描述**（action 字段），用 kw 会筛不到（本项目踩过一次）。
  const bakLogs = await admin.json(`/api/logs?action=${encodeURIComponent('备份导出')}&size=5`);
  const bakEntry = ((bakLogs.body.data && bakLogs.body.data.list) || [])[0] || {};
  check('备份动作本身留痕', !!bakEntry.action, JSON.stringify(bakEntry).slice(0, 160));
  check('备份留痕注明审计日志链状态', /日志链/.test(bakEntry.detail || ''), String(bakEntry.detail));
  check('备份留痕注明纳入的日志条数', /日志 \d+ 条/.test(bakEntry.detail || ''), String(bakEntry.detail));

  // ---------- 清理 ----------
  section('清理');
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  if (secretId) await admin.json(`/api/archives/${secretId}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const finalVerify = await admin.json('/api/logs/verify');
  check('清理后日志链仍然完整（篡改痕迹已全部还原）', finalVerify.body.data.ok === true,
    JSON.stringify(finalVerify.body.data).slice(0, 200));

  console.log(`\n审计跟踪回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n审计测试异常终止：', e); process.exit(1); });
