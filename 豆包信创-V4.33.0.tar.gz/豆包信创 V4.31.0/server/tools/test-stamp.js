/**
 * 归档章与备考表回归测试（DA/T 22—2015）
 *
 * 用法：node server/tools/test-stamp.js [http://127.0.0.1:8796]
 *
 * 覆盖：
 *   1. 归档章必备项：全宗号、年度、保管期限、件号、页数（机构(问题)为选择项）—— §5.4.4
 *   2. 件号推导：优先件号字段，其次从档号末段取（不足 4 位补零）
 *   3. 缺失必备项会被指出，而不是静默印出一枚空章
 *   4. 归档章三种形态：JSON / SVG / 整页打印；并嵌入二维码标签页
 *   5. 批量打印归档章（按 ids 与按检索条件两种入口，受密级约束）
 *   6. 备考表五项：盒内文件情况说明、整理人、整理日期、检查人、检查日期 —— §6.5
 *   7. 备考表可签署、可打印，并嵌入"卷内目录/盒脊"页
 *   8. 盒脊厚度只能是 20/30/40/50mm —— §6.4
 *
 * 脚本结束时清理测试数据，可重复运行。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function raw(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text(), headers: res.headers };
  }
  return { req, json, raw };
}

const TAG = 'STP' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [], boxes: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);
  const cats = (await admin.json('/api/categories')).body.data.flat;
  const cat = cats.find((c) => c.code === 'WS-XZ') || cats[0];

  async function makeArchive(extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({
        type_code: 'WS', category_id: cat.id, title: `${TAG} 归档章样本`, secret_level: '公开',
        retention: '定期30年', year: '2026', archive_date: '2026-01-01', responsible: '办公室',
        pages: '12', item_no: '0007',
      }, extra),
    });
    if (r.body.ok) created.archives.push(r.body.data.id);
    return r.body.ok ? r.body.data : null;
  }

  // ---------- 1. 归档章必备项 ----------
  section('归档章必备项（DA/T 22—2015 §5.4.4）');
  const a1 = await makeArchive();
  check('夹具档案创建成功', !!a1, JSON.stringify(a1).slice(0, 120));
  const st = await admin.json(`/api/archives/${a1.id}/stamp`);
  const sd = st.body.data || {};
  check('归档章接口可用', st.status === 200 && !!sd.fields, JSON.stringify(sd).slice(0, 160));
  check('含六项（五项必备 + 机构(问题)）', Array.isArray(sd.cells) && sd.cells.length === 6,
    String((sd.cells || []).length));
  check('必备项标注正确',
    (sd.cells || []).filter((c) => c.required).map((c) => c.label).join(',')
    === '全宗号,年度,件号,保管期限,页数',
    (sd.cells || []).filter((c) => c.required).map((c) => c.label).join(','));
  check('机构(问题)标为选择项', (sd.cells || []).some((c) => c.label === '机构(问题)' && !c.required));
  check('全宗号已填充（来自系统设置）', !!sd.fields.unit_code, String(sd.fields.unit_code));
  check('年度已填充', sd.fields.year === '2026', String(sd.fields.year));
  check('件号取档案上的件号字段', sd.fields.item_no === '0007', String(sd.fields.item_no));
  check('保管期限含名称与代码', /定期30年/.test(sd.fields.retention) && /D30/.test(sd.fields.retention),
    String(sd.fields.retention));
  check('页数已填充', sd.fields.pages === '12', String(sd.fields.pages));
  check('机构(问题)取自分类号后半段', sd.fields.org_code === 'XZ', String(sd.fields.org_code));
  check('必备项齐全时 complete=true', sd.complete === true, JSON.stringify(sd.missing));
  check('返回标准依据', /DA\/T 22/.test(sd.basis || ''), String(sd.basis));
  check('返回可直接嵌入的 HTML 与 SVG', /archive-stamp/.test(sd.html || '') && /<svg/.test(sd.svg || ''));

  section('件号推导与缺失提示');
  const cat2 = cats.find((c) => c.code === 'WS-BW') || cats[1] || cat;
  const a2 = await makeArchive({ item_no: '', category_id: cat2.id, title: `${TAG} 无件号样本` });
  const st2 = await admin.json(`/api/archives/${a2.id}/stamp`);
  check('件号为空时从档号末段推导', /^\d{4}$/.test((st2.body.data || {}).fields.item_no || ''),
    String((st2.body.data || {}).fields.item_no));
  check('推导出的件号与原档号末段一致',
    String(a2.archive_number).endsWith(String((st2.body.data || {}).fields.item_no)),
    `${a2.archive_number} vs ${(st2.body.data || {}).fields.item_no}`);

  const a3 = await makeArchive({ pages: '', title: `${TAG} 缺页数样本` });
  const st3 = await admin.json(`/api/archives/${a3.id}/stamp`);
  check('缺页数时 complete=false', (st3.body.data || {}).complete === false, JSON.stringify((st3.body.data || {}).missing));
  check('明确指出缺的是「页数」', ((st3.body.data || {}).missing || []).includes('页数'),
    JSON.stringify((st3.body.data || {}).missing));
  check('HTML 里也给出缺失提示', /缺少必备项/.test((st3.body.data || {}).html || ''),
    String((st3.body.data || {}).html).slice(0, 120));

  // ---------- 2. SVG 与批量打印 ----------
  section('归档章 SVG 与批量打印');
  const svg = await admin.raw(`/api/archives/${a1.id}/stamp?format=svg`);
  check('SVG 可直接取用', svg.status === 200 && /^<svg/.test(svg.text), 'status=' + svg.status);
  check('SVG 用章红色', /#c0392b/.test(svg.text));
  check('SVG 尺寸按毫米给出（打印 1mm 即 1mm）', /width="60mm"/.test(svg.text), svg.text.slice(0, 120));
  check('SVG 含六个格子标签',
    ['全宗号', '年度', '件号', '机构(问题)', '保管期限', '页数'].every((t) => svg.text.includes(t)),
    svg.text.slice(0, 200));

  const sheet = await admin.raw(`/api/print/stamps?ids=${a1.id},${a2.id}`);
  check('批量打印页可打开', sheet.status === 200 && /归 档 章/.test(sheet.text), 'status=' + sheet.status);
  check('批量页含两枚章', (sheet.text.match(/archive-stamp /g) || []).length >= 2,
    String((sheet.text.match(/archive-stamp /g) || []).length));
  check('批量页注明必备项依据', /§5\.4\.4|5\.4\.4/.test(sheet.text));
  check('批量页注明加盖位置', /首页上端居中/.test(sheet.text));
  check('批量页注明这是电子样式（仍需盖实体章）', /实体件仍须/.test(sheet.text));

  const sheetByFilter = await admin.raw(`/api/print/stamps?kw=${TAG}`);
  check('按检索条件批量打印可用', sheetByFilter.status === 200 && /archive-stamp/.test(sheetByFilter.text),
    'status=' + sheetByFilter.status);

  const labelPage = await admin.raw(`/api/print/archive/${a1.id}`);
  check('二维码标签页内嵌归档章', /archive-stamp/.test(labelPage.text) && /归档章/.test(labelPage.text));

  // ---------- 3. 备考表 ----------
  section('备考表（DA/T 22—2015 §6.5）');
  const boxR = await admin.json('/api/boxes', {
    method: 'POST',
    json: { box_code: `${TAG}-BOX`, title: `${TAG} 备考表测试盒`, type_code: 'WS', capacity: 50 },
  });
  const boxId = boxR.body.ok ? boxR.body.data.id : 0;
  if (boxId) created.boxes.push(boxId);
  check('档案盒创建成功', !!boxId, JSON.stringify(boxR.body).slice(0, 140));
  await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: [a1.id, a2.id] } });

  const bk = await admin.json(`/api/boxes/${boxId}/beikaobiao`);
  const bd = bk.body.data || {};
  check('备考表接口可用', bk.status === 200 && !!bd.box_code, JSON.stringify(bd).slice(0, 160));
  check('含五项字段',
    ['inventory_note', 'preparer', 'prepared_at', 'checker', 'checked_at'].every((k) => k in bd),
    JSON.stringify(Object.keys(bd)));
  check('盒内件数正确（2 件）', bd.item_count === 2, String(bd.item_count));
  check('给出起止档号', !!bd.first_no && !!bd.last_no, `${bd.first_no} ~ ${bd.last_no}`);
  check('整理人默认取盒创建人（谁装盒谁整理）', !!bd.preparer, String(bd.preparer));
  check('整理日期默认留空（日期是签署行为，系统不代填）', bd.prepared_at === '', String(bd.prepared_at));
  check('盒脊厚度默认 30mm', bd.spine_mm === 30, String(bd.spine_mm));
  check('返回标准依据', /DA\/T 22/.test(bd.basis || ''), String(bd.basis));

  const save = await admin.json(`/api/boxes/${boxId}/beikaobiao`, {
    method: 'PUT',
    json: {
      preparer: '张整理', prepared_at: '2026-03-05', checker: '李检查', checked_at: '2026-03-06',
      inventory_note: '盒内文件齐全，无缺损。', spine_mm: 40,
    },
  });
  check('备考表签署信息可保存', save.body.ok, JSON.stringify(save.body).slice(0, 160));
  check('保存后回读一致',
    save.body.data.preparer === '张整理' && save.body.data.prepared_at === '2026-03-05'
    && save.body.data.checker === '李检查' && save.body.data.checked_at === '2026-03-06',
    JSON.stringify(save.body.data).slice(0, 200));
  check('盒内情况说明已保存', save.body.data.inventory_note === '盒内文件齐全，无缺损。',
    String(save.body.data.inventory_note));
  check('盒脊厚度改为 40mm', save.body.data.spine_mm === 40, String(save.body.data.spine_mm));

  check('日期格式非法被拒绝',
    (await admin.json(`/api/boxes/${boxId}/beikaobiao`, { method: 'PUT', json: { prepared_at: '2026/03/05' } })).status === 400);
  check('盒脊厚度非法被拒绝（只能 20/30/40/50）',
    (await admin.json(`/api/boxes/${boxId}/beikaobiao`, { method: 'PUT', json: { spine_mm: 25 } })).status === 400);
  check('盒脊厚度非法时明确引用标准',
    /DA\/T 22/.test(JSON.stringify((await admin.json(`/api/boxes/${boxId}/beikaobiao`, {
      method: 'PUT', json: { spine_mm: 35 },
    })).body)));

  const bkPrint = await admin.raw(`/api/print/beikaobiao/${boxId}`);
  check('备考表可打印', bkPrint.status === 200 && /备 考 表/.test(bkPrint.text), 'status=' + bkPrint.status);
  check('打印件含五项', /盒内文件情况说明/.test(bkPrint.text) && /整理人/.test(bkPrint.text)
    && /整理日期/.test(bkPrint.text) && /检查人/.test(bkPrint.text) && /检查日期/.test(bkPrint.text));
  check('打印件带出了已签署的值', /张整理/.test(bkPrint.text) && /李检查/.test(bkPrint.text));
  check('打印件含盒内文件目录', /盒内文件目录/.test(bkPrint.text));
  check('打印件注明依据', /6\.5/.test(bkPrint.text));

  const boxPage = await admin.raw(`/api/print/box/${boxId}`);
  check('卷内目录/盒脊页内嵌备考表', /备 考 表/.test(boxPage.text) && /bukaobei|beikao/.test(boxPage.text));
  check('盒脊页注明盒脊必备项（§6.4）', /盒脊必备项/.test(boxPage.text) && /6\.4/.test(boxPage.text));
  check('盒脊页含起止件号', /起止件号/.test(boxPage.text));

  // ---------- 4. 设置与权限 ----------
  section('设置与权限');
  const badSpineSetting = await admin.json('/api/settings', { method: 'PUT', json: { 'box.spine_mm_default': '25' } });
  check('盒脊厚度默认值非法被拒绝', badSpineSetting.status === 400, 'status=' + badSpineSetting.status);
  const okSpineSetting = await admin.json('/api/settings', { method: 'PUT', json: { 'box.spine_mm_default': '40' } });
  check('合法盒脊厚度可保存', okSpineSetting.body.ok);
  const boxNew = await admin.json('/api/boxes', {
    method: 'POST', json: { box_code: `${TAG}-BOX2`, title: `${TAG} 厚度默认值测试`, type_code: 'WS' },
  });
  if (boxNew.body.ok) created.boxes.push(boxNew.body.data.id);
  const boxNewRow = (await admin.json(`/api/boxes?kw=${TAG}-BOX2`)).body.data.list[0] || {};
  check('新建盒采用设置的默认厚度', Number(boxNewRow.spine_mm) === 40, String(boxNewRow.spine_mm));
  await admin.json('/api/settings', { method: 'PUT', json: { 'box.spine_mm_default': '30' } });

  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_rd`, display_name: TAG, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  if (mk.body.ok) created.users.push(mk.body.data.id);
  const rd = makeSession();
  await rd.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_rd`, password: 'Test@12345' } });
  await rd.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const rdStamp = await rd.json(`/api/archives/${a1.id}/stamp`);
  check('普通用户可查看归档章（只读）', rdStamp.status === 200, 'status=' + rdStamp.status);
  const rdSheet = await rd.json(`/api/print/stamps?ids=${a1.id}`);
  check('普通用户不能批量打印归档章', rdSheet.status === 403, 'status=' + rdSheet.status);
  const rdBk = await rd.json(`/api/boxes/${boxId}/beikaobiao`, { method: 'PUT', json: { preparer: 'x' } });
  check('普通用户不能签署备考表', rdBk.status === 403, 'status=' + rdBk.status);

  const aSec = await makeArchive({ secret_level: '机密', title: `${TAG} 涉密样本` });
  const rdSec = await rd.json(`/api/archives/${aSec.id}/stamp`);
  check('低密级用户看不到涉密档案的归档章（404）', rdSec.status === 404, 'status=' + rdSec.status);
  const rdSheet2 = await rd.json(`/api/print/stamps?ids=${aSec.id}`);
  check('低密级用户批量打印时被过滤（无可用档案）',
    rdSheet2.status === 400 || !/archive-stamp/.test(rdSheet2.text || ''), 'status=' + rdSheet2.status);

  // ---------- 清理 ----------
  section('清理');
  for (const id of created.boxes) {
    await admin.json(`/api/boxes/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  for (const id of created.archives) await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('清理完成', true);

  console.log(`\n归档章与备考表回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n归档章测试异常终止：', e); process.exit(1); });
