/**
 * 前端渲染冒烟测试：用轻量 DOM 仿真在 Node 里真实执行 public/js/app.js，
 * 跑通登录 → 工作台 → 档案检索 → 著录 → 借阅 → 日志 → 系统管理 的渲染路径，
 * 捕捉真实存在的运行时错误（ReferenceError / TypeError / 接口字段错配）。
 *
 * 用法：node server/tools/smoke-frontend.js [http://127.0.0.1:8787]
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const ROOT = path.resolve(__dirname, '..', '..');
/**
 * `--dump <目录>`：把每一屏渲染出的**完整 DOM** 落盘成一个 HTML 文件。
 *
 * 用途是版面核对：改样式时，"读 CSS"永远不如"看渲染结果"可靠。
 * 落盘的文件可以直接拼进一张预览页里截图（见 _ui-preview.js），
 * 也可以自己用浏览器打开看 —— 因为它带的就是真实 index.html 的结构和真实 app.js 渲染出的内容。
 * 不传这个参数时完全不落盘，回归行为与以前一致。
 */
const dumpIdx = process.argv.indexOf('--dump');
const DUMP_DIR = dumpIdx > 0 ? String(process.argv[dumpIdx + 1] || '') : '';
let dumpSeq = 0;
const htmlSource = fs.readFileSync(path.join(ROOT, 'public', 'index.html'), 'utf8');

// ---------------------------------------------------------------- DOM 仿真
class ClassList {
  constructor() { this.set = new Set(); }
  add(...c) { c.forEach((x) => this.set.add(x)); }
  remove(...c) { c.forEach((x) => this.set.delete(x)); }
  contains(c) { return this.set.has(c); }
  toggle(c, force) {
    const want = force === undefined ? !this.set.has(c) : !!force;
    if (want) this.set.add(c); else this.set.delete(c);
    return want;
  }
  get value() { return [...this.set].join(' '); }
}

class El {
  constructor(tag) {
    this.tagName = String(tag || 'div').toUpperCase();
    this.children = [];
    this.parentNode = null;
    this.attrs = {};
    this.dataset = {};
    this.classList = new ClassList();
    this.style = {};
    this._text = '';
    this._html = '';
    this.value = '';
    this.disabled = false;
    this.hidden = false;
    this.checked = false;
    this.open = false;
    this.nodeType = 1;
  }
  get className() { return this.classList.value; }
  set className(v) { this.classList = new ClassList(); String(v).split(/\s+/).filter(Boolean).forEach((c) => this.classList.add(c)); }
  get innerHTML() {
    // 优先序列化真实子节点（模拟浏览器把 DOM 还原成 HTML 的行为）
    if (this.children.length) return this.children.map(serialize).join('');
    return this._html;
  }
  set innerHTML(v) {
    this._html = String(v);
    this.children = [];
    // 把片段解析成真实子节点，模拟浏览器的行为（这样 querySelector 能找到动态生成的元素）
    const frag = buildFromHtml(this._html);
    for (const c of frag.children) { c.parentNode = this; this.children.push(c); }
  }
  get textContent() { return this._text || stripTags(this._html); }
  set textContent(v) { this._text = String(v); this.children = []; }
  appendChild(c) { c.parentNode = this; this.children.push(c); return c; }
  removeChild(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); return c; }
  remove() { if (this.parentNode) this.parentNode.removeChild(this); }
  setAttribute(k, v) {
    this.attrs[k] = String(v);
    if (k === 'id') this.id = String(v);
    if (k === 'class') String(v).split(/\s+/).filter(Boolean).forEach((c) => this.classList.add(c));
    if (k.startsWith('data-')) this.dataset[k.slice(5).replace(/-([a-z])/g, (m, c) => c.toUpperCase())] = String(v);
  }
  getAttribute(k) { return this.attrs[k] === undefined ? null : this.attrs[k]; }
  removeAttribute(k) { delete this.attrs[k]; }
  addEventListener(type, fn) { (this._ev = this._ev || {})[type] = (this._ev[type] || []).concat(fn); }
  removeEventListener() {}
  dispatch(type, ev) {
    const fns = ((this._ev && this._ev[type]) || []).slice();
    const inline = this['on' + type];
    if (typeof inline === 'function') fns.push(inline);
    const event = Object.assign({ type, preventDefault() {}, stopPropagation() {}, target: this, key: '', dataTransfer: null }, ev || {});
    fns.forEach((f) => f(event));
  }
  click() { this.dispatch('click'); }
  focus() {} blur() {} select() {}
  showModal() { this.open = true; } close() { this.open = false; }
  querySelector(sel) { return matches(this, sel)[0] || null; }
  querySelectorAll(sel) { return matches(this, sel); }
  closest(sel) {
    let n = this;
    while (n) {
      if (n.nodeType === 1 && matches(n.parentNode || documentStub.body, sel).includes(n)) return n;
      n = n.parentNode;
    }
    return null;
  }
  contains(other) {
    let n = other;
    while (n) { if (n === this) return true; n = n.parentNode; }
    return false;
  }
  get firstChild() { return this.children[0] || null; }
  get lastChild() { return this.children[this.children.length - 1] || null; }
  get firstElementChild() { return this.children[0] || null; }
  get options() { return this.children.filter((c) => c.tagName === 'OPTION'); }
}

function stripTags(s) { return String(s).replace(/<[^>]*>/g, ''); }

/** 把仿真节点还原成 HTML 字符串 */
function serialize(node) {
  if (node.nodeType === 3 || node.tagName === 'TEXT') return node._text;
  const attrs0 = Object.assign({}, node.attrs || {});
  // class 必须取**活的** classList，而不是解析时的原始属性：
  // 浏览器里 classList.add('hidden') 之后，序列化出来的 HTML 也是带 hidden 的。
  // 此前这里用的是解析时存下的 class 属性，于是"JS 改了类名"在落盘/对比时完全看不见
  // （--dump 出来的预览页会把登录页和主界面同时画出来，正是这个原因）。
  if (node.classList && node.classList.value) attrs0.class = node.classList.value;
  else if (attrs0.class !== undefined && !String(attrs0.class).trim()) delete attrs0.class;
  const attrs = Object.entries(attrs0).map(([k, v]) => ` ${k}="${v}"`).join('');
  const inner = node.children.length ? node.children.map(serialize).join('') : (node._html || node._text || '');
  const styleAttr = node.style && Object.keys(node.style).length
    ? Object.entries(node.style).map(([k, v]) => ` style="${k}:${v}"`).join('') : '';
  return `<${node.tagName.toLowerCase()}${attrs}${styleAttr}>${inner}</${node.tagName.toLowerCase()}>`;
}

/** 极简选择器：支持 tag / .class / #id / [attr] 及其组合（空格分隔的后代组合暂按“全部”匹配） */
function matches(root, selector) {
  const out = [];
  const parts = String(selector).split(',').map((s) => s.trim()).filter(Boolean);
  const all = [];
  const walk = (n) => { for (const c of n.children) { all.push(c); walk(c); } };
  walk(root);
  for (const sel of parts) {
    const last = sel.split(/\s+/).pop();
    const test = (n) => {
      const m = /^([a-zA-Z][\w-]*)?((?:[.#][\w-]+|\[[^\]]+\])*)$/.exec(last);
      if (!m) return false;
      if (m[1] && n.tagName !== m[1].toUpperCase()) return false;
      const tokens = m[2].match(/[.#][\w-]+|\[[^\]]+\]/g) || [];
      for (const t of tokens) {
        if (t.startsWith('.')) { if (!n.classList.contains(t.slice(1))) return false; }
        else if (t.startsWith('#')) { if (n.id !== t.slice(1)) return false; }
        else {
          const inner = t.slice(1, -1);
          const eq = inner.indexOf('=');
          const k = eq < 0 ? inner : inner.slice(0, eq);
          if (eq < 0) { if (n.attrs[k] === undefined) return false; }
          else {
            const v = inner.slice(eq + 1).replace(/^["']|["']$/g, '');
            if (String(n.attrs[k]) !== v) return false;
          }
        }
      }
      return true;
    };
    for (const n of all) if (test(n) && !out.includes(n)) out.push(n);
  }
  return out;
}

function buildFromHtml(source) {
  const body = new El('body');
  const stack = [body];
  const tagRe = /<(\/?)([a-zA-Z][\w-]*)((?:\s+[^>]*?)?)(\/?)>/g;
  let m;
  let lastIndex = 0;
  while ((m = tagRe.exec(source))) {
    const between = source.slice(lastIndex, m.index);
    lastIndex = tagRe.lastIndex;
    if (/[^\s]/.test(between)) {
      const text = between.trim();
      if (text) stack[stack.length - 1]._text += text;
    }
    const [, closing, tag, rawAttrs, selfClose] = m;
    const tagUpper = tag.toUpperCase();
    if (closing) { if (stack.length > 1) stack.pop(); continue; }
    const node = new El(tag);
    const attrRe = /([\w:-]+)(?:\s*=\s*"([^"]*)"|\s*=\s*'([^']*)')?/g;
    let a;
    while ((a = attrRe.exec(rawAttrs || ''))) {
      const key = a[1];
      const val = a[2] !== undefined ? a[2] : (a[3] !== undefined ? a[3] : '');
      node.setAttribute(key, val);
    }
    node._html = '';
    stack[stack.length - 1].appendChild(node);
    const voidTags = ['INPUT', 'BR', 'HR', 'IMG', 'META', 'LINK'];
    if (!selfClose && !voidTags.includes(tagUpper)) stack.push(node);
  }
  return body;
}

const errors = [];
const consoleErrors = [];
const documentStub = {
  body: null,
  documentElement: new El('html'),
  readyState: 'complete',
  _listeners: {},
  createElement: (t) => new El(t),
  createTextNode: (t) => { const e = new El('text'); e._text = t; return e; },
  getElementById: (id) => matches(documentStub.body, '#' + id)[0] || null,
  querySelector: (sel) => matches(documentStub.body, sel)[0] || null,
  querySelectorAll: (sel) => matches(documentStub.body, sel),
  addEventListener(type, fn) { (this._listeners[type] = this._listeners[type] || []).push(fn); },
  removeEventListener() {},
  dispatch(type, ev) { (this._listeners[type] || []).forEach((f) => f(Object.assign({ type, preventDefault() {} }, ev || {}))); },
};
documentStub.body = buildFromHtml(htmlSource);

// ---------------------------------------------------------------- 运行环境
const storage = new Map();
const sandbox = {
  console: {
    log: () => {},
    warn: () => {},
    error: (...a) => { consoleErrors.push(a.map(String).join(' ')); },
  },
  document: documentStub,
  window: {
    location: { href: BASE + '/', assign() {}, replace() {} },
    open: () => null,
    addEventListener: () => {},
    setTimeout: (fn, ms) => setTimeout(fn, ms),
    localStorage: {
      getItem: (k) => (storage.has(k) ? storage.get(k) : null),
      setItem: (k, v) => storage.set(k, String(v)),
      removeItem: (k) => storage.delete(k),
    },
  },
  localStorage: {
    getItem: (k) => (storage.has(k) ? storage.get(k) : null),
    setItem: (k, v) => storage.set(k, String(v)),
    removeItem: (k) => storage.delete(k),
  },
  setTimeout, clearTimeout, setInterval, clearInterval,
  URLSearchParams, URL, Date, Math, JSON, Number, String, Array, Object, Boolean, Error, Promise, Set, Map,
  FormData: class FormData {
    constructor() { this.map = new Map(); }
    append(k, v) { const list = this.map.get(k) || []; list.push(v); this.map.set(k, list); }
    get(k) { return (this.map.get(k) || [])[0]; }
    set(k, v) { this.map.set(k, [v]); }
    entries() { return this.map.entries(); }
    forEach(fn) { for (const [k, list] of this.map) list.forEach((v) => fn(v, k)); }
    has(k) { return this.map.has(k); }
  },
  XMLHttpRequest: class XHR {
    open() {} send() { if (this.onerror) this.onerror(new Error('仿真环境不支持 XHR 上传')); }
    setRequestHeader() {}
  },
  fetch: (...args) => fetch(...args),
  alert: (m) => consoleErrors.push('alert: ' + m),
};

// 会话 cookie 共享：把服务端下发的 cookie 透传回后续请求
let cookieJar = '';
sandbox.fetch = async (url, opts = {}) => {
  const full = String(url).startsWith('http') ? String(url) : BASE + String(url);
  const headers = Object.assign({}, opts.headers);
  if (cookieJar) headers.Cookie = cookieJar;
  const res = await fetch(full, Object.assign({}, opts, { headers, redirect: 'manual' }));
  const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  if (sc.length) {
    const jar = new Map(cookieJar ? cookieJar.split('; ').map((p) => p.split('=')) : []);
    for (const c of sc) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      jar.set(pair.slice(0, i).trim(), pair.slice(i + 1).trim());
    }
    cookieJar = [...jar].filter(([, v]) => v !== '').map(([k, v]) => `${k}=${v}`).join('; ');
  }
  return res;
};

const context = vm.createContext(sandbox);
process.on('uncaughtException', (e) => { errors.push(e); });
process.on('unhandledRejection', (e) => { errors.push(e); });

// ---------------------------------------------------------------- 执行
const appSource = fs.readFileSync(path.join(ROOT, 'public', 'js', 'app.js'), 'utf8');
vm.runInContext(appSource, context, { filename: 'app.js' });

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function settle(label) {
  for (let i = 0; i < 40; i++) {
    await wait(50);
    const txt = documentStub.getElementById('content');
    if (txt && !txt.innerHTML.includes('加载中…') && txt.innerHTML.length > 50) break;
  }
  const content = documentStub.getElementById('content');
  const body = content ? content.innerHTML : '';
  const bad = /加载失败|加载中…/.test(body);
  console.log(`  ${bad ? '✗' : '✓'} ${label} — 渲染 ${body.length} 字符${bad ? '（出现加载失败或未完成）' : ''}`);
  if (bad) {
    const idx = Math.max(0, body.indexOf('加载失败'));
    errors.push(new Error(`${label} 渲染异常：${body.slice(idx, idx + 260)}`));
  } else if (body.length < 500 && label !== '页面：create') {
    console.log('    内容片段：' + body.replace(/\s+/g, ' ').slice(0, 200));
  }
  // --dump <目录>：把这一屏的**完整 DOM** 落盘，供肉眼/截图核对版面。
  // 为什么要落盘整个 body 而不是只落 #content：侧栏、顶栏、弹窗都是版面的一部分，
  // 只看内容区看不出"菜单分组对不对、小屏抽屉有没有生效"。
  if (DUMP_DIR) {
    try {
      fs.mkdirSync(DUMP_DIR, { recursive: true });
      const name = String(label).replace(/[\\/:*?"<>|\s（）()]+/g, '_').slice(0, 60);
      fs.writeFileSync(path.join(DUMP_DIR, `${String(dumpSeq++).padStart(2, '0')}-${name}.html`),
        documentStub.body.innerHTML, 'utf8');
    } catch (e) { console.log('    (dump 失败：' + e.message + ')'); }
  }
  return body;
}

/**
 * 切到某个页面（v4.31.0 起导航有两条路）。
 * 原来只有左侧导航 #nav .nav-item；工作台改版后，档案检索/著录/正文检索/扫码
 * 收进了工作台磁贴（wb-tile[data-go]），导航里就没有这些项了 —— 冒烟测试若还只认
 * 导航，会拿到 undefined 再调 dispatch，直接崩在半路（而页面本身完全正常）。
 * 所以这里先找导航，找不到就回工作台点磁贴。
 */
async function goToView(view) {
  const nav = documentStub.querySelectorAll('#nav .nav-item');
  const item = nav.find((n) => n.dataset.view === view);
  if (item) { item.dispatch('click'); return true; }
  let tile = documentStub.querySelectorAll('#content [data-go="' + view + '"]')[0];
  if (!tile) {
    const home = nav.find((n) => n.dataset.view === 'workbench');
    if (home) {
      home.dispatch('click');
      await wait(300);
      tile = documentStub.querySelectorAll('#content [data-go="' + view + '"]')[0];
    }
  }
  if (!tile) return false;
  tile.dispatch('click');
  return true;
}

async function main() {
  console.log('前端渲染冒烟测试 → ' + BASE + '\n');
  await wait(600);

  // 渲染完成没有回调可用（app.js 是异步 fetch + 直写 innerHTML），
  // 固定 wait(900) 在慢机器/冷库上会抢跑：登录还没回来就判"没进主界面"，
  // 页面刚点击还没画完就判"找不到子页签"。所以关键节点一律改成"等到条件成立"。
  async function waitUntil(fn, ms = 6000) {
    const until = Date.now() + ms;
    for (;;) {
      try { if (fn()) return true; } catch (_) { /* 还没准备好 */ }
      if (Date.now() > until) return false;
      await wait(100);
    }
  }

  const loginView = documentStub.getElementById('login-view');
  const appView = documentStub.getElementById('app-view');
  console.log('  ' + (!loginView.classList.contains('hidden') ? '✓' : '✗') + ' 初始显示登录页');
  console.log('  ' + (appView.classList.contains('hidden') ? '✓' : '✗') + ' 初始隐藏主界面');

  // 走真实登录表单提交（登录页只有「身份 + 口令」两个框，v4.19.0）
  documentStub.getElementById('login-identity').value = 'manager';
  documentStub.getElementById('login-password').value = 'admin123';
  documentStub.getElementById('login-form').dispatch('submit');
  await waitUntil(() => !appView.classList.contains('hidden')
    && documentStub.getElementById('user-name').textContent === '系统管理员', 10000);

  console.log('  ' + (!appView.classList.contains('hidden') ? '✓' : '✗') + ' 提交表单后进入主界面');
  console.log('  ' + (documentStub.getElementById('user-name').textContent === '系统管理员' ? '✓' : '✗')
    + ' 顶栏显示当前用户：' + documentStub.getElementById('user-name').textContent);

  await settle('工作台（统计卡片+图表+最近入库）');

  // v4.30.0：要有「接收作业区」，且左右两个版块（按录入时间 / 按项目）都在。
  // v4.31.0 起接收作业区不在工作台首页，而在「看板」页（工作台改成四张磁贴 + 统计卡）。
  // ⚠ 这里查的是**结构标记**（id），不是中文标题文字：
  //   本测试的 DOM 桩在"元素与文字混排"（如 <h3>接收作业区<span>…）时会丢掉纯文字节点，
  //   查文字会误报"没渲染"；而在真实浏览器里这种混排完全正常。
  if (await goToView('dashboard')) {
    await settle('看板（接收作业区）');
    await waitUntil(() => {
      const h = documentStub.getElementById('content').innerHTML;
      return h.includes('wb-new-batch') || h.includes('wb-new-project');
    }, 6000);
    const dashHtml = documentStub.getElementById('content').innerHTML;
    const hasWb = dashHtml.includes('wb-new-batch') || dashHtml.includes('wb-new-project');
    const hasCols = dashHtml.includes('wb-col-date') && dashHtml.includes('wb-col-project');
    if (!hasWb) errors.push(new Error('看板没有「接收作业区」'));
    if (!hasCols) errors.push(new Error('接收作业区的两个版块缺失'));
    console.log('  ' + (hasWb ? '✓' : '✗') + ' 看板含接收作业区（v4.30.0）');
    console.log('  ' + (hasCols ? '✓' : '✗') + ' 作业区两栏（按录入时间 / 按项目）都在');
    // 回工作台：后面的页面遍历以工作台为起点
    if (await goToView('workbench')) await wait(300);
  } else {
    errors.push(new Error('找不到「看板」入口'));
  }

  const navItems = documentStub.querySelectorAll('#nav .nav-item');
  console.log('  导航项数量：' + navItems.length);
  console.log('  绑定检查：' + navItems.map((n) => n.dataset.view + '=' + (typeof n.onclick === 'function' ? 'on' : 'off')).join(', '));
  console.log('  当前页面标识：' + documentStub.getElementById('crumb').textContent);

  const views = ['archives', 'textsearch', 'create', 'retention', 'storage', 'transfer', 'quality', 'import', 'loans', 'logs', 'manage'];
  for (const v of views) {
    if (!(await goToView(v))) { errors.push(new Error('找不到页面入口 ' + v)); continue; }
    await settle('页面：' + v);
  }

  // 第 2 版新增页面的子页签（注意各页签使用的 data 属性名不同）
  const subTabs = [
    ['retention', 'destroy', 'data-rtab', '到期与鉴定 / 销毁清册'],
    ['storage', 'locations', 'data-stab', '实体管理 / 库位'],
    ['storage', 'checks', 'data-stab', '实体管理 / 盘点'],
    ['storage', 'boxes', 'data-stab', '实体管理 / 档案盒'],
    ['manage', 'numbering', 'data-tab', '系统管理 / 档号规则'],
  ];
  for (const [view, tab, attr, label] of subTabs) {
    if (!(await goToView(view))) { errors.push(new Error('找不到页面入口 ' + view)); continue; }
    const pick = () => documentStub.querySelectorAll('#content [' + attr + ']')
      .find((b) => (b.dataset.tab || b.dataset.stab || b.dataset.rtab) === tab);
    await waitUntil(() => !!pick(), 6000);
    const btnEl = pick();
    if (!btnEl) { errors.push(new Error('找不到子页签 ' + label)); continue; }
    btnEl.dispatch('click');
    await settle(label);
  }

  // 系统管理四个子页
  const manageTabs = ['users', 'cats', 'data', 'about'];
  for (const tab of manageTabs) {
    if (!(await goToView('manage'))) { errors.push(new Error('找不到「系统管理」入口')); break; }
    await wait(500);
    const btnEl = documentStub.querySelectorAll('#content [data-tab]').find((b) => b.dataset.tab === tab);
    if (!btnEl) { errors.push(new Error('找不到系统管理子页签 ' + tab)); continue; }
    btnEl.dispatch('click');
    await settle('系统管理 / ' + tab);
  }

  // ---- 二维码 / 手机扫码：设置项与「扫码自检」面板必须真的渲染出来 ----
  // 这一组是 v3.0.2 的重点：二维码扫不出来时，用户唯一的自助排查入口就是这里，
  // 所以不能只保证接口对，页面也得真渲染出来。
  {
    if (await goToView('manage')) await wait(500);
    const tabBtn = documentStub.querySelectorAll('#content [data-tab]').find((b) => b.dataset.tab === 'numbering');
    if (tabBtn) { tabBtn.dispatch('click'); await settle('系统管理 / 档号规则（二维码设置）'); }
    const pageHtml = documentStub.getElementById('content').innerHTML;
    for (const [label, needle] of [
      ['二维码内容模式下拉', 'set-qrmode'],
      ['网址前缀输入框', 'set-qrbase'],
      ['扫码自检按钮', 'btn-scan-check'],
    ]) {
      if (pageHtml.includes(needle)) console.log('  ✓ 档号规则页含' + label);
      else { errors.push(new Error('档号规则页缺少' + label)); console.log('  ✗ 档号规则页缺少' + label); }
    }

    const scanBtn = documentStub.querySelectorAll('#content #btn-scan-check')[0];
    if (!scanBtn || typeof scanBtn.onclick !== 'function') {
      errors.push(new Error('「扫码自检」按钮没有绑定点击事件'));
      console.log('  ✗ 「扫码自检」按钮没有绑定点击事件');
    } else {
      scanBtn.dispatch('click');
      // 不能只靠 settle()：settle() 等的是 #content 渲染完成，而「扫码自检」是异步的 ——
      // 按钮处理函数里要先 await /api/system/net，请求回来才把内容写进 modal-body。
      // settle() 会在请求返回之前就返回，于是模态框读出来是空的。
      // 实测：服务器稍忙时（例如刚跑完一批二维码重建）请求超过 50ms，这个误报会稳定复现 ——
      // 表现为「扫码自检面板没有渲染出二维码 / 缺少排查说明 / 缺少自检页入口」三条同时失败。
      // 所以这里改为主动轮询 modal-body，最多等 3 秒。
      for (let i = 0; i < 60; i++) {
        await wait(50);
        const mb = documentStub.getElementById('modal-body');
        if (mb && /qrcode\.svg/.test(mb.innerHTML)) break;
      }
      await settle('扫码自检面板');
      const modalBody = documentStub.getElementById('modal-body');
      // 注意：DOM 仿真桩的 innerHTML 只保留元素、不保留纯文本节点，
      // 所以「有没有二维码图片」看 innerHTML，「有没有文字说明」看 textContent，
      // 两者合起来判断，才既严格又不会误报。
      const bodyHtml = modalBody.innerHTML;
      const bodyText = modalBody.textContent || '';
      const both = bodyHtml + '\n' + bodyText;
      const qrCount = (bodyHtml.match(/qrcode\.svg/g) || []).length;
      if (qrCount >= 1 && /qrcode\.svg\?text=/.test(bodyHtml)) {
        console.log(`  ✓ 扫码自检面板弹出，含 ${qrCount} 张可扫二维码`);
      } else {
        errors.push(new Error('扫码自检面板没有渲染出二维码'));
        console.log('  ✗ 扫码自检面板没有渲染出二维码：' + bodyHtml.replace(/\s+/g, ' ').slice(0, 200));
      }
      if (/可用地址|排查|局域网|自检页/.test(both)) {
        console.log('  ✓ 面板含地址清单与排查说明');
      } else {
        errors.push(new Error('扫码自检面板缺少排查说明'));
        console.log('  ✗ 扫码自检面板缺少排查说明：' + both.replace(/\s+/g, ' ').slice(0, 200));
      }
      if (/qrcode\/selftest/.test(bodyHtml)) {
        console.log('  ✓ 面板提供「二维码自检页」入口（区分码问题与网络问题）');
      } else {
        errors.push(new Error('扫码自检面板缺少自检页入口'));
        console.log('  ✗ 扫码自检面板缺少自检页入口');
      }
      if (/只监听本机|局域网里连不上/.test(both)) {
        console.log('    （面板已提示：当前未开启局域网访问，手机连不上）');
      }
      documentStub.getElementById('modal').close();
      await wait(200);
    }
  }

  // 档案详情弹窗（真实调用）
  // 注意：出厂分发包的库是空的，这里不能假设已有档案，
  // 需要时先建一条测试档案，跑完再删掉，保证脚本在空库上也能通过。
  let list = await (await fetch(BASE + '/api/archives?size=1', { headers: { Cookie: cookieJar } })).json();
  let fixtureId = null;
  if (!list.data.list.length) {
    const cats = await (await fetch(BASE + '/api/categories', { headers: { Cookie: cookieJar } })).json();
    const cat = cats.data.flat.find((c) => c.code === 'WS-XZ') || cats.data.flat[0];
    const mk = await fetch(BASE + '/api/archives', {
      method: 'POST',
      headers: { Cookie: cookieJar, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type_code: 'WS', title: '冒烟测试用档案（脚本自动清理）', category_id: cat.id,
        year: '2099', archive_date: '2099-01-01', retention: '永久', responsible: '自测',
      }),
    });
    const mkJson = await mk.json();
    if (mkJson.ok) {
      fixtureId = mkJson.data.id;
      console.log('  （空库环境：已临时建立 1 条测试档案）');
      list = await (await fetch(BASE + '/api/archives?size=1', { headers: { Cookie: cookieJar } })).json();
    }
  }
  const firstId = list.data.list.length ? list.data.list[0].id : null;
  if (firstId === null) {
    errors.push(new Error('无法准备用于详情弹窗测试的档案'));
  }
  if (await goToView('archives')) await settle('档案检索列表');
  else errors.push(new Error('找不到「档案检索」入口'));
  const rows = documentStub.querySelectorAll('#content tr[data-id]');
  console.log('  检索结果行数：' + rows.length);
  if (rows.length) {
    console.log('    首行 dataset.id=' + rows[0].dataset.id + ' onclick=' + typeof rows[0].onclick
      + ' 选择器命中详情行数=' + documentStub.querySelectorAll('#content tr[data-id]').length);
    rows[0].dispatch('click');
    await wait(1500);
    const dbg = documentStub.getElementById('modal-body').children[0];
    console.log('    modal-body 子节点: ' + (dbg ? dbg.tagName + ' len=' + dbg.innerHTML.length : '(无)'));
    if (dbg) console.log('    子节点全文片段: ' + dbg.innerHTML.replace(/\s+/g, ' ').slice(0, 260));
    let modalHtml = '';
    for (let i = 0; i < 40; i++) {
      await wait(60);
      modalHtml = documentStub.getElementById('modal-body').innerHTML;
      if (modalHtml.includes('著录信息')) break;
    }
    const ok = modalHtml.includes('著录信息') && modalHtml.includes('电子附件');
    console.log('  ' + (ok ? '✓' : '✗') + ` 打开档案详情弹窗（渲染 ${modalHtml.length} 字符）`);
    if (!ok) errors.push(new Error('详情弹窗渲染异常：' + modalHtml.replace(/\s+/g, ' ').slice(0, 240)));
    documentStub.getElementById('modal').close();
  }

  // 前端工具函数：预览按钮探测（用真实文件）
  const files = firstId
    ? await (await fetch(BASE + `/api/archives/${firstId}`, { headers: { Cookie: cookieJar } })).json()
    : { data: { files: [] } };
  if (files.data.files && files.data.files.length) {
    if (rows[0]) {
      rows[0].dispatch('click');
      for (let i = 0; i < 40; i++) {
        await wait(60);
        if (documentStub.getElementById('modal-body').innerHTML.includes('电子附件')) break;
      }
    }
    const pv = documentStub.querySelectorAll('#modal-body [data-fact="preview"]')[0];
    if (pv) {
      pv.dispatch('click');
      let after = '';
      for (let i = 0; i < 40; i++) {
        await wait(60);
        after = documentStub.getElementById('modal-body').innerHTML;
        if (!after.includes('加载中…')) break;
      }
      const hasBox = after.includes('preview-box');
      console.log('  ' + (hasBox ? '✓' : '✗') + ' 附件预览弹窗可打开并载入内容');
      if (!hasBox) errors.push(new Error('预览弹窗异常：' + after.replace(/\s+/g, ' ').slice(0, 240)));
      documentStub.getElementById('modal').close();
    } else {
      console.log('  - 未找到预览按钮，跳过预览检查');
    }
  } else {
    console.log('  - 该档案没有附件，跳过预览检查');
  }

  await wait(500);
  const toastCount = documentStub.getElementById('toast-wrap').children.length;
  console.log('  当前提示条数量：' + toastCount);

  // 清理临时建立的测试档案，保证脚本可重复运行、不污染数据
  if (fixtureId) {
    const del = await fetch(BASE + '/api/archives/' + fixtureId, { method: 'DELETE', headers: Object.assign({ 'Content-Type': 'application/json' }, { Cookie: cookieJar }), body: JSON.stringify({ reason: '测试夹具清理' }) });
    console.log('  ' + (del.ok ? '✓' : '✗') + ' 已清理临时测试档案');
    if (!del.ok) errors.push(new Error('临时测试档案清理失败，请手工检查 id=' + fixtureId));
  }

  console.log('\n' + '='.repeat(56));
  if (errors.length) {
    console.log(`前端冒烟测试：发现 ${errors.length} 个运行时问题`);
    errors.forEach((e) => console.log('  - ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n    ') : e)));
    if (consoleErrors.length) {
      console.log('\n控制台错误输出：');
      consoleErrors.forEach((e) => console.log('  - ' + e));
    }
    console.log('='.repeat(56));
    process.exit(1);
  }
  console.log('前端冒烟测试：全部通过，未发现运行时错误');
  console.log('='.repeat(56));
  process.exit(0);
}

main().catch((e) => {
  console.error('冒烟测试异常终止：', e);
  process.exit(1);
});
