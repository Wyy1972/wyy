/**
 * 独立二维码解码器：直接读图片文件（PNG），解码出内容。
 *
 * 用途：判定"扫不出来"到底是
 *   (a) 二维码本身生成错了（解码失败），还是
 *   (b) 二维码没错，是网络/地址/打印等别的原因（能解码出内容）。
 *
 * 这里不复用项目里的任何生成代码，是独立实现，避免"双方错得一致"。
 * 支持：PNG（8 位灰度/RGB/RGBA，自带 zlib 解压）、BMP（24/32 位未压缩）。
 */
'use strict';

const fs = require('node:fs');
const zlib = require('node:zlib');

// ============================================================ 图片读取
function readPng(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是 PNG');
  let pos = 8;
  let width = 0, height = 0, bitDepth = 0, colorType = 0;
  const idat = [];
  while (pos + 8 <= buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.slice(pos + 4, pos + 8).toString('latin1');
    const data = buf.slice(pos + 8, pos + 8 + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  /**
   * 支持 8 位与 1 位灰度。
   *
   * 1 位深是必须支持的：Python 的 qrcode 库（qrcode[pil]）默认就输出 1 位深的 PNG，
   * 而「每份档案一张二维码」允许用 Python 引擎生成，验证时就得能读它的产物。
   *
   * 注意：PNG 的反滤波是**按字节**做的，位深小于 8 时每个字节里塞多个像素，
   * 所以必须先按字节反滤波（bpp 按 1 算），再把位拆成像素。
   * 之前这里是「跳过 filter 字节直接取原始字节」，遇到非 0 滤波器时整行会错位。
   */
  if (bitDepth !== 8 && bitDepth !== 1) {
    throw new Error('仅支持 1 位或 8 位深度的 PNG（实际 ' + bitDepth + '）');
  }
  if (bitDepth === 1 && colorType !== 0 && colorType !== 3) {
    throw new Error('1 位深仅支持灰度(0)或调色板(3) PNG（实际颜色类型 ' + colorType + '）');
  }
  const channels = { 0: 1, 2: 3, 4: 2, 6: 4 }[colorType];
  if (!channels) throw new Error('不支持的 PNG 颜色类型 ' + colorType);
  const raw = zlib.inflateSync(Buffer.concat(idat));

  const is1bit = bitDepth === 1;
  const stride = is1bit ? Math.ceil(width / 8) : width * channels;
  const bpp = is1bit ? 1 : channels;
  const out = Buffer.alloc(height * stride);
  let rp = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[rp++];
    const line = raw.slice(rp, rp + stride);
    rp += stride;
    const prev = y > 0 ? out.slice((y - 1) * stride, y * stride) : Buffer.alloc(stride);
    const cur = out.slice(y * stride, (y + 1) * stride);
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? cur[x - bpp] : 0;
      const b = prev[x];
      const c = x >= bpp ? prev[x - bpp] : 0;
      let v = line[x];
      if (filter === 1) v = (v + a) & 0xff;
      else if (filter === 2) v = (v + b) & 0xff;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 0xff;
      else if (filter === 4) {
        const p = a + b - c;
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v = (v + (pa <= pb && pa <= pc ? a : (pb <= pc ? b : c))) & 0xff;
      }
      cur[x] = v;
    }
  }

  // 1 位深：反滤波完再按位拆成 8 位灰度（0 位 = 黑，1 位 = 白）
  if (is1bit) {
    const gray = Buffer.alloc(height * width);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const byte = out[y * stride + (x >> 3)];
        const bit = (byte >> (7 - (x & 7))) & 1;
        gray[y * width + x] = bit ? 0xff : 0x00;
      }
    }
    return { width, height, channels: 1, data: gray };
  }

  return { width, height, channels, data: out };
}

function readBmp(buf) {
  if (buf.readUInt16LE(0) !== 0x4d42) throw new Error('不是 BMP');
  const dataOffset = buf.readUInt32LE(10);
  const width = buf.readInt32LE(18);
  const heightRaw = buf.readInt32LE(22);
  const height = Math.abs(heightRaw);
  const bpp = buf.readUInt16LE(28);
  if (bpp !== 24 && bpp !== 32) throw new Error('仅支持 24/32 位 BMP（实际 ' + bpp + '）');
  const bytesPerPx = bpp / 8;
  const rowSize = Math.floor((bpp * width + 31) / 32) * 4;
  const bottomUp = heightRaw > 0;
  const data = Buffer.alloc(width * height * 3);
  for (let y = 0; y < height; y++) {
    const srcY = bottomUp ? height - 1 - y : y;
    const rowStart = dataOffset + srcY * rowSize;
    for (let x = 0; x < width; x++) {
      const s = rowStart + x * bytesPerPx;
      const d = (y * width + x) * 3;
      data[d] = buf[s + 2]; data[d + 1] = buf[s + 1]; data[d + 2] = buf[s];
    }
  }
  return { width, height, channels: 3, data };
}

/** 读成灰度矩阵（0=黑, 1=白），并按阈值二值化 */
function toGray(img) {
  const { width, height, channels, data } = img;
  const g = new Float32Array(width * height);
  for (let i = 0; i < width * height; i++) {
    const o = i * channels;
    const r = data[o], gg = data[o + 1] || r, b = data[o + 2] || r;
    g[i] = 0.299 * r + 0.587 * gg + 0.114 * b;
  }
  return { width, height, gray: g };
}

/** 大津法求阈值 */
function otsu(gray) {
  const hist = new Array(256).fill(0);
  for (const v of gray.gray) hist[Math.max(0, Math.min(255, Math.round(v)))]++;
  const total = gray.gray.length;
  let sum = 0;
  for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, best = 0, thr = 128;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (!wB) continue;
    const wF = total - wB;
    if (!wF) break;
    sumB += t * hist[t];
    const mB = sumB / wB, mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) { best = between; thr = t; }
  }
  return thr;
}

/** 粗略定位三个定位图案：在二值图里按"1:1:3:1:1"横向扫描 */
function findFinderCenters(bin, width, height) {
  const cands = [];
  const check = (x, y) => {
    // 以 (x,y) 为中心，验证 7 格比例与中心为黑
    const line = [];
    let i = x;
    while (i >= 0 && bin[y * width + i] === 1) i--;
    const s1 = x - i;
    while (i >= 0 && bin[y * width + i] === 0) i--;
    const s2 = i === -1 ? s1 : (i + 1) - i;
    let j = x;
    while (j < width && bin[y * width + j] === 1) j++;
    const e1 = j - x;
    while (j < width && bin[y * width + j] === 0) j++;
    const e2 = j - x;
    return { s1, e1 };
  };
  // 用更稳的方式：滑动窗口找中心点（上下左右都满足 3 格黑）
  for (let y = 3; y < height - 3; y++) {
    for (let x = 3; x < width - 3; x++) {
      if (bin[y * width + x] !== 1) continue;
      // 中心 3x3 必须全黑
      let ok = true;
      for (let dy = -1; dy <= 1 && ok; dy++) {
        for (let dx = -1; dx <= 1; dx++) if (bin[(y + dy) * width + (x + dx)] !== 1) { ok = false; break; }
      }
      if (!ok) continue;
      // 往外一圈（半径2）应为白
      const ring2 = [[0, -2], [0, 2], [-2, 0], [2, 0]];
      for (const [dx, dy] of ring2) if (bin[(y + dy) * width + (x + dx)] !== 0) { ok = false; break; }
      if (!ok) continue;
      // 再往外（半径3）应为黑
      const ring3 = [[0, -3], [0, 3], [-3, 0], [3, 0]];
      for (const [dx, dy] of ring3) if (bin[(y + dy) * width + (x + dx)] !== 1) { ok = false; break; }
      if (!ok) continue;
      cands.push({ x, y });
    }
  }
  // 聚类去重
  const centers = [];
  for (const c of cands) {
    const near = centers.find((k) => Math.abs(k.x - c.x) < 14 && Math.abs(k.y - c.y) < 14);
    if (near) { near.n++; near.x = (near.x * (near.n - 1) + c.x) / near.n; near.y = (near.y * (near.n - 1) + c.y) / near.n; }
    else centers.push({ x: c.x, y: c.y, n: 1 });
  }
  return centers.filter((c) => c.n >= 1).sort((a, b) => b.n - a.n);
}

/**
 * 直接网格采样法（对「导出的 PNG/BMP」这类无旋转、无透视、每格像素为整数倍的图片最可靠）。
 * 不依赖定位图案检测——定位检测需要处理旋转/透视/模糊，容易误判；
 * 而这类图片只要找到内容边界并按格宽采样即可。
 */
function decodeByGrid(bin, W, H) {
  // 1) 内容边界（去掉白边）。bin: 1=黑 0=白
  let minX = W, maxX = -1, minY = H, maxY = -1;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      if (bin[y * W + x] === 1) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return { ok: false, reason: '图片全白，没有内容' };
  const w = maxX - minX + 1;
  const h = maxY - minY + 1;
  if (Math.abs(w - h) > Math.max(w, h) * 0.05) {
    return { ok: false, reason: `内容区不是正方形（${w}x${h}），可能是旋转或有透视` };
  }

  // 2) 估计每格像素：统计扫描线上的游程，取最小游程的众数（一个模块）
  const runs = [];
  for (const fy of [0.5, 0.25, 0.75, 0.35, 0.65]) {
    const y = Math.min(H - 1, Math.floor(minY + h * fy));
    let cur = bin[y * W + minX] === 1, len = 0;
    for (let x = minX; x <= maxX; x++) {
      const d = bin[y * W + x] === 1;
      if (d === cur) len++;
      else { if (len > 0) runs.push(len); cur = d; len = 1; }
    }
    if (len > 0) runs.push(len);
  }
  if (!runs.length) return { ok: false, reason: '无法估计格宽（扫描线全为同色）' };
  runs.sort((a, b) => a - b);
  const minRun = runs[0];

  /**
   * 估计格宽并采样。
   *
   * 只按「最小游程 = 一个模块」来估并不稳：当整幅图里恰好没有单模块宽的
   * 黑白交替（例如内容区较密时），最小游程会被高估成 2 个模块，
   * 于是模块数被算成 32 这种非法尺寸，白白解不出。
   *
   * 所以这里改为：把最小游程附近的几个可能格宽都试一遍，
   * 每个候选都做「采样 → 校验定位图案 → RS 解码」，谁解得出来就用谁。
   * 反正 RS 校验是硬门槛，不会误判。
   */
  const tryCell = (cell, offsetX, offsetY) => {
    const nn = Math.round(w / cell);
    if (nn < 21 || nn > 57 || (nn - 17) % 4 !== 0) return null;
    const stepX = w / nn, stepY = h / nn;
    const mods = [];
    for (let r = 0; r < nn; r++) {
      const row = [];
      const py = Math.min(H - 1, Math.round(offsetY + (r + 0.5) * stepY));
      for (let c = 0; c < nn; c++) {
        const px = Math.min(W - 1, Math.round(offsetX + (c + 0.5) * stepX));
        row.push(bin[py * W + px]);
      }
      mods.push(row);
    }
    if (!finderOkIn(mods, nn, 0, 0)) return null;
    if (!finderOkIn(mods, nn, nn - 7, 0)) return null;
    if (!finderOkIn(mods, nn, 0, nn - 7)) return null;
    const version = (nn - 17) / 4;
    const res = tryDecodeModules(mods, nn, version);
    return res && res.ok ? { res, mods, nn, version, cell } : null;
  };

  // 候选格宽：最小游程及其附近整数（含按内容区宽高直接除出来的值）
  const candidates = new Set();
  for (let d = 0; d <= 3; d++) {
    if (minRun - d >= 1) candidates.add(minRun - d);
    candidates.add(minRun + d);
  }
  for (let nn = 21; nn <= 57; nn += 4) {
    if (w % nn === 0) candidates.add(w / nn);          // 整数倍缩放
    candidates.add(Math.round(w / nn));
  }
  const offsets = [[minX, minY]];
  // 内容区宽度可能因阈值化多算/少算 1~2 像素，顺带试一下微调偏移
  for (let d = 1; d <= 2; d++) {
    if (minX + d <= W - w) offsets.push([minX + d, minY]);
    if (minY + d <= H - h) offsets.push([minX, minY + d]);
  }

  const sorted = [...candidates].filter((c) => Number.isFinite(c) && c >= 1).sort((a, b) => a - b);
  for (const cell of sorted) {
    for (const [ox, oy] of offsets) {
      const hit = tryCell(cell, ox, oy);
      if (hit) {
        return Object.assign(hit.res, {
          method: '网格采样',
          modules: hit.mods,
          size: hit.nn,
          version: hit.version,
        });
      }
    }
  }
  return {
    ok: false,
    reason: `网格采样失败：内容区 ${w}x${h}，最小游程 ${minRun}px，`
      + `试过 ${sorted.length} 种格宽估计都无法通过定位图案校验与 Reed-Solomon 校验`,
  };
}

/** 校验某个矩阵里指定位置的定位图案（回字形）是否规范 */
function finderOkIn(modules, n, cx, cy) {
  for (let dy = 0; dy < 7; dy++) {
    for (let dx = 0; dx < 7; dx++) {
      const edge = dx === 0 || dx === 6 || dy === 0 || dy === 6;
      const core = dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4;
      const want = edge || core ? 1 : 0;
      if (modules[cy + dy] === undefined || modules[cy + dy][cx + dx] !== want) return false;
    }
  }
  return true;
}

/** 解码二维码（限定：正方形、水平、字节模式、纠错等级任意） */
function decodeQrFromImage(img) {
  const gray = toGray(img);
  // 阈值：取灰度范围中点。比 Otsu 更稳——图形导出的二维码只有黑白两级，
  // 而边框/抗锯齿会有很浅的灰，Otsu 有时会把它们判成黑，导致边界识别错误。
  let mn = 255, mx = 0;
  for (const v of gray.gray) { if (v < mn) mn = v; if (v > mx) mx = v; }
  const thr = mn + (mx - mn) * 0.5;
  const W = gray.width, H = gray.height;
  const bin = new Uint8Array(W * H);
  for (let i = 0; i < bin.length; i++) bin[i] = gray.gray[i] < thr ? 1 : 0;   // 1=黑 0=白

  const grid = decodeByGrid(bin, W, H);
  if (grid.ok) return Object.assign({ method: '网格采样', threshold: Math.round(thr) }, grid);

  const centers = findFinderCenters(bin, W, H);
  return {
    ok: false,
    reason: `网格采样失败（${grid.reason}）；定位图案检测找到 ${centers.length} 个（本解码器主要面向无旋转的导出图片）`,
    threshold: Math.round(thr),
  };
}

/**
 * 按标准位序读出两份格式信息副本，用 BCH 校验后返回纠错等级与掩码。
 *
 * 位序必须与编码端一致（LSB 优先、bit0 在最上/最右）：
 *   副本1：(8,0)=bit0 … (8,8)=bit7，(7,8)=bit8 … (0,8)=bit14
 *   副本2：(n-1,8)=bit0 … (n-8,8)=bit7，(8,n-7)=bit8 … (8,n-1)=bit14
 *
 * 血的教训：这里以前自己另写了一套**反向**的位序表，和编码端「一起错」，
 * 于是编码器把格式信息写反时，解码器照样能读出来、测试全绿、真机全瞎。
 * 现在两份副本都按标准读，并且要求 BCH 校验通过；读不出就明确报错，
 * 而不是默默退回枚举猜一个 —— 猜对了会把「格式信息写错」这个致命问题掩盖掉。
 */
function readFormatCopies(m, n) {
  const copy1 = [
    [8, 0, 0], [8, 1, 1], [8, 2, 2], [8, 3, 3], [8, 4, 4], [8, 5, 5],
    [8, 7, 6], [8, 8, 7],
    [7, 8, 8], [5, 8, 9], [4, 8, 10], [3, 8, 11], [2, 8, 12], [1, 8, 13], [0, 8, 14],
  ];
  const copy2 = [
    [n - 1, 8, 0], [n - 2, 8, 1], [n - 3, 8, 2], [n - 4, 8, 3], [n - 5, 8, 4],
    [n - 6, 8, 5], [n - 7, 8, 6], [n - 8, 8, 7],
    [8, n - 7, 8], [8, n - 6, 9], [8, n - 5, 10], [8, n - 4, 11], [8, n - 3, 12],
    [8, n - 2, 13], [8, n - 1, 14],
  ];
  const out = [];
  for (const [label, list] of [['副本1', copy1], ['副本2', copy2]]) {
    let bits = 0;
    for (const [x, y, bit] of list) if (m[y] && m[y][x]) bits |= (1 << bit);
    bits = bits >>> 0;
    const fmt = (bits ^ 0x5412) >>> 0;
    const d = fmt >>> 10;
    let chk = d << 10;
    for (let i = 14; i >= 10; i--) if ((chk >>> i) & 1) chk ^= 0x537 << (i - 10);
    if (((d << 10) | chk) === fmt) out.push({ label, ecCode: d >>> 3, mask: d & 7, bits });
  }
  return out;
}

/** 从采样出的模块矩阵解码。
 *
 *  正常路径与真扫码器一致：先按标准位序读格式信息，拿到纠错等级与掩码，
 *  再用它去解数据区并做 Reed-Solomon 校验。
 *
 *  只有在**两份副本都读不出**（BCH 校验不过）时，才退回枚举 32 种
 *  「纠错等级 × 掩码」组合来猜。这条退路是为了对付扫描件噪声，
 *  但结果会打上 viaFormat=false 标记 —— 因为靠猜才对上的二维码，
 *  真扫码器很可能是读不出的（它不会像我们这样遍历 32 种组合）。
 */
/**
 * 格式信息里的「纠错等级格式码」→ RS 分块表索引。
 *
 * 这两个东西长得很像但不是一回事，本项目已经因此栽过一次（编码端把
 * 分块表索引当成格式码写进矩阵）。这里再明确一次：
 *   格式码（写进二维码的 2 位）：M=00, L=01, H=10, Q=11
 *   分块表索引（下面 TABLE 的第一层下标）：L=0, M=1, Q=2, H=3
 * 直接拿格式码去查 TABLE 会查错等级，RS 校验必然失败。
 */
const FORMAT_EC_TO_TABLE = { 0: 1, 1: 0, 2: 3, 3: 2 };

function tryDecodeModules(m, n, version) {
  const reserved = buildReserved(n, version);

  // ---- 正常路径：用格式信息 ----
  const copies = readFormatCopies(m, n);
  if (copies.length) {
    const f = copies[0];
    const tableEc = FORMAT_EC_TO_TABLE[f.ecCode];
    const res = extractWithMask(m, n, version, f.mask, reserved, tableEc);
    if (res.ok) {
      return Object.assign(res, {
        viaFormat: true, formatCopy: f.label, ecCode: f.ecCode, ecTable: tableEc, ec: f.ecCode,
      });
    }
    return {
      ok: false,
      viaFormat: true,
      reason: `格式信息可以读出（${f.label}：纠错等级格式码 ${f.ecCode}，掩码 ${f.mask}），`
        + '但数据区 Reed-Solomon 校验失败：' + (res.reason || '数据不完整'),
    };
  }

  // ---- 退路：格式信息读不出，枚举猜 ----
  // 预生成 4 种格式码 × 8 个掩码的格式位串（用 BCH 生成多项式，独立实现）
  const candidates = [];
  for (let formatEc = 0; formatEc < 4; formatEc++) {
    for (let mask = 0; mask < 8; mask++) {
      const data = (formatEc << 3) | mask;
      let d = data << 10;
      for (let i = 14; i >= 10; i--) if ((d >>> i) & 1) d ^= 0x537 << (i - 10);
      candidates.push({
        formatEc, mask, tableEc: FORMAT_EC_TO_TABLE[formatEc],
        bits: (((data << 10) | d) ^ 0x5412) >>> 0,
      });
    }
  }

  // 读出两份副本的位串（按标准位序），挑汉明距离最小、且 RS 校验通过的组合
  const readCopy = (list) => {
    let v = 0;
    for (const [x, y, bit] of list) if (m[y] && m[y][x]) v |= (1 << bit);
    return v >>> 0;
  };
  const copy1 = readCopy([
    [8, 0, 0], [8, 1, 1], [8, 2, 2], [8, 3, 3], [8, 4, 4], [8, 5, 5],
    [8, 7, 6], [8, 8, 7],
    [7, 8, 8], [5, 8, 9], [4, 8, 10], [3, 8, 11], [2, 8, 12], [1, 8, 13], [0, 8, 14],
  ]);
  const copy2 = readCopy([
    [n - 1, 8, 0], [n - 2, 8, 1], [n - 3, 8, 2], [n - 4, 8, 3], [n - 5, 8, 4],
    [n - 6, 8, 5], [n - 7, 8, 6], [n - 8, 8, 7],
    [8, n - 7, 8], [8, n - 6, 9], [8, n - 5, 10], [8, n - 4, 11], [8, n - 3, 12],
    [8, n - 2, 13], [8, n - 1, 14],
  ]);
  const hamming = (a, b) => {
    let x = (a ^ b) >>> 0, c = 0;
    while (x) { c += x & 1; x >>>= 1; }
    return c;
  };
  candidates.forEach((c) => {
    c.dist = Math.min(hamming(copy1, c.bits), hamming(copy2, c.bits));
  });
  candidates.sort((a, b) => a.dist - b.dist);

  let lastReason = '';
  for (const cand of candidates.slice(0, 6)) {          // 只试最接近的几组，避免误判
    const res = extractWithMask(m, n, version, cand.mask, reserved, cand.tableEc);
    if (res.ok) {
      return Object.assign(res, {
        viaFormat: false, formatCopy: null, ecCode: cand.formatEc, ecTable: cand.tableEc, ec: cand.formatEc,
      });
    }
    if (res.reason) lastReason = res.reason;
  }
  return {
    ok: false,
    viaFormat: false,
    reason: '格式信息两份副本都读不出（BCH 校验不过），说明格式信息不符合标准，'
      + '真扫码器会直接判定这不是二维码。'
      + `枚举猜测的最佳候选位差=${candidates[0].dist}。` + (lastReason ? ' ' + lastReason : ''),
  };
}

/**
 * 用给定掩码取出数据并校验 Reed-Solomon。
 * 注意 tableEc 是 **RS 分块表索引**（L=0,M=1,Q=2,H=3），不是格式信息里的格式码。
 */
function extractWithMask(m, n, version, mask, reserved, tableEc) {
  const ecBits = tableEc;
  const data = [];
  let upward = true;
  for (let x = n - 1; x > 0; x -= 2) {
    if (x === 6) x = 5;
    for (let k = 0; k < n; k++) {
      const y = upward ? n - 1 - k : k;
      for (const dx of [0, -1]) {
        const xx = x + dx;
        if (reserved[y] === undefined || reserved[y][xx]) continue;
        let v = m[y][xx];
        if (maskFn(mask, xx, y)) v ^= 1;
        data.push(v);
      }
    }
    upward = !upward;
  }
  const bytes = [];
  for (let i = 0; i + 8 <= data.length; i += 8) {
    let b = 0;
    for (let j = 0; j < 8; j++) b = (b << 1) | data[i + j];
    bytes.push(b);
  }

  /**
   * 分块表（不同纠错等级、不同版本的块结构不同）。
   * 结构：[每块纠错码字数, 组1块数, 组1数据码字, 组2块数, 组2数据码字]
   *
   * 注意这里是**独立抄写的 ISO/IEC 18004 标准表**，不引用被测代码里的表 ——
   * 引用被测代码就等于「拿答案对答案」，失去意义。
   *
   * 这里曾经只写到版本 4，而编码器能生成到版本 10，
   * 结果 v5~v10 的二维码明明是对的却报「不支持的版本/纠错等级组合」——
   * 也就是说**高版本从来没被真正验证过**。现已补全到版本 10（编码器的上限）。
   */
  const TABLE = {
    // L（索引 0）
    0: {
      1: [7, 1, 19, 0, 0], 2: [10, 1, 34, 0, 0], 3: [15, 1, 55, 0, 0], 4: [20, 1, 80, 0, 0],
      5: [26, 1, 108, 0, 0], 6: [18, 2, 68, 0, 0], 7: [20, 2, 78, 0, 0], 8: [24, 2, 97, 0, 0],
      9: [30, 2, 116, 0, 0], 10: [18, 2, 68, 2, 69],
    },
    // M（索引 1）
    1: {
      1: [10, 1, 16, 0, 0], 2: [16, 1, 28, 0, 0], 3: [26, 1, 44, 0, 0], 4: [18, 2, 32, 0, 0],
      5: [24, 2, 43, 0, 0], 6: [16, 4, 27, 0, 0], 7: [18, 4, 31, 0, 0], 8: [22, 2, 38, 2, 39],
      9: [22, 3, 36, 2, 37], 10: [26, 4, 43, 1, 44],
    },
    // Q（索引 2）
    2: {
      1: [13, 1, 13, 0, 0], 2: [22, 1, 22, 0, 0], 3: [18, 2, 17, 0, 0], 4: [26, 2, 24, 0, 0],
      5: [18, 2, 15, 2, 16], 6: [24, 4, 19, 0, 0], 7: [18, 2, 14, 4, 15], 8: [22, 4, 18, 2, 19],
      9: [20, 4, 16, 4, 17], 10: [24, 6, 19, 2, 20],
    },
    // H（索引 3）—— 每份档案二维码用的就是这个等级
    3: {
      1: [17, 1, 9, 0, 0], 2: [28, 1, 16, 0, 0], 3: [22, 2, 13, 0, 0], 4: [16, 4, 9, 0, 0],
      5: [22, 2, 11, 2, 12], 6: [28, 4, 15, 0, 0], 7: [26, 4, 13, 1, 14], 8: [26, 4, 14, 2, 15],
      9: [24, 4, 12, 4, 13], 10: [28, 6, 15, 2, 16],
    },
  };
  const spec = (TABLE[ecBits] || {})[version];
  if (!spec) {
    return {
      ok: false,
      reason: `本解码器没有 v${version} 的分块表（只支持 v1~v10，与编码器上限一致）`,
    };
  }
  const [ecLen, b1, d1, b2, d2] = spec;

  const gfExp = new Uint8Array(512);
  const gfLog = new Uint8Array(256);
  (() => {
    let x = 1;
    for (let i = 0; i < 255; i++) { gfExp[i] = x; gfLog[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
    for (let i = 255; i < 512; i++) gfExp[i] = gfExp[i - 255];
  })();
  const gfMul = (a, b) => (a === 0 || b === 0 ? 0 : gfExp[gfLog[a] + gfLog[b]]);

  // 反交错
  const blocks = [];
  for (let i = 0; i < b1; i++) blocks.push({ len: d1, data: [], ec: [] });
  for (let i = 0; i < b2; i++) blocks.push({ len: d2, data: [], ec: [] });
  const maxData = Math.max(...blocks.map((b) => b.len));
  let idx = 0;
  for (let i = 0; i < maxData; i++) for (const b of blocks) if (i < b.len) b.data.push(bytes[idx++]);
  for (let i = 0; i < ecLen; i++) for (const b of blocks) b.ec.push(bytes[idx++]);

  // RS 校验
  let gen = [1];
  for (let i = 0; i < ecLen; i++) {
    const next = new Array(gen.length + 1).fill(0);
    for (let j = 0; j < gen.length; j++) { next[j] ^= gen[j]; next[j + 1] ^= gfMul(gen[j], gfExp[i]); }
    gen = next;
  }
  for (const b of blocks) {
    const res = new Array(ecLen).fill(0);
    for (const byte of b.data.concat(b.ec)) {
      const factor = byte ^ res[0];
      res.shift(); res.push(0);
      if (factor !== 0) for (let i = 0; i < ecLen; i++) res[i] ^= gfMul(gen[i + 1], factor);
    }
    if (res.some((v) => v !== 0)) return { ok: false, reason: 'Reed-Solomon 校验未通过' };
  }

  /**
   * 解析数据段。
   *
   * 必须**循环解析所有段**：一个二维码里可以混用多种编码模式，
   * 例如 Python 的 qrcode 库会把 "http://..." 拆成
   * 「http（字母数字模式）」+「://172.29…（字节模式）」两段。
   * 之前这里解析完第一段就 return，导致这种码只能读出 "http"，
   * 被误判成「内容不一致」——其实码是好的，是解码器读漏了。
   */
  const flat = blocks.flatMap((b) => b.data);
  const bits = [];
  for (const b of flat) for (let i = 7; i >= 0; i--) bits.push((b >>> i) & 1);
  let p = 0;
  const take = (k) => { let v = 0; for (let i = 0; i < k; i++) v = (v << 1) | (bits[p++] || 0); return v; };
  const ALPHA = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
  const parts = [];
  const modes = [];
  let guard = 0;
  while (p + 4 <= bits.length) {
    if (guard++ > 100) return { ok: false, reason: '数据段数量异常，可能解析错位' };
    const mode = take(4);
    if (mode === 0) break;                                  // 终止符
    if (mode === 4) {                                       // 字节模式（UTF-8）
      const len = take(version <= 9 ? 8 : 16);
      const bytes = [];
      for (let i = 0; i < len; i++) bytes.push(take(8));
      parts.push(Buffer.from(bytes).toString('utf8'));
      modes.push('byte');
      continue;
    }
    if (mode === 2) {                                       // 字母数字模式
      const len = take(version <= 9 ? 9 : 11);
      let s = '';
      for (let i = 0; i + 2 <= len; i += 2) { const v = take(11); s += ALPHA[Math.floor(v / 45)] + ALPHA[v % 45]; }
      if (len % 2) s += ALPHA[take(6)];
      parts.push(s);
      modes.push('alnum');
      continue;
    }
    if (mode === 1) {                                       // 数字模式
      const len = take(version <= 9 ? 10 : 12);
      let s = '';
      for (let i = 0; i + 3 <= len; i += 3) s += String(take(10)).padStart(3, '0');
      const rem = len % 3;
      if (rem === 1) s += String(take(4));
      if (rem === 2) s += String(take(7)).padStart(2, '0');
      parts.push(s);
      modes.push('numeric');
      continue;
    }
    return { ok: false, reason: '不支持的编码模式: ' + mode };
  }
  if (!parts.length) return { ok: false, reason: '没有解析出任何数据段（可能是空二维码）' };
  return {
    ok: true, text: parts.join(''), version, mask, ec: ecBits,
    segments: parts.length, modes: [...new Set(modes)],
  };
}

/**
 * 读格式信息（保留此函数名供外部调用，实现统一走 readFormatCopies）。
 *
 * 这里以前自己另写了一份**反向**位序的表，是「编码器写错、解码器跟着错」
 * 那类问题的帮凶。现在只保留一个实现，谁也不能另立一套。
 */
function readFormat(m, n) {
  const copies = readFormatCopies(m, n);
  if (!copies.length) return null;
  return { ec: copies[0].ecCode, mask: copies[0].mask, copy: copies[0].label };
}

function maskFn(m, x, y) {
  switch (m) {
    case 0: return (x + y) % 2 === 0;
    case 1: return y % 2 === 0;
    case 2: return x % 3 === 0;
    case 3: return (x + y) % 3 === 0;
    case 4: return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
    case 5: return ((x * y) % 2) + ((x * y) % 3) === 0;
    case 6: return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0;
    case 7: return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
    default: return false;
  }
}

function buildReserved(n, version) {
  const r = Array.from({ length: n }, () => new Array(n).fill(false));
  const set = (x, y) => { if (x >= 0 && y >= 0 && x < n && y < n) r[y][x] = true; };
  const finder = (cx, cy) => { for (let dy = -1; dy <= 7; dy++) for (let dx = -1; dx <= 7; dx++) set(cx + dx, cy + dy); };
  finder(0, 0); finder(n - 7, 0); finder(0, n - 7);
  for (let i = 8; i < n - 8; i++) { set(i, 6); set(6, i); }
  const align = { 1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50] };
  for (const ax of (align[version] || [])) {
    for (const ay of (align[version] || [])) {
      if ((ax <= 8 && ay <= 8) || (ax <= 8 && ay >= n - 9) || (ax >= n - 9 && ay <= 8)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy);
    }
  }
  for (let i = 0; i <= 8; i++) { set(i, 8); set(8, i); }
  for (let i = 0; i < 8; i++) { set(n - 1 - i, 8); set(8, n - 1 - i); }
  if (version >= 7) {
    for (let i = 0; i < 18; i++) {
      const a = Math.floor(i / 3), b = i % 3;
      set(n - 11 + b, a); set(a, n - 11 + b);
    }
  }
  return r;
}

// ============================================================ 入口
function decodeFile(file) {
  const buf = fs.readFileSync(file);
  let img;
  const head = buf.slice(0, 4).toString('hex');
  if (head.startsWith('89504e47')) img = readPng(buf);
  else if (head.startsWith('424d')) img = readBmp(buf);
  else return { ok: false, reason: '不支持的文件格式: ' + head };
  const res = decodeQrFromImage(img);
  return Object.assign({ width: img.width, height: img.height }, res);
}

if (require.main === module) {
  const files = process.argv.slice(2);
  if (!files.length) {
    console.log('用法: node qr-decode.js <图片...>');
    process.exit(1);
  }
  for (const f of files) {
    const name = f.split(/[\\/]/).pop();
    console.log('=== ' + name + ' ===');
    try {
      if (!fs.existsSync(f)) { console.log('  文件不存在'); continue; }
      const r = decodeFile(f);
      console.log('  尺寸: ' + r.width + 'x' + r.height);
      if (r.ok) {
        console.log('  ✅ 解码成功');
        console.log('  内容: ' + r.text);
        console.log('  版本: v' + r.version + '  纠错等级位: ' + r.ec + '  掩码: ' + r.mask);
      } else {
        console.log('  ❌ 解码失败: ' + r.reason);
      }
    } catch (e) {
      console.log('  ❌ 异常: ' + e.message);
    }
    console.log('');
  }
}

module.exports = { decodeFile, decodeQrFromImage, readPng, readBmp, tryDecodeModules, readFormat, readFormatCopies };
