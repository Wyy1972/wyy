/**
 * 千问版安全修复回归测试（v4.30.6）
 *
 * 用法：node server/tools/test-security-fixes.js <http://127.0.0.1:端口> <测试数据目录>
 *       （由 run-all.js 自动传入；独立测试库，绝不碰 data/ 真实数据）
 *
 * 钉住三个已证实漏洞的修复，每条★断言都对应一个"把修复改回去就会失败"的行为：
 *   1. 强制改密服务端门禁：must_change=1 的账号，除 查自己/改密/登出 外一律 403。
 *      改回去（只靠前端弹窗）→ 业务接口变 200，断言失败。
 *   2. 登录限流不认伪造头：X-Forwarded-For 每次换一个值，限流仍按真实连接地址生效。
 *      改回去（clientIp 信任 XFF）→ 每个伪造 IP 各自计数，永远不 429，断言失败。
 *   3. 身份登录失败也计数锁定：只给「身份+口令」连续输错，同样触发账号锁定（423）。
 *      改回去（身份路径不写 failed_count）→ 正确口令永远能进，断言失败。
 *   4. 附件上传类型白名单：.html/.svg/.exe 一律 400；正常 .txt 仍可上传。
 *   5. 附件输出防护：MIME 以扩展名为准（不信客户端谎报）；nosniff 恒在；
 *      历史遗留的危险类型记录（直接造库模拟旧版本数据）预览强制 attachment。
 *
 * 与 test-login.js 同一约定：假定出厂账号 admin/admin123（run-all.js 每轮重建测试库）。
 * 本套件会把 admin 口令改成强口令 —— 因此必须排在 run-all.js 套件清单**最后**。
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');
const storage = require('../lib/storage');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || '';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  return { req, json };
}

function multipart(files, fields = {}) {
  const boundary = '----qwenfix' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="files"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

function firstId(node, out = []) {
  if (!node || typeof node !== 'object') return out;
  if (Array.isArray(node)) { for (const n of node) firstId(n, out); return out; }
  if (typeof node.id === 'number') out.push(node.id);
  for (const v of Object.values(node)) if (v && typeof v === 'object') firstId(v, out);
  return out;
}

const TAG = 'QWF' + Math.random().toString(16).slice(2, 8).toUpperCase();
const ADMIN_PW = 'admin123';           // 独立测试库的出厂口令（run-all.js 每轮重建）
const NEW_PW = 'QwenFix@2026a';        // 符合默认口令策略的强口令
const GOOD_PW = 'Archive@2026x';

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [] };
  let settingsKeep = null;
  let legacyFileId = 0;   // 直接造库的"历史遗留危险附件"，清理时连记录带实体一起删

  async function cleanup() {
    try {
      if (settingsKeep) await admin.json('/api/settings', { method: 'PUT', json: settingsKeep });
      // 历史遗留夹具：服务不会删它（不是通过接口建的），测试自己收走
      if (legacyFileId && DATA_DIR) {
        try {
          const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
          const row = db.prepare('SELECT rel_path FROM files WHERE id=?').get(legacyFileId);
          db.prepare('DELETE FROM files WHERE id=?').run(legacyFileId);
          db.close();
          if (row && row.rel_path) {
            const abs = path.join(DATA_DIR, 'files', row.rel_path);
            if (fs.existsSync(abs)) fs.unlinkSync(abs);
          }
        } catch (_) { /* 尽力而为 */ }
      }
      for (const id of created.archives) {
        await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
      }
      for (const id of created.users) {
        await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
      }
      const admins = ((await admin.json('/api/users')).body.data.list || []).filter((x) => x.username === 'admin');
      for (const a of admins) await admin.json(`/api/users/${a.id}/unlock`, { method: 'POST' });
    } catch (_) { /* 清理尽力而为 */ }
  }

  try {
    section('准备');
    const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: ADMIN_PW } });
    check('管理员登录成功（独立测试库）', login.status === 200 && login.body.ok, JSON.stringify(login.body).slice(0, 140));
    if (!login.body.ok) { console.error('无法继续：管理员登录失败'); process.exit(1); }

    // 测试库由 init-empty-db.js 生成，admin 已标记"完成首改"（沿用全部自测脚本的既有约定），
    // 所以这里可以直接读设置。门禁本身用第 1 节的新建账号（must_change=1）完整验证。
    const settingsBefore = (await admin.json('/api/settings')).body.data.settings;
    settingsKeep = {
      'security.login_max_fail': settingsBefore['security.login_max_fail'],
      'security.login_lock_minutes': settingsBefore['security.login_lock_minutes'],
      'security.login_rate_per_minute': settingsBefore['security.login_rate_per_minute'],
    };
    await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '600' } });

    // ---------- 1. 强制改密：服务端门禁 ----------
    section('强制改密 · 服务端门禁');
    // 新建账号出厂即 must_change=1（建号接口写死），用它验证门禁，不动 admin。
    const mu = `${TAG.toLowerCase()}_mc`;
    // 显式传 must_change=1：即使测试模式允许夹具豁免首改，本账号也要保持"必须改密"，
    // 因为门禁断言全靠它。
    const mk = await admin.json('/api/users', { method: 'POST', json: { username: mu, display_name: mu, password: GOOD_PW, role: 'reader', must_change: 1 } });
    check('测试账号创建成功', mk.body.ok, JSON.stringify(mk.body).slice(0, 140));
    if (mk.body.ok) created.users.push(mk.body.data.id);
    const mcRow = ((await admin.json('/api/users')).body.data.list || []).find((x) => x.username === mu) || {};
    check('新账号出厂即标记必须改密', Number(mcRow.must_change) === 1, 'must_change=' + mcRow.must_change);

    const sMc = makeSession();
    const mcLogin = await sMc.json('/api/login', { method: 'POST', json: { username: mu, password: GOOD_PW } });
    check('未改密也能登录（登录本身不拦，进门后拦）', mcLogin.status === 200 && mcLogin.body.ok, JSON.stringify(mcLogin.body).slice(0, 140));

    const mcMe = await sMc.json('/api/me');
    check('未改密仍可查自己（/api/me 豁免，前端要靠它弹改密框）', mcMe.status === 200, 'status=' + mcMe.status);
    const mcList = await sMc.json('/api/archives?size=1');
    check('★ 未改密调业务接口 → 403（不再只靠前端弹窗）', mcList.status === 403, 'status=' + mcList.status);
    check('403 带可识别错误码与改密指引', mcList.body.code === 'PASSWORD_CHANGE_REQUIRED' && /修改/.test(String(mcList.body.error || '')),
      JSON.stringify(mcList.body).slice(0, 160));
    const mcWrite = await sMc.json('/api/loans', { method: 'POST', json: { archive_id: 1, mode: '查阅' } });
    check('未改密的写操作同样 403', mcWrite.status === 403, 'status=' + mcWrite.status);

    const mcChange = await sMc.json('/api/me/password', { method: 'POST', json: { oldPassword: GOOD_PW, newPassword: 'Archive@2026y' } });
    check('改密接口本身豁免（能完成改密）', mcChange.body.ok, JSON.stringify(mcChange.body).slice(0, 140));
    const mcAfter = await sMc.json('/api/archives?size=1');
    check('★ 改密完成后业务接口立即恢复', mcAfter.status === 200, 'status=' + mcAfter.status);
    const mcLogout = await sMc.json('/api/logout', { method: 'POST' });
    check('登出接口豁免', mcLogout.status === 200, 'status=' + mcLogout.status);

    // ---------- 2. 限流不认伪造 X-Forwarded-For ----------
    section('登录限流 · 伪造来源头无效');
    await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '2', 'security.login_max_fail': '0' } });
    let got429 = false, tried = 0;
    const statuses = [];
    for (let i = 0; i < 6 && !got429; i++) {
      tried++;
      // 每次伪造一个不同的来源头：修复前 clientIp 取 XFF 第一段，
      // 每个"IP"各自计数，永远不会触发限流 —— 这正是漏洞本身。
      const r = await fetch(BASE + '/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': `203.0.113.${i + 1}` },
        body: JSON.stringify({ username: `${TAG}_spray${i}`, password: 'Wrong@123456' }),
      });
      statuses.push(r.status);
      if (r.status === 429) got429 = true;
    }
    check('★ 每次换一个伪造 XFF，限流仍按真实连接地址生效（429）', got429, `尝试 ${tried} 次：${statuses.join(',')}`);
    await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_rate_per_minute': '600' } });
    const afterRate = await makeSession().json('/api/login', { method: 'POST', json: { username: 'admin', password: ADMIN_PW } });
    check('放宽限流后恢复正常登录', afterRate.body.ok, JSON.stringify(afterRate.body).slice(0, 140));

    // ---------- 3. 身份登录失败同样计数锁定 ----------
    section('身份登录 · 失败计数与锁定');
    await admin.json('/api/settings', { method: 'PUT', json: { 'security.login_max_fail': '3', 'security.login_lock_minutes': '2', 'security.login_rate_per_minute': '600' } });
    const idFails = [];
    for (let i = 0; i < 3; i++) {
      const r = await makeSession().json('/api/login', { method: 'POST', json: { identity: 'manager', password: 'Wrong@123456' } });
      idFails.push(r.status);
    }
    check('身份登录连续失败返回 401（尚未锁定）', idFails.slice(0, 2).every((s) => s === 401), idFails.join(','));
    // 修复前：身份路径失败不写 failed_count，正确口令永远能进 —— 爆破无上限。
    // 修复后：该身份下账号失败计数达阈值被锁，正确口令也 423。
    const lockedTry = await makeSession().json('/api/login', { method: 'POST', json: { identity: 'manager', password: ADMIN_PW } });
    check('★ 身份登录失败达阈值后，正确口令也被锁（423）', lockedTry.status === 423,
      'status=' + lockedTry.status + ' ' + JSON.stringify(lockedTry.body).slice(0, 120));
    const adminRow = ((await admin.json('/api/users')).body.data.list || []).find((x) => x.username === 'admin') || {};
    check('失败计数确实记到了账号上', Number(adminRow.failed_count) >= 3, 'failed_count=' + adminRow.failed_count);
    check('用户列表显示锁定状态', adminRow.locked === true, JSON.stringify(adminRow).slice(0, 140));
    const unlock = await admin.json(`/api/users/${adminRow.id}/unlock`, { method: 'POST' });
    check('管理员解锁后恢复', unlock.body.ok, JSON.stringify(unlock.body).slice(0, 120));
    const relogin = await makeSession().json('/api/login', { method: 'POST', json: { identity: 'manager', password: ADMIN_PW } });
    check('解锁后身份登录正常', relogin.body.ok, JSON.stringify(relogin.body).slice(0, 120));
    await admin.json('/api/settings', { method: 'PUT', json: settingsKeep });

    // ---------- 4. 附件上传类型白名单 ----------
    section('附件上传 · 危险类型拒收');
    const cats = await admin.json('/api/categories');
    const catId = firstId(cats.body.data)[0];
    const ar = await admin.json('/api/archives', {
      method: 'POST',
      json: { type_code: 'WS', category_id: catId, title: `${TAG} 附件防护夹具`, secret_level: '公开', retention: '定期10年', year: '2026', archive_date: '2026-01-01' },
    });
    check('测试档案创建成功', ar.body.ok, JSON.stringify(ar.body).slice(0, 140));
    const aId = ar.body.ok ? ar.body.data.id : 0;
    if (aId) created.archives.push(aId);

    for (const [fname, mime] of [['伪装档案.html', 'text/html'], ['矢量图.svg', 'image/svg+xml'], ['程序.exe', 'application/octet-stream']]) {
      const mp = multipart([{ filename: fname, mime, data: '<script>alert(1)</script>' }]);
      const up = await admin.json(`/api/archives/${aId}/files`, { method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body });
      check(`★ 拒收 ${fname}（400）`, up.status === 400, 'status=' + up.status + ' ' + JSON.stringify(up.body).slice(0, 120));
    }
    const mpOk = multipart([{ filename: '正常正文.txt', mime: 'text/plain', data: `${TAG} 正常文本附件` }]);
    const upOk = await admin.json(`/api/archives/${aId}/files`, { method: 'POST', headers: { 'Content-Type': mpOk.contentType }, body: mpOk.body });
    check('正常 .txt 仍可上传（功能不回归）', upOk.body.ok, JSON.stringify(upOk.body).slice(0, 140));
    const txtId = upOk.body.ok && upOk.body.data.files[0] ? upOk.body.data.files[0].id : 0;

    if (txtId) {
      const mpBad = multipart([{ filename: '换皮.html', mime: 'text/html', data: '<script>alert(2)</script>' }], { reason: '测试' });
      const rep = await admin.json(`/api/files/${txtId}/replace`, { method: 'POST', headers: { 'Content-Type': mpBad.contentType }, body: mpBad.body });
      check('替换正文也拒收危险类型（400）', rep.status === 400, 'status=' + rep.status);
    }

    // ---------- 5. 附件输出防护 ----------
    section('附件输出 · nosniff 与 MIME 以扩展名为准');
    if (txtId) {
      const pv = await admin.req(`/api/files/${txtId}/preview`);
      check('文本预览仍是 inline（功能不回归）', pv.status === 200 && /inline/.test(pv.headers.get('content-disposition') || ''),
        'status=' + pv.status + ' cd=' + pv.headers.get('content-disposition'));
      check('★ 预览响应带 X-Content-Type-Options: nosniff', (pv.headers.get('x-content-type-options') || '').toLowerCase() === 'nosniff',
        'xcto=' + pv.headers.get('x-content-type-options'));
      const dl = await admin.req(`/api/files/${txtId}/download`);
      check('下载响应同样带 nosniff', (dl.headers.get('x-content-type-options') || '').toLowerCase() === 'nosniff',
        'xcto=' + dl.headers.get('x-content-type-options'));
    }
    // 客户端谎报 MIME：扩展名合规所以能进门，但输出 MIME 必须按扩展名重算，
    // 否则一份 .txt 被报成 text/html 就能在预览时执行脚本。
    const mpLie = multipart([{ filename: '报假类型.txt', mime: 'text/html', data: '<script>alert(3)</script>' }]);
    const upLie = await admin.json(`/api/archives/${aId}/files`, { method: 'POST', headers: { 'Content-Type': mpLie.contentType }, body: mpLie.body });
    check('客户端谎报 MIME 也能上传（扩展名合规）', upLie.body.ok, JSON.stringify(upLie.body).slice(0, 140));
    const lieId = upLie.body.ok && upLie.body.data.files[0] ? upLie.body.data.files[0].id : 0;
    if (lieId) {
      const pvLie = await admin.req(`/api/files/${lieId}/preview`);
      const ctLie = (pvLie.headers.get('content-type') || '').toLowerCase();
      check('★ 输出 MIME 以扩展名为准，不信客户端谎报的 text/html', !ctLie.includes('text/html'), 'content-type=' + ctLie);
    }

    // 历史遗留危险记录：旧版本没有白名单，库里可能已经躺着 .html。
    // 上传入口拦不住存量数据，所以**出门这道必须独立成立**：
    // 直接造库模拟一条旧记录（与 seed-demo.js 同一套 storage 工具），验证预览被强制下载。
    if (aId && DATA_DIR) {
      const filesRoot = path.join(DATA_DIR, 'files');
      const aRow = await admin.json(`/api/archives/${aId}`);
      const aCode = (aRow.body.data && aRow.body.data.archive_code) || TAG;
      const saved = storage.saveArchiveFile(filesRoot, {
        dir: storage.relDirFor({ archive: { archive_code: aCode, year: '2026' } }),
        base: storage.fileBaseName({ archive_code: aCode }),
      }, { filename: `${TAG}_legacy.html`, mime: 'text/html', data: Buffer.from('<script>alert(9)</script>', 'utf8') }, { seq: 90 });
      const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
      const ins = db.prepare(`INSERT INTO files(archive_id,original_name,stored_name,rel_path,mime,size,sha256,kind,sort_no,uploaded_by,created_at,storage_kind)
                              VALUES(?,?,?,?,?,?,?,?,?,?,?,'process')`)
        .run(aId, saved.original_name, saved.stored_name, saved.rel_path, 'text/html', saved.size, saved.sha256, '正文', 90, 1, new Date().toISOString());
      legacyFileId = Number(ins.lastInsertRowid);
      db.close();
      const pvLegacy = await admin.req(`/api/files/${legacyFileId}/preview`);
      const cdLegacy = (pvLegacy.headers.get('content-disposition') || '').toLowerCase();
      check('★ 历史遗留 .html 预览被强制 attachment（脚本无法在同源执行）',
        pvLegacy.status === 200 && cdLegacy.startsWith('attachment'),
        'status=' + pvLegacy.status + ' cd=' + cdLegacy);
      check('历史遗留 .html 响应也带 nosniff', (pvLegacy.headers.get('x-content-type-options') || '').toLowerCase() === 'nosniff',
        'xcto=' + pvLegacy.headers.get('x-content-type-options'));
    } else {
      check('历史遗留 .html 预览被强制 attachment（需要数据目录参数）', false, '未传测试数据目录');
    }

    // ---------- 6. admin 改密闭环 ----------
    section('出厂口令 · 改密后门禁解除');
    const chg = await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: ADMIN_PW, newPassword: NEW_PW } });
    check('admin 改密成功', chg.body.ok, JSON.stringify(chg.body).slice(0, 140));
    const meAfter = await admin.json('/api/me');
    check('改密后 must_change 清零', Number(meAfter.body.data.user.must_change) === 0, JSON.stringify(meAfter.body.data.user || {}).slice(0, 140));
    const listAfter = await admin.json('/api/archives?size=1');
    check('改密后业务接口正常', listAfter.status === 200, 'status=' + listAfter.status);
    // 出厂弱口令不允许被设回去（改密接口拒绝）——这本身就是正确行为，顺带钉住
    const back = await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: NEW_PW, newPassword: ADMIN_PW } });
    check('出厂弱口令不允许被设回去（400）', back.status === 400, 'status=' + back.status);
  } finally {
    section('清理');
    await cleanup();
    console.log('  （admin 口令已改为强口令；独立测试库每轮重建，本套件必须排在最后）');
  }

  console.log(`\n千问版安全修复回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n安全修复测试异常终止：', e); process.exit(1); });