/**
 * 离线授权签发工具（V4.33.0，发行方自己用）
 *
 * 用法：
 *   node server/tools/授权工具.js 机器码                       # 显示本机机器码（装机时让客户报这串）
 *   node server/tools/授权工具.js 签发 --unit "某某单位" --months 12 --out license.json
 *   node server/tools/授权工具.js 签发 --unit "某某单位" --months 12 --fp ABCD-1234-EF56-7890
 *   node server/tools/授权工具.js 校验 --file license.json
 *
 * 说明：
 *   · 不带 --fp 时用本机机器码签发（"给自己这台机器开授权"，适合演示/自用）
 *   · 给客户签发时，把客户报来的机器码传给 --fp；--fp-core/--fp-full 需要完整 64 位摘要时用
 *   · 签出来的 license.json 放到客户机器的 <数据目录>/ 或程序目录即可，重启或点"重新读取授权"生效
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const lic = require('../lib/license');

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = (argv[i + 1] && !argv[i + 1].startsWith('--')) ? argv[++i] : true;
      out[k] = v;
    } else out._.push(a);
  }
  return out;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = String(args._[0] || '机器码');
  const mc = lic.machineCode();

  if (cmd === '机器码' || cmd === 'code') {
    console.log('本机机器码：' + mc.code);
    console.log('  （把这一串报给发行方即可签发；换机/换主板会变）');
    const f = mc.factors;
    console.log('  因子：主机名=' + f.host + '  CPU=' + (f.cpu || '未知') + '  内存=' + f.mem + 'GB  网卡=' + (f.mac || '未取到'));
    if (mc.note) console.log('  注意：' + mc.note);
    console.log('  完整摘要 fp_core=' + mc.fpCore);
    console.log('            fp_full=' + mc.fpFull);
    return 0;
  }

  if (cmd === '签发' || cmd === 'issue') {
    const unit = String(args.unit || '').trim();
    if (!unit) { console.error('必须给 --unit "授权单位名称"'); return 1; }
    const months = Number(args.months || 12);
    const days = Number(args.days || 0);
    // --fp 给的是 16 位短码：无法反推 64 位摘要，所以这里如实提示改用完整摘要
    let fpCore = args['fp-core'] ? String(args['fp-core']) : '';
    let fpFull = args['fp-full'] ? String(args['fp-full']) : '';
    const fpShort = String(args.fp || '').replace(/[^0-9A-Fa-f]/g, '').toUpperCase();
    if (!fpCore && !fpFull) {
      if (fpShort) {
        // 短码只能比对前 16 位：签发时把"短码比对"写进授权对象（fp_core 存短码，校验端兼容）
        fpCore = 'SHORT:' + fpShort;
      } else {
        fpCore = mc.fpCore;
        fpFull = mc.fpFull;
        console.log('（未指定 --fp，按本机机器码签发：' + mc.code + '）');
      }
    }
    const obj = lic.issueLicense({
      unit, edition: String(args.edition || '标准版'), modules: String(args.modules || 'all').split(','),
      months, days, maxUsers: Number(args.users || 0), fpCore, fpFull, issuedAt: args.date ? String(args.date) : '',
    });
    const out = path.resolve(String(args.out || 'license.json'));
    fs.writeFileSync(out, JSON.stringify(obj, null, 2), 'utf8');
    console.log('已签发：' + out);
    console.log('  单位：' + obj.unit + '　版本：' + obj.edition + '　有效期至：' + obj.expires_at);
    if (!fpShort) console.log('  绑定：本机（' + mc.code + '）');
    else console.log('  绑定：机器码短码 ' + fpShort.replace(/(.{4})(?=.)/g, '$1-') + '（只校验前 16 位，同型号机器可能撞码，建议改用完整摘要）');
    return 0;
  }

  if (cmd === '校验' || cmd === 'check') {
    const file = String(args.file || args._[1] || '');
    const r = lic.checkLicense({ explicit: file ? path.resolve(file) : undefined });
    console.log('状态：' + r.state + '　只读：' + (r.readOnly ? '是' : '否'));
    console.log('说明：' + r.message);
    if (r.unit) console.log('单位：' + r.unit + '　到期：' + ((r.license || {}).expires_at || '') + '　剩余：' + r.remainDays + ' 天');
    console.log('本机机器码：' + mc.code);
    return r.state === 'ok' || r.state === 'none' ? 0 : 2;
  }

  console.error('未知命令：' + cmd + '（可用：机器码 / 签发 / 校验）');
  return 1;
}

process.exit(main());
