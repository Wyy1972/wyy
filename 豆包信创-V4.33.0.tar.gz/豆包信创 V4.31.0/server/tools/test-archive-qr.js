﻿/**
 * 档案二维码功能验证（需已启动服务）
 *
 * 覆盖：
 *   1) 启动时自动批量生成（文件确实落盘、命名按档号、内容=落地页网址）
 *   2) 参数正确：纠错等级 H / 静区（默认 6 模块）/ 每模块像素（默认 15）
 *   3) PNG 是合法图片，且能被独立解码器按标准读出（真机可读的等价证明）
 *   4) 新建/修改/删除档案时二维码同步增删改
 *   5) 单件 PNG 接口、统计接口、批量重建接口、标签打印页
 *   6) 权限控制
 *
 * 用法：node server/tools/test-archive-qr.js [http://127.0.0.1:8787] [数据目录]
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { decodeFile } = require('./qr-decode');

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const DATA_DIR = process.argv[3] || '';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

/**
 * 判断二维码里读到的那段文字，是不是「这份档案的二维码内容」。
 *
 * 现在的默认内容（qr.archive_mode=url）是**短落地页网址**：<base>/q/<令牌>[/<档号>]
 *   令牌   = 内部 id 的 36 进制 + 8 位 HMAC 签名（用于查找 + 防枚举）
 *   档号   = **只用于显示**，扫码时那串字里就能一眼看到编号；不参与查找
 * 之所以要短：二维码内容越短，模块数越少，打印到纸上每个模块越大越好扫。
 * 长格式 <base>/api/a/<档号>?k=…&i=… 仍然兼容（已经打印出去的旧标签），所以都接受。
 */
function isArchiveQrText(t, codeLike) {
  if (typeof t !== 'string' || !t) return false;
  if (codeLike && t === codeLike) return true;                       // code 模式（老扫码枪）
  // 短落地页网址（令牌后面可以带一段档号）
  if (/^https?:\/\/.+\/q\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/.test(t)) return true;
  if (/^https?:\/\/.+\/api\/a\//.test(t)) return true;                // 兼容长格式旧标签
  return false;
}

/** 从短落地页网址里取出**令牌那一段**（注意：末尾可能还有档号，不能取最后一段） */
function shortTokenOf(t) {
  const m = /\/q\/([0-9A-Za-z]{9,})(?:\/|$)/.exec(String(t || ''));
  return m ? m[1] : '';
}

function makeSession() {
  const jar = new Map();
  async function req(p, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + p, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(p, opts) {
    const res = await req(p, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  return { req, json };
}

const created = { archives: [], users: [] };

/** 找到二维码目录：优先用命令行给的数据目录，否则尝试常见位置 */
function findQrDir() {
  const cands = [];
  if (DATA_DIR) cands.push(path.join(DATA_DIR, 'qrcodes'));
  cands.push(path.join(__dirname, '..', '..', 'data', 'qrcodes'));
  for (const c of cands) if (fs.existsSync(c)) return c;
  return cands[0];
}

async function main() {
  console.log('档案二维码功能验证 → ' + BASE + '\n');
  const admin = makeSession();
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  if (login.status !== 200) { console.error('无法登录，终止：', JSON.stringify(login.body)); process.exit(1); }
  console.log('已登录管理员');

  const cats = await admin.json('/api/categories');
  const catId = (cats.body.data.flat.find((c) => c.code === 'WS-XZ') || cats.body.data.flat[0]).id;

  // ---------- 1. 统计接口与启动自动生成 ----------
  section('1. 启动自动生成与统计接口');
  const st0 = await admin.json('/api/qrcodes/stats');
  check('二维码统计接口可用', st0.status === 200 && !!st0.body.data, 'HTTP ' + st0.status);
  const s0 = st0.body.data || {};
  const expBorder = Number(s0.margin);
  const expScale = Number(s0.scale);
  check('统计返回纠错等级 H 与可用的静区/模块参数',
    s0.ec_level === 'H' && expBorder >= 4 && expScale >= 1,
    JSON.stringify({ ec: s0.ec_level, margin: s0.margin, scale: s0.scale }));
  console.log(`    二维码参数：纠错 ${s0.ec_level} / 静区 ${expBorder} 模块 / 每模块 ${expScale}px`);
  // 先做一次增量重建把目录对齐（其它自测脚本可能刚建过又删过档案），
  // 再断言「图片数 == 档案数、无缺失、无孤儿」这个不变式。
  const norm = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
  check('增量重建可用', norm.status === 200 && typeof norm.body.data.created === 'number',
    JSON.stringify(norm.body).slice(0, 160));
  const st1 = await admin.json('/api/qrcodes/stats');
  const s1 = st1.body.data || {};
  check('对齐后图片数与档案数完全一致（无缺失、无孤儿）',
    Number(s1.images) === Number(s1.archives) && Number(s1.missing) === 0,
    `档案 ${s1.archives} / 图片 ${s1.images} / 缺 ${s1.missing}`);
  console.log(`    档案 ${s0.archives} 份，已生成图片 ${s0.images} 张，占用 ${Math.round((s0.bytes || 0) / 1024)} KB`);
  console.log(`    目录：${s0.dir}`);
  const qrDir = s0.dir || findQrDir();
  check('二维码目录存在', fs.existsSync(qrDir), qrDir);
  check('目录里有清单.csv', fs.existsSync(path.join(qrDir, '清单.csv')), '');
  const bom = (() => {
    try { const b = fs.readFileSync(path.join(qrDir, '清单.csv')); return b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf; } catch (_) { return false; }
  })();
  check('清单.csv 带 UTF-8 BOM（Excel 双击不乱码）', bom);

  // ---------- 2. 新建档案 → 自动生成二维码 ----------
  section('2. 新建档案后自动生成二维码');
  const code = 'QR-TEST-' + Date.now().toString().slice(-6);
  const mk = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', title: '二维码功能验证档案（脚本自动清理）', category_id: catId,
      year: '2099', archive_date: '2099-01-01', retention: '永久', responsible: '自测',
      archive_code: code,
    },
  });
  check('新建档案成功', mk.status === 200 && mk.body.data && mk.body.data.id, JSON.stringify(mk.body).slice(0, 160));
  const id = mk.body.data && mk.body.data.id;
  if (id) created.archives.push(id);

  // 文件名优先用「规范档号」（archive_number），没有才退回短档案号 —— 与 lib/archive-qr.js 的规则一致
  const number = (mk.body.data && mk.body.data.archive_number) || '';
  const nameBase = number || code;
  const expectFile = path.join(qrDir, nameBase + '.png');
  // 这份档案「应该」写进二维码的内容（由后端算，短落地页网址）——
  // 后面多处断言都要拿它做精确比对，所以声明在块外面
  let expectText = '';
  console.log(`    短档案号=${code}  规范档号=${number || '（无）'}  预期文件名=${nameBase}.png`);
  check('新建后立刻生成 PNG（不用等重启）', fs.existsSync(expectFile), expectFile);
  if (fs.existsSync(expectFile)) {
    const buf = fs.readFileSync(expectFile);
    const sig = buf.slice(0, 8).toString('hex');
    const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
    check('文件是合法 PNG（签名 + 尺寸）', sig === '89504e470d0a1a0a' && w === h && w > 100, `${sig} ${w}x${h}`);
    check('文件按档号命名', path.basename(expectFile) === nameBase + '.png', path.basename(expectFile));

    // 用独立解码器验证「真机可读」
    const tmp = path.join(os.tmpdir(), 'aqr-' + Math.random().toString(16).slice(2) + '.png');
    fs.copyFileSync(expectFile, tmp);
    const dec = decodeFile(tmp);
    fs.unlinkSync(tmp);
    check('独立解码器能读出内容，且是这份档案的落地页网址',
      !!(dec && dec.ok && isArchiveQrText(dec.text, code)), dec ? (dec.ok ? `读出「${dec.text}」` : dec.reason) : '无结果');
    // 精确比对：图片里的内容必须与接口报的一致（防止两边算法不一致）
    const lab0 = await admin.json(`/api/archives/${id}/label`);
    expectText = lab0.body.data.qr_text || '';
    check('图片里的内容与 /label 接口报告的一致', !!(dec && dec.ok && dec.text === expectText),
      `图「${dec && dec.text}」 vs 接口「${expectText}」`);
    // 令牌前缀 = 本档案 id 的 36 进制 —— 保证这个码指向的确实是这份档案
    check('令牌指向的就是这份档案（前缀 = 本档案 id 的 36 进制）',
      shortTokenOf(expectText).startsWith(id.toString(36))
      && shortTokenOf(expectText).length >= 9,
      `id=${id} id36=${id.toString(36)} 令牌=${shortTokenOf(expectText)}`);
    check('内容长度 ≤ 70 字符（长了打印出来每模块就太小）', expectText.length <= 70, expectText.length + ' 字符');
    check('内容里带档号（扫出来一眼就能看到编号）', expectText.endsWith('/' + code), expectText);
    check('走的是格式信息正常路径（真扫码器同样依赖）',
      !!(dec && dec.viaFormat === true), dec ? 'viaFormat=' + dec.viaFormat : '无结果');
    // 尺寸应等于 (模块数 + 静区 8) × 10
    check(`尺寸符合 静区${expBorder} + 每模块${expScale}px 的参数`,
      dec && dec.ok && w === (dec.size + expBorder * 2) * expScale,
      dec && dec.ok ? `模块${dec.size} → 应 ${(dec.size + expBorder * 2) * expScale}，实际 ${w}` : '无模块数');
  }

  // ---------- 3. 单件 PNG 接口 ----------
  section('3. 单件二维码接口');
  const png = await admin.req(`/api/archives/${id}/qrcode.png`);
  const pngBuf = Buffer.from(await png.arrayBuffer());
  check('接口返回 PNG', png.status === 200 && png.headers.get('content-type') === 'image/png', 'HTTP ' + png.status);
  check('返回内容与磁盘文件一致', pngBuf.equals(fs.readFileSync(expectFile)));
  const dl = await admin.req(`/api/archives/${id}/qrcode.png?download=1`);
  check('download=1 时带附件头（可直接另存）',
    dl.status === 200 && /attachment/.test(dl.headers.get('content-disposition') || ''),
    dl.headers.get('content-disposition'));
  await dl.arrayBuffer();
  const rb = await admin.req(`/api/archives/${id}/qrcode.png?rebuild=1`);
  check('rebuild=1 可强制重新生成', rb.status === 200, 'HTTP ' + rb.status);
  await rb.arrayBuffer();

  // ---------- 4. 修改档案 → 二维码跟着改 ----------
  section('4. 修改档案后二维码同步更新');
  const newCode = code + '-B';
  const filesBefore = fs.readdirSync(qrDir).filter((f) => /\.png$/i.test(f)).length;
  const up = await admin.json(`/api/archives/${id}`, {
    method: 'PUT',
    json: { archive_code: newCode, title: '二维码功能验证档案（已改名）' },
  });
  check('修改档案成功', up.status === 200, JSON.stringify(up.body).slice(0, 140));
  const newFile = path.join(qrDir, nameBase + '.png');
  check('二维码图片仍然存在（按规范档号命名，档号没变则文件名不变）', fs.existsSync(newFile), path.basename(newFile));
  const filesAfter = fs.readdirSync(qrDir).filter((f) => /\.png$/i.test(f)).length;
  check('图片数量没有变多（没有留下孤儿文件）', filesAfter === filesBefore, `${filesBefore} → ${filesAfter}`);
  const oldText = expectText;                       // 改档号之前的二维码内容
  if (fs.existsSync(newFile)) {
    const tmp = path.join(os.tmpdir(), 'aqr2-' + Math.random().toString(16).slice(2) + '.png');
    fs.copyFileSync(newFile, tmp);
    const dec = decodeFile(tmp);
    fs.unlinkSync(tmp);
    check('二维码内容仍然是这份档案的落地页网址', !!(dec && dec.ok && isArchiveQrText(dec.text, newCode)),
      dec ? (dec.ok ? `读出「${dec.text}」` : dec.reason) : '无结果');
    // 改档号后：网址**显示的那一段**跟着变成新档号，但**令牌不变**（令牌里是内部 id）
    const lab1 = await admin.json(`/api/archives/${id}/label`);
    expectText = lab1.body.data.qr_text || '';
    check('改档号后二维码内容跟着更新（显示的那段变成新档号）',
      expectText.endsWith('/' + newCode), expectText);
    check('但令牌没变（令牌只认内部 id，与档号无关）',
      shortTokenOf(expectText) === shortTokenOf(oldText),
      `${shortTokenOf(oldText)} → ${shortTokenOf(expectText)}`);
    // ★ 关键：旧的二维码链接（网址里还是旧档号）必须仍然能打开这份档案 ——
    //   否则「改一次档号就把已经贴在盒子上的标签全废掉」。
    const anon = makeSession();
    const oldPath = oldText.replace(/^https?:\/\/[^/]+/, '');
    const r = await anon.req(oldPath);
    const htmlOld = await r.text();
    check('用【旧档号】的二维码链接照样能打开这份档案（旧标签不会因为改档号而失效）',
      r.status === 200 && htmlOld.includes(newCode), 'HTTP ' + r.status);
  }

  // ---------- 5. 标签打印页 ----------
  section('5. 单件标签打印页');
  const pr = await admin.req(`/api/print/archive/${id}`);
  const html = await pr.text();
  check('标签页可打开', pr.status === 200 && html.includes('档 案 二 维 码 标 签'), 'HTTP ' + pr.status);
  check('标签页含档案号', html.includes(newCode));
  check('标签页内嵌 base64 图片（断网也能打印）', /data:image\/png;base64,/.test(html));
  const imgs = (html.match(/data:image\/png;base64,/g) || []).length;
  check('默认输出 12 枚标签', imgs === 12, '数量=' + imgs);
  const pr3 = await admin.req(`/api/print/archive/${id}?count=3`);
  const html3 = await pr3.text();
  check('count 参数生效', (html3.match(/data:image\/png;base64,/g) || []).length === 3);

  // ---------- 6. 批量重建 ----------
  section('6. 批量重建接口');
  const r1 = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
  check('增量重建可用（返回统计）', r1.status === 200 && typeof r1.body.data.created === 'number',
    JSON.stringify(r1.body).slice(0, 160));
  const r2 = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true } });
  check('全部重建可用且会重写图片', r2.status === 200 && r2.body.data.created >= 1,
    JSON.stringify(r2.body.data).slice(0, 160));
  check('重建会自动清扫孤儿图片（字段已返回）',
    typeof r2.body.data.orphansRemoved === 'number', JSON.stringify(r2.body.data).slice(0, 120));
  {
    const st2 = await admin.json('/api/qrcodes/stats');
    const s2 = st2.body.data || {};
    check('全部重建后图片数与档案数仍然一致',
      Number(s2.images) === Number(s2.archives) && Number(s2.missing) === 0,
      `档案 ${s2.archives} / 图片 ${s2.images} / 缺 ${s2.missing}`);
  }
  check('重建后图片仍然可解码（重写没有损坏）', (() => {
    try {
      const tmp = path.join(os.tmpdir(), 'aqr3-' + Math.random().toString(16).slice(2) + '.png');
      fs.copyFileSync(newFile, tmp);
      const dec = decodeFile(tmp);
      fs.unlinkSync(tmp);
      return dec.ok && dec.text === expectText;
    } catch (_) { return false; }
  })());

  // ---------- 7. 权限 ----------
  section('7. 权限控制');
  const uname = 'qrtest' + Date.now().toString().slice(-5);
  const uRes = await admin.json('/api/users', {
    method: 'POST',
    json: { username: uname, password: 'Test12345', display_name: '二维码测试用户', role: 'reader' },
  });
  if (uRes.status === 200) {
    created.users.push({ id: uRes.body.data.id, username: uname });
    const reader = makeSession();
    const rl = await reader.json('/api/login', { method: 'POST', json: { username: uname, password: 'Test12345' } });
    await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
    check('普通用户可登录', rl.status === 200, JSON.stringify(rl.body).slice(0, 120));
    const readerRebuild = await reader.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
    check('普通用户不能批量重建（403）', readerRebuild.status === 403, 'HTTP ' + readerRebuild.status);
    const readerStats = await reader.json('/api/qrcodes/stats');
    check('普通用户可以查看统计', readerStats.status === 200, 'HTTP ' + readerStats.status);
    const readerPng = await reader.req(`/api/archives/${id}/qrcode.png`);
    check('普通用户可以看图', readerPng.status === 200, 'HTTP ' + readerPng.status);
    await readerPng.arrayBuffer();
  } else {
    check('建立测试用户', false, JSON.stringify(uRes.body).slice(0, 140));
  }

  // ---------- 测. 生成引擎：Python qrcode 库 / 内置引擎 ----------
  section('测. 生成引擎切换（Python qrcode 库 ↔ 内置引擎）');
  {
    const st = await admin.json('/api/qrcodes/stats');
    const d = st.body.data || {};
    check('统计接口返回引擎信息',
      typeof d.engine === 'string' && typeof d.python_available === 'boolean',
      JSON.stringify({ engine: d.engine, python: d.python_available }));
    console.log(`    配置引擎=${d.engine}　Python 可用=${d.python_available}`
      + `${d.python_available ? '  ' + (d.python_exe || '') + ' / Python ' + (d.python_version || '') : '  ' + (d.python_reason || '')}`);

    const net = await admin.json('/api/system/net');
    check('/api/system/net 也返回 Python 探测结果',
      typeof net.body.data.qr_python_available === 'boolean',
      JSON.stringify(net.body.data.qr_python_available));

    const countPng = () => fs.readdirSync(qrDir).filter((f) => /\.png$/i.test(f)).length;
    const before = countPng();

    // 内置引擎：任何机器都必须能用
    const builtin = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { engine: 'builtin', force: true } });
    check('内置引擎重建成功', builtin.status === 200 && builtin.body.data.engine === 'builtin',
      JSON.stringify(builtin.body).slice(0, 160));
    check('内置引擎重建后图片仍可解码', (() => {
      try { const dec = decodeFile(newFile); return dec.ok && dec.text === expectText; } catch (_) { return false; }
    })());
    const afterBuiltin = countPng();
    check('内置引擎生成的文件名与其他引擎一致（数量不变，无重复）', afterBuiltin === before,
      `${before} → ${afterBuiltin}`);

    // Python 引擎
    const pyRes = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { engine: 'python', force: true } });
    if (d.python_available) {
      check('Python 引擎重建成功且报告引擎名',
        pyRes.status === 200 && pyRes.body.data.engine === 'python-qrcode',
        JSON.stringify(pyRes.body).slice(0, 200));
      check('Python 引擎回报的参数与系统设置一致',
        pyRes.body.data.ec_level === 'H'
        && Number(pyRes.body.data.border) === expBorder
        && Number(pyRes.body.data.box_size) === expScale,
        JSON.stringify(pyRes.body.data).slice(0, 160));
      const afterPy = countPng();
      check('Python 引擎生成的文件名与内置引擎完全一致（数量不变，可随时切换）',
        afterPy === before, `${before} → ${afterPy}`);
      check('Python 生成后图片仍能被独立解码器读回且内容正确', (() => {
        try {
          const dec = decodeFile(newFile);
          return dec.ok && dec.text === expectText && dec.viaFormat === true;
        } catch (_) { return false; }
      })());
      // Python 的 qrcode 默认输出 1 位深 PNG，解码器必须支持
      try {
        const b = fs.readFileSync(newFile);
        check('Python 产物为 1 位深 PNG 且能被读取（位深=' + b[24] + '）', b[24] === 1 && b[25] === 0);
      } catch (e) { check('读取 Python 产物', false, e.message); }
    } else {
      check('Python 不可用时，强制指定 python 会如实报错（不静默换引擎）',
        pyRes.status === 500 && /Python|qrcode/i.test(String(pyRes.body.error || '')),
        'HTTP ' + pyRes.status + ' ' + String(pyRes.body.error || '').slice(0, 120));
    }

    // auto：没 Python 时必须能自动退回内置引擎
    const auto = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { engine: 'auto', force: true } });
    check('auto 引擎重建成功', auto.status === 200 && typeof auto.body.data.engine === 'string',
      JSON.stringify(auto.body).slice(0, 160));
    check('auto 时若 Python 不可用则自动退回内置引擎',
      d.python_available ? auto.body.data.engine === 'python-qrcode' : auto.body.data.engine === 'builtin',
      'engine=' + (auto.body.data && auto.body.data.engine));
  }

  // ---------- 测2. Python 脚本与 Node 侧的接口契约（静态检查） ----------
  section('测2. Python 脚本契约（参数与报告字段）');
  {
    const pyPath = path.join(__dirname, 'generate_qrcodes.py');
    check('Python 生成脚本存在', fs.existsSync(pyPath), pyPath);
    if (fs.existsSync(pyPath)) {
      const src = fs.readFileSync(pyPath, 'utf8');
      check('脚本使用 ERROR_CORRECT_H（容错率 H）', /ERROR_CORRECT_H/.test(src));
      check('脚本默认静区 ≥ 4（规范最低要求）', /BORDER\s*=\s*(\d+)/.test(src)
        && Number(/BORDER\s*=\s*(\d+)/.exec(src)[1]) >= 4, (src.match(/BORDER\s*=\s*\d+/) || [''])[0]);
      check('脚本默认每模块像素 ≥ 4', /BOX_SIZE\s*=\s*(\d+)/.test(src)
        && Number(/BOX_SIZE\s*=\s*(\d+)/.exec(src)[1]) >= 4, (src.match(/BOX_SIZE\s*=\s*\d+/) || [''])[0]);
      check('脚本支持 --border / --box-size（与系统设置同步）',
        /--border/.test(src) && /--box-size/.test(src));
      check('脚本支持公网网址参数（--base-url / --archive-mode / --sign-key）',
        /--base-url/.test(src) && /--archive-mode/.test(src) && /--sign-key/.test(src));
      check('脚本按档号命名并输出 PNG', /\.png/.test(src) && /archive_number/.test(src) && /archive_code/.test(src));
      check('脚本支持 --report（Node 侧靠它取结果，不用管道）', /--report/.test(src) && /json\.dump/.test(src));
      check('脚本会比对上次内容，地址变了就重写（DHCP 换 IP 也能跟上）',
        /read_recorded_contents/.test(src) && /content_changed/.test(src));
      check('清单.csv 的 4 列顺序正确（档案号/题名/文件名/内容），内容列不能写成档案号',
        /\["档案号", "题名", "二维码图片文件名", "二维码内容"\]/.test(src)
        && /index_rows\.append\(\(row\["archive_number"\] or row\["archive_code"\] or ""/.test(src));
      // Node 侧读取的字段必须都在 Python 的报告里
      const wants = ['ok', 'engine', 'total', 'created', 'skipped', 'failed', 'errors', 'dir', 'ec_level', 'border', 'box_size'];
      const missing = wants.filter((k) => !new RegExp('"' + k + '"').test(src));
      check('报告 JSON 含 Node 侧需要的全部字段', missing.length === 0, '缺少：' + missing.join(', '));
    }
    const nodeSrc = fs.readFileSync(path.join(__dirname, '..', 'lib', 'python-qr.js'), 'utf8');
    check('Node 侧用报告文件而不是管道取结果（受限环境也能跑）', /--report/.test(nodeSrc) && /stdio:\s*'ignore'/.test(nodeSrc));
    check('Node 侧对「Python 不可用」有明确原因', /available:\s*false/.test(nodeSrc) && /reason/.test(nodeSrc));
  }

  // ---------- 测3. 地址变了要自动重写（DHCP 换 IP 的场景） ----------
  // 这是「扫不出来」最阴的一种：IP 一变，旧图片里写的还是老地址，
  // 二维码看着完好，扫出来却打不开。所以必须比内容、自动重写。
  section('测3. 网址前缀变化后，旧二维码必须自动重写');
  {
    // 用 2098 年度，避免与上面那份 2099 的档案撞规范档号（会 409 建不出来）
    const mk2 = await admin.json('/api/archives', {
      method: 'POST',
      json: {
        type_code: 'WS', title: '二维码地址变化验证（脚本自动清理）', category_id: catId,
        year: '2098', archive_date: '2098-01-01', retention: '永久', responsible: '自测',
      },
    });
    const id2 = mk2.body.data && mk2.body.data.id;
    check('建立「地址变化」验证用档案', mk2.status === 200 && !!id2,
      'HTTP ' + mk2.status + ' ' + JSON.stringify(mk2.body).slice(0, 180));
    if (id2) created.archives.push(id2);
    const num2 = (mk2.body.data && mk2.body.data.archive_number) || '';
    const code2 = (mk2.body.data && mk2.body.data.archive_code) || '';
    console.log(`    档案 id=${id2} 规范档号=${num2 || '（无）'} 短档号=${code2}`);

    const readContent = () => {
      const st = JSON.parse(fs.readFileSync(path.join(qrDir, '.gen.json'), 'utf8'));
      return st;
    };
    const findFile = () => {
      if (num2 && fs.existsSync(path.join(qrDir, num2 + '.png'))) return path.join(qrDir, num2 + '.png');
      if (code2 && fs.existsSync(path.join(qrDir, code2 + '.png'))) return path.join(qrDir, code2 + '.png');
      // 兜底：目录里最新的那张 PNG（刚建完档案，最新的一定是它）
      const pngs = fs.readdirSync(qrDir).filter((f) => /\.png$/i.test(f))
        .map((f) => ({ f, t: fs.statSync(path.join(qrDir, f)).mtimeMs }))
        .sort((x, y) => y.t - x.t);
      return pngs.length ? path.join(qrDir, pngs[0].f) : '';
    };
    const decodeNow = () => {
      const f = findFile();
      if (!f || !fs.existsSync(f)) return null;
      const tmp = path.join(os.tmpdir(), 'aqr4-' + Math.random().toString(16).slice(2) + '.png');
      fs.copyFileSync(f, tmp);
      const d = decodeFile(tmp);
      try { fs.unlinkSync(tmp); } catch (_) {}
      return d;
    };

    // 第一次：用 A 地址生成
    await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': 'http://10.20.30.40:8787' } } });
    const r1 = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
    check('按 A 地址重建成功', r1.status === 200, JSON.stringify(r1.body).slice(0, 140));
    const d1 = decodeNow();
    check('图片里写的是 A 地址',
      !!(d1 && d1.ok && d1.text.startsWith('http://10.20.30.40:8787/q/')),
      d1 && d1.ok ? d1.text : '无结果');

    // 第二次：只改地址，**不带 force**（模拟「本机 IP 变了，系统自己发现」）
    await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.base_url': 'http://10.20.30.41:8787' } } });
    const r2 = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
    check('不带 force 也检测到内容变化并重写', r2.status === 200 && Number(r2.body.data.created) >= 1,
      `created=${r2.body.data && r2.body.data.created}`);
    check('接口回报「检测到变化、已自动重写」', /自动重写/.test(String(r2.body.data && r2.body.data.note || '')),
      String(r2.body.data && r2.body.data.note || '').slice(0, 120));
    const d2 = decodeNow();
    check('图片里已经变成 B 地址（不是 A 地址，不是死链）',
      !!(d2 && d2.ok && d2.text.startsWith('http://10.20.30.41:8787/q/')),
      d2 && d2.ok ? d2.text : '无结果');
    const st2 = r2.body.data && r2.body.data.staleDetected;
    check('回报里带 staleDetected（内容变化张数 > 0）',
      !!(st2 && Number(st2.contentChanged) > 0), JSON.stringify(st2));

    // 清单.csv 必须是 4 列且第 4 列是真正的二维码内容（曾经 Python 引擎写错过）
    const csv = fs.readFileSync(path.join(qrDir, '清单.csv'), 'utf8').replace(/^\ufeff/, '');
    const head = csv.split(/\r?\n/)[0];
    check('清单.csv 表头是 4 列且顺序正确',
      head === '档案号,题名,二维码图片文件名,二维码内容', head);
    const rowLine = csv.split(/\r?\n/).find((l) => l.includes(path.basename(findFile()))) || '';
    const cells = rowLine.split('","').map((s) => s.replace(/^"|"$/g, ''));
    check('清单.csv 第 4 列是落地页网址（不是档案号）',
      cells.length >= 4 && /^https?:\/\/.+\/q\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/.test(cells[3]), cells[3] || rowLine.slice(0, 160));
    check('.gen.json 记录了参数指纹（供下次判断参数是否变过）',
      !!readContent() && Number(readContent().margin) >= 4, JSON.stringify(readContent()));

    // 参数变化也要触发整体重写
    await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.box_size': '10' } } });
    const r3 = await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: {} });
    check('只改每模块像素、不带 force 也会整体重写',
      r3.status === 200 && r3.body.data.staleDetected && r3.body.data.staleDetected.paramsChanged === true,
      JSON.stringify(r3.body.data && r3.body.data.staleDetected));
    await admin.json('/api/settings', { method: 'PUT', json: { settings: { 'qr.box_size': String(expScale), 'qr.base_url': '' } } });
    await admin.json('/api/qrcodes/rebuild', { method: 'POST', json: { force: true } });

    if (id2) {
      await admin.json('/api/archives/' + id2, { method: 'DELETE', json: { reason: '测试夹具清理' } });
      created.archives = created.archives.filter((x) => x !== id2);
    }
  }

  // ---------- 8. 清理 ----------
  section('8. 清理自测数据');
  let cleaned = true;
  for (const aid of created.archives) {
    const r = await admin.json('/api/archives/' + aid, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    if (r.status !== 200) cleaned = false;
  }
  check('测试档案已删除', cleaned);
  check('档案删除后二维码图片也一并清除', !fs.existsSync(newFile), path.basename(newFile));  for (const u of created.users) {
    if (u.id) await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } }).catch(() => {});
  }
  check('测试用户已清理', true);

  console.log('\n' + '='.repeat(56));
  console.log(`档案二维码功能验证：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) fails.forEach((f) => console.log('  - ' + f));
  console.log('='.repeat(56));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('验证异常终止：', e); process.exit(1); });
