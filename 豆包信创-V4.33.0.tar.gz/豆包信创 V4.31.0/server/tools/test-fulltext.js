/**
 * 全文搜索补全（v4.12.0）验证 —— 旧版 Office 提取 / 扩展名嗅探 / 统一检索框 / 零安装 OCR
 *
 * 这一版解决的是实测出来的真问题：用户本机 50 个真实文件里，全文检索只成功 26 个（52%），
 * **.doc 17 个全失败、.xls 4 个全失败**。失败的原因有两类，本套件各盯一半：
 *
 *  ① **扩展名不可信**。那 21 个文件里只有 5 个是真的 OLE2 二进制，16 个是扩展名写着 .doc、
 *     内容却是 Word 2003 XML，还有 1 个是 HTML。只看扩展名会把能读的文件判成"不支持"。
 *  ② **真的旧版二进制**（.doc/.xls）需要按 OLE2 容器 + BIFF8 共享字符串表 / Word 片段表来解。
 *
 * 另外两件事也在这里验：
 *  ③ **统一检索框**：关键词要能命中附件正文，并且要在结果里标出"命中于附件正文"。
 *  ④ **Windows 自带 OCR（零安装）**：本机 Windows 就带识别引擎，不该逼用户去装 tesseract。
 *     这一条用"自己画一张中文图片再识别"来验，不依赖任何外部夹具。
 *
 * 关于 OLE2 真二进制：二进制夹具不便在测试里手工构造，所以本套件对**本机真实样本**做条件检查
 * （样本目录里没有 .doc/.xls 时如实标记为跳过，而不是假装通过）。
 */
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const LIB = path.join(__dirname, '..', 'lib');

let pass = 0;
let failed = 0;
let skipped = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
function skip(name, why) { skipped++; console.log('  – ' + name + '（跳过：' + why + '）'); }
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

function multipart(files, fields = {}) {
  const boundary = '----ft' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'application/octet-stream'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const TAG = 'FT' + Math.random().toString(16).slice(2, 8).toUpperCase();
const YR = '2046';

// ---------------------------------------------------------------------------
// 纯解析层（不起服务，直接调文本提取模块）
// ---------------------------------------------------------------------------
function localChecks() {
  const te = require(path.join(LIB, 'text-extract'));
  const sniff = require(path.join(LIB, 'office-sniff'));

  section('一、按字节嗅探真实格式（扩展名不可信）');
  check('ZIP 包识别为 zip', sniff.sniffFormat(Buffer.from('PK\u0003\u0004xxxx')) === 'zip');
  check('OLE2 头识别为 ole2', sniff.sniffFormat(Buffer.concat([Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]), Buffer.alloc(600)])) === 'ole2');
  check('RTF 识别为 rtf', sniff.sniffFormat(Buffer.from('{\\rtf1\\ansi')) === 'rtf');
  check('XML 识别为 xml', sniff.sniffFormat(Buffer.from('<?xml version="1.0"?><w:wordDocument/>')) === 'xml');
  check('HTML 识别为 html', sniff.sniffFormat(Buffer.from('<html><body>x</body></html>')) === 'html');
  check('带 BOM 的 HTML 也能识别', sniff.sniffFormat(Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), Buffer.from('<html><body>x</body></html>')])) === 'html');

  section('二、伪装成 .doc 的 Word 2003 XML（真实样本里占 16/21）');
  const wxml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<?mso-application progid="Word.Document"?>
<w:wordDocument xmlns:w="http://schemas.microsoft.com/office/word/2003/wordml">
<w:body>
<w:p><w:r><w:t>作 品 登 记 承 诺 书</w:t></w:r></w:p>
<w:p><w:r><w:t>本人承诺：所提交的作品登记申请材料全面、真实、有效。</w:t></w:r></w:p>
<w:p><w:r><w:t>特此承诺。</w:t></w:r></w:p>
</w:body></w:wordDocument>`;
  const r1 = te.extractText(Buffer.from(wxml, 'utf8'), '用户承诺书.doc');
  check('★ 能提取出正文', r1.ok, r1.reason);
  check('★ 正文里没有 XML 标签', r1.ok && !/<\w/.test(r1.text), String(r1.text || '').slice(0, 60));
  check('★ 抓到了正文内容', r1.ok && /作品登记承诺书|承诺/.test(r1.text), String(r1.text || '').slice(0, 60));
  check('如实说明"实际是 XML 格式"', /XML/.test(r1.kind || ''), r1.kind);

  section('三、伪装成 .doc 的 HTML / RTF / docx 包');
  const htmlDoc = Buffer.from('<html><head><title>x</title></head><body><p>值班信息：2026年7月20日</p><p>全区平均降雨量为4.2毫米，最大降雨量为39.8毫米。</p></body></html>', 'utf8');
  const r2 = te.extractText(htmlDoc, '值班信息.doc');
  check('★ HTML 伪装成 .doc 能提取', r2.ok && /降雨量/.test(r2.text), r2.reason);
  check('正文不含 HTML 标签', r2.ok && !/<p>|<\/p>/.test(r2.text), String(r2.text || '').slice(0, 60));

  // RTF：\'d6\'d0… 是 CP936 十六进制转义。文本要够长（提取器有 20 字下限，避免把噪声当正文）
  const rtfHex = "{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 SimSun;}}\\f0\\fs32 \\'d6\\'d0\\'ce\\'c4\\'b5\\'b5\\'b0\\'b8\\'bc\\'c7\\'c2\\'bc\\'a3\\'ba\\'c8\\'ab\\'c7\\'f8\\'c6\\'bd\\'be\\'f9\\'bd\\'b5\\'d3\\'ea\\'c1\\'bf\\'ce\\'aa4.2\\'ba\\'c1\\'c3\\'d7\\'a3\\'ac\\'d7\\'ee\\'b4\\'f3\\'bd\\'b5\\'d3\\'ea\\'c1\\'bf\\'ce\\'aa39.8\\'ba\\'c1\\'c3\\'d7\\'a1\\'a3\\par}";
  const r3 = te.extractText(Buffer.from(rtfHex, 'binary'), '记录.doc');
  check('RTF 伪装成 .doc 能提取', r3.ok, r3.reason);
  check('RTF 的十六进制转义按 CP936 正确还原', r3.ok && /中文报送|降雨量|毫米/.test(r3.text),
    String(r3.text || '').slice(0, 60));

  section('四、诚实的失败：宁可不提取，也不灌垃圾');
  check('无法识别的内容如实报错', !te.extractText(Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]), 'x.doc').ok);
  const junk = '檒抍孴婲胈鄗燫剉梿橖' .repeat(20);
  check('★ 乱码被判为"不像人话"', sniff.looksLikeGarbage(junk), sniff.plausibility(junk).toFixed(3));
  check('★ 正常中文不会被误判', !sniff.looksLikeGarbage('广州市南沙区排水和污水处理事务中心章程第一章总则第一条为加强党的全面领导保障科学民主管理'),
    sniff.plausibility('广州市南沙区排水和污水处理事务中心章程第一章总则第一条为加强党的全面领导保障科学民主管理').toFixed(3));

  section('五、canExtract 覆盖旧版扩展名');
  check('.doc 可提取', te.canExtract('a.doc'));
  check('.xls 可提取', te.canExtract('a.xls'));
  check('.ppt 可提取', te.canExtract('a.ppt'));
  check('.wps 可提取', te.canExtract('a.wps'));

  section('六、本机真实旧版文件（条件检查）');
  const dirs = ['Desktop', 'Documents', 'Downloads'].map((d) => path.join(process.env.USERPROFILE || '', d));
  let real = [];
  let tempFiles = 0;
  for (const d of dirs) {
    let list = [];
    try { list = fs.readdirSync(d); } catch (_) { continue; }
    for (const f of list) {
      if (!/\.(doc|xls)$/i.test(f)) continue;
      // Office 临时锁文件（~$ 开头）不是文档，不该算进"应能提取"的分母
      if (/^~\$/.test(f)) { tempFiles++; continue; }
      real.push(path.join(d, f));
    }
  }
  if (tempFiles) {
    const sample = real.length ? real[0] : null;
    if (sample) {
      const dir0 = path.dirname(sample);
      const lk = fs.readdirSync(dir0).find((f) => /^~\$.*\.(doc|xls)$/i.test(f));
      if (lk) {
        const r = te.extractText(fs.readFileSync(path.join(dir0, lk)), lk);
        check('★ Office 临时锁文件被识别并说明（而不是报"无法识别"）',
          /临时/.test(r.kind || '') || /临时/.test(r.reason || ''), `${r.kind} / ${r.reason}`);
      }
    }
  }
  if (!real.length) {
    skip('真实 .doc/.xls 提取', '样本目录里没有这类文件');
  } else {
    let okCount = 0;
    const bad = [];
    for (const p of real) {
      let r;
      try { r = te.extractText(fs.readFileSync(p), path.basename(p)); } catch (e) { r = { ok: false, reason: e.message }; }
      if (r.ok && !sniff.looksLikeGarbage(r.text)) okCount++;
      else bad.push(path.basename(p) + '：' + (r.reason || '内容判为垃圾'));
    }
    check(`★ 本机 ${real.length} 个真实 .doc/.xls 全部提取成功且内容可读`,
      okCount === real.length, bad.slice(0, 3).join(' / '));
  }
}

// ---------------------------------------------------------------------------
// 接口层
// ---------------------------------------------------------------------------
async function main() {
  localChecks();

  const admin = makeSession();
  section('七、准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) { report(); return; }
  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const leaf = flat.find((c) => c.level === 2 && String(c.code).startsWith('WS-'));
  check('拿到二级分类', !!leaf, leaf && leaf.code);
  if (!leaf) { report(); return; }

  const created = [];
  async function mk(title, extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({ type_code: 'WS', category_id: leaf.id, title, year: YR, secret_level: '公开' }, extra),
    });
    if (r.body && r.body.ok && r.body.data && r.body.data.id) created.push(r.body.data.id);
    return r;
  }

  section('八、统一检索框：关键词能命中附件正文');
  const A = await mk(`${TAG}与关键词无关的题名`);
  const a = A.body.data.id;
  const MARK = '附件里的特殊标记' + TAG;
  const mpTxt = multipart([{ filename: '正文.txt', data: `这是一份附件。 ${MARK} 内涝防治应急预案。`, mime: 'text/plain' }]);
  const up = await admin.req(`/api/archives/${a}/files`, { method: 'POST', headers: { 'Content-Type': mpTxt.contentType }, body: mpTxt.body });
  check('上传含关键词的附件', up.status === 200, String(up.status));

  const hit = await admin.json('/api/archives?kw=' + encodeURIComponent(MARK) + '&size=50');
  check('★ 关键词命中附件正文（题名里没有这个词）',
    ((hit.body.data || {}).list || []).some((x) => x.id === a), `total=${hit.body.data.total}`);
  const row = ((hit.body.data || {}).list || []).find((x) => x.id === a) || {};
  check('★ 结果里标出"命中于附件正文"', !!row.text_hit, JSON.stringify(Object.keys(row)));
  check('★ 带出可读的命中片段', row.text_hit && /内涝防治|附件里的特殊标记/.test(row.text_hit.snippet || ''),
    row.text_hit && row.text_hit.snippet);
  check('片段标注了正文来源为原生', row.text_hit && row.text_hit.via === 'native', row.text_hit && row.text_hit.via);
  check('附件名也带出来了', row.text_hit && !!row.text_hit.original_name, row.text_hit && row.text_hit.original_name);

  const noText = await admin.json('/api/archives?kw=' + encodeURIComponent(MARK) + '&noText=1&size=50');
  check('★ noText=1 时只搜档案行本身（不命中附件正文）',
    !((noText.body.data || {}).list || []).some((x) => x.id === a), `total=${noText.body.data.total}`);

  const titleHit = await admin.json('/api/archives?kw=' + encodeURIComponent(TAG) + '&size=50');
  const trow = ((titleHit.body.data || {}).list || []).find((x) => x.id === a) || {};
  check('题名命中时不需要附件标注', !trow.text_hit || trow.text_hit !== null
    ? (trow.text_hit === undefined || !!(trow.text_hit && trow.text_hit.snippet))
    : true);

  section('九、表达式里的裸词也走同一口径');
  const expr = await admin.json('/api/archives?expr=' + encodeURIComponent(MARK) + '&size=50');
  check('★ 高级检索表达式的裸词也命中附件正文',
    ((expr.body.data || {}).list || []).some((x) => x.id === a), String(expr.status));
  const exprAnd = await admin.json('/api/archives?expr=' + encodeURIComponent(`${MARK} AND 年度:${YR}`) + '&size=50');
  check('裸词可与字段条件组合', ((exprAnd.body.data || {}).list || []).some((x) => x.id === a), String(exprAnd.status));

  section('十、OCR：Windows 自带引擎（零安装）');
  const st = await admin.json('/api/ocr/status?force=1');
  check('OCR 状态接口可用', st.status === 200 && st.body.ok, String(st.status));
  const det = (st.body.data || {}).detect || {};
  if (det.engine === 'windows') {
    check('★ 探测到 Windows 自带识别引擎', !!det.windows && det.available, JSON.stringify(det).slice(0, 120));
    check('★ 报告了识别语言（中文）', (det.windows.langs || []).some((l) => /^zh/i.test(l)),
      JSON.stringify(det.windows && det.windows.langs));
    check('★ 扫描版 PDF 也能处理（用系统自带渲染器）', det.canPdf === true && det.pdfVia === 'windows',
      `canPdf=${det.canPdf} pdfVia=${det.pdfVia}`);
    check('提示里说明了"无需安装任何软件"', (det.notes || []).some((n) => /无需安装/.test(n)),
      JSON.stringify(det.notes));

    // 用系统画一张中文图片，走完整识别链路
    const w = require(path.join(LIB, 'ocr-windows'));
    const dir = path.join(os.tmpdir(), 'dsh-ft-ocr-' + TAG);
    fs.mkdirSync(dir, { recursive: true });
    const png = path.join(dir, 't.png');
    const drawOut = path.join(dir, 'draw.txt');
    fs.writeFileSync(drawOut, '');
    w.runPowerShell(`
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$b = [System.Drawing.Bitmap]::new(1000, 300)
$g = [System.Drawing.Graphics]::FromImage($b)
$g.Clear([System.Drawing.Color]::White)
$f = [System.Drawing.Font]::new('SimSun', 34)
$g.DrawString('${TAG} 内涝防治应急预案', $f, [System.Drawing.Brushes]::Black, 24, 40)
$g.DrawString('值班制度与责任分工', $f, [System.Drawing.Brushes]::Black, 24, 130)
$g.Dispose(); $b.Save(${JSON.stringify(png)}); $b.Dispose()
`, drawOut, 60000);

    if (!fs.existsSync(png)) {
      skip('Windows OCR 真实识别', '本机无法生成测试图片（缺 System.Drawing 或字体）');
    } else {
      const B = await mk(`${TAG}扫描件样本`);
      const b = B.body.data.id;
      const mpPng = multipart([{ filename: '扫描件.png', data: fs.readFileSync(png), mime: 'image/png' }]);
      const upPng = await admin.req(`/api/archives/${b}/files`, { method: 'POST', headers: { 'Content-Type': mpPng.contentType }, body: mpPng.body });
      check('上传扫描件（PNG）成功', upPng.status === 200, String(upPng.status));
      const upJson = await upPng.json();
      const fid = upJson.data.files[0].id;

      const ocr = await admin.json(`/api/files/${fid}/ocr`, { method: 'POST', json: {} });
      check('★ Windows 自带 OCR 识别成功（零安装）', ocr.status === 200 && ocr.body.data.ok,
        JSON.stringify(ocr.body).slice(0, 180));
      check('★ 报告了引擎与识别字数', /Windows OCR/.test(ocr.body.data.engine || '') && ocr.body.data.chars > 0,
        JSON.stringify({ e: ocr.body.data.engine, c: ocr.body.data.chars }));

      const txt = await admin.json(`/api/files/${fid}/text`);
      check('★ 识别出的中文正文入库', /内涝防治|应急预案|值班制度/.test(txt.body.data.content || ''),
        String(txt.body.data.content || '').slice(0, 80));
      check('★ 汉字之间的空格已去掉（否则搜不到整词）',
        !/[\u4e00-\u9fff] [\u4e00-\u9fff]/.test(txt.body.data.content || ''),
        String(txt.body.data.content || '').slice(0, 60));
      check('正文标记为 OCR 来源', txt.body.data.via === 'ocr', String(txt.body.data.via));

      const ocrSearch = await admin.json('/api/search/text?kw=' + encodeURIComponent('内涝防治') + '&via=ocr');
      check('★ OCR 出的正文能被正文检索命中',
        ((ocrSearch.body.data || {}).list || []).some((x) => x.file_id === fid), `total=${ocrSearch.body.data.total}`);

      const archSearch = await admin.json('/api/archives?kw=' + encodeURIComponent('内涝防治') + '&size=50');
      const arow = ((archSearch.body.data || {}).list || []).find((x) => x.id === b) || {};
      check('★ 统一检索框也能命中 OCR 出来的附件正文', !!arow.id, `total=${archSearch.body.data.total}`);
      check('★ 片段上标了 OCR 来源', arow.text_hit && arow.text_hit.via === 'ocr',
        JSON.stringify(arow.text_hit || {}).slice(0, 120));
    }
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 忽略 */ }
  } else {
    skip('Windows 自带 OCR 真实识别', `本机主引擎是 ${det.engine}，不是 windows`);
  }

  section('十一、收尾');
  for (const id of created) await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const left = await admin.json('/api/archives?kw=' + encodeURIComponent(TAG) + '&size=100');
  check('清理：没有残留测试档案', ((left.body.data || {}).list || []).length === 0,
    String(((left.body.data || {}).list || []).length));

  report();
}

function report() {
  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项${skipped ? `，跳过 ${skipped} 项` : ''}`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
