/**
 * 元数据方案回归测试（DA/T 46）
 *
 * 用法：node server/tools/test-metadata.js [http://127.0.0.1:8796]
 *
 * 覆盖：
 *   1. 方案定义：三实体（文件/机构人员/业务）× 20 项（《数字档案室建设指南》§5.3.4）
 *   2. 必选项（约束性为必选即必备项，DA/T 92—2022 §8.1.1）与完备性计算
 *   3. 自动捕获为主：新建档案即产生元数据；改档案/传附件会重新捕获
 *   4. **禁止修改背景/结构/管理过程元数据**：接口拒绝 + 留下拦截留痕
 *   5. 描述性元数据可改且写回档案表（两边永远一致）
 *   6. 元数据 XML 导出（含实体分组、完备性、标准依据）
 *   7. 存量补建与完备率统计
 *   8. 密级隔离与权限
 *
 * 脚本结束时清理测试数据，可重复运行。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text, headers: res.headers };
  }
  async function raw(pathname, opts) {
    const res = await req(pathname, opts);
    return { status: res.status, text: await res.text(), headers: res.headers };
  }
  return { req, json, raw };
}

function multipart(files, fields = {}) {
  const boundary = '----meta' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'files'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/plain'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const TAG = 'META' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const created = { users: [], archives: [] };

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok);
  if (!login.body.ok) process.exit(1);
  const cats = (await admin.json('/api/categories')).body.data.flat;
  const cat = cats.find((c) => c.code === 'WS-XZ') || cats[0];

  async function makeArchive(extra = {}) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: Object.assign({
        type_code: 'WS', category_id: cat.id, title: `${TAG} 元数据样本`, secret_level: '公开',
        retention: '定期10年', year: '2026', archive_date: '2026-01-01',
        responsible: '办公室', department: '综合科',
      }, extra),
    });
    if (r.body.ok) created.archives.push(r.body.data.id);
    return r.body.ok ? r.body.data : null;
  }

  // ---------- 1. 方案定义 ----------
  section('元数据方案定义');
  const sc = await admin.json('/api/metadata/scheme');
  const s = sc.body.data || {};
  check('方案标注为 DA/T 46—2009', s.scheme === 'DA/T 46—2009', String(s.scheme));
  check('包含 20 项文书类元数据（建设指南 §5.3.4）', (s.elements || []).length === 20,
    String((s.elements || []).length));
  const entCodes = (s.entities || []).map((e) => e.code).sort().join(',');
  check('包含三个元数据实体（文件/机构人员/业务）', entCodes === 'agent,business,file', entCodes);
  check('每个实体都有元数据项', ['file', 'agent', 'business']
    .every((e) => (s.elements || []).some((x) => x.entity === e)),
    JSON.stringify((s.elements || []).map((x) => x.entity)));
  check('每项标注了标准依据', (s.elements || []).every((x) => !!x.basis));
  check('每项标注了是否必选', (s.elements || []).every((x) => typeof x.required === 'boolean'));
  check('每项标注了是否可改', (s.elements || []).every((x) => typeof x.editable === 'boolean'));
  check('每项标注了是否为自动捕获', (s.elements || []).every((x) => typeof x.autoCaptured === 'boolean'));
  check('区分背景/结构/管理过程/描述四类信息',
    new Set((s.elements || []).map((x) => x.kind)).size === 4,
    JSON.stringify([...new Set((s.elements || []).map((x) => x.kind))]));
  check('禁止修改的三类共 13 项左右（背景+结构+管理过程）',
    (s.totals || {}).immutable >= 10, JSON.stringify(s.totals));
  check('必选项数量合理（不少于 12 项）', (s.totals || {}).required >= 12, JSON.stringify(s.totals));
  for (const code of ['M01', 'M05', 'M06', 'M07', 'M09', 'M11', 'M16', 'M17', 'M18', 'M19', 'M20']) {
    check(`方案包含元数据项 ${code}`, (s.elements || []).some((x) => x.code === code));
  }

  // ---------- 2. 自动捕获 ----------
  section('新建档案即自动捕获元数据');
  const a1 = await makeArchive();
  check('夹具档案创建成功', !!a1, JSON.stringify(a1).slice(0, 120));
  check('新建接口返回元数据完备性', !!(a1 && a1.metadata_completeness),
    JSON.stringify(a1 && a1.metadata_completeness).slice(0, 160));

  const m1 = await admin.json(`/api/archives/${a1.id}/metadata`);
  const md1 = m1.body.data || {};
  check('元数据已落库（captured=true）', md1.captured === true, String(md1.captured));
  check('返回 20 项元数据值', Object.keys(md1.values || {}).length === 20,
    String(Object.keys(md1.values || {}).length));
  check('档号已自动捕获且与档案一致', (md1.values || {}).M05 === a1.archive_number,
    `${(md1.values || {}).M05} vs ${a1.archive_number}`);
  check('年度/保管期限已自动捕获', (md1.values || {}).M06 === '2026' && /定期10年/.test((md1.values || {}).M07 || ''),
    JSON.stringify([(md1.values || {}).M06, (md1.values || {}).M07]));
  check('实体标识符已生成（AR- 前缀）', /^AR-\d{8}$/.test((md1.values || {}).M20 || ''),
    String((md1.values || {}).M20));
  check('聚合层次为「件」', (md1.values || {}).M01 === '件', String((md1.values || {}).M01));
  check('业务行为/行为时间已捕获', !!(md1.values || {}).M18 && !!(md1.values || {}).M19,
    JSON.stringify([(md1.values || {}).M18, (md1.values || {}).M19]));
  check('完备性判定为齐全（必选项都有值）', (md1.completeness || {}).complete === true,
    JSON.stringify(md1.completeness));
  check('完备率 100%', (md1.completeness || {}).rate === 100, String((md1.completeness || {}).rate));

  section('元数据随档案变更重新捕获');
  const before = (md1.values || {}).M19;
  await new Promise((r) => setTimeout(r, 20));
  await admin.json(`/api/archives/${a1.id}`, {
    method: 'PUT',
    json: {
      title: `${TAG} 元数据样本（改名）`, category_id: cat.id, retention: '定期30年',
      secret_level: '内部', year: '2026', archive_date: '2026-01-01', responsible: '办公室', department: '综合科',
    },
  });
  const m1b = await admin.json(`/api/archives/${a1.id}/metadata`);
  const v1b = (m1b.body.data || {}).values || {};
  check('题名变更已同步到元数据', v1b.M09 === `${TAG} 元数据样本（改名）`, String(v1b.M09));
  check('保管期限变更已同步', /定期30年/.test(v1b.M07 || ''), String(v1b.M07));
  check('密级变更已同步', v1b.M11 === '内部', String(v1b.M11));
  check('行为时间随变更刷新', v1b.M19 !== before, `${before} → ${v1b.M19}`);
  const changes = (m1b.body.data || {}).changes || [];
  check('变更留痕记录了自动捕获', changes.some((c) => c.action === '自动捕获'),
    JSON.stringify(changes.slice(0, 3)));

  // ---------- 3. 禁止修改三类元数据 ----------
  section('禁止修改背景/结构/管理过程元数据');
  const rejectAttempt = await admin.json(`/api/archives/${a1.id}/metadata`, {
    method: 'PUT',
    json: { values: { M05: 'Z999-WS·2026-D30-XZ-9999', M06: '1999', M20: 'AR-99999999' } },
  });
  check('接口返回成功但逐项拒绝', rejectAttempt.status === 200 &&
    (rejectAttempt.body.data.rejected || []).length === 3,
    JSON.stringify(rejectAttempt.body.data).slice(0, 220));
  check('拒绝原因引用了标准条款',
    /数字档案室建设指南|GB\/T 18894/.test(JSON.stringify(rejectAttempt.body.data.rejected)),
    JSON.stringify(rejectAttempt.body.data.rejected).slice(0, 200));
  check('拒绝原因说明了该项属于哪类信息',
    /管理过程信息/.test(JSON.stringify(rejectAttempt.body.data.rejected)),
    JSON.stringify(rejectAttempt.body.data.rejected).slice(0, 200));
  const afterReject = await admin.json(`/api/archives/${a1.id}/metadata`);
  const vAfter = (afterReject.body.data || {}).values || {};
  check('档号未被改动', vAfter.M05 === a1.archive_number, String(vAfter.M05));
  check('年度未被改动', vAfter.M06 === '2026', String(vAfter.M06));
  check('实体标识符未被改动', /^AR-\d{8}$/.test(vAfter.M20 || ''), String(vAfter.M20));
  check('被拒绝的修改留下了留痕',
    ((afterReject.body.data || {}).changes || []).some((c) => c.action === '拒绝修改'),
    JSON.stringify(((afterReject.body.data || {}).changes || []).slice(0, 3)));
  check('留痕里记录了试图写入的新值',
    ((afterReject.body.data || {}).changes || []).some((c) => c.action === '拒绝修改' && c.new_value === '1999'),
    JSON.stringify(((afterReject.body.data || {}).changes || []).filter((c) => c.action === '拒绝修改').slice(0, 2)));

  section('描述性元数据可改（写回档案表）');
  const editOk = await admin.json(`/api/archives/${a1.id}/metadata`, {
    method: 'PUT',
    json: { values: { M09: `${TAG} 通过元数据接口改名`, M11: '秘密', M08: '这是通过元数据接口写入的内容描述' } },
  });
  check('描述性元数据修改被接受', (editOk.body.data.applied || []).length === 3,
    JSON.stringify(editOk.body.data).slice(0, 220));
  check('返回写回的目标字段',
    (editOk.body.data.applied || []).every((x) => !!x.wroteTo), JSON.stringify(editOk.body.data.applied));
  const arch = await admin.json(`/api/archives/${a1.id}`);
  check('题名已写回档案表', arch.body.data.title === `${TAG} 通过元数据接口改名`, String(arch.body.data.title));
  check('密级已写回档案表', arch.body.data.secret_level === '秘密', String(arch.body.data.secret_level));
  check('内容描述已写回档案表', /通过元数据接口写入/.test(arch.body.data.abstract || ''), String(arch.body.data.abstract));
  const afterEdit = await admin.json(`/api/archives/${a1.id}/metadata`);
  check('元数据与档案表一致（题名）',
    ((afterEdit.body.data || {}).values || {}).M09 === arch.body.data.title,
    String(((afterEdit.body.data || {}).values || {}).M09));
  check('非法密级被拒绝',
    (await admin.json(`/api/archives/${a1.id}/metadata`, {
      method: 'PUT', json: { values: { M11: '绝密' } },
    })).body.data.rejected.some((r) => /密级/.test(r.reason)));
  check('空题名被拒绝',
    (await admin.json(`/api/archives/${a1.id}/metadata`, {
      method: 'PUT', json: { values: { M09: '   ' } },
    })).body.data.rejected.some((r) => /题名/.test(r.reason)));
  check('未知元数据项被拒绝',
    (await admin.json(`/api/archives/${a1.id}/metadata`, {
      method: 'PUT', json: { values: { M99: 'x' } },
    })).body.data.rejected.some((r) => /不是本方案定义/.test(r.reason)));
  check('纯人工元素可以写入（脱机载体编号）',
    (await admin.json(`/api/archives/${a1.id}/metadata`, {
      method: 'PUT', json: { values: { M14: 'OFFLINE-DVD-001' } },
    })).body.data.applied.some((x) => x.code === 'M14'));
  const m14 = await admin.json(`/api/archives/${a1.id}/metadata`);
  check('人工值在重新捕获后仍保留', ((m14.body.data || {}).values || {}).M14 === 'OFFLINE-DVD-001',
    String(((m14.body.data || {}).values || {}).M14));

  // ---------- 4. 附件相关结构元数据 ----------
  section('结构元数据随附件变化');
  const mp = multipart([{ filename: 'note.txt', data: `${TAG} 正文` }]);
  await admin.json(`/api/archives/${a1.id}/files`, {
    method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body,
  });
  const mAfterUp = await admin.json(`/api/archives/${a1.id}/metadata`);
  const form = ((mAfterUp.body.data || {}).values || {}).M12 || '';
  check('形式特征已反映附件数量与格式', /附件：1 个/.test(form) && /txt/.test(form), form);
  const loc = ((mAfterUp.body.data || {}).values || {}).M13 || '';
  check('存储位置已反映在线存储', /在线/.test(loc), loc);

  // ---------- 5. XML 导出 ----------
  section('元数据 XML 导出');
  const xml = await admin.raw(`/api/archives/${a1.id}/metadata/export.xml`);
  check('导出返回 XML', xml.status === 200 && /^<\?xml/.test(xml.text), 'status=' + xml.status);
  check('XML 标注方案为 DA/T 46', /scheme="DA\/T 46/.test(xml.text));
  check('XML 含三个实体分组', /entity code="file"/.test(xml.text)
    && /entity code="agent"/.test(xml.text) && /entity code="business"/.test(xml.text));
  check('XML 含 20 个元素', (xml.text.match(/<element code=/g) || []).length === 20,
    String((xml.text.match(/<element code=/g) || []).length));
  check('XML 标注每项是否必选与是否可改', /required="true"/.test(xml.text) && /editable="false"/.test(xml.text));
  check('XML 含完备性结论', /<completeness /.test(xml.text));
  check('XML 含档号与题名', xml.text.includes(a1.archive_number) && xml.text.includes(TAG));
  check('导出的文件名带档号', /filename\*=UTF-8''/.test(xml.headers.get('content-disposition') || ''),
    xml.headers.get('content-disposition'));

  // ---------- 6. 补建与完备率 ----------
  section('存量补建与完备率');
  const mstats = await admin.json('/api/metadata/stats');
  const ms = mstats.body.data || {};
  check('完备率接口可用', mstats.status === 200 && typeof ms.completeRate === 'number',
    JSON.stringify(ms).slice(0, 160));
  check('按元素统计已填数量', ms.byElement && typeof ms.byElement.M05 === 'number',
    JSON.stringify(ms.byElement).slice(0, 160));
  check('给出未完备样本与缺失项', Array.isArray(ms.incompleteSamples), String((ms.incompleteSamples || []).length));

  const bf = await admin.json('/api/metadata/backfill', { method: 'POST', json: { limit: 500 } });
  check('存量补建可执行', bf.status === 200 && typeof bf.body.data.processed === 'number',
    JSON.stringify(bf.body.data).slice(0, 160));
  check('补建后处理数大于 0', bf.body.data.processed > 0, String(bf.body.data.processed));
  const mstats2 = await admin.json('/api/metadata/stats');
  check('补建后完备档案数增加', (mstats2.body.data.complete || 0) >= (ms.complete || 0),
    `${ms.complete} → ${mstats2.body.data.complete}`);
  check('补建后剩余未补建为 0', bf.body.data.remaining === 0, String(bf.body.data.remaining));

  // ---------- 7. 权限与密级 ----------
  section('权限与密级隔离');
  const aSec = await makeArchive({ secret_level: '机密', title: `${TAG} 涉密样本` });
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: `${TAG.toLowerCase()}_rd`, display_name: TAG, password: 'Test@12345', role: 'reader', clearance: '公开' },
  });
  if (mk.body.ok) created.users.push(mk.body.data.id);
  const rd = makeSession();
  await rd.json('/api/login', { method: 'POST', json: { username: `${TAG.toLowerCase()}_rd`, password: 'Test@12345' } });
  await rd.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const rdMeta = await rd.json(`/api/archives/${aSec.id}/metadata`);
  check('低密级用户读不到涉密档案的元数据（404）', rdMeta.status === 404, 'status=' + rdMeta.status);
  const rdXml = await rd.raw(`/api/archives/${aSec.id}/metadata/export.xml`);
  check('低密级用户导不出涉密档案的元数据（404）', rdXml.status === 404, 'status=' + rdXml.status);
  const rdEdit = await rd.json(`/api/archives/${a1.id}/metadata`, { method: 'PUT', json: { values: { M09: 'x' } } });
  check('普通用户不能修改元数据', rdEdit.status === 403, 'status=' + rdEdit.status);
  const rdBackfill = await rd.json('/api/metadata/backfill', { method: 'POST', json: {} });
  check('普通用户不能执行存量补建', rdBackfill.status === 403, 'status=' + rdBackfill.status);
  const rdStats = await rd.json('/api/metadata/stats');
  check('完备率统计按密级过滤（低密级账号可用）', rdStats.status === 200, 'status=' + rdStats.status);
  check('低密级账号统计口径小于管理员', (rdStats.body.data.archives || 0) <= (mstats2.body.data.archives || 0),
    `${rdStats.body.data.archives} vs ${mstats2.body.data.archives}`);

  // ---------- 清理 ----------
  section('清理');
  for (const id of created.archives) await admin.json(`/api/archives/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.users) await admin.json(`/api/users/${id}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('清理完成', true);

  console.log(`\n元数据方案回归：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n元数据测试异常终止：', e); process.exit(1); });
