/**
 * 把二值矩阵渲染成 24 位 BMP（纯手写，不依赖任何图形库）。
 *
 * 用途：喂给「独立解码器」做交叉验证时，必须走真正经过像素采样的路径 ——
 * 直接把矩阵交给解码器等于跳过了采样环节，测不出采样相关的问题。
 */
'use strict';

function matrixToBmp(modules, size, scale = 8, quiet = 4) {
  const dim = (size + quiet * 2) * scale;
  const rowSize = Math.floor((24 * dim + 31) / 32) * 4;
  const pixelBytes = rowSize * dim;
  const fileSize = 54 + pixelBytes;
  const buf = Buffer.alloc(fileSize);
  // 文件头
  buf.write('BM', 0);
  buf.writeUInt32LE(fileSize, 2);
  buf.writeUInt32LE(54, 10);
  // 信息头
  buf.writeUInt32LE(40, 14);
  buf.writeInt32LE(dim, 18);
  buf.writeInt32LE(dim, 22);
  buf.writeUInt16LE(1, 26);
  buf.writeUInt16LE(24, 28);
  buf.writeUInt32LE(0, 30);
  buf.writeUInt32LE(pixelBytes, 34);
  // 像素（BMP 自底向上，BGR）
  for (let y = 0; y < dim; y++) {
    const srcY = dim - 1 - y;             // 翻转
    const rowStart = 54 + y * rowSize;
    for (let x = 0; x < dim; x++) {
      const mx = Math.floor(x / scale) - quiet;
      const my = Math.floor(srcY / scale) - quiet;
      const dark = mx >= 0 && my >= 0 && mx < size && my < size && modules[my][mx] === 1;
      const v = dark ? 0 : 255;
      const o = rowStart + x * 3;
      buf[o] = v; buf[o + 1] = v; buf[o + 2] = v;
    }
  }
  return buf;
}

module.exports = { matrixToBmp };
