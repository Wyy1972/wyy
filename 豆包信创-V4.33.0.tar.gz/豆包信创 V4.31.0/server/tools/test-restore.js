﻿/**
 * 整库恢复与恢复演练 回归测试（豆包信创 V4.31.0）
 *
 * 用法：
 *   node server/tools/test-restore.js                # 自建临时服务 + 独立数据目录，跑完自动清
 *
 * 覆盖：
 *   1. 没有备份时演练给出明确提示（404），不是 500
 *   2. 演练能从包里数出账目、校验日志哈希链、抽查附件是否都在包里
 *   3. 演练台账可查（mode=演练，含档案/附件/用户/日志数与链结论）
 *   4. 演练后 backups.restore_tested 被置位（"这份备份能不能恢复"有据可查）
 *   5. 服务在跑时命令行恢复拒绝执行（退出码 2），不乱动生产数据
 *   6. 停服后命令行恢复成功：库与附件回到包内状态，账目一致
 *   7. 恢复后服务能正常起、原账号口令仍可登录（"恢复完打不开"是验收最常见的坑）
 *   8. 恢复动作在台账里记成 mode=实际恢复，并且审计日志里有"整库恢复"一条
 *
 * 设计说明：恢复必须停服，所以本套件**自己拉起、自己停掉**服务，
 * 不挂到 run-all 的共享库上，避免把同一次回归里别的套件的数据换掉。
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const net = require('node:net');
const { spawn, spawnSync } = require('node:child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const TEST_DATA = path.join(APP_ROOT, '.regress-restore-data');
const ADMIN_PWD_AFTER = 'Archive@2026r';
const TAG = Math.random().toString(36).slice(2, 8);

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeSession(base) {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(base + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json, jar };
}

async function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(0));
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(() => resolve(p));
    });
  });
}

async function waitPing(base, ms = 25000) {
  const until = Date.now() + ms;
  for (;;) {
    try {
      const r = await fetch(base + '/api/ping');
      const t = await r.text();
      if (t.includes('档案管理系统在运行')) return true;
    } catch (_) { /* 还没起来 */ }
    if (Date.now() > until) return false;
    await sleep(200);
  }
}

async function waitDown(base, ms = 15000) {
  const until = Date.now() + ms;
  for (;;) {
    try {
      await fetch(base + '/api/ping');
    } catch (_) { return true; }
    if (Date.now() > until) return false;
    await sleep(150);
  }
}

function removeDirDeep(dir) {
  if (!fs.existsSync(dir)) return;
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 走兜底 */ }
  if (!fs.existsSync(dir)) return;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
    for (const it of items) {
      const p = path.join(d, it.name);
      if (it.isDirectory()) { walk(p); try { fs.rmdirSync(p); } catch (_) {} }
      else { try { fs.unlinkSync(p); } catch (_) {} }
    }
  };
  walk(dir);
  try { fs.rmdirSync(dir); } catch (_) {}
}

function startServer(port) {
  const child = spawn(process.execPath, [
    path.join(APP_ROOT, 'server', 'server.js'),
    '--data', TEST_DATA, '--port', String(port), '--no-qr', '--no-scheduler', '--quiet',
  ], { cwd: APP_ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  child.stdout.on('data', (d) => { out += d; });
  child.stderr.on('data', (d) => { out += d; });
  const text = () => out;
  return { child, text };
}

async function stopServer(srv, base) {
  try { srv.child.kill(); } catch (_) {}
  await waitDown(base);
  await sleep(300);   // 给 SQLite 一个关文件句柄的窗口
}

async function main() {
  await removeDirDeep(TEST_DATA);
  const port = await freePort();
  let BASE = 'http://127.0.0.1:' + port;
  let srv = startServer(port);
  if (!await waitPing(BASE)) {
    console.error('服务没能启动，输出如下：\n' + srv.text().slice(-2000));
    try { srv.child.kill(); } catch (_) {}
    process.exit(1);
  }

  const admin = makeSession(BASE);
  let backupPath = '';
  let backupNo = '';
  let statsBefore = 0;

  try {
    section('准备');
    const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
    check('管理员可登录', login.status === 200 && login.body.ok, 'HTTP ' + login.status);
    if (!login.body.ok) throw new Error('前置失败：管理员登录不了');
    const chg = await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: 'admin123', newPassword: ADMIN_PWD_AFTER } });
    check('出厂 admin 首改口令', chg.status === 200 && chg.body.ok, JSON.stringify(chg.body).slice(0, 140));
    const st = await admin.json('/api/stats/overview');
    statsBefore = Number((st.body.data || {}).total || 0);

    section('没有备份时的演练');
    const none = await admin.json('/api/backup/drills', { method: 'POST', json: {} });
    check('无备份时演练返回 404 且提示明确', none.status === 404 && /没有可演练的备份/i.test(none.body.error || ''),
      'HTTP ' + none.status + ' ' + (none.body.error || ''));

    section('做一次备份');
    const run = await admin.json('/api/backup/run', { method: 'POST', json: { note: '恢复套件用' } });
    check('备份制作成功', run.status === 200 && run.body.ok, JSON.stringify(run.body).slice(0, 160));
    const bd = (run.body.data || {});
    backupPath = bd.dest_path || '';
    backupNo = bd.backup_no || '';
    check('备份包已落盘', backupPath && fs.existsSync(backupPath), backupPath);
    check('备份登记了摘要', String(bd.sha256 || '').length === 64);

    section('恢复演练（不碰生产库）');
    const drill = await admin.json('/api/backup/drills', { method: 'POST', json: {} });
    const dd = (drill.body.data || {});
    check('演练接口成功', drill.status === 200 && drill.body.ok, JSON.stringify(drill.body).slice(0, 160));
    check('演练结论为合格', dd.ok === true && dd.result === '合格', (dd.problems || []).join('；'));
    check('演练能数出包内账目', dd.counts && Number(dd.counts.users) > 0 && Number(dd.counts.archives) >= 0,
      JSON.stringify(dd.counts));
    check('演练校验了日志哈希链', dd.chain_ok === true);
    check('演练抽查了附件存在性（库里没附件时抽查数为 0 也算执行过）',
      dd.attachments && typeof dd.attachments.total === 'number' && Array.isArray(dd.attachments.missing),
      JSON.stringify(dd.attachments || {}).slice(0, 120));
    check('演练不产生生产库改动（统计数不变）', Number(((await admin.json('/api/stats/overview')).body.data || {}).total || 0) === statsBefore);

    const list = await admin.json('/api/backups');
    const rec = (list.body.data.list || []).find((x) => x.backup_no === backupNo) || {};
    check('演练后备份被标记已做恢复演练', Number(rec.restore_tested) === 1, 'restore_tested=' + rec.restore_tested);

    const ledger = await admin.json('/api/backup/drills?limit=10');
    check('演练台账可查', ledger.status === 200 && ledger.body.ok && Array.isArray(ledger.body.data.list));
    check('台账里有本次演练（mode=演练、合格）',
      !!(ledger.body.data.last_drill && ledger.body.data.last_drill.mode === '演练' && ledger.body.data.last_drill.result === '合格'),
      JSON.stringify(ledger.body.data.last_drill || {}).slice(0, 160));

    section('服务运行中时，命令行恢复必须拒绝');
    const running = spawnSync(process.execPath, [
      path.join(APP_ROOT, 'server', 'tools', 'restore-backup.js'),
      '--backup', backupPath, '--data', TEST_DATA, '--yes', '--port', String(port),
    ], { cwd: APP_ROOT, encoding: 'utf8' });
    check('运行中恢复被拒（退出码 2）', running.status === 2, '退出码 ' + running.status + ' ' + String(running.stdout || '').slice(-200));
    check('被拒时提示先停服务', /停止服务|还在监听/.test(String(running.stdout || '') + String(running.stderr || '')));

    section('停服后整库恢复');
    await stopServer(srv, BASE);
    const restore = spawnSync(process.execPath, [
      path.join(APP_ROOT, 'server', 'tools', 'restore-backup.js'),
      '--backup', backupPath, '--data', TEST_DATA, '--yes', '--by', '回归套件', '--port', String(port),
    ], { cwd: APP_ROOT, encoding: 'utf8' });
    const rlog = String(restore.stdout || '') + String(restore.stderr || '');
    check('恢复命令执行成功', restore.status === 0, '退出码 ' + restore.status + '\n' + rlog.slice(-600));
    check('输出里给出结论与回滚点', /恢复完成/.test(rlog) && /回滚点/.test(rlog));
    const bakDirs = fs.existsSync(TEST_DATA)
      ? fs.readdirSync(TEST_DATA).filter((f) => f.startsWith('_restore-bak-'))
      : [];
    check('留下了回滚点目录', bakDirs.length >= 1, bakDirs.join(','));

    section('恢复后服务可用性');
    srv = startServer(port);
    check('服务能重新起来', await waitPing(BASE), srv.text().slice(-400));
    const admin2 = makeSession(BASE);
    const relog = await admin2.json('/api/login', { method: 'POST', json: { username: 'admin', password: ADMIN_PWD_AFTER } });
    check('恢复后原账号口令仍可登录（不是回到出厂口令）', relog.status === 200 && relog.body.ok,
      'HTTP ' + relog.status + ' ' + (relog.body.error || ''));
    const st2 = await admin2.json('/api/stats/overview');
    check('恢复后账目与恢复前一致', Number((st2.body.data || {}).total || 0) === statsBefore,
      '前 ' + statsBefore + ' 后 ' + ((st2.body.data || {}).total));

    const led2 = await admin2.json('/api/backup/drills?limit=20');
    check('恢复动作进台账（mode=实际恢复）',
      !!(led2.body.data.last_restore && led2.body.data.last_restore.mode === '实际恢复'),
      JSON.stringify(led2.body.data.last_restore || {}).slice(0, 160));
    check('恢复台账记录了操作来源', !!(led2.body.data.last_restore && String(led2.body.data.last_restore.by_name || '').length));
    const logs = await admin2.json('/api/logs?size=30&action=' + encodeURIComponent('整库恢复'));
    const logList = ((logs.body.data || {}).list || []);
    check('审计日志里有“整库恢复”一条', logList.some((l) => String(l.action || '').includes('整库恢复')),
      '日志条数 ' + logList.length);
  } catch (e) {
    failed += 1;
    fails.push('异常中断：' + e.message);
    console.log('\n  ✗ 套件异常中断：' + (e && e.stack ? e.stack : e));
  } finally {
    try { srv.child.kill(); } catch (_) {}
    await sleep(400);
    removeDirDeep(TEST_DATA);
    try { fs.rmSync(path.join(APP_ROOT, '.regress-restore-data'), { recursive: true, force: true }); } catch (_) {}
  }

  console.log(`\n${failed === 0 ? '全部通过' : '存在失败'}：通过 ${pass} 项，失败 ${failed} 项`);
  if (fails.length) { console.log('失败清单：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((e) => { console.error(e && e.stack ? e.stack : e); process.exit(1); });
