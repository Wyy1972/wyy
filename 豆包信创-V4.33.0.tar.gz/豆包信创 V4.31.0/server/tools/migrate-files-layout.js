/**
 * 把旧版"内容寻址"的附件（data/files/WS/2026/ea/<hash>.xlsx）搬到档号目录。
 *
 * 用法（**默认只预演，不动任何文件**）：
 *   node server/tools/migrate-files-layout.js --data .\tmp-data              :: 预演
 *   node server/tools/migrate-files-layout.js --data .\tmp-data --apply      :: 真搬
 *   node server/tools/migrate-files-layout.js --data .\tmp-data --apply --backup
 *
 * 为什么默认只预演：这个脚本会移动真实档案文件。先看清"要搬哪些、搬到哪"，
 * 再决定动不动手 —— 比"跑完发现不对劲"要便宜得多。
 *
 * 安全边界：
 *   - 只动 `files` 表里有记录的文件，不碰别的目录
 *   - 目标已存在同名文件时**自动加序号**，绝不覆盖
 *   - 搬一个、写一行库；中途失败就停下并报告"已搬几个"，不会留下半套
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { openDatabase } = require('../db');
const storage = require('../lib/storage');

function arg(name, dft) {
  const i = process.argv.indexOf('--' + name);
  if (i < 0) return dft;
  const v = process.argv[i + 1];
  return v && !v.startsWith('--') ? v : true;
}

const dataDir = path.resolve(String(arg('data', path.join(__dirname, '..', '..', 'data'))));
const apply = process.argv.includes('--apply');
const doBackup = process.argv.includes('--backup');
const filesRoot = path.join(dataDir, 'files');
const dbPath = path.join(dataDir, 'archive.db');

if (!fs.existsSync(dbPath)) {
  console.error(`找不到数据库：${dbPath}`);
  console.error('请用 --data 指向数据目录（例如 D:\\我做的软件\\档案管理系统 V4.27.1\\data 的副本）');
  process.exit(1);
}

const db = openDatabase(dbPath);
const q = db.prepare.bind(db);

const rows = db.prepare(`
  SELECT f.id, f.archive_id, f.rel_path, f.sort_no, f.original_name,
         a.archive_number, a.archive_code
    FROM files f JOIN archives a ON a.id = f.archive_id
   ORDER BY f.archive_id, f.sort_no, f.id
`).all();

const totals = { already: 0, move: 0, missing: 0, failed: 0 };
const planned = [];
const seqByArchive = new Map();

for (const r of rows) {
  const rel = String(r.rel_path || '').replace(/\\/g, '/');
  const abs = path.join(filesRoot, rel);
  if (!fs.existsSync(abs)) { totals.missing += 1; continue; }

  const segs = storage.archiveSegments(r);
  // 旧文件都是"已成形"的归档件，目标直接进归档区（按档号逐级目录）
  const dir = storage.relDirFor({ zone: 'archive', archive: r });
  // 已经在目标目录里（同一件、同一目录）就跳过，脚本可重复执行
  if (rel.startsWith(dir + '/')) { totals.already += 1; continue; }

  const ext = storage.extOf(r.original_name) || storage.extOf(rel) || '';
  let seq = (seqByArchive.get(r.archive_id) || 0) + 1;
  let targetRel = `${dir}/${storage.fileBaseName(r)}${seq === 1 ? '' : '-' + String(seq).padStart(2, '0')}${ext}`;
  while (fs.existsSync(path.join(filesRoot, targetRel))) {
    seq += 1;
    targetRel = `${dir}/${storage.fileBaseName(r)}${'-' + String(seq).padStart(2, '0')}${ext}`;
  }
  seqByArchive.set(r.archive_id, seq);
  totals.move += 1;
  planned.push({ id: r.id, archive_code: r.archive_code, from: rel, to: targetRel });
}

console.log(`数据目录：${dataDir}`);
console.log(`模式：${apply ? '实际搬迁（--apply）' : '预演（只打印，不改动）'}`);
console.log(`待处理文件记录 ${rows.length} 条：需搬迁 ${totals.move}、已在档号目录 ${totals.already}、文件缺失 ${totals.missing}`);
for (const p of planned.slice(0, 20)) {
  console.log(`  ${p.archive_code}  ${p.from}\n      → ${p.to}`);
}
if (planned.length > 20) console.log(`  …另有 ${planned.length - 20} 条`);

if (!apply) {
  console.log('\n这是预演。确认无误后加 --apply 执行（建议同时加 --backup 先备份数据库）。');
  process.exit(0);
}

if (doBackup) {
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  const bak = `${dbPath}.bak-${stamp}`;
  try {
    db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
    fs.copyFileSync(dbPath, bak);
    console.log(`已备份数据库：${bak}`);
  } catch (e) {
    console.error('备份失败，已中止：' + e.message);
    process.exit(1);
  }
}

const upd = db.prepare("UPDATE files SET rel_path=?, stored_name=?, storage_kind='archive' WHERE id=?");
let moved = 0;
for (const p of planned) {
  const fromAbs = path.join(filesRoot, p.from);
  const toAbs = path.join(filesRoot, p.to);
  try {
    fs.mkdirSync(path.dirname(toAbs), { recursive: true });
    fs.renameSync(fromAbs, toAbs);
    upd.run(p.to, path.basename(p.to), p.id);
    moved += 1;
    // 顺手清掉搬空的老目录（只删空目录）
    let d = path.dirname(fromAbs);
    const root = path.resolve(filesRoot);
    while (d.startsWith(root + path.sep)) {
      try {
        if (fs.readdirSync(d).length) break;
        fs.rmdirSync(d);
      } catch (_) { break; }
      d = path.dirname(d);
    }
  } catch (e) {
    totals.failed += 1;
    console.error(`失败：${p.from} → ${p.to}：${e.message}`);
  }
}
console.log(`\n完成：已搬迁 ${moved} 个，失败 ${totals.failed} 个，跳过（缺失）${totals.missing} 个`);
