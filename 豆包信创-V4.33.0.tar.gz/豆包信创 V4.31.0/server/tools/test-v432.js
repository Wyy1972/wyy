/**
 * 制度五项 回归测试（豆包信创 V4.32.0）
 *
 * 用法：node server/tools/test-v432.js
 *
 * 覆盖：
 *   1. 保管期限表：播种齐、可增改删、同门类重名被拒、按门类+关键词能带出期限与依据
 *   2. 件级状态机：非法跳转被拒、按流程推进留痕、终态不可再流转
 *   3. 四性证据链：完整性实测真算 SHA-256 并与登记值比对、四类覆盖/缺失能算出来
 *   4. 件级授权：超密级的读者看不到 → 授权后能看 → 撤销后即刻失效，且放行写审计
 *   5. 利用登记：查详情与下载自动记账
 *   6. 管理驾驶舱：总量、七项著录完成度、风险清单可算
 */
'use strict';

const path = require('node:path');
const fs = require('node:fs');
const net = require('node:net');
const { spawn } = require('node:child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const TEST_DATA = path.join(APP_ROOT, '.regress-v432-data');
const ADMIN_PWD = 'Archive@2026v';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeSession(base) {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(base + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json, jar };
}

async function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(0));
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); });
  });
}

async function waitPing(base, ms = 25000) {
  const until = Date.now() + ms;
  for (;;) {
    try {
      const r = await fetch(base + '/api/ping');
      const t = await r.text();
      if (t.includes('在运行')) return true;
    } catch (_) { /* 还没起来 */ }
    if (Date.now() > until) return false;
    await sleep(200);
  }
}

function removeDirDeep(dir) {
  if (!fs.existsSync(dir)) return;
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* 兜底 */ }
}

async function main() {
  removeDirDeep(TEST_DATA);
  const port = await freePort();
  const BASE = 'http://127.0.0.1:' + port;
  const srv = spawn(process.execPath, [
    path.join(APP_ROOT, 'server', 'server.js'),
    '--data', TEST_DATA, '--port', String(port), '--no-qr', '--no-scheduler', '--quiet',
  ], { cwd: APP_ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  srv.stdout.on('data', (d) => { out += d; });
  srv.stderr.on('data', (d) => { out += d; });

  const admin = makeSession(BASE);
  const reader = makeSession(BASE);
  let archId = 0, archSecretId = 0, readerId = 0;

  try {
    if (!await waitPing(BASE)) throw new Error('服务没能启动：\n' + out.slice(-1500));

    section('准备');
    const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
    check('管理员可登录', login.status === 200 && login.body.ok, 'HTTP ' + login.status);
    if (!login.body.ok) throw new Error('前置失败：管理员登录不了');
    await admin.json('/api/me/password', { method: 'POST', json: { oldPassword: 'admin123', newPassword: ADMIN_PWD } });

    const cats = await admin.json('/api/categories');
    const flat = ((cats.body.data || {}).flat) || [];
    const cat = flat.find((c) => String(c.code || '') === 'WS-XZ') || flat[flat.length - 1];

    section('保管期限表');
    const sched = await admin.json('/api/retention/schedule');
    check('保管期限表接口可用', sched.status === 200 && sched.body.ok);
    const sList = (sched.body.data || {}).list || [];
    const sTypes = (sched.body.data || {}).types || [];
    check('门类已各播一条默认期限', sList.length >= sTypes.length && sTypes.length >= 5,
      `条目 ${sList.length} / 门类 ${sTypes.length}`);
    check('播种行带依据（8 号令）', sList.some((x) => /8号|国家档案局令/.test(String(x.basis || ''))));
    check('期限取值合法', sList.every((x) => ['永久', '长期', '定期30年', '定期10年', '定期5年'].includes(x.retention)),
      sList.map((x) => x.retention).join(','));
    const tempItem = '回归测试事项' + Math.random().toString(36).slice(2, 6);
    const add = await admin.json('/api/retention/schedule', {
      method: 'POST', json: { type_code: 'WS', item: tempItem, retention: '定期10年', basis: '回归自建' },
    });
    const addId = Number((add.body.data || {}).id || 0);
    check('新增条目成功', add.status === 200 && addId > 0, JSON.stringify(add.body).slice(0, 140));
    const dup = await admin.json('/api/retention/schedule', {
      method: 'POST', json: { type_code: 'WS', item: tempItem, retention: '永久' },
    });
    check('同门类重名被拒（409）', dup.status === 409, 'HTTP ' + dup.status);
    const sug = await admin.json('/api/retention/suggest?type_code=WS&kw=' + encodeURIComponent('回归测试事项'));
    check('按门类+关键词能查表并带出建议',
      sug.status === 200 && (sug.body.data || {}).suggested
      && (sug.body.data || {}).suggested.retention === '定期10年',
      JSON.stringify((sug.body.data || {}).suggested || {}).slice(0, 140));
    const upd = await admin.json('/api/retention/schedule/' + addId, {
      method: 'PUT', json: { type_code: 'WS', item: tempItem, retention: '永久', basis: '改为永久', status: '停用' },
    });
    check('条目可改（期限与状态一起改）', upd.status === 200 && upd.body.ok);

    section('件级状态机');
    const created = await admin.json('/api/archives', {
      method: 'POST', json: { title: '状态机回归件', category_id: cat && cat.id, type_code: 'WS', year: '2026', pages: '2' },
    });
    archId = Number((created.body.data || {}).id || 0);
    check('建档案成功', created.status === 200 && archId > 0, JSON.stringify(created.body).slice(0, 140));
    const tr0 = await admin.json('/api/archives/' + archId + '/transitions');
    check('流转接口可用', tr0.status === 200 && tr0.body.ok);
    const bad = await admin.json('/api/archives/' + archId + '/transition', { method: 'POST', json: { to: '上架' } });
    check('非法跳转被拒（不能一步到上架）', bad.status === 400 && /不允许|可走/.test(bad.body.error || ''),
      'HTTP ' + bad.status + ' ' + (bad.body.error || ''));
    const step = await admin.json('/api/archives/' + archId + '/transition', {
      method: 'POST', json: { to: '整理', reason: '回归：整理完毕' },
    });
    check('按流程流转成功（→整理）', step.status === 200 && step.body.ok, JSON.stringify(step.body).slice(0, 140));
    const tr1 = await admin.json('/api/archives/' + archId + '/transitions');
    const td = tr1.body.data || {};
    check('当前节点已更新', td.current === '整理', String(td.current));
    check('下一步给出合法选项', Array.isArray(td.next) && td.next.includes('著录'), JSON.stringify(td.next));
    check('流转留痕（含原因与经办人）',
      (td.list || []).some((x) => x.to_state === '整理' && String(x.reason || '').includes('回归') && String(x.by_name || '').length),
      JSON.stringify((td.list || [])[0] || {}).slice(0, 140));

    section('四性证据链');
    const fd = new FormData();
    fd.append('files', new Blob(['v432 fixity probe\n'], { type: 'text/plain' }), 'fixity.txt');
    const up = await admin.req('/api/archives/' + archId + '/files', { method: 'POST', body: fd });
    const upBody = await up.text();
    check('附件上传成功', up.status === 200 && /"ok":true/.test(upBody), 'HTTP ' + up.status + ' ' + upBody.slice(0, 140));
    const ev1 = await admin.json('/api/archives/' + archId + '/evidence', { method: 'POST', json: { aspect: '完整性' } });
    const ev1d = ev1.body.data || {};
    check('完整性实测给出结论', ev1.status === 200 && ev1.body.ok);
    check('完整性结论=通过（哈希与登记值一致）', ev1d.result === '通过', String(ev1d.result));
    check('完整性证据是真哈希（64 位十六进制）', /^[0-9a-f]{64}$/.test(String(ev1d.value || '')),
      String(ev1d.value || '').slice(0, 20));
    check('方法写明 SHA-256', /SHA-256/.test(String(ev1d.method || '')), String(ev1d.method));
    await admin.json('/api/archives/' + archId + '/evidence', {
      method: 'POST', json: { aspect: '安全性', method: '权限校验', value: '越权访问被拒', result: '通过' },
    });
    const evList = await admin.json('/api/archives/' + archId + '/evidence');
    const ed = evList.body.data || {};
    check('证据可查且按类别聚合', (ed.list || []).length >= 2, '条数 ' + (ed.list || []).length);
    check('缺失类别能算出来（真实性/可用性还空着）',
      Array.isArray(ed.missing) && ed.missing.includes('真实性') && ed.missing.includes('可用性'),
      JSON.stringify(ed.missing));
    const evSum = await admin.json('/api/evidence/summary');
    check('四性汇总可用（覆盖件数 ≤ 总量）', evSum.status === 200 && evSum.body.ok
      && Number((evSum.body.data || {}).covered || 0) >= 1, JSON.stringify((evSum.body.data || {})).slice(0, 120));

    section('件级授权（密级 × 部门 × 件级）');
    const mkUser = await admin.json('/api/users', {
      method: 'POST', json: { username: 'v432reader', password: 'Reader@2026x', display_name: '回归读者', role: 'reader', department: '综合组' },
    });
    readerId = Number((mkUser.body.data || {}).id || 0);
    check('建读者账号成功', mkUser.status === 200, JSON.stringify(mkUser.body).slice(0, 160));
    const rl = await reader.json('/api/login', { method: 'POST', json: { username: 'v432reader', password: 'Reader@2026x' } });
    // 新账号带 must_change=1：登录本身能过，但后续接口会被拦住，必须先改口令
    await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Reader@2026x', newPassword: 'Reader@2026y' } });
    await reader.json('/api/login', { method: 'POST', json: { username: 'v432reader', password: 'Reader@2026y' } });
    const rl2 = await reader.json('/api/me');
    check('读者已登录', rl2.status === 200 && rl2.body.ok, 'HTTP ' + rl2.status);

    const made = await admin.json('/api/archives', {
      method: 'POST', json: { title: '机密回归件', category_id: cat && cat.id, type_code: 'WS', year: '2026',
        pages: '1', secret_level: '机密', secret_term: '10年', department: '档案室' },
    });
    archSecretId = Number((made.body.data || {}).id || 0);
    check('建一件“机密”档案', made.status === 200 && archSecretId > 0, JSON.stringify(made.body).slice(0, 160));
    const rBefore = await reader.json('/api/archives/' + archSecretId);
    check('读者按密级看不到（统一 404，不泄露存在性）', rBefore.status === 404, 'HTTP ' + rBefore.status);
    const g1 = await admin.json('/api/archives/' + archSecretId + '/grants', {
      method: 'POST', json: { user_id: readerId, reason: '回归：局长批示查阅', expires_at: '' },
    });
    check('授权成功', g1.status === 200 && g1.body.ok, JSON.stringify(g1.body).slice(0, 140));
    const rAfter = await reader.json('/api/archives/' + archSecretId);
    check('授权后读者能查到这一件', rAfter.status === 200 && rAfter.body.ok,
      'HTTP ' + rAfter.status + ' ' + (rAfter.body.error || ''));
    const rOther = await reader.json('/api/archives/' + archId);
    check('授权不外溢：同库其它件仍按密级判定', rOther.status === 200, 'HTTP ' + rOther.status);
    const gl = await admin.json('/api/archive-grants');
    const grantRow = ((gl.body.data || {}).list || []).find((x) => Number(x.archive_id) === archSecretId
      && Number(x.user_id) === readerId) || {};
    check('授权进台账（含档案/账号/理由）', !!grantRow.id && /批示/.test(String(grantRow.reason || '')),
      JSON.stringify(grantRow).slice(0, 160));
    const alogs = await admin.json('/api/logs?size=30&action=' + encodeURIComponent('件级授权放行'));
    check('凭授权查阅写了审计', (((alogs.body.data || {}).list) || []).some((l) => String(l.action || '').includes('件级授权放行')),
      '日志条数 ' + (((alogs.body.data || {}).list) || []).length);
    const rev = await admin.json('/api/archives/' + archSecretId + '/grants/' + Number(grantRow.id), { method: 'DELETE' });
    check('撤销授权成功', rev.status === 200 && rev.body.ok, JSON.stringify(rev.body).slice(0, 120));
    const rRevoked = await reader.json('/api/archives/' + archSecretId);
    check('撤销后立刻恢复不可见', rRevoked.status === 404, 'HTTP ' + rRevoked.status);

    section('利用登记');
    await admin.json('/api/archives/' + archId);
    const ur = await admin.json('/api/usage-registry?limit=20');
    const ud = ur.body.data || {};
    check('利用登记接口可用', ur.status === 200 && ur.body.ok);
    check('查详情已自动记账（查阅）', (ud.list || []).some((x) => Number(x.archive_id) === archId && x.action === '查阅'),
      JSON.stringify((ud.list || [])[0] || {}).slice(0, 140));
    check('登记含使用人与时间', (ud.list || []).every((x) => String(x.username || '').length && String(x.at || '').length));
    const urKw = await admin.json('/api/usage-registry?kw=' + encodeURIComponent('状态机回归件'));
    check('按关键词能筛出台账', (((urKw.body.data || {}).list) || []).some((x) => Number(x.archive_id) === archId));

    section('管理驾驶舱');
    const cp = await admin.json('/api/cockpit');
    const cd = cp.body.data || {};
    check('驾驶舱接口可用', cp.status === 200 && cp.body.ok);
    check('总量 ≥ 2', Number(cd.total) >= 2, 'total=' + cd.total);
    check('七项著录完成度都算出来了', (cd.progress || []).length === 7,
      JSON.stringify((cd.progress || []).map((p) => p.label)));
    check('完成度是 0–100 的百分比', (cd.progress || []).every((p) => p.ratio >= 0 && p.ratio <= 100));
    check('风险清单是数组（含未做四性取证）', Array.isArray(cd.risks) && cd.risks.some((r) => /四性取证/.test(String(r.kind))),
      JSON.stringify((cd.risks || []).map((r) => r.kind)));
    check('按门类/年度/期限/进度四个维度都有数', ['byType', 'byYear', 'byRetention', 'byLifecycle'].every((k) => Array.isArray(cd[k])));
    check('含附件件数与电子件数', Number(cd.withFiles) >= 1, 'withFiles=' + cd.withFiles);
  } catch (e) {
    failed += 1;
    fails.push('异常中断：' + (e && e.message));
    console.log('\n  ✗ 套件异常中断：' + (e && e.stack ? e.stack : e));
  } finally {
    try { srv.kill(); } catch (_) {}
    await sleep(400);
    removeDirDeep(TEST_DATA);
  }

  console.log(`\n${failed === 0 ? '全部通过' : '存在失败'}：通过 ${pass} 项，失败 ${failed} 项`);
  if (fails.length) { console.log('失败清单：'); fails.forEach((f) => console.log('  - ' + f)); }
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((e) => { console.error(e && e.stack ? e.stack : e); process.exit(1); });
