/**
 * 高级检索表达式（v4.7.0）验证
 *
 * 这个套件盯的是四类事：
 *   ① **解析器本身**：语法、优先级、运算符语义、报错位置 —— 纯函数，直接 require 进来测；
 *   ② **口径一致**：同一条条件，走表单参数和走表达式，**必须返回同一批档案**。
 *      这是"字段定义只有一份"这个设计的验收点；两边一旦漂移，这里立刻红；
 *   ③ **密级不变量**：表达式无论怎么写都不能扩大可读范围
 *      （写 secret:机密 而权限不够时，结果只能是空，不能是漏）；
 *   ④ **所有出口一致**：列表 / 导出 CSV / 打印 / 批量修改 走的是同一个 buildFilters，
 *      表达式在四个出口都必须同样生效、同样报 400。
 */
'use strict';

const qx = require('../lib/query-expr');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');
const enc = encodeURIComponent;
const same = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
const subset = (a, b) => a.every((v) => b.includes(v));

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'QX' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const anon = makeSession();

  // =========================================================================
  section('一、解析器（纯函数）');
  // =========================================================================
  const ok = (src, name, extra) => {
    try { const c = qx.compile(src); check(name || src, true); return c; }
    catch (e) { check(name || src, false, e.message); return null; }
  };
  const bad = (src, name, wantWord) => {
    try { qx.compile(src); check(name || src, false, '竟然通过了'); }
    catch (e) {
      const okPos = typeof e.position === 'number' && e.position >= 0 && e.position <= src.length;
      const okCode = e.statusCode === 400;
      const hitWord = !wantWord || String(e.message).includes(wantWord);
      check(name || src, okCode && okPos && hitWord, `statusCode=${e.statusCode} pos=${e.position} msg=${e.message}`);
    }
  };

  const c1 = ok('门类:WS', '中文别名可用（门类）');
  check('  中文别名映射到 type_code', c1 && c1.sql.includes('a.type_code'), c1 && c1.sql);
  check('  取值走占位符绑定（不是拼字符串）', c1 && c1.params.length === 1 && c1.params[0] === '%WS%', JSON.stringify(c1 && c1.params));

  const c2 = ok('type:WS AND year>=2020');
  check('  AND + 数字比较生成 CAST 比较', c2 && c2.sql.includes('CAST(a.year AS INTEGER) >='), c2 && c2.sql);
  check('  数字比较绑定的是数字而不是字符串', c2 && c2.params[1] === 2020, JSON.stringify(c2 && c2.params));

  const c3 = ok('type:WS year:2026', '隐式 AND（相邻条件不用写 AND）');
  check('  隐式 AND 等价于显式 AND',
    c3 && c1 && (() => { const a = qx.compile('type:WS AND year:2026'); return c3.sql === a.sql && same(c3.params, a.params); })());

  const c4 = ok('!type:WS AND NOT type:HT', '! 与 NOT 都表示取反');
  check('  NOT 生成 (NOT (...))', c4 && c4.sql.includes('(NOT ('), c4 && c4.sql);

  const c5 = ok('type:WS OR type:HT AND year:2026');
  const c5b = qx.compile('type:WS OR (type:HT AND year:2026)');
  check('  优先级：AND 紧于 OR（a OR b AND c 等于 a OR (b AND c)）',
    c5 && c5.sql === c5b.sql, c5 && c5.sql);

  const c6 = ok('(type:WS OR type:HT) AND year:2026', '括号可改变优先级');
  check('  括号确实改变了结构', c6 && c5 && c6.sql !== c5.sql);

  const c7 = ok('retention:[永久,30年]');
  check('  列表生成 IN (?,?)', c7 && c7.sql.includes('IN (?,?)'), c7 && c7.sql);
  const c7b = qx.compile('retention!=[永久,30年]');
  check('  列表配 != 生成 NOT IN', c7b.sql.includes('NOT IN'), c7b.sql);

  const c8 = ok('title:"年度 检查"', '双引号短语（含空格）');
  check('  短语整体作为一个值', c8 && c8.params[0] === '%年度 检查%', JSON.stringify(c8 && c8.params));

  const c9 = ok('title~检查', '~ 与 : 同义（包含）');
  check('  ~ 生成 LIKE', c9 && c9.sql.includes('LIKE'), c9 && c9.sql);

  const c10 = ok('hasfile:是', '附件支持"是/有"');
  check('  生成 EXISTS', c10 && c10.sql.includes('EXISTS'), c10 && c10.sql);
  const c10b = qx.compile('hasfile:无');
  check('  生成 NOT EXISTS', c10b.sql.includes('NOT EXISTS'), c10b.sql);

  const c11 = ok('category:3', '分类可用数字 id');
  check('  含下级分类（与表单口径一致）', c11 && c11.sql.includes('parent_id'), c11 && c11.sql);

  const c12 = ok('随便一个词', '裸词当关键词');
  check('  裸词走的是与表单 kw 完全相同的子句', c12 && c12.sql.includes('archives_fts MATCH'), c12 && c12.sql);
  // v4.12.0：裸词子句 = 档案行 7 路（6 LIKE + 1 FTS） + 附件正文 2 路（LIKE + FTS）
  // （纯 ASCII 词还会再多 2 路拼音；这里用的是中文词，所以是 9）
  check('  裸词参数 9 个（档案行 7 路 + 附件正文 2 路）', c12 && c12.params.length === 9,
    String(c12 && c12.params.length));
  check('  裸词也检索附件正文（v4.12.0 统一检索框）',
    c12 && c12.sql.includes('file_text') && c12.sql.includes('file_text_fts'), c12 && c12.sql);
  const c12b = ok('wsgl', '纯 ASCII 裸词');
  check('  纯 ASCII 裸词再多 2 路拼音 → 11 个参数', c12b && c12b.params.length === 11,
    String(c12b && c12b.params.length));

  const c13 = ok('title:"a\\"b"', '引号内可用反斜杠转义');
  check('  转义后的引号进了取值', c13 && c13.params[0] === '%a"b%', JSON.stringify(c13 && c13.params));

  check('LIKE 特殊字符被转义（% _ \\）',
    qx.likeParam('100%_x\\y') === '%100\\%\\_x\\\\y%', qx.likeParam('100%_x\\y'));

  // ---- 报错与位置 ----
  bad('nosuchfield:x', '未知字段被拒（400）', '不认识的字段');
  bad('year>=abc', '数字字段给了非数字被拒', '不是数字');
  bad('date>=昨天', '日期格式不对被拒', '日期');
  bad('type:', '运算符后缺值被拒', '缺少值');
  bad('(type:WS', '括号未闭合被拒', '括号');
  bad('type:WS)', '多余右括号被拒', '多出来');
  bad('type:WS AND', '末尾悬空 AND 被拒', '还缺一个条件');
  bad('type:[1,2', '列表未闭合被拒', '列表');
  bad('type>WS', '文本字段不支持大小比较被拒', '不支持大小比较');
  bad('hasfile:也许', '附件取值非法被拒', '附件');
  bad('', '空表达式被拒', '空');
  bad('   ', '全空白被拒', '空');
  bad('title:' + 'x'.repeat(600), '超长被拒', '太长');
  bad('('.repeat(12) + 'type:WS' + ')'.repeat(12), '括号过深被拒', '嵌套太深');

  // 位置要真的指到出错的地方，而不是永远 0
  const posOf = (src) => { try { qx.compile(src); return -1; } catch (e) { return e.position; } };
  check('位置指向出错的值：year>=abc → 6', posOf('year>=abc') === 6, String(posOf('year>=abc')));
  check('位置指向出错的值：hasfile:也许 → 8', posOf('hasfile:也许') === 8, String(posOf('hasfile:也许')));
  check('位置指向未知字段本身：xxx:1 → 0', posOf('xxx:1') === 0, String(posOf('xxx:1')));
  check('位置指向多余的那个字符：type:WS) → 7', posOf('type:WS)') === 7, String(posOf('type:WS)')));
  check('validate 对合法表达式返回 true', qx.validate('type:WS') === true);

  // =========================================================================
  section('二、准备与字段表接口');
  // =========================================================================
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  check('未登录不能用表达式检索（401）', (await anon.json('/api/archives?expr=' + enc('type:WS'))).status === 401);
  check('未登录不能读字段表（401）', (await anon.json('/api/archives/query-fields')).status === 401);

  const qf = await admin.json('/api/archives/query-fields');
  check('字段表可取', qf.status === 200 && qf.body.ok && Array.isArray(qf.body.data.fields), String(qf.status));
  const serverFields = (qf.body.data.fields || []).map((f) => f.name).sort();
  const localFields = Object.keys(qx.FIELDS).sort();
  check('字段表与服务端注册表完全一致（前端不另抄一份）', same(serverFields, localFields),
    `server=${serverFields.length} local=${localFields.length}`);
  check('字段表带上了 compare / list 能力标注',
    (qf.body.data.fields || []).every((f) => typeof f.compare === 'boolean' && typeof f.list === 'boolean'));
  check('字段表暴露了长度上限', qf.body.data.limits && qf.body.data.limits.MAX_LEN === qx.LIMITS.MAX_LEN,
    JSON.stringify(qf.body.data.limits));

  // 造一条本套件专用的档案，避免依赖演示数据的具体内容
  const cats = await admin.json('/api/categories');
  const flat = (cats.body.data && cats.body.data.flat) || [];
  const types = await admin.json('/api/types');
  const typeList = (types.body.data && (types.body.data.list || types.body.data)) || [];
  const wsCat = flat.find((c) => (c.type_code === 'WS' || c.code === 'WS')) || flat[0];
  const wsType = typeList.find((t) => (t.code === 'WS')) || typeList[0];
  check('拿到了分类与门类（建档案用）', !!wsCat && !!wsType,
    `cat=${wsCat && wsCat.id} type=${wsType && wsType.code}`);

  const TITLE = '表达式测试档案' + TAG;
  const mk = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: wsType.code, category_id: wsCat.id, title: TITLE,
      year: '2031', retention: '永久', department: '表达式测试部门' + TAG,
      responsible: '表达式测试责任者', keywords: '表达式关键词' + TAG,
    },
  });
  check('创建测试档案成功', mk.status === 200 && mk.body.ok, JSON.stringify(mk.body).slice(0, 160));
  const madeId = mk.body.ok ? mk.body.data.id : 0;
  const madeCode = mk.body.ok ? (mk.body.data.archive_code || '') : '';
  // 规范档号：打印目录/归档章展示的是它，不是短档案号（v4.8.0 起出厂默认模板已含全部分段）
  const madeNumber = mk.body.ok ? (mk.body.data.archive_number || '') : '';
  check('拿到测试档案的档号', !!madeCode, madeCode);
  check('拿到了规范档号（打印/归档章用）', !!madeNumber, madeNumber);

  // =========================================================================
  section('三、接口集成：表达式真的在筛选');
  // =========================================================================
  async function ids(qs) {
    const r = await admin.json('/api/archives?size=200&' + qs);
    const list = (r.body && r.body.ok && r.body.data.list) || [];
    return { status: r.status, body: r.body, ids: list.map((x) => x.id).sort((a, b) => a - b), list };
  }

  const all = await ids('');
  check('全量列表可读', all.status === 200 && all.ids.length > 0, String(all.ids.length));

  const byExpr = await ids('expr=' + enc('code=' + madeCode));
  check('用表达式按档号精确命中测试档案', byExpr.ids.length === 1 && byExpr.ids[0] === madeId,
    JSON.stringify(byExpr.ids));
  check('命中的确实是那条', byExpr.list[0] && byExpr.list[0].title === TITLE, byExpr.list[0] && byExpr.list[0].title);

  const byContains = await ids('expr=' + enc('title:' + TAG));
  check('表达式按题名包含命中', byContains.ids.includes(madeId), JSON.stringify(byContains.ids));
  const exactTitle = await ids('expr=' + enc('title="' + TITLE + '"'));
  check('= 是精确（只命中题名完全相同的那条）', exactTitle.ids.length === 1 && exactTitle.ids[0] === madeId,
    JSON.stringify(exactTitle.ids));
  check('包含 ⊇ 精确（: 比 = 宽）', subset(exactTitle.ids, byContains.ids));

  const notTitle = await ids('expr=' + enc('NOT title:' + TAG));
  check('NOT 排除了命中项', !notTitle.ids.includes(madeId) && notTitle.ids.length === all.ids.length - 1,
    `${notTitle.ids.length} vs ${all.ids.length - 1}`);

  const orExpr = await ids('expr=' + enc('code=' + madeCode + ' OR title:' + TAG));
  check('OR 命中', orExpr.ids.includes(madeId));
  const andFalse = await ids('expr=' + enc('code=' + madeCode + ' AND year=1999'));
  check('AND 的另一个条件不成立时命中为空', andFalse.ids.length === 0, JSON.stringify(andFalse.ids));

  const yearCmp = await ids('expr=' + enc('year>=2031'));
  check('年度大小比较命中测试档案（2031）', yearCmp.ids.includes(madeId), JSON.stringify(yearCmp.ids));
  const yearCmp2 = await ids('expr=' + enc('year>2031'));
  check('年度 > 排除了它', !yearCmp2.ids.includes(madeId));

  const hasKw = await ids('expr=' + enc('表达式关键词' + TAG));
  const hasKwForm = await ids('kw=' + enc('表达式关键词' + TAG));
  check('裸词 == 表单关键词（同一子句，结果必须一模一样）', same(hasKw.ids, hasKwForm.ids),
    `${hasKw.ids.length} vs ${hasKwForm.ids.length}`);
  check('裸词确实命中了测试档案', hasKw.ids.includes(madeId));
  check('真·关键词单独也能命中（说明 FTS 那一路也在工作）', hasKwForm.ids.includes(madeId));

  // =========================================================================
  section('四、口径一致：表单参数 vs 等价表达式');
  // =========================================================================
  const pairs = [
    ['type', 'type=' + enc(wsType.code), 'expr=' + enc('type=' + wsType.code)],
    ['category', 'category=' + wsCat.id, 'expr=' + enc('category:' + wsCat.id)],
    ['year', 'year=2031', 'expr=' + enc('year:2031')],
    ['status', 'status=' + enc('在库'), 'expr=' + enc('status=在库')],
    ['retention', 'retention=' + enc('永久'), 'expr=' + enc('retention=永久')],
    ['secret', 'secret=' + enc('公开'), 'expr=' + enc('secret=公开')],
    ['hasFile', 'hasFile=1', 'expr=' + enc('hasfile:1')],
    ['hasFile', 'hasFile=0', 'expr=' + enc('hasfile:0')],
    ['department', 'department=' + enc('表达式测试部门' + TAG), 'expr=' + enc('department=表达式测试部门' + TAG)],
  ];
  for (const [label, formQs, exprQs] of pairs) {
    const a = await ids(formQs);
    const b = await ids(exprQs);
    check(`口径一致：${label}  表单 vs 表达式`, same(a.ids, b.ids), `表单${a.ids.length} 表达式${b.ids.length}`);
  }
  const df = await ids('dateFrom=2020-01-01&dateTo=2035-12-31');
  const de = await ids('expr=' + enc('date>=2020-01-01 AND date<=2035-12-31'));
  check('口径一致：归档日期区间  表单 vs 表达式', same(df.ids, de.ids), `表单${df.ids.length} 表达式${de.ids.length}`);

  // 表单条件与表达式混用：两者都要生效（AND）
  const mixed = await ids('type=' + enc(wsType.code) + '&expr=' + enc('code=' + madeCode));
  check('表单条件与表达式可以同时用（AND）', mixed.ids.length === 1 && mixed.ids[0] === madeId,
    JSON.stringify(mixed.ids));

  // =========================================================================
  section('五、密级不变量：表达式不能扩大可读范围');
  // =========================================================================
  const clkName = TAG.toLowerCase() + '_rd';
  const mkUser = await admin.json('/api/users', {
    method: 'POST',
    json: { username: clkName, display_name: '表达式权限测试', password: 'Test@12345', role: 'reader' },
  });
  check('创建低权限账号成功', mkUser.status === 200 && mkUser.body.ok, JSON.stringify(mkUser.body).slice(0, 160));
  const low = makeSession();
  await low.json('/api/login', { method: 'POST', json: { username: clkName, password: 'Test@12345' } });
  await low.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  async function lowIds(qs) {
    const r = await low.json('/api/archives?size=200&' + qs);
    const list = (r.body && r.body.ok && r.body.data.list) || [];
    return { status: r.status, ids: list.map((x) => x.id).sort((a, b) => a - b), list };
  }
  const lowAll = await lowIds('');
  check('低权限账号能读到一部分（不是全空，否则本项测不出东西）', lowAll.ids.length > 0, String(lowAll.ids.length));
  check('低权限账号看不到全部（密级过滤生效）', lowAll.ids.length <= all.ids.length, `${lowAll.ids.length}/${all.ids.length}`);

  const lowSecret = await lowIds('expr=' + enc('secret:机密'));
  check('低权限用表达式查「机密」是空的（不是漏）', lowSecret.ids.length === 0, JSON.stringify(lowSecret.ids));

  const lowWiden = await lowIds('expr=' + enc('secret:机密 OR title:档案'));
  check('试图用 OR 扩大范围也无效（结果仍在其可见范围内）', subset(lowWiden.ids, lowAll.ids),
    `越界 ${lowWiden.ids.filter((i) => !lowAll.ids.includes(i)).join(',')}`);
  check('该 OR 表达式仍能查到它本来就能看的那些', lowWiden.ids.length > 0, String(lowWiden.ids.length));

  const lowNot = await lowIds('expr=' + enc('NOT secret:公开'));
  check('NOT 也不能绕过密级过滤', subset(lowNot.ids, lowAll.ids),
    `越界 ${lowNot.ids.filter((i) => !lowAll.ids.includes(i)).join(',')}`);

  // =========================================================================
  section('六、400 边界：错误表达式在各出口都要给出位置');
  // =========================================================================
  const e1 = await admin.json('/api/archives?expr=' + enc('nosuchfield:x'));
  check('列表：未知字段 → 400', e1.status === 400, String(e1.status));
  check('列表：400 带 position', e1.body && typeof e1.body.position === 'number', JSON.stringify(e1.body));
  check('列表：400 是 ok:false 且有可读错误', e1.body && e1.body.ok === false && typeof e1.body.error === 'string',
    JSON.stringify(e1.body).slice(0, 160));
  check('列表：400 不返回任何数据', !(e1.body && e1.body.data), JSON.stringify(e1.body && e1.body.data));

  const e2 = await admin.req('/api/export/archives.csv?expr=' + enc('year>=abc'));
  check('导出 CSV：错误表达式 → 400', e2.status === 400, String(e2.status));
  const e3 = await admin.req('/api/print/catalog?expr=' + enc('(type:WS'));
  check('打印目录：错误表达式 → 400', e3.status === 400, String(e3.status));
  const e4 = await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { filter: { expr: 'type:WS AND' }, changes: { department: 'X' } },
  });
  check('批量修改：错误表达式 → 400', e4.status === 400, String(e4.status));

  // 合法表达式在其它出口要真的生效
  const csvFiltered = await admin.req('/api/export/archives.csv?expr=' + enc('code=' + madeCode));
  const csvText = await csvFiltered.text();
  check('导出 CSV：合法表达式 → 200', csvFiltered.status === 200, String(csvFiltered.status));
  check('导出 CSV：里含目标档号', csvText.includes(madeCode), csvText.slice(0, 120));
  const csvFull = await (await admin.req('/api/export/archives.csv')).text();
  check('导出 CSV：筛选后确实比全量少（表达式在导出出口也生效）',
    csvText.split('\n').length < csvFull.split('\n').length,
    `${csvText.split('\n').length} vs ${csvFull.split('\n').length}`);

  const pr = await admin.req('/api/print/catalog?expr=' + enc('code=' + madeCode));
  const prText = await pr.text();
  check('打印目录：合法表达式 → 200', pr.status === 200, String(pr.status));
  check('打印目录：页面上只有这一条（表达式生效）',
    prText.includes(madeNumber) || prText.includes(madeCode), prText.slice(0, 120));

  // 批量修改：用表达式定位到本套件造的那条，改完再改回来
  const bulk = await admin.json('/api/archives/bulk-update', {
    method: 'POST',
    json: { filter: { expr: 'code=' + madeCode }, changes: { department: '表达式批量改过' + TAG } },
  });
  check('批量修改：用表达式定位 → 200', bulk.status === 200 && bulk.body.ok, JSON.stringify(bulk.body).slice(0, 160));
  const after = await admin.json('/api/archives/' + madeId);
  check('批量修改：确实改到了目标档案',
    after.body.ok && after.body.data.department === '表达式批量改过' + TAG,
    after.body.ok && after.body.data.department);
  await admin.json('/api/archives/bulk-update', {
    method: 'POST', json: { ids: [madeId], changes: { department: '表达式测试部门' + TAG } },
  });
  const restored = await admin.json('/api/archives/' + madeId);
  check('批量修改：已恢复原值', restored.body.ok && restored.body.data.department === '表达式测试部门' + TAG,
    restored.body.ok && restored.body.data.department);

  // =========================================================================
  section('七、与"常用检索"配合');
  // =========================================================================
  const SNAME = '表达式常用检索' + TAG;
  const saveOk = await admin.json('/api/searches', {
    method: 'POST', json: { name: SNAME, query: { expr: 'type:WS AND year>=2031' }, note: '含表达式' },
  });
  check('可把表达式存进常用检索', saveOk.status === 200 && saveOk.body.ok, JSON.stringify(saveOk.body).slice(0, 160));
  const sid = saveOk.body.ok ? saveOk.body.data.id : 0;
  const useIt = await admin.json(`/api/searches/${sid}/use`, { method: 'POST', json: {} });
  check('调出来还是条件对象且 expr 原样保留',
    useIt.body.ok && useIt.body.data.query && useIt.body.data.query.expr === 'type:WS AND year>=2031',
    JSON.stringify(useIt.body.data && useIt.body.data.query));
  const replay = await ids('expr=' + enc(useIt.body.data.query.expr));
  check('调出来的表达式能直接查（存得下就查得了）', replay.status === 200, String(replay.status));

  const saveBad = await admin.json('/api/searches', {
    method: 'POST', json: { name: SNAME + '坏', query: { expr: 'nosuchfield:x' } },
  });
  check('保存时就拒绝语法错误的表达式（400）', saveBad.status === 400, String(saveBad.status));
  check('保存时报错说明了原因', saveBad.body && String(saveBad.body.error).includes('不认识的字段'),
    JSON.stringify(saveBad.body).slice(0, 160));

  const saveLong = await admin.json('/api/searches', {
    method: 'POST', json: { name: SNAME + '长', query: { expr: 'title:' + 'x'.repeat(qx.LIMITS.MAX_LEN + 50) } },
  });
  check('保存时拒绝超长表达式（400）', saveLong.status === 400, String(saveLong.status));

  const saveNormalLong = await admin.json('/api/searches', {
    method: 'POST', json: { name: SNAME + '普通长', query: { kw: 'x'.repeat(201) } },
  });
  check('普通条件仍是 200 字上限（没被表达式放宽）', saveNormalLong.status === 400, String(saveNormalLong.status));

  // =========================================================================
  section('八、收尾');
  // =========================================================================
  if (sid) await admin.json(`/api/searches/${sid}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('清理：常用检索已删除', !((await admin.json('/api/searches')).body.data.list || []).some((s) => s.id === sid));
  if (madeId) await admin.json(`/api/archives/${madeId}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('清理：测试档案已删除', (await admin.json(`/api/archives/${madeId}`)).status === 404);
  if (mkUser.body.ok) await admin.json('/api/users/' + mkUser.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const leftovers = await ids('expr=' + enc('title:' + TAG));
  check('清理：没有残留测试数据', leftovers.ids.length === 0, JSON.stringify(leftovers.ids));

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
