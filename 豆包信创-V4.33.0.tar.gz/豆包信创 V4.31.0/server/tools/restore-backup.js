﻿/**
 * 整库恢复（停服执行）
 *
 * 用法：
 *   node server/tools/restore-backup.js --backup <备份包.zip>            # 交互确认
 *   node server/tools/restore-backup.js --backup <备份包.zip> --yes      # 不确认
 *   node server/tools/restore-backup.js --backup <备份包.zip> --data <数据目录>
 *   node server/tools/restore-backup.js --list                           # 列出本机已有备份包
 *
 * 为什么做成命令行、且要求先停服：
 *   整库恢复要把正在使用的数据库文件换掉。运行中的进程握着文件句柄、还有 WAL/SHM 残留，
 *   在进程内直接换文件，轻则读到半截数据、重则库被写坏。业界的做法都是"停服务 → 换文件 → 起服务"，
 *   所以这里不去赌运行中换库，而是把它做成一个维护动作：先把现在的数据整份挪到
 *   data/_restore-bak-<时间>/ 作为回滚点，再落新库，失败自动回滚。
 *
 * 安全约束：
 *   - 默认检测端口，服务还在跑就直接拒绝（要强行执行加 --force，风险自负）
 *   - 备份包先验摘要/结构/库可读，任何一项不过都不动生产数据
 *   - 恢复结果写一条 backup_drills 台账（mode=实际恢复）并写审计日志
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const { DatabaseSync } = require('node:sqlite');

const ROOT = path.resolve(__dirname, '..', '..');
const { readZipEntries } = require(path.join(ROOT, 'server', 'lib', 'text-extract'));
const { openDatabase } = require(path.join(ROOT, 'server', 'db'));
const audit = require(path.join(ROOT, 'server', 'lib', 'audit'));

function arg(name, dflt) {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === '--' + name) return argv[i + 1] === undefined ? true : argv[i + 1];
    if (a.startsWith('--' + name + '=')) return a.slice(name.length + 3);
  }
  return dflt;
}

function hasFlag(name) {
  return process.argv.slice(2).some((a) => a === '--' + name);
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function human(bytes) {
  const n = Number(bytes || 0);
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}

function readConfig() {
  const p = path.join(ROOT, 'config.json');
  if (!fs.existsSync(p)) return {};
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (_) { return {}; }
}

/** 递归拷贝目录
 *  实测：Node 22 的 fs.cpSync 在 Windows 中文路径的深层目录上会触发进程级崩溃
 *  （STATUS_STACK_BUFFER_OVERRUN，退出码 0xC0000409）。恢复这种关键时刻不能赌它，
 *  所以按 readdir + copyFileSync 自己逐层拷，路径完全可控。 */
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  let items = [];
  try { items = fs.readdirSync(src, { withFileTypes: true }); } catch (_) { return; }
  for (const it of items) {
    const s = path.join(src, it.name);
    const d = path.join(dst, it.name);
    if (it.isDirectory()) copyDir(s, d);
    else if (it.isFile()) fs.copyFileSync(s, d);
  }
}

function dirSize(p) {
  let total = 0;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
    for (const it of items) {
      const f = path.join(d, it.name);
      if (it.isDirectory()) walk(f);
      else { try { total += fs.statSync(f).size; } catch (_) {} }
    }
  };
  walk(p);
  return total;
}

/** 端口探活：判断服务是不是还在跑 */
function portOpen(host, port, timeout = 1200) {
  return new Promise((resolve) => {
    const sock = net.connect({ host, port });
    const done = (v) => { try { sock.destroy(); } catch (_) {} resolve(v); };
    sock.setTimeout(timeout);
    sock.once('connect', () => done(true));
    sock.once('timeout', () => done(false));
    sock.once('error', () => done(false));
  });
}

function verifyPackage(zipPath, dataDir) {
  const problems = [];
  if (!fs.existsSync(zipPath)) return { problems: ['备份包不存在：' + zipPath] };
  let buf;
  try { buf = fs.readFileSync(zipPath); } catch (e) { return { problems: ['读取失败：' + e.message] }; }
  let entries;
  try { entries = readZipEntries(buf); } catch (e) { return { problems: ['不是可读的 ZIP：' + e.message] }; }
  const dbBuf = entries.get('db/archive.db');
  if (!dbBuf) problems.push('包内缺少 db/archive.db');
  let manifest = null;
  const mBuf = entries.get('manifest.json');
  if (mBuf) { try { manifest = JSON.parse(mBuf.toString('utf8')); } catch (_) { problems.push('manifest.json 无法解析'); } }
  if (problems.length) return { problems, entries, manifest, buf };

  const tmp = path.join(dataDir, 'tmp', `.restore-check-${stamp()}.db`);
  try { fs.mkdirSync(path.dirname(tmp), { recursive: true }); } catch (_) {}
  fs.writeFileSync(tmp, dbBuf);
  let counts = null;
  let chain = { ok: false, reason: '未校验' };
  try {
    const tdb = new DatabaseSync(tmp, { readOnly: true });
    const cnt = (sql) => { try { return Number((tdb.prepare(sql).get() || { c: 0 }).c || 0); } catch (_) { return -1; } };
    counts = {
      archives: cnt('SELECT COUNT(*) c FROM archives'),
      files: cnt('SELECT COUNT(*) c FROM files'),
      users: cnt('SELECT COUNT(*) c FROM users'),
      logs: cnt('SELECT COUNT(*) c FROM logs'),
    };
    try {
      const rows = tdb.prepare('SELECT id,prev_hash,at,user_id,username,action,target,detail,ip,step,result,category,hash FROM logs ORDER BY id ASC').all();
      chain = audit.verifyChain(rows);
    } catch (e) { chain = { ok: false, reason: '读日志失败：' + e.message }; }
    tdb.close();
  } catch (e) {
    problems.push('包内数据库打不开：' + e.message);
  } finally {
    try { fs.unlinkSync(tmp); } catch (_) {}
  }
  return { problems, entries, manifest, buf, counts, chain };
}

function listBackups(dataDir) {
  const dir = path.join(dataDir, 'backups');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((f) => /\.zip$/i.test(f))
    .map((f) => {
      const p = path.join(dir, f);
      return { name: f, path: p, size: fs.statSync(p).size, mtime: fs.statSync(p).mtime };
    })
    .sort((a, b) => b.mtime - a.mtime);
}

async function main() {
  const cfg = readConfig();
  const dataDir = path.resolve(String(arg('data', cfg.dataDir || path.join(ROOT, 'data'))));
  const host = '127.0.0.1';
  const port = Number(arg('port', cfg.port || 8787));

  if (hasFlag('list')) {
    const list = listBackups(dataDir);
    console.log(`数据目录：${dataDir}`);
    if (!list.length) console.log('（该数据目录下还没有备份包，通常在 data/backups/）');
    list.forEach((b) => console.log(`  ${b.name}  ${human(b.size)}  ${b.mtime.toLocaleString('zh-CN')}`));
    return 0;
  }

  let zipPath = String(arg('backup', '') || '');
  if (!zipPath) {
    const list = listBackups(dataDir);
    if (!list.length) {
      console.error('请用 --backup <备份包路径> 指定要恢复的备份包（可先 --list 查看）');
      return 1;
    }
    zipPath = list[0].path;
    console.log(`未指定 --backup，自动选用最新的：${list[0].name}`);
  }
  zipPath = path.resolve(zipPath);

  console.log('== 整库恢复（停服执行） ==');
  console.log(`数据目录：${dataDir}`);
  console.log(`备份包　：${zipPath}（${human(fs.statSync(zipPath).size)}）`);

  const running = await portOpen(host, port);
  if (running && !hasFlag('force')) {
    console.error(`\n端口 ${port} 还在监听 —— 服务仍在运行，不能直接替换数据库。`);
    console.error('请先停止服务（后台启动的用「停止后台服务.bat」，Linux 用 systemctl stop），再执行本命令。');
    console.error('确实要在服务运行状态下强行恢复，加 --force（不推荐，可能出现并发写入冲突）。');
    return 2;
  }

  console.log('\n1) 校验备份包…');
  const pkg = verifyPackage(zipPath, dataDir);
  if (pkg.problems.length) {
    console.error('   校验未通过，未改动任何生产数据：\n   - ' + pkg.problems.join('\n   - '));
    return 3;
  }
  console.log(`   包内条目 ${pkg.entries.size} 个；档案 ${pkg.counts.archives} 条、附件 ${pkg.counts.files} 个、用户 ${pkg.counts.users} 个、日志 ${pkg.counts.logs} 条`);
  console.log(`   日志哈希链：${pkg.chain.ok ? '完整' : '异常（' + (pkg.chain.reason || '') + '）'}`);
  if (pkg.manifest) {
    const m = pkg.manifest;
    const no = m.backup_no || m.backupNo || '';
    if (no) console.log(`   清单登记：${no}${m.created_at ? '，制作于 ' + m.created_at : ''}`);
  }

  if (!hasFlag('yes')) {
    console.log('\n即将执行：把当前 库 + 附件 整份备份到 data/_restore-bak- 下，再用包内容覆盖。');
    console.log('确认无误请加 --yes 重新执行（本命令不做交互，避免脚本化时挂住）。');
    return 4;
  }

  const dbFile = path.join(dataDir, 'archive.db');
  const altDb = path.join(dataDir, 'db', 'archive.db');   // 兼容 db/ 子目录布局
  const realDb = fs.existsSync(dbFile) ? dbFile : altDb;
  const filesDir = path.join(dataDir, 'files');
  const bakDir = path.join(dataDir, `_restore-bak-${stamp()}`);

  console.log('\n2) 建立回滚点…');
  fs.mkdirSync(bakDir, { recursive: true });
  if (fs.existsSync(realDb)) {
    fs.copyFileSync(realDb, path.join(bakDir, 'archive.db'));
    for (const suf of ['-wal', '-shm']) {
      const f = realDb + suf;
      if (fs.existsSync(f)) fs.copyFileSync(f, path.join(bakDir, 'archive.db' + suf));
    }
  }
  if (fs.existsSync(filesDir)) { copyDir(filesDir, path.join(bakDir, 'files')); }
  console.log(`   已备份到 ${bakDir}（${human(dirSize(bakDir))}）`);

  const rollback = (why) => {
    console.error('\n恢复失败：' + why);
    console.error('   正在回滚…');
    try {
      if (fs.existsSync(path.join(bakDir, 'archive.db'))) fs.copyFileSync(path.join(bakDir, 'archive.db'), realDb);
      for (const suf of ['-wal', '-shm']) { try { fs.unlinkSync(realDb + suf); } catch (_) {} }
      if (fs.existsSync(path.join(bakDir, 'files'))) {
        fs.rmSync(filesDir, { recursive: true, force: true });
        copyDir(path.join(bakDir, 'files'), filesDir);
      }
      console.error('   已回到恢复前的状态。');
    } catch (e) {
      console.error('   回滚也失败了：' + e.message + ' —— 请手工用 ' + bakDir + ' 里的 archive.db 与 files 复原。');
    }
  };

  try {
    console.log('\n3) 落新数据库…');
    fs.mkdirSync(path.dirname(realDb), { recursive: true });
    for (const suf of ['-wal', '-shm']) { try { fs.unlinkSync(realDb + suf); } catch (_) {} }
    fs.writeFileSync(realDb, pkg.entries.get('db/archive.db'));

    console.log('4) 落附件…');
    fs.rmSync(filesDir, { recursive: true, force: true });
    fs.mkdirSync(filesDir, { recursive: true });
    let wrote = 0;
    for (const [name, data] of pkg.entries) {
      if (!name.startsWith('files/') || name.endsWith('/')) continue;
      const rel = name.slice('files/'.length);
      const dest = path.join(filesDir, rel);
      if (!path.resolve(dest).startsWith(path.resolve(filesDir) + path.sep)) continue;  // 防目录穿越
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data);
      wrote += 1;
    }
    console.log(`   写入附件 ${wrote} 个，${human(dirSize(filesDir))}`);

    console.log('\n5) 复核恢复结果…');
    const db = openDatabase(realDb);
    try {
      const cnt = (sql) => Number((db.prepare(sql).get() || { c: 0 }).c || 0);
      const got = {
        archives: cnt('SELECT COUNT(*) c FROM archives'),
        files: cnt('SELECT COUNT(*) c FROM files'),
        users: cnt('SELECT COUNT(*) c FROM users'),
        logs: cnt('SELECT COUNT(*) c FROM logs'),
      };
      console.log(`   档案 ${got.archives} 条、附件 ${got.files} 个、用户 ${got.users} 个、日志 ${got.logs} 条`);
      const bad = [];
      for (const k of ['archives', 'files', 'users', 'logs']) {
        if (pkg.counts[k] >= 0 && got[k] !== pkg.counts[k]) bad.push(`${k} 期望 ${pkg.counts[k]} 实际 ${got[k]}`);
      }
      const missing = [];
      const rows = db.prepare('SELECT id,original_name,rel_path FROM files').all();
      for (const r of rows) {
        const f = path.join(filesDir, String(r.rel_path || ''));
        if (!fs.existsSync(f)) missing.push(r.original_name || r.rel_path);
      }
      if (missing.length) bad.push(`${missing.length} 个附件在库里登记了但文件不存在（例：${missing.slice(0, 3).join('、')}）`);

      const detail = [
        `由备份包 ${path.basename(zipPath)} 恢复`,
        `${got.archives} 档案 / ${got.files} 附件 / ${got.users} 用户 / ${got.logs} 日志`,
        `落盘附件 ${wrote} 个`,
        `日志链原包结论：${pkg.chain.ok ? '完整' : '异常'}`,
        bad.length ? '复核不一致：' + bad.join('；') : '复核一致',
      ].join('；');
      const result = bad.length ? '不合格' : '合格';
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO backup_drills
        (at,backup_no,mode,result,archives,files,users,logs,chain_ok,detail,by_user,by_name,ip)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        now, path.basename(zipPath, '.zip'), '实际恢复', result,
        got.archives, got.files, got.users, got.logs, pkg.chain.ok ? 1 : 0,
        detail, null, String(arg('by', '命令行恢复')), '127.0.0.1',
      );
      try {
        audit.appendLog(db, {
          at: now, user_id: '', username: String(arg('by', '命令行恢复')),
          action: '整库恢复', target: path.basename(zipPath),
          detail, ip: '127.0.0.1', step: '整库恢复', result: bad.length ? '失败' : '成功', category: 'system',
        });
      } catch (_) { /* 审计写入失败不阻断恢复 */ }

      if (bad.length) {
        console.error('   复核不一致：' + bad.join('；'));
        rollback('复核不一致');
        return 5;
      }
    } finally {
      try { db.close(); } catch (_) {}
    }
  } catch (e) {
    rollback(e.message);
    return 5;
  }

  console.log('\n恢复完成。');
  console.log(`   回滚点保留在：${bakDir}（确认业务正常后可自行删除）`);
  console.log('   请重新启动服务，并用一个已有账号登录核对数据。');
  return 0;
}

main().then((code) => process.exit(code)).catch((e) => {
  console.error('恢复过程异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
