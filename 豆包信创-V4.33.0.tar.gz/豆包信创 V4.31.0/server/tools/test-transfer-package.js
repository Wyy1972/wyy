/**
 * 移交进馆标准数据包验证
 *
 * 这个包的意义就是"接收方不必相信本系统也能自己校验"，所以测试也照着这个来：
 * **把 ZIP 解开**，逐项核对 manifest、元数据 XML、目录清单、交接文据与说明，
 * 并**重算某个原文的 SHA-256 与 manifest 里记的比对** —— 只断言"接口返回 200"等于没测。
 *
 * 另外两件必须验的事：
 *   · 未提交的批次不许导出（内容还会变）；
 *   · 密级不够的档案**不进包**，且 manifest **如实记录未纳入的件数**（不能假装拿全了）。
 */
'use strict';

const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const BASE = process.argv[2] || 'http://127.0.0.1:8796';
const DATA_DIR = process.argv[3] || path.resolve(__dirname, '..', '..', 'data');

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

/** 手工解 ZIP（本项目的 ZipWriter 是 stored 不压缩，直接按本地文件头顺序切） */
function unzip(buf) {
  const out = new Map();
  let i = 0;
  while (i + 30 <= buf.length && buf.readUInt32LE(i) === 0x04034b50) {
    const size = buf.readUInt32LE(i + 18);
    const nameLen = buf.readUInt16LE(i + 26);
    const extraLen = buf.readUInt16LE(i + 28);
    const name = buf.slice(i + 30, i + 30 + nameLen).toString('utf8');
    const start = i + 30 + nameLen + extraLen;
    out.set(name, buf.slice(start, start + size));
    i = start + size;
  }
  return out;
}
const sha256hex = (b) => crypto.createHash('sha256').update(b).digest('hex');

const TAG = 'TP' + Math.random().toString(16).slice(2, 8).toUpperCase();

async function main() {
  const admin = makeSession();
  const anon = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);

  const db = new DatabaseSync(path.join(DATA_DIR, 'archive.db'));
  const rows = db.prepare("SELECT id, archive_code, secret_level FROM archives WHERE status NOT IN ('已销毁') ORDER BY (secret_level='秘密') DESC, id LIMIT 8").all();
  const candidates = rows.map((r) => Number(r.id));
  check('演示数据里可挑出待移交档案', candidates.length >= 2, String(candidates.length));

  // 移交闸门（v8）：每件都必须先有**合格的归档环节四性检测记录**才能提交。
  // 所以这里先跑检测，再只用合格的件建批次 —— 这也正是真实使用时的顺序。
  section('先做四性检测（移交闸门要求）');
  const det = await admin.json('/api/detections', { method: 'POST', json: { archive_ids: candidates, environment: 'archive', source: '数据包测试' } });
  check('四性检测可执行', det.status === 200 && !!det.body.data, JSON.stringify(det.body).slice(0, 160));
  const results = (det.body.data || {}).results || [];
  const okIds = results.filter((r) => r.qualified).map((r) => Number(r.archive_id));
  const badIds = results.filter((r) => r.qualified === false && r.conclusion).map((r) => r.archive_id);
  check('至少 2 件通过归档环节检测（用于建批次）', okIds.length >= 2,
    `合格 ${okIds.length} / 不合格 ${badIds.length}`);
  if (okIds.length < 2) { console.log('  提示：演示数据里合格件不足，无法继续'); process.exit(1); }
  const ids = okIds.slice(0, 5);

  section('建批次 / 提交前不许导出');
  const mk = await admin.json('/api/transfers', {
    method: 'POST',
    json: {
      archive_ids: ids, title: '移交数据包测试' + TAG, target_unit: '测试档案馆', basis: '《档案法》第十五条',
      contact: '测试联系人', phone: '0000-0000000',
    },
  });
  check('新建移交批次成功', mk.status === 200 && mk.body.ok, JSON.stringify(mk.body).slice(0, 160));
  const tid = mk.body.ok ? mk.body.data.id : 0;
  if (!tid) { console.log('批次创建失败，后续用例无法继续'); process.exit(1); }

  const beforeSubmit = await admin.json(`/api/transfers/${tid}/package`);
  check('未提交的批次拒绝导出（400，内容还会变）', beforeSubmit.status === 400, String(beforeSubmit.status));

  const submit = await admin.json(`/api/transfers/${tid}/submit`, { method: 'POST', json: {} });
  check('提交成功', submit.status === 200 && submit.body.ok, JSON.stringify(submit.body).slice(0, 140));

  section('导出并解包');
  check('未登录不能导出（401）', (await anon.req(`/api/transfers/${tid}/package`)).status === 401);
  const res = await admin.req(`/api/transfers/${tid}/package`);
  check('导出返回 200', res.status === 200, String(res.status));
  check('内容类型是 zip', /zip/.test(res.headers.get('content-type') || ''), String(res.headers.get('content-type')));
  check('带下载文件名', /filename/.test(res.headers.get('content-disposition') || ''), String(res.headers.get('content-disposition')));
  const buf = Buffer.from(await res.arrayBuffer());
  check('包体不是空的（> 2KB）', buf.length > 2048, String(buf.length));

  let files = new Map();
  try { files = unzip(buf); } catch (e) { check('ZIP 能解开', false, e.message); }
  check('ZIP 能解开', files.size > 0, String(files.size));
  const names = [...files.keys()];
  for (const must of ['manifest.json', '目录清单.csv', '交接文据.html', '说明.txt']) {
    check('包内含 ' + must, files.has(must), names.slice(0, 8).join(' | '));
  }
  check('包内含元数据目录', names.some((n) => n.startsWith('元数据/')), names.slice(0, 8).join(' | '));

  section('manifest 逐项核对');
  let manifest = null;
  try { manifest = JSON.parse(files.get('manifest.json').toString('utf8')); } catch (e) { check('manifest.json 可解析', false, e.message); }
  check('manifest.json 可解析', !!manifest);
  if (manifest) {
    check('标注了包类型', manifest.package_kind === '档案移交进馆标准数据包', String(manifest.package_kind));
    check('带打包器版本（应用版本，非占位）', /^档案管理系统 v\d+\.\d+\.\d+$/.test(manifest.generator || ''), String(manifest.generator));
    check('记录了移交单位', typeof manifest.unit === 'string' && manifest.unit.length > 0, String(manifest.unit));
    check('记录了批次号与接收单位', manifest.transfer.transfer_no && manifest.transfer.target_unit === '测试档案馆',
      JSON.stringify(manifest.transfer).slice(0, 160));
    check('件数与批次一致', manifest.counts.items_in_package === ids.length,
      `${manifest.counts.items_in_package} vs ${ids.length}`);
    check('记录了审计链校验结论', typeof manifest.audit.chain_ok === 'boolean', JSON.stringify(manifest.audit));
    check('逐件带档号/题名/期限', (manifest.items || []).every((x) => x.archive_code && x.title !== undefined && x.retention !== undefined));
    check('逐件标出元数据文件名', (manifest.items || []).every((x) => String(x.metadata_file || '').startsWith('元数据/')),
      JSON.stringify((manifest.items || [])[0] || {}).slice(0, 140));

    // 每一件在包里都要有对应的元数据 XML
    const missXml = (manifest.items || []).filter((x) => !files.has(x.metadata_file));
    check('每件都有对应的元数据 XML', missXml.length === 0, JSON.stringify(missXml.map((x) => x.metadata_file)).slice(0, 160));
    const firstXml = files.get((manifest.items[0] || {}).metadata_file);
    check('元数据 XML 是标记文本', !!firstXml && /</.test(firstXml.toString('utf8').slice(0, 200)),
      firstXml ? firstXml.toString('utf8').slice(0, 80) : 'missing');

    // —— 最关键的一步：重算摘要与 manifest 比对（接收方要做的就是这件事） ——
    const withFiles = (manifest.items || []).find((x) => (x.files || []).length > 0);
    if (withFiles) {
      const f0 = withFiles.files[0];
      const entryName = `原文/${withFiles.archive_code}/${f0.name}`;
      const data = files.get(entryName);
      check('原文确实在包里（路径与 manifest 一致）', !!data, entryName);
      if (data) {
        check('manifest 记的大小与实际一致', f0.size === data.length, `${f0.size} vs ${data.length}`);
        check('重算 SHA-256 与 manifest 相符', !f0.sha256 || f0.sha256 === sha256hex(data),
          `${f0.sha256} vs ${sha256hex(data)}`);
      }
    } else {
      check('演示数据里至少有一件带电子原文', false, '没有原文可验摘要');
      check('manifest 记的大小与实际一致', false, '夹具缺失');
      check('重算 SHA-256 与 manifest 相符', false, '夹具缺失');
    }
  } else {
    check('标注了包类型', false, 'manifest 解析失败');
  }

  section('清单 / 文据 / 说明 的可读性');
  const item0 = ((manifest && manifest.items) || [])[0] || {};
  const csv = (files.get('目录清单.csv') || Buffer.from('')).toString('utf8');
  check('目录清单带 BOM（Excel 打开不乱码）', csv.charCodeAt(0) === 0xFEFF, String(csv.charCodeAt(0)));
  check('目录清单含表头', /序号.*档号.*题名/.test(csv), csv.slice(0, 80).replace(/\n/g, ' '));
  check('目录清单含第一件档号', !!item0.archive_code && csv.includes(item0.archive_code), String(item0.archive_code));
  const sig = (files.get('交接文据.html') || Buffer.from('')).toString('utf8');
  check('交接文据是 HTML', /<html/i.test(sig), sig.slice(0, 60));
  check('交接文据含签署栏', /移交单位（盖章）/.test(sig) && /接收单位（盖章）/.test(sig));
  check('交接文据含审计链结论', /审计链校验/.test(sig));
  const readme = (files.get('说明.txt') || Buffer.from('')).toString('utf8');
  check('说明写明校验方法', /SHA-256/.test(readme) && /manifest\.json/.test(readme));
  check('说明写明包内结构', /元数据\//.test(readme) && /原文\//.test(readme));

  section('密级：不进包 + 如实告知');
  const secretRow = rows.find((r) => r.secret_level === '秘密');
  if (secretRow) {
    const clk = TAG.toLowerCase() + '_clk';
    const mkUser = await admin.json('/api/users', {
      method: 'POST',
      json: { username: clk, display_name: '数据包测试档案员', password: 'Test@12345', role: 'clerk', clearance: '内部' },
    });
    check('创建低密级档案员（上限=内部）', mkUser.status === 200 && mkUser.body.ok, JSON.stringify(mkUser.body).slice(0, 140));
    const clerk = makeSession();
    await clerk.json('/api/login', { method: 'POST', json: { username: clk, password: 'Test@12345' } });
    await clerk.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
    const r2 = await clerk.req(`/api/transfers/${tid}/package`);
    check('低密级账号仍可导出（不报错，而是过滤）', r2.status === 200, String(r2.status));
    const f2 = unzip(Buffer.from(await r2.arrayBuffer()));
    const m2 = JSON.parse(f2.get('manifest.json').toString('utf8'));
    const c2 = m2.counts || {};
    check('manifest 如实记录「因密级未纳入 N 件」', c2.items_excluded_by_clearance >= 1,
      JSON.stringify(c2));
    check('未纳入的件数 = 批次总数 - 包内件数',
      c2.items_excluded_by_clearance === c2.items_in_transfer - c2.items_in_package,
      JSON.stringify(c2));
    const secretCode = secretRow.archive_code;
    check('超密级那份的元数据 XML 确实没进包', ![...f2.keys()].some((n) => n.includes(secretCode)),
      [...f2.keys()].filter((n) => n.startsWith('元数据/')).slice(0, 4).join(' | '));
    check('说明里也写明了未纳入的原因', /未纳入本包/.test(f2.get('说明.txt').toString('utf8')));
    if (mkUser.body.ok) await admin.json('/api/users/' + mkUser.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  } else {
    check('演示数据里有秘密级档案（夹具前提）', false, '没有秘密级档案');
    check('manifest 如实记录「因密级未纳入 N 件」', false, '夹具缺失');
    check('未纳入的件数 = 批次总数 - 包内件数', false, '夹具缺失');
    check('超密级那份的元数据 XML 确实没进包', false, '夹具缺失');
    check('说明里也写明了未纳入的原因', false, '夹具缺失');
  }

  section('权限');
  const readerName = TAG.toLowerCase() + '_rd';
  const mkRd = await admin.json('/api/users', {
    method: 'POST',
    json: { username: readerName, display_name: '数据包测试阅读者', password: 'Test@12345', role: 'reader' },
  });
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: readerName, password: 'Test@12345' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  check('阅读者不能导出移交数据包（403）', (await reader.json(`/api/transfers/${tid}/package`)).status === 403);
  if (mkRd.body.ok) await admin.json('/api/users/' + mkRd.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });

  db.close();
  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
