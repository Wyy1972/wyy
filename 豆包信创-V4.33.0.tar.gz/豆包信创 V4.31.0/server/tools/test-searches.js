/**
 * 常用检索（保存检索策略）验证
 *
 * 关注四件事：
 *   ① 存进去的是**检索条件对象**，取出来还得是对象（不是字符串）—— 否则前端套不回表单；
 *   ② 同名覆盖（连点两次不该存出一堆重名）；条件里的空值/嵌套值被剔除；
 *   ③ 「最近用过」要真的更新（列表靠它排序，常用的才会自动浮到前面）；
 *   ④ **隔离**：别人的私有检索既看不到、也不能删；共享的能看到但不能删。
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8796';

let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim();
      const v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 300) }; }
    return { status: res.status, body: data, text };
  }
  return { req, json };
}

const TAG = 'SS' + Math.random().toString(16).slice(2, 8).toUpperCase();
const NAME = '常用检索测试' + TAG;
const QUERY = { kw: '档案', type: 'WS', year: '2026', status: '' };

async function main() {
  const admin = makeSession();
  const anon = makeSession();

  section('准备');
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  check('管理员登录成功', login.status === 200 && login.body.ok, String(login.status));
  if (!login.body.ok) process.exit(1);
  check('未登录不能读常用检索（401）', (await anon.json('/api/searches')).status === 401);

  const base0 = await admin.json('/api/searches');
  check('列表可取', base0.status === 200 && Array.isArray(base0.body.data.list), String(base0.status));
  const beforeCount = base0.body.data.list.length;

  section('保存');
  const save = await admin.json('/api/searches', { method: 'POST', json: { name: NAME, query: QUERY, note: '测试' } });
  check('保存成功', save.status === 200 && save.body.ok === true, JSON.stringify(save.body).slice(0, 140));
  const sid = save.body.ok ? save.body.data.id : 0;
  check('首次保存不是覆盖', save.body.data.updated === false, JSON.stringify(save.body.data));

  const badName = await admin.json('/api/searches', { method: 'POST', json: { name: '  ', query: QUERY } });
  check('空名字被拒（400）', badName.status === 400, String(badName.status));
  const badQuery = await admin.json('/api/searches', { method: 'POST', json: { name: NAME + 'x', query: [1, 2, 3] } });
  check('条件传数组被拒（400）', badQuery.status === 400, String(badQuery.status));
  const huge = await admin.json('/api/searches', { method: 'POST', json: { name: NAME + 'y', query: { kw: 'x'.repeat(6000) } } });
  check('条件过大被拒（400）', huge.status === 400, String(huge.status));

  section('取回来必须还是"条件对象"');
  const list1 = await admin.json('/api/searches');
  const mine = (list1.body.data.list || []).find((s) => s.id === sid);
  check('列表里能找到刚存的', !!mine, String(sid));
  check('query 是对象而不是字符串（前端要直接套回表单）',
    mine && typeof mine.query === 'object' && !Array.isArray(mine.query), JSON.stringify(mine && mine.query));
  check('条件内容原样保留', mine && mine.query.kw === QUERY.kw && mine.query.type === QUERY.type,
    JSON.stringify(mine && mine.query));
  check('标出"是我的"（前端用来区分共享项）', mine && mine.mine === true, String(mine && mine.mine));
  check('列表条数 +1', list1.body.data.list.length === beforeCount + 1,
    `${beforeCount} → ${list1.body.data.list.length}`);

  section('同名覆盖 / 空值剔除');
  const save2 = await admin.json('/api/searches', {
    method: 'POST',
    json: { name: NAME, query: { kw: '新关键词', type: 'WS', year: '', nested: { a: 1 } }, shared: true },
  });
  check('同名再次保存是覆盖', save2.status === 200 && save2.body.data.updated === true && save2.body.data.id === sid,
    JSON.stringify(save2.body.data));
  const list2 = await admin.json('/api/searches');
  check('没有存出重复的同名项',
    (list2.body.data.list || []).filter((s) => s.name === NAME).length === 1,
    String((list2.body.data.list || []).filter((s) => s.name === NAME).length));
  const mine2 = (list2.body.data.list || []).find((s) => s.id === sid);
  check('覆盖后条件是新的一份', mine2 && mine2.query.kw === '新关键词', JSON.stringify(mine2 && mine2.query));
  check('空值被剔除（不存 year:""）', mine2 && !Object.prototype.hasOwnProperty.call(mine2.query, 'year'),
    JSON.stringify(mine2 && mine2.query));
  check('嵌套对象被剔除（只收标量）', mine2 && !Object.prototype.hasOwnProperty.call(mine2.query, 'nested'),
    JSON.stringify(mine2 && mine2.query));
  check('覆盖时把可见范围改成了共享', mine2 && Number(mine2.shared) === 1, String(mine2 && mine2.shared));

  section('使用计数与最近使用');
  check('初始使用次数为 0', mine2 && Number(mine2.used_count) === 0, String(mine2 && mine2.used_count));
  const use = await admin.json(`/api/searches/${sid}/use`, { method: 'POST', json: {} });
  check('记一次使用成功', use.status === 200 && use.body.ok, JSON.stringify(use.body).slice(0, 140));
  check('使用接口把条件一并返回（前端据此套用）', use.body.data && use.body.data.query && use.body.data.query.kw === '新关键词',
    JSON.stringify(use.body.data));
  const list3 = await admin.json('/api/searches');
  const mine3 = (list3.body.data.list || []).find((s) => s.id === sid);
  check('使用次数 +1', mine3 && Number(mine3.used_count) === 1, String(mine3 && mine3.used_count));
  check('记录了最近使用时间（列表按它排序）', mine3 && !!mine3.last_used_at, String(mine3 && mine3.last_used_at));

  section('隔离：别人的私有看不到、也不能删');
  const clkName = TAG.toLowerCase() + '_clk';
  const mk = await admin.json('/api/users', {
    method: 'POST',
    json: { username: clkName, display_name: '常用检索测试档案员', password: 'Test@12345', role: 'clerk' },
  });
  check('创建档案员账号成功', mk.status === 200 && mk.body.ok, JSON.stringify(mk.body).slice(0, 140));
  const clerk = makeSession();
  await clerk.json('/api/login', { method: 'POST', json: { username: clkName, password: 'Test@12345' } });
  await clerk.json('/api/me/password', { method: 'POST', json: { oldPassword: 'Test@12345', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const clkList = await clerk.json('/api/searches');
  const sharedOne = (clkList.body.data.list || []).find((s) => s.id === sid);
  check('共享的检索别人能看到', !!sharedOne, String(sid));
  check('共享项标为"不是我的"', sharedOne && sharedOne.mine === false, String(sharedOne && sharedOne.mine));
  check('共享项仍可被别人使用', (await clerk.json(`/api/searches/${sid}/use`, { method: 'POST', json: {} })).status === 200);
  check('别人的（共享的）检索不能删（403）', (await clerk.json(`/api/searches/${sid}`, { method: 'DELETE', json: { reason: '测试夹具清理' } })).status === 403);

  // 私有项：先由管理员改回私有，再让档案员看不见
  await admin.json('/api/searches', { method: 'POST', json: { name: NAME, query: QUERY, shared: false } });
  const clkList2 = await clerk.json('/api/searches');
  check('改成私有后别人就看不到了（按不存在处理，不泄露）',
    !(clkList2.body.data.list || []).some((s) => s.id === sid), String(sid));
  check('别人的私有检索不能记使用（404）', (await clerk.json(`/api/searches/${sid}/use`, { method: 'POST', json: {} })).status === 404);

  section('删除');
  check('删除不存在的返回 404', (await admin.json('/api/searches/99999999', { method: 'DELETE', json: { reason: '测试夹具清理' } })).status === 404);
  const del = await admin.json(`/api/searches/${sid}`, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  check('本人删除成功', del.status === 200 && del.body.ok, String(del.status));
  const list4 = await admin.json('/api/searches');
  check('删除后列表里没有了', !(list4.body.data.list || []).some((s) => s.id === sid), String(sid));

  if (mk.body.ok) await admin.json('/api/users/' + mk.body.data.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });

  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
