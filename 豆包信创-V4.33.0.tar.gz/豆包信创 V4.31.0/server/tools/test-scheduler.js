/**
 * 定时任务与待办中心验证（v13）
 *
 * 全部**离线**跑：直接操作临时库，不依赖 HTTP 服务。
 * 之所以做成离线且可注入时间，是因为要验证的行为几乎都和时间有关：
 *   - 重启补跑（停机 3 小时 vs 停机 5 天）
 *   - 每日固定时刻的下一次运行时间
 *   - 并发互斥与失败隔离
 * 真等几个小时才能测一次是不现实的，所以 now() 由外部注入。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { openDatabase } = require('../db');
const { createScheduler } = require('../lib/scheduler');
const { buildJobs } = require('../lib/jobs');
const audit = require('../lib/audit');
const { makeApi } = require('../lib/q');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'assched-'));
const dbPath = path.join(dir, 'test.db');
let pass = 0;
let failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); } else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

const db = openDatabase(dbPath);
const q = makeApi(db);
const silent = { log() {}, warn() {}, error() {} };
/** 注入的"现在"，测试里随意拨动 */
let NOW = new Date('2026-03-01T10:00:00.000Z');
const nowFn = () => NOW;
const newSched = () => createScheduler({ db, now: nowFn, logger: silent });

(async () => {
  // 防"静默通过"保险：若某个用例意外让事件循环清空，Node 会静默退出（退出码 0），
  // 看起来全绿、实际后面的用例一条没跑。这个定时器保证脚本一定会走到汇总那一行。
  const keepAlive = setInterval(() => {}, 1000);

  // ---------------------------------------------------------------- 1 结构与迁移
  console.log('【1. v13 结构】');
  const tables = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name));
  check('存在表 scheduler_state', tables.has('scheduler_state'));
  check('存在表 todos', tables.has('todos'));
  check('schema_version >= 13', Number(q.scalar("SELECT value FROM meta WHERE key='schema_version'")) >= 13,
    String(q.scalar("SELECT value FROM meta WHERE key='schema_version'")));
  for (const k of ['scheduler.enabled', 'scheduler.backup_hour', 'scheduler.catch_up_hours',
    'backup.keep_copies', 'detection.sweep_interval_days', 'todo.badge_limit']) {
    const v = q.scalar('SELECT value FROM settings WHERE key=?', k);
    check('设置项已写入 ' + k, v !== undefined && v !== null && v !== '', String(v));
  }
  const todoCols = new Set(db.prepare('PRAGMA table_info(todos)').all().map((r) => r.name));
  for (const c of ['dedupe_key', 'kind', 'level', 'title', 'detail', 'status', 'handled_by', 'handled_at']) {
    check('todos 含列 ' + c, todoCols.has(c));
  }

  // ---------------------------------------------------------------- 2 注册校验
  console.log('\n【2. 注册参数校验（宁可启动就报错，也不要静默不跑）】');
  let threw = false;
  try { newSched().register({ title: '无 key', run() {} }); } catch (_) { threw = true; }
  check('缺 key 抛错', threw);
  threw = false;
  try { newSched().register({ key: 'x' }); } catch (_) { threw = true; }
  check('缺 run 抛错', threw);
  threw = false;
  try { newSched().register({ key: 'x', run() {} }); } catch (_) { threw = true; }
  check('既无 everyMs 也无 dailyHour 抛错', threw);

  // ---------------------------------------------------------------- 3 首次不立即执行
  console.log('\n【3. 新装系统不该一开机就跑备份】');
  let s1Runs = 0;
  const s1 = newSched();
  s1.register({ key: 't.never', title: '未曾运行', everyMs: 3600000, async run() { s1Runs++; } });
  await s1.start();
  check('首次启动未立即执行', s1Runs === 0, 'runs=' + s1Runs);
  const st1 = s1.status()[0];
  check('已排定下一次运行', Date.parse(st1.next_run_at) > NOW.getTime(), st1.next_run_at);
  check('状态含 next_run_at 字段', !!st1.next_run_at);
  check('状态含 last_status 字段', typeof st1.last_status === 'string');
  s1.stop();

  // ---------------------------------------------------------------- 4 runOnFirstStart
  console.log('\n【4. 声明了 runOnFirstStart 的任务应立即执行】');
  let s2Runs = 0;
  const s2 = newSched();
  s2.register({ key: 't.first', title: '立即执行型', everyMs: 86400000, runOnFirstStart: true, async run() { s2Runs++; return { detail: '首跑' }; } });
  await s2.start();
  check('首次启动执行了一次', s2Runs === 1, 'runs=' + s2Runs);
  s2.stop();

  // ---------------------------------------------------------------- 5 重启补跑
  console.log('\n【5. 重启补跑：停机期间错过的任务要补上】');
  // 造一条"3 小时前跑过"的状态（任务间隔 1 小时 ⇒ 逾期 2 小时）
  db.prepare(`INSERT INTO scheduler_state(task_key,last_run_at,last_status,runs,fails,updated_at)
              VALUES('t.catchup',?, 'ok',1,0,?)`)
    .run(new Date(NOW.getTime() - 3 * 3600000).toISOString(), NOW.toISOString());
  let s3Runs = 0;
  const s3 = newSched();
  s3.register({ key: 't.catchup', title: '补跑型', everyMs: 3600000, catchUpHours: 24, async run() { s3Runs++; return { detail: '补跑完成' }; } });
  await s3.start();
  check('逾期任务被补跑一次', s3Runs === 1, 'runs=' + s3Runs);
  const st3 = db.prepare("SELECT * FROM scheduler_state WHERE task_key='t.catchup'").get();
  check('补跑后 last_status=ok', st3.last_status === 'ok', st3.last_status);
  check('补跑后 runs 累加', Number(st3.runs) === 2, String(st3.runs));
  s3.stop();

  // ---------------------------------------------------------------- 6 停机过久不补跑
  console.log('\n【6. 停机过久不补跑：防止开机后连环爆跑打满磁盘】');
  db.prepare(`INSERT INTO scheduler_state(task_key,last_run_at,last_status,runs,fails,updated_at)
              VALUES('t.toolate',?, 'ok',1,0,?)`)
    .run(new Date(NOW.getTime() - 5 * 86400000).toISOString(), NOW.toISOString());
  let s4Runs = 0;
  const s4 = newSched();
  s4.register({ key: 't.toolate', title: '停机过久型', everyMs: 3600000, catchUpHours: 24, async run() { s4Runs++; } });
  const st4 = s4.status()[0];
  check('判定为不补跑', st4.due === false);
  check('原因说明是跳过补跑', /跳过补跑/.test(st4.reason), st4.reason);
  await s4.start();
  check('确实没有执行', s4Runs === 0, 'runs=' + s4Runs);
  s4.stop();

  // ---------------------------------------------------------------- 7 每日固定时刻
  console.log('\n【7. 每日固定时刻的下一次运行时间】');
  const s5 = newSched();
  s5.register({ key: 't.daily', title: '每日任务', dailyHour: 2, async run() {} });
  const st5 = s5.status()[0];
  const next5 = new Date(st5.next_run_at);
  check('下一次是明天（当前 10 点已过 2 点）', next5.getTime() > NOW.getTime(), st5.next_run_at);
  check('下一次的小时数为 2', next5.getHours() === 2, String(next5.getHours()));
  s5.stop();

  // ---------------------------------------------------------------- 8 并发互斥
  console.log('\n【8. 并发互斥：同任务不重入】');
  let s6Runs = 0;
  const s6 = newSched();
  s6.register({
    key: 't.slow', title: '慢任务', everyMs: 3600000,
    // 用真实的定时器制造"执行中"状态。**不要**用手动 resolve 的挂起 Promise：
    // 那种写法一旦没被 resolve，事件循环会直接清空，Node 静默退出（退出码 0），
    // 测试看起来"通过了"，其实后面的用例一条都没跑 —— 本项目踩过一次。
    async run() { s6Runs++; await new Promise((r) => setTimeout(r, 150)); return { detail: '慢任务完成' }; },
  });
  const first = s6.runNow('t.slow');
  await new Promise((r) => setTimeout(r, 30));       // 让第一次真正进入执行
  const second = await s6.runNow('t.slow');
  check('第二次被拒绝（skipped）', second.skipped === true, JSON.stringify(second));
  check('慢任务只执行了一次', s6Runs === 1, 'runs=' + s6Runs);
  await first;
  check('第一次已正常结束', s6Runs === 1, 'runs=' + s6Runs);
  const after = await s6.runNow('t.slow');
  check('前一次结束后可以再执行', after.ok === true, JSON.stringify(after));
  s6.stop();

  // ---------------------------------------------------------------- 9 失败隔离
  console.log('\n【9. 失败隔离：任务抛错不能带崩服务，且必须可见】');
  const s7 = newSched();
  s7.register({
    key: 't.boom', title: '会失败的任务', everyMs: 3600000, runOnFirstStart: true,
    async run() { throw new Error('故意失败'); },
  });
  await s7.start();
  const st7 = db.prepare("SELECT * FROM scheduler_state WHERE task_key='t.boom'").get();
  check('状态记为 fail', st7.last_status === 'fail', st7.last_status);
  check('失败次数累加', Number(st7.fails) === 1, String(st7.fails));
  check('失败详情记录了原因', /故意失败/.test(st7.last_detail), st7.last_detail);
  check('失败生成待办', Number(q.scalar("SELECT COUNT(*) FROM todos WHERE dedupe_key='scheduler.fail:t.boom'")) === 1);
  const failTodo = q.get("SELECT * FROM todos WHERE dedupe_key='scheduler.fail:t.boom'");
  check('失败待办级别为 warn', failTodo.level === 'warn', failTodo.level);
  check('服务未受影响（仍可继续注册执行）', s7.keys().length === 1);
  s7.stop();

  // ---------------------------------------------------------------- 9b 任务超时
  console.log('\n【9b. 任务超时保护：卡死不能永久占住互斥】');
  const s7b = newSched();
  s7b.register({
    key: 't.hang', title: '卡死任务', everyMs: 3600000, timeoutMs: 200,
    async run() { await new Promise(() => {}); },   // 永不 resolve：模拟卡死的任务
  });
  const hangRes = await s7b.runNow('t.hang');
  check('卡死任务被判超时失败', hangRes.ok === false, JSON.stringify(hangRes));
  check('失败原因写明超时', /超时/.test(hangRes.detail || ''), hangRes.detail);
  const stHang = db.prepare("SELECT * FROM scheduler_state WHERE task_key='t.hang'").get();
  check('状态记为 fail', stHang.last_status === 'fail', stHang.last_status);
  check('超时生成失败待办', Number(q.scalar("SELECT COUNT(*) FROM todos WHERE dedupe_key='scheduler.fail:t.hang'")) === 1);
  check('互斥已解除', s7b.status().find((x) => x.key === 't.hang').running === false);
  const hangAgain = await s7b.runNow('t.hang');
  check('超时后仍可再次触发（不会被永久挡住）', hangAgain.ok === false && !hangAgain.skipped, JSON.stringify(hangAgain));
  s7b.stop();

  // ---------------------------------------------------------------- 10 审计落链
  console.log('\n【10. 每次执行都进审计链】');
  const taskLogs = q.all("SELECT * FROM logs WHERE action LIKE '定时任务·%' ORDER BY id");
  check('产生了定时任务审计记录', taskLogs.length >= 3, 'count=' + taskLogs.length);
  check('审计分类为 scheduler', taskLogs.every((r) => r.category === 'scheduler'), taskLogs[0] && taskLogs[0].category);
  check('操作人记为系统', taskLogs.every((r) => r.username === '系统'), taskLogs[0] && taskLogs[0].username);
  check('失败也留痕', taskLogs.some((r) => r.result === '失败'));
  const chain = audit.verifyChain(q.all('SELECT * FROM logs ORDER BY id'));
  check('审计链仍然完整（未因新分类断链）', chain.ok === true, JSON.stringify(chain));

  // ---------------------------------------------------------------- 11 待办幂等
  console.log('\n【11. 待办幂等：反复扫描不刷屏】');
  const s8 = newSched();
  db.prepare("DELETE FROM todos WHERE dedupe_key LIKE 'test.%'").run();
  // 直接用调度器内部的 todo 能力：通过一个任务来登记
  s8.register({
    key: 't.todo', title: '登记待办', everyMs: 3600000, runOnFirstStart: true,
    async run(ctx) {
      ctx.todo({ dedupeKey: 'test.dup', kind: 'backup', level: 'warn', title: '同一件事', detail: '第一次' });
      ctx.todo({ dedupeKey: 'test.dup', kind: 'backup', level: 'warn', title: '同一件事', detail: '第二次' });
      return { detail: '已登记' };
    },
  });
  await s8.start();
  check('同一 dedupe_key 只有一行', Number(q.scalar("SELECT COUNT(*) FROM todos WHERE dedupe_key='test.dup'")) === 1);
  check('重复登记会更新内容', /第二次/.test(q.scalar("SELECT detail FROM todos WHERE dedupe_key='test.dup'")), q.scalar("SELECT detail FROM todos WHERE dedupe_key='test.dup'"));
  // 已处理过的不再被重新打开
  db.prepare("UPDATE todos SET status='done' WHERE dedupe_key='test.dup'").run();
  await s8.runNow('t.todo');
  check('已处理的待办不会被重新打开', q.scalar("SELECT status FROM todos WHERE dedupe_key='test.dup'") === 'done',
    q.scalar("SELECT status FROM todos WHERE dedupe_key='test.dup'"));
  s8.stop();

  // ---------------------------------------------------------------- 12 状态总览
  console.log('\n【12. 状态总览字段完整（界面就靠它渲染）】');
  const s9 = newSched();
  s9.register({ key: 't.stat', title: '统计用任务', everyMs: 60000, async run() { return { detail: 'ok' }; } });
  const row = s9.status()[0];
  for (const f of ['key', 'title', 'every_ms', 'daily_hour', 'last_run_at', 'last_status', 'last_detail',
    'last_ms', 'runs', 'fails', 'next_run_at', 'due', 'reason', 'running']) {
    check('status 含字段 ' + f, Object.prototype.hasOwnProperty.call(row, f));
  }
  s9.stop();

  // ---------------------------------------------------------------- 13 内置任务
  console.log('\n【13. 内置任务表（buildJobs）】');
  const fakeApi = {
    runBackup: () => ({ id: 1, backup_no: 'B1', size_bytes: 1024, chain_ok: true, archives_count: 0, files_count: 0, logs_count: 0 }),
    runStorageCheck: () => ({ check_no: 'S1', conclusion: '正常', warnings: [] }),
    runDetectionSweep: () => ({ detail: '无待检', scanned: 0, checked: 0, qualified: 0, unqualified: 0, failed: 0, remaining: 0 }),
    processLoanDue: () => ({ autoReturned: 0, markedOverdue: 0 }),
    pruneLoginAttempts: () => 0,
  };
  const jobs = buildJobs({ api: fakeApi, db, logger: silent });
  check('内置任务共 5 个', jobs.length === 5, 'count=' + jobs.length);
  for (const k of ['backup.auto', 'detection.sweep', 'storage.check', 'remind.due', 'housekeep.login_attempts']) {
    const j = jobs.find((x) => x.key === k);
    check('存在任务 ' + k, !!j);
    check('任务 ' + k + ' 有中文名与 run()', !!j && typeof j.title === 'string' && typeof j.run === 'function');
    check('任务 ' + k + ' 有调度周期', !!j && (!!j.everyMs || Number.isInteger(j.dailyHour)));
  }
  const backupJob = jobs.find((j) => j.key === 'backup.auto');
  check('自动备份的默认时刻按设置（2 点）', backupJob.dailyHour === 2, String(backupJob.dailyHour));
  const remindJob = jobs.find((j) => j.key === 'remind.due');
  check('到期提醒在早上 8 点（人上班能看到）', remindJob.dailyHour === 8, String(remindJob.dailyHour));
  const sweepJob = jobs.find((j) => j.key === 'detection.sweep');
  check('四检巡检周期默认 30 天', sweepJob.everyMs === 30 * 86400000, String(sweepJob.everyMs));

  // 内置任务真的能跑通（用假的 api，验证任务体本身不抛错）
  console.log('\n【14. 内置任务可执行】');
  const s10 = newSched();
  for (const spec of jobs) s10.register(Object.assign({}, spec, { runOnFirstStart: false }));
  for (const k of s10.keys()) {
    const r = await s10.runNow(k);
    check('任务 ' + k + ' 执行成功', r.ok === true, r.detail);
  }
  s10.stop();

  // ---------------------------------------------------------------- 收尾
  console.log('\n────────────────────────────────────────');
  if (fails.length) {
    console.log('失败明细：');
    for (const f of fails) console.log('  - ' + f);
  }
  console.log(`通过 ${pass} 项，失败 ${failed} 项`);
  clearInterval(keepAlive);
  try { db.close(); } catch (_) { /* ignore */ }
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* ignore */ }
  process.exit(failed ? 1 : 0);
})().catch((e) => {
  console.error('测试脚本自身异常：' + (e && e.stack ? e.stack : e));
  try { db.close(); } catch (_) { /* ignore */ }
  process.exit(1);
});
