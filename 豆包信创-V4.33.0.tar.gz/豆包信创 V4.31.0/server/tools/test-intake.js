/**
 * 过程接收自测：node server/tools/test-intake.js --url http://127.0.0.1:8914 --data .\tmp-intake-test
 *
 * 验证 v4.29.0 的"过程—结束"链路（不只看接口，要看磁盘）：
 *   ① 建项目 → 登记接收批次（日期、阶段、移交人）
 *   ② 新建一件并挂到批次 → 接收日期自动继承批次的日期
 *   ③ 导入扫描件 → 落在「过程/门类/项目号 项目名/日期 批次名/」
 *   ④ 批次台账统计件数与扫描页数
 *   ⑤ 归档定稿 → 文件整体移到「归档/档号各段/」，件状态变「已归档」
 *
 * 前置：node server/server.js --data .\tmp-intake-test --port 8914 --no-qr
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { DatabaseSync } = require('node:sqlite');

/** 直接查库：详情接口刻意不暴露内部存放路径（合理），但存储测试要看磁盘真相 */
function dbRow(sql, ...args) {
  const db = new DatabaseSync(path.join(DATA, 'archive.db'));
  try { return db.prepare(sql).get(...args); } finally { db.close(); }
}

function arg(name, dft) {
  const i = process.argv.indexOf('--' + name);
  if (i >= 0) {
    const v = process.argv[i + 1];
    return v && !v.startsWith('--') ? v : true;
  }
  // 兼容 run-all.js 的位置传参：argv[2]=服务地址，argv[3]=测试数据目录。
  // 只认 --url 的话，被 run-all 调起时会退回默认 8914 端口，整套断言跑不到（零断言假绿）。
  if (name === 'url' && process.argv[2] && /^http/i.test(process.argv[2])) return process.argv[2];
  if (name === 'data' && process.argv[3] && !process.argv[3].startsWith('--')) return process.argv[3];
  return dft;
}

const BASE = String(arg('url', 'http://127.0.0.1:8914')).replace(/\/+$/, '');
const DATA = path.resolve(String(arg('data', path.join(__dirname, '..', '..', 'tmp-intake-test'))));
const PASSWORD = String(arg('password', 'admin123'));
let cookie = '';
let pass = 0;
let fail = 0;

function check(name, ok, detail) {
  if (ok) { pass += 1; console.log(`  ✓ ${name}`); } else {
    fail += 1;
    console.log(`  ✗ ${name}${detail ? '：' + detail : ''}`);
  }
}

function req(method, p, { body } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(BASE + p);
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const headers = {};
    if (payload) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = payload.length; }
    if (cookie) headers.Cookie = cookie;
    const r = http.request({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const sc = res.headers['set-cookie'];
        if (sc) cookie = sc.map((x) => x.split(';')[0]).join('; ');
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { json = null; }
        resolve({ status: res.statusCode, json, text: Buffer.concat(chunks).toString('utf8') });
      });
    });
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

function upload(archiveId, { kind, filename, data, fields = {} }) {
  return new Promise((resolve, reject) => {
    const boundary = '----intake' + Date.now().toString(16);
    const parts = [];
    for (const [k, v] of Object.entries({ kind, ...fields })) {
      parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
    }
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="files"; filename="${filename}"\r\n`
      + 'Content-Type: application/pdf\r\n\r\n'));
    parts.push(data);
    parts.push(Buffer.from(`\r\n--${boundary}--\r\n`));
    const body = Buffer.concat(parts);
    const u = new URL(BASE + `/api/archives/${archiveId}/files`);
    const r = http.request({
      hostname: u.hostname, port: u.port, path: u.pathname, method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length,
        ...(cookie ? { Cookie: cookie } : {}),
      },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { json = null; }
        resolve({ status: res.statusCode, json, text: Buffer.concat(chunks).toString('utf8') });
      });
    });
    r.on('error', reject);
    r.write(body);
    r.end();
  });
}

function makePdf(n) {
  const objs = ['<< /Type /Catalog /Pages 2 0 R >>', ''];
  const kids = [];
  for (let i = 0; i < n; i += 1) {
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents ${n + 3 + i} 0 R >>`);
  }
  for (let i = 0; i < n; i += 1) {
    kids.push(`${3 + i} 0 R`);
    objs.push('<< /Length 0 >>\nstream\n\nendstream');
  }
  objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${n} >>`;
  let out = '%PDF-1.7\n';
  const offs = [];
  objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (const o of offs) out += `${String(o).padStart(10, '0')} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}

(async () => {
  console.log('过程接收自测');
  const ping = await req('GET', '/api/ping');
  check('服务可达', ping.status === 200);
  const login = await req('POST', '/api/login', { body: { username: 'admin', password: PASSWORD } });
  check('管理员登录', login.status === 200 && login.json && login.json.ok, (login.json && login.json.error) || '');

  const proj = await req('POST', '/api/projects', {
    body: { kind: '工程', name: '自测泵站改造工程', start_date: '2026-01-05' },
  });
  const project = proj.json && proj.json.data;
  check('新建项目并自动编号', !!(project && /^GC-\d{4}-\d{3}$/.test(project.project_no)),
    JSON.stringify(proj.json).slice(0, 120));

  const bt = await req('POST', '/api/batches', {
    body: {
      project_id: project.id, title: '第1批 开工资料', stage: '开工', received_at: '2026-03-12',
      source_unit: '工程管理科', handover_by: '张工', handover_phone: '13800138000',
    },
  });
  const batch = bt.json && bt.json.data;
  check('登记接收批次', !!(batch && /^SR-20260312-\d{2}$/.test(batch.batch_no)), JSON.stringify(bt.json).slice(0, 120));

  const btInfo = await req('GET', `/api/batches/${batch.id}`);
  const btRow = (btInfo.json && btInfo.json.data && btInfo.json.data.batch) || {};
  check('交件人电话已保存', btRow.handover_phone === '13800138000', String(btRow.handover_phone));
  check('录入日期 = 登记时填的日期', btRow.received_at === '2026-03-12', String(btRow.received_at));

  const cats = await req('GET', '/api/categories');
  const flat = (cats.json && cats.json.data && cats.json.data.flat) || [];
  const cat = flat.find((c) => String(c.code || '') === 'GC-SG') || flat.find((c) => String(c.code || '').startsWith('GC-')) || flat[0];
  const created = await req('POST', '/api/archives', {
    body: {
      title: '开工报告', category_id: cat.id, type_code: 'GC', year: '2026', pages: '3',
      project_id: project.id, batch_id: batch.id,
    },
  });
  const a = created.json && created.json.data;
  check('新建一件并挂批次', created.status === 200 && !!a, (created.json && created.json.error) || '');

  const detail = await req('GET', `/api/archives/${a.id}`);
  const full = detail.json && detail.json.data;
  check('详情带出项目', !!(full && full.project && full.project.project_no === project.project_no));
  check('接收日期继承批次日期', !!(full && full.received_at === '2026-03-12'), full && full.received_at);

  const up = await upload(a.id, {
    kind: '扫描件', filename: '开工报告.pdf', data: makePdf(3),
    fields: { dpi: '300', color_mode: '彩色', device: '自测扫描仪' },
  });
  const file = up.json && up.json.data && up.json.data.files[0];
  check('导入扫描件', !!file, (up.json && up.json.error) || '');
  check('落在过程区「项目/批次日期」目录', !!file
    && file.rel_path.startsWith(`过程/工程/${project.project_no} 自测泵站改造工程/2026-03-12 第1批 开工资料/`),
  file && file.rel_path);
  const abs = path.join(DATA, 'files', file ? file.rel_path : '');
  check('磁盘上确实存在', fs.existsSync(abs), abs);

  const bdetail = await req('GET', `/api/batches/${batch.id}`);
  const items = (bdetail.json && bdetail.json.data && bdetail.json.data.items) || [];
  const bj = (bdetail.json && bdetail.json.data && bdetail.json.data.batch) || {};
  check('批次台账件数', items.length === 1, `items=${items.length}`);
  check('批次台账扫描页数', Number(bj.scanned_pages) === 3, `scanned_pages=${bj.scanned_pages}`);

  const pr = await req('GET', `/api/print/batch/${batch.id}`);
  check('交接单可打印', pr.status === 200 && String(pr.text).includes('档 案 资 料 交 接 单')
    && String(pr.text).includes(batch.batch_no) && String(pr.text).includes('交件人（签字）'), `HTTP ${pr.status}`);
  check('交接单带交件人与电话', String(pr.text).includes('13800138000') && String(pr.text).includes('张工'));
  check('交接单含件数与页数合计', String(pr.text).includes('合计') && String(pr.text).includes('1 件')
    && String(pr.text).includes('>3<'), '合计行缺失');

  const fin = await req('POST', `/api/batches/${batch.id}/finalize`, { body: {} });
  const fr = fin.json && fin.json.data;
  check('归档定稿', !!(fr && fr.archived === 1 && fr.failed === 0), JSON.stringify(fin.json).slice(0, 140));

  const after = await req('GET', `/api/archives/${a.id}`);
  const af = after.json && after.json.data;
  check('件状态变已归档', !!(af && af.archive_state === '已归档'), af && af.archive_state);
  const row = dbRow('SELECT rel_path FROM files WHERE archive_id=? ORDER BY sort_no, id LIMIT 1', a.id) || {};
  check('文件已移入归档区（按档号）', String(row.rel_path || '').startsWith('归档/'), row.rel_path);
  const newAbs = path.join(DATA, 'files', String(row.rel_path || ''));
  check('归档区文件存在、过程区已清空', !!row.rel_path && fs.existsSync(newAbs) && !fs.existsSync(abs), newAbs);

  const btAfter = await req('GET', `/api/batches/${batch.id}`);
  check('批次状态已归档', !!(btAfter.json && btAfter.json.data.batch.status === '已归档'));

  console.log(`\n通过 ${pass}，失败 ${fail}`);
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error('自测异常：' + (e && e.message));
  process.exit(1);
});
