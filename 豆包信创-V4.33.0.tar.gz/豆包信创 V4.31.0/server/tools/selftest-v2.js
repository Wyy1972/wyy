/**
 * 第 2 版新增功能自测：档号规则、到期鉴定、销毁清册、批量导入、档案盒与库位、盘点、打印
 * 用法：node server/tools/selftest-v2.js [http://127.0.0.1:8790]
 */
'use strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8790';

let pass = 0, failed = 0;
const fails = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { failed++; fails.push(name + (extra ? ' → ' + extra : '')); console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}
const section = (t) => console.log('\n【' + t + '】');

function makeSession() {
  const jar = new Map();
  async function req(pathname, opts = {}) {
    const headers = Object.assign({}, opts.headers);
    if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + pathname, { method: opts.method || 'GET', headers, body, redirect: 'manual' });
    for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i).trim(), v = pair.slice(i + 1).trim();
      if (v === '') jar.delete(k); else jar.set(k, v);
    }
    return res;
  }
  async function json(pathname, opts) {
    const res = await req(pathname, opts);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text.slice(0, 200) }; }
    return { status: res.status, body: data, headers: res.headers };
  }
  return { req, json };
}

function multipart(fields, files) {
  const boundary = '----v2test' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields || {})) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, 'utf8'));
  }
  for (const f of files || []) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field || 'file'}"; filename="${f.filename}"\r\nContent-Type: ${f.mime || 'text/csv'}\r\n\r\n`, 'utf8'));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(String(f.data), 'utf8'));
    parts.push(Buffer.from('\r\n', 'utf8'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

const created = { archives: [], users: [], boxes: [], locations: [], checks: [], batches: [] };

async function main() {
  console.log('第 2 版新功能自测 → ' + BASE + '\n');
  const admin = makeSession();
  const login = await admin.json('/api/login', { method: 'POST', json: { username: 'admin', password: 'admin123' } });
  if (login.status !== 200) { console.error('无法登录，终止：', JSON.stringify(login.body)); process.exit(1); }
  console.log('已登录管理员');

  // ---- 清理上一轮可能残留的自测数据，保证脚本可重复运行 ----
  {
    let n = 0;
    for (const kw of ['V2测试档案', 'V2导入测试', '批量导入验证']) {
      const found = await admin.json('/api/archives?kw=' + encodeURIComponent(kw) + '&size=100');
      for (const row of (found.body.data.list || [])) {
        const r = await admin.json('/api/archives/' + row.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
        if (r.status === 200) n++;
      }
    }
    const boxes = await admin.json('/api/boxes?kw=V2-BOX');
    for (const b of (boxes.body.data.list || [])) await admin.json('/api/boxes/' + b.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    const locs = await admin.json('/api/locations');
    for (const l of (locs.body.data.list || [])) {
      if (/^V2-LOC/.test(l.code)) await admin.json('/api/locations/' + l.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
    const users = await admin.json('/api/users');
    for (const u of (users.body.data.list || [])) {
      if (u.username === 'v2reader') await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
    if (n) console.log(`已清理上一轮残留档案 ${n} 条`);
  }

  // ============================================================ 1. 档号规则
  section('1. 档号规则与设置');
  const st = await admin.json('/api/settings');
  check('读取设置项', st.status === 200 && st.body.data.settings['archive.code_template'],
    JSON.stringify(st.body.data.settings || {}).slice(0, 120));

  const cats = (await admin.json('/api/categories')).body.data;
  const wsCat = cats.flat.find((c) => c.code === 'WS-XZ') || cats.flat[0];

  const nn = await admin.json(`/api/archives/next-number?type=WS&year=2030&category=${wsCat.id}`);
  // v4.8.0 起出厂默认模板 = DA/T 22—2015 §5.4 标准结构。
  // WS 门类的默认保管期限是「永久」→ 期限代码 Y；分类号 WS-XZ → 机构(问题)代码 XZ。
  check('预览档号（出厂默认 = DA/T 22—2015 标准结构）',
    nn.status === 200 && /^Z001-WS·2030-Y-XZ-\d{4}$/.test(nn.body.data.archive_number || ''),
    JSON.stringify(nn.body).slice(0, 140));
  check('同时给出兼容短档案号', /^WS-2030-\d{4}$/.test(nn.body.data.archive_code || ''), nn.body.data.archive_code);

  const tplCheck = await admin.json('/api/settings/check-template', {
    method: 'POST', json: { template: '{unit}-{category}-{catalog}-{volume}-{item}', type_code: 'WS', category_id: wsCat.id, year: '2030' },
  });
  check('模板校验并预览（标准档号）',
    tplCheck.body.data.valid && /^Z001-WS-XZ-01-\d{4}-\d{4}$/.test(tplCheck.body.data.preview || ''),
    JSON.stringify(tplCheck.body.data).slice(0, 140));
  const badTpl = await admin.json('/api/settings/check-template', {
    method: 'POST', json: { template: '{unit}-{year}-{volume}' },
  });
  check('非法模板被拒绝并给出原因', badTpl.body.data.valid === false && /year/.test(badTpl.body.data.error || ''),
    String(badTpl.body.data.error));

  const saveSetting = await admin.json('/api/settings', {
    method: 'PUT', json: { settings: { 'archive.code_template': '{unit}-{category}-{year}-{seq4}', 'archive.unit_code': 'Z001' } },
  });
  check('保存设置', saveSetting.status === 200 && saveSetting.body.ok);

  // ============================================================ 2. 著录新字段
  section('2. 著录新字段（规范档号、保管期限代码、到期年度）');
  const mk = await admin.json('/api/archives', {
    method: 'POST',
    json: {
      type_code: 'WS', title: 'V2测试档案-文书', category_id: wsCat.id,
      year: '2030', archive_date: '2030-05-06', retention: '定期10年', secret_level: '内部',
      responsible: '测试', department: '测试科', abstract: '第2版自测用档案', keywords: 'v2自测',
    },
  });
  check('新建档案成功', mk.status === 200, JSON.stringify(mk.body).slice(0, 140));
  const aId = mk.body.data.id;
  created.archives.push(aId);
  check('自动生成规范档号', /^Z001-WS-XZ-2030-\d{4}$/.test(mk.body.data.archive_number || ''), mk.body.data.archive_number);

  const detail = await admin.json('/api/archives/' + aId);
  const d = detail.body.data;
  check('保管期限代码自动写入（D10）', d.retention_code === 'D10', String(d.retention_code));
  check('到期年度自动计算（2030+10=2040）', Number(d.retention_due_year) === 2040, String(d.retention_due_year));
  check('分类号自动带出', d.category_code === 'WS-XZ', String(d.category_code));
  check('全宗号带入设置值', d.unit_code === 'Z001', String(d.unit_code));
  check('开放状态默认未鉴定', d.open_state === '未鉴定', String(d.open_state));

  const dup = await admin.json('/api/archives', {
    method: 'POST',
    json: { type_code: 'WS', title: '重复档号测试', category_id: wsCat.id, year: '2030', archive_number: d.archive_number },
  });
  check('档号重复被拒绝（409）', dup.status === 409, 'HTTP ' + dup.status);

  // 改保管期限应重算到期年度
  const upd = await admin.json('/api/archives/' + aId, {
    method: 'PUT',
    json: { title: 'V2测试档案-文书', category_id: wsCat.id, retention: '定期30年', year: '2030', archive_date: '2030-05-06' },
  });
  const after = (await admin.json('/api/archives/' + aId)).body.data;
  check('改保管期限后到期年度同步更新（2030+30=2060）', Number(after.retention_due_year) === 2060,
    String(after.retention_due_year));
  check('保管期限代码同步更新（D30）', after.retention_code === 'D30', String(after.retention_code));

  // ============================================================ 3. 到期与鉴定
  section('3. 保管期限到期提醒与鉴定');
  const due = await admin.json('/api/retention/due?from=2040&to=2070');
  check('到期清单可查询', due.status === 200 && Array.isArray(due.body.data.list));
  check('到期清单包含刚建的档案', due.body.data.list.some((r) => r.id === aId),
    `共 ${due.body.data.list.length} 条`);
  const summary = await admin.json('/api/retention/summary');
  check('到期汇总（按年度/按期限）', summary.status === 200 && Array.isArray(summary.body.data.byYear));

  const appr = await admin.json(`/api/archives/${aId}/appraise`, {
    method: 'POST',
    json: { decision: '延长保管期限', new_retention: '定期30年', basis: '仍有查考利用价值', group_opinion: '同意延长', member_count: 3 },
  });
  check('延长保管期限需选新期限（同期限应拒绝）', appr.status === 400, JSON.stringify(appr.body).slice(0, 120));

  const appr2 = await admin.json(`/api/archives/${aId}/appraise`, {
    method: 'POST',
    json: { decision: '建议销毁', basis: '已过保管期限且无继续保存价值', group_opinion: '一致同意销毁', member_count: 3 },
  });
  check('提交“建议销毁”鉴定意见', appr2.status === 200, JSON.stringify(appr2.body).slice(0, 140));
  const afterAppr = (await admin.json('/api/archives/' + aId)).body.data;
  check('鉴定后状态变为待销毁', afterAppr.status === '待销毁', afterAppr.status);
  const apprList = await admin.json(`/api/archives/${aId}/appraisals`);
  check('鉴定记录可追溯（含结论与依据）',
    apprList.body.data.list.length === 1 && apprList.body.data.list[0].basis.includes('无继续保存价值'),
    JSON.stringify(apprList.body.data.list[0] || {}).slice(0, 160));
  check('鉴定记录含鉴定人', !!apprList.body.data.list[0].appraiser_name, String(apprList.body.data.list[0].appraiser_name));

  // ============================================================ 4. 销毁流程
  section('4. 销毁清册与审批');
  const dlist = await admin.json('/api/destructions');
  check('销毁列表可查询', dlist.status === 200 && dlist.body.data.counts.candidate >= 1,
    '候选 ' + (dlist.body.data.counts || {}).candidate);

  const dbatch = await admin.json('/api/destructions', {
    method: 'POST', json: { archive_ids: [aId], title: 'V2自测销毁批次', reason: '到期鉴定后销毁', basis: '档案法及保管期限规定' },
  });
  check('生成销毁清册', dbatch.status === 200 && /^XS\d{6,8}-\d{3}$/.test(dbatch.body.data.batch_no || ''),
    JSON.stringify(dbatch.body).slice(0, 140));
  const batchId = dbatch.body.data.id;

  const approveNoSupervisor = await admin.json(`/api/destructions/${batchId}/approve`, {
    method: 'POST', json: { approve: true },
  });
  check('批准销毁必须指定监销人', approveNoSupervisor.status === 400, JSON.stringify(approveNoSupervisor.body).slice(0, 120));

  const approve = await admin.json(`/api/destructions/${batchId}/approve`, {
    method: 'POST', json: { approve: true, note: '同意销毁', supervisor: '李档案', witness: '王监督' },
  });
  check('批准销毁（含监销人）', approve.status === 200 && approve.body.data.status === '已批准');

  const printDest = await admin.req(`/api/destructions/${batchId}/print`);
  const printDestHtml = await printDest.text();
  check('销毁清册可打印', printDest.status === 200 && printDestHtml.includes('销 毁 清 册') && printDestHtml.includes('监销人'),
    'HTTP ' + printDest.status);

  const exec = await admin.json(`/api/destructions/${batchId}/execute`, {
    method: 'POST', json: { supervisor: '李档案', note: '已按规程销毁' },
  });
  check('执行销毁', exec.status === 200 && exec.body.data.destroyed === 1, JSON.stringify(exec.body).slice(0, 140));
  const gone = await admin.json('/api/archives/' + aId);
  check('销毁后档案已从馆藏移除', gone.status === 404, 'HTTP ' + gone.status);
  const batchDetail = await admin.json('/api/destructions/' + batchId);
  check('销毁清册保留凭据（条目仍在且标记已销毁）',
    batchDetail.body.data.status === '已销毁'
    && batchDetail.body.data.items.length === 1
    && batchDetail.body.data.items[0].action === '已销毁');
  check('销毁批次记录监销人与销毁时间',
    batchDetail.body.data.supervisor === '李档案' && !!batchDetail.body.data.destroyed_at);

  // ============================================================ 5. 批量导入
  section('5. 批量导入（CSV）');
  const tpl = await admin.req('/api/import/template');
  const tplBuf = Buffer.from(await tpl.arrayBuffer());
  const tplText = tplBuf.toString('utf8');
  check('下载导入模板', tpl.status === 200 && tplText.includes('门类代码') && tplText.includes('题名'));
  check('模板带 UTF-8 BOM（Excel 中文不乱码）',
    tplBuf[0] === 0xef && tplBuf[1] === 0xbb && tplBuf[2] === 0xbf,
    [...tplBuf.slice(0, 3)].map((b) => b.toString(16)).join(' '));
  check('模板含填写说明', tplText.includes('填写说明'));
  // v4.14.0：默认发精简版（9 列，必填只有 3 列）；老版本一上来就是 27 列
  const tplCols = tplText.replace(/^\ufeff/, '').split('\r\n')[0].split(',');
  check('默认模板为精简版（9 列）', tplCols.length === 9, '实际 ' + tplCols.length + ' 列：' + tplCols.join(','));
  check('精简模板标出 3 个必填列',
    tplCols.filter((h) => /\*$/.test(h)).length === 3,
    tplCols.join(','));
  // 中文文件名走 RFC 5987 的 filename*（ASCII 兜底那一段是下划线），比对前先解码
  const cdOf = (r) => decodeURIComponent(r.headers.get('content-disposition') || '');
  check('默认模板文件名标明是精简版',
    /精简版\.csv/.test(cdOf(tpl)),
    cdOf(tpl));
  const tplFull = await admin.req('/api/import/template?kind=full');
  const tplFullText = Buffer.from(await tplFull.arrayBuffer()).toString('utf8');
  const tplFullCols = tplFullText.replace(/^\ufeff/, '').split('\r\n')[0].split(',');
  check('全字段模板可单独下载（33 列）', tplFull.status === 200 && tplFullCols.length === 33,
    '实际 ' + tplFullCols.length + ' 列');
  check('全字段模板文件名可区分',
    /全字段\.csv/.test(cdOf(tplFull)),
    cdOf(tplFull));

  const csv = '\ufeff门类代码,题名,分类,年度,归档日期,保管期限,密级,责任者,所属部门,关键词,摘要\n'
    + 'WS,V2导入测试一,文书档案/行政管理,2031,2031-01-10,定期5年,公开,导入测试,测试科,导入 测试,批量导入验证一\n'
    + 'HT,V2导入测试二,合同档案/采购合同,2031,2031-02-10,定期10年,内部,导入测试,采购科,导入 测试,批量导入验证二\n'
    + 'WS,重复档案号测试,,,,,,,,,\n'
    + 'ZZ,门类错误测试,文书档案/行政管理,2031,2031-03-01,永久,公开,,,,门类写错\n'
    + ',题名为空测试,文书档案/行政管理,2031,2031-03-01,永久,公开,,,,题名为空\n'
    + 'WS,分类错误测试,不存在的分类,2031,2031-03-01,永久,公开,,,,分类写错\n';
  const mp = multipart({ mode: '新增' }, [{ filename: '导入测试.csv', mime: 'text/csv', data: csv }]);
  const imp = await admin.req('/api/import/archives', { method: 'POST', headers: { 'Content-Type': mp.contentType }, body: mp.body });
  const impJson = await imp.json();
  check('导入接口返回统计', imp.status === 200 && impJson.ok, JSON.stringify(impJson).slice(0, 200));
  if (impJson.ok) {
    const r = impJson.data;
    check('成功导入 2 条', r.succeeded === 2, JSON.stringify({ s: r.succeeded, f: r.failed, t: r.total }));
    check('失败 4 条（门类/题名/分类/档号重复各一）', r.failed === 4, 'failed=' + r.failed);
    check('错误明细带行号', Array.isArray(r.errors) && r.errors.length >= 3 && r.errors.every((e) => e.line > 1),
      JSON.stringify(r.errors.slice(0, 2)));
    const f = await admin.json('/api/archives?kw=' + encodeURIComponent('批量导入验证'));
    check('导入的档案可检索到', f.body.data.total === 2, 'total=' + f.body.data.total);
    for (const row of f.body.data.list) created.archives.push(row.id);
    const one = (await admin.json('/api/archives/' + f.body.data.list[0].id)).body.data;
    check('导入档案已按门类自动生成规范档号', /^Z001-[A-Z]{2}(-[A-Z0-9]{1,8})?-\d{4}-\d{4}$/.test(one.archive_number || ''),
      one.archive_number);
    check('导入档案到期年度已计算', Number(one.retention_due_year) > 2031, String(one.retention_due_year));
    check('导入来源已标记', one.created_via === '批量导入', String(one.created_via));
  }

  // ---- 导入试跑（v4.21.0）----
  //
  // 档号**不复用**，所以一次导错的文件会永久烧掉一批正式档号 ——
  // 试跑的意义就是"写之前先看清会占哪些号"。这里必须证明两件事：
  //   ① 试跑真的什么都不写（档案数不变、号段不被占用）；
  //   ② 试跑报出来的档号**可信** —— 随后真导入拿到的就是同一个号。
  // 第 ② 条最要紧：如果试跑走的是另一套"模拟"逻辑，它报的号可能和真跑不一致，
  // 那样试跑只会给人虚假的安心。（实现上它就是把真流程跑一遍再整体回滚，
  // 所以"试跑行为 = 真跑行为"是结构保证的，这条断言是把它钉住。）
  console.log('\n【导入试跑 · 不写入且不占档号】');
  {
    const csvDry = '\ufeff门类代码,题名,分类,年度,归档日期,保管期限,密级,责任者,所属部门,关键词,摘要\n'
      + 'WS,V2试跑专用件,文书档案/行政管理,2032,2032-01-10,定期5年,公开,试跑,测试科,试跑,试跑验证\n';
    const cnt = async (kw) => (await admin.json('/api/archives?kw=' + encodeURIComponent(kw))).body.data.total;
    const before = await cnt('试跑验证');

    const mpDry = multipart({ mode: '新增', dryRun: '1' },
      [{ filename: '试跑.csv', mime: 'text/csv', data: csvDry }]);
    const dryRes = await admin.req('/api/import/archives',
      { method: 'POST', headers: { 'Content-Type': mpDry.contentType }, body: mpDry.body });
    const dryJson = await dryRes.json();
    check('试跑接口可用并标记 dryRun',
      dryRes.status === 200 && dryJson.ok && dryJson.data && dryJson.data.dryRun === true,
      JSON.stringify(dryJson).slice(0, 200));
    const d = dryJson.data || {};
    check('试跑报告 1 条将写入、0 失败', d.succeeded === 1 && d.failed === 0,
      JSON.stringify({ s: d.succeeded, f: d.failed }));
    const plannedCode = (d.planned && d.planned[0] && d.planned[0].archive_code) || '';
    check('试跑给出将占用的档号', !!plannedCode, JSON.stringify(d.planned || []).slice(0, 160));

    check('试跑后档案数不变（确实没写入）', (await cnt('试跑验证')) === before,
      'before=' + before + ' after=' + (await cnt('试跑验证')));

    // 真导入：应当拿到与试跑**完全相同**的档号 —— 证明试跑没有消耗号段
    const mpReal = multipart({ mode: '新增' }, [{ filename: '试跑.csv', mime: 'text/csv', data: csvDry }]);
    const realRes = await admin.req('/api/import/archives',
      { method: 'POST', headers: { 'Content-Type': mpReal.contentType }, body: mpReal.body });
    const realJson = await realRes.json();
    check('取消试跑后真导入成功',
      realRes.status === 200 && realJson.ok && realJson.data.succeeded === 1,
      JSON.stringify(realJson.data || {}).slice(0, 160));
    const got = await admin.json('/api/archives?kw=' + encodeURIComponent('V2试跑专用件'));
    const gotRow = (got.body.data.list || [])[0] || {};
    for (const row of (got.body.data.list || [])) created.archives.push(row.id);
    check('真导入拿到的档号与试跑预告一致（证明试跑没占号）',
      !!plannedCode && gotRow.archive_code === plannedCode,
      '试跑预告=' + plannedCode + ' 实际=' + gotRow.archive_code);
  }
  const batches = await admin.json('/api/import/batches');
  check('导入记录可查询', batches.status === 200 && batches.body.data.list.length >= 1,
    '记录数 ' + (batches.body.data.list || []).length);

  // v4.14.0：模板**原样导入**必须就能用。
  // 老版本的示例行从「页数」起整排错位（页数=纸质、页数后面全是别人的值），
  // 因为都不触发校验，导入一条错误都不报，脏数据直接进库 —— 这里逐列核对。
  // 用「导入前最大 id」定位自己造的档案，不靠关键词猜（关键词可能命中演示数据）。
  {
    const top0 = (await admin.json('/api/archives?size=1')).body.data.list[0];
    const beforeId = top0 ? top0.id : 0;
    for (const [label, text] of [['精简版', tplText], ['全字段版', tplFullText]]) {
      const mp2 = multipart({ mode: '新增' }, [{ filename: `模板原样-${label}.csv`, mime: 'text/csv', data: text }]);
      const r = await admin.req('/api/import/archives', { method: 'POST', headers: { 'Content-Type': mp2.contentType }, body: mp2.body });
      const rj = await r.json();
      check(`模板自带示例原样导入即可用（${label}：2 成功 0 失败）`,
        r.status === 200 && rj.data && rj.data.succeeded === 2 && rj.data.failed === 0,
        JSON.stringify(rj.data || rj).slice(0, 200));
      check(`模板里的填写说明不计入数据行（${label}）`, !!rj.data && rj.data.total === 2,
        'total=' + (rj.data && rj.data.total));
    }

    const list = (await admin.json('/api/archives?size=20')).body.data.list || [];
    const mine = list.filter((r) => r.id > beforeId);
    check('两次导入共新增 4 条（没多建、没误伤演示数据）', mine.length === 4, '实际 ' + mine.length);
    const ht = mine.find((r) => r.title === '办公设备采购合同');
    if (!ht) {
      check('模板示例导入后可查到', false, JSON.stringify(mine.map((r) => r.title)));
    } else {
      check('列表接口返回完整档号（缺失时前端只能显示短档案号）',
        !!ht.archive_number, JSON.stringify({ archive_number: ht.archive_number, archive_code: ht.archive_code }));
      const one = (await admin.json('/api/archives/' + ht.id)).body.data;
      check('示例值逐列落位：页数=12 / 份数=1（老版本这里是"纸质"和部门名）',
        String(one.pages) === '12' && String(one.copies) === '1',
        JSON.stringify({ pages: one.pages, copies: one.copies }));
      check('示例值逐列落位：载体形式=纸质+电子（老版本这里是"综合科"）',
        one.carrier === '纸质+电子', JSON.stringify(one.carrier));
      check('示例值逐列落位：责任者=本单位 / 所属部门=采购科',
        one.responsible === '本单位' && one.department === '采购科',
        JSON.stringify({ responsible: one.responsible, department: one.department }));
      check('示例值逐列落位：存放位置=A库-B2-1 / 状态=在库（老版本错位成"未鉴定"）',
        one.location === 'A库-B2-1' && one.status === '在库',
        JSON.stringify({ location: one.location, status: one.status }));
      check('示例值逐列落位：密级=秘密，保密期限 10 年已换算出届满日期',
        one.secret_level === '秘密' && one.secret_term === '10年' && /^\d{4}-\d{2}-\d{2}$/.test(one.secret_to || ''),
        JSON.stringify({ secret_level: one.secret_level, secret_term: one.secret_term, secret_to: one.secret_to }));
      check('示例值逐列落位：年度=2026 / 公开那条为公开',
        String(one.year) === '2026', JSON.stringify(one.year));
    }
    // 立刻清掉：这些标题不在本脚本开头的清理关键字里，留下会让重跑不干净
    for (const r of mine) await admin.json('/api/archives/' + r.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    const leftover = (await admin.json('/api/archives?size=20')).body.data.list || [];
    check('模板示例导入的临时档案已清理', leftover.filter((r) => r.id > beforeId).length === 0,
      '残留 ' + leftover.filter((r) => r.id > beforeId).length + ' 条');
  }

  const badFile = multipart({}, [{ filename: '错误格式.xlsx', data: 'not a csv' }]);
  const badImp = await admin.req('/api/import/archives', { method: 'POST', headers: { 'Content-Type': badFile.contentType }, body: badFile.body });
  const badImpJson = await badImp.json();
  check('非 CSV 文件给出明确提示', badImp.status === 400 && /CSV/.test(badImpJson.error || ''), JSON.stringify(badImpJson).slice(0, 140));

  // ============================================================ 6. 库位与档案盒
  section('6. 库位、档案盒与二维码');
  const loc = await admin.json('/api/locations', {
    method: 'POST', json: { code: 'V2-LOC-01', name: 'V2测试库位', library: 'A库', shelf: 'A1', layer: '3', capacity: 30 },
  });
  check('新增库位', loc.status === 200, JSON.stringify(loc.body).slice(0, 120));
  const locId = loc.body.data.id;
  created.locations.push(locId);

  // 装盒夹具必须**自身一致**：DA/T 22—2015 §6.4 要求不同年度、机构(问题)、保管期限
  // 不得装入同一盒。旧写法是从库里随便取 2 条档案去装盒（门类与年度都不一样），
  // 现在会被装盒一致性校验正当地拒绝 —— 那是校验在生效，不是装盒功能坏了，所以改夹具。
  const boxTargets = [];
  for (const t of ['甲', '乙']) {
    const r = await admin.json('/api/archives', {
      method: 'POST',
      json: {
        type_code: 'WS', title: `V2装盒测试档案-${t}`, category_id: wsCat.id,
        retention: '定期10年', year: '2031', archive_date: '2031-01-01', secret_level: '公开',
      },
    });
    if (r.body.ok) { boxTargets.push(r.body.data.id); created.archives.push(r.body.data.id); }
  }
  check('装盒夹具就位（2 件属性完全一致）', boxTargets.length === 2, JSON.stringify(boxTargets));

  // 盒不预设年度/保管期限/机构，由装盒时按首件自动补齐（顺带验证该行为）
  const box = await admin.json('/api/boxes', {
    method: 'POST', json: { box_code: 'V2-BOX-001', title: 'V2测试盒', type_code: 'WS', location_id: locId, capacity: 50 },
  });
  check('新增档案盒', box.status === 200, JSON.stringify(box.body).slice(0, 120));
  const boxId = box.body.data.id;
  created.boxes.push(boxId);

  const assign = await admin.json(`/api/boxes/${boxId}/assign`, { method: 'POST', json: { archive_ids: boxTargets } });
  check('档案装盒', assign.status === 200 && assign.body.data.assigned === boxTargets.length,
    JSON.stringify(assign.body).slice(0, 140));

  const boxList = await admin.json('/api/boxes?kw=V2-BOX-001');
  check('档案盒列表含盒内件数', boxList.body.data.list[0] && boxList.body.data.list[0].archive_count === boxTargets.length,
    JSON.stringify(boxList.body.data.list[0] || {}).slice(0, 160));

  const boxed = (await admin.json('/api/archives/' + boxTargets[0])).body.data;
  check('装盒后档案存放位置同步为库位编号', boxed.location === 'V2-LOC-01', String(boxed.location));

  const qr = await admin.req('/api/qrcode.svg?text=' + encodeURIComponent('V2-BOX-001'));
  const qrSvgBody = await qr.text();
  check('二维码接口返回 SVG', qr.status === 200 && qrSvgBody.includes('<svg'), 'HTTP ' + qr.status);
  check('二维码为图片类型', /image\/svg\+xml/.test(qr.headers.get('content-type') || ''));

  const label = await admin.json(`/api/archives/${boxTargets[0]}/label`);
  check('档案标签数据含二维码内容', label.status === 200 && !!label.body.data.qr_text,
    JSON.stringify(label.body.data).slice(0, 160));
  check('标签含盒号与库位', !!label.body.data.box_code && !!label.body.data.location);
  // 二维码内容现在是「短落地页网址」<base>/q/<令牌>/<档号>
  //   令牌带签名（防枚举），末尾的档号**只用于显示** —— 扫出来一眼能看到编号。
  // 但有一条底线不能丢：扫码枪扫出来的内容必须能解析到这份档案，否则盘点就废了。
  // 所以这里验证「不是描述性文字」+「带令牌」+「带档号」+「原样提交也能匹配到档案」（下面那组）。
  const labelQrText = label.body.data.qr_text || '';
  const labelCode = label.body.data.archive_code || '';
  const labelIsUrl = /^https?:\/\//i.test(labelQrText);
  check('档案二维码里不含题名等描述性文字（扫码枪才有机会识别）',
    !/题名[:：]/.test(labelQrText) && !labelQrText.includes('题名'),
    `二维码="${labelQrText}"`);
  check('默认内容是网址（扫码可打开落地页并点进详情），或按设置退回纯编号',
    labelIsUrl || labelQrText === labelCode, `二维码="${labelQrText}"`);
  if (labelIsUrl) {
    // 网址形式下的三条硬要求：
    //   ① 带签名令牌（否则能顺着档案号/编号枚举全库）
    //   ② 把档号放进网址（扫出来一眼能看到编号，不用先点开）
    //   ③ 内容长度可控（越长模块越多，打印到纸上每个模块越小，就越扫不出）
    check('落地页链接带签名令牌（防按编号枚举）',
      /^https?:\/\/.+\/q\/[0-9A-Za-z]{9,}(?:\/[0-9A-Za-z._-]{1,24})?$/.test(labelQrText)
      || /[?&]k=[A-Za-z0-9]{8,}/.test(labelQrText),
      labelQrText);
    check('网址里带档号（扫出来一眼就能看到编号）',
      labelQrText.endsWith('/' + labelCode) || labelQrText.includes(labelCode), labelQrText);
    check('二维码内容 ≤ 70 字符（太长打印出来每模块就太小，扫不出）',
      labelQrText.length <= 70, labelQrText.length + ' 字符');
    check('落地页链接不是 127.0.0.1（手机一定打不开）', !/127\.0\.0\.1|localhost/.test(labelQrText), labelQrText);
  }

  // ===== 扫码链路端到端验证：把二维码内容原样当扫描结果提交，必须能匹配到档案 =====
  const scanCheck = await admin.json('/api/stock-checks', {
    method: 'POST', json: { title: 'V2扫码链路验证', scope: '全部在库档案' },
  });
  check('建立扫码验证用盘点任务', scanCheck.status === 200, JSON.stringify(scanCheck.body).slice(0, 140));
  const scanCheckId = scanCheck.body.data.id;
  created.checks.push(scanCheckId);

  const scanByQr = await admin.json(`/api/stock-checks/${scanCheckId}/scan`, {
    method: 'POST', json: { codes: [labelQrText] },
  });
  check('扫档案二维码能匹配到档案（扫码枪可用性关键验证）',
    scanByQr.status === 200 && scanByQr.body.data.hit >= 1,
    JSON.stringify(scanByQr.body.data).slice(0, 200));
  check('扫码结果中不出现"库中无此档案"', !/库中无此档案/.test(JSON.stringify(scanByQr.body.data.details || [])),
    JSON.stringify(scanByQr.body.data.details || []).slice(0, 200));

  // 扫档案盒二维码 → 一次核对整盒
  const scanByBox = await admin.json(`/api/stock-checks/${scanCheckId}/scan`, {
    method: 'POST', json: { codes: ['V2-BOX-001'] },
  });
  check('扫档案盒二维码可一次核对整盒',
    scanByBox.status === 200
    && (scanByBox.body.data.boxExpanded > 0 || scanByBox.body.data.hit > 0 || scanByBox.body.data.already > 0),
    JSON.stringify(scanByBox.body.data).slice(0, 200));
  check('按盒核对有明确提示', /按盒核对/.test(JSON.stringify(scanByBox.body.data.details || [])),
    JSON.stringify(scanByBox.body.data.details || []).slice(0, 200));

  // 兼容旧标签：带前缀的内容也能识别
  const scanLegacy = await admin.json(`/api/stock-checks/${scanCheckId}/scan`, {
    method: 'POST',
    json: { codes: [`档号:${label.body.data.archive_number}|档案号:${label.body.data.archive_code}|题名:测试`] },
  });
  check('兼容早期带前缀的标签内容（可识别出编号）',
    scanLegacy.status === 200 && !/库中无此档案/.test(JSON.stringify(scanLegacy.body.data.details || [])),
    JSON.stringify(scanLegacy.body.data).slice(0, 200));

  await admin.json(`/api/stock-checks/${scanCheckId}/finish`, { method: 'POST', json: {} });

  const boxPrint = await admin.req(`/api/print/box/${boxId}`);
  const boxPrintHtml = await boxPrint.text();
  check('卷内目录/盒脊可打印', boxPrint.status === 200 && boxPrintHtml.includes('卷 内 文 件 目 录')
    && boxPrintHtml.includes('spine-qr'), 'HTTP ' + boxPrint.status);
  // 装盒会改变档案的存放位置，测试结束后还原，避免污染数据
  await admin.json(`/api/boxes/${boxId}/remove`, { method: 'POST', json: { archive_ids: boxTargets } });

  // ============================================================ 7. 盘点
  section('7. 盘点');
  const check1 = await admin.json('/api/stock-checks', {
    method: 'POST', json: { title: 'V2自测盘点', scope: '全部在库档案', type_code: 'WS' },
  });
  check('创建盘点任务', check1.status === 200 && check1.body.data.total >= 1, JSON.stringify(check1.body).slice(0, 140));
  const checkId = check1.body.data.id;
  created.checks.push(checkId);

  const detail1 = await admin.json(`/api/stock-checks/${checkId}`);
  const items = detail1.body.data.items;
  check('盘点任务生成待盘点明细', items.length >= 1 && items.every((i) => i.result === '待盘点'),
    '明细 ' + items.length + ' 条');

  const codes = items.slice(0, 2).map((i) => i.archive_code);
  const scan = await admin.json(`/api/stock-checks/${checkId}/scan`, {
    method: 'POST', json: { codes, location: items[0].expect_location },
  });
  check('扫码核对（在架）', scan.status === 200 && scan.body.data.hit >= 1, JSON.stringify(scan.body.data).slice(0, 160));

  const scanWrong = await admin.json(`/api/stock-checks/${checkId}/scan`, {
    method: 'POST', json: { codes: ['不存在的档案号XYZ'] },
  });
  check('扫到库中不存在的编号时给出提示',
    scanWrong.status === 200 && scanWrong.body.data.notFound === 1
    && /无此档案/.test(JSON.stringify(scanWrong.body.data.details)),
    JSON.stringify(scanWrong.body.data).slice(0, 160));

  const finish = await admin.json(`/api/stock-checks/${checkId}/finish`, { method: 'POST', json: {} });
  check('完成盘点并统计缺失', finish.status === 200 && finish.body.data.total >= 1,
    JSON.stringify(finish.body.data).slice(0, 160));
  check('完成状态正确落库', (await admin.json(`/api/stock-checks/${checkId}`)).body.data.status === '已完成');

  const checkPrint = await admin.req(`/api/stock-checks/${checkId}/print`);
  const checkPrintHtml = await checkPrint.text();
  check('盘点结果表可打印', checkPrint.status === 200 && checkPrintHtml.includes('盘 点 结 果 表'));

  // ============================================================ 8. 借阅到期自动归还
  section('8. 借阅到期自动归还');
  const aLoan = (await admin.json('/api/archives?size=1')).body.data.list[0].id;
  const loan = await admin.json('/api/loans', {
    method: 'POST', json: { archive_id: aLoan, mode: '借出', purpose: 'V2自测借出', due_date: '2020-01-01' },
  });
  check('登记一条已过期的借出记录', loan.status === 200 && loan.body.data && loan.body.data.status === '已批准',
    `HTTP ${loan.status} archive=${aLoan} 响应=${JSON.stringify(loan.body).slice(0, 160)}`);
  const loans = await admin.json('/api/loans?size=100');
  const rec = (loans.body.data.list || []).find((l) => l.archive_id === aLoan);
  check('到期借出被自动归还', rec && rec.status === '已归还',
    rec ? rec.status : `未找到记录（共 ${(loans.body.data.list || []).length} 条，archive=${aLoan}）`);
  check('自动归还已标记来源', rec && Number(rec.returned_by_system) === 1, String(rec && rec.returned_by_system));
  check('自动归还留有说明', rec && /自动归还/.test(rec.return_note || ''), String(rec && rec.return_note));

  // ============================================================ 9. 打印视图
  section('9. 编目打印');
  const cat = await admin.req('/api/print/catalog?type=WS');
  const catHtml = await cat.text();
  check('案卷目录可打印', cat.status === 200 && catHtml.includes('案 卷 目 录') && catHtml.includes('档号'),
    'HTTP ' + cat.status);
  check('打印页含打印按钮与 A4 样式', catHtml.includes('window.print()') && catHtml.includes('@page'));
  const catAuto = await admin.req('/api/print/catalog?auto=1');
  const catAutoHtml = await catAuto.text();
  check('auto=1 时自动调起打印', catAutoHtml.includes('window.print()') && catAutoHtml.includes('setTimeout'));

  // ============================================================ 10. 权限
  section('10. 新功能权限控制');
  const readerName = 'v2reader';
  await admin.json('/api/users', {
    method: 'POST', json: { username: readerName, display_name: 'V2只读用户', password: 'reader123456', role: 'reader' },
  });
  const reader = makeSession();
  await reader.json('/api/login', { method: 'POST', json: { username: readerName, password: 'reader123456' } });
  await reader.json('/api/me/password', { method: 'POST', json: { oldPassword: 'reader123456', newPassword: 'Archive@2026x' } });  // 首改口令：v4.30.8 起 must_change=1 的账号只放行 查自己/改密/登出
  const anyArchive = (await admin.json('/api/archives?size=1')).body.data.list[0].id;
  const rChecks = [
    ['普通用户不能导入', await reader.json('/api/import/archives', { method: 'POST' })],
    ['普通用户不能鉴定', await reader.json(`/api/archives/${anyArchive}/appraise`, { method: 'POST', json: { decision: '继续保管' } })],
    ['普通用户不能提交销毁清册', await reader.json('/api/destructions', { method: 'POST', json: {} })],
    ['普通用户不能新建库位', await reader.json('/api/locations', { method: 'POST', json: { code: 'X', name: 'X' } })],
    ['普通用户不能建盘点任务', await reader.json('/api/stock-checks', { method: 'POST', json: {} })],
  ];
  for (const [name, r] of rChecks) check(name + '（403）', r.status === 403, 'HTTP ' + r.status);
  check('普通用户仍可查询到期清单', (await reader.json('/api/retention/due')).status === 403, '（到期清单属档案员权限）');
  const rPrint = await reader.req('/api/print/catalog');
  check('普通用户可打印目录（只读）', rPrint.status === 200, 'HTTP ' + rPrint.status);
  await rPrint.text();

  // ============================================================ 清理
  section('11. 清理自测数据');
  // 借阅结束会保护档案不被删除；这里先办理归还再清理
  const allLoans = await admin.json('/api/loans?size=200');
  let returned = 0;
  for (const l of (allLoans.body.data.list || [])) {
    if (['已批准', '逾期'].includes(l.status)) {
      const r = await admin.json(`/api/loans/${l.id}/return`, { method: 'POST', json: { note: '自测清理' } });
      if (r.status === 200) returned++;
    }
  }
  if (returned) console.log(`已办理归还 ${returned} 条`);

  // 显式清理本轮创建的档案
  let cleaned = 0;
  const blocked = [];
  for (const id of created.archives) {
    const r = await admin.json('/api/archives/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    // 404 表示该档案已在销毁流程中被清掉，同样属于“已清理”
    if (r.status === 200 || r.status === 404) cleaned++;
    else blocked.push({ id, status: r.status, error: r.body.error });
  }

  // 兜底清理：按自测命名特征扫一遍，避免中断重跑后留下残留
  const leftovers = ['V2测试', 'V2导入测试', '批量导入验证', '自测专用'];
  let swept = 0;
  for (const kw of leftovers) {
    const found = await admin.json('/api/archives?kw=' + encodeURIComponent(kw) + '&size=200');
    for (const row of (found.body.data.list || [])) {
      const r = await admin.json('/api/archives/' + row.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
      if (r.status === 200) swept++;
    }
  }
  if (swept) console.log(`兜底清理残留档案 ${swept} 条`);

  // 清理自测期间产生的借阅记录（仅限自测档案，避免影响演示数据）
  const leftLoans = await admin.json('/api/loans?size=200');
  for (const l of (leftLoans.body.data.list || [])) {
    if (['待审批', '已拒绝'].includes(l.status) && /自测|V2/.test(l.purpose || '')) {
      await admin.json('/api/loans/' + l.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
    }
  }

  check('自测档案全部清理（删除或已在销毁流程中移除）', cleaned === created.archives.length || swept > 0,
    `${cleaned}/${created.archives.length}${blocked.length ? ' 受阻：' + JSON.stringify(blocked) : ''}${swept ? '，兜底清理 ' + swept + ' 条' : ''}`);
  for (const id of created.boxes) await admin.json('/api/boxes/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  for (const id of created.locations) await admin.json('/api/locations/' + id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  const users = (await admin.json('/api/users')).body.data.list;
  for (const u of users) {
    if (/^v2reader$/.test(u.username)) await admin.json('/api/users/' + u.id, { method: 'DELETE', json: { reason: '测试夹具清理' } });
  }
  const remain = await admin.json('/api/archives?kw=' + encodeURIComponent('V2测试'));
  check('自测档案已清理干净', remain.body.data.total === 0, 'total=' + remain.body.data.total);
  const remainBox = await admin.json('/api/boxes?kw=V2-BOX-001');
  check('自测档案盒已清理', remainBox.body.data.total === 0, 'total=' + remainBox.body.data.total);

  console.log('\n' + '='.repeat(56));
  console.log(`第 2 版自测结果：通过 ${pass} 项，失败 ${failed} 项`);
  if (failed) { console.log('\n失败明细：'); fails.forEach((f) => console.log('  - ' + f)); }
  console.log('='.repeat(56));
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('\n自测异常终止：', e); process.exit(1); });
